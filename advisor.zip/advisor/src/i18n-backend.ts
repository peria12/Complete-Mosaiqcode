import i18n from 'i18next';
import backend from 'i18next-http-backend';
import { initReactI18next } from 'react-i18next';

const loadResources = async (locale: string) => {
    const translationUrl = 'http://localhost:3001';
    return await fetch(`${translationUrl}/${locale}`)
        .then((response) => response.json())
        .catch((error) => {
            // eslint-disable-next-line no-console
            console.log(error);
        });
};

const backendOptions = {
    loadPath: '{{lng}}|{{ns}}',
    request: (options: any, url: any, payload: any, callback: any) => {
        try {
            const [lng] = url.split('|');
            loadResources(lng).then((response) => {
                callback(null, { data: response, status: 200 });
            });
        } catch (e) {
            callback(null, { status: 500 });
        }
    }
};

i18n.use(initReactI18next)
    .use(backend)
    .init({
        backend: backendOptions,
        fallbackLng: 'en',
        load: 'languageOnly',
        ns: ['translations'],
        defaultNS: 'translations',
        keySeparator: false,
        interpolation: {
            escapeValue: false,
            formatSeparator: ','
        }
    });

export default i18n;
