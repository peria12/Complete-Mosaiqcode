import { Story } from '@storybook/react';
import SelectComponent from '../index';

export default {
    title: 'GOE/Atoms',
    component: SelectComponent
};

const Template: Story = (args) => {
    const { autoWidth, multiple, native, label, data, value, placeholder, id, onChange } = args;

    return (
        <SelectComponent
            autoWidth={autoWidth}
            multiple={multiple}
            native={native}
            label={label}
            data={data}
            value={value}
            placeholder={placeholder}
            id={id}
            onChange={onChange}
        />
    );
};

export const Select = Template.bind({});
Select.args = {
    autoWidth: false,
    multiple: false,
    native: false,
    label: 'Month',
    data: [
        {
            value: 'Conservative',
            label: 'Conservative'
        },
        {
            value: 'Somewhat Conservative',
            label: 'Somewhat Conservative'
        },
        {
            value: 'Moderate',
            label: 'Moderate'
        },
        {
            value: 'Somewhat Aggressive',
            label: 'Somewhat Aggressive'
        },
        {
            value: 'Aggressive',
            label: 'Aggressive'
        }
    ],
    value: 'Moderate',
    placeholder: 'Please select',
    id: 'month',
    onChange: () => {}
};
