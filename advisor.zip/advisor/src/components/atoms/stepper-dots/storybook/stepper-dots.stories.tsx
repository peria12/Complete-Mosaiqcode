import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import StepperDotsComponent from '../index';

export default {
    title: 'GOE/Atoms',
    component: StepperDotsComponent
};

const Template: Story = ({ data }) => (
    <Stack spacing={2} m={5}>
        <StepperDotsComponent data={data} />
    </Stack>
);

export const StepperDots = Template.bind({});

StepperDots.args = {
    data: [
        {
            value: 1,
            active: false
        },
        {
            value: 2,
            active: true
        },
        {
            value: 3,
            active: false
        },
        {
            value: 4,
            active: false
        },
        {
            value: 5,
            active: false
        }
    ]
};
