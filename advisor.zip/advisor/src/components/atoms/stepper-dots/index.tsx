import { styled } from '@mui/material/styles';

interface StyledDotProps {
    active?: boolean;
}

interface StepperDotsProps {
    data: Array<{
        value: number;
        active: boolean;
    }>;
}

const StepperDotsContainer = styled('div')(() => ({}));

const Dot = styled('span')<StyledDotProps>(({ theme, active }) => ({
    height: 16,
    width: 16,
    margin: '0 4px',
    background: active ? theme.palette.primary.main : theme.palette.common.white,
    borderRadius: 50,
    border: `1px solid ${theme.palette.primary.main}`,
    display: 'inline-block',
    cursor: 'pointer'
}));

function StepperDots({ data }: StepperDotsProps) {
    return (
        <StepperDotsContainer>
            {data.map(({ active }, index) => (
                <Dot key={index} active={active} />
            ))}
        </StepperDotsContainer>
    );
}

export default StepperDots;
