import React from 'react';
import { styled } from '@mui/material/styles';
import Typography, { TypographyProps } from '@mui/material/Typography';
import Slider from '@mui/material/Slider';
import { numberWithCommas } from '../../../utils/forms';

const SliderContainer = styled('div')(({ theme }) => ({
    minHeight: '64px',
    backgroundColor: theme.palette.slider.background,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    borderRadius: '4px',
    padding: '10px 12px',
    '& .MuiSlider-root': {
        marginTop: 0,
        padding: '0 0 12px 0'
    }
}));

const StyledSlider = styled(Slider)(({ theme }) => ({
    height: '8px',
    color: theme.palette.common.white,
    '& .MuiSlider-thumb': {
        width: '20px',
        height: '20px',
        '&:hover, &.Mui-focusVisible': {
            boxShadow: 'none'
        },
        '&.Mui-active': {
            boxShadow: 'none'
        }
    },
    '& .MuiSlider-rail': {
        color: theme.palette.slider.rail,
        height: '10px'
    }
}));

const SliderTypography = styled(Typography)<TypographyProps>(({ theme }) => ({
    margin: 0,
    color: theme.palette.common.white,
    fontWeight: 500,
    paddingBottom: '8px'
}));

const SliderLabel = styled(Typography)<TypographyProps>(() => ({
    margin: '4px 0',
    fontSize: '0.75rem'
}));

interface SliderComponentProps {
    label: string;
    min: number;
    max: number;
    val: number;
    step: number;
}

const SliderComponent = ({ label, min, max, val, step }: SliderComponentProps) => {
    const [value, setValue] = React.useState<number>(val);

    const handleChange = (event: Event, newValue: number | number[]) => {
        if (typeof newValue === 'number') {
            setValue(newValue);
        }
    };

    return (
        <>
            <SliderLabel>{label}</SliderLabel>
            <SliderContainer>
                <SliderTypography variant="body1" id="range-slider">
                    {`$ ${numberWithCommas(value)}`}
                </SliderTypography>
                <StyledSlider
                    aria-labelledby="range-slider"
                    value={value}
                    onChange={handleChange}
                    min={min}
                    max={max}
                    step={step}
                />
            </SliderContainer>
        </>
    );
};

export default SliderComponent;
