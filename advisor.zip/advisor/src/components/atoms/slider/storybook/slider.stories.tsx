import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import SliderComponent from '../index';

export default {
    title: 'GOE/Atoms',
    component: SliderComponent
};

const Template: Story = ({ label, min, max, val, step }) => (
    <Stack direction="column" m={5}>
        <SliderComponent label={label} min={min} max={max} val={val} step={step} />
    </Stack>
);

export const Slider = Template.bind({});

Slider.args = {
    label: 'Target Amount',
    min: 500,
    max: 50000,
    val: 1000,
    step: 500
};
