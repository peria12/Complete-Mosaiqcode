import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import DatePickerComponent from '../index';

export default {
    title: 'GOE/Atoms',
    component: DatePickerComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <DatePickerComponent {...args} />
    </Stack>
);

export const DatePickerInput = Template.bind({});

DatePickerInput.args = {
    name: 'date',
    label: 'date',
    value: '',
    placeholder: 'dd/mm/yyyy',
    onChange: () => {},
    type: 'date',
    error: false,
    id: 'date-input'
};
