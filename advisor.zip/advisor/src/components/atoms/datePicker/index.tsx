import { styled } from '@mui/material/styles';
import InputBase, { InputBaseProps } from '@mui/material/InputBase';
import FormControl from '@mui/material/FormControl';
import CheckIcon from '@mui/icons-material/Check';

const BootstrapFormControl = styled(FormControl)(() => ({
    width: '100%',
    display: 'flex'
}));

const BootstrapInputLabel = styled('div')(({ theme }) => ({
    display: 'flex',
    position: 'relative',
    borderRadius: 4,
    backgroundColor: theme.palette.common.white,
    flexGrow: 1,
    width: '100%',
    // '& :first-child': {
    //   flexGrow: 1
    // },
    '.MuiInputBase-root': {
        width: '100%'
    }
}));
const BootstrapDateInput = styled(InputBase)(({ theme, error, value }) => ({
    'label + &': {
        marginTop: theme.spacing(3)
    },
    'input#goal-date': {
        position: 'relative',
        overflow: 'hidden'
    },
    'input#goal-date::-webkit-calendar-picker-indicator': {
        display: 'block',
        width: '100%',
        top: 0,
        left: 0,
        position: 'absolute',
        transform: 'scale(12)'
    },
    '& .MuiInputBase-input': {
        position: 'relative',
        backgroundColor: value ? theme.palette.goal.formFields.background : theme.palette.common.white,
        border: error ?
            `1px solid ${theme.palette.error.main}` :
            value ?
            `1px solid ${theme.palette.primary.main} !important` :
            `1px solid ${theme.palette.common.black} !important`,
        borderRadius: 4,
        fontSize: 16,
        width: '100%',
        padding: '8px 12px',
        transition: theme.transitions.create(['border-color', 'background-color', 'box-shadow']),
        '&:focus': {
            boxShadow: '0px 0px 4px rgba(0, 0, 0, 0.25)',
            borderColor: error ? theme.palette.error.main : theme.palette.primary.main
        },
        '&::placeholder': {
            color: theme.palette.common.black,
            fontWeight: 600,
            fontSize: 14
        }
    },
    '& .MuiInputBase-input:valid': {
        backgroundColor: value ? theme.palette.goal.formFields.background : '',
        borderColor: theme.palette.primary.main
    }
}));
const SearchIconWrapper = styled('div')(({ theme }) => ({
    alignSelf: 'flex-end',
    marginTop: '-22px',
    paddingRight: '12px',
    zIndex: '2',
    '.MuiSvgIcon-root': {
        fontSize: '18px',
        color: theme.palette.primary.main,
        backgroundColor: theme.palette.goal.formFields.background
    }
}));

interface InputProps extends InputBaseProps {
    label?: string;
    type?: string;
}

function DatePickerInput(props: InputProps) {
    const { label, type, placeholder, id, error, value } = props;
    return (
        <BootstrapFormControl variant="standard">
            {label ? <BootstrapInputLabel>{label} </BootstrapInputLabel> : ''}
            <BootstrapDateInput
                inputProps={{ 'aria-label': label }}
                type={type}
                error={error}
                id={id}
                value={value}
                placeholder={placeholder}
                {...props}
            />
            {value ? (
                <SearchIconWrapper>
                    <CheckIcon />
                </SearchIconWrapper>
            ) : (
                ''
            )}
        </BootstrapFormControl>
    );
}

export default DatePickerInput;
