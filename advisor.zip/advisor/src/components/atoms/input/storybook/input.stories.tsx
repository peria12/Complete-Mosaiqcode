import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import InputComponent from '../index';

export default {
    title: 'GOE/Atoms',
    component: InputComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <InputComponent {...args} />
    </Stack>
);

export const Input = Template.bind({});

Input.args = {
    name: 'email',
    label: 'Email',
    value: 'johndoe@gmail.com',
    placeholder: 'Enter Email',
    onChange: () => {},
    type: 'email',
    error: false,
    id: 'email-input'
};
