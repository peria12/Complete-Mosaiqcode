import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import CheckboxComponent from '../index';

export default {
    title: 'GOE/Atoms',
    component: CheckboxComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <CheckboxComponent {...args} />
    </Stack>
);

export const Checkbox = Template.bind({});

Checkbox.args = {
    checked: true,
    disabled: true
};
