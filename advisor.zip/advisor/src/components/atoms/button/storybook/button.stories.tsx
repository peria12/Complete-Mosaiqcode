import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import ButtonComponent from '../index';

export default {
    title: 'GOE/Atoms',
    component: ButtonComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <ButtonComponent {...args}>Button</ButtonComponent>
    </Stack>
);

export const Button = Template.bind({});

Button.args = {
    variant: 'contained',
    size: 'medium',
    disabled: false
};
