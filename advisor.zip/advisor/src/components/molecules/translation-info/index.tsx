import { styled } from '@mui/material/styles';
import { useForm, Controller } from 'react-hook-form';
import Grid from '@mui/material/Grid';
import { useTranslation } from 'react-i18next';

import Input from '../../atoms/input';
import ButtonComponent from '../../atoms/button';

const GridContainer: any = styled(Grid)(() => ({
    '.MuiInputBase-input': {
        boxSizing: 'border-box'
    },
    marginTop: '2px'
}));

const ErrorSpan = styled('span')(({ theme }) => ({
    color: theme.palette.goal.formFields.errorLabel,
    fontSize: '12px'
}));

const AccordianFooter: any = styled('div')(() => ({
    marginTop: '110px',
    marginBottom: '30px',
    textAlign: 'right'
}));

const ButtonContainer = styled('span')(() => ({
    display: 'inline-block',
    margin: '6px'
}));

interface FormInput {
    id: string | number;
    lookupKey: string | number;
    lookupValue: string | number;
    description?: string;
}

interface TranslationInfoProps {
    // eslint-disable-next-line no-unused-vars
    onSubmit: (formValues: FormInput) => void;
    onCancel: () => void;
    submitButtonText?: string;
    data?: FormInput;
}

export default function TranslationInfo({ data, submitButtonText, onSubmit, onCancel }: TranslationInfoProps) {
    const { t } = useTranslation();
    const {
        handleSubmit,
        control,
        formState: { errors, isValid }
    } = useForm<FormInput>({
        mode: 'onBlur',
        reValidateMode: 'onChange',
        defaultValues: data || {}
    });

    return (
        <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <GridContainer container spacing={2}>
                <GridContainer item xs={12} sm={6} md={3}>
                    <Controller
                        name="lookupKey"
                        control={control}
                        rules={{
                            required: true
                        }}
                        render={({ field: { onChange, onBlur, value, ref } }) => (
                            <Input
                                onBlur={onBlur}
                                onChange={onChange}
                                value={value}
                                inputRef={ref}
                                error={!!errors.lookupKey}
                                label={t('TEXT_LABEL_LOOK_UP_KEY')}
                                type="text"
                            />
                        )}
                    />
                    {errors.lookupKey && <ErrorSpan role="alert">{errors.lookupKey.message}</ErrorSpan>}
                </GridContainer>

                <GridContainer item xs={12} sm={6} md={3}>
                    <Controller
                        name="lookupValue"
                        control={control}
                        rules={{
                            required: true
                        }}
                        render={({ field: { onChange, onBlur, value, ref } }) => (
                            <Input
                                onBlur={onBlur}
                                onChange={onChange}
                                value={value}
                                inputRef={ref}
                                error={!!errors.lookupValue}
                                label={t('TEXT_LABEL_LOOK_UP_VALUE')}
                                type="text"
                            />
                        )}
                    />
                    {errors.lookupValue && <ErrorSpan role="alert">{errors.lookupValue.message}</ErrorSpan>}
                </GridContainer>

                <GridContainer item xs={12} sm={6} md={3}>
                    <Controller
                        name="description"
                        control={control}
                        rules={{
                            required: false
                        }}
                        render={({ field: { onChange, onBlur, value, ref } }) => (
                            <Input
                                onBlur={onBlur}
                                onChange={onChange}
                                value={value}
                                inputRef={ref}
                                error={!!errors.description}
                                label={t('TEXT_LABEL_DESCRIPTION')}
                                type="text"
                            />
                        )}
                    />
                    {errors.description && <ErrorSpan role="alert">{errors.description.message}</ErrorSpan>}
                </GridContainer>
            </GridContainer>

            <AccordianFooter>
                <ButtonContainer>
                    <ButtonComponent variant="outlined" onClick={onCancel}>
                        {t('TEXT_LABEL_CANCEL')}
                    </ButtonComponent>
                </ButtonContainer>
                <ButtonComponent
                    type="submit"
                    variant={!isValid ? 'outlined' : 'contained'}
                    custom={+!isValid}
                    disabled={!isValid}
                >
                    {submitButtonText || t('TEXT_LABEL_SUBMIT_BUTTON')}
                </ButtonComponent>
            </AccordianFooter>
        </form>
    );
}
