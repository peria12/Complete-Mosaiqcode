import { useState } from 'react';
import { styled } from '@mui/material/styles';
import Typography, { TypographyProps } from '@mui/material/Typography';
import CircularCheckbox from '../../atoms/circularCheckbox';

interface ArrayList {
    icon: string;
    value: number;
    active: boolean;
    helperText: string;
    label: string;
}

interface DataList {
    DataObj: Array<ArrayList>;
    heading1: string;
    heading2: string;
    subheading1: string;
    subheading2: string;
    showHr: boolean;
}
const Hr = styled('hr')(({ theme }) => ({
    position: 'absolute',
    height: '2px',
    width: '80%',
    background: theme.palette.grey[600],

    [theme.breakpoints.up('sm')]: {
        top: 'calc(85px / 2)'
    },
    [theme.breakpoints.up('md')]: {
        top: 'calc(85px / 2)'
    },
    [theme.breakpoints.up('lg')]: {
        top: 'calc(85px / 2)'
    },
    left: '50%',
    zIndex: '0',
    transform: 'translate(-50%, -50%)'
}));
const RiskHeadings = styled('div')(() => ({
    marginTop: '30px',
    display: 'flex',
    justifyContent: 'space-between',
    fontWeight: '500',
    fontSize: '24px',
    lineHeight: '30px',
    textTransform: 'capitalize',
    color: '#333333'
}));
const RiskSubHeadings = styled('div')(() => ({
    display: 'flex',
    flexDirection: 'column'
    // justifyContent: 'space-between'
}));
const SubheadingHelperText = styled(Typography)<TypographyProps>(() => ({
    fontSize: '12px'
}));
const ProgressContainer = styled('div')(() => ({
    display: 'inline-flex',
    position: 'relative',
    width: '100%'
}));
const singleStepData = ({ DataObj, heading1, heading2, subheading1, subheading2, showHr }: DataList) => {
    const [DataValue, setDataValue] = useState<any[]>(DataObj);

    const changeActive = (index: any) => {
        DataObj[index].active = !DataObj[index].active;

        DataObj.filter((_, idx) => idx !== index).map((itm) => {
            const newItm = {
                ...itm
            };
            newItm.active = false;
            return newItm;
        });
        setDataValue([...DataObj]);
    };

    return (
        <>
            {heading1 ? (
                <RiskHeadings>
                    <RiskSubHeadings>
                        <span>{heading1}</span>
                        <SubheadingHelperText variant="subtitle1">{subheading1}</SubheadingHelperText>
                    </RiskSubHeadings>
                    <RiskSubHeadings>
                        <span>{heading2}</span>
                        <SubheadingHelperText variant="subtitle1">{subheading2}</SubheadingHelperText>
                    </RiskSubHeadings>
                </RiskHeadings>
            ) : (
                ''
            )}

            <ProgressContainer>
                {showHr ? <Hr /> : ''}
                {DataValue.map((item, index) => (
                    <CircularCheckbox
                        key={index}
                        value={item.value}
                        helperText={item.helperText}
                        label={item.label}
                        active={item.active}
                        changeActive={() => {
                            changeActive(index);
                        }}
                    />
                ))}
            </ProgressContainer>
        </>
    );
};

export default singleStepData;
