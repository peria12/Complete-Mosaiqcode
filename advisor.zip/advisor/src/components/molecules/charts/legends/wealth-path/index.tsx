import { styled } from '@mui/material/styles';
import Typography, { TypographyProps } from '@mui/material/Typography';
import { useTranslation } from 'react-i18next';
import { isEmpty } from 'lodash';
import { format } from '../../../../../utils/charts';

interface BgColor {
    bgcolor?: string;
}

const Container = styled('div')(() => ({
    display: 'flex',
    marginLeft: '40px'
}));

const LegendContainer = styled('div')(() => ({
    display: 'flex',
    alignItems: 'center',
    marginRight: '16px'
}));

const AverageBox = styled('div')<BgColor>(({ bgcolor }) => ({
    height: '2px',
    width: '8px',
    backgroundColor: bgcolor,
    marginRight: '4px'
}));

const ContributionBox = styled('div')<BgColor>(({ bgcolor }) => ({
    height: '2px',
    width: '8px',
    backgroundColor: bgcolor,
    marginRight: '4px'
}));

const StyledLabelTypography = styled(Typography)<TypographyProps>(() => ({
    margin: '0px',
    fontSize: '12px',
    fontWeight: 400,
    lineHeight: '15px',
    marginRight: '4px'
}));

const StyledAllocationTypography = styled(Typography)<TypographyProps>(() => ({
    margin: '0px',
    fontSize: '14px',
    fontWeight: 700
}));

const WealthPathLegend = ({
    average,
    contribution,
    averageColor,
    contributionColor,
    contributionTranslation,
    translation,
    currency
}: any) => {
    const { t } = useTranslation();
    return (
        <>
            <Container>
                <LegendContainer>
                    <AverageBox bgcolor={averageColor} />
                    <StyledLabelTypography>{t('TEXT_WEALTH_PATH_AVERAGE')} </StyledLabelTypography>
                    {!isEmpty(average) && (
                        <StyledAllocationTypography variant="body1">
                            {format(average[average.length - 1], currency, translation)}
                        </StyledAllocationTypography>
                    )}
                </LegendContainer>
                <LegendContainer>
                    <ContributionBox bgcolor={contributionColor} />
                    <StyledLabelTypography>{contributionTranslation} </StyledLabelTypography>
                    {!isEmpty(contribution) && (
                        <StyledAllocationTypography variant="body1">
                            {format(contribution[contribution.length - 1], currency, translation)}
                        </StyledAllocationTypography>
                    )}
                </LegendContainer>
            </Container>
        </>
    );
};

export default WealthPathLegend;
