import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import { useTranslation } from 'react-i18next';

import WealthPathComponent from '../index';

export default {
    title: 'GOE/Molecules/Charts',
    component: WealthPathComponent
};

const Template: Story = (args) => {
    const { t } = useTranslation();
    return (
        <Stack direction="column" spacing={2} m={5}>
            <WealthPathComponent {...args} translation={t} />
        </Stack>
    );
};

export const WealthPath = Template.bind({});

WealthPath.args = {
    theme: {
        breakpoints: {
            keys: ['xs', 'sm', 'md', 'lg', 'xl'],
            values: { xs: 0, sm: 768, md: 992, lg: 1440, xl: 1920 },
            unit: 'px'
        },
        direction: 'ltr',
        components: {
            MuiCssBaseline: {
                styleOverrides: {
                    '@font-face': [
                        {
                            fontFamily: 'TT Commons Pro',
                            src: " \n      local('TT Commons Pro'),\n      url(/static/media/TTCommonsProRegular.e42cf10cd17cb50fdb86.ttf) format('truetype'),\n      url(/static/media/TTCommonsClassicRegular.daab958bfa744680ed7e.ttf) format('truetype'),\n      url(/static/media/TTCommonsProCondensedRegular.dab90b0b0326974691c6.ttf) format('truetype')\n    "
                        }
                    ]
                }
            },
            MuiButtonBase: {
                defaultProps: { disableRipple: true },
                styleOverrides: { root: { textTransform: 'none' } }
            },
            MuiCheckbox: { defaultProps: { disableRipple: true } }
        },
        palette: {
            mode: 'light',
            common: { black: '#000000', white: '#FFFFFF' },
            primary: {
                extraLight: '#DDEAFF',
                light: '#DDEAFF',
                main: '#3769FF',
                dark: '#1446E1',
                contrastText: '#FFFFFF'
            },
            secondary: { light: '#6cc247', main: '#5abc2a', dark: '#589435', contrastText: '#FFFFFF' },
            success: { contrastText: '#FFFFFF', dark: '#006600', main: '#006600', light: '#006600' },
            info: { contrastText: '#005ea5', dark: '#FFFFFF', main: '#FFFFFF', light: '#FFFFFF' },
            warning: { contrastText: '#FFFFFF', dark: '#7986cb', main: '#7986cb', light: '#7986cb' },
            error: {
                light: '#e57373',
                main: '#CC0000',
                dark: '#d32f2f',
                contrastText: '#FFFFFF',
                background: 'rgba(230,0,0,0.06)'
            },
            grey: {
                50: '#fafafa',
                100: '#f5f5f5',
                200: '#eeeeee',
                300: '#e0e0e0',
                400: '#bdbdbd',
                500: '#9e9e9e',
                600: '#767676',
                700: '#616161',
                800: '#424242',
                900: '#333333',
                A100: '#d5d5d5',
                A200: '#aaaaaa',
                A400: '#303030',
                A700: '#616161',
                A800: '#454545'
            },
            text: {
                primary: '#000000',
                secondary: '#3769FF',
                disabled: '#9a9a9a',
                hint: '#aaaaaa',
                grey: '#726e70'
            },
            button: { grey: '#918c8b', green: '#5abc2a', blue: '#3769FF' },
            background: { paper: '#FFFFFF', default: '#FFFFFF', light: '#E1F3F8' },
            action: {
                active: 'rgba(0, 0, 0, 0.54)',
                hover: 'rgba(0, 0, 0, 0.08)',
                hoverOpacity: 0.08,
                selected: 'rgba(0, 0, 0, 0.14)',
                selectedOpacity: 0.08,
                disabled: 'rgba(0, 0, 0, 0.26)',
                disabledBackground: 'rgba(0, 0, 0, 0.12)',
                disabledOpacity: 0.38,
                focus: 'rgba(0, 0, 0, 0.12)',
                focusOpacity: 0.12,
                activatedOpacity: 0.12
            },
            divider: 'rgba(0, 0, 0, 0.12)',
            type: 'light',
            icon: '#005ea5',
            table: {
                header: '#ddeaff',
                row: { even: '#fafafa', odd: '#fefefe', hover: '#eff5ff' },
                score: { 50: '#DC0546', 75: '#FF9665', 100: '#00847D' }
            },
            slider: { background: '#3769FF', rail: '#91B9FF', label: '#333333' },
            goal: {
                formFields: { background: '#DDEAFF', errorBackground: '#FFDDE6', errorLabel: '#FF0F52' },
                heading: {
                    background: {
                        content: '#698EFF',
                        savingGoal: '#E1E9FF',
                        clientInfo: '#B2C6FF',
                        riskTolerance: '#C8D6FF'
                    }
                },
                button: { disabled: '#E8E8E8' }
            },
            charts: {
                glidePath: {
                    equity: '#B39AF5',
                    fixedIncome: '#72DBD5',
                    pie: { equity: '#9370E2', fixedIncome: '#00BFB3' },
                    line: '#086bf7',
                    label: { equity: '#9370E2', fixedIncome: '#00BFB3' }
                },
                portfolioComposition: { equity: '#9370E2', fixedIncome: '#00BFB3' }
            },
            wealthPath: {
                goodProb: '#00847D',
                moderateProb: '#FF9665',
                badProb: '#DC0546',
                yAxisPlotLine: '#000',
                tick: '#000',
                axisLabel: '#767676',
                title: '#000',
                crosshair: '#000',
                accumulationLine: '#9370E2',
                drawdownLine: '#C042EA',
                gridLine: '#fff'
            },
            recommendation: { amount: '#3769FF', amountBorderBottom: '#3769FF' },
            layout: { primary: '#3769ff' },
            contrastThreshold: 3,
            tonalOffset: 0.2
        },
        shape: { borderRadius: 4 },
        typography: {
            htmlFontSize: 16,
            fontFamily: 'TT Commons Pro',
            fontSize: 14,
            fontWeightLight: 300,
            fontWeightRegular: 400,
            fontWeightMedium: 500,
            fontWeightBold: 700,
            h1: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 300,
                fontSize: '3.125rem',
                lineHeight: '3.5rem',
                color: '#000000',
                letterSpacing: '-0.01562em',
                '@media (max-width: 1440px)': { fontSize: '2rem', lineHeight: '2.5rem' },
                '@media (max-width: 768px)': {
                    fontSize: 'calc(2rem + (((100vw - 48rem) / (90 - 48))) * (3.125 - 2))',
                    lineHeight: 'calc(2.75rem + (((100vw - 48rem) / (90 - 48))) * (2.125 - 1.5))'
                }
            },
            h2: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 300,
                fontSize: '2.125rem',
                lineHeight: '2.5rem',
                color: '#000000',
                letterSpacing: '-0.00833em',
                '@media (max-width: 1440px)': { fontSize: '1.5rem', lineHeight: '2.25rem' },
                '@media (max-width: 768px)': {
                    fontSize: 'calc(1.5rem + (((100vw - 48rem) / (90 - 48))) * (2.125 - 1.5))',
                    lineHeight: 'calc( 1.75rem + (((100vw - 48rem) / (90 - 48))) * (2.125 - 1.5))'
                }
            },
            h3: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 400,
                fontSize: '1.875rem',
                lineHeight: '2.5rem',
                color: '#000000',
                letterSpacing: '0em',
                '@media (max-width: 1440px)': { fontSize: '1.25rem', lineHeight: '1.875rem' },
                '@media (max-width: 768px)': {
                    fontSize: 'calc(1.25rem + (((100vw - 48rem) / (90 - 48))) * (1.875 - 1.25))',
                    lineHeight: 'calc(2rem + (((100vw - 48rem) / (90 - 48))) * (1.875 - 1.25))'
                }
            },
            h4: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 800,
                fontSize: '1.375rem',
                lineHeight: '2.063rem',
                color: '#000000',
                letterSpacing: '0.00735em',
                '@media (max-width: 1440px)': { fontSize: '0.875rem', lineHeight: 'inherit' },
                '@media (max-width: 768px)': {
                    fontSize: 'calc(0.875rem + (((100vw - 48rem) / (90 - 48))) * (1.375 - 0.875))',
                    lineHeight: 'calc(1.25rem + (((100vw - 48rem) / (90 - 48))) * (1.375 - 0.875))'
                }
            },
            h5: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 400,
                fontSize: '1.125rem',
                lineHeight: '1.625rem',
                color: '#000000',
                letterSpacing: '0em',
                '@media (max-width: 1440px)': { fontSize: '1.125rem', lineHeight: 'inherit' },
                '@media (max-width: 768px)': {
                    fontSize: 'calc(0.875rem + (((100vw - 48rem) / (90 - 48))) * (1.375 - 0.875))',
                    lineHeight: '2.5rem'
                }
            },
            h6: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 500,
                fontSize: '1.25rem',
                lineHeight: '1.8rem',
                color: '#726e70',
                letterSpacing: '0.0075em'
            },
            subtitle1: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 400,
                fontSize: 'calc(1rem + (1 - 1) * ((100vw - 20rem) / (120 - 20)))',
                lineHeight: 1.75,
                color: '#000000',
                letterSpacing: '0.00938em'
            },
            subtitle2: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 500,
                fontSize: 'calc(1rem + (0.875 - 1) * ((100vw - 20rem) / (120 - 20)))',
                lineHeight: 1.57,
                color: '#9a9a9a',
                letterSpacing: '0.00714em'
            },
            body1: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 400,
                fontSize: 'calc(1rem + (1 - 1) * ((100vw - 20rem) / (120 - 20)))',
                lineHeight: 1.5,
                color: '#000000',
                letterSpacing: '0.00938em'
            },
            body2: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 400,
                fontSize: 'calc(1rem + (0.875 - 1) * ((100vw - 20rem) / (120 - 20)))',
                lineHeight: 1.43,
                color: '#726e70',
                letterSpacing: '0.01071em'
            },
            button: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 500,
                fontSize: '1rem',
                lineHeight: 1.75,
                textTransform: 'uppercase'
            },
            caption: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 400,
                fontSize: 'calc(1rem + (0.75 - 1) * ((100vw - 20rem) / (120 - 20)))',
                lineHeight: 2.66,
                color: '#9a9a9a',
                letterSpacing: '0.03333em'
            },
            overline: {
                fontFamily: 'TT Commons Pro',
                fontWeight: 400,
                fontSize: '0.75rem',
                lineHeight: 2.66,
                textTransform: 'uppercase'
            }
        },
        mixins: {
            toolbar: {
                minHeight: 56,
                '@media (min-width:0px)': { '@media (orientation: landscape)': { minHeight: 48 } },
                '@media (min-width:768px)': { minHeight: 64 }
            }
        },
        shadows: [
            'none',
            '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            '0px 3px 1px -2px rgba(0,0,0,0.2),0px 2px 2px 0px rgba(0,0,0,0.14),0px 1px 5px 0px rgba(0,0,0,0.12)',
            '0px 3px 3px -2px rgba(0,0,0,0.2),0px 3px 4px 0px rgba(0,0,0,0.14),0px 1px 8px 0px rgba(0,0,0,0.12)',
            '0px 2px 4px -1px rgba(0,0,0,0.2),0px 4px 5px 0px rgba(0,0,0,0.14),0px 1px 10px 0px rgba(0,0,0,0.12)',
            '0px 3px 5px -1px rgba(0,0,0,0.2),0px 5px 8px 0px rgba(0,0,0,0.14),0px 1px 14px 0px rgba(0,0,0,0.12)',
            '0px 3px 5px -1px rgba(0,0,0,0.2),0px 6px 10px 0px rgba(0,0,0,0.14),0px 1px 18px 0px rgba(0,0,0,0.12)',
            '0px 4px 5px -2px rgba(0,0,0,0.2),0px 7px 10px 1px rgba(0,0,0,0.14),0px 2px 16px 1px rgba(0,0,0,0.12)',
            '0px 5px 5px -3px rgba(0,0,0,0.2),0px 8px 10px 1px rgba(0,0,0,0.14),0px 3px 14px 2px rgba(0,0,0,0.12)',
            '0px 5px 6px -3px rgba(0,0,0,0.2),0px 9px 12px 1px rgba(0,0,0,0.14),0px 3px 16px 2px rgba(0,0,0,0.12)',
            '0px 6px 6px -3px rgba(0,0,0,0.2),0px 10px 14px 1px rgba(0,0,0,0.14),0px 4px 18px 3px rgba(0,0,0,0.12)',
            '0px 6px 7px -4px rgba(0,0,0,0.2),0px 11px 15px 1px rgba(0,0,0,0.14),0px 4px 20px 3px rgba(0,0,0,0.12)',
            '0px 7px 8px -4px rgba(0,0,0,0.2),0px 12px 17px 2px rgba(0,0,0,0.14),0px 5px 22px 4px rgba(0,0,0,0.12)',
            '0px 7px 8px -4px rgba(0,0,0,0.2),0px 13px 19px 2px rgba(0,0,0,0.14),0px 5px 24px 4px rgba(0,0,0,0.12)',
            '0px 7px 9px -4px rgba(0,0,0,0.2),0px 14px 21px 2px rgba(0,0,0,0.14),0px 5px 26px 4px rgba(0,0,0,0.12)',
            '0px 8px 9px -5px rgba(0,0,0,0.2),0px 15px 22px 2px rgba(0,0,0,0.14),0px 6px 28px 5px rgba(0,0,0,0.12)',
            '0px 8px 10px -5px rgba(0,0,0,0.2),0px 16px 24px 2px rgba(0,0,0,0.14),0px 6px 30px 5px rgba(0,0,0,0.12)',
            '0px 8px 11px -5px rgba(0,0,0,0.2),0px 17px 26px 2px rgba(0,0,0,0.14),0px 6px 32px 5px rgba(0,0,0,0.12)',
            '0px 9px 11px -5px rgba(0,0,0,0.2),0px 18px 28px 2px rgba(0,0,0,0.14),0px 7px 34px 6px rgba(0,0,0,0.12)',
            '0px 9px 12px -6px rgba(0,0,0,0.2),0px 19px 29px 2px rgba(0,0,0,0.14),0px 7px 36px 6px rgba(0,0,0,0.12)',
            '0px 10px 13px -6px rgba(0,0,0,0.2),0px 20px 31px 3px rgba(0,0,0,0.14),0px 8px 38px 7px rgba(0,0,0,0.12)',
            '0px 10px 13px -6px rgba(0,0,0,0.2),0px 21px 33px 3px rgba(0,0,0,0.14),0px 8px 40px 7px rgba(0,0,0,0.12)',
            '0px 10px 14px -6px rgba(0,0,0,0.2),0px 22px 35px 3px rgba(0,0,0,0.14),0px 8px 42px 7px rgba(0,0,0,0.12)',
            '0px 11px 14px -7px rgba(0,0,0,0.2),0px 23px 36px 3px rgba(0,0,0,0.14),0px 9px 44px 8px rgba(0,0,0,0.12)',
            '0px 11px 15px -7px rgba(0,0,0,0.2),0px 24px 38px 3px rgba(0,0,0,0.14),0px 9px 46px 8px rgba(0,0,0,0.12)'
        ],
        transitions: {
            easing: {
                easeInOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
                easeOut: 'cubic-bezier(0.0, 0, 0.2, 1)',
                easeIn: 'cubic-bezier(0.4, 0, 1, 1)',
                sharp: 'cubic-bezier(0.4, 0, 0.6, 1)'
            },
            duration: {
                shortest: 150,
                shorter: 200,
                short: 250,
                standard: 300,
                complex: 375,
                enteringScreen: 225,
                leavingScreen: 195
            }
        },
        zIndex: {
            mobileStepper: 1000,
            fab: 1050,
            speedDial: 1050,
            appBar: 1100,
            drawer: 1200,
            modal: 1300,
            snackbar: 1400,
            tooltip: 1500
        }
    },
    currency: '$',
    xAxisCategories: ['2022', '2023', '2024', '2025', '2026', '2027', '2028', '2029', '2030', '2031'],
    wealthPathData: [
        11313, 11464.997714308576, 22048.90646179705, 32905.812279010526, 43550.43610960437, 55376.288532248785,
        66752.94641412901, 78347.41359759253, 90736.6420628089, 103691.8341751784, 105085.00325385711
    ],
    annualDistribution: [0, 10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 80000],
    targetAmount: 53111,
    goalProb: 99,
    response: {
        analysisReport: {
            advisorDiscretionReport: { 1: 0.99 },
            bankruptcyMsg: 'NA',
            currentGoalProbability: 0.99,
            currentLossThresholdProbability: 0.99,
            isGoalRealistic: true,
            lossThreshold: 53111,
            meetGoalPriority: true,
            meetLossPriority: true,
            message: null,
            monthlyTopUpAccumulation: 0,
            monthlyTopUpDecumulation: 0,
            oneTimeTopUp: 0,
            pDeltaCurrentGoalProbability: 0.99,
            pDeltaCurrentLossThresholdProbability: 0.99,
            'recommendedFinalWealthAt50%': 32212,
            'recommendedFinalWealthAt75%': 42661.5,
            recommendedPortfolioId: 1,
            'recommendedProbAt50%': 0.99,
            'recommendedProbAt75%': 0.99,
            recommendedTenure: 'NA',
            yearlyTopUpAccumulation: 0,
            yearlyTopUpDecumulation: 0
        },
        pathReport: {
            portfolioPath: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            wealthPath: [
                11313, 11464.997714308576, 22048.90646179705, 32905.812279010526, 43550.43610960437, 55376.288532248785,
                66752.94641412901, 78347.41359759253, 90736.6420628089, 103691.8341751784, 105085.00325385711
            ]
        }
    },
    isBadProb: false,
    isModerateProb: false,
    goalProbAt75: 99,
    goalProbAt50: 99,
    RECOMMENDED: {
        PROB_75: 'recommendedProbAt75%',
        PROB_50: 'recommendedProbAt50%',
        WEALTH_50: 'recommendedFinalWealthAt50%',
        WEALTH_75: 'recommendedFinalWealthAt75%'
    }
};
