import { useTranslation } from 'react-i18next';

const Tooltip = ({ label }: { label: string }) => {
    const { t } = useTranslation();
    return <>{t(`TEXT_PORTFOLIO_COMPOSITION_${label}`)}</>;
};
export default Tooltip;
