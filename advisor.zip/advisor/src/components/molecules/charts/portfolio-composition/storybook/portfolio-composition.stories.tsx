import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import PortfolioCompositionComponent from '../index';

export default {
    title: 'GOE/Molecules/Charts',
    component: PortfolioCompositionComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <PortfolioCompositionComponent {...args} />
    </Stack>
);

export const PortfolioComposition = Template.bind({});

PortfolioComposition.args = {
    labelXaxis: 6,
    labelYaxis: 90,
    label: '2022',
    data: [
        {
            name: '["FHYQX","Fixed Income","https://www.franklintempleton.com/investments/options/mutual-funds/products/4330/A/franklin-high-yield-tax-free-income-fund/FHYQX"]',
            y: 90,
            color: '#00BFB3'
        },
        {
            name: '["LMISX","Equity","https://www.franklintempleton.com/investments/options/mutual-funds/products/90646/IS/franklin-u-s-large-cap-equity-fund/LMISX"]',
            y: 6,
            color: '#9370E2'
        },
        {
            name: '["CFIPX","Equity","https://www.franklintempleton.com/investments/options/mutual-funds/products/90052/AA2/franklin-global-equity-fund/CFIPX"]',
            y: 1.75,
            color: '#9370E2'
        },
        {
            name: '["FLQM","Equity","https://www.franklintempleton.com/investments/options/exchange-traded-funds/products/25772/SINGLCLASS/franklin-liberty-q-u-s-mid-cap-equity-etf/FLQM"]',
            y: 1,
            color: '#9370E2'
        },
        {
            name: '["LMBMX","Equity","https://www.franklintempleton.com/investments/options/mutual-funds/products/90190/IS/franklin-u-s-small-cap-equity-fund/LMSIX"]',
            y: 0.5,
            color: '#9370E2'
        },
        {
            name: '["EMF","Equity","https://www.franklintempleton.com/investments/options/closed-end-funds/products/111/SINGLCLASS/templeton-emerging-markets-fund/EMF"]',
            y: 0.5,
            color: '#9370E2'
        },
        {
            name: '["FINAX","Equity","https://www.franklintempleton.com/investments/options/mutual-funds/products/90052/AA2/franklin-global-equity-fund/CFIPX"]',
            y: 0.25,
            color: '#9370E2'
        }
    ],
    showPercentageOnBar: false
};
