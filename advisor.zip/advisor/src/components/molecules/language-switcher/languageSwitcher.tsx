import { useTranslation } from 'react-i18next';
import SelectComponent from '../../atoms/select';

function LanguageSwitcher() {
    const { i18n } = useTranslation();
    const data = [
        { label: 'English', value: 'en' },
        { label: 'Germany', value: 'de' }
    ];
    return (
        <div className="select">
            <SelectComponent
                data={data}
                id="language-select"
                placeholder="Please select..."
                label="Select Language"
                autoWidth={false}
                multiple={false}
                native={false}
                value={i18n.language}
                onChange={(e: any) => i18n.changeLanguage(e.target.value as string)}
            />
        </div>
    );
}
export default LanguageSwitcher;
