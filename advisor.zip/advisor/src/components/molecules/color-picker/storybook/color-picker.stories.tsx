// @ts-nocheck
import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import ColorPickerComponent from '../index';

export default {
    title: 'GOE/Molecules/ColorPicker',
    component: ColorPickerComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <ColorPickerComponent {...args} />
    </Stack>
);

export const ColorPicker = Template.bind({});

ColorPicker.args = {
    color: '#3769ff',
    formState: {},
    handleSubmit: () => {},
    register: () => {},
    checkKeyDown: () => {},
    onSubmit: () => {},
    handleColorChange: () => {}
};
