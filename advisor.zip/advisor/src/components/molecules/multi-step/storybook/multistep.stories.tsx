import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import MultiStepComponent from '../index';

export default {
    title: 'GOE/Molecules/MultiStep',
    component: MultiStepComponent
};

const Template: Story = ({ data }) => (
    <Stack m={5}>
        <MultiStepComponent data={data} />
    </Stack>
);

export const Desktop = Template.bind({});
Desktop.args = {
    data: [
        {
            value: 1,
            label: 'Conservative',
            active: false
        },
        {
            value: 2,
            label: 'Somewhat Conservative',
            active: true
        },
        {
            value: 3,
            label: 'Moderate',
            active: false
        },
        {
            value: 4,
            label: 'Somewhat Aggressive',
            active: false
        },
        {
            value: 5,
            label: 'Aggressive',
            active: false
        }
    ]
};
