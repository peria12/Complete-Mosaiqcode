import { styled } from '@mui/material/styles';
import CheckIcon from '@mui/icons-material/Check';
import Typography, { TypographyProps } from '@mui/material/Typography';

interface CircleProps {
    active?: boolean;
}

interface DataList {
    value: number;
    label: string;
    active: boolean;
}

interface MultiStepProps {
    data: Array<DataList>;
}

const ProgressContainer = styled('div')(() => ({
    display: 'inline-flex',
    position: 'relative'
}));

const CircleAndContentContainer = styled('div')(() => ({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '100%',
    textAlign: 'center'
}));

const Circle = styled('div')<CircleProps>(({ theme, active }) => ({
    backgroundColor: active ? theme.palette.primary.main : theme.palette.common.white,
    color: active ? theme.palette.common.white : theme.palette.grey[600],
    borderRadius: '50%',
    height: '85px',
    width: '85px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    border: active ? `3px solid ${theme.palette.primary.main}` : `3px solid ${theme.palette.grey[600]}`,
    transition: '0.4 ease',
    cursor: 'pointer',
    '&:hover': {
        backgroundColor: theme.palette.primary.main,
        border: `3px solid ${theme.palette.primary.main}`,
        boxShadow: '0 0 0 20px rgb(55 105 255 / 33%)'
    }
}));

const Hr = styled('hr')(({ theme }) => ({
    position: 'absolute',
    height: '4px',
    width: '80%',
    background: theme.palette.grey[600],
    top: 'calc(85px / 2)',
    left: '50%',
    zIndex: '-1',
    transform: 'translate(-50%, -50%)'
}));

const Content = styled(Typography)<TypographyProps>(() => ({
    marginTop: '30px'
}));

function MultiStepCircle({ data }: MultiStepProps) {
    return (
        <ProgressContainer>
            <Hr />
            {data.map(({ value, active, label }, i) => (
                <CircleAndContentContainer key={`${value}-${i}`}>
                    <Circle active={active}>{active ? <CheckIcon sx={{ fontSize: '3rem' }} /> : null}</Circle>
                    <Content variant="h4">{label}</Content>
                </CircleAndContentContainer>
            ))}
        </ProgressContainer>
    );
}

export default MultiStepCircle;
