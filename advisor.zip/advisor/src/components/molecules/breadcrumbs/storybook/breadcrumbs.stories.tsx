import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';

import BreadrumbsComponent from '../index';

export default {
    title: 'GOE/Molecules/Breadrumbs',
    component: BreadrumbsComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <BreadrumbsComponent {...args} />
    </Stack>
);

export const Breadrumbs = Template.bind({});

Breadrumbs.args = {
    breadcrumbs: [
        <Typography key="3" variant="body1" sx={{ color: 'primary.main', fontSize: '22px' }}>
            Dashboard
        </Typography>,
        <Typography key="3" variant="body1" sx={{ color: 'primary.main', fontSize: '22px' }}>
            Add New User
        </Typography>
    ]
};
