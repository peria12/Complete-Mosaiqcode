import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import PaginationComponent from '../index';

export default {
    title: 'GOE/Molecules/Pagination',
    component: PaginationComponent
};

const Template: Story = ({ totalCount, pageEntries, nextPage, previousPage, canNextPage, canPreviousPage }) => (
    <Stack m={5}>
        <PaginationComponent
            totalCount={totalCount}
            pageEntries={pageEntries}
            nextPage={nextPage}
            previousPage={previousPage}
            canNextPage={canNextPage}
            canPreviousPage={canPreviousPage}
        />
    </Stack>
);

export const Pagination = Template.bind({});

Pagination.args = {
    totalCount: 1202,
    pageEntries: '1-10 of ',
    nextPage: () => 'Hello Next Page',
    previousPage: () => 'Hello Prev Page',
    canPreviousPage: false,
    canNextPage: false
};
