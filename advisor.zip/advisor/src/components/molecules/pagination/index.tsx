import ButtonGroup, { ButtonGroupProps } from '@mui/material/ButtonGroup';
import { styled } from '@mui/material/styles';
import Button, { ButtonProps } from '@mui/material/Button';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { Typography, TypographyProps } from '@mui/material';
import { numberWithCommas } from '../../../utils/table';

interface PaginationProps {
    totalCount: number;
    pageEntries?: string | number;
    nextPage: () => void;
    previousPage: () => void;
    canPreviousPage: boolean;
    canNextPage: boolean;
}

interface StyledButtonProps extends ButtonProps {
    children?: React.ReactNode;
    onClick?: () => void;
}

interface StyledButtonGroupProps extends ButtonGroupProps {
    children?: React.ReactNode;
}

const PaginationContainer = styled('div')(() => ({
    display: 'inline-flex',
    alignItems: 'flex-end'
}));

const StyledButtonGroup = styled(ButtonGroup)<StyledButtonGroupProps>(() => ({
    paddingLeft: '15px',
    '.MuiButtonGroup-grouped': {
        minWidth: '30px'
    }
}));

const StyledButton = styled(Button)<StyledButtonProps>(({ theme }) => ({
    width: '30px',
    height: '30px',
    border: `1px solid ${theme.palette.primary.main}`,
    padding: '5px'
}));

const StyledTypography = styled(Typography)<TypographyProps>(({ theme }) => ({
    color: theme.palette.primary.main,
    span: {
        fontWeight: '700'
    }
}));

function Pagination({
    totalCount,
    pageEntries,
    canPreviousPage,
    canNextPage,
    nextPage,
    previousPage
}: PaginationProps) {
    return canPreviousPage && canNextPage ? null : (
        <PaginationContainer>
            <StyledTypography variant="body1">
                {pageEntries}
                <span>{numberWithCommas(totalCount)}</span>
            </StyledTypography>
            <StyledButtonGroup disableElevation variant="outlined">
                <StyledButton
                    aria-label="pagination previous button"
                    tabIndex={0}
                    onClick={() => previousPage()}
                    disabled={canPreviousPage}
                >
                    <ChevronLeftIcon />
                </StyledButton>
                <StyledButton
                    aria-label="pagination next button"
                    tabIndex={0}
                    onClick={() => nextPage()}
                    disabled={canNextPage}
                >
                    <ChevronRightIcon />
                </StyledButton>
            </StyledButtonGroup>
        </PaginationContainer>
    );
}

export default Pagination;
