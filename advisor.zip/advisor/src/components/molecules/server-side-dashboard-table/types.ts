export interface TableData {
    [x: string]: any;
    managerName?: string;
    advisorName?: string;
    clientName?: string;
    id?: string | number;
    goalName?: string;
    goalAmount?: number | string;
    goals?: number | string;
    equityFixedIncome?: number | string;
    lastModified?: number | string;
    score?: number | string;
    actualData?: number | string;
    subRows?: TableData[];
}

export interface TableSortingIconProps {
    paddingtop?: boolean | number;
    paddingbottom?: boolean | number;
}

export interface ScoreCircleIconProps {
    color: string;
}

export interface ExpandableStyledTableCellProps {
    bordertop?: boolean | number;
    borderbottom?: boolean | number;
}
