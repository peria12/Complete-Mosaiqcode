/* eslint-disable indent */
/* eslint-disable react/jsx-indent */
import React, { memo, useEffect } from 'react';
import { isEmpty, isUndefined } from 'lodash';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import { useTheme } from '@mui/material/styles';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TableContainer from '@mui/material/TableContainer';
import {
    ExpandedState,
    useReactTable,
    getCoreRowModel,
    getExpandedRowModel,
    ColumnDef,
    getFilteredRowModel,
    getSortedRowModel,
    SortingState,
    flexRender
} from '@tanstack/react-table';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import {
    StyledExpandableKeyboardArrow,
    ScoreCircleIcon,
    AlignTableCell,
    StyledTableCell,
    StyledTableRow,
    TableHeaderRowContainer,
    TableSortingUpAndDownIconContainer,
    TableSortingIcon,
    StyledTableContainer,
    ExpandableIconContainer,
    ExpandableIcon,
    NoResultsFoundContainer,
    CellSpacing,
    ViewLink
} from './styles';
import { ReactComponent as ArrowUp } from './assets/arrow-up.svg';
import { ReactComponent as ArrowDown } from './assets/arrow-down.svg';
import {
    numberWithCommas,
    addCurrencySymbol,
    getScoreAndGoalPriority,
    getScoreColor,
    convertDateFormatMMDDYYYY
} from '../../../utils/table';
import { TableData } from './types';
import { ACCESSOR_KEYS, NO_RESULTS_FOUND, SORTING } from '../../../constants';
import { useTranslation } from 'react-i18next';

function DataTableOrganism({
    handleClientGoalSummaryClick,
    unStructuredData,
    data,
    columnsTranslation,
    handleManualSorting,
    handleDelete,
    caption
}: any) {
    const { t } = useTranslation();
    const theme = useTheme();

    const columns = React.useMemo<ColumnDef<TableData>[]>(
        () => [
            {
                id: 'expansion-icon',
                header: '',
                cell: ({ row }) => (
                    <ExpandableIconContainer>
                        {row.getCanExpand() ? (
                            <ExpandableIcon onClick={row.getToggleExpandedHandler()}>
                                {row.getIsExpanded() ? (
                                    <StyledExpandableKeyboardArrow as={KeyboardArrowDownIcon} />
                                ) : (
                                    <StyledExpandableKeyboardArrow as={KeyboardArrowRight} />
                                )}
                            </ExpandableIcon>
                        ) : (
                            <CellSpacing> </CellSpacing>
                        )}
                    </ExpandableIconContainer>
                )
            },
            // {
            //   accessorKey: ACCESSOR_KEYS.CLIENT_NAME,
            //   id: ACCESSOR_KEYS.CLIENT_NAME,
            //   header: columnsTranslation.client_name,
            //   cell: ({ row, getValue }) => (
            //     <ExpandableIconContainer>
            //       {!isEmpty(getValue()) ? (
            //         row.getCanExpand() ? (
            //           <ExpandableIcon onClick={row.getToggleExpandedHandler()}>
            //             {row.getIsExpanded() ? (
            //               <StyledExpandableKeyboardArrow as={KeyboardArrowDownIcon} />
            //             ) : (
            //               <StyledExpandableKeyboardArrow as={KeyboardArrowRight} />
            //             )}
            //           </ExpandableIcon>
            //         ) : (
            //           <CellSpacing> </CellSpacing>
            //         )
            //       ) : null}{' '}
            //       {!isEmpty(getValue()) ? <>{getValue() as string}</> : null}
            //     </ExpandableIconContainer>
            //   )
            // },
            {
                accessorKey: ACCESSOR_KEYS.CLIENT_FULL_NAME,
                id: ACCESSOR_KEYS.CLIENT_FULL_NAME,
                header: columnsTranslation.client_full_name,
                cell: ({ getValue }) => <>{!isEmpty(getValue()) ? <>{getValue() as string}</> : null}</>
            },
            {
                accessorKey: ACCESSOR_KEYS.GOAL_NAME,
                id: ACCESSOR_KEYS.GOAL_NAME,
                header: columnsTranslation.goal_name,
                enableSorting: false,
                cell: ({ getValue, row }) => {
                    if (!isEmpty(getValue())) {
                        return <>{getValue() as string}</>;
                    }
                    if (row?.original?.showAddGoalButton) {
                        return <ViewLink onClick={() => {}}>{columnsTranslation.add_goal}</ViewLink>;
                    }

                    return '-';
                }
                // cell: ({ getValue, row }) => getValue()
            },
            {
                accessorKey: ACCESSOR_KEYS.GOAL_AMOUNT,
                id: ACCESSOR_KEYS.GOAL_AMOUNT,
                header: columnsTranslation.proposal_value,
                cell: ({ getValue, row }) =>
                    (getValue() || getValue() === 0) && !row.original.showAddGoalButton ? (
                        <AlignTableCell position="end">
                            {addCurrencySymbol(numberWithCommas(getValue()))}
                        </AlignTableCell>
                    ) : row.original.showAddGoalButton ? (
                        <AlignTableCell position="end">{columnsTranslation.not_found}</AlignTableCell>
                    ) : (
                        ''
                    )
            },
            {
                accessorKey: ACCESSOR_KEYS.GOALS,
                id: ACCESSOR_KEYS.GOALS,
                header: columnsTranslation.goals,
                cell: ({ getValue, row }) =>
                    getValue() ? (
                        <AlignTableCell position="center">{getValue() as string | number}</AlignTableCell>
                    ) : row.original.showAddGoalButton ? (
                        <AlignTableCell position="center">{columnsTranslation.not_found}</AlignTableCell>
                    ) : (
                        ''
                    )
            },
            {
                accessorKey: ACCESSOR_KEYS.SCORE,
                id: ACCESSOR_KEYS.SCORE,
                header: columnsTranslation.score,
                cell: ({ getValue, row }) => (
                    <>
                        {!row.original.goalPriority &&
                        !isEmpty(row.originalSubRows) &&
                        (getValue() || getValue() === 0) ? (
                            <AlignTableCell position="center">
                                <ScoreCircleIcon
                                    color={getScoreColor(
                                        getScoreAndGoalPriority(row.original, row.originalSubRows),
                                        theme
                                    )}
                                >
                                    {getValue()}
                                </ScoreCircleIcon>
                            </AlignTableCell>
                        ) : (
                            <>
                                {getValue() || getValue() === 0 ? (
                                    <AlignTableCell position="center">
                                        <ScoreCircleIcon
                                            color={getScoreColor(
                                                {
                                                    score: row.original.score,
                                                    goalPriority: row.original.goalPriority
                                                },
                                                theme
                                            )}
                                        >
                                            {getValue()}
                                        </ScoreCircleIcon>
                                    </AlignTableCell>
                                ) : row.original.showAddGoalButton ? (
                                    <AlignTableCell position="center">{columnsTranslation.not_found}</AlignTableCell>
                                ) : null}
                            </>
                        )}
                    </>
                )
            },
            {
                accessorKey: ACCESSOR_KEYS.LAST_MODIFIED,
                id: ACCESSOR_KEYS.LAST_MODIFIED,
                header: columnsTranslation.last_modified,
                cell: ({ getValue, row }) => {
                    if (!isUndefined(getValue()) && !isEmpty(getValue())) {
                        return (
                            <AlignTableCell position="end">
                                {convertDateFormatMMDDYYYY(getValue() as string)}
                            </AlignTableCell>
                        );
                    }
                    if (row?.original?.showAddGoalButton) {
                        return <AlignTableCell position="end">{columnsTranslation.not_found}</AlignTableCell>;
                    }
                }
            },
            {
                accessorKey: ACCESSOR_KEYS.EQUITY_FIXED_INCOME,
                enableSorting: false,
                id: ACCESSOR_KEYS.EQUITY_FIXED_INCOME,
                header: columnsTranslation.equity_fixed_income,
                cell: ({ getValue, row }) =>
                    !isEmpty(getValue()) ? (
                        <AlignTableCell position="center">{getValue() as string}</AlignTableCell>
                    ) : row.original.showAddGoalButton ? (
                        <AlignTableCell position="center">{columnsTranslation.not_found}</AlignTableCell>
                    ) : (
                        <AlignTableCell position="center">-</AlignTableCell>
                    )
            },
            {
                id: 'view-client-summary',
                header: '',
                enableSorting: false,
                cell: ({ row }) =>
                    !row.original.showAddGoalButton && (
                        <>
                            <ViewLink onClick={() => handleClientGoalSummaryClick(row, row.index)}>
                                {columnsTranslation.view}
                            </ViewLink>
                        </>
                    )
            },
            {
                accessorKey: ACCESSOR_KEYS.ID,
                id: 'deleteIcon',
                header: columnsTranslation.delete,
                enableSorting: false,
                cell: ({ row, getValue }) => (
                    <>
                        {getValue() && (
                            <AlignTableCell position="center">
                                <DeleteIcon onClick={() => handleDelete(row.original.id)} />
                            </AlignTableCell>
                        )}
                    </>
                )
            }
        ],
        [unStructuredData, data]
    );

    const [sorting, setSorting] = React.useState<SortingState>([]);
    const [expanded, setExpanded] = React.useState<ExpandedState>({});

    const table = useReactTable({
        data,
        columns,
        state: {
            expanded,
            sorting
        },
        manualSorting: true,
        onSortingChange: setSorting,
        getFilteredRowModel: getFilteredRowModel(),
        autoResetExpanded: false,
        onExpandedChange: setExpanded,
        getSubRows: (row) => row.subRows,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getExpandedRowModel: getExpandedRowModel(),
        debugTable: true
    });

    useEffect(() => {
        if (sorting[0]?.id !== SORTING.NO_SORT || isEmpty(sorting)) {
            handleManualSorting(sorting);
        }
    }, [sorting]);

    return (
        <StyledTableContainer>
            {!isEmpty(table.getRowModel().rows) ? (
                <TableContainer component={Paper}>
                    <Table
                        sx={{
                            '& .MuiTableRow-root:hover': {
                                backgroundColor: 'table.row.hover'
                            }
                        }}
                        stickyHeader
                        aria-label="caption table"
                    >
                        <caption tabIndex={0}>{caption}</caption>
                        <TableHead>
                            {table
                                .getHeaderGroups()
                                .map((headerGroup: { id: React.Key | null | undefined; headers: any[] }) => (
                                    <TableRow key={headerGroup.id}>
                                        {headerGroup.headers.map(
                                            (header: {
                                                id: React.Key | null | undefined;
                                                colSpan: number | undefined;
                                                isPlaceholder: any;
                                                column: {
                                                    getCanSort: () => string | number;
                                                    getToggleSortingHandler: () => any;
                                                    columnDef: {
                                                        header:
                                                            | string
                                                            | number
                                                            | boolean
                                                            | React.ReactElement<
                                                                  any,
                                                                  string | React.JSXElementConstructor<any>
                                                              >
                                                            | React.ReactFragment
                                                            | React.ComponentType<any>
                                                            | null
                                                            | undefined;
                                                    };
                                                    getIsSorted: () => string;
                                                };
                                                getContext: () => any;
                                            }) => (
                                                <StyledTableCell key={header.id} colSpan={header.colSpan}>
                                                    {header.isPlaceholder ? null : header.column.getCanSort() ? (
                                                        <TableHeaderRowContainer
                                                            center={+header.column.getCanSort()}
                                                            {...{
                                                                onClick: header.column.getToggleSortingHandler()
                                                            }}
                                                        >
                                                            {flexRender(
                                                                header.column.columnDef.header,
                                                                header.getContext()
                                                            )}
                                                            {{
                                                                asc: <TableSortingIcon as={ArrowUp} />,
                                                                desc: <TableSortingIcon as={ArrowDown} />
                                                            }[header.column.getIsSorted() as string] ?? (
                                                                <TableSortingUpAndDownIconContainer>
                                                                    <TableSortingIcon as={ArrowUp} />
                                                                    <TableSortingIcon as={ArrowDown} />
                                                                </TableSortingUpAndDownIconContainer>
                                                            )}
                                                        </TableHeaderRowContainer>
                                                    ) : (
                                                        <TableHeaderRowContainer center={+header.column.getCanSort()}>
                                                            {' '}
                                                            {flexRender(
                                                                header.column.columnDef.header,
                                                                header.getContext()
                                                            )}
                                                        </TableHeaderRowContainer>
                                                    )}
                                                </StyledTableCell>
                                            )
                                        )}
                                    </TableRow>
                                ))}
                        </TableHead>
                        <TableBody>
                            {table
                                .getRowModel()
                                .rows.map(
                                    (row: {
                                        id: React.Key | null | undefined;
                                        depth: any;
                                        getVisibleCells: () => any[];
                                    }) => (
                                        <StyledTableRow key={row.id} className={`table-expanded-depth-${row.depth}`}>
                                            {row.getVisibleCells().map(
                                                (cell: {
                                                    id: React.Key | null | undefined;
                                                    column: {
                                                        columnDef: {
                                                            cell:
                                                                | string
                                                                | number
                                                                | boolean
                                                                | React.ReactElement<
                                                                      any,
                                                                      string | React.JSXElementConstructor<any>
                                                                  >
                                                                | React.ReactFragment
                                                                | React.ReactPortal
                                                                | React.ComponentType<any>
                                                                | null
                                                                | undefined;
                                                        };
                                                    };
                                                    getContext: () => any;
                                                }) => (
                                                    <StyledTableCell key={cell.id}>
                                                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                                    </StyledTableCell>
                                                )
                                            )}
                                        </StyledTableRow>
                                    )
                                )}
                        </TableBody>
                    </Table>
                </TableContainer>
            ) : (
                <NoResultsFoundContainer>
                    <Typography variant="h1" component="div">
                        {t(NO_RESULTS_FOUND)}
                    </Typography>
                </NoResultsFoundContainer>
            )}
        </StyledTableContainer>
    );
}

export default memo(DataTableOrganism);
