import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Skeleton from '@mui/material/Skeleton';
import Paper from '@mui/material/Paper';
import { useTranslation } from 'react-i18next';

import { StyledTableCell, StyledTableRow } from './styles';

const rows = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

export default function TableSkeletonLoader() {
    const { t } = useTranslation();

    const columnsTranslation = {
        client_first_name: t('HEADER_TABLE_CLIENT_FIRST_NAME'),
        client_last_name: t('HEADER_TABLE_CLIENT_LAST_NAME'),
        goal_name: t('HEADER_TABLE_GOAL_NAME'),
        proposal_value: t('HEADER_TABLE_PORTFOLIO_VALUE'),
        goals: t('HEADER_TABLE_GOALS'),
        score: t('HEADER_TABLE_SCORE'),
        last_modified: t('HEADER_TABLE_LAST_MODIFIED'),
        equity_fixed_income: t('HEADER_TABLE_EQUITY_FIXED_INCOME'),
        delete: t('HEADER_TABLE_DELETE'),
        view: t('HEADER_TABLE_VIEW')
    };

    return (
        <TableContainer component={Paper}>
            <Table
                sx={{
                    '& .MuiTableRow-root:hover': {
                        backgroundColor: 'table.row.hover'
                    }
                }}
                stickyHeader
                aria-label="caption table"
            >
                <TableHead>
                    <TableRow>
                        <StyledTableCell />
                        <StyledTableCell align="left">{columnsTranslation.client_first_name}</StyledTableCell>
                        <StyledTableCell align="left">{columnsTranslation.client_last_name}</StyledTableCell>
                        <StyledTableCell align="left">{columnsTranslation.goal_name}</StyledTableCell>
                        <StyledTableCell align="left">{columnsTranslation.proposal_value}</StyledTableCell>
                        <StyledTableCell>{columnsTranslation.goals}</StyledTableCell>
                        <StyledTableCell align="left">{columnsTranslation.score}</StyledTableCell>
                        <StyledTableCell align="left">{columnsTranslation.last_modified}</StyledTableCell>
                        <StyledTableCell align="left">{columnsTranslation.equity_fixed_income}</StyledTableCell>
                        <StyledTableCell align="left">
                            <p style={{ visibility: 'hidden', margin: '0' }}>{columnsTranslation.view}</p>
                        </StyledTableCell>
                        <StyledTableCell align="left">{columnsTranslation.delete}</StyledTableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rows.map((_, index) => (
                        <StyledTableRow key={index}>
                            <StyledTableCell component="th" scope="row">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell component="th" scope="row">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                            <StyledTableCell align="right">
                                <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
                            </StyledTableCell>
                        </StyledTableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}
