import { JSXElementConstructor, Key, ReactElement, ReactFragment, ReactPortal } from 'react';
import { styled } from '@mui/material/styles';
import ButtonComponent from '../../atoms/button';
import { ReactComponent as Plus } from './assets/plus.svg';

const Tabs = styled('div')`
    width: 100%;
    overflow: hidden;
    margin: 1em 0 2em;
`;

const TabContainer = styled('ul')(() => ({
    padding: 0,
    margin: 0,
    display: 'inline-block',
    '& li': {
        '&:first-of-type': {
            marginLeft: 0,
            '@media (max-width: 991px)': {
                marginLeft: 10
            }
        }
    },
    '@media (max-width: 400px)': {
        display: 'unset'
    }
}));

const Nav = styled('nav')(() => ({
    '@media (max-width: 991px)': {
        textAlign: 'center'
    }
}));

const Tab = styled('li')(({ theme }) => ({
    border: `2px solid ${theme.palette.grey[900]}`,
    borderBottom: 'none',
    margin: '0 10px',
    display: 'block',
    float: 'left',
    position: 'relative',
    borderTopRightRadius: 5,
    borderTopLeftRadius: 5,
    backgroundColor: theme.palette.common.white,
    // zIndex: 100,
    // '&::before': {
    //   content: '""',
    //   position: 'absolute',
    //   height: '2px',
    //   right: '100%',
    //   bottom: 0,
    //   width: '1000px',
    //   background: theme.palette.common.black
    // },
    // '&::after': {
    //   content: '""',
    //   position: 'absolute',
    //   height: '2px',
    //   right: '100%',
    //   left: '100%',
    //   bottom: 0,
    //   width: '4000px',
    //   background: theme.palette.common.black
    // },
    '@media (max-width: 991px)': {
        float: 'unset',
        textAlign: 'center'
    },
    '&.tab-current': {
        border: `2px solid  ${theme.palette.primary.main}`,
        borderBottom: 'none',
        zIndex: 100,
        '&::before': {
            content: '""',
            position: 'absolute',
            height: '2px',
            right: '100%',
            bottom: 0,
            width: '1000px',
            background: theme.palette.primary.main
        },
        '&::after': {
            content: '""',
            position: 'absolute',
            height: '2px',
            right: '100%',
            left: '100%',
            bottom: 0,
            width: '4000px',
            background: theme.palette.primary.main
        },

        '& span': {
            color: theme.palette.primary.main
        }
    }
}));

const Span = styled('span')(({ theme }) => ({
    color: theme.palette.grey[900],
    display: 'block',
    fontSize: '24px',
    lineHeight: 2.5,
    padding: '0 14px',
    cursor: 'pointer',
    fontWeight: 400,
    overflow: 'hidden',
    maxWidth: '24ch',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap'
}));

const AddGoalCTA = styled('span')(({ theme }) => ({
    color: theme.palette.grey[900],
    display: 'block',
    fontSize: '24px',
    lineHeight: 2.5,
    padding: '0 24px',
    cursor: 'pointer',
    fontWeight: 900,
    overflow: 'hidden',
    whiteSpace: 'nowrap'
}));

const ButtonContainer = styled('div')(() => ({
    float: 'right',
    '@media (max-width: 991px)': {
        display: 'none'
    },
    '& .MuiButton-root': {
        marginLeft: '10px',
        padding: '10px'
    }
}));

const PlusIcon = styled('span')(() => ({
    width: '24px',
    color: 'black'
}));

const TabsComponent = ({
    tabsData,
    toggleState,
    toggleTab,
    onButtonClick,
    buttonTitle,
    hideEditButton,
    showAddTab = true
}: any) => (
    <>
        <Tabs>
            <Nav>
                <TabContainer>
                    {tabsData?.map(
                        (
                            value: {
                                data: any;
                                value:
                                    | string
                                    | number
                                    | boolean
                                    | ReactElement<any, string | JSXElementConstructor<any>>
                                    | ReactFragment
                                    | ReactPortal
                                    | null
                                    | undefined;
                            },
                            index: Key | null | undefined
                        ) => (
                            <Tab
                                className={toggleState === index ? 'tab-current' : ''}
                                onClick={() => toggleTab(value, index)}
                                key={index}
                                tabIndex={0}
                                role="tab"
                                onKeyPress={() => toggleTab(value, index)}
                            >
                                <Span>{value.data.goalName}</Span>
                            </Tab>
                        )
                    )}
                    {showAddTab && (
                        <Tab onClick={() => {}} tabIndex={0} role="tab" onKeyPress={() => {}}>
                            <AddGoalCTA>
                                <PlusIcon as={Plus} />
                            </AddGoalCTA>
                        </Tab>
                    )}
                </TabContainer>
                {!hideEditButton && (
                    <ButtonContainer>
                        <ButtonComponent variant="contained" onClick={onButtonClick}>
                            {buttonTitle || 'Edit'}
                        </ButtonComponent>
                    </ButtonContainer>
                )}
            </Nav>
        </Tabs>
    </>
);

export default TabsComponent;
