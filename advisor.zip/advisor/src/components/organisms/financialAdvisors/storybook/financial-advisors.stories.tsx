// @ts-nocheck
import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import FinancialAdvisorsListComponent from '../financialAdvisorTable';

export default {
    title: 'GOE/Organisms/FinancialAdvisorsList',
    component: FinancialAdvisorsListComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <FinancialAdvisorsListComponent {...args} />
    </Stack>
);

export const FinancialAdvisorsList = Template.bind({});

FinancialAdvisorsList.args = {
    data: [
        {
            advisorFirstName: 'Jason',
            advisorLastName: 'Adams',
            advisorEmail: 'Jason.Adams@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '7',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Michael',
            advisorLastName: 'Hamilton',
            advisorEmail: 'Michael.Hamilton@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '12',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Serena',
            advisorLastName: 'Wolf',
            advisorEmail: '-',
            advisorPhoneNumber: '',
            numberOfClients: '5',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Daniel',
            advisorLastName: 'Chadwick',
            advisorEmail: 'Daniel.Chadwick@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '9',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Jamie',
            advisorLastName: 'Croft',
            advisorEmail: 'Jamie.Croft@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '12',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Lewis',
            advisorLastName: 'Palmer',
            advisorEmail: 'Lewis.Palmer2@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '16',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Jason',
            advisorLastName: 'Adams',
            advisorEmail: 'Jason.Adams@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '7',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Michael',
            advisorLastName: 'Hamilton',
            advisorEmail: 'Michael.Hamilton@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '12',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Serena',
            advisorLastName: 'Wolf',
            advisorEmail: '-',
            advisorPhoneNumber: '',
            numberOfClients: '5',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Daniel',
            advisorLastName: 'Chadwick',
            advisorEmail: 'Daniel.Chadwick@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '9',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Jamie',
            advisorLastName: 'Croft',
            advisorEmail: 'Jamie.Croft@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '12',
            numberOfGoals: '20'
        },
        {
            advisorFirstName: 'Lewis',
            advisorLastName: 'Palmer',
            advisorEmail: 'Lewis.Palmer2@logoipsum.com',
            advisorPhoneNumber: '',
            numberOfClients: '16',
            numberOfGoals: '20'
        }
    ],
    buttonOnClick: () => {},
    columns: [
        { accessorKey: 'advisorName', id: 'advisorName', header: 'Advisor Name' },
        { accessorKey: 'advisorEmail', id: 'advisorEmail', header: 'Advisor Email' },
        { accessorKey: 'numberOfClients', id: 'numberOfClients', header: 'Clients' },
        { accessorKey: 'remove', id: 'remove', header: 'Remove', enableSorting: false }
    ],
    button: 'Add New Advisor'
};
