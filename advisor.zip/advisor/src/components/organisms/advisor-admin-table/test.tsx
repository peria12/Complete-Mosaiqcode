/* eslint-disable indent */
/* eslint-disable react/jsx-indent */
// @ts-nocheck
import React, { memo } from 'react';
import { isEmpty } from 'lodash';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import { useTranslation } from 'react-i18next';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TableContainer from '@mui/material/TableContainer';

import {
    ExpandedState,
    useReactTable,
    getCoreRowModel,
    getExpandedRowModel,
    ColumnDef,
    getFilteredRowModel,
    getSortedRowModel,
    SortingState,
    flexRender
} from '@tanstack/react-table';

import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';

import {
    StyledExpandableKeyboardArrow,
    CircleIcon,
    AlignTableCellCenter,
    StyledTableCell,
    StyledTableRow,
    TableHeaderRowContainer,
    TableSortingUpAndDownIconContainer,
    TableSortingIcon,
    StyledTableContainer,
    PointerCursor,
    CellSpacing,
    NoResultsFoundContainer
} from './styles';

import { ReactComponent as ArrowUp } from './assets/arrow-up.svg';
import { ReactComponent as ArrowDown } from './assets/arrow-down.svg';
import { numberWithCommas, addCurrencySymbol } from '../../../utils';
import { TableData } from './types';
import { ACCESSOR_KEYS, NO_RESULTS_FOUND } from '../../../constants';

function DataTableOrganism({ handleClientGoalClick, unStructuredData, data, columnsTranslation }: any) {
    const { t } = useTranslation();

    const CLIENTS = t('TEXT_CLIENTS');

    const columns = React.useMemo<ColumnDef<TableData>[]>(
        () => [
            {
                accessorKey: ACCESSOR_KEYS.CLIENT_NAME,
                id: ACCESSOR_KEYS.CLIENT_NAME,
                header: columnsTranslation.client_name,
                cell: ({ row, getValue }) => (
                    <>
                        {!isEmpty(getValue()) ? (
                            row.getCanExpand() ? (
                                <PointerCursor onClick={row.getToggleExpandedHandler()}>
                                    {row.getIsExpanded() ? (
                                        <StyledExpandableKeyboardArrow as={KeyboardArrowDownIcon} />
                                    ) : (
                                        <StyledExpandableKeyboardArrow as={KeyboardArrowRight} />
                                    )}
                                </PointerCursor>
                            ) : (
                                <span style={{ padding: '10px' }}> </span>
                            )
                        ) : null}{' '}
                        {typeof getValue() === 'number' ? (
                            `${getValue()} ${CLIENTS}`
                        ) : !isEmpty(getValue()) ? (
                            <CellSpacing style={{ cursor: 'pointer' }} onClick={() => handleClientGoalClick(row, 0)}>
                                {getValue() as string}
                            </CellSpacing>
                        ) : null}
                    </>
                )
            },
            {
                accessorKey: ACCESSOR_KEYS.GOAL_NAME,
                id: ACCESSOR_KEYS.GOAL_NAME,
                header: columnsTranslation.goal_name,
                cell: ({ getValue, row }) => {
                    if (!isEmpty(getValue())) {
                        return (
                            <span style={{ cursor: 'pointer' }} onClick={() => handleClientGoalClick(row, row.index)}>
                                {getValue()}
                            </span>
                        );
                    }

                    return '-';
                }

                // cell: ({ getValue, row }) => getValue()
            },
            {
                accessorKey: ACCESSOR_KEYS.GOAL_AMOUNT,
                id: ACCESSOR_KEYS.GOAL_AMOUNT,
                header: columnsTranslation.proposal_value,
                cell: ({ getValue }) => (getValue() ? addCurrencySymbol(numberWithCommas(getValue())) : '')
            },
            {
                accessorKey: ACCESSOR_KEYS.GOALS,
                id: ACCESSOR_KEYS.GOALS,
                header: columnsTranslation.goals,
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: ACCESSOR_KEYS.SCORE,
                id: ACCESSOR_KEYS.SCORE,
                header: columnsTranslation.score,
                cell: ({ getValue }) => (
                    <>
                        {getValue() ? (
                            <AlignTableCellCenter>
                                <CircleIcon score={getValue()}>{getValue()}</CircleIcon>
                            </AlignTableCellCenter>
                        ) : null}
                    </>
                )
            },
            {
                accessorKey: ACCESSOR_KEYS.LAST_MODIFIED,
                id: ACCESSOR_KEYS.LAST_MODIFIED,
                header: columnsTranslation.last_modified,
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: ACCESSOR_KEYS.EQUITY_FIXED_INCOME,
                id: ACCESSOR_KEYS.EQUITY_FIXED_INCOME,
                header: columnsTranslation.equity_fixed_income,
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: ACCESSOR_KEYS.ID,
                id: 'deleteIcon',
                header: columnsTranslation.delete,
                enableSorting: false,
                cell: ({ row, getValue }) => (
                    <>
                        {getValue() && (
                            <AlignTableCellCenter>
                                {/* eslint-disable-next-line no-console */}
                                <DeleteIcon onClick={() => console.log(row.original.id)} />
                            </AlignTableCellCenter>
                        )}
                    </>
                )
            }
        ],
        [unStructuredData, data]
    );

    const [sorting, setSorting] = React.useState<SortingState>([]);
    const [expanded, setExpanded] = React.useState<ExpandedState>({});

    const table = useReactTable({
        data,
        columns,
        state: {
            expanded,
            sorting
        },
        onSortingChange: setSorting,
        getFilteredRowModel: getFilteredRowModel(),
        autoResetExpanded: false,
        onExpandedChange: setExpanded,
        getSubRows: (row) => row.subRows,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getExpandedRowModel: getExpandedRowModel(),
        debugTable: true
    });

    return (
        <StyledTableContainer>
            {!isEmpty(table.getRowModel().rows) ? (
                <TableContainer component={Paper}>
                    <Table
                        sx={{
                            '& .MuiTableRow-root:hover': {
                                backgroundColor: 'table.row.hover'
                            }
                        }}
                        stickyHeader
                        aria-label="customized table"
                    >
                        <TableHead>
                            {table
                                .getHeaderGroups()
                                .map((headerGroup: { id: React.Key | null | undefined; headers: any[] }) => (
                                    <TableRow key={headerGroup.id}>
                                        {headerGroup.headers.map(
                                            (header: {
                                                id: React.Key | null | undefined;
                                                colSpan: number | undefined;
                                                isPlaceholder: any;
                                                column: {
                                                    getCanSort: () => string | number;
                                                    getToggleSortingHandler: () => any;
                                                    columnDef: {
                                                        header:
                                                            | string
                                                            | number
                                                            | boolean
                                                            | React.ReactElement<
                                                                  any,
                                                                  string | React.JSXElementConstructor<any>
                                                              >
                                                            | React.ReactFragment
                                                            | React.ComponentType<any>
                                                            | null
                                                            | undefined;
                                                    };
                                                    getIsSorted: () => string;
                                                };
                                                getContext: () => any;
                                            }) => (
                                                <StyledTableCell key={header.id} colSpan={header.colSpan}>
                                                    {header.isPlaceholder ? null : header.column.getCanSort() ? (
                                                        <TableHeaderRowContainer
                                                            center={+header.column.getCanSort()}
                                                            {...{
                                                                onClick: header.column.getToggleSortingHandler()
                                                            }}
                                                        >
                                                            {flexRender(
                                                                header.column.columnDef.header,
                                                                header.getContext()
                                                            )}
                                                            {{
                                                                asc: <TableSortingIcon as={ArrowUp} />,
                                                                desc: <TableSortingIcon as={ArrowDown} />
                                                            }[header.column.getIsSorted() as string] ?? (
                                                                <TableSortingUpAndDownIconContainer>
                                                                    <TableSortingIcon as={ArrowUp} />
                                                                    <TableSortingIcon as={ArrowDown} />
                                                                </TableSortingUpAndDownIconContainer>
                                                            )}
                                                        </TableHeaderRowContainer>
                                                    ) : (
                                                        <TableHeaderRowContainer center={+header.column.getCanSort()}>
                                                            {' '}
                                                            {flexRender(
                                                                header.column.columnDef.header,
                                                                header.getContext()
                                                            )}
                                                        </TableHeaderRowContainer>
                                                    )}
                                                </StyledTableCell>
                                            )
                                        )}
                                    </TableRow>
                                ))}
                        </TableHead>
                        <TableBody>
                            {table
                                .getRowModel()
                                .rows.map(
                                    (row: {
                                        id: React.Key | null | undefined;
                                        depth: any;
                                        getVisibleCells: () => any[];
                                    }) => (
                                        <StyledTableRow key={row.id} className={`table-expanded-depth-${row.depth}`}>
                                            {row.getVisibleCells().map(
                                                (cell: {
                                                    id: React.Key | null | undefined;
                                                    column: {
                                                        columnDef: {
                                                            cell:
                                                                | string
                                                                | number
                                                                | boolean
                                                                | React.ReactElement<
                                                                      any,
                                                                      string | React.JSXElementConstructor<any>
                                                                  >
                                                                | React.ReactFragment
                                                                | React.ReactPortal
                                                                | React.ComponentType<any>
                                                                | null
                                                                | undefined;
                                                        };
                                                    };
                                                    getContext: () => any;
                                                }) => (
                                                    <StyledTableCell key={cell.id}>
                                                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                                    </StyledTableCell>
                                                )
                                            )}
                                        </StyledTableRow>
                                    )
                                )}
                        </TableBody>
                    </Table>
                </TableContainer>
            ) : (
                <NoResultsFoundContainer>
                    <Typography variant="h1" component="div">
                        {t(NO_RESULTS_FOUND)}
                    </Typography>
                </NoResultsFoundContainer>
            )}
        </StyledTableContainer>
    );
}

export default memo(DataTableOrganism);
