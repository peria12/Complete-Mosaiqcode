import { Story } from '@storybook/react';
import Stack from '@mui/material/Stack';
import DashboardTableComponent from '../index';

export default {
    title: 'GOE/Organisms/DashboardTable',
    component: DashboardTableComponent
};

const Template: Story = (args) => (
    <Stack direction="column" spacing={2} m={5}>
        <DashboardTableComponent {...args} />
    </Stack>
);

export const DashboardTable = Template.bind({});

DashboardTable.args = {
    columnVisibility: {
        managerName: false,
        advisorName: false
    },
    data: [
        {
            clientName: 'simi agarwal',
            clientFirstName: 'simi',
            clientLastName: 'agarwal',
            id: {
                clientEmail: 'ksimi@gmail.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'sample Ample12',
            clientFirstName: 'sample',
            clientLastName: 'Ample12',
            id: {
                clientEmail: 'sample@ample.co',
                goal: '',
                clientId: 480
            },
            goalName: '',
            goalAmount: 53111,
            goals: 3,
            score: 90,
            lastModified: '13-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'sample@ample.co',
                        goal: 480,
                        clientId: 480
                    },
                    goalName: 'save for future investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '13-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'sample@ample.co',
                        goal: 481,
                        clientId: 480
                    },
                    goalName: 'Income Stream',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '13-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'sample@ample.co',
                        goal: 482,
                        clientId: 480
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '30/70',
                    lastModified: '13-12-2022',
                    score: 90,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'sample ample4',
            clientFirstName: 'sample',
            clientLastName: 'ample4',
            id: {
                clientEmail: 'ampl@yop.co',
                goal: '',
                clientId: 509
            },
            goalName: '',
            goalAmount: 13111,
            goals: 5,
            score: 99,
            lastModified: '14-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ampl@yop.co',
                        goal: 509,
                        clientId: 509
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ampl@yop.co',
                        goal: 510,
                        clientId: 509
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ampl@yop.co',
                        goal: 508,
                        clientId: 509
                    },
                    goalName: 'Retirement',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Wish',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ampl@yop.co',
                        goal: 511,
                        clientId: 509
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ampl@yop.co',
                        goal: 512,
                        clientId: 509
                    },
                    goalName: 'save for future investment',
                    goalAmount: 13111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'test135 Aproposal1',
            clientFirstName: 'test135',
            clientLastName: 'Aproposal1',
            id: {
                clientEmail: 'save151.proposal@gm.com',
                goal: '',
                clientId: 492
            },
            goalName: '',
            goalAmount: 1400000,
            goals: 5,
            score: 0,
            lastModified: '13-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'save151.proposal@gm.com',
                        goal: 492,
                        clientId: 492
                    },
                    goalName: 'mutualfunds',
                    goalAmount: 400000,
                    goals: '',
                    equityFixedIncome: '40/60',
                    lastModified: '13-12-2022',
                    score: 0,
                    goalPriority: 'Dream',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'save151.proposal@gm.com',
                        goal: 493,
                        clientId: 492
                    },
                    goalName: 'Marriage',
                    goalAmount: 1000000,
                    goals: '',
                    equityFixedIncome: '40/60',
                    lastModified: '13-12-2022',
                    score: 0,
                    goalPriority: 'Wish',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'save151.proposal@gm.com',
                        goal: 494,
                        clientId: 492
                    },
                    goalName: 'healthinsurance',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '40/60',
                    lastModified: '13-12-2022',
                    score: 0,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'save151.proposal@gm.com',
                        goal: 499,
                        clientId: 492
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '40/60',
                    lastModified: '13-12-2022',
                    score: 73,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'save151.proposal@gm.com',
                        goal: 500,
                        clientId: 492
                    },
                    goalName: 'adafasfasf',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '40/60',
                    lastModified: '13-12-2022',
                    score: 0,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'test135 Aproposal1',
            clientFirstName: 'test135',
            clientLastName: 'Aproposal1',
            id: {
                clientEmail: 'save51.proposal@gm.com',
                goal: '',
                clientId: 498
            },
            goalName: 'saveforevent1',
            goalAmount: 0,
            goals: 1,
            score: 1,
            lastModified: '13-12-2022',
            equityFixedIncome: '40/60',
            goalPriority: 'Dream',
            showAddGoalButton: false
        },
        {
            clientName: 'Bruce Banner',
            clientFirstName: 'Bruce',
            clientLastName: 'Banner',
            id: {
                clientEmail: 'bruce@avengers.com',
                goal: '',
                clientId: 244
            },
            goalName: 'save for college',
            goalAmount: 26000,
            goals: 1,
            score: 39,
            lastModified: '17-11-2022',
            equityFixedIncome: '100/0',
            goalPriority: 'Wish',
            showAddGoalButton: false
        },
        {
            clientName: 'Jyoti Bora',
            clientFirstName: 'Jyoti',
            clientLastName: 'Bora',
            id: {
                clientEmail: 'Jyoti.Bora@franklintempleton.com',
                goal: '',
                clientId: 250
            },
            goalName: 'future event test1',
            goalAmount: 7000,
            goals: 1,
            score: 84,
            lastModified: '21-11-2022',
            equityFixedIncome: '20/80',
            goalPriority: 'Wish',
            showAddGoalButton: false
        },
        {
            clientName: 'Jyoti Bora',
            clientFirstName: 'Jyoti',
            clientLastName: 'Bora',
            id: {
                clientEmail: 'jshdk@yahoo.com',
                goal: '',
                clientId: 288
            },
            goalName: 'house',
            goalAmount: 300000,
            goals: 1,
            score: 66,
            lastModified: '28-11-2022',
            equityFixedIncome: '60/40',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'ClientName ClientName',
            clientFirstName: 'ClientName',
            clientLastName: 'ClientName',
            id: {
                clientEmail: 'clientname@mail.com',
                goal: '',
                clientId: 268
            },
            goalName: 'gautam income1',
            goalAmount: 0,
            goals: 1,
            score: 95,
            lastModified: '08-12-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Want',
            showAddGoalButton: false
        },
        {
            clientName: 'Dharma Dharma',
            clientFirstName: 'Dharma',
            clientLastName: 'Dharma',
            id: {
                clientEmail: 'dharma@dharma.com',
                goal: '',
                clientId: 249
            },
            goalName: 'Dharma Goa Plan',
            goalAmount: 320000,
            goals: 1,
            score: 99,
            lastModified: '18-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'John Doe',
            clientFirstName: 'John',
            clientLastName: 'Doe',
            id: {
                clientEmail: 'sam.ragsdale@gmail.com',
                goal: '',
                clientId: 519
            },
            goalName: 'Retirement',
            goalAmount: 0,
            goals: 1,
            score: 80,
            lastModified: '14-12-2022',
            equityFixedIncome: '80/20',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'sdfsdf dsfsdf',
            clientFirstName: 'sdfsdf',
            clientLastName: 'dsfsdf',
            id: {
                clientEmail: 'sap@f.co',
                goal: '',
                clientId: 309
            },
            goalName: 'Retirement test scenario',
            goalAmount: 0,
            goals: 1,
            score: 99,
            lastModified: '05-12-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'sdfsdgqq dsrfwsfqw',
            clientFirstName: 'sdfsdgqq',
            clientLastName: 'dsrfwsfqw',
            id: {
                clientEmail: 's@j.co',
                goal: '',
                clientId: 301
            },
            goalName: '',
            goalAmount: 53111,
            goals: 2,
            score: 99,
            lastModified: '05-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 's@j.co',
                        goal: 301,
                        clientId: 301
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '05-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 's@j.co',
                        goal: 302,
                        clientId: 301
                    },
                    goalName: 'save for future investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '05-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'jhklgoill dythfdj',
            clientFirstName: 'jhklgoill',
            clientLastName: 'dythfdj',
            id: {
                clientEmail: 'd@t.fo',
                goal: '',
                clientId: 333
            },
            goalName: '',
            goalAmount: 60111,
            goals: 2,
            score: 99,
            lastModified: '08-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'd@t.fo',
                        goal: 333,
                        clientId: 333
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '08-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'd@t.fo',
                        goal: 334,
                        clientId: 333
                    },
                    goalName: 'save for future investment',
                    goalAmount: 60111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '08-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'ssfsdf efsdfsdf',
            clientFirstName: 'ssfsdf',
            clientLastName: 'efsdfsdf',
            id: {
                clientEmail: 'da@j.co',
                goal: '',
                clientId: 324
            },
            goalName: '',
            goalAmount: 53111,
            goals: 2,
            score: 85,
            lastModified: '07-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'da@j.co',
                        goal: 324,
                        clientId: 324
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '07-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'da@j.co',
                        goal: 323,
                        clientId: 324
                    },
                    goalName: 'save for future investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '70/30',
                    lastModified: '07-12-2022',
                    score: 85,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'FGD FGD',
            clientFirstName: 'FGD',
            clientLastName: 'FGD',
            id: {
                clientEmail: 'dfg@mail.com',
                goal: '',
                clientId: 319
            },
            goalName: 'save for future investment',
            goalAmount: 50000,
            goals: 1,
            score: 99,
            lastModified: '07-12-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'FT FT',
            clientFirstName: 'FT',
            clientLastName: 'FT',
            id: {
                clientEmail: 'ft@mail.com',
                goal: '',
                clientId: 317
            },
            goalName: '',
            goalAmount: 13111,
            goals: 3,
            score: 76,
            lastModified: '06-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ft@mail.com',
                        goal: 317,
                        clientId: 317
                    },
                    goalName: 'sample',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '06-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ft@mail.com',
                        goal: 318,
                        clientId: 317
                    },
                    goalName: 'Retirement',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '06-12-2022',
                    score: 99,
                    goalPriority: 'Wish',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'ft@mail.com',
                        goal: 316,
                        clientId: 317
                    },
                    goalName: 'save for future investment',
                    goalAmount: 13111,
                    goals: '',
                    equityFixedIncome: '20/80',
                    lastModified: '06-12-2022',
                    score: 76,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'save future',
            clientFirstName: 'save',
            clientLastName: 'future',
            id: {
                clientEmail: 'sav@fut.co',
                goal: '',
                clientId: 256
            },
            goalName: 'save',
            goalAmount: 100000,
            goals: 1,
            score: 99,
            lastModified: '21-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'save123 future123',
            clientFirstName: 'save123',
            clientLastName: 'future123',
            id: {
                clientEmail: 'save@fu.com',
                goal: '',
                clientId: 257
            },
            goalName: 'save money',
            goalAmount: 200000,
            goals: 1,
            score: 99,
            lastModified: '21-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Wish',
            showAddGoalButton: false
        },
        {
            clientName: 'jyoti Gayle',
            clientFirstName: 'jyoti',
            clientLastName: 'Gayle',
            id: {
                clientEmail: 'jg@gmail.com',
                goal: '',
                clientId: 232
            },
            goalName: 'retirement_test7',
            goalAmount: 0,
            goals: 1,
            score: 10,
            lastModified: '16-11-2022',
            equityFixedIncome: '70/30',
            goalPriority: 'Want',
            showAddGoalButton: false
        },
        {
            clientName: 'Goal Goal',
            clientFirstName: 'Goal',
            clientLastName: 'Goal',
            id: {
                clientEmail: 'goals@mail.com',
                goal: '',
                clientId: 429
            },
            goalName: '',
            goalAmount: 53111,
            goals: 3,
            score: 99,
            lastModified: '08-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'goals@mail.com',
                        goal: 429,
                        clientId: 429
                    },
                    goalName: 'save for future investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '08-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'goals@mail.com',
                        goal: 431,
                        clientId: 429
                    },
                    goalName: 'retirement test42',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '08-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'goals@mail.com',
                        goal: 430,
                        clientId: 429
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '08-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'iuewriweur iuiuiu',
            clientFirstName: 'iuewriweur',
            clientLastName: 'iuiuiu',
            id: {
                clientEmail: 'kjskdf@kjkj.wewe',
                goal: '',
                clientId: 199
            },
            goalName: 'Dhanush Wealth Path Plan',
            goalAmount: 0,
            goals: 1,
            score: 99,
            lastModified: '14-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'IW IW',
            clientFirstName: 'IW',
            clientLastName: 'IW',
            id: {
                clientEmail: 'iw@mail.com',
                goal: '',
                clientId: 449
            },
            goalName: '',
            goalAmount: 106222,
            goals: 4,
            score: 74,
            lastModified: '12-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'iw@mail.com',
                        goal: 449,
                        clientId: 449
                    },
                    goalName: 'save for future investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'iw@mail.com',
                        goal: 450,
                        clientId: 449
                    },
                    goalName: 'Future Investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'iw@mail.com',
                        goal: 451,
                        clientId: 449
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '50/50',
                    lastModified: '12-12-2022',
                    score: 74,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'iw@mail.com',
                        goal: 452,
                        clientId: 449
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'random jbtest',
            clientFirstName: 'random',
            clientLastName: 'jbtest',
            id: {
                clientEmail: 'jbtestrandom@ft.com',
                goal: '',
                clientId: 265
            },
            goalName: 'generateincome8',
            goalAmount: 89089,
            goals: 1,
            score: 99,
            lastModified: '22-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Wish',
            showAddGoalButton: false
        },
        {
            clientName: 'test jeff',
            clientFirstName: 'test',
            clientLastName: 'jeff',
            id: {
                clientEmail: 'test@test1.com',
                goal: '',
                clientId: 311
            },
            goalName: 'save for future investment',
            goalAmount: 200000,
            goals: 1,
            score: 0,
            lastModified: '05-12-2022',
            equityFixedIncome: '70/30',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'sdjkfhserujh jhjhjh',
            clientFirstName: 'sdjkfhserujh',
            clientLastName: 'jhjhjh',
            id: {
                clientEmail: 'jkhjkh@jkhjkh.kjkj',
                goal: '',
                clientId: 458
            },
            goalName: '',
            goalAmount: 13111,
            goals: 2,
            score: 27,
            lastModified: '12-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'jkhjkh@jkhjkh.kjkj',
                        goal: 458,
                        clientId: 458
                    },
                    goalName: 'save for future investment',
                    goalAmount: 13111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 27,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'jkhjkh@jkhjkh.kjkj',
                        goal: 459,
                        clientId: 458
                    },
                    goalName: 'Income Stream1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'kayle jim',
            clientFirstName: 'kayle',
            clientLastName: 'jim',
            id: {
                clientEmail: 'jim@gmail.com',
                goal: '',
                clientId: 460
            },
            goalName: '',
            goalAmount: 53111,
            goals: 2,
            score: 99,
            lastModified: '12-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'jim@gmail.com',
                        goal: 460,
                        clientId: 460
                    },
                    goalName: 'Retirement',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 99,
                    goalPriority: 'Wish',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'jim@gmail.com',
                        goal: 461,
                        clientId: 460
                    },
                    goalName: 'save for future investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'uwherjkhw jkhjhejr',
            clientFirstName: 'uwherjkhw',
            clientLastName: 'jkhjhejr',
            id: {
                clientEmail: 'usewsdwsed@tuwtye.sdsd',
                goal: '',
                clientId: 210
            },
            goalName: 'Wakanda',
            goalAmount: 0,
            goals: 1,
            score: 99,
            lastModified: '14-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'jacin johnson',
            clientFirstName: 'jacin',
            clientLastName: 'johnson',
            id: {
                clientEmail: 'jacin@gmail.com',
                goal: '',
                clientId: 490
            },
            goalName: '',
            goalAmount: 1000000,
            goals: 2,
            score: 0,
            lastModified: '13-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'jacin@gmail.com',
                        goal: 490,
                        clientId: 490
                    },
                    goalName: 'incomejyoti',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '40/60',
                    lastModified: '13-12-2022',
                    score: 63,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'jacin@gmail.com',
                        goal: 491,
                        clientId: 490
                    },
                    goalName: 'save event jyoti bora for future higher education fee saving high',
                    goalAmount: 1000000,
                    goals: '',
                    equityFixedIncome: '40/60',
                    lastModified: '13-12-2022',
                    score: 0,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'test Jyotib',
            clientFirstName: 'test',
            clientLastName: 'Jyotib',
            id: {
                clientEmail: 'jbtest@gmail.com',
                goal: '',
                clientId: 262
            },
            goalName: 'saveforevent5',
            goalAmount: 700000,
            goals: 1,
            score: 87,
            lastModified: '22-11-2022',
            equityFixedIncome: '20/80',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'test Jyotib',
            clientFirstName: 'test',
            clientLastName: 'Jyotib',
            id: {
                clientEmail: 'jb11@gmail.com',
                goal: '',
                clientId: 267
            },
            goalName: 'saveforevent1',
            goalAmount: 200000,
            goals: 1,
            score: 99,
            lastModified: '23-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'test Jyotib',
            clientFirstName: 'test',
            clientLastName: 'Jyotib',
            id: {
                clientEmail: 'jb90@gmail.com',
                goal: '',
                clientId: 489
            },
            goalName: 'saveforevent2',
            goalAmount: 400000,
            goals: 1,
            score: 0,
            lastModified: '13-12-2022',
            equityFixedIncome: '70/30',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'Mounica K',
            clientFirstName: 'Mounica',
            clientLastName: 'K',
            id: {
                clientEmail: 'Monu@gmail.com',
                goal: '',
                clientId: 503
            },
            goalName: '',
            goalAmount: 1300000,
            goals: 3,
            score: 0,
            lastModified: '14-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Monu@gmail.com',
                        goal: 503,
                        clientId: 503
                    },
                    goalName: 'vvvvvvvb',
                    goalAmount: 1000000,
                    goals: '',
                    equityFixedIncome: '70/30',
                    lastModified: '14-12-2022',
                    score: 0,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Monu@gmail.com',
                        goal: 501,
                        clientId: 503
                    },
                    goalName: 'yejinhousing',
                    goalAmount: 300000,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Monu@gmail.com',
                        goal: 502,
                        clientId: 503
                    },
                    goalName: 'retirement',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaivanan@franklintempleton.com',
                goal: '',
                clientId: 149
            },
            goalName: '',
            goalAmount: 8000,
            goals: 5,
            score: 38,
            lastModified: '15-11-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Authithya.Kalaivanan@franklintempleton.com',
                        goal: 149,
                        clientId: 149
                    },
                    goalName: 'authi income test1',
                    goalAmount: 8000,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '15-11-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Authithya.Kalaivanan@franklintempleton.com',
                        goal: 179,
                        clientId: 149
                    },
                    goalName: 'aathi Retirement',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '20/80',
                    lastModified: '15-11-2022',
                    score: 99,
                    goalPriority: 'Want',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Authithya.Kalaivanan@franklintempleton.com',
                        goal: 160,
                        clientId: 149
                    },
                    goalName: 'aathi Retirement',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '15-11-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Authithya.Kalaivanan@franklintempleton.com',
                        goal: 187,
                        clientId: 149
                    },
                    goalName: 'authi generate income delet',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '100/0',
                    lastModified: '10-11-2022',
                    score: 38,
                    goalPriority: 'Wish',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Authithya.Kalaivanan@franklintempleton.com',
                        goal: 192,
                        clientId: 149
                    },
                    goalName: 'authi generate income',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '11-11-2022',
                    score: 99,
                    goalPriority: 'Want',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authi@franklintempleton.com',
                goal: '',
                clientId: 235
            },
            goalName: 'authi generate income',
            goalAmount: 0,
            goals: 1,
            score: 99,
            lastModified: '16-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaivan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaivana@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithyan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authitya.Kalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'authithya Kalaivanan',
            clientFirstName: 'authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 's@aa.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authiivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authya.Kalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'ya.Kalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Auhya.Kalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalainan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Ahithya.Kalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Auth.Kalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaivanan@franintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaivanan@franklmp.com',
                goal: '',
                clientId: 453
            },
            goalName: '',
            goalAmount: 53111,
            goals: 2,
            score: 85,
            lastModified: '12-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Authithya.Kalaivanan@franklmp.com',
                        goal: 453,
                        clientId: 453
                    },
                    goalName: 'save for future investment56',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '70/30',
                    lastModified: '12-12-2022',
                    score: 85,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Authithya.Kalaivanan@franklmp.com',
                        goal: 454,
                        clientId: 453
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '12-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaivanan@fklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'uhya.Kalaivanan@franklintempleton.com',
                goal: '',
                clientId: 274
            },
            goalName: 'aathi Retirement',
            goalAmount: 0,
            goals: 1,
            score: 83,
            lastModified: '24-11-2022',
            equityFixedIncome: '70/30',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithj@franklintempleton.com',
                goal: '',
                clientId: 467
            },
            goalName: 'generateincomtest',
            goalAmount: 10000,
            goals: 1,
            score: 48,
            lastModified: '12-12-2022',
            equityFixedIncome: '100/0',
            goalPriority: 'Want',
            showAddGoalButton: false
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Avanan@franklintempleton.com',
                goal: '',
                clientId: 504
            },
            goalName: '',
            goalAmount: 53111,
            goals: 4,
            score: 99,
            lastModified: '14-12-2022',
            equityFixedIncome: '',
            goalPriority: '',
            showAddGoalButton: false,
            subRows: [
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Avanan@franklintempleton.com',
                        goal: 504,
                        clientId: 504
                    },
                    goalName: 'save for future investment',
                    goalAmount: 53111,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Avanan@franklintempleton.com',
                        goal: 505,
                        clientId: 504
                    },
                    goalName: 'gautam income1',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Avanan@franklintempleton.com',
                        goal: 506,
                        clientId: 504
                    },
                    goalName: 'Retirement',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Need',
                    showAddGoalButton: false
                },
                {
                    managerName: '',
                    advisorName: '',
                    clientName: '',
                    clientFirstName: '',
                    clientLastName: '',
                    id: {
                        clientEmail: 'Avanan@franklintempleton.com',
                        goal: 507,
                        clientId: 504
                    },
                    goalName: 'retirement test42',
                    goalAmount: 0,
                    goals: '',
                    equityFixedIncome: '10/90',
                    lastModified: '14-12-2022',
                    score: 99,
                    goalPriority: 'Wish',
                    showAddGoalButton: false
                }
            ]
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaivan@fralintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'hya.Kalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithya.Kalaiv@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'Authithyaalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Authithya Kalaivanan',
            clientFirstName: 'Authithya',
            clientLastName: 'Kalaivanan',
            id: {
                clientEmail: 'AuthithyaKalaivanan@franklintempleton.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Mohammed Khan',
            clientFirstName: 'Mohammed',
            clientLastName: 'Khan',
            id: {
                clientEmail: 'mkhan2@frk.com',
                goal: '',
                clientId: 197
            },
            goalName: 'MOE',
            goalAmount: 0,
            goals: 1,
            score: 99,
            lastModified: '11-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'ksjdjsdkj kjksjdj',
            clientFirstName: 'ksjdjsdkj',
            clientLastName: 'kjksjdj',
            id: {
                clientEmail: 'oiweow@oio.we',
                goal: '',
                clientId: 246
            },
            goalName: 'oiwoei',
            goalAmount: 345676,
            goals: 1,
            score: 67,
            lastModified: '18-11-2022',
            equityFixedIncome: '80/20',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'uklsjdfkj kljikljlkj',
            clientFirstName: 'uklsjdfkj',
            clientLastName: 'kljikljlkj',
            id: {
                clientEmail: 'userere@dfd.dfdf',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'dhanush kumar',
            clientFirstName: 'dhanush',
            clientLastName: 'kumar',
            id: {
                clientEmail: 'usey@y.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Dhanush kumar',
            clientFirstName: 'Dhanush',
            clientLastName: 'kumar',
            id: {
                clientEmail: 'sklhjdfjklsjrfhlaj@iuiwer.wewe',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'dhanush kumar',
            clientFirstName: 'dhanush',
            clientLastName: 'kumar',
            id: {
                clientEmail: 'dhanushnew@gmai.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Dhanush kumar',
            clientFirstName: 'Dhanush',
            clientLastName: 'kumar',
            id: {
                clientEmail: 'dhanushkumarsivaji@gmail.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'dhanush kumar',
            clientFirstName: 'dhanush',
            clientLastName: 'kumar',
            id: {
                clientEmail: 'user@test.coms',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'dhanush kumar',
            clientFirstName: 'dhanush',
            clientLastName: 'kumar',
            id: {
                clientEmail: 'user123j@y.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Buzz Lightyear',
            clientFirstName: 'Buzz',
            clientLastName: 'Lightyear',
            id: {
                clientEmail: 'etest@test.com',
                goal: '',
                clientId: 320
            },
            goalName: 'save for future investment',
            goalAmount: 53111,
            goals: 1,
            score: 99,
            lastModified: '07-12-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Need',
            showAddGoalButton: false
        },
        {
            clientName: 'kjasdfhkjashf lkhjlijsdfklgj',
            clientFirstName: 'kjasdfhkjashf',
            clientLastName: 'lkhjlijsdfklgj',
            id: {
                clientEmail: 'owieowi@gmail.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'asdmfsdlkj lkjlkjsefd',
            clientFirstName: 'asdmfsdlkj',
            clientLastName: 'lkjlkjsefd',
            id: {
                clientEmail: 'kljkljlkjkj@kjkj.wewe',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'lkjkdjsklljlke lkjsekj',
            clientFirstName: 'lkjkdjsklljlke',
            clientLastName: 'lkjsekj',
            id: {
                clientEmail: 'abc@ft.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'l lklkfg',
            clientFirstName: 'l',
            clientLastName: 'lklkfg',
            id: {
                clientEmail: 'abc@gmail.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Jeff Me',
            clientFirstName: 'Jeff',
            clientLastName: 'Me',
            id: {
                clientEmail: 'jmetz@frk.com',
                goal: ''
            },
            goalAmount: -1,
            goals: 0,
            score: '',
            lastModified: '',
            equityFixedIncome: '',
            showAddGoalButton: true
        },
        {
            clientName: 'Lewis Mercy',
            clientFirstName: 'Lewis',
            clientLastName: 'Mercy',
            id: {
                clientEmail: 'lewismer@gmail.com',
                goal: '',
                clientId: 254
            },
            goalName: 'retire',
            goalAmount: 0,
            goals: 1,
            score: 99,
            lastModified: '21-11-2022',
            equityFixedIncome: '10/90',
            goalPriority: 'Want',
            showAddGoalButton: false
        },
        {
            clientName: 'Jeff Metz',
            clientFirstName: 'Jeff',
            clientLastName: 'Metz',
            id: {
                clientEmail: 'jeffrey.metz@franklintempleton2.com',
                goal: '',
                clientId: 292
            },
            goalName: 'Wedding',
            goalAmount: 25000,
            goals: 1,
            score: 25,
            lastModified: '29-11-2022',
            equityFixedIncome: '20/80',
            goalPriority: 'Need',
            showAddGoalButton: false
        }
    ],
    columns: [
        {
            id: 'expansion-icon',
            header: ''
        },
        {
            accessorKey: 'managerName',
            id: 'managerName',
            header: 'Manager Name'
        },
        {
            accessorKey: 'advisorName',
            id: 'advisorName',
            header: 'Advisor Name'
        },
        {
            accessorKey: 'clientFirstName',
            id: 'clientFirstName',
            header: 'First Name'
        },
        {
            accessorKey: 'clientLastName',
            id: 'clientLastName',
            header: 'Last Name'
        },
        {
            accessorKey: 'goalName',
            id: 'goalName',
            header: 'Goal Name',
            enableSorting: false
        },
        {
            accessorKey: 'goalAmount',
            id: 'goalAmount',
            header: 'Overall Value*'
        },
        {
            accessorKey: 'goals',
            id: 'goals',
            header: '# of Goals'
        },
        {
            accessorKey: 'score',
            id: 'score',
            header: 'Score'
        },
        {
            accessorKey: 'lastModified',
            id: 'lastModified',
            header: 'Last Modified'
        },
        {
            accessorKey: 'equityFixedIncome',
            enableSorting: false,
            id: 'equityFixedIncome',
            header: 'Equity / Fixed Income'
        },
        {
            id: 'view-client-summary',
            header: '',
            enableSorting: false
        },
        {
            accessorKey: 'id',
            id: 'deleteIcon',
            header: 'Delete',
            enableSorting: false
        }
    ],
    handleAddClientClick: () => {}
};
