import { isEmpty } from 'lodash';
import { styled } from '@mui/material/styles';
import Grid, { GridProps } from '@mui/material/Grid';
import Typography, { TypographyProps } from '@mui/material/Typography';
import TableComponent from '../../molecules/server-side-dashboard-table';
import Pagination from '../../molecules/pagination';
import SearchBar from '../../atoms/search';
import ButtonComponent from '../../atoms/button';

const PaginationLayout = styled(Grid)<GridProps>(() => ({
    marginTop: '14px',
    display: 'flex',
    justifyContent: 'end',
    '@media (max-width: 991px)': {
        justifyContent: 'unset'
    }
}));

const PortfolioLastUpdated = styled(Typography)<TypographyProps>(() => ({
    fontSize: '14px',
    lineHeight: '17.5px',
    fontWeight: 400,
    display: 'flex',
    alignItems: 'center',
    '@media (max-width: 991px)': {
        padding: '20px 0px'
    }
}));

const FilterContainer = styled(Grid)<GridProps>(() => ({
    marginBottom: 10
}));

const SearchLayout = styled(Grid)<GridProps>(() => ({}));

const AddClientButtonLayout = styled(Grid)<GridProps>(() => ({
    paddingLeft: 10
}));

function DataTable({
    searchPorps,
    data,
    // totalCount,
    pageLimit,
    paginationProps,
    columnsTranslation,
    buttonTranslation,
    handleAddClientClick,
    portfolioLastUpdatedTranslation,
    ...rest
}: any) {
    return (
        <>
            <FilterContainer container>
                <Grid item xs={12} sm={12} md={8} lg={8} display="flex">
                    <SearchLayout item xs={12} sm={12} md={3} lg={3}>
                        <SearchBar {...searchPorps} />
                    </SearchLayout>
                    <AddClientButtonLayout item xs={12} sm={12} md={3} lg={2}>
                        <ButtonComponent variant="contained" onClick={() => handleAddClientClick()}>
                            {buttonTranslation}
                        </ButtonComponent>
                    </AddClientButtonLayout>
                </Grid>
                <Grid
                    item
                    xs={12}
                    sm={12}
                    md={4}
                    lg={4}
                    display="flex"
                    sx={{
                        justifyContent: { xs: 'start', sm: 'start', md: 'end', lg: 'end' },
                        alignItems: 'center'
                    }}
                >
                    <PortfolioLastUpdated variant="body1" tabIndex={0}>
                        {portfolioLastUpdatedTranslation}
                    </PortfolioLastUpdated>
                </Grid>
            </FilterContainer>
            <TableComponent
                data={!isEmpty(data) ? data.slice(0, pageLimit) : []}
                handleAddClientClick={handleAddClientClick}
                columnsTranslation={columnsTranslation}
                {...rest}
            />
            {!isEmpty(data) ? (
                <PaginationLayout>
                    <Pagination {...paginationProps} />
                </PaginationLayout>
            ) : null}
        </>
    );
}

export default DataTable;
