import React, { useState } from 'react';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { useTranslation } from 'react-i18next';
import { SelectChangeEvent } from '@mui/material';
import Button from '../atoms/button';
import Input from '../atoms/input';
import Search from '../atoms/search';
import Dots from '../atoms/stepper-dots';
import MultiStepCircle from '../molecules/checkbox-stepper';
import Checkbox from '../atoms/checkbox';
import SelectComponent from '../atoms/select';
import DatePickerInput from '../atoms/datePicker';
import MaskedInputDate from '../atoms/maskedInput';
import LanguageSwitcher from '../molecules/language-switcher/languageSwitcher';

type eventProp = React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>;

export default function Test() {
    const [selectValue, setSelectValue] = useState('Moderate');
    const handleSelectChange = (e: SelectChangeEvent<HTMLInputElement>) => {
        setSelectValue(e.target.value as string);
    };

    const [value, setValue] = useState({
        email: '',
        password: '',
        date: ''
    });
    const [dateValue, setDateValue] = useState('');
    const { t } = useTranslation();

    const [searchString, setSearchString] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setValue({ ...value, [e.target.name]: e.target.value });
    };
    const handleDateChange = (e: any) => {
        setDateValue(e);
    };
    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setSearchString(e.target.value);
    };
    const multiStepData = {
        icon: 'Circlecheck',
        subheading1: 'Less Risk',
        subheading2: 'More Risk',
        subheadingHelper1: 'Minimize Short-Term Losses',
        subheadingHelper2: 'Maximize Total Returns',
        clientAddValue: '',
        formValue: [],
        TabData: [],
        checkboxValue: [
            {
                icon: 'check',
                value: 1,

                label: 'Conservative',
                helperText: 'We may suggest more asset invested in bond and short-term investment',

                active: false
            },

            {
                icon: 'check',
                value: 2,

                label: 'Somewhat Conservative',
                helperText: '',

                active: true
            },

            {
                icon: 'check',
                value: 3,

                label: 'Moderate',
                helperText: '',

                active: false
            },

            {
                icon: 'check',
                value: 4,

                label: 'Somewhat Aggressive',
                helperText: '',

                active: false
            },

            {
                icon: 'check',
                value: 5,

                label: 'Aggressive',
                helperText: '',

                active: false
            }
        ]
    };

    const selectData = [
        {
            value: 'Conservative',
            label: 'Conservative'
        },
        {
            value: 'Somewhat Conservative',
            label: 'Somewhat Conservative'
        },
        {
            value: 'Moderate',
            label: 'Moderate'
        },
        {
            value: 'Somewhat Aggressive',
            label: 'Somewhat Aggressive'
        },
        {
            value: 'Aggressive',
            label: 'Aggressive'
        }
    ];

    const dotsData = [
        {
            value: 1,
            active: false
        },
        {
            value: 2,
            active: false
        },
        {
            value: 3,
            active: true
        },
        {
            value: 4,
            active: false
        },
        {
            value: 5,
            active: false
        }
    ];
    return (
        <Stack direction="column" spacing={2} mt={5} mb={5}>
            <Typography variant="h1" component="h1">
                h1. Heading
            </Typography>
            <Typography variant="h2" component="h2">
                h2. Heading
            </Typography>
            <Typography variant="h3" component="h3">
                h3. Heading
            </Typography>
            <Typography variant="h4" component="h4">
                h4. Heading
            </Typography>
            <Typography variant="h5" component="h5">
                h5. Heading
            </Typography>
            <Typography variant="h6" component="h6">
                h6. Heading
            </Typography>
            <Button variant="contained" size="medium">
                Primary
            </Button>
            <Button variant="outlined" size="medium">
                Secondary
            </Button>
            <Button variant="outlined" disabled size="medium">
                Disabled
            </Button>
            <Input
                name="email"
                label="Email"
                value={value.email}
                placeholder="Enter Email"
                onChange={(e) => handleChange(e)}
                type="email"
                id="email-input"
            />
            <Input
                name="password"
                label="Password"
                value={value.password}
                placeholder="Enter Password"
                onChange={(e) => handleChange(e)}
                type="password"
                error
                id="password-input"
            />
            <DatePickerInput
                label="Date"
                name="date"
                type="date"
                value={value.date}
                onChange={(e) => handleChange(e)}
                placeholder="dd/mm/yyy"
            />
            <MaskedInputDate
                label="Date"
                error={dateValue.toString() === 'Invalid Date'}
                value={dateValue}
                name="maskDate"
                placeholder="MM/yyyy"
                onChange={handleDateChange}
            />

            <Search
                onChange={(e: eventProp) => handleSearchChange(e)}
                placeholder="Search For Client"
                value={searchString}
                label="search"
            />
            <Dots data={dotsData} />
            <MultiStepCircle
                DataObj={multiStepData.checkboxValue}
                heading1={multiStepData.subheading1}
                heading2={multiStepData.subheading2}
                subheading1={multiStepData.subheadingHelper1}
                subheading2={multiStepData.subheadingHelper2}
                showHr={!!(multiStepData.icon && multiStepData.icon === 'Circlecheck')}
            />
            <Checkbox disableRipple />
            <LanguageSwitcher />
            <div>{t('dummyTitle')}</div>
            <SelectComponent
                autoWidth={false}
                multiple={false}
                native={false}
                label="Month"
                data={selectData}
                value={selectValue}
                placeholder="Please select"
                id="month"
                onChange={(e: any) => handleSelectChange(e as any)}
            />
        </Stack>
    );
}
