const { createProxyMiddleware } = require('http-proxy-middleware');

const api_port = process.env.REST_API_PORT;
const target = process.env.REACT_APP_UIP_API_URL || `http://localhost:${api_port}`;

module.exports = function (app) {
    const proxy = createProxyMiddleware({
        target,
        changeOrigin: true,
        secure: false
    });

    app.use('/api/advisorportal', proxy);
    app.use('/signIn', proxy);
    app.use('/refreshToken', proxy);
};
