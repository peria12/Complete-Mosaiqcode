/* eslint-disable */
import { Palette, PaletteOptions } from '@mui/material/styles';

declare module '@mui/material/styles' {
    interface Palette {
        table: {
            header: string;
            row: {
                even: string;
                odd: string;
                hover: string;
            };
            score: {
                50: string;
                75: string;
                100: string;
            };
        };
        layout: {
            primary: string;
        };
        slider: {
            background: string;
            rail: string;
            label: string;
        };
        goal: {
            formFields: {
                background: string;
                errorBackground: string;
                errorLabel: string;
            };
            heading: {
                background: {
                    content: string;
                    savingGoal: string;
                    clientInfo: string;
                    riskTolerance: string;
                };
            };
            button: {
                disabled: string;
            };
        };
        charts: {
            glidePath: {
                equity: string;
                fixedIncome: string;
                pie: {
                    equity: string;
                    fixedIncome: string;
                };
                line: string;
                label: {
                    equity: string;
                    fixedIncome: string;
                };
            };
            portfolioComposition: {
                equity: string;
                fixedIncome: string;
            };
            wealthPath: {
                goodProb: string;
                moderateProb: string;
                badProb: string;
                yAxisPlotLine: string;
                tick: string;
                axisLabel: string;
                title: string;
                crosshair: string;
                accumulationLine: string;
                drawdownLine: string;
                gridLine: string;
            };
            recommendation: {
                amount: string;
                amountBorderBottom: string;
            };
        };
    }

    // interface PaletteOptions {
    //   table?: {
    //     header: string;
    //     row: {
    //       even: string;
    //       odd: string;
    //       string: string;
    //     };
    //     score: {
    //       50: string;
    //       75: string;
    //       100: string;
    //     };
    //   };
    //   slider: {
    //     background: string;
    //     rail: string;
    //   };
    //   goal?: {
    //     formFields: {
    //       background: string;
    //     };
    //     heading: {
    //       content: string;
    //       background: string;
    //     };
    //   };
    //   charts: {
    //     glidePath: {
    //       equity: string;
    //       fixedIncome: string;
    //       pie: {
    //         equity: string;
    //         fixedIncome: string;
    //       };
    //       line: string;
    //       label: {
    //         equity: string;
    //         fixedIncome: string;
    //       };
    //     };
    //     portfolioComposition: {
    //       equity: string;
    //       fixedIncome: string;
    //     };
    //   };
    // }
}
