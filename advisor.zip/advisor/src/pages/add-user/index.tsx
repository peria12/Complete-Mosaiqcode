/* eslint-disable operator-linebreak */
import Typography from '@mui/material/Typography';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

import AddUserContainer from '../../containers/add-user';
import BreadcrumbsComponent from '../../components/molecules/breadcrumbs';

export default function AddUser() {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const { state }: any = useLocation();

    const breadcrumbs = [
        <Typography
            key="1"
            variant="body1"
            onClick={() => navigate('/admin')}
            sx={{
                color: 'primary.main',
                fontSize: '22px',
                cursor: 'pointer',
                '&:hover': {
                    textDecoration: 'underline 1px',
                    textUnderlineOffset: '3px'
                }
            }}
        >
            {t('TEXT_ADMIN_DASHBOARD_HEADER')}
        </Typography>,
        <Typography key="2" variant="body1" sx={{ color: 'primary.main', fontSize: '22px' }}>
            {state?.fromAdvisor ? t('FINANCIAL_ADVISORS_ADD_NEW_ADVISOR') : t('TEXT_ADMIN_USER_MANAGEMENT_ADD_NEW')}
        </Typography>
    ];
    return (
        <>
            <BreadcrumbsComponent breadcrumbs={breadcrumbs} />
            <AddUserContainer fromAdvisor={state?.fromAdvisor} />
        </>
    );
}
