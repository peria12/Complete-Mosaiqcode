import ForgotPasswordContainer from '../../containers/forgot-password';

const ForgotPassword = () => <ForgotPasswordContainer />;

export default ForgotPassword;
