import LoginContainer from '../../containers/login';

const Login = () => <LoginContainer />;

export default Login;
