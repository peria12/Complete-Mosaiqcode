import AdminManageTranslationTable from '../../containers/admin-manage-translation-table';

function AdminManageTranslation() {
    return (
        <>
            <AdminManageTranslationTable />
        </>
    );
}

export default AdminManageTranslation;
