const goeJson = {
    saveForCollege: {
        statusCode: 200,
        message: 'Success',
        data: {
            analysis_report: {
                'advisor discretion report': { 6: 0.5684 },
                'current goal probability': 0.5683852356508939,
                'current loss threshold probability': 0.8936011338314616,
                bankruptcy_msg: 'NA',
                'is goal realistic': true,
                'meet goal priority': false,
                'meet loss priority': false,
                'monthly top-up accumulation': '202',
                'monthly top-up decumulation': '0',
                'one time top-up': '20742',
                'p-delta current goal probability': 0.5464,
                'p-delta current loss threshold probability': 0.8973,
                'recommended portfolio id': 6,
                'recommended tenure': 'Goal probability at T+2 years : 90% ; Goal probability at T+4 years : 99%',
                'yearly top-up accumulation': '2511',
                'yearly top-up decumulation': '0',
                'recommended final wealth at 50%': 125000.0,
                'recommended final wealth at 75%': 162500.0,
                'recommended prob at 50%': 0.99,
                pdeltaCurrentLossThresholdProbability: 0.8973,
                pdeltaCurrentGoalProbability: 0.5464,
                'recommended prob at 75%': 0.9479709927681789
            },
            path_report: {
                'Portfolio Path': [6, 6, 6, 6, 6, 6, 6, 6, 3, 1],
                'Wealth Node Prob': [
                    0.5683852356508939, 0.5711568560919468, 0.4790789994924675, 0.4297949006828414, 0.3854495736167312,
                    0.3380224274462117, 0.2777612139462608, 0.2300703918253886, 0.11667415823481657, 0.03646665827873973
                ],
                'Wealth Path': [
                    50000.0, 50921.60688147893, 60019.30454380662, 72046.33835844412, 84918.19854126342,
                    98278.27749232888, 111681.7483821964, 126913.22273813552, 139048.8334348444, 155152.90888478202,
                    169988.83582812865
                ],
                years: [2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032]
            },
            annualDistribution: {
                amount: [0, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 0],
                years: [2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032]
            }
        }
    },
    houseDownPayment: {
        statusCode: 200,
        message: 'Success',
        data: {
            analysis_report: {
                'advisor discretion report': { 7: 0.385 },
                'current goal probability': 0.3850303901850183,
                'current loss threshold probability': 0.9077579381267652,
                bankruptcy_msg: 'NA',
                'is goal realistic': true,
                'meet goal priority': false,
                'meet loss priority': false,
                'monthly top-up accumulation': '145',
                'monthly top-up decumulation': '0',
                'one time top-up': '10180',
                'p-delta current goal probability': 0.3673,
                'p-delta current loss threshold probability': 0.9152,
                'recommended portfolio id': 7,
                'recommended tenure': 'Goal probability at T+2 years : 86% ; Goal probability at T+4 years : 99%',
                'yearly top-up accumulation': '1830',
                'yearly top-up decumulation': '0',
                'recommended final wealth at 50%': 67500.0,
                'recommended final wealth at 75%': 83750.0,
                'recommended prob at 50%': 0.99,
                pdeltaCurrentLossThresholdProbability: 0.9152,
                pdeltaCurrentGoalProbability: 0.3673,
                'recommended prob at 75%': 0.8101545022067492
            },
            path_report: {
                'Portfolio Path': [7, 7, 7, 7, 7, 7, 7],
                'Wealth Node Prob': [
                    0.3850303901850183, 0.3651325114058089, 0.33049815481940675, 0.27777877988220145,
                    0.21775268664385025, 0.16871779895969952, 0.039647455030190085
                ],
                'Wealth Path': [
                    35000.0, 35000.00000000003, 42774.44068794796, 50403.571200532395, 58320.14750969287,
                    67480.1313585577, 75282.47671491724, 83986.96306943883
                ],
                years: [2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029]
            },
            annualDistribution: {
                amount: [0, 7000, 7000, 7000, 7000, 7000, 7000, 0],
                years: [2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029]
            }
        }
    },
    dreamVacation: {
        statusCode: 200,
        message: 'Success',
        data: {
            analysis_report: {
                'advisor discretion report': { 16: 0.6338 },
                'current goal probability': 0.6338478302327196,
                'current loss threshold probability': 0.9566688560011677,
                bankruptcy_msg: 'NA',
                'is goal realistic': true,
                'meet goal priority': true,
                'meet loss priority': true,
                'monthly top-up accumulation': '0',
                'monthly top-up decumulation': '0',
                'one time top-up': '0',
                'p-delta current goal probability': 0.5878,
                'p-delta current loss threshold probability': 0.9561,
                'recommended portfolio id': 16,
                'recommended tenure': 'NA',
                'yearly top-up accumulation': '0',
                'yearly top-up decumulation': '0',
                'recommended final wealth at 50%': 20500.0,
                'recommended final wealth at 75%': 27750.0,
                'recommended prob at 50%': 0.99,
                pdeltaCurrentLossThresholdProbability: 0.9561,
                pdeltaCurrentGoalProbability: 0.5878,
                'recommended prob at 75%': 0.99
            },
            path_report: {
                'Portfolio Path': [16, 12, 8, 8, 8, 8],
                'Wealth Node Prob': [
                    0.6338478302327196, 0.6330937369551886, 0.6425334756094627, 0.6727673874058611, 0.7085429224144859,
                    0.8182020884313681
                ],
                'Wealth Path': [
                    6000.0, 6455.604548838785, 12025.831146230345, 17986.069975070877, 24103.435792940614,
                    30576.120110823864, 36715.25485153573
                ],
                years: [2022, 2023, 2024, 2025, 2026, 2027, 2028]
            },
            annualDistribution: {
                amount: [0, 5000, 5000, 5000, 5000, 5000, 0],
                years: [2022, 2023, 2024, 2025, 2026, 2027, 2028]
            }
        }
    },
    incomeStream: {
        statusCode: 200,
        message: 'Success',
        data: {
            analysis_report: {
                'advisor discretion report': { 7: 0.2918 },
                'current goal probability': 0.29176183100444275,
                'current loss threshold probability': 0.9022638595800585,
                bankruptcy_msg: 'NA',
                'is goal realistic': false,
                'meet goal priority': false,
                'meet loss priority': false,
                message:
                    'This goal is unrealistic. Please modify the goal parameters to improve probability as per GOE recommendations.',
                'monthly top-up accumulation': '0',
                'monthly top-up decumulation': '4101',
                'one time top-up': '717380',
                'p-delta current goal probability': 0.2878,
                'p-delta current loss threshold probability': 0.9028,
                'recommended portfolio id': 7,
                'recommended tenure': 'NA',
                'yearly top-up accumulation': '0',
                'yearly top-up decumulation': '49707',
                pdeltaCurrentLossThresholdProbability: 0.9028,
                pdeltaCurrentGoalProbability: 0.2878
            },
            path_report: {
                'Portfolio Path': [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7],
                'Wealth Node Prob': [
                    0.29176183100444275, 0.26946999823165907, 0.23027160105041222, 0.19335707472309327,
                    0.17364151633427266, 0.140805263480309, 0.12315998028290723, 0.0952496857962156,
                    0.07995262597270238, 0.05775219390309148, 0.03941862817814123, 0.024908301352780732,
                    0.016621905203529953, 0.010766278931155036, 0.004988415014585508, 0.0015476284378722373,
                    0.0002753005387554696, 0.000022674121982493957, 3.963009690463757e-8, 0.0
                ],
                'Wealth Path': [
                    2000000.0, 2000000.0000000028, 1942459.0032863533, 1886573.4897241108, 1859236.601043283,
                    1805745.4374680254, 1779579.766064896, 1728380.3693294937, 1703335.7357587134, 1654329.9177719527,
                    1606734.0215910487, 1560507.4830630147, 1537895.3666612674, 1493649.3505417765, 1450676.314356342,
                    1408939.6338378685, 1368403.7384176757, 1348575.2499589394, 1309776.067945946, 1272093.1577352989,
                    1253660.2319923798
                ],
                years: [
                    2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2037,
                    2038, 2039, 2040, 2041, 2042
                ]
            },
            annualDistribution: {
                amount: [
                    0, 80000, 80000, 80000, 80000, 80000, 80000, 80000, 80000, 80000, 80000, 80000, 80000, 80000, 80000,
                    80000, 80000, 80000, 80000, 80000, 80000
                ],
                years: [
                    2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2037,
                    2038, 2039, 2040, 2041, 2042
                ]
            }
        }
    }
};

export default goeJson;
