/// <reference types="react-scripts" />

declare module 'xlsx/xlsx.mjs';
