export interface UnknownProperties {
    [key: string]: any;
}
