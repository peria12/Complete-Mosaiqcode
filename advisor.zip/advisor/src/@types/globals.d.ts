declare module 'highcharts-rounded-corners';
declare module 'react-input-mask';
