import { memo, useState, useEffect } from 'react';
import { isEmpty } from 'lodash';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import DataTableOrganism from '../../components/organisms/server-side-dashboard-table';
import {
    fetchServerSideProposal,
    fetchSearchProposal,
    fetchSortingProposal,
    updatePageNumber,
    updateDeleteId,
    updateDeleteModalState,
    deleteClient,
    deleteGoal,
    updateClientSummaryModalState
} from '../../features/my-clients/server-side-dashboard-table-slice';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import { PAGINATION, SORTING } from '../../constants';
import { updateClientSummary } from '../../features/client-summary';
import useDebounce from '../../hooks/useDebounce';
import DeleteModalComponent from '../../components/molecules/modal';
import ClientSummaryModalComponent from '../client-summary';
import TableSkeletonLoader from '../../components/molecules/table/loader';
import { updateActiveTabIndex } from '../../features/global/globalSlice';

function DataTableContainer() {
    interface SortingData {
        [x: string]: any;
        data: Array<{
            id: string;
            desc: boolean;
        }>;
    }

    const { t } = useTranslation();
    const dispatch = useAppDispatch();
    const [unStructuredData, setUnstructuredData] = useState<any[]>([]);
    const [data, setData] = useState<any[]>([]);
    const [searchString, setSearchString] = useState('');
    const debouncedValue = useDebounce<string>(searchString, 500);
    const navigate = useNavigate();
    const [deleteModalState, setDeleteModalState] = useState(false);
    const [clientSummaryState, setClientSummaryState] = useState(false);
    const {
        pageNumber,
        pageLimit,
        totalCount,
        from,
        to,
        lastPage,
        actualData,
        tableData,
        showDeleteModal,
        deleteId,
        clientSummaryModalState,
        loading
    } = useAppSelector((state) => state.serverSideTableProposals || []);
    const clientSummary = useAppSelector((state) => state.client.clientSummary);

    useEffect(() => {
        setClientSummaryState(clientSummaryModalState);
    }, [clientSummaryModalState, clientSummary]);

    useEffect(() => {
        setDeleteModalState(showDeleteModal as any);
    }, [deleteId, showDeleteModal]);

    useEffect(() => {
        setData(tableData);
        setUnstructuredData(actualData);
    }, [tableData, actualData]);

    useEffect(() => {
        if (!isEmpty(debouncedValue)) {
            dispatch(fetchSearchProposal(debouncedValue));
        } else {
            dispatch(fetchServerSideProposal({ pageNumber, pageLimit }));
        }
    }, [pageNumber, debouncedValue]);

    function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
        setSearchString(e.target.value);
    }

    const paginationProps = {
        totalCount,
        pageEntries: t('TEXT_PAGINATION_FROM_TO', {
            FROM: from,
            TO: to
        }),
        nextPage: () => dispatch(updatePageNumber(pageNumber + 1)),
        previousPage: () => dispatch(updatePageNumber(pageNumber - 1)),
        canPreviousPage: pageNumber === PAGINATION.PAGE_NUMBER_INITIAL,
        canNextPage: pageNumber === lastPage
    };

    const searchPorps = {
        placeholder: t('TEXT_SEARCH_FOR_CLIENT'),
        value: searchString,
        label: t('LABEL_SEARCH'),
        onChange: handleChange,
        key: 'searchBar'
    };

    const columnsTranslation = {
        manager_name: t('HEADER_TABLE_MANAGER_NAME'),
        advisor_name: t('HEADER_TABLE_ADVISOR_NAME'),
        client_name: t('HEADER_TABLE_CLIENT_NAME'),
        client_full_name: t('HEADER_TABLE_CLIENT_FULL_NAME'),
        risk_tolerance: t('HEADER_TABLE_RISK_TOLERANCE'),
        goal_priority: t('HEADER_TABLE_GOAL_PRIORITY'),
        goal_name: t('HEADER_TABLE_GOAL_NAME'),
        proposal_value: t('HEADER_TABLE_PORTFOLIO_VALUE'),
        goals: t('HEADER_TABLE_GOALS'),
        score: t('HEADER_TABLE_SCORE'),
        last_modified: t('HEADER_TABLE_LAST_MODIFIED'),
        equity_fixed_income: t('HEADER_TABLE_EQUITY_FIXED_INCOME'),
        delete: t('HEADER_TABLE_DELETE'),
        view: t('HEADER_TABLE_VIEW'),
        add_goal: t('TEXT_ADD_GOAL'),
        not_found: t('TEXT_NOT_FOUND')
    };
    const portfolioLastUpdatedTranslation = t('DESCRIPTION_PORTFOLIO_LAST_MODIFIED');

    // const handleClientGoalClick = (row: any, index: number) => {
    //   if (!isEmpty(unStructuredData)) {
    //     const data = unStructuredData.find((v) => v.id === row.original.id.clientId);
    //     if (row.depth >= 1) {
    //       index = index;
    //     } else {
    //       index = 0;
    //     }
    //     const formFields = JSON.parse(data.formFields);
    //     if (!isEmpty(formFields)) {
    //       // dispatch(updateClientPortfolioValue(row.original.goalAmount));
    //       dispatch(updateClientSummary(data));
    //       dispatch(updateActiveTabIndex(index));
    //       navigate('/client-summary');
    //     }
    //   }
    // };

    const handleClientGoalSummaryClick = (row: any, index: number) => {
        if (!isEmpty(unStructuredData)) {
            const data = unStructuredData.find((v) => v?.clientEmail === row?.original?.id?.clientEmail);
            if (row.depth >= 1) {
                index = index;
            } else {
                index = 0;
            }
            const formFields = data?.formFields;
            if (!isEmpty(formFields)) {
                // dispatch(updateClientPortfolioValue(row.original.goalAmount));
                dispatch(updateClientSummary(data));
                dispatch(updateActiveTabIndex(index));
                dispatch(updateClientSummaryModalState(true));
            }
        }
    };

    const handleAddClientClick = () => {
        navigate('/add-client');
    };

    const handleManualSorting = (data: SortingData) => {
        if (!isEmpty(data)) {
            const { desc } = data[0];
            dispatch(fetchSortingProposal({ name: 'clientFirstName', order: desc ? SORTING.DESC : SORTING.ASC }));
        } else {
            dispatch(fetchServerSideProposal({ pageNumber, pageLimit }));
        }
    };

    const handleDelete = (data: { client: string; goal: string }) => {
        dispatch(updateDeleteId(data));
        dispatch(updateDeleteModalState(true));
    };

    const handleCloseDeleteModal = () => {
        dispatch(updateDeleteModalState(false));
    };
    const handleCloseClientSummaryModal = () => {
        dispatch(updateClientSummaryModalState(false));
    };

    const handleClientGoalDelete = () => {
        if (deleteId.clientEmail && !deleteId.goal) {
            dispatch(deleteClient(deleteId.clientId));
            dispatch(updateDeleteModalState(false));
        } else if (deleteId.clientEmail && deleteId.goal) {
            dispatch(deleteGoal(deleteId.goal));
            dispatch(updateDeleteModalState(false));
        }
    };

    const buttonTranslation = t('BUTTON_ADD_NEW_CLIENT');

    const caption = t('DESCRIPTION_TABLE');

    return (
        <>
            {!isEmpty(data) || !loading ? (
                <DataTableOrganism
                    buttonTranslation={buttonTranslation}
                    searchPorps={searchPorps}
                    paginationProps={paginationProps}
                    data={!isEmpty(data) ? data.slice(0, pageLimit) : []}
                    handleAddClientClick={handleAddClientClick}
                    handleClientGoalSummaryClick={handleClientGoalSummaryClick}
                    unStructuredData={unStructuredData}
                    columnsTranslation={columnsTranslation}
                    portfolioLastUpdatedTranslation={portfolioLastUpdatedTranslation}
                    handleManualSorting={handleManualSorting}
                    handleDelete={handleDelete}
                    caption={caption}
                />
            ) : (
                <TableSkeletonLoader />
            )}
            <DeleteModalComponent
                handleClose={handleCloseDeleteModal}
                handleClientGoalDelete={handleClientGoalDelete}
                open={deleteModalState}
                deleteId={deleteId}
            />
            <ClientSummaryModalComponent
                open={clientSummaryState}
                handleClose={handleCloseClientSummaryModal}
                clientSummary={clientSummary}
            />
        </>
    );
}

export default memo(DataTableContainer);
