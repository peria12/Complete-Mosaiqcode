import { memo, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ColumnDef } from '@tanstack/react-table';
import { styled } from '@mui/material/styles';
import BorderColorIcon from '@mui/icons-material/BorderColor';

import DataTableOrganism from '../../components/organisms/client-side-dashboard-table';
import {
    fetchTranslations,
    translationType,
    updateTranslations,
    selectTranslation
} from '../../features/admin-manage-translation';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import { PAGINATION, ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS } from '../../constants';
import { AlignTableCellCenter } from '../../components/organisms/client-side-dashboard-table/styles';
import AddTranslationModal from './add-translation';
import EditTranslation from './edit-translation';
import { HeaderText } from '../advisor-admin-clients-table';

const IconContainer = styled(AlignTableCellCenter)(({ theme }) => ({
    cursor: 'pointer',
    color: theme.palette.primary.dark
}));

function AdminManageTranslationTable() {
    const [isAppTranslationModalOpen, setIsAppTranslationModalOpen] = useState(false);
    const [isEditTranslationModalOpen, setIsEditTranslationModalOpen] = useState<any>(null);

    const { t } = useTranslation();
    const dispatch = useAppDispatch();

    const { translations } = useAppSelector((state) => state.translations || []);

    useEffect(() => {
        (async () => {
            const data: any = await dispatch(fetchTranslations());

            dispatch(updateTranslations(data.payload));
        })();
    }, []);

    const handleAddClientClick = () => {
        setIsAppTranslationModalOpen(true);
    };

    const columns = useMemo<ColumnDef<translationType>[]>(
        () => [
            {
                accessorKey: ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS.LOOK_UP_KEY,
                id: ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS.LOOK_UP_KEY,
                header: t('TEXT_TABLE_HEADER_LOOK_UP_KEY'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS.LOOK_UP_VALUE,
                id: ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS.LOOK_UP_VALUE,
                header: t('TEXT_TABLE_HEADER_LOOK_UP_VALUE'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS.DESCRIPTION,
                id: ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS.DESCRIPTION,
                header: t('TEXT_TABLE_HEADER_DESCRIPTION'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: ADMIN_MANAGE_TRANSLATION_TABLE_ACCESS_KEYS.ID,
                id: 'deleteIcon',
                header: t('TEXT_TABLE_HEADER_ACTIONS'),
                enableSorting: false,
                cell: ({ row, getValue }) => (
                    <>
                        {getValue() && (
                            <IconContainer>
                                {/* eslint-disable-next-line no-console */}
                                <BorderColorIcon
                                    onClick={() => {
                                        dispatch(selectTranslation(row.original));
                                        setIsEditTranslationModalOpen(row.original);
                                    }}
                                />
                            </IconContainer>
                        )}
                    </>
                )
            }
        ],
        [translations]
    );

    return (
        <>
            <HeaderText>{t('TEXT_ADMIN_MANAGE_TRANSLATION_PAGE_HEADER')}</HeaderText>

            <DataTableOrganism
                data={translations}
                columns={columns}
                handleAddClientClick={handleAddClientClick}
                columnVisibility={{}}
                searchPlaceHolder={t('TEXT_ADMIN_MANAGE_TRANSLATION_PAGE_SEARCH_PLACEHOLDER')}
                pageLimit={PAGINATION.PAGE_LIMIT}
                hideExtraText
                addButtonText={t('TEXT_ADMIN_MANAGE_TRANSLATION_PAGE_ADD_BUTTON')}
            />

            <AddTranslationModal
                open={isAppTranslationModalOpen}
                handleClose={() => {
                    setIsAppTranslationModalOpen(false);
                }}
            />

            <EditTranslation
                open={Boolean(isEditTranslationModalOpen)}
                handleClose={() => {
                    setIsEditTranslationModalOpen(null);
                }}
            />
        </>
    );
}

export default memo(AdminManageTranslationTable);
