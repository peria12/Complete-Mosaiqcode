import { memo } from 'react';
import { styled } from '@mui/material/styles';
import Box, { BoxProps } from '@mui/material/Box';
import Modal from '@mui/material/Modal';

import TranslationInfo from '../../components/molecules/translation-info';

const StyledBox = styled(Box)<BoxProps>(({ theme }) => ({
    position: 'absolute' as 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '90%',
    color: theme.palette.common.white,
    zIndex: 100,
    fontSize: '1rem',
    padding: '10px 32px !important',
    overflowX: 'scroll',
    maxHeight: '85%',
    '@media(max-width: 991px)': {
        top: '10%',
        transform: 'translate(-50%, 0%)',
        padding: '10px 32px !important',
        width: '90%'
    }
}));

const AddTranslationModal = ({ open, handleClose }: any) => (
    <>
        <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
            sx={{ overflowY: 'scroll' }}
            disableScrollLock
        >
            <StyledBox sx={{ bgcolor: 'background.paper', p: 4, borderRadius: 1 }}>
                <TranslationInfo onSubmit={() => {}} onCancel={handleClose} />
            </StyledBox>
        </Modal>
    </>
);

export default memo(AddTranslationModal);
