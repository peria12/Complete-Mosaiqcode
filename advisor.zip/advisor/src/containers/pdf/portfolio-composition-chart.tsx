import { useState, useEffect } from 'react';
import { useTheme } from '@mui/material/styles';
import { isEmpty } from 'lodash';
import { EQUITY } from '../../constants';
import PortfolioCompositionOrganism from '../../components/organisms/charts/portfolio-composition';

const portfolioCompositionContainer = ({
    showLoader,
    portfolioDataForChart,
    enableSourceCaveatNumbers,
    ...rest
}: any) => {
    const theme = useTheme();
    const { chartData, label, equity, fixedIncome } = portfolioDataForChart;

    const [data, setData] = useState([]);
    const [labelXaxis, setLableXaxis] = useState(0);
    const [labelYaxis, setLableYaxis] = useState(0);

    useEffect(() => {
        if (!isEmpty(chartData)) {
            let updatedData: any = chartData
                .map((val: any) =>
                    val.subAssets.map((v: { ticker: string; allocatedValue: string; tickerLink: string }) => ({
                        name: JSON.stringify([v.ticker, val.type, v.tickerLink]),
                        y: v.allocatedValue,
                        color:
                            val.type === EQUITY ?
                                theme.palette.charts.portfolioComposition.equity :
                                theme.palette.charts.portfolioComposition.fixedIncome
                    }))
                )
                .flat();

            updatedData = updatedData.sort(
                (a: { y: string | any }, b: { y: string | any }) => parseFloat(b.y) - parseFloat(a.y)
            );
            setLableYaxis(Math.max(...updatedData.map((o: { y: any }) => o.y)));
            setLableXaxis(updatedData.length - 1);
            setData(updatedData);
        }
    }, [chartData]);
    return (
        <PortfolioCompositionOrganism
            theme={theme}
            labelXaxis={labelXaxis}
            labelYaxis={labelYaxis}
            label={label}
            hideChartLabel
            data={data}
            equity={equity}
            showLoader={showLoader}
            fixedIncome={fixedIncome}
            enableSourceCaveatNumbers={enableSourceCaveatNumbers}
            {...rest}
        />
    );
};

export default portfolioCompositionContainer;
