import { useState, useEffect } from 'react';

const PersonalizedPlanContainer = () => {
    const [title, setTitle] = useState('');
    useEffect(() => {
        setTitle('PersonalizedPlanContainer');
    }, []);

    return (
        <>
            <p>{title}</p>
        </>
    );
};

export default PersonalizedPlanContainer;
