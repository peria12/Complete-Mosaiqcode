import { Card, CardContent } from '@mui/material';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import LockResetIcon from '@mui/icons-material/LockReset';
import PersonRemoveIcon from '@mui/icons-material/PersonRemove';
import KeyIcon from '@mui/icons-material/Key';
import KeyOffIcon from '@mui/icons-material/KeyOff';
import { styled } from '@mui/material/styles';

const StyledCard = styled(Card)(() => ({
    minWidth: '214.792px',
    cursor: 'pointer',
    maxWidth: 'max-content',
    margin: '0 20px'
}));

const StyledCardContent = styled(CardContent)(() => ({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center'
}));

const LockIcon = styled(LockOpenIcon)(() => ({
    fontSize: '80px',
    marginBottom: '10px'
}));

const ResetIcon = styled(LockResetIcon)(() => ({
    fontSize: '80px',
    marginBottom: '10px'
}));

const RemoveIcon = styled(PersonRemoveIcon)(() => ({
    fontSize: '80px',
    marginBottom: '10px'
}));

const RestrictIcon = styled(KeyIcon)(() => ({
    fontSize: '80px',
    marginBottom: '10px'
}));

const UnrestrictIcon = styled(KeyOffIcon)(() => ({
    fontSize: '80px',
    marginBottom: '10px'
}));

const Span = styled('span')(({ theme }) => ({
    color: theme.palette.grey[900],
    display: 'block',
    fontSize: '18px',
    lineHeight: 2.5,
    fontWeight: 400,
    overflow: 'hidden',
    maxWidth: '24ch',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap'
}));

const Title = styled(Span)(() => ({
    fontSize: '24px',
    margin: '20px 0'
}));

const Row = styled('div')(() => ({
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center'
}));

export default function ManageUser() {
    return (
        <>
            <Title>User Password:</Title>

            <Row>
                <StyledCard>
                    <StyledCardContent>
                        <LockIcon />

                        <Span>Remove Password Lock</Span>
                    </StyledCardContent>
                </StyledCard>

                <StyledCard>
                    <StyledCardContent>
                        <ResetIcon />

                        <Span>Reset Password</Span>
                    </StyledCardContent>
                </StyledCard>
            </Row>

            <Title>Account Access:</Title>

            <Row>
                <StyledCard>
                    <StyledCardContent>
                        <RestrictIcon />

                        <Span>Suspend User Access</Span>
                    </StyledCardContent>
                </StyledCard>

                <StyledCard>
                    <StyledCardContent>
                        <UnrestrictIcon />

                        <Span>UnSuspend User Access</Span>
                    </StyledCardContent>
                </StyledCard>

                <StyledCard>
                    <StyledCardContent>
                        <RemoveIcon />

                        <Span>Remove User</Span>
                    </StyledCardContent>
                </StyledCard>
            </Row>
        </>
    );
}
