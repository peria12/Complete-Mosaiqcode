import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { styled } from '@mui/material/styles';

import { useAppSelector } from '../../app/hooks';
import TabsComponent from '../../components/molecules/tabs';
import EditUser from '../../containers/user-summary/edit-user';
import ManageUser from '../../containers/user-summary/manage-user';

const Container = styled('div')(() => ({
    minHeight: '73.2vh'
}));

const Span = styled('span')(({ theme }) => ({
    color: theme.palette.grey[900],
    display: 'block',
    fontSize: '18px',
    lineHeight: 2.5,
    fontWeight: 400,
    overflow: 'hidden',
    maxWidth: '24ch',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap'
}));

const Title = styled(Span)(() => ({
    fontSize: '24px',
    margin: '20px 0'
}));

const Row = styled('div')(() => ({
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center'
}));

export default function UserSummaryContainer() {
    const navigate = useNavigate();

    const [currentTab, setCurrentTab] = useState(0);

    const user = useAppSelector((state) => state.users.userSelected);

    return (
        <Container>
            <Row
                style={{
                    justifyContent: 'space-between'
                }}
            >
                <Title
                    style={{
                        color: '#3769FF',
                        fontWeight: 'bold',
                        margin: 0
                    }}
                >
                    {user?.firstName} {user?.lastName}
                </Title>

                <Title
                    style={{
                        color: '#3769FF',
                        fontWeight: 'bold',
                        alignSelf: 'flex-end',
                        margin: 0
                    }}
                >
                    Last Login: {user?.lastLogin}
                </Title>
            </Row>

            <TabsComponent
                toggleState={currentTab}
                toggleTab={(value: any, index: number) => {
                    setCurrentTab(index);
                }}
                onEdit={() => {}}
                buttonTitle="Go Back"
                onButtonClick={() => {
                    navigate('/user-management');
                }}
                tabsData={[
                    {
                        data: {
                            goalName: 'User Summary'
                        },
                        value: 'User Summary'
                    },
                    {
                        data: {
                            goalName: 'Manage User'
                        },
                        value: 'Manage User'
                    }
                ]}
            />

            {currentTab === 0 && <EditUser />}

            {currentTab === 1 && <ManageUser />}
        </Container>
    );
}
