import UserInfo from '../../components/molecules/add-user';
import { useAppSelector } from '../../app/hooks';

export default function EditUser() {
    const user = useAppSelector((state) => state.users.userSelected);

    return <UserInfo data={user} submitButtonText="Save" onSubmit={() => {}} onCancel={() => {}} />;
}
