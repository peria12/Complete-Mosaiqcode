import { memo, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { ColumnDef } from '@tanstack/react-table';
import { useNavigate } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';

import DataTableOrganism from '../../components/organisms/client-side-dashboard-table';
import { fetchUsers, updateUsers, userType, selectUser } from '../../features/user-management';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import { PAGINATION, USERS_TABLE_ACCESS_KEYS } from '../../constants';
import { AlignTableCellCenter } from '../../components/organisms/client-side-dashboard-table/styles';

const IconContainer = styled(AlignTableCellCenter)(({ theme }) => ({
    cursor: 'pointer',
    color: theme.palette.primary.dark
}));

function UserManagementDataTableContainer() {
    const { t } = useTranslation();
    const dispatch = useAppDispatch();
    const navigate = useNavigate();

    const { users } = useAppSelector((state) => state.users || []);

    useEffect(() => {
        (async () => {
            const data: any = await dispatch(fetchUsers());

            dispatch(updateUsers(data.payload));
        })();
    }, []);

    const handleAddClientClick = () => {
        navigate('/add-user');
    };

    const columns = useMemo<ColumnDef<userType>[]>(
        () => [
            {
                accessorKey: USERS_TABLE_ACCESS_KEYS.FIRST_NAME,
                id: USERS_TABLE_ACCESS_KEYS.FIRST_NAME,
                header: t('HEADER_USER_MANAGEMENT_TABLE_FIRST_NAME'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: USERS_TABLE_ACCESS_KEYS.LAST_NAME,
                id: USERS_TABLE_ACCESS_KEYS.LAST_NAME,
                header: t('HEADER_USER_MANAGEMENT_TABLE_LAST_NAME'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: USERS_TABLE_ACCESS_KEYS.ACCESS_LEVEL,
                id: USERS_TABLE_ACCESS_KEYS.ACCESS_LEVEL,
                header: t('HEADER_USER_MANAGEMENT_TABLE_ACCESS_LEVEL'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: USERS_TABLE_ACCESS_KEYS.USERNAME,
                id: USERS_TABLE_ACCESS_KEYS.USERNAME,
                header: t('HEADER_USER_MANAGEMENT_TABLE_USERNAME'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: USERS_TABLE_ACCESS_KEYS.EMAIL_ADDRESS,
                id: USERS_TABLE_ACCESS_KEYS.EMAIL_ADDRESS,
                header: t('HEADER_USER_MANAGEMENT_TABLE_EMAIL_ADDRESS'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: USERS_TABLE_ACCESS_KEYS.LAST_LOGIN,
                id: USERS_TABLE_ACCESS_KEYS.LAST_LOGIN,
                header: t('HEADER_USER_MANAGEMENT_TABLE_LAST_LOGGED_IN'),
                cell: ({ getValue }) => getValue()
            },
            {
                accessorKey: USERS_TABLE_ACCESS_KEYS.ID,
                id: 'deleteIcon',
                header: t('HEADER_USER_MANAGEMENT_TABLE_MANAGE_USER'),
                enableSorting: false,
                cell: ({ row, getValue }) => (
                    <>
                        {getValue() && (
                            <IconContainer>
                                {/* eslint-disable-next-line no-console */}
                                <ManageAccountsIcon
                                    onClick={() => {
                                        dispatch(selectUser(row.original));
                                        navigate('/user-summary');
                                    }}
                                />
                            </IconContainer>
                        )}
                    </>
                )
            }
        ],
        [users]
    );

    return (
        <DataTableOrganism
            data={users}
            columns={columns}
            handleAddClientClick={handleAddClientClick}
            columnVisibility={{}}
            searchPlaceHolder={t('PLACEHOLDER_SEARCH')}
            pageLimit={PAGINATION.PAGE_LIMIT}
            hideExtraText
            addButtonText={t('BUTTON_ADD_NEW_USER')}
        />
    );
}

export default memo(UserManagementDataTableContainer);
