import jwt
import os
import datetime
import time
import json

from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from fastapi.responses import PlainTextResponse
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from goelib.errors import GoeException

from uip_auth_s import Validater
from starlette.responses import HTMLResponse

import uip_files
import uip_logging

uip_logging.initialize("fastapi-transcoder")

import uip_config
import uip_grpc
import logging

from uip_utils import generate_request_id

from goe import router
from auth import auth_router

from fastapi.openapi.utils import get_openapi
from starlette.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from fastapi.openapi.docs import (
    get_swagger_ui_oauth2_redirect_html,
    swagger_ui_default_parameters,
    get_swagger_ui_html,
    get_redoc_html
)
from uip_auth_s import Okta

okta = Okta()

cfg = uip_config.ConfigDict()

port = os.environ.get("FASTAPI_PORT")

topbar_definitions = [
    {"url": "/api/v1/openapi.json", "name": "API Version 1"},
    {"url": "/api/v2/openapi.json", "name": "API Version 2"},
]


app = FastAPI(
    title="GOEAPI",
    description='<div style="color:blue"><i>GOE apis documentation.</i></div>',
    # contact={
    #     "name": "API Support",
    #     "url": "https://example.com/contact",
    #     "email": "goe@franklintempleton.com",
    # },
    # openapi_tags= ["default"],
    docs_url=None,
    redoc_url=None,
    openapi_url="/documentation/openapi.json",
    swagger_ui_oauth2_redirect_url="/documentation/docs/oauth2-redirect",
    separate_input_output_schemas=False,
    topbar_definitions= topbar_definitions
)
app.mount("/documentation/static", StaticFiles(directory="www/swagger"), name="static")


def custom_openapi():
    if not app.openapi_schema:
        app.openapi_schema = get_openapi(
            title=app.title,
            version=app.version,
            openapi_version=app.openapi_version,
            description=app.description,
            terms_of_service=app.terms_of_service,
            contact=app.contact,
            license_info=app.license_info,
            routes=app.routes,
            tags=app.openapi_tags,
            servers=app.servers,
        )
        for _, method_item in app.openapi_schema.get("paths").items():
            for _, param in method_item.items():
                responses = param.get("responses")
                # remove 422 response, also can remove other status code
                if "422" in responses:
                    del responses["422"]
    return app.openapi_schema


app.openapi = custom_openapi
app.include_router(router)
app.include_router(auth_router)


class Middleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        await self.app(scope, receive, send)


app.add_middleware(Middleware)
app.add_middleware(CORSMiddleware, allow_origins=["*"])

grpc_channels = uip_grpc.GRPC(async_mode=True)
validater = Validater()

fio = uip_files.Files()

usage = {}
usage_minute = time.time() // 60

@app.middleware("http")
async def before_requests(request: Request, call_next):
    # Do something before the request is handled
    logging.info("Request received")
    auth = request.headers.get("authorization")
    if not auth:
        auth = request.path_params.get("access_token", "")
    token = auth.replace("Bearer ", "")
    source_ip = request.headers.get("HTTP_X_REAL_IP", request.client.host)
    if (
        request.url.path.lower()
        in [
            "/api/fastapihealthcheck",
            "/forgotpassword",
            "/refreshtoken",
            "/changepassword",
            "/signin",
        ]        
        or request.url.path.startswith("/documentation/")
        or request.url.path.startswith("/api/file-name/public/")
        or request.url.path.startswith("/apis/custom.metrics.k8s.io/")
        or (request.url.path.startswith("/api/file-id/") and fio.is_file_public(request.url.path.split("/")[-1]))
        or (source_ip in cfg["safe_hosts"] and request.url.path.startswith("/api/file/"))
    ):
        # this request is coming from a safe host,
        # we allow file requests from safe hosts
        # TODO remove the DAL overide when SEnthil's demo is done
        svc_account = cfg["uip_svc_account"].get("user")

        metadata_d = {
            "ipaddr": source_ip,
            "email": svc_account,
            "target-email": request.headers.get("target-email", svc_account),
        }
    else:
        try:
            auth_data = await validater.validate_token_and_return_data(token)
            metadata_d = {
                "first-name": auth_data.get("given_name"),
                "ipaddr": auth_data.get("ipaddr") or source_ip,
                "user-full-name": auth_data.get("name"),
                "user-name": auth_data["unique_name"].replace("@franklintempleton.com", ""),
                "user-id": auth_data["oid"],
                "email": auth_data.get("username") or auth_data["unique_name"],
                "target-email": request.headers.get("target-email", auth_data["unique_name"]),
            }

        except Exception as e:
            try:
                logging.error(f"Exception Occured while validating token and generating metadata_d {e}")
                if "Signature has expired" in str(e):
                    data = jwt.decode(token, options={"verify_signature": False})
                    return JSONResponse(
                        {
                            "name": "TokenExpiredError",
                            "message": "jwt expired",
                            "expiredAt": datetime.datetime.utcfromtimestamp(data["exp"]).isoformat(),
                        },
                        status_code=500,
                    )
            except Exception as e:
                logging.error(f"Auth Error {e}")
                return JSONResponse({"name": "authentication error", "message": str(e)}, status_code=401)
            return JSONResponse({"name": "authentication error", "message": str(e)}, status_code=401)

    metadata_d["authorization"] = request.headers.get("authorization", request.path_params.get("access_token", ""))
    metadata_d["request-id"] = request.headers.get("request-id", generate_request_id())
    request.state.vars = {
        "user": metadata_d.get("target-email"),
        "metadata_d": metadata_d,
        "metadata_t": tuple(metadata_d.items()),
        "L": logging.LoggerAdapter(logging.getLogger("user"), metadata_d),
    }
    response = await call_next(request)
    return response


def usage_count(user):
    global usage
    global usage_minute

    now = time.time() // 60
    if now > usage_minute:
        usage_minute = now
        usage = {}

    if user in usage:
        usage[user] += 1
    else:
        usage[user] = 1

    return usage[user]


# @app.after_request
# async def after_request_func(response):
#     request_id = request.headers.get("Request-Id")
#     response.headers["Request-Id"] = request_id
#     return response

@app.get("/documentation/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    swagger_ui_parameters = {"syntaxHighlight": True,  "layout": "BaseLayout",
    "deepLinking": True,
    "showExtensions": True,
    "showCommonExtensions": True,
    # "tryItOutEnabled": True,
    # "docExpansion": "none",
    "presets": "SwaggerUI.presets.ApisPreset",
    "defaultModelsExpandDepth": -1
    }
    current_swagger_ui_parameters = swagger_ui_default_parameters.copy()
    if swagger_ui_parameters:
        current_swagger_ui_parameters.update(swagger_ui_parameters)
    html = """

    <!DOCTYPE html>
    <html>
    <head>
    <link type="text/css" rel="stylesheet" href="/documentation/static/swagger-ui.css">
    <link rel="shortcut icon" href="/documentation/static/img/favicon.png">
    <title>GOEAPI - Swagger UI</title>
    </head>
    <body>
    <div id="swagger-ui">
    </div>
    <script src="/documentation/static/swagger-ui-bundle.js"></script>
    <!-- `SwaggerUIBundle` is now available on the page -->
    <script defer src="/documentation/static/swagger_js.js">
    </script>
    </body>
    </html>"""
    return HTMLResponse(html)
    # return get_swagger_ui_html(
    #     openapi_url=app.openapi_url,
    #     title="GOE" + " - Swagger UI",
    #     oauth2_redirect_url=app.swagger_ui_oauth2_redirect_url,
    #     swagger_js_url="/documentation/static/swagger-ui-bundle.js",
    #     swagger_css_url="/documentation/static/swagger-ui.css",
    #     swagger_favicon_url="/documentation/static/img/favicon.png",
    #     swagger_ui_parameters=current_swagger_ui_parameters
    # )


@app.get(app.swagger_ui_oauth2_redirect_url, include_in_schema=False)
async def swagger_ui_redirect():
    return get_swagger_ui_oauth2_redirect_html()


@app.get("/documentation/redoc", include_in_schema=False)
async def redoc_html():
    return get_redoc_html(
        openapi_url=app.openapi_url,
        with_google_fonts=None,
        title=app.title + " - ReDoc",
        redoc_js_url="/documentation/static/redoc.standalone.js",
        redoc_favicon_url= "/documentation/static/img/favicon.png",
    )

    # html = """<!DOCTYPE html>
    # <html>
    # <head>
    # <title>FastAPI - ReDoc</title>
    # <!-- needed for adaptive design -->
    # <meta charset="utf-8"/>
    # <meta name="viewport" content="width=device-width, initial-scale=1">
    # <link rel="shortcut icon" href="/documentation/static/img/favicon.png">
    # <!--
    # ReDoc doesn't change outer page styles
    # -->
    # <style>
    #   body {
    #     margin: 0;
    #     padding: 0;
    #   }
    # </style>
    # </head>
    # <body>
    # <div id="redoc-container"></div>
    # <script src="/documentation/static/redoc.standalone.js"> </script>
    # <script src= "/documentation/static/redoc_init.js" > </script>
    # </body>
    # </html>"""
    # return HTMLResponse(html)


@app.route("/api/fastapihealthcheck", methods=["GET"])
def healthcheck(request: Request):
    version = os.getenv("UIP_VERSION") or "na"
    env = os.getenv("UIP_ENV") or "user"
    return JSONResponse({"healthcheck": "OK", "version": version, "env": env})


from uip_auth_s import Okta

import uip_config
import humps
import time
from pydantic import BaseModel, Field
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from typing import Annotated
from fastapi import Depends, FastAPI, HTTPException, status

class Token(BaseModel):
    access_token: str
    token_type: str

class SignInInputModel(BaseModel):
    email: str = Field()
    password: str = Field()

# @app.post("/signIn", response_model=Token,  name="signIn")
# async def signin(
#     # form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
#     signin_data: SignInInputModel,
#     request: Request
# ):
#     data = json.loads(signin_data.json())
#     email = data.get("email", None)
#     password = data.get("password", None)
#     L = request.state.vars["L"]
#     if not email:
#         L.info("Okta signin API: email not provided.")
#         return JSONResponse({"statusCode": 400, "message": "Email not provided", "body": None}, status_code=400)

#     if not password:
#         L.info("Okta signin API: password not provided.")
#         return JSONResponse({"statusCode": 400, "message": "Missing required parameter PASSWORD", "body": None}, status_code=400)

#     L.info(f"Okta signIn {email}")

#     count = usage_count(email)
#     if count > cfg["okta"]["rate_limit"]:
#         L.info(f"Okta signIn {email}, blocked, count {count}")
#         return JSONResponse({"statusCode": 400, "message": "Too many signIn attempts.", "body": None}, status_code=400)

#     try:
#         result = await okta.signin(username=email, password=password)
#         return JSONResponse({"AuthenticationResult": humps.pascalize(result)})
#     except Exception as exc:
#         L.info(f"Okta signin API Failed {str(exc)}")
#         return JSONResponse({"statusCode": 400, "message": "Incorrect username or password.", "body": None}, status_code=400)


@app.exception_handler(GoeException)
async def goe_exception_handler(request: Request, exc: GoeException):
    return JSONResponse(
        status_code=exc.code,
        content={"statusCode":exc.code , "message": f"{exc.messages}"},
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse({"message": str(exc.detail), "statusCode": exc.status_code}, status_code=exc.status_code)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    return PlainTextResponse(str(exc), status_code=400)

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"statusCode":500 , "message": f"{exc}"},
    )

if __name__ == "__main__":
    import uvicorn

    uvicorn.run("__main__:app", host="0.0.0.0", port=int(port), reload=True)
