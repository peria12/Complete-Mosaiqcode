"""
    Goe apis entry point is defined here.
    for external urls which will be defined from now
    will use this prefix /api/goe-api
"""
import json
import traceback
import simplejson

import rest_pb2
import rest_pb2_grpc
import tempfile
import uip_files

# import pandas

import uip_grpc

# from datetime import date
from werkzeug.exceptions import HTTPException

from quart import Blueprint, jsonify, request, make_response

from async_timeout import timeout
from google.protobuf.struct_pb2 import Struct


# from quart.json import JSONEncoder

from google.protobuf.json_format import MessageToJson
from goelib.api.shared.case_conversion import convertToCamelCase

from transcoder_libs import download
from goelib.api.resources.admin import dump_data_to_database
from goelib.api.resources.pipeserverless import (
    pipe_controller_run_wealth_splitter,
    pipe_serverless_controller_run_advisor_engine,
    pipe_serverless_controller_run_advisor_engine_v2,
    pipe_serverless_controller_run_advisor_engine_v4,
    pipe_serverless_controller_historical_live_scenarios,
    # pipe_serverless_historical_live_scenarios_get_status,
    hantz_translator_api,
    replacement_income_calculator_api,
    goe_run_pipe_taxes,
    goe_goal_simulation_engine_payload,
    social_security_calculator_api,
    # goe_decumulation_api,
    fixed_discretionary_calculator_api,
    # goal_calculator_api,
    read_data_from_csv,
    custom_portfolios_api_payload,
)
from goelib.api.shared.common import DictDefault
from goelib.errors import GoeException
from goelib.api.resources import admin

from transcoder_libs import authorize


from goelib.api.resources.australia_demo import handler

grpc_channels = uip_grpc.GRPC(async_mode=True)

goe_app = Blueprint(
    "goe",
    __name__,
)

svc_client = uip_grpc.ServiceClient()


# class DateJSONEncoder(JSONEncoder):
#     def default(self, obj):
#         if isinstance(obj, date) or isinstance(obj, pandas.Timestamp):
#             return obj.isoformat()
#         return super().default(obj)


# goe_app.json_encoder = DateJSONEncoder


# @goe_app.route("/v3/RUNWEALTHSPLITTER", methods=["POST"])
# @goe_app.route("/v3/runwealthsplitter", methods=["POST"])
# @goe_app.route("/v3/runWealthSplitter", methods=["POST"])
# @authorize(
#     (
#         ("goe", "client-settings", "admin"),
#         ("goe", "client-settings", "view"),
#         ("goe", "client-settings", "client"),
#     )
# )
# async def svc_goe_initial_wealth_splitter():
#     L = request.vars["L"]

#     request_json = await request.json
#     L.info(f"POST /v3/runWealthSplitter {request_json}")
#     L.info("User is accessing app in UI: GOE API:/v3/runWealthSplitter")
#     req = {}
#     req["remote_addr"] = request.remote_addr
#     req["headers"] = request.headers
#     req["request_meta_data"] = request.vars["metadata_t"]
#     req["requester_oid"] = request.vars["metadata_d"]["user-id"]
#     result = await pipe_controller_run_wealth_splitter(req, request_json)
#     if isinstance(result, tuple):  # tuple returned incase of request need to passed to goe algo
#         pipe_result, handler = result
#     else:
#         pipe_result = result
#     pipe_result = DictDefault(pipe_result)
#     if pipe_result.statusCode in [200, 400]:
#         json_data = json.dumps(pipe_result)
#         data = await make_response(json_data)
#         data.headers.set("Content-Type", "application/json")
#         L.info(f"RESPONSE PAYLOAD POST /v3/runWealthSplitter {json_data}")
#         return data, pipe_result.statusCode
#     elif pipe_result.get("statusCode") is None:  # If status is None then request need to submit to goealgo api.
#         goe_response = MessageToJson(
#             await svc_client.call_queue_based_service(
#                 "goe-service",
#                 "InitialWealthSplitter",
#                 rest_pb2.GOERequest(request=json.dumps(pipe_result)),
#                 metadata=request.vars["metadata_t"],
#             ),
#             preserving_proto_field_name=True,
#         )
#         res = handler(goe_response)
#         # res = pipe_gen[0].asend(goe_response)
#         L.info(f"RESPONSE POST /v3/runWealthSplitter {res}")
#         return res
#     else:
#         L.info(f"RESPONSE ERROR POST /v3/runWealthSplitter {pipe_result}")
#         return pipe_result


@goe_app.route("/api/goe/runwealthsplitter_grpc", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "client"),
    )
)
async def svc_goe_initial_wealth_splitter_with_grpc():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/goe/runwealthsplitter_grpc {request_json}")
    L.info("User is accessing app in UI: GOE API:/api/goe/runwealthsplitter_grpc")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    result = await pipe_controller_run_wealth_splitter(req, request_json)
    if isinstance(result, tuple):  # tuple returned incase of request need to passed to goe algo
        pipe_result, handler = result
    else:
        pipe_result = result
    pipe_result = DictDefault(pipe_result)
    if pipe_result.statusCode in [200, 400]:
        json_data = json.dumps(pipe_result)
        data = await make_response(json_data)
        data.headers.set("Content-Type", "application/json")
        L.info(f"RESPONSE PAYLOAD POST /v3/runWealthSplitter {json_data}")
        return data, pipe_result.statusCode
    elif pipe_result.get("statusCode") is None:  # If status is None then request need to submit to goealgo api.
        goe_response = MessageToJson(
            await rest_pb2_grpc.GOEServiceStub(grpc_channels.get_channel("goe-algorithm")).InitialWealthSplitter(
                request=rest_pb2.GOERequest(request=json.dumps(pipe_result)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        res = handler(goe_response)
        L.info(f"RESPONSE POST /api/goe/runwealthsplitter_grpc {res}")
        return res
    else:
        L.info(f"RESPONSE ERROR POST /api/goe/runwealthsplitter_grpc {pipe_result}")
        return pipe_result


@goe_app.route("/v1/HISTORICALLIVESCENARIOS/CALLBACK", methods=["POST"])
@goe_app.route("/v1/historicallivescenarios/callback", methods=["POST"])
@goe_app.route("/v1/historicalLiveScenarios/callback", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "client"),
    )
)
async def svc_goe_historical_live_scenarios():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /v1/historicalLiveScenarios/callback {request_json}")
    L.info("User is accessing app in UI: GOE API:/v1/historicalLiveScenarios")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    result = await pipe_serverless_controller_historical_live_scenarios(req, request_json)
    if isinstance(
        result, tuple
    ):  # tuple returned incase of request need to and proceed further for next step to submit to  goe algo
        pipePayload, handler = result
    else:
        pipePayload = result
    pipePayload = DictDefault(pipePayload)
    if pipePayload.statusCode in [400, 200]:
        json_data = json.dumps(pipePayload)
        data = await make_response(json_data)
        data.headers.set("Content-Type", "application/json")
        L.info(f"RESPONSE PAYLOAD POST /v1/historicalLiveScenarios/callback {json_data}")
        return data, pipePayload.statusCode
    elif (
        pipePayload and pipePayload.statusCode is None
    ):  # If status is None then request need to submit to goealgo api.
        # This call has streaming response.
        # We return immediately after getting the first msg in the stream

        request_id = await svc_client.make_deferred_request(
            "goe-service",
            "HistoricalLiveScenarios",
            rest_pb2.GOERequest(request=json.dumps(pipePayload)),
            metadata=request.vars["metadata_t"],
        )

        res = {"body": {"requestId": request_id}, "message": "Success", "statusCode": 200}

        L.info(f"RESPONSE POST /v1/historicalLiveScenarios/callback {res}")
        return res
    else:
        L.info(f"RESPONSE ERROR POST /v1/historicalLiveScenarios/callback {pipePayload}")
        return pipePayload


@goe_app.route("/decumulation/dumpdata", methods=["GET"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_decumulation_data_dump():
    L = request.vars["L"]
    L.info("GET /decumulation/dumpdata")
    collection_name = "goe-settings"
    document_id = "decumulation_look_up"
    document_info = MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetDocument(
            request=rest_pb2.GetDocumentRequest(
                collection_name=collection_name,
                document_id=document_id,
                version=request.args.get("version", None),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
        sort_keys=True,
    )
    document_info = eval(document_info)
    file_document_id = document_info["files"][0]["file_id"]
    download_obj = await download(file_document_id)
    tmp = tempfile.NamedTemporaryFile()
    file_path = tmp.name

    with open(file_path, "wb") as file_obj:
        file_obj.write(download_obj["data"])
    decumulation_data = await read_data_from_csv(file_path)
    dum_data_status = await dump_data_to_database(decumulation_data)
    if dum_data_status:
        return {"statusCode": 202, "message": "Decumulation data dumped in database successfully."}, 200
    else:
        return {
            "error": {"status": 400, "message": "Decumulation data dump in database has failed.", "name": "Error"}
        }, 200


@goe_app.route("/v1/HISTORICALLIVESCENARIOS/<request_id>", methods=["GET"])
@goe_app.route("/v1/historicallivescenarios/<request_id>", methods=["GET"])
@goe_app.route("/v1/historicalLiveScenarios/<request_id>", methods=["GET"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "client"),
    )
)
async def svc_goe_historical_live_scenarios_get(request_id):
    L = request.vars["L"]

    L.info(f"GET /v1/historicalLiveScenarios/{request_id}")
    # pipe_pay_load = pipe_serverless_historical_live_scenarios_get_status(request_id)
    res = await svc_client.get_deferred_results(
        "goe-service",
        request_id,
        metadata=request.vars["metadata_t"],
    )

    if not res["result"]:
        L.info(f"RESPONSE ERROR GET /v1/historicalLiveScenarios/{request_id}")
        if res["token_id_valid"]:
            return {"statusCode": 202, "message": "Request is still processing"}, 200
        else:
            return {"error": {"status": 400, "message": "request id not found", "name": "Error"}}, 200

    res = json.loads(MessageToJson(res["result"], preserving_proto_field_name=True))

    res = res.get("outputObject")
    res["statusCode"] = int(res.get("statusCode"))
    if res and res.get("statusCode") == 200:
        if res.get("data"):
            res["body"] = json.loads(res.get("data"))
            del res["data"]

    resp_json = simplejson.dumps(res, ignore_nan=True)
    res = await make_response(resp_json)
    res.headers.set("Content-Type", "application/json")
    L.info(f"RESPONSE GET /v1/historicalLiveScenarios/{request_id} {resp_json}")
    return res, 200


@goe_app.route("/v2/UNIFIEDPORTFOLIOADVICE", methods=["POST"])
@goe_app.route("/v2/unifiedportfolioadvice", methods=["POST"])
@goe_app.route("/v2/unifiedPortfolioAdvice", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "client"),
    )
)
async def svc_goe_unified_portfolio_advice():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /v2/unifiedPortfolioAdvice {request_json}")
    L.info("User is accessing app in UI: GOE API:/v2/unifiedPortfolioAdvice")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    result = await pipe_serverless_controller_run_advisor_engine(req, request_json)
    if isinstance(result, tuple):
        pipePayload, handler = result
    else:
        pipePayload = result
    pipePayload = DictDefault(pipePayload)
    if pipePayload.statusCode in [400, 200]:
        json_data = json.dumps(pipePayload)
        data = await make_response(json_data)
        data.headers.set("Content-Type", "application/json")
        L.info(f"RESPONSE PAYLOAD POST /v2/unifiedPortfolioAdvice {json_data}")
        return data, pipePayload.statusCode
    elif pipePayload and pipePayload.statusCode is None:
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "UnifiedPortfolioAdvice",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        res = handler(goe_response)
        L.info(f"RESPONSE POST /v2/unifiedPortfolioAdvice {res}")
        return res
    else:
        L.info(f"RESPONSE ERROR POST /v2/unifiedPortfolioAdvice {pipePayload}")
        return pipePayload


@goe_app.route("/v3/UNIFIEDPORTFOLIOADVICE", methods=["POST"])
@goe_app.route("/v3/unifiedportfolioadvice", methods=["POST"])
@goe_app.route("/v3/unifiedPortfolioAdvice", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "client"),
    )
)
async def svc_goe_unified_portfolio_advice2():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /v3/unifiedPortfolioAdvice {request_json}")
    L.info("User is accessing app in UI: GOE API:/v3/unifiedPortfolioAdvice")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    result = await pipe_serverless_controller_run_advisor_engine_v2(req, request_json)
    if isinstance(result, tuple):
        pipePayload, handler = result
    else:
        pipePayload = result
    pipePayload = DictDefault(pipePayload)
    if pipePayload.statusCode in [400, 200]:
        json_data = json.dumps(pipePayload)
        data = await make_response(json_data)
        data.headers.set("Content-Type", "application/json")
        L.info(f"RESPONSE PAYLOAD POST /v3/unifiedPortfolioAdvice {json_data}")
        return data, pipePayload.statusCode
    elif pipePayload and pipePayload.statusCode is None:
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "UnifiedPortfolioAdvice2",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        if request.headers.get("version") == "4":
            # Delete 'Wealth Node Prob' from response specific to version 4 of UPA 2 api
            new_goe_reponse = json.loads(goe_response)
            if new_goe_reponse.get("statusCode") != 200:
                res = handler(goe_response)
                return res
            new_goe_reponse["data"] = json.loads(new_goe_reponse["data"])
            if "Wealth Node Prob" in new_goe_reponse["data"]["path_report_mod"]:
                del new_goe_reponse["data"]["path_report_mod"]["Wealth Node Prob"]
            if "Wealth Node Prob" in new_goe_reponse["data"]["path_report"]:
                del new_goe_reponse["data"]["path_report"]["Wealth Node Prob"]
            new_goe_reponse["data"] = json.dumps(new_goe_reponse["data"])
            goe_response = json.dumps(new_goe_reponse)
        res = handler(goe_response)
        L.info(f"RESPONSE POST /v3/unifiedPortfolioAdvice {res}")
        return res
    else:
        L.info(f"RESPONSE ERROR POST /v3/unifiedPortfolioAdvice {pipePayload}")
        return pipePayload


# @goe_app.route("/v3/RUNPIPE", methods=["POST"])
# @goe_app.route("/v3/runpipe", methods=["POST"])
# @goe_app.route("/v3/runPipe", methods=["POST"])
# @authorize(
#     (
#         ("goe", "client-settings", "admin"),
#         ("goe", "client-settings", "view"),
#         ("goe", "client-settings", "client"),
#     )
# )
# async def svc_run_pipe_v3():
#     L = request.vars["L"]

#     request_json = await request.json
#     L.info(f"POST /v3/runPipe {request_json}")
#     L.info("User is accessing app in UI: GOE API:/v3/runPipe")
#     req = {}
#     req["headers"] = request.headers
#     req["remote_addr"] = request.remote_addr
#     req["request_meta_data"] = request.vars["metadata_t"]
#     req["requester_oid"] = request.vars["metadata_d"]["user-id"]
#     result = await pipe_serverless_controller_run_pipe_version3(req, request_json)
#     if isinstance(result, tuple):
#         pipePayload, handler = result
#     else:
#         pipePayload = result
#     pipePayload = DictDefault(pipePayload)
#     if pipePayload.statusCode in [400, 200]:
#         json_payload = json.dumps(pipePayload)
#         data = await make_response(json_payload)
#         data.headers.set("Content-Type", "application/json")
#         L.info(f"RESPONSE PAYLOAD POST /v3/runPipe {json_payload}")
#         return data, pipePayload.statusCode
#     # if payload has no statuscode it means generatePipePayload is False and proceed further for next steps
#     # return json.dumps(pipePayload), 200
#     elif pipePayload.statusCode is None:
#         req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
#         goe_response = MessageToJson(
#             await svc_client.call_queue_based_service(
#                 "goe-service",
#                 "CoreGOE",
#                 rest_pb2.GOERequest(request=json.dumps(pipePayload)),
#                 metadata=request.vars["metadata_t"],
#             ),
#             preserving_proto_field_name=True,
#         )
#         res = handler(goe_response)
#         L.info(f"RESPONSE POST /v3/runPipe {res}")
#         return res


@goe_app.route("/api/goe/createUser", methods=["POST"])
@authorize((("goe", "client-settings", "admin"),))
async def create_user():
    """saves user"""
    L = request.vars["L"]

    L.info("POST Request for /api/goe/createUser")
    request_json = await request.json
    request_meta_data = request.vars["metadata_t"]
    res = await admin.create_user(request_meta_data, request_json)
    return jsonify(res), 200


@goe_app.route("/api/goe/updateUser", methods=["PUT"])
@authorize((("goe", "client-settings", "admin"),))
async def update_user():
    """update user"""
    L = request.vars["L"]

    L.info("POST Request for /api/goe/updateUser")
    request_json = await request.json
    requester_oid = request.vars["metadata_d"]["user-id"]
    request_meta_data = request.vars["metadata_t"]
    res = await admin.update_user(requester_oid, request_meta_data, request_json)
    return jsonify(res), 200


@goe_app.route("/api/goe/getLatestDraft", methods=["GET"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "portfolios", "view"),
        ("goe", "portfolios", "admin"),
    )
)
async def get_latest_draft():
    """Fetches Latest draft"""
    L = request.vars["L"]
    # req = request.args.get("req")
    L.info("GET Request for /api/goe/get_latest_draft")

    requester_oid = request.vars["metadata_d"]["user-id"]
    table = await admin.get_latest_drafts(requester_oid)
    data = await make_response(json.dumps(table))
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/createDraft", methods=["POST"])
@authorize((("goe", "client-settings", "admin"),))
async def create_draft():
    """saves draft"""
    L = request.vars["L"]

    L.info("POST Request for /api/goe/createDraft")
    request_json = await request.json
    requester_oid = request.vars["metadata_d"]["user-id"]
    res = await admin.create_draft(requester_oid, request_json)
    return jsonify(res), 201


@goe_app.route("/api/goe/actuarial/create", methods=["POST"])
@authorize((("goe", "actuarials", "admin"),))
async def actuarial_create():
    """save actuarial data"""
    L = request.vars["L"]

    L.info("POST Request for /api/goe/actuarial/create")
    res = await admin.actuarial_create(request)
    return jsonify(res), 201


@goe_app.route("/api/goe/actuarial/update/<actuarial_id>", methods=["PUT"])
@authorize((("goe", "actuarials", "admin"),))
async def actuarial_update(actuarial_id):
    """save actuarial data"""
    L = request.vars["L"]

    L.info("PUT Request for /api/goe/actuarial/update")
    # user = await getUserFromRequest(request)
    # if(not user):
    #     raise ValueError('Invalid Credentials; User not found.')
    # id = request.params.id
    res = await admin.actuarial_update(request, actuarial_id)
    return jsonify(res), 200


@goe_app.route("/api/goe/actuarial/getAll", methods=["POST"])
@authorize(
    (
        ("goe", "actuarials", "admin"),
        ("goe", "actuarials", "view"),
    )
)
async def actuarial_get_all():
    """get all actuarial data"""
    L = request.vars["L"]
    L.info("POST Request for /api/goe/actuarial/getAll")
    request_json = await request.json
    request_meta_data = request.vars["metadata_t"]
    res = await admin.actuarial_get_all(request_meta_data, request_json)
    return jsonify(res), 200


@goe_app.route("/api/goe/actuarial/getActuarial/<actuarial_id>", methods=["GET"])
@authorize(
    (
        ("goe", "actuarials", "admin"),
        ("goe", "actuarials", "view"),
    )
)
async def actuarial_get(actuarial_id):
    """get actuarial data by id"""
    L = request.vars["L"]

    L.info("POST Request for /api/goe/actuarial/getActuarial")
    request_meta_data = request.vars["metadata_t"]
    res = await admin.actuarial_get(request_meta_data, actuarial_id)

    return jsonify(res), 200


@goe_app.route("/api/goe/actuarial/getAllActuarialFiles/<actuarial_id>", methods=["GET"])
@authorize(
    (
        ("goe", "actuarials", "admin"),
        ("goe", "actuarials", "view"),
    )
)
async def actuarial_get_all_files(actuarial_id):
    """get actuarial data by id"""
    L = request.vars["L"]

    L.info(f"POST Request for /api/goe/actuarial/getAllActuarialFiles/{actuarial_id}")
    request_meta_data = request.vars["metadata_t"]
    res = await admin.actuarial_get(request_meta_data, actuarial_id, inactive=True)

    return jsonify(res), 200


@goe_app.route("/api/goe/actuarial/getNamesWithFilter", methods=["POST"])
@authorize(
    (
        ("goe", "actuarials", "admin"),
        ("goe", "actuarials", "view"),
    )
)
async def actuarial_get_names_with_filter():
    """get all distinct actuarial names"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/actuarial/getNamesWithFilter",
    )
    request_json = await request.json
    res = await admin.actuarial_get_names_with_filter(request_json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/actuarial/getNamesWithCustomFilter", methods=["POST"])
@authorize(
    (
        ("goe", "actuarials", "admin"),
        ("goe", "actuarials", "view"),
    )
)
async def actuarial_get_names_with_custom_filter():
    """get all distinct actuarial names"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/actuarial/getNamesWithCustomFilter",
    )
    request_json = await request.json
    res = await admin.actuarial_get_names_with_custom_filter(request_json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/actuarial/getFileById/<file_id>", methods=["GET"])
@authorize(
    (
        ("goe", "actuarials", "admin"),
        ("goe", "actuarials", "view"),
    )
)
async def actuarial_get_file_by_id(file_id):
    """get all distinct actuarial names"""
    L = request.vars["L"]

    L.info(
        "GET Request for /api/goe/actuarial/getFileById",
    )
    # request_json = await request.json
    request_meta_data = request.vars["metadata_t"]
    res = await admin.actuarial_get_file_by_id(request_meta_data, file_id)
    response = await make_response(res["data"])
    response.headers.set("Content-Type", res["file_type"])
    response.headers.set("Content-Disposition", "attachment", filename=res["file_name"])
    return response


@goe_app.route("/api/goe/config/<user_id>", methods=["GET"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def get_config(user_id):
    L = request.vars["L"]

    L.info(
        "GET Request for /api/goe/config/<user_id>",
    )
    request_meta_data = request.vars["metadata_t"]
    res = await admin.get_config(user_id, request_meta_data)
    response = await make_response(res["data"])
    response.headers.set("Content-Type", res["file_type"])
    response.headers.set("Content-Disposition", "attachment", filename=res["file_name"])
    return response


@goe_app.route("/api/goe/enum/createActuarialStatus", methods=["POST"])
@authorize((("goe", "actuarials", "admin"),))
async def create_actuarial_status():
    """get all distinct actuarial names"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/actuarial/createActuarialStatus",
    )
    request_json = await request.json
    res = await admin.create_actuarial_status(request_json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/enum/createActuarialType", methods=["POST"])
@authorize((("goe", "actuarials", "admin"),))
async def create_actuarial_type():
    """get all distinct actuarial names"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/enum/createActuarialType",
    )
    request_json = await request.json
    res = await admin.create_actuarial_type(request_json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/enum/createCountry", methods=["POST"])
@authorize((("goe", "client-settings", "admin"),))
async def create_country():
    """create country"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/enum/createCountry",
    )
    request_json = await request.json
    res = await admin.create_country(request_json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/enum/createSegment", methods=["POST"])
@authorize((("goe", "client-settings", "admin"),))
async def create_segment():
    """create segment"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/enum/createSegment",
    )
    request_json = await request.json
    res = await admin.create_segment(request_json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/portfolioBundle/getEnums", methods=["GET"])
@authorize(
    (
        ("goe", "portfolios", "admin"),
        ("goe", "portfolios", "view"),
    )
)
async def get_portfolio_bundle_enums():
    """get portfoliobundle enums will returns all countries, segments and portfolioBundleNames"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolioBundle​/getEnums",
    )
    res = await admin.get_portfolio_bundle_enums()
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/portfolioBundle/create", methods=["POST"])
@authorize((("goe", "portfolios", "admin"),))
async def portfolio_bundle_create():
    """create portfoliobundle"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolioBundle/create",
    )
    request_json = await request.json
    requester_oid = request.vars["metadata_d"]["user-id"]
    request_meta_data = request.vars["metadata_t"]
    data = await admin.portfolio_bundle_create(requester_oid, request_meta_data, request_json)
    # data = await make_response(json.dumps(res))
    # data.headers.set("Content-Type", "application/json")
    return jsonify(data), 200


@goe_app.route("/api/goe/portfolio/create", methods=["POST"])
@authorize((("goe", "portfolios", "admin"),))
async def portfolio_create():
    """create portfoliobundle"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolio/create",
    )
    request_json = await request.json
    request_meta_data = request.vars["metadata_t"]
    data = await admin.portfolio_create(request_meta_data, request_json)
    # data = await make_response(json.dumps(res))
    # data.headers.set("Content-Type", "application/json")
    return jsonify(data), 200


@goe_app.route("/api/goe/portfolioBundle/getOne", methods=["POST"])
@authorize(
    (
        ("goe", "portfolios", "admin"),
        ("goe", "portfolios", "view"),
    )
)
async def portfolio_bundle_get_one():
    """get portfoliobundle for a given details"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolioBundle​/getOne",
    )
    request_json = await request.json
    res = await admin.portfolio_bundle_get_one(request_json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/PORTFOLIOBUNDLE/GETPORTFOLIOSBYUSER", methods=["GET"])
@goe_app.route("/portfoliobundle/getportfoliosbyuser", methods=["GET"])
@goe_app.route("/portfolioBundle/getPortfoliosByUser", methods=["GET"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "client"),
    )
)
async def get_portfolio_by_user():
    """get portfoliobundle for a given details"""
    L = request.vars["L"]

    req = {}
    req["headers"] = request.headers
    req["remote_addr"] = request.remote_addr
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]

    L.info("GET /portfolioBundle/getPortfoliosByUser")

    res = await admin.get_portfolio_by_user(req)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    L.info(f"RESPONSE GET /portfolioBundle/getPortfoliosByUser {res}")
    return data, 200


@goe_app.route("/api/goe/portfolioBundle/getAll", methods=["POST"])
@authorize(
    (
        ("goe", "portfolios", "admin"),
        ("goe", "portfolios", "view"),
    )
)
async def portfolio_bundle_get_all():
    """get portfoliobundle for a given details"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolioBundle/getAll",
    )
    request_json = await request.json
    res = await admin.portfolio_bundle_get_all(request_json)
    # data = await make_response(res)
    # data.headers.set("Content-Type", "application/json")
    return jsonify(res), 200


@goe_app.route("/api/goe/portfolio/getAll", methods=["POST"])
@authorize(
    (
        ("goe", "portfolios", "admin"),
        ("goe", "portfolios", "view"),
    )
)
async def portfolio_get_all():
    """get portfolio for a given details"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolio/getAll",
    )
    request_json = await request.json
    res = await admin.portfolio_get_all(request_json)
    # data = await make_response(res)
    # data.headers.set("Content-Type", "application/json")
    return jsonify(res), 200


# @goe_app.route("/api/goe/getUserStatuses", methods=["GET"])
# @authorize(
#     (
#         ("goe", "api", "admin"),
#         ("goe", "api", "view"),
#         # ("goe", "roles", "admin"),
#         # ("goe", "roles", "level_1_user"),
#         # ("goe", "roles", "level_2_user"),
#     )
# )
# async def get_user_statuses():
#     """get user statuses"""
#     L = request.vars["L"]

#     L.info(
#         "POST Request for /api/goe/getUserStatuses",
#
#     )
#     res = await admin.get_user_statuses()
#     data = await make_response(res)
#     data.headers.set("Content-Type", "application/json")
#     return data, 200


# @goe_app.route("/api/goe/updateUserStatus", methods=["POST"])
# @authorize(
#     (
#         ("goe", "api", "admin"), ("goe", "api", "view"),
#         # ("goe", "roles", "admin"),
#         # ("goe", "roles", "level_1_user"),
#     )
# )
# async def update_user_statuses():
#     """get user statuses"""
#     L = request.vars["L"]

#     L.info(
#         "POST Request for /api/goe/updateUserStatus",
#
#     )
#     request_json = await request.json
#     requester_oid = request.vars["metadata_d"]["user-id"]
#     request_meta_data = request.vars["metadata_t"]
#     res = await admin.update_user_statuses(requester_oid, request_meta_data, request_json)
#     data = await make_response(res)
#     data.headers.set("Content-Type", "application/json")
#     return data, 200


@goe_app.route("/api/goe/getUsers", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def get_users():
    """get users"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/getUsers",
    )
    request_json = await request.json
    request_meta_data = request.vars["metadata_t"]
    res = await admin.get_users(request_meta_data, request_json)
    return jsonify(res), 200


@goe_app.route("/api/goe/getUser", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def get_user():
    """get user for a given id"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/getUsers",
    )
    request_json = await request.json
    request_meta_data = request.vars["metadata_t"]
    res = await admin.get_user(request_meta_data, request_json)
    return jsonify(res), 200


@goe_app.route("/api/goe/socialSecurityCalculator", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "admin"),
    )
)
async def social_security_calc():
    """get social security calc"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/socialSecurityCalculator",
    )
    req = {}
    req["headers"] = request.headers
    req["remote_addr"] = request.remote_addr
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    L.info("GOT response")
    L.info(f"POST /api/goe/socialSecurityCalculator {request_json}")
    pipePayload = await social_security_calculator_api(req, request_json)

    if (
        pipePayload.get("isValid") is None
        and pipePayload.get("statusCode") == 200
        and request.headers.get("generatepayloadonly") != "true"
    ):
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "SocialSecurityCalculator",
                rest_pb2.GOERequest(request=json.dumps(pipePayload.get("body"))),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(response)
        status_code = int(response_data["statusCode"])
        if status_code == 200:
            response_data["body"] = json.loads(response_data["data"])
            response_data["body"]["earningListUsed"] = json.loads(response_data["body"]["earningListUsed"])
            response_data["statusCode"] = int(response_data["statusCode"])
            response_data["message"] = "Success"
            del response_data["data"]
    else:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    L.info(f"RESPONSE POST /api/goe/socialSecurityCalculator {pipePayload}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


@goe_app.route("/api/goe/portfolioBundle/getNamesWithFilter", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def portfolio_bundle_get_names_with_filter():
    """get user statuses"""
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolioBundle​/getNamesWithFilter",
    )
    res = await admin.portfolio_bundle_get_names_with_filter(await request.json)
    data = await make_response(res)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/australiademo", methods=["POST"])
async def australia_demo_api():
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/australiademo",
    )

    L.info(f"Request payload {await request.json}")
    request_json = await request.json

    response = await handler.validate_payload(request_json)
    if response.get("isValid") is False:
        L.info(f"Response post validation fail: {response}")
        return {
            "statusCode": 400,
            "errorCode": response.get("errorCode"),
            "message": "Validation Error",
            "body": response.get("body"),
        }, 400
    resp = await handler.get_configs()
    if resp.get("statusCode") != 200:
        return resp, resp.get("statusCode")
    request_json.update(resp)
    response = await handler.main(request_json, request.vars["metadata_t"])
    if response.get("statusCode") == 400:
        final_response = {
            "errorCode": response.get("errorCode"),
            "message": "Validation Error",
            "body": response.get("body"),
            "statusCode": 400,
        }
    else:
        final_response = {"body": response, "message": "success", "statusCode": 200}
    L.info(f"Response post final_response: {final_response}")
    return final_response, final_response.get("statusCode")


@goe_app.route("/runAggRetirementAccounts-H", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_hantz_translator():
    L = request.vars["L"]

    L.info(
        "GET Request for /runAggRetirementAccounts-H",
    )
    L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    pipePayload = await hantz_translator_api(req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "HantzTranslator",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(goe_response)
        status_code = int(response_data["statusCode"])
        response_data["statusCode"] = status_code
        if status_code == 200:
            response_data["body"] = (
                response_data["data"] if response_data["data"] is not None else response_data["data"]
            )
            response_data["statusCode"] = int(response_data["statusCode"])
            response_data["message"] = "Success"
            del response_data["data"]
    L.info(f"RESPONSE GET /runAggRetirementAccounts-H {pipePayload}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


@goe_app.route("/api/goe/replacementincomecalculator", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_replacement_income_calculator():
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/replacementincomecalculator",
    )
    L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    pipePayload = await replacement_income_calculator_api(req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "ReplacementIncomeCalculator",
                req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(response)
        status_code = int(response_data["statusCode"])
        if status_code == 200:
            response_data["body"] = json.loads(response_data["data"])
            response_data["statusCode"] = int(response_data["statusCode"])
            response_data["message"] = "Success"
            del response_data["data"]
    else:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    L.info(f"RESPONSE POST /api/goe/replacementincomecalculator {pipePayload}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


@goe_app.route("/api/goe/fixed_discretionary_calculator", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_fixed_discretionary_calculator():
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/fixed_discretionary_calculator",
    )
    L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    pipePayload = await fixed_discretionary_calculator_api(req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "FixedDiscretionaryCalculator",
                req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(response)
        status_code = int(response_data["statusCode"])
        response_data["statusCode"] = int(response_data["statusCode"])
        if status_code == 200:
            response_data["body"] = json.loads(response_data["data"])
            response_data["message"] = "Success"
            del response_data["data"]
    else:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    L.info(f"RESPONSE POST /api/goe/fixed_discretionary_calculator {pipePayload}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


@goe_app.route("/api/goe/custom_portfolios", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_custom_portfolio_api():
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/custom_portfolios",
    )
    L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    pipePayload = await custom_portfolios_api_payload(req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "CustomPortfolioService",
                req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(response)
        status_code = int(response_data["statusCode"])
        response_data["statusCode"] = int(response_data["statusCode"])
        if status_code == 200:
            response_data["body"] = json.loads(response_data["data"])
            response_data["message"] = "Success"
            del response_data["data"]
    else:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    L.info(f"RESPONSE POST /api/goe/fixed_discretionary_calculator {pipePayload}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


# @goe_app.route("/api/goe-api/goalCalculator", methods=["POST"])
# @goe_app.route("/api/goe-api/goalcalculator", methods=["POST"])
# @authorize(
#     (
#         ("goe", "client-settings", "admin"),
#         ("goe", "client-settings", "view"),
#     )
# )
# async def goe_goal_calculator():
#     L = request.vars["L"]

#     L.info(
#         "POST Request for /goalcalculator",
#     )
#     L.info(f"Request payload {await request.json}")
#     req = {}
#     req["remote_addr"] = request.remote_addr
#     req["headers"] = request.headers
#     req["request_meta_data"] = request.vars["metadata_t"]
#     req["requester_oid"] = request.vars["metadata_d"]["user-id"]
#     request_json = await request.json
#     pipePayload, _ = await goal_calculator_api(req, request_json)
#     response_data = pipePayload
#     status_code = pipePayload.get("statusCode")
#     if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
#         response_data = pipePayload
#         status_code = pipePayload.get("statusCode")
#     elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
#         req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
#         response = MessageToJson(
#             await svc_client.call_queue_based_service(
#                 "goe-service",
#                 "GoalCalculator",
#                 req,
#                 metadata=request.vars["metadata_t"],
#             ),
#             preserving_proto_field_name=True,
#         )
#         response_data = json.loads(response)
#         response_data = convertToCamelCase(response_data)
#         status_code = int(response_data["statusCode"])
#         response_data["statusCode"] = int(response_data["statusCode"])
#         if status_code == 200:
#             response_data["body"] = response_data["data"]
#             response_data["message"] = "Success"
#             del response_data["data"]
#         else:
#             response_data["body"] = response_data["message"]
#             del response_data["message"]

#     else:
#         response_data = pipePayload
#         status_code = pipePayload.get("statusCode")
#     L.info(f"RESPONSE POST /goalcalculator {pipePayload}")
#     data = await make_response(response_data)
#     data.headers.set("Content-Type", "application/json")
#     return data, status_code


@goe_app.route("/GOEforTaxes", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_tax_liability():
    L = request.vars["L"]
    L.info(
        "GET Request for /GOEforTaxes",
    )
    L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    pipePayload = await goe_run_pipe_taxes(req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "TaxLiability",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(goe_response)
        status_code = int(response_data["statusCode"])
        response_data["statusCode"] = status_code
        if status_code == 200:
            response_data = {"body": response_data["data"], "statusCode": status_code, "message": "Success"}
        elif status_code == 400:
            response_data = {
                "body": response_data.get("message", ""),
                "statusCode": status_code,
                "message": "ValidationError",
            }
        elif status_code == 500:
            response_data = {
                "body": response_data.get("message", ""),
                "statusCode": status_code,
                "message": "Internal Server Error",
            }
        # response_data = convertToCamelCase(response_data)

    L.info(f"RESPONSE GET /GOEforTaxes {response_data}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


@goe_app.route("/api/goe/australia_retirement_income", methods=["POST"])
async def australia_retirement_income():
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/australia_retirement_income",
    )

    L.info(f"Request payload {await request.json}")
    request_json = await request.json
    response = await handler.validate_payload(request_json)
    if not response.get("isValid"):
        L.info(f"Response for retirement income {response}")
        return {
            "statusCode": 400,
            "message": "Validation Error",
            "errorCode": response.get("errorCode"),
            "body": response.get("body"),
        }, 400
    response = await handler.get_retirement_income(request_json)
    L.debug(f"Response for retirement income {response}")

    if response.get("isValid") is False:
        final_response = {"message": response.get("message"), "errorType": "validationError", "statusCode": 400}
    else:
        final_response = {"body": response, "message": "success", "statusCode": 200}
    L.info(f"Response post final_response: {final_response}")
    return final_response, final_response.get("statusCode")


# @goe_app.route("/api/goe/goefordecumulation", methods=["POST"])
# @authorize(
#     (
#         ("goe", "client-settings", "admin"),
#         ("goe", "client-settings", "view"),
#     )
# )
# async def goe_for_decumulation():
#     L = request.vars["L"]

#     L.info(
#         "GET Request for /api/goe/goefordecumulation",
#     )
#     L.info(f"Request payload {await request.json}")
#     req = {}
#     req["remote_addr"] = request.remote_addr
#     req["headers"] = request.headers
#     req["request_meta_data"] = request.vars["metadata_t"]
#     req["requester_oid"] = request.vars["metadata_d"]["user-id"]
#     request_json = await request.json
#     pipePayload = await goe_decumulation_api(req, request_json)
#     response_data = pipePayload
#     status_code = pipePayload.get("statusCode")
#     if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
#         response_data = pipePayload
#         status_code = pipePayload.get("statusCode")
#     elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
#         req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
#         goe_response = MessageToJson(
#             await svc_client.call_queue_based_service(
#                 "goe-service",
#                 "GoeForDecumulation",
#                 rest_pb2.GOERequest(request=json.dumps(pipePayload)),
#                 metadata=request.vars["metadata_t"],
#             ),
#             preserving_proto_field_name=True,
#         )
#         response_data = json.loads(goe_response)
#         status_code = int(response_data["statusCode"])
#         response_data["statusCode"] = status_code
#         if status_code == 200:
#             response_data.update({"body": convertToCamelCase(response_data["data"]), "message": "Success"})
#         elif status_code == 400:
#             response_data.update({"body": response_data["message"], "message": "ValidationError"})
#         if "data" in response_data:
#             del response_data["data"]
#         if "errorCode" in response_data:
#             response_data["errorCode"] = int(response_data["errorCode"])

#     L.info(f"RESPONSE POST /api/goe/goefordecumulation {response_data}")
#     data = await make_response(response_data)
#     data.headers.set("Content-Type", "application/json")
#     return data, status_code


@goe_app.route("/api/goe/portfolio_upload_admin", methods=["POST"])
async def portfolio_upload_admin():
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/portfolio_upload_admin",
    )

    L.info(f"Request payload {await request.json}")
    response = await admin.portfolio_upload(request)
    if response.get("isValid"):
        status_code = 200
        response = {"statusCode": status_code, "body": response.get("response"), "message": "success"}
    else:
        status_code = 400
        response = {"statusCode": status_code, "body": response.get("message"), "message": "validationError"}
    data = await make_response(response)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


@goe_app.route("/api/goe/upload_file", methods=["POST"])
async def upload_file():
    L = request.vars["L"]

    L.info(
        "POST Request for /api/goe/upload_file",
    )

    L.info(f"Request payload {await request.json}")
    response = await admin.upload_file(request)
    data = await make_response(response)
    data.headers.set("Content-Type", "application/json")
    return data, 200


@goe_app.route("/api/goe/api_end_point_list", methods=["GET"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_api_end_points():
    L = request.vars["L"]

    L.info(
        "GET Request for /api/goe/api_end_point_list",
    )
    L.info(f"Request payload {await request.json}")
    resp = await admin.goe_api_end_points()
    return resp


@goe_app.errorhandler(GoeException)
async def handle_goe_error(e):
    """Return json error for GoeException errors defined in errors.py .
    This will avoid having to try/catch Errors in all endpoints, returning
    correct JSON response with associated HTTP 400 Status
    """
    L = request.vars["L"]
    L.info("Goe api failed")
    data = {"message": e.messages, "name": e.name, "statusCode": e.code}
    if hasattr(e, "errors"):
        data.update({"errors": e.errors})
    return jsonify(data), e.code


@goe_app.errorhandler(Exception)
async def handle_error(exception):
    """Return json error for errors not handled in handle_goe_error fn.
    This will avoid having to try/catch Errors in all endpoints, returning
    correct JSON response with associated HTTP 500 Status
    """
    L = request.vars["L"]
    L.error(exception)

    L.error(traceback.format_exc())
    msg = jsonify({"message": str(exception)})

    if isinstance(exception, HTTPException):
        return msg, exception.code

    return msg, 500


@goe_app.route("/api/goe-api/goalSimulationEngine", methods=["POST"])
@goe_app.route("/api/goe-api/goalsimulationengine", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def goe_goal_simulaiton_engine():
    L = request.vars["L"]
    L.info(
        "GET Request for /api/goe-api/goalSimulationEngine",
    )
    L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    pipePayload = await goe_goal_simulation_engine_payload(req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "SimulationEngine",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(goe_response)
        status_code = int(response_data["statusCode"])
        response_data["statusCode"] = status_code
        if status_code == 200:
            response_data = {"body": response_data["data"], "statusCode": status_code, "message": "Success"}
        elif status_code == 400:
            response_data = {
                "body": response_data.get("message", ""),
                "statusCode": status_code,
                "message": "ValidationError",
            }
        elif status_code == 500:
            response_data = {
                "body": response_data.get("message", ""),
                "statusCode": status_code,
                "message": "Internal Server Error",
            }
        # response_data = convertToCamelCase(response_data)

    L.info(f"RESPONSE GET /api/goe-api/goalSimulationEngine {response_data}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code


@goe_app.route("/api/goe/decumulation_lookup", methods=["POST"])
@authorize(
    (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
    )
)
async def decumulation_lookup():
    L = request.vars["L"]
    L.info(
        "GET Request for /api/goe/decumulation_lookup",
    )
    L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.remote_addr
    req["headers"] = request.headers
    req["request_meta_data"] = request.vars["metadata_t"]
    req["requester_oid"] = request.vars["metadata_d"]["user-id"]
    request_json = await request.json
    goe_response = MessageToJson(
        await svc_client.call_queue_based_service(
            "goe-service",
            "GoeDDataLookup",
            rest_pb2.GOERequest(request=json.dumps(request_json)),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    response_data = json.loads(goe_response)
    L.info(f"RESPONSE GET /api/goe/decumulation_lookup {response_data}")
    data = await make_response(response_data)
    data.headers.set("Content-Type", "application/json")
    return data


@goe_app.route("/api/goe/decumulation_upload_file", methods=["POST"])
async def goe_dec_upload():
    try:
        tmp = tempfile.NamedTemporaryFile()
        file_name = tmp.name
        print(file_name)
        header = "currentYear,retirementAge,planningAge,currentAge,gender,currentExpenditures,initialInvestment,guaranteedIncome,riskProfile,annuityAllocation,nextYearWealth,annuityPay"
        async with timeout(5000):
            with open(file_name, "wb") as f:
                is_first_line = True
                async for data in request.body:
                    if is_first_line:
                        is_first_line = False
                        data_str = data.decode("utf-8")
                        if data_str.find(header) >= 0:
                            x = data_str[data_str.find(header) :]
                            f.write(x.encode("utf-8"))
                        continue
                    x = data
                    f.write(data)
    except Exception as e:
        return {"data": str(e), "statusCode": 400, "message": "Success"}, 400
    L = request.vars["L"]
    fw = uip_files.Files()
    file = fw.WriteFile(
        file_name="goe_decumulation_lookup",
        folder="decumulationFiles",
        file_type="text/csv",
        service_name=None,
        data=open(file_name, "rb").read(),
    )
    print(file_name)
    L.info("new file created", file)
    get_dec_lookup = MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetDocument(
            request=rest_pb2.GetDocumentRequest(
                collection_name="goe-settings",
                document_id="decumulation_look_up",
                version=request.args.get("version", None),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
        sort_keys=True,
    )
    body = Struct()
    get_dec_lookup = json.loads(get_dec_lookup)
    get_dec_lookup["files"].insert(0, file)
    get_dec_lookup["files"][0].update({"enabled": True})
    new_data = {"document_id": get_dec_lookup["_id"], "document": json.dumps({"files": get_dec_lookup["files"]})}
    body.update(new_data)
    MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateDocument(
            request=rest_pb2.UpdateDocumentRequest(
                collection_name="goe-settings",
                payload=body,
                comment="App updated.",
                document_id="decumulation_look_up",
                type=request.args.get("type"),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    # L.info(res)
    return file
