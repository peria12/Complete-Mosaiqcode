import asyncio
import json
import string
import datetime
import io
import pandas as pd

import random
import os

import rest_pb2
import rest_pb2_grpc

import uip_grpc


from collections import abc
from collections import OrderedDict
from collections import Counter

from uip_email import EmailMsg

from sqlalchemy import select, func, desc, asc, distinct, or_
from sqlalchemy import insert, update
from sqlalchemy.exc import IntegrityError

from quart import request
from goelib import DbAccess
from goelib import GenerateTables

from goelib.auth.lib import Roles

from goelib.api.shared.user_utils import (
    UserStatus,
    get_users_data,
    get_user_from_oid,
    get_oid_by_email,
    has_greater_precision,
)

from goelib.errors import BadRequest, RecordDoesNotExist, BadRequestError, Unauthorized, ValidationError

from transcoder_libs import process_post_data, check_access, download, process_files


from google.protobuf.json_format import MessageToJson, MessageToDict, ParseDict
from google.protobuf.struct_pb2 import Struct

from goelib.api.shared.user_utils import get_enums

from goelib.api.shared.user_utils import cast_doc_object

from goelib.api.shared.common import DictDefault, get_meta_data_for_tables, actuarial_get_one

db_con = DbAccess()
grpc_channels = uip_grpc.GRPC(async_mode=True)


async def dump_data_to_database(decumulation_data):
    decumulation_statu = False
    chunk_size = 500
    chunk_list_size = len(decumulation_data) // chunk_size
    try:
        decumulation_data_list = [
            decumulation_data[i : i + chunk_size] for i in range(0, len(decumulation_data), chunk_size)
        ]
        db = await db_con.get_access()
        tables = await get_meta_data_for_tables(["decumulation_lookup"])
        decumulation_lookup = tables["decumulation_lookup"]
        db = await db_con.get_writer_access()
        engine = db.conn.engine
        import sqlalchemy as sa

        delete_dt_stmt = sa.text("DELETE FROM decumulation_lookup")
        async with engine.begin() as conn:
            await conn.execute(delete_dt_stmt)
        db = await db_con.get_writer_access()
        engine = db.conn.engine
        decumulation_lookup_columns = decumulation_lookup.columns.keys()
        for decumulation_data_chunk in decumulation_data_list:
            async with engine.begin() as conn:
                try:
                    decumulation_stmt = (
                        insert(decumulation_lookup)
                        .values(decumulation_data_chunk)
                        .returning(*decumulation_lookup.columns)
                    )
                    cursor = await conn.execute(decumulation_stmt)
                    decumulation_info = cursor.fetchall()
                    if not decumulation_info:
                        BadRequest.messages = (
                            f"There seems an issue portfolio insert seems failed portfolio_data: {decumulation_info}"
                        )
                        raise BadRequest
                except IntegrityError as e:
                    BadRequest.messages = e.orig.args[0].split(":")[1].split("\n")[0].replace('"', "")
                    raise BadRequest
        decumulation_statu = True
    except:
        decumulation_statu = False

    return decumulation_statu


async def table_mapping(item):
    if not item:
        return {}
    item = DictDefault(item)
    db = await db_con.get_writer_access()

    tables = await get_meta_data_for_tables(
        ["country", "segment", "actuarial_type", "actuarial_status", "portfolio_bundle"]
    )
    Country = tables["country"]
    Segment = tables["segment"]
    ActuarialType = tables["actuarial_type"]
    ActuarialStatus = tables["actuarial_status"]
    portfolio_bundle = tables["portfolio_bundle"]
    if "countryId" in item:
        stmt = select(Country).where(Country.c.id == int(item.countryId))
        country_result = await db.get_data(stmt, as_dataframe=True)
        item["country"] = country_result.name[0] if (country_result is not None or not country_result.empty) else ""
        del item["countryId"]
    if "segmentId" in item:
        stmt = select(Segment).where(Segment.c.id == int(item.segmentId))
        segment_result = await db.get_data(stmt, as_dataframe=True)
        item["segment"] = segment_result.name[0] if (segment_result is not None or not segment_result.empty) else ""
        del item["segmentId"]
    if "typeId" in item:
        stmt = select(ActuarialType).where(ActuarialType.c.id == int(item.typeId))
        actuarial_type_result = await db.get_data(stmt, as_dataframe=True)
        item["type"] = (
            actuarial_type_result.name[0]
            if (actuarial_type_result is not None or not actuarial_type_result.empty)
            else ""
        )
        del item["typeId"]
    if "statusId" in item:
        stmt = select(ActuarialStatus).where(ActuarialStatus.c.id == int(item.statusId))
        actuarial_status_result = await db.get_data(stmt, as_dataframe=True)

        item["status"] = (
            actuarial_status_result.name[0]
            if (actuarial_status_result is not None or not actuarial_status_result.empty)
            else ""
        )
        del item["statusId"]
    if "portfolioBundleId" in item:
        stmt = select(portfolio_bundle).where(portfolio_bundle.c.id == int(item.portfolioBundleId))
        portfolio_result = await db.get_data(stmt, as_dataframe=True)
        item["portfolioBundle"] = (
            portfolio_result.name[0] if (portfolio_result is not None or not portfolio_result.empty) else ""
        )
        del item["portfolioBundleId"]

    return item


async def user_change_notification(item, operation):
    _item = DictDefault(item)
    if not item:
        return {}
    item = cast_doc_object(DictDefault(_item["app_settings"]["goe"]["client-settings"]))
    item = await table_mapping(item)
    data = OrderedDict()
    data["name"] = _item.name
    data["contactName"] = item.contactName
    data["contactId"] = item.contactId
    data["email"] = _item.email
    data["phone"] = item.phone
    data["notes"] = item.notes
    data["config"] = item.config.configuration
    data["updatedBy"] = _item.__meta.user
    data["createdBy"] = _item.createdBy
    data["createdAt"] = _item.createdAt
    data["country"] = item.country
    data["segment"] = item.segment
    data["status"] = item.status.name
    data["portfolioBundle"] = item.portfolioBundle

    # Portfolio Configuration
    data["Portfolio Configuration"] = "isaheader"
    data["Distribution Channel"] = item.config.channelName
    data["Using Ft Portfolio"] = item.config.portfolioConfig.usingFtPortfolio
    data["Levels Of Risk Profile"] = item.config.portfolioConfig.level
    data["Conservative Risk Profiles"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.conservativeRiskProfiles)
        if item.config.portfolioConfig.portfolioConfig.conservativeRiskProfiles
        else ""
    )
    data["Moderate Risk Profiles"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.moderateRiskProfiles)
        if item.config.portfolioConfig.portfolioConfig.moderateRiskProfiles
        else ""
    )
    data["Aggressive Risk Profiles"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.aggressiveRiskProfiles)
        if item.config.portfolioConfig.portfolioConfig.aggressiveRiskProfiles
        else ""
    )
    data["Decumulation Scenario Goals"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.decumulationScenarioProfiles)
        if item.config.portfolioConfig.portfolioConfig.decumulationScenarioProfiles
        else ""
    )
    data["Portfolios for Short Term Goals"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.shortTermGoalProfiles)
        if item.config.portfolioConfig.portfolioConfig.shortTermGoalProfiles
        else ""
    )
    data["Short Term Goal Tenure"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.shortTermGoalTenure)
        if item.config.portfolioConfig.portfolioConfig.shortTermGoalTenure
        else ""
    )
    data["Portfolios for Short Term Goals Retirement"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalProfiles)
        if item.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalProfiles
        else ""
    )
    data["Short Term Retirement Goal Tenure"] = (
        ",".join("{0}".format(n) for n in item.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalTenure)
        if item.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalTenure
        else ""
    )
    # Allocation Configuration
    data["Allocation Configuration"] = "isaheader"
    data["Reallocation Frequency"] = item.config.allocationConfiguration.reallocationFrequency
    data["Reallocation (Yearly)"] = item.config.allocationConfiguration.reallocationDatesByFrequency.yearly
    data["Reallocation (Half Yearly)"] = item.config.allocationConfiguration.reallocationDatesByFrequency.halfyearly
    data["Reallocation (Quarterly)"] = item.config.allocationConfiguration.reallocationDatesByFrequency.quarterly
    allow_config = DictDefault(
        dict([(j.get("name"), j.get("value")) for j in item.config.allocationConfiguration.reallocationTriggers])
    )
    data["When the user Retakes the RTQ"] = allow_config.newRiskProfile
    data["When the user changes the investment Tenure"] = allow_config.changesInvestmentTenure
    data["When the user re-prioritizes a goal"] = allow_config.changesInvestmentTenure
    data["When risk indicator flashes"] = allow_config.rePrioritizesGoal
    data["When is new goal"] = allow_config.newGoal
    data["When the client wants to reallocate"] = allow_config.wantsToReallocate
    # Goal Priority
    data["Goal Priority"] = "isaheader"

    data["Levels of goal priority"] = len(item.config.goalPriority.probabilityLevels)
    goal_config = DictDefault(
        dict([(j.get("name"), j.get("value")) for j in item.config.goalPriority.probabilityLevels])
    )
    data["Need"] = goal_config.get("need", "")
    data["Want"] = goal_config.get("want", "")
    data["Wish"] = goal_config.get("wish", "")
    data["Wish"] = goal_config.get("wish", "")
    data["Dream"] = goal_config.get("dream", "")
    data["Desire"] = goal_config.get("desire", "")
    # Loss Threshold
    data["Loss Threshold"] = "isaheader"
    data["Loss Threshold Floor"] = item.config.goalPriority.lossThreshold
    data["Loss Threshold Probability"] = item.config.goalPriority.lossThresholdProbability
    data["Downside Protection"] = item.config.goalPriority.generalSettings.downsideProtection
    data["Accumulation Need"] = item.config.goalPriority.lossthresholdValues[0]["accumulation"]
    data["Decumulation Need"] = item.config.goalPriority.lossthresholdValues[0]["decumulation"]
    data["Accumulation Want"] = item.config.goalPriority.lossthresholdValues[1]["accumulation"]
    data["Decumulation Want"] = item.config.goalPriority.lossthresholdValues[1]["decumulation"]
    data["Accumulation Wish"] = item.config.goalPriority.lossthresholdValues[2]["accumulation"]
    data["Decumulation Wish"] = item.config.goalPriority.lossthresholdValues[2]["decumulation"]
    data["Accumulation Dream"] = item.config.goalPriority.lossthresholdValues[2]["accumulation"]
    data["Decumulation Dream"] = item.config.goalPriority.lossthresholdValues[2]["decumulation"]
    data["Accumulation Desire"] = item.config.goalPriority.lossthresholdValues[3]["accumulation"]
    data["Decumulation Desire"] = item.config.goalPriority.lossthresholdValues[3]["decumulation"]
    # General Settings
    data["General Settings"] = "isaheader"
    data["Unrealistic Probability"] = item.config.goalPriority.generalSettings.unrealisticProbability
    data["Swing Constraint"] = item.config.goalPriority.generalSettings.swingConstraint
    data["Swing Constraint Number"] = item.config.goalPriority.generalSettings.swingConstraintNumber
    data[
        "Safeguard Achieve Wealth in Last Year"
    ] = item.config.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear
    data["Grid Frequency"] = item.config.goalPriority.generalSettings.gridFrequency
    data["Recommend Tenure"] = item.config.goalPriority.generalSettings.recommendTenure
    data["Recommend Top-up Infusion"] = item.config.goalPriority.generalSettings.recommendTopUpInfusion
    data["Run Backward Pass Only"] = item.config.goalPriority.generalSettings.backPassOnly
    data[
        "Do you want to split your wealth across goal optimally"
    ] = item.config.goalPriority.generalSettings.splitWealthAcrossGoalOptimally
    data["Inflation"] = item.config.goalPriority.generalSettings.inflation
    data["Inflation Measures for Infusions"] = item.config.goalPriority.generalSettings.inflationMeasureForInfusions
    data["Max Age"] = item.config.goalPriority.generalSettings.maxAge
    data["Adjust Fees"] = item.config.goalPriority.generalSettings.adjustFees
    data["FEE ADJUSTER (ANNUAL FEE IN BPS)"] = item.config.goalPriority.generalSettings.annualInBPS
    data["Wealth Path"] = item.config.goalPriority.generalSettings.wealthPath
    data["Wealth Path Probability"] = item.config.goalPriority.generalSettings.wealthPathProbability
    # DEFAULT PROBABILITIES
    data["DEFAULT PROBABILITIES"] = "isaheader"
    data["ADDITIONAL WEALTH PATHS"] = item.config.goalPriority.generalSettings.additionalWealthPaths
    data["PESSIMISTIC PATH PROBABILITY"] = item.config.goalPriority.generalSettings.pessimisticPathProbability
    data["OPTIMISTIC PATH PROBABILITY"] = item.config.goalPriority.generalSettings.optimisticPathProbability
    # Probability Thresholds
    data["PROBABILITY THRESHOLDS"] = "isaheader"
    data["MIN PROBABILITY[0]"] = item.config.goalPriority.probabilityThresholds[0].labelValue
    data["MIN PROBABILITY[1]"] = item.config.goalPriority.probabilityThresholds[1].labelValue
    data["MIN PROBABILITY[2]"] = item.config.goalPriority.probabilityThresholds[2].labelValue
    data["MAX PROBABILITY[0]"] = item.config.goalPriority.probabilityThresholds[0].value
    data["MAX PROBABILITY[1]"] = item.config.goalPriority.probabilityThresholds[1].value
    data["MAX PROBABILITY[2]"] = item.config.goalPriority.probabilityThresholds[2].value
    data["THRESHOLD[0]"] = item.config.goalPriority.probabilityThresholds[0].val
    data["THRESHOLD[1]"] = item.config.goalPriority.probabilityThresholds[1].val
    data["THRESHOLD[2]"] = item.config.goalPriority.probabilityThresholds[2].val

    # Performance
    data["Performance"] = "isaheader"

    data["Risk Overlay"] = item.config.goalPriority.performance.riskOverlay
    if item.config.goalPriority.performance.riskIndicator:
        data["Risk Indicator UpperLimit - Lowerlimit"] = (
            f"{item.config.goalPriority.performance.riskIndicator.lower}"
            + "-"
            + f"{item.config.goalPriority.performance.riskIndicator.upper}"
        )
    data["IRR For Range Adjustment"] = item.config.goalPriority.performance.irrForRangeAdjustment
    data["Sigma"] = item.config.goalPriority.performance.sigma
    data["Alternative Sigma"] = item.config.goalPriority.performance.alternativeSigma
    data["Nodes Per Sd"] = item.config.goalPriority.performance.nodesPerSd
    data["IRR for Performance Threshold"] = item.config.goalPriority.performance.irrPerformanceThreshold
    data["Long Tenure Threshold"] = item.config.goalPriority.performance.longTenureThreshold
    data["Alternated Nodes Per Sd"] = item.config.goalPriority.performance.altNodesPerSd
    # Miscellaneous
    data["Miscellaneous"] = "isaheader"
    data["Configuration"] = item.config.configuration
    data["Channel Name"] = item.config.channelName
    # Actuarials
    data["Actuarials"] = "isaheader"
    for i in range(len(item.config.goalPriority.generalSettings.actuarials)):
        data["Actuarial name [{0}]".format(i)] = item.config.goalPriority.generalSettings.actuarials[i].name
        data["Actuarial type [{0}]".format(i)] = item.config.goalPriority.generalSettings.actuarials[i].type
    data["DE-RISK"] = "isaheader"
    data[
        "TENURE FOR SHORT TERM RETIREMENT GOALS (IN YEARS TO RETIREMENT)"
    ] = f"{item.config.portfolioConfig.shortTermRetirementGoalTenure} - {item.config.portfolioConfig.shortTermRetirementGoalTenureUnengaged }"
    # data["PORTFOLIOS FOR SHORT TERM RETIREMENT GOALS"] = item.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalProfiles
    data["AGGREGATED RETIREMENT"] = "isaheader"
    data["AGGREGATED RETIREMENT ACCOUNTS"] = item.config.goalPriority.generalSettings.aggregatedRetirementAccounts
    data["PORTFOLIO MAPPING TABLE"] = item.config.goalPriority.generalSettings.PortfolioMappingTable
    data["CONTRIBUTION RATE"] = item.config.goalPriority.generalSettings.contributionRate
    data["FIXED BENEFITS"] = item.config.goalPriority.generalSettings.fixedBenefits
    data["CALCULATE GOALS"] = item.config.goalPriority.generalSettings.calculateGoals

    # GOE FOR DECUMMULATION - Guardrails
    data["GOE FOR DECUMMULATION - Guardrials"] = "isaheader"
    for derisk_idx, derisk in enumerate(item.config.goalPriority.generalSettings.derisking):
        data[f"DE-RISKING - AGE [{derisk_idx}]"] = derisk.age
    for derisk_idx, derisk in enumerate(item.config.goalPriority.generalSettings.derisking):
        data[f"DE-RISKING - PORTFOLIO [{derisk_idx}]"] = derisk.portfolio
    data["ADDITIONAL CONSUMPTION CAP"] = item.config.decummulationFiles.additionalConsumptionCap
    data["MINIMUM CONSUMPTION FLOOR"] = item.config.decummulationFiles.minConsumptionFloor
    data["MAXIMUM EQUITY EXPOSURE"] = item.config.decummulationFiles.maxEquityExposure
    data["AGE BASED ANNUITY CAP"] = item.config.decummulationFiles.ageBasedAnnuityCap
    data["AGE BASED GI% CAP"] = item.config.decummulationFiles.ageBasedGICap
    data["GOE FOR DECUMMULATION - Guaranteed Income %"] = "isaheader"
    for gip_idx, gip in enumerate(item.config.goalPriority.guaranteedIncomePercent):
        data[f"MIN GI%[{gip_idx}]"] = gip.min

    # GOE FOR DECUMMULATION - PLanning Age
    data["GOE FOR DECUMMULATION - Planning Age"] = "isaheader"
    data["USE A FIXED PLANNING AGE"] = item.config.goalPriority.generalSettings.useAFixedPlanningAge
    if item.config.goalPriority.generalSettings.useAFixedPlanningAge:
        data["PLANNING AGE"] = item.config.goalPriority.generalSettings.planningAge
    else:
        data["MINIMUM PLANNING AGE"] = item.config.goalPriority.generalSettings.minimumPlanningAge
    data["MINIMUM ANNUITISATION AMOUNT"] = item.config.goalPriority.generalSettings.minimumAnnuitisationAmount
    data["TYPE OF MORTALITY TABLE"] = item.config.goalPriority.generalSettings.typeOfMortalityTable
    data[
        "SOCIAL SECURITY FILING AGE"
    ] = f"{item.config.goalPriority.generalSettings.socialSecurityFilingAge.maximumSocialSecurityFilingAge} - {item.config.goalPriority.generalSettings.socialSecurityFilingAge.minimumSocialSecurityFilingAge}"
    # Tax
    data["Tax"] = "isaheader"
    for i in range(len(item.config.goalPriority.generalSettings.taxActuarialData)):
        data["DATA TABLE DATA [{0}]".format(i)] = item.config.goalPriority.generalSettings.taxActuarialData[i].name
        data["DATA TABLE DATA [{0}]".format(i)] = item.config.goalPriority.generalSettings.taxActuarialData[i].type

    data["LY PACKAGE ID"] = item.config.goalPriority.generalSettings.LYPackageID
    data["TOTAL ALLOWED CONTRIBUTION"] = item.config.goalPriority.generalSettings.totalAllowedContribution
    data[
        "TOTAL ALLOWED CATCHUP CONTRIBUTION"
    ] = item.config.goalPriority.generalSettings.totalAllowedCatchupContribution
    data["LIFEYIELD ENVIRONMENT"] = item.config.goalPriority.generalSettings.lifeYieldEnvironment
    data["SIMULATION TYPE"] = item.config.goalPriority.generalSettings.simulationType

    # UPA
    data["UPA"] = "isaheader"
    data["Goal Modification"] = "isaheader"
    if item.config.goalPriority.goalModification:
        for gm in item.config.goalPriority.goalModification:
            data[f"Goal Modification - {gm['name']}"] = gm["value"]
    data["Mode"] = "isaheader"
    data["USE CASE"] = item.config.goalPriority.generalSettings.useCase
    data["MAXIMUM GOAL MODIFICATION PER ITERATION"] = item.config.goalPriority.generalSettings.goalDropStep
    data["Goal Drop Step Size"] = item.config.goalPriority.generalSettings.goalDropStepSize
    data["Max Tenure Goal Drop Limit"] = item.config.goalPriority.generalSettings.maxTenureDropLimit
    return data


async def send_db_change_notification(request_meta_data, table_name, new_entry, old_entry=None, operation="CREATE"):
    try:
        L = request.vars["L"]

        os.environ["SEND_DB_NOTIFICATION"] = "True"
        email_config = MessageToJson(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetCollections(
                request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        email_config = list(
            filter(lambda x: x.get("name") == "goe-settings", json.loads(json.loads(email_config)["collections"]))
        )
        email_config = list(filter(lambda x: x.get("_id") == "email-config", email_config[0]["documents"]))
        if not email_config:
            raise ValueError("Email config is missing")
        email_config = email_config[0]
        if not os.environ.get("SEND_DB_NOTIFICATION"):
            return None
        name = dict(request_meta_data).get("user-name")
        if operation == "UPDATE" and table_name in ["actuarial", "portfolio_bundle"]:
            # audit_table = f"{table_name}_trail"
            stmt = f"""SELECT * FROM trail."{table_name}_trail"
                where "id" = {new_entry.get('id')}
                order by "createdAt" desc
                limit 1"""
            db = await db_con.get_writer_access()
            result = await db.get_data(stmt, as_dict=True)

            old_entry = result[0] if result is not None else None

        old_entry = {} if old_entry is None else old_entry
        content = f"""Hi,<br/><br/>
        Someone just made a db update on {table_name} table. <br/><br/>
        User: {name}<br/><br/>
        Date: {datetime.datetime.isoformat(datetime.datetime.now())} [UTC] <br/>
        Type of change: {operation} <br/> <br/>"""
        if table_name == "user":
            doc_history = MessageToJson(
                await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetDocumentHistory(
                    request=rest_pb2.DocumentHistoryRequest(
                        collection_name="users",
                        document_id=new_entry["_id"],
                    ),
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
                sort_keys=True,
            )
            doc_history = json.loads(doc_history)
            if "history" in doc_history and doc_history["history"]:
                createdBy, createdAt = (
                    doc_history["history"][0]["__meta"]["user"],
                    doc_history["history"][0]["__meta"]["timestamp"],
                )
                new_entry["createdBy"] = createdBy
                new_entry["createdAt"] = createdAt
                if old_entry:
                    old_entry["createdBy"] = createdBy
                    old_entry["createdAt"] = createdAt
            new_entry = await user_change_notification(new_entry, None)
            if operation == "UPDATE":
                old_entry = await user_change_notification(old_entry, operation)
        if table_name == "actuarial":
            new_entry = await table_mapping(new_entry)
            del new_entry["createdBy"]
            if operation == "UPDATE":
                old_entry = await table_mapping(old_entry)
                del old_entry["performedOn"]
                del old_entry["createdBy"]
        if table_name == "portfolio_bundle":
            new_entry = await table_mapping(new_entry)
        html_msg = """
            <!DOCTYPE html>
            <html><head>
            <style>
            table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            }
            td, th {
            border: 1px solid;
            text-align: left;
            padding: 8px;
            }
            </style>"""
        if new_entry:
            html_table = """<table>"""
            html_table += (
                "<tr style='background-color:#eeeeee'><th>Column</th><th>New Value</th><th>Old Value</th></tr>"
            )
            for col in new_entry.keys():
                if new_entry.get(col, "") == "isaheader":
                    html_table += f"""<tr><th colspan="3" style='background-color:#eeeeee'>{col}</th></tr>"""
                elif new_entry.get(col, "") != old_entry.get(col, ""):
                    html_table += f"""<tr style='background-color:#ffffff'><td>{col}</td>
                        <td>{new_entry.get(col, "") or "" }</td>
                        <td>{old_entry.get(col, "") or "" }</td></tr>"""
                else:
                    html_table += (
                        f"""<tr style='background-color:#dddddd'><td>{col}</td><td>{new_entry.get(col, "") or  "" }"""
                    )
                    html_table += f"""</td><td>{old_entry.get(col, "") or "" }</td></tr>"""
            html_table += """</table>"""

        msg = f"""
            </head>
                <body>
                    {content}
                    {html_table}
                </body>
            </html>"""

        email = EmailMsg(
            from_addr="ftis-no-reply@franklintempleton.com",
            to_addr=",".join(email_config.get("recipients", [])),
            cc_addr=",".join(email_config.get("cc", [])),
            subject=f" GOE {table_name} update activity",
            content=html_msg + msg,
        )

        email.send()
    except KeyError:
        L.error("Error in reading object and send_db_change_notification failed", exc_info=True)
        return
    except Exception:
        L.error("Error in send_db_change_notification", exc_info=True)
        return


async def get_latest_drafts(requester_oid):
    """Get latest record on created At desc

    Args:
        request (object): request object

    Returns:
        str: json results
    """
    # admin apis has to get email from request meta data
    user_id = requester_oid
    if not user_id:
        ValidationError.messages = "User not found."
        raise ValidationError
    tables = await get_meta_data_for_tables(["draft"])
    Draft = tables["draft"]

    stmt = (
        select(func.row_to_json(Draft.table_valued()).label("drafts"))
        .where(Draft.c.userId == user_id)
        .order_by(desc(Draft.c.createdAt))
        .limit(1)
    )
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    if result is None or result.empty:
        return {}
    result = json.loads(result.to_json(orient="records", date_format="iso"))
    if not result or len(result) < 1:
        return result
    user = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
            request=rest_pb2.UserInfoRequest(user_ids=[user_id]),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    result[0]["drafts"]["createdBy"] = user[user_id]
    result[0]["drafts"]["data"] = json.loads(result[0]["drafts"]["data"])
    return result[0]["drafts"]


async def get_user_from_db(request_meta_data, oid):
    """Get User from document db for a given Oid/docid

    Args:
        req (request object): Request object passed
        oid (str): oid of the user to search in document db.

    Raises:
        ValidationError: Invalid id attribute passed.
        ValidationError: no user found for id
        ValidationError: no goe user profile configured for this user

    Returns:
        [type]: [description]
    """
    if not isinstance(oid, str):
        ValidationError.messages = f"Invalid id attribute passed. Id should be str: Got {oid}"
        raise ValidationError

    # now get GOE app settings for the above users
    users = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
            request=rest_pb2.AppUserSettingsRequest(user_ids=[oid]),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )

    if oid not in users:
        ValidationError.messages = f"No user found with user_id: {oid}"
        raise ValidationError

    return users[oid]


async def get_users_from_db(request_meta_data):
    """Get all goe related users from document db.

    Raises:
        ValidationError: "no users found for goe"

    Returns:
        [dict]: users data returned. {"data": results, "count": len(results)}
    """
    L = request.vars["L"]

    # list of all access tuples that you want
    # users for
    req = {
        "join": "or",
        "access": [
            ["goe", "client-settings", "client"],
        ],
    }

    goe_users = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUsersWithAccess(
            request=rest_pb2.JSON(str=json.dumps(req)),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )

    if not goe_users:
        L.info("Either there are no user collection are you dont have rights to see")
        return {"count": 0, "data": []}

    # now get GOE app settings for the above users
    users = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
            request=rest_pb2.AppUserSettingsRequest(user_ids=list(goe_users.keys())),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )

    if users.get("error"):
        raise Exception("Failed to read users: " + users.get("error"))

    if not users:
        L.info("No GOE settings found for requested users")
        return {"count": 0, "data": []}

    users = [users[user] for user in users]
    users = sorted(users, key=lambda x: x["__meta"]["timestamp"])
    return await get_users_data(users, includeCountriesAndSegments=True)


async def generate_password():
    """basic Password generator of length 8 is returned
    with atleast 2 small letter, 2 capital letters, 2 digits and 2 punctuations.

    Returns:
        str: random string is returned.
    """
    LOWER_LETTERS = random.choices(list(string.ascii_lowercase), k=3)
    UPPER_LETTERS = random.choices(list(string.ascii_uppercase), k=3)
    DIGITS = random.choices(list(string.digits), k=3)
    PUNCTUATION = random.choices(list(string.punctuation), k=3)

    random_password = LOWER_LETTERS + UPPER_LETTERS + DIGITS + PUNCTUATION
    random.shuffle(random_password)
    random_password = "".join(random_password)
    return random_password


async def create_user(request_meta_data, body):
    """User will be created in okta and get oid of
     specific user created and add config to oid and save in documentstore.
    User create in okta will be skipped if user/email exists in uip user collections.
    Get oid of user from collections and add config and save in documentdb.
    """
    L = request.vars["L"]
    data = DictDefault(body)
    user_with_email_exists = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
            request=rest_pb2.UserInfoRequest(emails=[data["email"]]),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    if user_with_email_exists:
        return {"success": False, "message": "User with email already exists in Db."}
    r = rest_pb2.CreateUserRequest(
        is_external=True,
        email=data["email"],
        password=await generate_password(),
        name=data["name"],
        phone_number=data["phone_number"],
        activate=data.get("activate", False),
    )
    user_oid = MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).CreateUser(
            request=r,
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )
    if len(user_oid) > 100 or "error" in user_oid:
        ValidationError.messages = user_oid
        raise ValidationError
    user_oid = json.loads(user_oid).get("oid")
    L.info(f"user created and oid: {user_oid}")
    data = await insert_update_user_config(request_meta_data, user_oid, body, "CREATE")
    if data.get("success"):
        user = MessageToDict(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
                request=rest_pb2.UserInfoRequest(user_ids=[user_oid]),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        req = rest_pb2.AccessUpdateRequest()
        req.updates.append(
            rest_pb2.AccessUpdate(
                app="goe",
                zone="client-settings",
                type="client",
                user_id=user_oid,
                action=1,
            )
        )
        pui = req.user_info[user_oid]
        info = {
            "first_name": user[user_oid]["first-name"],
            "name": user[user_oid]["name"],
            "email": user[user_oid]["email"],
        }
        pui = ParseDict(info, pui)

        res = MessageToDict(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateAccess(
                request=req, metadata=request.vars["metadata_t"]
            ),
            preserving_proto_field_name=True,
        )
        if res.get("success"):
            # await send_db_change_notification(request_meta_data, "user", data, None, "CREATE")
            return data
        else:
            return {"success": False, "message": "user created but updating to default access failed."}


async def insert_update_user_config(request_meta_data, oid, params, action):
    """Config will be added or updated for user in document db.

    Args:
        req (request object): request object.
        oid (str uuid): oid of the user
        params (dict): user params.
        executed_by_fname(str): fn which execute this
        update_config (bool, optional): help to determin if this called by create/update user. Defaults to False.

    Raises:
        ValidationError: [Requester oid if not present in request object User not found error raised.]
        ValidationError: [Invalid Status: If status not found]
        ValidationError: [Invalid Segment: if segment not found]
        ValidationError: [Invalid Country: if country not found]
        ValidationError: [Portfolio not found for given name, country and segment]
        ValidationError: [Actuarial not found for given name and segment]

    Returns:
        [dict]: [user object is returned {'data':{}, 'count':int}]
    """
    DEFAULT_STATUS = "Active"

    user = {}
    user = DictDefault(user)
    params = DictDefault(params)
    user.config = params.config or {}

    if params.segment:
        segment_data = await get_enums(table_name="segment", name=params.segment)
        if not segment_data:
            ValidationError.messages = f"Invalid Segment: {params.segment}"
            raise ValidationError
    if params.country:
        country_data = await get_enums(table_name="country", name=params.country)
        if not country_data:
            ValidationError.messages = f"Invalid Country: {params.country}"
            raise ValidationError
    if params.portfolioBundleName:
        bundle = await portfolio_country_segment_name(params.country, params.segment, params.portfolioBundleName)
        if not bundle.get("data"):
            ValidationError.messages = f"Portfolio not found. segment: {params.segment}, Country: {params.country}."
            raise ValidationError
    channelName = f"{params.country}_{params.segment}"
    if user.config:
        user.config.channelName = channelName
    user.segmentId = json.loads(segment_data)[0].get("id")
    user.countryId = json.loads(country_data)[0].get("id")
    user.portfolioBundleId = bundle["data"].get("id")

    if (
        user.config
        and user.config.goalPriority
        and user.config.goalPriority.generalSettings
        and user.config.goalPriority.generalSettings.actuarials
        and len(user.config.goalPriority.generalSettings.actuarials) > 0
    ):
        actuarials = user.config.goalPriority.generalSettings.actuarials
        actuarial_status = "Active"
        for actuarial in actuarials:
            result = await actuarial_country_type_name(params.country, actuarial.type, actuarial_status, actuarial.name)
            if result is None or result.empty:
                ValidationError.messages = f"Actuarial not found. segment: {params.segment}, Country: {params.country}."
                raise ValidationError
            actuarial.id = int(result.iloc[0].id)
        user.config.goalPriority.generalSettings.actuarials = actuarials
    if (
        user.config
        and user.config.goalPriority
        and user.config.goalPriority.generalSettings
        and user.config.goalPriority.generalSettings.taxActuarialData
        and len(user.config.goalPriority.generalSettings.taxActuarialData) > 0
    ):
        taxActuarialData = user.config.goalPriority.generalSettings.taxActuarialData
        actuarial_status = "Active"
        for actuarial in taxActuarialData:
            result = await actuarial_country_type_name(params.country, actuarial.type, actuarial_status, actuarial.name)
            if result is None or result.empty:
                ValidationError.messages = f"Actuarial not found. segment: {params.segment}, Country: {params.country}."
                raise ValidationError
            actuarial.id = int(result.iloc[0].id)
        user.config.goalPriority.generalSettings.taxActuarialData = taxActuarialData

    goe_settings = {
        "config": user.config or {},
        "contactId": params.contactId,
        "countryId": user.countryId,
        "notes": params.get("notes"),
        "phone": params.phone,
        "contactName": params.contactName,
        "portfolioBundleId": user.get("portfolioBundleId"),
        "segmentId": user.get("segmentId"),
        "status": {"name": DEFAULT_STATUS},
    }
    settings = Struct()
    settings.update(goe_settings)
    old_entry = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
            request=rest_pb2.AppUserSettingsRequest(user_ids=[oid]),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )

    user_obj = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateAppSettingsForUser(
            request=rest_pb2.UpdateAppUserSettingsRequest(
                app="goe", user_id=oid, zone="client-settings", settings=settings, path=""
            ),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )

    await asyncio.sleep(1)
    if not user_obj.get("success"):
        ValidationError.messages = "user create/update is failed"
        raise ValidationError
    if "success" in user_obj:
        new_entry = MessageToDict(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
                request=rest_pb2.AppUserSettingsRequest(user_ids=[oid]),
                metadata=request_meta_data,
            ),
            preserving_proto_field_name=True,
        )
        new_user_data = new_entry.copy()
        oid, new_data = new_user_data.popitem()
        if new_data["app_settings"]["goe"]["client-settings"]["config"]["goalPriority"]["generalSettings"].get(
            "actuarials", []
        ):
            actuarial_ids = [
                int(act["id"])
                for act in new_data["app_settings"]["goe"]["client-settings"]["config"]["goalPriority"][
                    "generalSettings"
                ]["actuarials"]
                if act["type"] in ["DecumulationLookUp", "GoalDiscoveryLookUp"]
            ]
            for actuarial_id in actuarial_ids:
                actuarial = await actuarial_get_one(actuarial_id)
                if actuarial is not None and not actuarial.empty and list(actuarial['files'].values)[0]:
                    file = actuarial.files[0].get("path")
                    folder, file_id = file.split("-")
                    file = {
                        "file_id": file_id,
                        "file_type": "text/csv",
                        "folder": folder,
                    }
                    await lookup_upload(actuarial_id, file, actuarial.actuarial_type[0], request_meta_data, request=None)
        if oid in old_entry:
            old_entry = old_entry[oid]
        if oid in new_entry:
            new_entry = new_entry[oid]
        await send_db_change_notification(request_meta_data, "user", new_entry, old_entry, action)
    return user_obj


async def update_user(requester_oid, request_meta_data, body):
    """[update user config and other params for given request params.
        Also add entry in user_activty table for old config]

    Args:
        req (request object): [request object]
        body ([dict]): [request body]

    Raises:
        ValidationError: [User not found. If given oid doesnt exists in document db]

    Returns:
        [dict]: [user object returned {'data':dict, 'count': int}]
    """
    user_id = body.get("id")
    user = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
            request=rest_pb2.UserInfoRequest(user_ids=[user_id]),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    if not user:
        ValidationError.messages = f"user not found for oid: {user_id}"
        raise ValidationError
    result = await insert_update_user_config(request_meta_data, user_id, body, "UPDATE")
    return result


async def get_segments():
    """Get segments from segment table
    Returns:
        str: json result
    """
    return await get_enums(table_name="segment")


async def get_countries():
    """Get countries from country table

    Returns:
        str: json result
    """
    return await get_enums(table_name="country")


async def get_actuarial_types():
    """Get actuarial types from actuarial_type table
    Returns:
        str: json result
    """
    return await get_enums(table_name="actuarial_type")


async def get_actuarial_status():
    """Get roles from role table

    Returns:
        str: json result
    """
    return await get_enums(table_name="actuarial_status")


async def portfolio_bundle_enums():
    """portfolio distinct bundle name with isFTPortfolio details are retuned

    Returns:
        [dict]: result returned
    """

    stmt = """SELECT json_agg("portfolio_bundle_table".*) AS portfolio_bundle
        FROM (
            SELECT DISTINCT("portfolio_bundle". "name"),
                "portfolio_bundle". "isFtPortfolio"
            FROM public."portfolio_bundle") AS "portfolio_bundle_table";"""
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    if result is None or result.empty:
        return {}
    portfolio_bundle = json.loads(result.to_json(orient="records"))[0]["portfolio_bundle"]
    countries = await get_enums(table_name="country")
    segments = await get_enums(table_name="segment")
    data = {
        "countries": json.loads(countries),
        "segments": json.loads(segments),
        "portfolioBundleNames": portfolio_bundle,
    }
    return data


async def get_portfolio_bundle_enums():
    """Get portfolio bundle enums
    Returns:
        str: json string
    """
    data = await portfolio_bundle_enums()
    return json.dumps(data)


async def validate_portfolios_body(portfolios):
    required_fields = ["riskOn", "meanPercent", "sdPercent", "assetAllocations", "feesAdjuster", "name"]
    if isinstance(portfolios, abc.MutableSequence):
        for index, pt in enumerate(portfolios):
            missing_keys = set(required_fields - pt.keys())
            if len(missing_keys) > 0:
                BadRequest.messages = "Missing attribute in portfolios at index {0},  attrname: {1}".format(
                    index, ",".join(missing_keys)
                )
                raise BadRequest
    else:
        BadRequest.messages = "portfolios should be list"
        raise BadRequest


async def portfolio_bundle_create(requester_oid, request_meta_data, body):
    """portfolio bundle is created"""
    db = await db_con.get_access()
    tables = await get_meta_data_for_tables(["portfolio_bundle", "portfolio"])
    portfolio_bundle, portfolio = tables["portfolio_bundle"], tables["portfolio"]
    body = DictDefault(body)
    # user = await getUserFromRequest(req)
    user_id = requester_oid
    if not user_id:
        raise ValueError("User not found.")
    segment = body.segment
    country = body.country
    portfolios = body.portfolios
    await validate_portfolios_body(portfolios)
    isFtPortfolio = body.isFtPortfolio
    name = body.name
    description = body.description
    segment = await get_enums(table_name="segment", name=segment)
    country = await get_enums(table_name="country", name=country)
    if segment:
        segment = json.loads(segment)
        segmentId = segment[0].get("id")
    if country:
        country = json.loads(country)
        countryId = country[0].get("id")
    kwargs = {
        "segmentId": segmentId,
        "countryId": countryId,
        "isFtPortfolio": isFtPortfolio,
        "description": description,
        "name": name,
        "createdById": user_id,
        "createdBy": user_id,
    }
    db = await db_con.get_writer_access()
    engine = db.conn.engine
    portfolio_bundle_columns = portfolio_bundle.columns.keys()

    async with engine.begin() as conn:
        try:
            ptfb_stmt = insert(portfolio_bundle).values(**kwargs).returning(*portfolio_bundle.columns)
            cursor = await conn.execute(ptfb_stmt)
            portfolio_bundle_data = cursor.fetchall()
            if portfolio_bundle_data:
                portfolio_bundle_data = dict(zip(portfolio_bundle_columns, portfolio_bundle_data[0]))
                bundle_id = portfolio_bundle_data.get("id")
                portfolio_to_send = []
                for portfolio_item in portfolios:
                    portfolio_item["bundleId"] = bundle_id
                    portfolio_item["assetAllocations"] = json.dumps(portfolio_item["assetAllocations"])
                    portfolio_to_send.append(portfolio_item)
                ptf_stmt = insert(portfolio).values(portfolio_to_send).returning(*portfolio.columns)
                cursor = await conn.execute(ptf_stmt)
                portfolio_data = cursor.fetchall()
                if not portfolio_data:
                    BadRequest.messages = (
                        f"There seems an issue portfolio insert seems failed portfolio_data: {portfolio_data}"
                    )
                    raise BadRequest
        except IntegrityError as e:
            BadRequest.messages = e.orig.args[0].split(":")[1].split("\n")[0].replace('"', "")
            raise BadRequest
    await send_db_change_notification(request_meta_data, "portfolio_bundle", portfolio_bundle_data, None, "CREATE")
    return await get_portfolios(request_meta_data, bundle_id)


async def get_portfolios(request_meta_data, portfolio_id=None, **kwargs):
    tables = await get_meta_data_for_tables(["portfolio_bundle", "portfolio", "segment", "country"])
    portfolio_bundle, Portfolio, Segment, Country = (
        tables["portfolio_bundle"],
        tables["portfolio"],
        tables["segment"],
        tables["country"],
    )
    stmt = (
        select(
            portfolio_bundle,
            func.row_to_json(Country.table_valued()).label("country"),
            func.row_to_json(Segment.table_valued()).label("segment"),
        )
        .join_from(portfolio_bundle, Country, portfolio_bundle.c.countryId == Country.c.id, isouter=True)
        .join_from(portfolio_bundle, Segment, portfolio_bundle.c.segmentId == Segment.c.id, isouter=True)
    )
    if portfolio_id and isinstance(portfolio_id, int):
        stmt = stmt.where(portfolio_bundle.c.id == portfolio_id)
    if kwargs.get("name") and isinstance(kwargs.get("name"), str):
        stmt = stmt.where(portfolio_bundle.c.name == kwargs.get("name"))
    if kwargs.get("country") and isinstance(kwargs.get("country"), str):
        stmt = stmt.where(Country.c.name == kwargs.get("country"))
    if kwargs.get("segment") and isinstance(kwargs.get("segment"), str):
        stmt = stmt.where(Segment.c.name == kwargs.get("segment"))
    if kwargs:
        stmt = stmt.order_by(desc("createdAt")).limit(1)
    db = await db_con.get_writer_access()
    results = await db.get_data(stmt, as_dict=True)
    # results = json.loads(result.to_json(orient="records", date_format="iso"))

    portfolio_stmt = select(Portfolio)
    if portfolio_id:
        portfolio_stmt = portfolio_stmt.where(Portfolio.c.bundleId == portfolio_id)
        portfolios = await db.get_data(portfolio_stmt, as_dataframe=True)
        for result in results:
            portfolio_id = result["id"]
            created_byid = result["createdById"]
            # user = await get_user(request_meta_data, {"id": created_byid})
            user = MessageToDict(
                await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
                    request=rest_pb2.UserInfoRequest(user_ids=[created_byid]),
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            if user:
                result["createdBy"] = user[created_byid]
            if portfolios is not None or not portfolios.empty:
                result["portfolios"] = json.loads(
                    portfolios[portfolios.bundleId == portfolio_id].to_json(orient="records", date_format="iso")
                )
                for pt in result["portfolios"]:
                    if pt.get("assetAllocations"):
                        pt["assetAllocations"] = json.loads(pt["assetAllocations"])
    return results


async def portfolio_create(request_meta_data, body):
    body = DictDefault(body)
    name = body.name
    bundleId = body.bundleId
    riskOn = body.riskOn
    meanPercent = body.meanPercent
    sdPercent = body.sdPercent
    assetAllocations = json.dumps(body.assetAllocations)
    data = {
        "name": name,
        "bundleId": bundleId,
        "riskOn": riskOn,
        "meanPercent": meanPercent,
        "sdPercent": sdPercent,
        "assetAllocations": assetAllocations,
        "createdBy": dict(request_meta_data).get("user-id"),
    }
    portfolio = await insert_record_into_one_table("portfolio", **data)
    bundle_id = portfolio.get("bundleId")
    bundle = await get_enums(table_name="portfolio_bundle", table_id=bundle_id)
    portfolio.update({"bundle": json.loads(bundle)})
    if portfolio.get("assetAllocations"):
        portfolio["assetAllocations"] = json.loads(portfolio["assetAllocations"])
    return portfolio


async def portfolio_country_segment_name(country_name, segment_name, name):
    tables = await get_meta_data_for_tables(["portfolio_bundle", "portfolio", "segment", "country"])
    portfolio_bundle, Portfolio, Segment, Country = (
        tables["portfolio_bundle"],
        tables["portfolio"],
        tables["segment"],
        tables["country"],
    )
    subq = select(func.json_agg(Portfolio.table_valued())).where(portfolio_bundle.c.id == Portfolio.c.bundleId)
    stmt = (
        select(
            portfolio_bundle,
            subq.label("portfolios"),
            func.row_to_json(Country.table_valued()).label("country"),
            func.row_to_json(Segment.table_valued()).label("segment"),
        )
        .join_from(portfolio_bundle, Country, portfolio_bundle.c.countryId == Country.c.id, isouter=True)
        .join_from(portfolio_bundle, Segment, portfolio_bundle.c.segmentId == Segment.c.id, isouter=True)
    )
    if country_name:
        stmt = stmt.where(Country.c.name == country_name)
    if segment_name:
        stmt = stmt.where(Segment.c.name == segment_name)
    if name:
        stmt = stmt.where(portfolio_bundle.c.name == name)
    stmt = stmt.order_by(desc(portfolio_bundle.c.createdAt)).limit(1)
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    if result is None or result.empty:
        return {"data": {}}
    result = json.loads(result.to_json(orient="records", date_format="iso"))
    if not result or len(result) < 1:
        return {"data": result}
    result = result[0]
    for pt in result["portfolios"]:
        if pt.get("assetAllocations"):
            pt["assetAllocations"] = json.loads(pt.get("assetAllocations"))
    return {"data": result}


async def portfolio_bundle_get_one(body):
    name = body.get("portfolioBundleName")
    country_name = body.get("country")
    segment_name = body.get("segment")
    result = await portfolio_country_segment_name(country_name, segment_name, name)
    return result


async def get_portfolio_by_user(req):
    """Get portfolio of user by taking email from request headers"""
    user = None
    # allow to access to impersonate both for admin and view users
    is_admin = await check_access(req, (("goe", "client-settings", "admin"), ("goe", "client-settings", "view")))
    is_client = await check_access(req, (("goe", "client-settings", "client"),))
    if is_client:
        requester_oid = req["requester_oid"]
        user = await get_user_from_oid(requester_oid, req["request_meta_data"], True)
    elif is_admin:  # if user is admin get email from headers
        if not req["headers"].get("clientemail") or type(req["headers"].get("clientemail")) is not str:
            raise BadRequest
        # user = await getUserFromEmail(req.headers.get("clientemail"), True)
        request_meta_data = req["request_meta_data"]
        oid = await get_oid_by_email(req["headers"].get("clientemail"), request_meta_data)
        user = await get_user_from_oid(oid, request_meta_data, True)
    if not user:
        BadRequest.messages = "User not found to search portfolios"
        raise BadRequest
    user = DictDefault(user)
    portfoliosRiskOn = []
    portfoliosRiskOff = []
    for index, pt in enumerate(user.app_settings.goe["client-settings"].portfolio_bundle.portfolios):
        if pt.riskOn:
            data = {
                "portfolioId": index + 1,
                "riskOn": pt.riskOn,
                "meanPercent": pt.meanPercent,
                "sdPercent": pt.sdPercent,
                "assetAllocations": pt.assetAllocations,
            }
            portfoliosRiskOn.append(data)
        else:
            data = {
                "portfolioId": index + 1,
                "riskOn": pt.riskOn,
                "meanPercent": pt.meanPercent,
                "sdPercent": pt.sdPercent,
                "assetAllocations": pt.assetAllocations,
            }
            portfoliosRiskOff.append(pt)

    portfoliosRiskOn.extend(portfoliosRiskOff)
    return json.dumps({"statusCode": 200, "message": "Success", "body": portfoliosRiskOn})


async def _get_portfolio_bundle(params):
    if not isinstance(params, DictDefault):
        params = DictDefault(params)
    tables = await get_meta_data_for_tables(["portfolio_bundle", "segment", "country"])
    portfolio_bundle, Segment, Country = (
        tables["portfolio_bundle"],
        tables["segment"],
        tables["country"],
    )
    stmt = (
        select(portfolio_bundle)
        .join_from(portfolio_bundle, Segment, portfolio_bundle.c.segmentId == Segment.c.id, isouter=True)
        .join_from(portfolio_bundle, Country, portfolio_bundle.c.countryId == Country.c.id, isouter=True)
    )
    if params.country_name:
        stmt = stmt.where(Country.c.name == params.country_name)
    if params.segment_name:
        stmt = stmt.where(Segment.c.name == params.segment_name)
    subq = stmt.subquery()
    stmt = select(distinct(subq.c.name), subq.c.isFtPortfolio)
    db = await db_con.get_access()
    results = await db.get_data(stmt, as_dict=True)
    if results is None or len(results) < 1:
        RecordDoesNotExist.messages = "portfolio not found"
        raise RecordDoesNotExist
    for result in results:
        if result.get("portfolios"):
            if result.get("portfolios").get("assetAllocations"):
                result["portfolios"]["assetAllocations"] = json.loads(result["portfolios"]["assetAllocations"])
    return results


async def portfolio_bundle_get_all(body):
    body = DictDefault(body)
    body = Body(take=body.take, skip=body.skip, sortKey=body.sortKey, sortDirection=body.sortDirection)
    stmt = '''SELECT "portfolio_bundle".*, (
        SELECT json_agg("public"."portfolio".*)
            FROM public."portfolio"
            WHERE "portfolio_bundle"."id"=public."portfolio"."bundleId"
        ) AS "portfolios",
        (SELECT json_agg("country".*) FROM country WHERE "country"."id" = "portfolio_bundle"."countryId"
        ) AS "country",
        (SELECT json_agg("segment".*) FROM segment WHERE "segment"."id" = "portfolio_bundle"."segmentId"
        ) AS "segment"
        FROM public."portfolio_bundle"
        INNER JOIN public."country" ON "country"."id" = "portfolio_bundle"."countryId"
        INNER JOIN public."segment" ON "segment"."id" = "portfolio_bundle"."segmentId"'''
    db = await db_con.get_access()
    results = await db.get_data(stmt, as_dict=True)
    created_by_users = [usr["createdById"] for usr in results if usr.get("createdById")]
    updated_by_users = [usr["updatedBy"] for usr in results if usr.get("updatedBy")]
    created_updated_users = list(set(created_by_users + updated_by_users))
    created_updated_users = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
            request=rest_pb2.UserInfoRequest(user_ids=created_updated_users),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    tables = []
    for idx, result in enumerate(results):
        record = {}
        if result:
            record["country"] = result.pop("country")[0]
            record["segment"] = result.pop("segment")[0]
            record["portfolios"] = (
                list(result.pop("portfolios")) if result.get("portfolios") is not None else result.pop("portfolios")
            )
            if record["portfolios"]:
                for idx, pt in enumerate(record["portfolios"]):
                    if pt.get("assetAllocations"):
                        record["portfolios"][idx]["assetAllocations"] = json.loads(pt.get("assetAllocations"))
            # update remaining keys if there are any apart from above.
            record.update(result)
            if result.get("createdById"):
                record["createdBy"] = created_updated_users.get(result["createdById"])
            if result.get("updatedBy"):
                record["updatedBy"] = created_updated_users.get(result["updatedBy"])
            tables.append(record)
    return {"data": tables, "count": len(tables)}


async def portfolio_get_all(body):
    body = DictDefault(body)
    body = Body(take=body.take, skip=body.skip, sortKey=body.sortKey, sortDirection=body.sortDirection)
    stmt = '''SELECT "public"."portfolio".*,
        (SELECT json_agg("public"."portfolio_bundle".*)
        FROM "public"."portfolio_bundle"
        WHERE "portfolio_bundle"."id"="portfolio"."bundleId") AS "bundle"
    FROM public."portfolio"'''
    db = await db_con.get_access()
    results = await db.get_data(stmt, as_dict=True)
    tables = []
    for _, result in enumerate(results):
        if result.get("assetAllocations"):
            result["assetAllocations"] = json.loads(result.get("assetAllocations"))
        if result.get("bundle"):
            result["bundle"] = list(result.get("bundle"))
        tables.append(result)
    return {"data": tables, "count": len(tables)}


async def update_role(requester_oid, request_meta_data, body):
    """update user role.
        Identify user with given status and id.
            if not found raise Error
            else update user role
    Args:
        req ([type]): [description]
        body (dict): body.id user id who is updating this record
                     body.role user who want to update to this role
                     body.status user status

    Raises:
        ValidationError: Role not found for given role
        ValidationError: UserStatus not found for given user Status
        ValidationError: User not found for given Id

    Returns:
        [type]: [description]
    """
    user_id = body.get("id")
    role = body.get("role")
    status = body.get("status")
    # role_data = {"id": body.get("id"), "role": body.get("role"), "status": body.get("status")}
    if role == Roles.SUPER_ADMIN.value or role == Roles.CLIENT.value:
        Unauthorized.messages = f"Unauthorized, Cannot change the role to: {role}."
        raise Unauthorized
    roleVal = await get_enums(table_name="role", name=role)
    roleVal = roleVal if len(json.loads(roleVal)) > 0 else None
    statusVal = await get_enums(table_name="user_status", name=status)
    statusVal = statusVal if len(json.loads(statusVal)) > 0 else None
    if not roleVal:
        ValidationError.messages = f"Role not found. Role; {role}"
        raise ValidationError
    if not statusVal:
        ValidationError.messages = f"Status not found. Role; {status}"
        raise ValidationError
    roleVal = DictDefault(json.loads(roleVal)[0])
    statusVal = DictDefault(json.loads(statusVal)[0])
    userToUpdate = await get_user(request_meta_data, {"id": user_id})

    if len(userToUpdate["data"]) < 1:
        ValidationError.messages = f"User not found. Id; {id}"
        raise ValidationError
    userToUpdate = userToUpdate["data"][0]
    # oldUser = userToUpdate
    userToUpdate = DictDefault(userToUpdate)
    userToUpdate.roleId = roleVal.id
    userToUpdate.statusId = statusVal.id
    # assign oid or user-id which is nothing but principalId
    userToUpdate.updatedBy = requester_oid  # getPrincipalIdFromRequest(req)
    db = await db_con.get_access()
    METADATA = GenerateTables.generate_metadata()
    User = METADATA.metadata.tables.get("user")
    engine = db.conn.engine
    columns = User.columns.keys()
    async with engine.begin() as conn:
        stmt = (
            update(User)
            .where(User.c.id == user_id)
            .values(**{"roleId": roleVal.id, "statusId": statusVal.id})
            .returning(*User.columns)
        )
        result = await conn.execute(stmt)
    result = result.fetchall()
    result = dict(zip(columns, result[0]))
    # send_db_change_notification('user', userToUpdate, oldUser, 'UPDATE');
    result_data = await get_user(request_meta_data, {"id": user_id})

    del result_data["data"][0]["createdBy"]
    del result_data["data"][0]["segment"]
    del result_data["data"][0]["segmentId"]
    user = result_data["data"][0]
    return {"status": True, "user": user}


async def actuarial_country_type_name(country, type, status, actuarial_name):
    tables = await get_meta_data_for_tables(["actuarial", "actuarial_type", "actuarial_status", "country"])
    Actuarial, ActuarialType, ActuarialStatus, Country = (
        tables["actuarial"],
        tables["actuarial_type"],
        tables["actuarial_status"],
        tables["country"],
    )
    stmt = (
        select(Actuarial)
        .join_from(Actuarial, Country, Actuarial.c.countryId == Country.c.id, isouter=True)
        .join_from(Actuarial, ActuarialType, Actuarial.c.typeId == ActuarialType.c.id, isouter=True)
        .join_from(Actuarial, ActuarialStatus, Actuarial.c.statusId == ActuarialStatus.c.id, isouter=True)
        .where(Actuarial.c.name == actuarial_name)
        .where(Country.c.name == country)
        .where(ActuarialStatus.c.name == status)
        .where(ActuarialType.c.name == type)
        .order_by(desc(Actuarial.c.createdAt))
        .limit(1)
    )
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    return result


async def create_country(body):
    if not isinstance(body.get("name"), str):
        target = {
            "target": body,
            "property": "name",
            "children": [],
            "constraints": {"isString": "name must be a string"},
        }
        BadRequestError.errors.append(target)
        raise BadRequestError
    if not body.get("description"):
        body["description"] = body.get("name")
    country = await insert_record_into_one_table("country", **body)
    return country


async def create_role(body):
    if not isinstance(body.get("name"), str):
        target = {
            "target": body,
            "property": "name",
            "children": [],
            "constraints": {"isString": "name must be a string"},
        }
        BadRequestError.errors.append(target)
        raise BadRequestError
    if not body.get("description"):
        body["description"] = body.get("name")
    role = await insert_record_into_one_table("role", **body)
    return role


async def create_segment(body):
    if not isinstance(body.get("name"), str):
        target = {
            "target": body,
            "property": "name",
            "children": [],
            "constraints": {"isString": "name must be a string"},
        }
        BadRequestError.errors.append(target)
        raise BadRequestError
    if not body.get("description"):
        body["description"] = body.get("name")
    country = await insert_record_into_one_table("segment", **body)
    return country


async def create_draft(requester_oid, body):
    db = await db_con.get_writer_access()
    tables = await get_meta_data_for_tables(["draft"])
    Draft = tables["draft"]
    user_id = requester_oid
    if not user_id:
        raise ValueError("User not found.")
    engine = db.conn.engine
    columns = Draft.columns.keys()
    async with engine.begin() as conn:
        stmt = insert(Draft).values(data=json.dumps(body.get("data")), userId=user_id).returning(*Draft.columns)
        draft = await conn.execute(stmt)
    draft = draft.fetchall()
    if not draft:
        BadRequest.messages = f"There seems an issue draft insert failed.  draft:{draft}"
        raise BadRequest
    draft = draft[0]
    table = dict([(col, draft[idx]) for idx, col in enumerate(columns)])
    return table


async def actuarial_data_map(request_meta_data, params, db_reader=True, inactive=False):
    L = request.vars["L"]
    if not isinstance(params, DictDefault):
        params = DictDefault(params)
    tables = await get_meta_data_for_tables(["actuarial", "actuarial_type", "actuarial_file", "country", "segment"])
    Actuarial, ActuarialType, ActuarialFile, Country, Segment = (
        tables["actuarial"],
        tables["actuarial_type"],
        tables["actuarial_file"],
        tables["country"],
        tables["segment"],
    )
    stmt = (
        select(
            Actuarial,
            func.row_to_json(ActuarialType.table_valued()).label("type"),
            func.row_to_json(ActuarialFile.table_valued()).label("files"),
            func.row_to_json(Country.table_valued()).label("country"),
            func.row_to_json(Segment.table_valued()).label("segment"),
        )
        .join_from(Actuarial, ActuarialType, Actuarial.c.typeId == ActuarialType.c.id, isouter=True)
        .join_from(Actuarial, ActuarialFile, Actuarial.c.id == ActuarialFile.c.actuarialId, isouter=True)
        .join_from(Actuarial, Country, Actuarial.c.countryId == Country.c.id, isouter=True)
        .join_from(Actuarial, Segment, Actuarial.c.segmentId == Segment.c.id, isouter=True)
    )
    if inactive is False:
        stmt = stmt.where(or_(ActuarialFile.c.active == None, ActuarialFile.c.active == True))  # noqa: E711
    if params.actuarial_id:
        stmt = stmt.where(Actuarial.c.id == int(params.actuarial_id))
    if params.sortKey:
        stmt = (
            stmt.order_by(asc(params.sortKey)) if params.sortDirection == "ASC" else stmt.order_by(desc(params.sortKey))
        )
    if params.take:
        stmt = stmt.limit(params.take)
    if params.skip:
        stmt = stmt.offset(params.skip)
    L.info(f"{stmt}")
    if db_reader:
        db = await db_con.get_access()
    else:
        db = await db_con.get_writer_access()
    result = await db.get_data(stmt, as_dataframe=True)
    users = await get_users_from_db(request_meta_data)
    if not users or not users["data"]:
        ValidationError.messages = "Users not found to map with actuarial data/No access to user collection"
        raise ValidationError

    if result is None or result.empty:
        return {}
    actuarials = json.loads(result.to_json(orient="records", date_format="iso"))
    if not actuarials or len(actuarials) <= 0:
        return {}
    actuarials_created_by_ids = [
        actuarial.get("createdById") for actuarial in actuarials if actuarial.get("createdById")
    ]
    actuarials_updated_by_ids = [actuarial.get("updatedBy") for actuarial in actuarials if actuarial.get("updatedBy")]
    actuarial_user_ids = list(set(actuarials_updated_by_ids + actuarials_created_by_ids))
    actuarial_update_users = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
            request=rest_pb2.UserInfoRequest(user_ids=actuarial_user_ids),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )

    for actuarial in actuarials:
        if actuarial.get("createdById"):
            actuarial["createdBy"] = actuarial_update_users.get(actuarial.get("createdById"))
        if actuarial.get("updatedBy"):
            actuarial["updatedBy"] = actuarial_update_users.get(actuarial.get("updatedBy"))
            # actuarial["createdBy"]["executedBy"] = actuarial["createdById"]
    return {"count": len(actuarials), "data": actuarials}


async def actuarial_get_all(request_meta_data, body):
    body = DictDefault(body)
    body = Body(take=body.take, skip=body.skip, sortKey=body.sortKey, sortDirection=body.sortDirection)
    table = await actuarial_data_map(request_meta_data, vars(body))
    return table


async def actuarial_by_id(request_meta_data, actuarial_id, db_reader=True, inactive=False):
    params = {"actuarial_id": actuarial_id}
    table = await actuarial_data_map(request_meta_data, params, db_reader=db_reader, inactive=inactive)
    if not table or not table["data"]:
        raise RecordDoesNotExist
    return table["data"]


async def actuarial_get(request_meta_data, actuarial_id, inactive=False):
    """Get actuarial data from actuarial table for a given actuarial_id

    Args:
        actuarial_id ([type]): actuarial id for which data is pulled

    Returns:
        str: json result
    """
    table = await actuarial_by_id(request_meta_data, actuarial_id, inactive=inactive)
    return table


async def actuarial_get_file_by_id(request_meta_data, file_id):
    """Download actuarial file by id

    Args:
        file_id ([str]): Actuarial file id

    Raises:
        ValidationError: Invalid file_id error

    Returns:
        [type]: [description]
    """
    if not file_id or not file_id.isnumeric():
        ValidationError.messages = f"Invalid file_id Got file_id {file_id}"
        raise ValidationError
    actuarial_id = int(file_id)
    actuarial = await actuarial_by_id(request_meta_data, actuarial_id)
    if actuarial:
        _, fileid = actuarial[0].get("files").get("path").split("-")
        return await download(fileid)


async def lookup_upload(actuarial_id, file, data_table_type, request_meta_data, request=None):
    """This will add/update the look up document which track the when changes are done to data
    table or user is mapped with specific data table goaldiscoverylookup, decumulationlookup.

    Args:
        actuarial_id int: actuarial id
        file dict: file object which file details.
        data_table_type str: DecumulationLookUp or GoalDiscoveryLookUp
        request_meta_data dict: meta data request 
        request object: request object valid when called by fastapi. Defaults to None.
    Returns:
        dict: file object
    """
    if data_table_type == "DecumulationLookUp":
        doc_name = "decumulation_look_up"
    elif data_table_type == "GoalDiscoveryLookUp":
        doc_name = "goal_discovery_look_up"
    else:
        ValidationError.messages = f"look_upload failed as there is no such data table type: {data_table_type}"
        raise ValidationError
    users = await get_users_from_db(request_meta_data)
    users = users.get("data", [])
    users_actuarials = dict(
        [
            (
                i["_id"],
                i["app_settings"]["goe"]["client-settings"]["config"]["goalPriority"]["generalSettings"]["actuarials"],
            )
            for i in users
            if "app_settings" in i
            and "goe" in i["app_settings"]
            and "client-settings" in i["app_settings"]["goe"]
            and "config" in i["app_settings"]["goe"]["client-settings"]
            and "goalPriority" in i["app_settings"]["goe"]["client-settings"]["config"]
            and "generalSettings" in i["app_settings"]["goe"]["client-settings"]["config"]["goalPriority"]
            and "actuarials" in i["app_settings"]["goe"]["client-settings"]["config"]["goalPriority"]["generalSettings"]
        ]
    )
    users_acts = {}
    for o in users_actuarials:
        for act in users_actuarials[o]:
            if act["type"] in ["DecumulationLookUp", "GoalDiscoveryLookUp"] and act["id"] == actuarial_id:
                users_acts[o] = act
    get_lookup = MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetDocument(
            request=rest_pb2.GetDocumentRequest(
                collection_name="goe-settings",
                document_id=doc_name,
                # version=request.args.get("version", None),
            ),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
        sort_keys=True,
    )
    body = Struct()
    get_lookup = json.loads(get_lookup)
    changed = False
    for oid in users_acts:
        if request:
            request.vars["L"].info(
                f"There is user mapped with this datatable {users_acts[oid]}."
                "Will update decumulation_look_up so airflow takes care of loading this data in decumualtion lookup."
            )
        # update the look_up doc when a file changed/added.
        if oid not in get_lookup["user_files"] or get_lookup["user_files"][oid]['file_id'] != file['file_id'] or (
            get_lookup["user_files"][oid]['file_id'] == file['file_id'] and get_lookup["user_files"][oid].get('enabled', False)):
            # add enable flag so the job picks it up.
            file.update({"enabled": True})
            get_lookup["user_files"].update({oid: file})
            changed = True
    if changed:
        new_data = {
            "document_id": get_lookup["_id"],
            "document": json.dumps({"user_files": get_lookup["user_files"]}),
        }
        body.update(new_data)
        MessageToJson(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateDocument(
                request=rest_pb2.UpdateDocumentRequest(
                    collection_name="goe-settings",
                    payload=body,
                    comment="App updated.",
                    document_id=doc_name,
                    type=None,
                ),
                metadata=request_meta_data,
            ),
            preserving_proto_field_name=True,
        )
        return file


async def actuarial_create(req):
    """Create actuarial record

    Args:
        req (object): request object

    Raises:
        ValueError: User not found
        ValueError: Invalid country name request

    Returns:
        [type]: [description]
    """
    # user = await getUserFromRequest(req)
    user_id = req.vars["metadata_d"]["user-id"]
    if not user_id:
        raise ValueError(" User not found.")
    L = request.vars["L"]
    folder = req.args.get("folder", "actuarialTypeFile")
    # if actuarial_type == "DecumulationLookUp":
    #     file = await decumulation_lookup_upload(request, req, folder=folder)
    # else:
    file = await process_post_data(req, folder=folder, allow_excel=True)
    L.info("new file created", file)
    file_path = file.get("filePath")
    data = json.loads(file["json"])
    segment = data.get("segment")
    country = data.get("country")
    name = data.get("name")
    actuarial_type = data.get("type")
    # if actuarial_type == "DecumulationLookUp":
    #     if "filePath" in file:
    #         dec_file = await decumulation_lookup_upload(file["filePath"][0])
    actuarial_status = "Active"
    if file_path and file_path[0]:
        filePath = "%s-%s" % (file_path[0].get("folder"), file_path[0].get("file_id"))
    description = data.get("description")
    db = await db_con.get_access()

    country_result = await get_enums(table_name="country", name=country, as_dataframe=True)
    if country_result is None or country_result.empty:
        ValidationError.messages = "Invalid Country name"
        raise ValidationError

    segment_result = await get_enums(table_name="segment", name=segment, as_dataframe=True)
    if segment_result is None or segment_result.empty:
        ValidationError.messages = "Invalid Segment name"
        raise ValidationError

    actuarial_type_result = await get_enums(table_name="actuarial_type", name=actuarial_type, as_dataframe=True)
    if actuarial_type_result is None or actuarial_type_result.empty:
        ValidationError.messages = "Invalid type name"
        raise ValidationError

    actuarial_status_result = await get_enums(table_name="actuarial_status", name=actuarial_status, as_dataframe=True)
    if actuarial_status_result is None or actuarial_status_result.empty:
        ValidationError.messages = "Invalid status name"
        raise ValidationError
    actuarial_request_data = {
        "segmentId": segment_result.id.values[0],
        "countryId": country_result.id.values[0],
        "description": description,
        "createdBy": user_id,
        "name": name,
        "typeId": actuarial_type_result.id.values[0],
        "statusId": actuarial_status_result.id.values[0],
        "createdById": user_id,
    }
    tables = await get_meta_data_for_tables(["actuarial", "actuarial_file"])
    Actuarial, ActuarialFile = tables["actuarial"], tables["actuarial_file"]
    db = await db_con.get_writer_access()
    engine = db.conn.engine
    actuarial_columns = Actuarial.columns.keys()
    async with engine.begin() as conn:
        try:
            stmt = insert(Actuarial).values(**actuarial_request_data).returning(*Actuarial.columns)
            actuarial = await conn.execute(stmt)
            actuarial = actuarial.fetchall()
            actuarial = dict(
                zip(actuarial_columns, actuarial[0])
            )  # There will be one record returned must else exception raised if input is wrong.
            actuarial_file_data = {
                "name": actuarial_type_result.name.values[0],
                "path": filePath,
                "actuarialId": actuarial.get("id"),
                "createdBy": user_id,
                "active": True,
            }

            actuarial_file_stmt = insert(ActuarialFile).values(**actuarial_file_data).returning(*ActuarialFile.columns)
            await conn.execute(actuarial_file_stmt)
        except IntegrityError as e:
            BadRequest.messages = e.orig.args[0].split(":")[1].split("\n")[0]
            raise BadRequest
    request_meta_data = req.vars["metadata_t"]
    table = await actuarial_by_id(
        request_meta_data, actuarial.get("id"), db_reader=False
    )  # this will connect to writer instance of db
    await send_db_change_notification(request_meta_data, "actuarial", actuarial, None, "CREATE")
    return table


def check_risk_records_exists(rows):
    check_pass = True
    # validate order of riskon and riskoff provided in csv file.
    port_nos = set(Counter(rows["Portfolio Number"]).values())
    expected_no = {2}
    if len(port_nos - expected_no) >= 1:
        return False
    port_risk_nos = Counter(rows["Risk-Off"].str.lower())
    if port_risk_nos["yes"] != len(rows) / 2 or port_risk_nos["no"] != len(rows) / 2:
        return False
    return check_pass


async def portfolio_upload(request):
    """Portfolio info read from csv file and return data.

    Args:
        request (object): request object

    Returns:
        [dict]: [data returned which is payload used for creating portfolio]
    """
    files = await process_files(request)
    if not files:
        return {"isValid": False, "message": "Please upload a file"}
    elif len(files) != 1:
        return {"isValid": False, "message": "Please upload one file only"}

    val = list(files.values())[0][0]
    data = pd.read_csv(io.StringIO(val["buf"].decode("utf-8")))
    if len(set(data["Portfolio Name"])) > 1:
        return {"isValid": False, "message": "There are more than 1 Portfolio Names "}
    risk_off_values = set(data["Risk-Off"].values)
    if not (1 <= len(risk_off_values) <= 2):
        return {"isValid": False, "message": "Risk off values are not as expected."}
    risk_off = False
    if "yes" in [i.lower() for i in risk_off_values]:
        risk_off = True
    if risk_off:
        if not check_risk_records_exists(data):
            return {"isValid": False, "message": "Risk on and Risk off records are not equal"}
    response = {
        "name": data["Portfolio Name"][0],
        "description": data["Portfolio Description"][0],
        "country": data["Country"][0],
        "segment": data["Segment"][0],
        "isFtPortfolio": True if data["Portfolio Origin"][0].lower() == "ft" else False,
        "risk_off": risk_off,
    }
    portfolios = []
    for idx, rec in data.iterrows():
        assetAllocations = []
        if rec["Bond"] != 0:
            assetAllocations.append({"name": "bond", "weightPercent": rec["Bond"] * 100})
        if rec["Money Market"] != 0:
            assetAllocations.append({"name": "money", "weightPercent": rec["Money Market"] * 100})
        if rec["Equity"] != 0:
            assetAllocations.append({"name": "equity", "weightPercent": rec["Equity"] * 100})
        rec_risk_off = True if rec["Risk-Off"].lower() == "yes" else False
        if rec_risk_off:
            portfolios[-1].update(
                {
                    "meanPercent_risk_off": rec["Mean Return"],
                    "sdPercent_risk_off": rec["Standard Deviation"],
                    "feesAdjuster_risk_off": rec["Fees Adjuster (Annual in bps)"],
                    "name_risk_off": rec["Portfolio Name"],
                    "assetAllocations_risk_off": assetAllocations,
                }
            )
        else:
            portfolios.append(
                {
                    "meanPercent": rec["Mean Return"],
                    "sdPercent": rec["Standard Deviation"],
                    "feesAdjuster": rec["Fees Adjuster (Annual in bps)"],
                    "name": rec["Portfolio Name"],
                    "assetAllocations": assetAllocations,
                }
            )
    response.update({"portfolios": portfolios})
    return {"isValid": True, "response": response}


async def validate_decumulation_files(field_name, data):
    check_decimal_places = True
    valid_columns = []
    if field_name["fieldName"].lower() == "additionalconsumptioncap":
        valid_columns = ["age", "additional consumption factor"]
        valid_decimal_places = 2
    elif field_name["fieldName"].lower() == "minconsumptionfloor":
        valid_columns = ["age", "minimum consumption floor"]
        valid_decimal_places = 3
    elif field_name["fieldName"].lower() == "agebasedgicap":
        valid_columns = ["age", "gi% cap factor"]
        valid_decimal_places = 3
    elif field_name["fieldName"].lower() == "agebasedannuitycap":
        valid_columns = ["age", "additional annuity cap factor"]
        valid_decimal_places = 2
    elif field_name["fieldName"].lower() == "maxequityexposure":
        valid_columns = ["risk profile", "age", "portfolio index"]
        check_decimal_places = False
    column_names = [col.lower() for col in data.columns.tolist()]
    if not valid_columns:
        ValidationError.messages = "fieldName provided doesnt match with {'additionalconsumptioncap', \
            'minconsumptionfloor', 'agebasedgicap', 'agebasedannuitycap', 'maxequityexposure'}."
        raise ValidationError
    diff_exists = set(valid_columns) - set(column_names)
    unknown_col_exists = set(column_names) - set(valid_columns)
    if diff_exists:
        ValidationError.messages = f"These are missing fields in file {diff_exists}"
        raise ValidationError
    if unknown_col_exists:
        ValidationError.messages = f"These are unknown fields in file {unknown_col_exists}"
        raise ValidationError

    if check_decimal_places:
        isincorrect_data = True in [
            has_greater_precision(x, valid_decimal_places) if type(x) in [int, float] else True
            for x in data[data.columns.to_list()[1]].to_list()
        ]
        if isincorrect_data:
            col_with_invalid_data = data.columns.to_list()[1]
            ValidationError.messages = f"{col_with_invalid_data} column should have values less than or equal {valid_decimal_places} decimal places."
            raise ValidationError
    return True


async def upload_file(req):
    L = request.vars["L"]
    form = await request.form
    field_name = json.loads(form.to_dict()["json"]) if form.to_dict() else {}

    if not form or "fieldName" not in field_name:
        ValidationError.messages = "fieldName is mandatory while submitting."
        raise ValidationError
    files = await process_files(request, allow_excel=True, offset=0)
    if not files:
        return {"isValid": False, "message": "Please upload a file"}

    val = list(files.values())[0][0]
    if val["file_type"] == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        xl = pd.ExcelFile(io.BytesIO(val["buf"]))
        xl_data = {}
        for sheet in xl.sheet_names:
            data = pd.read_excel(io.BytesIO(val["buf"]), sheet_name=sheet)
            xl_data[sheet] = json.loads(data.to_json(orient="records"))
            break
    else:
        data = pd.read_csv(io.StringIO(val["buf"].decode("utf-8")))

    await validate_decumulation_files(field_name, data)
    folder = req.args.get("folder", "decummulationFileType")

    file = await process_post_data(req, folder=folder, allow_excel=True, offset=0)

    L.info("new file created", file)
    file_path = file.get("filePath")

    return {"response": file_path}


async def actuarial_update(req, actuarial_id):
    """Given actuarial id will update the record

    Args:
        req (object): request object
        actuarial_id (int): actuarial id where it update actuarial data.

    Raises:
        ValueError: Invalid country name requested from api
        ValueError: Invalid segment name requested from api
        ValueError: Invalid actuarial type requested from api
        ValueError: Invalid actuarial status type- requested from api
        ValueError: actuarial not found for given id
        ValueError: There are no old actuarial file for given id

    Returns:
        dict: actuarial data returned
    """
    user_id = req.vars["metadata_d"]["user-id"]
    if not user_id:
        raise ValueError("Invalid Credentials; User not found.")
    L = request.vars["L"]
    folder = req.args.get("folder", "actuarialTypeFile")
    # if actuarial_type == "DecumulationLookUp":
    #     file = await decumulation_lookup_upload(request, req, folder=folder)
    # else:
    file = await process_post_data(req, folder=folder, allow_excel=True)
    L.info("new file created", file)
    file_path = file.get("filePath")
    data = json.loads(file["json"])
    actuarial_id = int(actuarial_id)
    segment = data.get("segment")
    country = data.get("country")
    name = data.get("name")
    actuarial_type = data.get("type")
    if actuarial_type in ["DecumulationLookUp", "GoalDiscoveryLookUp"]:
        if "filePath" in file:
            await lookup_upload(actuarial_id, file["filePath"][0], actuarial_type, req.vars["metadata_t"], req)

    actuarial_status = "Active"
    if file_path and file_path[0]:
        filePath = "%s-%s" % (file_path[0].get("folder"), file_path[0].get("file_id"))
    description = data.get("description")

    db = await db_con.get_access()
    country_result = await get_enums(table_name="country", name=country, as_dataframe=True)
    if country_result is None or country_result.empty:
        ValidationError.messages = "Invalid Country name"
        raise ValidationError

    segment_result = await get_enums(table_name="segment", name=segment, as_dataframe=True)
    if segment_result is None or segment_result.empty:
        ValidationError.messages = "Invalid Segment name"
        raise ValidationError

    actuarial_type_result = await get_enums(table_name="actuarial_type", name=actuarial_type, as_dataframe=True)
    if actuarial_type_result is None or actuarial_type_result.empty:
        ValidationError.messages = "Invalid type name"
        raise ValidationError

    actuarial_status_result = await get_enums(table_name="actuarial_status", name=actuarial_status, as_dataframe=True)
    if actuarial_status_result is None or actuarial_status_result.empty:
        ValidationError.messages = "Invalid status name"
        raise ValidationError
    actuarial_result = await get_enums(table_name="actuarial", table_id=actuarial_id, as_dataframe=True)
    if actuarial_result is None or actuarial_result.empty:
        ValidationError.messages = f"actuarial not found for given id {actuarial_id}"
        raise ValidationError
    actuarial_file_stmt = f"""SELECT "actuarial_file".* FROM public."actuarial_file"
        WHERE "actuarial_file"."actuarialId" = '{actuarial_id}';"""
    actuarial_file_result = await db.get_data(actuarial_file_stmt, as_dataframe=True)
    if actuarial_file_result is None or actuarial_file_result.empty:
        L.info(f"There are no old actuarial file for given id {actuarial_id}")
        operation = "CREATE"
    else:
        operation = "UPDATE"
        actuarial_old_file_data = {
            "name": actuarial_file_result["name"].iloc[0],
            "path": actuarial_file_result["path"].iloc[0],
            "actuarialId": actuarial_file_result["actuarialId"].iloc[0],
            "createdBy": actuarial_file_result["createdBy"].iloc[0],
            "updatedBy": actuarial_file_result["updatedBy"].iloc[0],
            "createdAt": actuarial_file_result["createdAt"].iloc[0],
            "updatedAt": actuarial_file_result["updatedAt"].iloc[0],
        }

        L.info(f"actuarial_old_file_data { actuarial_old_file_data}", extra=req.vars["metadata_d"])
    old_actuarial = actuarial_result.to_dict(orient="records")
    L.info(f"old actuarial {old_actuarial}", extra=req.vars["metadata_d"])
    # {
    #     "name": actuarial_result['name'].iloc[0],
    #     "description": actuarial_file_result['description'].iloc[0],
    #     "id": actuarial_file_result['id'].iloc[0],
    #     "createdBy": actuarial_result['createdBy'].iloc[0],
    #     "updatedBy": actuarial_result['updatedBy'].iloc[0],
    #     "createdAt": actuarial_result['createdAt'].iloc[0],
    #     "updatedAt": actuarial_result['updatedAt'].iloc[0]
    #     }
    # actuarial_table = METADATA.metadata.tables.get('actuarial')
    actuarial_request_data = {
        "segmentId": segment_result.id.values[0],
        "countryId": country_result.id.values[0],
        "description": description,
        "updatedBy": user_id,
        "name": name,
        "typeId": actuarial_type_result.id.values[0],
        "statusId": actuarial_status_result.id.values[0],
        "createdBy": user_id,
    }
    tables = await get_meta_data_for_tables(["actuarial", "actuarial_file"])
    Actuarial, ActuarialFile = tables["actuarial"], tables["actuarial_file"]
    db = await db_con.get_writer_access()
    engine = db.conn.engine
    actuarial_columns = Actuarial.columns.keys()
    async with engine.begin() as conn:
        actuarial_file_data = {
            "name": actuarial_type_result.name.values[0],
            "path": filePath,
            "createdBy": user_id,
            "updatedBy": user_id,
            "actuarialId": actuarial_file_result["actuarialId"].iloc[0] if operation == "UPDATE" else actuarial_id,
            "active": True,
        }

        if operation == "UPDATE":
            existing_actuarial_file = {
                "updatedBy": user_id,
                "active": False,
                "actuarialId": actuarial_file_result["actuarialId"].iloc[0],
                # "updatedAt":""
            }
            actuarial_file_update_stmt = (
                update(ActuarialFile)
                .where(or_(ActuarialFile.c.id == actuarial_file_result["id"].iloc[0], ActuarialFile.c.active == True))
                .values(**existing_actuarial_file)
                .returning(*ActuarialFile.columns)
            )
            actuarial_file_update = await conn.execute(actuarial_file_update_stmt)
            print(actuarial_file_update.fetchall())
            actuarial_file_data.update({"active": True})
            actuarial_file_stmt = insert(ActuarialFile).values(**actuarial_file_data).returning(*ActuarialFile.columns)

            actuarial_file = await conn.execute(actuarial_file_stmt)
            actuarial_file = actuarial_file.fetchall()
            actuarial_file = dict(zip(actuarial_columns, actuarial_file[0]))
            # request_meta_data = req.environ["request_meta_data"]
            # send_db_change_notification(request_meta_data, 'actuarial_file',
            # actuarialFile, oldActuarialFile, 'UPDATE');
        else:
            actuarial_file_data.update({"actuarialId": actuarial_id})
            actuarial_file_stmt = insert(ActuarialFile).values(**actuarial_file_data).returning(*ActuarialFile.columns)
            actuarial_file = await conn.execute(actuarial_file_stmt)
            # send_db_change_notification('actuarial_file', actuarialFile, null)
        stmt = (
            update(Actuarial)
            .where(Actuarial.c.id == actuarial_id)
            .values(**actuarial_request_data)
            .returning(*Actuarial.columns)
        )
        actuarial = await conn.execute(stmt)
        actuarial = actuarial.fetchall()
        actuarial = dict(
            zip(actuarial_columns, actuarial[0])
        )  # There will return one record must as it is insert else exception raised if input is wrong.
    request_meta_data = req.vars["metadata_t"]
    await send_db_change_notification(request_meta_data, "actuarial", actuarial, old_actuarial, "UPDATE")
    table = await actuarial_by_id(request_meta_data, actuarial_id, db_reader=False)  # connect to db writer instance
    return table


async def actuarial_get_names_with_filter(body):
    body = DictDefault(body)
    body = ActuarialGetNamesWithFilterBody(body.country, body.segment, body.type, body.status)
    stmt = """SELECT DISTINCT("actuarial"."name") AS name, "country"."name" AS country,
                "segment"."name" AS segment, "actuarial_type"."name" AS type,
                "actuarial_status"."name" AS "status"
            FROM public.actuarial
            INNER JOIN "country" ON "country"."id" = "actuarial"."countryId"
            INNER JOIN "segment" ON "segment"."id" = "actuarial"."segmentId"
            INNER JOIN "actuarial_type" ON "actuarial_type"."id" = "actuarial"."typeId"
            INNER JOIN "actuarial_status" ON "actuarial_status"."id" = "actuarial"."statusId"
            INNER JOIN "actuarial_file" ON "actuarial"."id" = "actuarial_file"."actuarialId"
            WHERE "actuarial_file"."active" IS NULL OR "actuarial_file"."active" IS true;"""
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    if result is None or result.empty:
        return {}
    if body.country:
        result = result[result["country"] == body.country]
    if body.segment:
        result = result[result["segment"] == body.segment]
    if body.type:
        result = result[result["type"] == body.type]
    if body.status:
        result = result[result["status"] == body.status]
    table = [{"name": col} for col in result["name"]]
    return json.dumps(table)


async def insert_record_into_one_table(table_name, **kwargs):
    db = await db_con.get_writer_access()
    METADATA = GenerateTables.generate_metadata()
    Table = METADATA.metadata.tables.get(table_name)
    engine = db.conn.engine
    columns = Table.columns.keys()
    async with engine.begin() as conn:
        stmt = insert(Table).values(**kwargs).returning(*Table.columns)
        result = await conn.execute(stmt)
    result = result.fetchall()
    result = dict(zip(columns, result[0]))
    return result


async def update_record_into_one_table(table_name, **kwargs):
    db = await db_con.get_writer_access()
    METADATA = GenerateTables.generate_metadata()
    Table = METADATA.metadata.tables.get(table_name)
    engine = db.conn.engine
    columns = Table.columns.keys()
    async with engine.begin() as conn:
        stmt = update(Table).where(Table.c.id == kwargs["id"]).values(**kwargs).returning(*Table.columns)
        result = await conn.execute(stmt)
    result = result.fetchall()
    result = dict(zip(columns, result[0]))
    return result


async def create_actuarial_status(body):
    if not isinstance(body.get("name"), str):
        target = {
            "target": body,
            "property": "name",
            "children": [],
            "constraints": {"isString": "name must be a string"},
        }
        BadRequestError.errors.append(target)
        raise BadRequestError
    if not body.get("description"):
        body["description"] = body.get("name")
    actuarial_status = await insert_record_into_one_table("actuarial_status", **body)
    return actuarial_status


async def create_actuarial_type(body):
    if not isinstance(body.get("name"), str):
        target = {
            "target": body,
            "property": "name",
            "children": [],
            "constraints": {"isString": "name must be a string"},
        }
        BadRequestError.errors.append(target)
        raise BadRequestError
    if not body.get("description"):
        body["description"] = body.get("name")
    actuarial_type = await insert_record_into_one_table("actuarial_type", **body)
    return actuarial_type


async def actuarial_get_names_with_custom_filter(body):
    """get actuarial names from actuarial table.

    Args:
        body (dict): api input request

    Returns:
        str: json result
    """
    body = DictDefault(body)
    body = ActuarialGetNamesWithFilterBody(body.country, body.segment, body.type, body.status)
    stmt = """SELECT DISTINCT("actuarial"."name") AS name, "country"."name" AS country,
                "segment"."name" AS segment, "actuarial_type"."name" AS type,
                "actuarial_status"."name" AS "status"
            FROM public."actuarial"
            INNER JOIN "country" ON "country"."id" = "actuarial"."countryId"
            INNER JOIN "segment" ON "segment"."id" = "actuarial"."segmentId"
            INNER JOIN "actuarial_type" ON "actuarial_type"."id" = "actuarial"."typeId"
            INNER JOIN "actuarial_status" ON "actuarial_status"."id" = "actuarial"."statusId"
            INNER JOIN "actuarial_file" ON "actuarial"."id" = "actuarial_file"."actuarialId"
            WHERE "actuarial_file"."active" IS NULL OR "actuarial_file"."active" IS true;"""
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    if body.country:
        result = result[result["country"] == body.country]

    if body.segment:
        result = result[result["segment"] == body.segment]
    if body.type:
        result = result[result["type"] == body.type]
    if body.status:
        result = result[result["status"] == body.status]
    table = [{"name": col.get("name"), "type": col.get("type")} for col in result.to_dict(orient="records")]
    return json.dumps(table)


async def get_user_statuses():
    """Get User status results from user_status table

    Returns:
        str: json result
    """
    # return await get_enums(table_name="user_status")
    return json.dumps(
        [
            {"name": UserStatus.ACTIVE.value},
            {"name": UserStatus.INACTIVE.value},
            # TODO: If Pending is required. need to see how to get it from uip
            # {"name": UserStatus.Pending.value}
        ]
    )


async def get_user_enums():
    data = await portfolio_bundle_enums()
    # roles = await get_enums(table_name="role")
    data = {
        "userCountries": data.get("countries"),
        "userSegments": data.get("Segments"),
        # TODO: roles will not be shown or should be hardcoded or get from access from doc db.
        # "roles": json.loads(roles),
        "portfolioBundleNames": data.get("portfolioBundleNames"),
    }
    return json.dumps(data)


async def get_roles():
    roles = await get_enums(table_name="role")
    return roles


async def get_users(request_meta_data, body):
    return await get_users_from_db(request_meta_data)


async def get_user(request_meta_data, body):
    """get user details for a given user id

    Args:
        req (object): request object
        body (dict): input received from api e.g {"id": uuid or oid}

    Returns:
        str: json result
    """
    doc_id = body.get("id")
    user_profile_doc = await get_user_from_db(request_meta_data, doc_id)
    if not user_profile_doc:
        return {}

    # if user_profile_doc.get("createdBy"):
    #     created_by_user_doc_id = user_profile_doc.get("createdBy")
    #     user_created_profile_doc = await get_user_from_db(request_meta_data, created_by_user_doc_id)
    #     user_profile_doc["createdBy"] = user_created_profile_doc

    body = [user_profile_doc]
    return await get_users_data(body, includeCountriesAndSegments=True)


async def portfolio_bundle_get_names_with_filter(body):
    """Get portfolio bundle names

    Returns:
        str: json result
    """
    params = {
        "country_name": body.get("country"),
        "segment_name": body.get("segment"),
    }
    results = await _get_portfolio_bundle(params)
    return json.dumps(results)


async def get_config(user_id, request_meta_data):
    """Get config for a given user_id"""
    if not user_id or not isinstance(user_id, str) or user_id.strip() == "":
        ValidationError.messages = "User id is not a valid value. Please make sure it is not an empty string \
            with no trailing or leading white spaces."
        raise ValidationError
    target_user = await get_user_from_oid(user_id, request_meta_data)
    res = {"data": target_user, "file_type": "text/plain", "file_name": f"user-{user_id}-config"}
    return res


async def goe_api_end_points():
    """Get api end point list for goe."""
    goe_configs = MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppZoneSettings(
            request=rest_pb2.AppSettingsRequest(app="goe", zone="client-settings"),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    goe_configs = json.loads(goe_configs)
    goe_api_list = goe_configs.get("goe_client_apis_list")
    return goe_api_list


class Body:
    def __init__(self, take: int = 0, skip: int = 0, sortKey: str = "id", sortDirection: str = "ASC"):
        if type(take) is not int:
            ValidationError.messages = "take should be int"
            raise ValidationError
        if type(skip) is not int:
            ValidationError.messages = "skip should be int"
            raise ValidationError
        self.take = None if take <= 0 else take
        self.skip = None if skip <= 0 else skip
        self.sortKey = "id" if sortKey is None else sortKey
        self.sortDirection = (
            "DESC" if (sortDirection is None or sortDirection.upper() not in ["ASC", "DESC"]) else sortDirection.upper()
        )


class ActuarialGetNamesWithFilterBody:
    def __init__(self, country: str, segment: str, type: str, status: str):
        if country is not None and not isinstance(country, str):
            raise ValueError("country is not valid")
        if segment is not None and not isinstance(segment, str):
            raise ValueError("segment is not valid")
        if type is not None and not isinstance(type, str):
            raise ValueError("type is not valid")
        if status is not None and not isinstance(status, str):
            raise ValueError("status is not valid")
        self.country = country
        self.segment = segment
        self.type = type
        self.status = status
