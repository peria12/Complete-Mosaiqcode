import json
import uuid
import re
import datetime
import uip_grpc

import rest_pb2_grpc
import rest_pb2

from dateutil.relativedelta import relativedelta

from collections import abc
from collections import namedtuple
from collections import Counter
import pandas as pd

from quart import abort, request

from goelib.errors import UserConfigNotFoundException, ValidationError
from goelib.api.shared.user_utils import get_user_profile, has_greater_precision
from goelib.api.shared.common import (
    genericResponse,
    generateMortalityPayload,
    generatePipePayload,
    isDateFormatValid,
    DictDefault,
    validateDates,
    isDateFormatValidV1,
    is_valid_format_mmyyyy,
    validateRequiredDataCheck,
    generateGlidePathData,
    generatePortfolioMappingData,
    generateTranslatorPayload,
    generateTaxLiabilityPayload,
    generateReplacementCalculatorPayload,
    generateReplacementCalcData,
    calculateAge,
    getDataTablesforGOETaxes,
    getDataTablesforGOESimulationEngine,
    read_actuarial_files,
    generate_decumulation_payload,
    getDataTablesforDecumulation,
    get_decumulation_uploads,
    generateFixedDiscretionaryCalculatorPayload,
    getDataTablesforDiscretionaryCalculator,
    generateGoalSimulationPayload,
    get_data_tables_for_age_based_equity,
    generateCustomPortfolioPayload,
    getDataTablesforCustomPortfolio,
)
from goelib.api.shared.wealthsplit import (
    generateWealthSplitterPayload,
    validateWealthSplitterPayloadV3,
)
from goelib.api.shared.validate_risk_profile import validateIfRiskProfileisRiskProfileValid
from goelib.api.shared.advisor_engine_utils import (
    validateAdvisorEnginePayload,
    generateAdvisorEnginePayload,
    generateAdvisorEnginePayload_v4,
)
from goelib.api.shared.case_conversion import convertToCamelCase
from goelib.api.shared.historical_live_scenarios_utils import (
    validateHistoricalLiveScenariosPayload,
    generateHistoricalLiveScenariosPayload,
)
from goelib.api.resources.common import prepare_portfolio

from google.protobuf.json_format import MessageToDict

grpc_channels = uip_grpc.GRPC(async_mode=True)


def getCaseInSensitiveRiskProfileMapping(portfolioMapping):
    newMapping = {}
    for key in portfolioMapping:
        lowerCasedKey = key.toLowerCase()
        newMapping[lowerCasedKey] = portfolioMapping[key]
    return newMapping


def validateRunPipePayloadV3dot8(payload):
    infusionType = payload.infusionType
    scenarioType = payload.scenarioType
    isNearTermVolatility = payload.isNearTermVolatility
    cashflowDate = payload.cashflowDate
    isNewGoal = payload.isNewGoal
    isNewRiskProfile = payload.isNewRiskProfile
    isNewGoalPriority = payload.isNewGoalPriority
    engagedParticipant = payload.engagedParticipant
    reallocationFreq = payload.reallocationFreq
    if infusionType not in ["yearly", "monthly"]:
        return {
            "isValid": False,
            "message": "infusionType must be one of yearly or monthly.",
        }
    if scenarioType not in ["retirement", "regular"]:
        return {
            "isValid": False,
            "message": "scenarioType must be one of retirement or regular",
        }
    # isNearTermVolatility is optional and if provided should be boolean
    if "isNearTermVolatility" in payload and (
        isNearTermVolatility is not None and type(isNearTermVolatility) is not bool
    ):
        return {
            "isValid": False,
            "message": "isNearTermVolatility must be a boolean.",
        }
    if "cashflowDate" in payload and cashflowDate is not None and not isDateFormatValid(cashflowDate):
        return {
            "isValid": False,
            "message": "cashflowDate must be in ISO date format or null.",
        }
    if type(isNewGoalPriority) is not bool:
        return {"isValid": False, "message": "isNewGoalPriority must be a boolean."}
    if type(isNewGoal) is not bool:
        return {
            "isValid": False,
            "message": "isNewGoal must be a boolean.",
        }
    if type(isNewRiskProfile) is not bool:
        return {"isValid": False, "message": "isNewRiskProfile must be a boolean"}
    if engagedParticipant is not None and not isinstance(engagedParticipant, bool):
        return {
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true",
        }
    if reallocationFreq is None or reallocationFreq not in ["yearly", "half-yearly", "quarterly"]:
        return {
            "isValid": False,
            "message": "reallocationFreq is a mandatory field and has to be one of yearly, half-yearly or quarterly",
        }
    if "lastReallocationDate" in payload and not isDateFormatValid(payload.lastReallocationDate):
        return {
            "isValid": False,
            "message": "lastReallocationDate is optional if provided should follow format dd-mm-yyyy.",
        }
    return {"isValid": True, "message": None}


def validateRunPipePayload(payload, version="2", req_type=None):
    calibrateRecommendations = payload.calibrateRecommendations
    lastReallocatedDate = payload.lastReallocatedDate
    isNewRTQ = payload.isNewRTQ
    isNewInvestmentTenure = payload.isNewInvestmentTenure
    isNearTermVolatility = payload.isNearTermVolatility
    goalAmount = payload.goalAmount
    initialInvestment = payload.initialInvestment
    infusions = payload.infusions
    startDate = payload.startDate
    currDate = payload.currDate
    endDate = payload.endDate
    currentWealth = payload.currentWealth
    currentPortfolioId = payload.currentPortfolioId if "currentPortfolioId" in payload else False
    getPath = payload.getPath
    goalPriority = payload.goalPriority
    bequestPriority = payload.bequestPriority
    infusion_type = payload.infusion_type
    scenario_type = payload.scenario_type
    cashflowDate = payload.cashflowDate
    isNewGoalPriority = payload.isNewGoalPriority
    considerMortality = payload.considerMortality
    currentAge = payload.currentAge
    retirementAge = payload.retirementAge
    riskOverride = payload.riskOverride
    reallocate = payload.reallocate

    engagedParticipant = payload.engagedParticipant
    lossThreshold = payload.lossThreshold
    rebalancing = payload.rebalancing
    if version == "4":
        result3dot8 = DictDefault(validateRunPipePayloadV3dot8(payload))
        if not result3dot8.isValid:
            return result3dot8
    else:
        if infusion_type not in ["yearly", "monthly"]:
            return {
                "isValid": False,
                "message": "infusion_type must be one of yearly or monthly.",
            }
        if scenario_type not in ["retirement", "regular"]:
            return {
                "isValid": False,
                "message": "scenario_type must be one of retirement or regular",
            }
        if type(isNearTermVolatility) is not bool:
            return {
                "isValid": False,
                "message": "isNearTermVolatility must be a boolean.",
            }

        if type(isNewRTQ) is not bool:
            return {"isValid": False, "message": "isNewRTQ must be a boolean."}

    if version not in ["3", "4"]:
        if type(lastReallocatedDate) is not str or not isDateFormatValid(lastReallocatedDate):
            return {
                "isValid": False,
                "message": "Valid lastReallocationDate range is between 1-01-1800 to 31-12-2399",
            }

    if version == "3":
        if "cashflowDate" in payload and cashflowDate is not None and not isDateFormatValid(cashflowDate):
            return {
                "isValid": False,
                "message": "cashFlowDate can be null or can be between 1-01-1800 to 31-12-2399",
            }

    if version == "3":
        if type(isNewGoalPriority) is not bool:
            return {
                "isValid": False,
                "message": "isNewGoalPriority must be a boolean.",
            }
    if type(isNewInvestmentTenure) is not bool:
        return {
            "isValid": False,
            "message": "isNewInvestmentTenure must be a boolean.",
        }
    if version == "4":
        if req_type != "goalcalculator":
            if type(goalAmount) not in [float, int] or goalAmount < 0:
                return {
                    "isValid": False,
                    "message": "goalAmount must be a number.",
                }
        if req_type == "goalcalculator":
            if payload.scenarioType == "regular" and "goalAmount" in payload and payload.goalAmount != 0:
                return {
                    "isValid": False,
                    "message": "goalAmount is optional if provided must be 0 when scenarioType is regular.",
                }
            if payload.scenarioType == "retirement" and "goalAmount" in payload and not (payload.goalAmount >= 0):
                return {
                    "isValid": False,
                    "message": "goalAmount is optional if provided must be greater than 0 when scenarioType is retirement.",
                }
            if "stepupDate" in payload and (
                not isinstance(payload.stepupDate, str) or not isDateFormatValid(payload.stepupDate)
            ):
                return {
                    "isValid": False,
                    "message": "Valid date range for stepupDate should be between 1-01-1800 to 31-12-2399.",
                }

    if type(initialInvestment) not in [float, int] or initialInvestment < 0:
        return {
            "isValid": False,
            "message": "initialInvestment must be a number greater than or equal to 0.",
        }
    if infusions is None:
        return {
            "isValid": False,
            "message": "infusions must be a list of numbers",
        }
    if isinstance(infusions, abc.MutableSequence):  # TOCHECK
        for i in infusions:
            if type(i) not in (float, int):
                return {
                    "isValid": False,
                    "message": "Error in infusions {0}, infusion must be an number.".format(i),
                }
    if not isinstance(startDate, str) or not isDateFormatValid(startDate):
        return {
            "isValid": False,
            "message": "Valid date range for startDate should be between 1-01-1800 to 31-12-2399.",
        }

    if "currDate" in payload and (not isinstance(currDate, str) or not isDateFormatValid(currDate)):
        return {"isValid": False, "message": "Valid date range for currDate should be between 1-01-1800 to 31-12-2399."}

    if not isinstance(endDate, str) or not isDateFormatValid(endDate):
        return {
            "isValid": False,
            "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399",
        }
    # currentWealth is mandatory and accepts null or number
    if "currentWealth" not in payload or (
        currentWealth is not None and (type(currentWealth) not in (float, int) or currentWealth < 0)
    ):
        return {
            "isValid": False,
            "message": "currentWealth must be a number greater or equal 0 or null",
        }
    if currentPortfolioId is not None and (
        currentPortfolioId is False
        or (type(currentPortfolioId) == int and currentPortfolioId < 0)
        or type(currentPortfolioId) not in [int]
    ):
        return {
            "isValid": False,
            "message": "currentPortfolioId must be an integer or null.",
        }
    if not isinstance(getPath, bool):
        return {
            "isValid": False,
            "message": "getPath must be a boolean.",
        }
    if goalPriority not in ["Need", "Want", "Wish", "Dream"]:
        return {
            "isValid": False,
            "message": "goalPriority must be one of Need, Want, Wish, and Dream.",
        }

    if bequestPriority is not None and bequestPriority not in ["Need", "Want", "Wish", "Dream"]:
        return {
            "isValid": False,
            "message": "bequestPriority must be one of Need, Want, Wish, and Dream or null.",
        }
    if considerMortality is not None and not type(considerMortality) is bool:
        return {
            "isValid": False,
            "message": "considerMortality must be a boolean. When not specificed, default value is false",
        }
    if currentAge is not None and (type(currentAge) is not int or currentAge < 0):
        return {
            "isValid": False,
            "message": "currentAge must be an integer or null.",
        }
    if retirementAge is not None and (type(retirementAge) is not int or retirementAge < 0):
        return {
            "isValid": False,
            "message": "retirementAge must be an integer or null.",
        }
    if riskOverride is not None and type(riskOverride) is not bool:
        return {
            "isValid": False,
            "message": "riskOverride must be a boolean. When not specificed, default value is false",
        }
    if calibrateRecommendations is not None and type(calibrateRecommendations) is not bool:
        return {
            "isValid": False,
            "message": "calibrateRecommendations must be a boolean. When not specificed, default value is false",
        }
    if "reallocate" in payload and type(reallocate) is not bool:
        return {
            "isValid": False,
            "message": "reallocate must be a boolean. When not specificed, default value is false",
        }
    if engagedParticipant is not None and not isinstance(engagedParticipant, bool):
        return {
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true",
        }
    if (
        "lossThreshold" in payload
        and payload.lossThreshold is not None
        and (type(lossThreshold) not in [float, int] or lossThreshold < 0)
    ):
        return {
            "isValid": False,
            "message": "lossThreshold must be a number greater than equal to 0 or null",
        }
    if payload.participantID is not None and type(payload.participantID) not in [str]:
        return {
            "isValid": False,
            "message": "participantID must be a alphanumeric.",
        }
    if isinstance(payload.participantID, str) and not payload.participantID.isalnum():
        return {
            "isValid": False,
            "message": "participantID must be a alphanumeric.",
        }
    if payload.planID is not None and type(payload.planID) not in [str]:
        return {
            "isValid": False,
            "message": "planID must be a alphanumeric.",
        }
    if isinstance(payload.planID, str) and not payload.planID.isalnum():
        return {
            "isValid": False,
            "message": "planID must be a alphanumeric.",
        }
    if payload.sourceID is not None and type(payload.sourceID) not in [str]:
        return {
            "isValid": False,
            "message": "sourceID must be a alphanumeric.",
        }
    if isinstance(payload.sourceID, str) and not payload.sourceID.isalnum():
        return {
            "isValid": False,
            "message": "sourceID must be a alphanumeric.",
        }
    if (
        "lastReallocationProbability" in payload
        and payload.lastReallocationProbability is not None
        and (
            type(payload.lastReallocationProbability) not in [float, int]
            or not (0 <= payload.lastReallocationProbability <= 0.99)
        )
    ):
        return {
            "isValid": False,
            "message": "lastReallocationProbability must be float and between 0 and 0.99.",
        }
    if "wealthPathProbabilities" in payload and payload.wealthPathProbabilities is not None:
        if (
            not isinstance(payload.wealthPathProbabilities, abc.MutableSequence)
            or len(payload.wealthPathProbabilities) != 2
        ):
            return {"isValid": False, "message": "wealthPathProbabilities must be array of length 2."}
        for wealth in payload.wealthPathProbabilities:
            if type(wealth) not in [int, float] or not (0 <= wealth <= 1):
                return {
                    "isValid": False,
                    "message": "value in wealthPathProbabilities should be integer or float"
                    " and should be between 0 and 1.",
                }
    # if "useAgeBasedCap" in payload and type(payload.useAgeBasedCap) != bool:
    #     return {"isValid": False, "message": "useAgeBasedCap must be boolean."}
    if "inflation" in payload and (
        (payload.inflation is not None and type(payload.inflation) not in [int, float])
        or (payload.inflation is not None and not (0 <= payload.inflation <= 1))
    ):
        return {"isValid": False, "message": "inflation must be number between 0 and 1 or should be null."}
    dateValidation = DictDefault(validateDates(startDate, endDate, currDate))
    if not dateValidation.isValid:
        return dateValidation
    if version == "3":
        if rebalancing is None or rebalancing not in ["yearly", "half-yearly", "quarterly"]:
            return {
                "isValid": False,
                "message": "rebalancing is a mandatory field and has to be one of yearly, half-yearly or quarterly",
            }
    return {
        "isValid": True,
        "message": None,
    }


def goe_api_response_handler(logData, version):
    def wrapper(pipe_result):
        res = None
        if isinstance(pipe_result, str):  # if pipe result is json string convert it. else not required
            pipe_result = json.loads(pipe_result)
        data, statusCode = pipe_result.get("data"), pipe_result.get("statusCode")
        pipeMessage = pipe_result.get("message")
        if pipe_result.get("outputObject"):
            data = pipe_result.get("outputObject").get("data")
            statusCode = pipe_result.get("outputObject").get("statusCode")
            pipeMessage = pipe_result.get("outputObject").get("message")
        if not (statusCode in [200, 200.0]):
            message = "Internal Server Error"
            data = "Unexpected error: Please contact FT GOE Business team."
            if statusCode != 500:
                statusCode = 400
                message = "Validation Error"
                data = pipeMessage
            json_data = {
                "logData": logData,
                "statusCode": statusCode,
                "message": message,
                "body": data,
            }
            if pipe_result.get("outputObject"):
                json_data.update({"requestId": pipe_result.get("requestId")})
            return genericResponse(
                res,
                json_data,
            )
        data = json.loads(data)
        if version in ["4", "v4"]:
            data = convertToCamelCase(data)
        json_data = {
            "logData": logData,
            "statusCode": int(statusCode),
            "message": "Success",
            "body": data,
        }
        if pipe_result.get("outputObject"):
            json_data.update({"requestId": pipe_result.get("requestId")})
        return genericResponse(
            res,
            json_data,
        )

    return wrapper


async def pipe_controller_run_wealth_splitter(request, req, body, res=None):
    """Runs wealth splitter api."""
    L = request.state.vars["L"]
    ptf = await prepare_portfolio(req, body, request)
    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    config = DictDefault(config)
    if not config:
        raise UserConfigNotFoundException
    body = DictDefault(body)
    req = DictDefault(req)
    version = "lts"
    if req.headers.get("version") and type(req.headers.get("version")) is str:
        version = req.headers.get("version")
        body.debug = False
    if req.headers.get("debug") == "true":
        body.debug = True
    validate_wealth_splitter_payload = validateWealthSplitterPayloadV3(body, version)
    isValid = validate_wealth_splitter_payload.get("isValid")
    message = validate_wealth_splitter_payload.get("message")
    L.info(f"validate_wealth_splitter_payload----------------{isValid}, {message}")
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v3/runWealthSplitter",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    if not isValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
        )
    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage")
    L.info(f"validateIfRiskProfileisRiskProfileValid------------- {isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
        )
    actuarialData = {}
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(
            body, config, request_type="iws", request=request
        )
        if age_based_equity_data:
            actuarialData.update(age_based_equity_data["actuarialData"])
    actuarialData = DictDefault(actuarialData)

    wealth_splitter_pay_load_response = generateWealthSplitterPayload(
        body, config, portfolios, actuarialData, version, ptf=ptf
    )
    error = wealth_splitter_pay_load_response.get("error")
    wealthSplitterPayload = wealth_splitter_pay_load_response.get("data")
    L.info(f"wealthSplitterPayload ------------------------------ {error}")
    if error:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": error, "data": None},
        )
    L.info("final pay load generated ------------------------------")
    if generatePayloadOnly:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 200, "message": "Success", "data": wealthSplitterPayload},
        )
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v3/runWealthSplitter",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    handler = goe_api_response_handler(logData, version)
    return (wealthSplitterPayload, handler)


# @Post('/v2/unifiedPortfolioAdvice')
async def pipe_serverless_controller_run_advisor_engine(req, body, res=None):
    """Run advisor engine

    :rtype: generator object
    """
    L = request.vars["L"]
    ptf = await prepare_portfolio(req, body)
    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    body = ptf.get("body")
    body = DictDefault(body)
    currentPortfolioId = body.currentPortfolioId
    portfoliosRiskOn = ptf.get("portfoliosRiskOn")
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v2/unifiedPortfolioAdvice",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    if currentPortfolioId is not None and (
        (type(currentPortfolioId) == int and (currentPortfolioId < 0 or currentPortfolioId > len(portfoliosRiskOn)))
        or type(currentPortfolioId) not in [int]
    ):
        return genericResponse(
            res,
            {
                "logData": logData,
                "statusCode": 400,
                "message": "CurrentPortfolioId must be a positive integer not greater than the number of portfolios",
                "data": None,
            },
        )
    validate_advisor_engine_payload = validateAdvisorEnginePayload(body)
    isValid = validate_advisor_engine_payload.get("isValid")
    message = validate_advisor_engine_payload.get("message")
    L.info(f"validate_advisor_engine_payload---------------- {isValid}, {message}")
    if not isValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
        )

    config = DictDefault(config)
    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    L.info(f"validateIfRiskProfileisRiskProfileValid-------------{isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
        )
    actuarialData = {}
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(body, config)
        if age_based_equity_data:
            actuarialData.update(age_based_equity_data["actuarialData"])
    actuarialData = DictDefault(actuarialData)
    advisor_engine_pay_load_response = generateAdvisorEnginePayload(
        body, config, portfolios, actuarialData, "lts", ptf=ptf
    )
    error = advisor_engine_pay_load_response.get("error")
    pipePayload = advisor_engine_pay_load_response.get("data")
    L.info(f"generateAdvisorEnginePayload ------------------------------ {error}")
    if error:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": error, "data": None},
        )
    if generatePayloadOnly:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 200, "message": "Success", "data": pipePayload},
        )
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v2/unifiedPortfolioAdvice",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    handler = goe_api_response_handler(logData, None)
    return (pipePayload, handler)


async def pipe_serverless_controller_run_advisor_engine_v2(req, body, res=None):  # noqa: E501
    """Run advisor engine v 3

     # noqa: E501

    :param body:
    :type body: dict | bytes

    :rtype: None
    """

    L = request.vars["L"]
    ptf = await prepare_portfolio(req, body)
    # user = ptf.get("user")
    config = ptf.get("config")
    body = ptf.get("body")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    body = DictDefault(ptf.get("body"))
    currentPortfolioId = body.currentPortfolioId
    # userConfigPortfolioArray = user.portfolio_bundle.portfolios
    portfoliosRiskOn = ptf.get("portfoliosRiskOn")
    portfolios = ptf.get("portfolios")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    requestId = "{}".format(uuid.uuid4())
    if not body.request_id:
        body.request_id = requestId
    headers = req.get("headers")
    version = "4"

    req = DictDefault(req)

    body.debug = False
    if headers.get("debug") == "true":
        body.debug = True

    # maximumIndexShortTermPortfolios = max(shortTermGoalProfiles)
    currentPortfolioId = body.currentPortfolioId
    # userConfigPortfolioArray = user.portfolio_bundle.portfolios
    portfoliosRiskOn = ptf.get("portfoliosRiskOn")
    portfolios = ptf.get("portfolios")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v3/unifiedPortfolioAdvice",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    if currentPortfolioId is not None and (
        (type(currentPortfolioId) == int and (currentPortfolioId < 0 or currentPortfolioId > len(portfoliosRiskOn)))
        or type(currentPortfolioId) not in [int]
    ):
        return genericResponse(
            res,
            {
                "logData": logData,
                "statusCode": 400,
                "message": "CurrentPortfolioId must be a positive integer not greater than the number of portfolios",
                "data": None,
            },
        )

    validate_advisor_engine_payload = validateAdvisorEnginePayload(body, version)
    isValid = validate_advisor_engine_payload.get("isValid")
    message = validate_advisor_engine_payload.get("message")
    L.info(f"validate_advisor_engine_payload---------------- {isValid}, {message}")
    if not isValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
        )
    config = DictDefault(config)

    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    L.info(f"validateIfRiskProfileisRiskProfileValid------------- {isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
        )
    actuarialData = {}
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(body, config)
        if age_based_equity_data:
            actuarialData.update(age_based_equity_data["actuarialData"])
    actuarialData = DictDefault(actuarialData)

    advisor_engine_pay_load_response = generateAdvisorEnginePayload(
        body, config, portfolios, actuarialData, version, ptf=ptf
    )
    error = advisor_engine_pay_load_response.get("error")
    pipePayload = advisor_engine_pay_load_response.get("data")
    L.info(f"generateAdvisorEnginePayload {error}")

    if error:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": error, "data": None},
        )
    if generatePayloadOnly:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 200, "message": "Success", "data": pipePayload},
        )

    handler = goe_api_response_handler(logData, version)
    return (pipePayload, handler)


async def pipe_serverless_controller_run_advisor_engine_v4(request, req, body, res=None):  # noqa: E501
    """Run advisor engine v 4

     # noqa: E501
    :param request: Request Object
    :param body:
    :type body: dict | bytes

    :rtype: None
    """

    L = request.state.vars["L"]
    ptf = await prepare_portfolio(req, body, request)
    # user = ptf.get("user")
    config = ptf.get("config")
    body = ptf.get("body")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    body = DictDefault(ptf.get("body"))
    currentPortfolioId = body.currentPortfolioId
    # userConfigPortfolioArray = user.portfolio_bundle.portfolios
    portfoliosRiskOn = ptf.get("portfoliosRiskOn")
    portfolios = ptf.get("portfolios")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    requestId = "{}".format(uuid.uuid4())
    if not body.request_id:
        body.request_id = requestId
    headers = req.get("headers")
    version = "v4"

    req = DictDefault(req)

    body.debug = False
    if headers.get("debug") == "true":
        body.debug = True
    body.detailedResponse = True
    if "detailedResponse" in headers and headers.get("detailedResponse") != "true":
        body.detailedResponse = False
    # maximumIndexShortTermPortfolios = max(shortTermGoalProfiles)
    currentPortfolioId = body.currentPortfolioId
    # userConfigPortfolioArray = user.portfolio_bundle.portfolios
    portfoliosRiskOn = ptf.get("portfoliosRiskOn")
    portfolios = ptf.get("portfolios")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v4/unifiedPortfolioAdvice",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    if currentPortfolioId is not None and (
        (type(currentPortfolioId) == int and (currentPortfolioId < 0 or currentPortfolioId > len(portfoliosRiskOn)))
        or type(currentPortfolioId) not in [int]
    ):
        return genericResponse(
            res,
            {
                "logData": logData,
                "statusCode": 400,
                "data": "CurrentPortfolioId must be a positive integer not greater than the number of portfolios",
                "message": "Validation Error",
            },
        )

    validate_advisor_engine_payload = validateAdvisorEnginePayload(body, version)
    isValid = validate_advisor_engine_payload.get("isValid")
    message = validate_advisor_engine_payload.get("message")
    L.info(f"validate_advisor_engine_payload---------------- {isValid}, {message}")
    if not isValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
        )
    config = DictDefault(config)

    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    L.info(f"validateIfRiskProfileisRiskProfileValid------------- {isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
        )
    actuarialData = {}
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(
            body, config, request_type="UPA", req=request
        )
        if age_based_equity_data:
            actuarialData.update(age_based_equity_data["actuarialData"])
    actuarialData = DictDefault(actuarialData)
    advisor_engine_pay_load_response = generateAdvisorEnginePayload_v4(
        body, config, portfolios, actuarialData, version, ptf=ptf
    )
    error = advisor_engine_pay_load_response.get("error")
    pipePayload = advisor_engine_pay_load_response.get("data")
    L.info(f"generateAdvisorEnginePayload {error}")

    if error:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": error, "data": None},
        )
    if generatePayloadOnly:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 200, "message": "Success", "data": pipePayload},
        )

    handler = goe_api_response_handler(logData, version)
    return (pipePayload, handler)


async def pipe_serverless_controller_run_pipe_version3(req, body, request=None):  # noqa: E501
    """Run pipe version 3
     # noqa: E501
    :param body:
    :type body: dict | bytes
    :rtype: None
    """
    L = request.vars["L"]
    res = None
    ptf = await prepare_portfolio(req, body, request)

    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    user = ptf.get("user")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    user = DictDefault(user)
    clientId = user.id
    config = user.config
    name = user.name
    email = user.email
    body = DictDefault(body)
    version = "3"
    req = DictDefault(req)
    if req.headers.get("version") == "4":
        version = req.headers.get("version")
    body.debug = False
    if req.headers.get("debug") == "true":
        body.debug = True
    valid_require_data_check = await validateRequiredDataCheck(body)
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v3/runPipe",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }

    if not valid_require_data_check.get("isValid"):
        return genericResponse(
            res,
            {
                "logData": logData,
                "statusCode": 400,
                "message": "Validation Error",
                "data": valid_require_data_check.get("message"),
            },
        )
    if "requiredDataAvailable" not in body:
        body.requiredDataAvailable = True
        required_data_available = True
    else:
        required_data_available = body.requiredDataAvailable
    if required_data_available is False:
        isValid, message = True, None
    else:
        isValid, message = validateRunPipePayload(body, version).values()

    if not isValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
        )
    config = DictDefault(config)
    if required_data_available is False:
        isRiskProfileValid, riskProfileErrorMessage = True, None
    else:
        isRiskProfileValid, riskProfileErrorMessage = validateIfRiskProfileisRiskProfileValid(
            config.portfolioConfig, body
        ).values()

    if not isRiskProfileValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
        )
    glide_path_data = await generateGlidePathData(body, config, request_type="runpipe", req=request)
    _data = await generateMortalityPayload(body, config, request_type="runpipe", req=request)
    _data = DictDefault(_data)
    actuarialData, considerMortality = _data.actuarialData, _data.considerMortality
    body.considerMortality = considerMortality
    if glide_path_data:
        actuarialData.update(glide_path_data["actuarialData"])
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(
            body, config, request_type="runpipe", req=request
        )
        if age_based_equity_data:
            actuarialData.update(age_based_equity_data["actuarialData"])
    pipe_payload = generatePipePayload(body, config, portfolios, actuarialData, version, ptf=ptf, request=request)

    error = pipe_payload.get("error")
    pipePayload = pipe_payload.get("data")
    L.info(f"{error}, generatePipePayload passed")
    if error:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": error, "data": None},
        )
    if generatePayloadOnly:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 200, "message": "Success", "data": pipePayload},
        )
    handler = goe_api_response_handler(logData, version)

    # with open("pipe_run_payload.json", "rb") as f:
    #     pipePayload = f.read()

    return (pipePayload, handler)


# @Post('/v1/historicalLiveScenarios/callback')
async def pipe_serverless_controller_historical_live_scenarios(req, body, res=None):
    requestId = str(uuid.uuid4())
    ptf = await prepare_portfolio(req, body)

    user = ptf.get("user")
    sourceIp = ptf.get("sourceIp")
    portfolios = ptf.get("portfolios")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    user = DictDefault(user)
    clientId = user.id
    config = user.config
    name = user.name
    email = user.email
    # config_json = json.loads(config).get("portfolioConfig").get("portfolioConfig")
    body = DictDefault(body)
    version = "3"
    req = DictDefault(req)
    if req.headers.get("version") and type(req.headers.get("version")) is str:
        version = req.headers.get("version")
    body.debug = False
    if req.headers.get("debug") == "true":
        body.debug = True
    validate_historical_live_pay_load = validateHistoricalLiveScenariosPayload(body, version)
    isValid = validate_historical_live_pay_load.get("isValid")
    message = validate_historical_live_pay_load.get("message")
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v1/historicalLiveScenarios",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    if not isValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
        )
    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    if not isRiskProfileValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
        )

    actuarialData = {}
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(body, config)
        if age_based_equity_data:
            actuarialData.update(age_based_equity_data["actuarialData"])
    actuarialData = DictDefault(actuarialData)

    generate_historical_live_scenarios_pay_load = generateHistoricalLiveScenariosPayload(
        body, config, portfolios, actuarialData, version, ptf=ptf
    )
    error = generate_historical_live_scenarios_pay_load.get("error")
    pipePayload = generate_historical_live_scenarios_pay_load.get("data")
    if error:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": error, "data": None},
        )
    if generatePayloadOnly:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 200, "message": "Success", "data": pipePayload},
        )
    pipePayload.requestId = requestId
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/v1/historicalLiveScenarios",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    handler = goe_api_response_handler(logData, version)
    return (pipePayload, handler)


def pipe_serverless_historical_live_scenarios_get_status(req, body):
    """connect to mongodb specific table with request id and fetch status of that req"""
    raise NotImplementedError


async def goal_calculator_api(request, req, body, res=None):  # noqa: E501
    L = request.state.vars["L"]
    ptf = await prepare_portfolio(req, body)
    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    user = ptf.get("user")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    user = DictDefault(user)
    clientId = user.id
    config = user.config
    name = user.name
    email = user.email
    body = DictDefault(body)
    version = "4"
    req = DictDefault(req)
    body.debug = False
    if req.headers.get("debug") == "true":
        body.debug = True
    valid_require_data_check = await validateRequiredDataCheck(body)
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/goalcalculator",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }

    if not valid_require_data_check.get("isValid"):
        return genericResponse(
            res,
            {
                "logData": logData,
                "statusCode": 400,
                "message": "Validation Error",
                "data": valid_require_data_check.get("message"),
            },
        )
    if "requiredDataAvailable" not in body:
        body.requiredDataAvailable = True
        required_data_available = True
    else:
        required_data_available = body.requiredDataAvailable
    if required_data_available is False:
        isValid, message = True, None
    else:
        isValid, message = validateRunPipePayload(body, version, req_type="goalcalculator").values()

    if not isValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
        )
    config = DictDefault(config)
    if required_data_available is False:
        isRiskProfileValid, riskProfileErrorMessage = True, None
    else:
        isRiskProfileValid, riskProfileErrorMessage = validateIfRiskProfileisRiskProfileValid(
            config.portfolioConfig, body
        ).values()

    if not isRiskProfileValid:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
        )
    glide_path_data = await generateGlidePathData(body, config, request_type="goalcal", req=request)
    _data = await generateMortalityPayload(body, config, request_type="goalcal", req=request)
    _data = DictDefault(_data)
    actuarialData, considerMortality = _data.actuarialData, _data.considerMortality
    body.considerMortality = considerMortality
    if glide_path_data:
        actuarialData.update(glide_path_data["actuarialData"])
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(
            body, config, request_type="goalcal", req=request
        )
        if age_based_equity_data:
            actuarialData.update(age_based_equity_data["actuarialData"])

    pipe_payload = generatePipePayload(body, config, portfolios, actuarialData, version, ptf)
    error = pipe_payload.get("error")
    pipePayload = pipe_payload.get("data")
    L.info(f"{error}, generatePipePayload passed")
    if error:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 400, "message": error, "data": None},
        )
    if generatePayloadOnly:
        return genericResponse(
            res,
            {"logData": logData, "statusCode": 200, "message": "Success", "data": pipePayload},
        )
    handler = goe_api_response_handler(logData, version)
    return (pipePayload, handler)


def validate_translator_investments(investments, investment_type):
    assets_under_management = investments.assetsUnderManagement
    if (
        "assetsUnderManagement" not in investments
        or not isinstance(assets_under_management, abc.MutableSequence)
        or not len(assets_under_management) > 0
    ):
        return {
            "isValid": False,
            "message": f"assetsUnderManagement is mandatory and must be an array of atleast one item"
            f" in {investment_type}.",
        }

    assets_held_away = investments.assetsHeldAway
    if "assetsHeldAway" not in investments or (
        assets_held_away is not None and not isinstance(assets_held_away, abc.MutableSequence)
    ):
        return {
            "isValid": False,
            "message": f"assetsHeldAway must be an array or null in {investment_type}.",
        }
    asset_type = "assetsUnderManagement"

    for idx, i in enumerate(assets_under_management):
        if not isinstance(i, abc.MutableMapping):
            return {
                "isValid": False,
                "message": f"assetsUnderManagement item in {investment_type} must be a mapping object.",
            }
        account_id = i.get("accountId")
        if account_id is not None and type(account_id) not in [str]:
            return {
                "isValid": False,
                "message": f"accountId must be string in {investment_type} > {asset_type}.",
            }
        if not isinstance(i.get("accountType"), str):
            return {
                "isValid": False,
                "message": f"accountType must be string in {investment_type} > {asset_type}.",
            }
        if not isinstance(i.get("model"), str):
            return {
                "isValid": False,
                "message": f"model must be string in in {investment_type} > {asset_type}.",
            }
        if (
            "assetCategory" not in i
            or not isinstance(i.get("assetCategory"), str)
            or i.get("assetCategory").lower() not in ["retirement", "wealth"]
        ):
            return {
                "isValid": False,
                "message": f"assetCategory must be Retirement or Wealth in {investment_type}" f" > {asset_type}.",
            }
        if not isinstance(i.get("GOEAUM"), bool):
            return {
                "isValid": False,
                "message": f"GOEAUM must be boolean in {investment_type} > {asset_type}.",
            }
        if "advisorAUM" in i and type(i.get("advisorAUM")) not in [bool]:
            return {
                "isValid": False,
                "message": f"advisorAUM must be boolean in {investment_type} > {asset_type}.",
            }
        if "assetValue" not in i or type(i.get("assetValue")) not in [int, float] or not i.get("assetValue") >= 0:
            return {
                "isValid": False,
                "message": f"assetValue must be a non negative number." f" in {investment_type} > {asset_type}.",
            }
        if (
            "accountOwnership" not in i
            or not isinstance(i.get("accountOwnership"), str)
            or i.get("accountOwnership").lower() not in ["client", "spouse"]
        ):
            return {
                "isValid": False,
                "message": f"accountOwnership must be Client or Spouse in {investment_type} > {asset_type}.",
            }

    asset_type = "assetsHeldAway"
    if assets_held_away:
        for idx, j in enumerate(assets_held_away):
            if not isinstance(j, abc.MutableMapping):
                return {
                    "isValid": False,
                    "message": f"assetsHeldAway item in {investment_type} must be a mapping object.",
                }
            account_id = j.get("accountId")
            if account_id is not None and type(account_id) not in [str]:
                return {
                    "isValid": False,
                    "message": f"accountId must be string in {investment_type} > {asset_type}.",
                }
            if not isinstance(j.get("accountType"), str):
                return {
                    "isValid": False,
                    "message": f"accountType must be string in {investment_type} > {asset_type}.",
                }

            if (
                "assetCategory" not in j
                or not isinstance(j.get("assetCategory"), str)
                or j.get("assetCategory").lower() not in ["retirement", "wealth"]
            ):
                return {
                    "isValid": False,
                    "message": f"assetCategory must be Retirement or Wealth in {investment_type} > {asset_type}.",
                }

            if "assetValue" not in j or (
                type(j.get("assetValue")) not in [int, float]
                or (isinstance(j.get("assetValue"), int) and not j.get("assetValue") >= 0)
            ):
                return {
                    "isValid": False,
                    "message": f"assetValue must be a non negative number" f" in {investment_type} > {asset_type}.",
                }
            if (
                "accountOwnership" not in j
                or not isinstance(j.get("accountOwnership"), str)
                or j.get("accountOwnership").lower() not in ["client", "spouse"]
            ):
                return {
                    "isValid": False,
                    "message": f"accountOwnership must be Client or Spouse in" f" {investment_type} > {asset_type}.",
                }
    return {"isValid": True, "message": None}


def validate_translator_api(payload):
    # if "useAgeBasedCap" in payload and type(payload.useAgeBasedCap) != bool:
    #     return {"isValid": False, "message": "useAgeBasedCap must be boolean."}
    if payload.clientId is not None and type(payload.clientId) not in [str]:
        return {
            "isValid": False,
            "message": "clientId must be a alphanumeric.",
        }
    if "lastReallocationProbability" in payload and (
        type(payload.lastReallocationProbability) not in [float, int]
        or not (0 <= payload.lastReallocationProbability <= 0.99)
    ):
        return {
            "isValid": False,
            "message": "lastReallocationProbability must be float and between 0 and 0.99.",
        }
    if isinstance(payload.clientId, str) and not payload.clientId.isalnum():
        return {
            "isValid": False,
            "message": "clientId must be a alphanumeric.",
        }
    if not isinstance(payload.reallocate, bool):
        return {
            "isValid": False,
            "message": "reallocate must be a boolean.",
        }

    if "currentPortfolioId" not in payload or (
        payload.currentPortfolioId is not None
        and (
            payload.currentPortfolioId is False
            or (type(payload.currentPortfolioId) == int and payload.currentPortfolioId < 0)
            or type(payload.currentPortfolioId) not in [int]
        )
    ):
        return {
            "isValid": False,
            "message": "currentPortfolioId must be an integer or null.",
        }
    if type(payload.currentPortfolioRiskScore) not in [int] or not (1 <= payload.currentPortfolioRiskScore <= 100):
        return {
            "isValid": False,
            "message": "currentPortfolioRiskScore is not valid. Must be a number between 1 to 100.",
        }
    # if "riskProfile" not in payload or not isinstance(payload.riskProfile, str):
    #     return {
    #         "isValid": False,
    #         "message": "riskProfile is mandatory and should be string.",
    #     }
    if payload.currentRetirementGoal is not None and (
        type(payload.currentRetirementGoal) not in [float, int] or payload.currentRetirementGoal <= 0
    ):
        return {
            "isValid": False,
            "message": "currentRetirementGoal should be number greater than 0.",
        }
    if not isinstance(payload.householdProfile, abc.MutableMapping):
        return {"isValid": False, "message": "householdProfile must have atleast clientProfile or spouseProfile."}
    if payload.householdProfile.clientProfile is not None and not isinstance(
        payload.householdProfile.clientProfile, abc.MutableMapping
    ):
        return {"isValid": False, "message": "clientProfile must be mapping object."}
    if payload.householdProfile.spouseProfile is not None and not isinstance(
        payload.householdProfile.spouseProfile, abc.MutableMapping
    ):
        return {"isValid": False, "message": "spouseProfile must be mapping object."}
    if (payload.householdProfile.clientProfile is None or not payload.householdProfile.clientProfile) and (
        payload.householdProfile.spouseProfile is None or not payload.householdProfile.spouseProfile
    ):
        return {"isValid": False, "message": "Either householdProfile or spouseProfile should be available."}
    if "clientProfile" in payload.householdProfile and payload.householdProfile.clientProfile is not None:
        if payload.householdProfile.clientProfile.salary is not None and (
            type(payload.householdProfile.clientProfile.salary) not in [int, float]
            or payload.householdProfile.clientProfile.salary < 0
        ):
            return {"isValid": False, "message": "salary of ClientProfile must be non negative number."}
        if payload.householdProfile.clientProfile.currentAge is not None and (
            type(payload.householdProfile.clientProfile.currentAge) not in [int]
            or payload.householdProfile.clientProfile.currentAge <= 0
        ):
            return {"isValid": False, "message": "Current Age of ClientProfile is not valid."}
        if payload.householdProfile.clientProfile.retirementAge is not None and (
            type(payload.householdProfile.clientProfile.retirementAge) not in [int]
            or payload.householdProfile.clientProfile.retirementAge <= 0
        ):
            return {"isValid": False, "message": "retirementAge of Client Profile is not valid."}
        if payload.householdProfile.clientProfile.socialSecurityAge is not None and (
            type(payload.householdProfile.clientProfile.socialSecurityAge) not in [int]
            or (payload.householdProfile.clientProfile.socialSecurityAge < 0)
        ):
            return {
                "isValid": False,
                "message": "socialSecurityAge of Client Profile should be null or integer greater than 0.",
            }
        if ("socialSecurityIncome" not in payload.householdProfile.clientProfile) or (
            (
                "socialSecurityIncome" in payload.householdProfile.clientProfile
                and payload.householdProfile.clientProfile.socialSecurityIncome is not None
            )
            and (
                type(payload.householdProfile.clientProfile.socialSecurityIncome) not in [int, float]
                or (payload.householdProfile.clientProfile.socialSecurityIncome < 0)
            )
        ):
            return {
                "isValid": False,
                "message": "socialSecurityIncome of Client Profile is mandatory and can be nullable but when provided should be integer greater than or equal to 0.",
            }
    if "spouseProfile" in payload.householdProfile and payload.householdProfile.spouseProfile is not None:
        if payload.householdProfile.spouseProfile.salary is not None and (
            type(payload.householdProfile.spouseProfile.salary) not in [int, float]
            or payload.householdProfile.spouseProfile.salary < 0
        ):
            return {"isValid": False, "message": "salary of spouseProfile must be non negative."}
        if payload.householdProfile.spouseProfile.currentAge is not None and (
            type(payload.householdProfile.spouseProfile.currentAge) not in [int]
            or payload.householdProfile.spouseProfile.currentAge <= 0
        ):
            return {"isValid": False, "message": "Current Age of spouseProfile is not valid."}
        if payload.householdProfile.spouseProfile.retirementAge is not None and (
            type(payload.householdProfile.spouseProfile.retirementAge) not in [int]
            or payload.householdProfile.spouseProfile.retirementAge <= 0
        ):
            return {"isValid": False, "message": "retirementAge of spouseProfile is not valid."}
        if payload.householdProfile.spouseProfile.socialSecurityAge is not None and (
            type(payload.householdProfile.spouseProfile.socialSecurityAge) not in [int]
            or (payload.householdProfile.spouseProfile.socialSecurityAge < 0)
        ):
            return {
                "isValid": False,
                "message": "socialSecurityAge of spouse Profile should be null or integer greater than 0.",
            }
        if "socialSecurityIncome" not in payload.householdProfile.spouseProfile or (
            (
                "socialSecurityIncome" in payload.householdProfile.spouseProfile
                and payload.householdProfile.spouseProfile.socialSecurityIncome is not None
            )
            and (
                type(payload.householdProfile.spouseProfile.socialSecurityIncome) not in [int, float]
                or (payload.householdProfile.spouseProfile.socialSecurityIncome < 0)
            )
        ):
            return {
                "isValid": False,
                "message": "socialSecurityIncome of spouseProfile is mandatory and can be nullable but when provided should be integer greater than or equal to 0.",
            }
    if payload.householdProfile.comfortZone not in range(1, 4):
        return {"isValid": False, "message": "comfortZone should range from 1 to 3."}
    if payload.householdProfile.riskScore is not None and type(payload.householdProfile.riskScore) not in [int]:
        return {"isValid": False, "message": "riskScore range from 1 to 100."}
    if payload.householdProfile.riskScore is not None and not (1 <= payload.householdProfile.riskScore <= 100):
        return {"isValid": False, "message": "riskScore range from 1 to 100."}
    if payload.initialInvestment is None or not isinstance(payload.initialInvestment, abc.MutableMapping):
        return {"isValid": False, "message": "initialInvestment is mandatory and a mapping object."}
    if payload.initialInvestment is not None:
        valid_initial_investment = validate_translator_investments(payload.initialInvestment, "initialInvestment")
        if valid_initial_investment.get("isValid") is False:
            return valid_initial_investment
    if "currentInvestment" not in payload or not isinstance(payload.currentInvestment, abc.MutableMapping):
        return {"isValid": False, "message": "currentInvestment is mandatory and should be a mapping object."}
    if payload.currentInvestment is not None:
        valid_initial_investment = validate_translator_investments(payload.currentInvestment, "currentInvestment")
        if valid_initial_investment.get("isValid") is False:
            return valid_initial_investment
    if not isDateFormatValidV1(payload.startDate):
        return {"isValid": False, "message": "startDate is not valid and must be dd-mm-yyyy."}
    if payload.currDate is not None and not isDateFormatValidV1(payload.currDate):
        return {"isValid": False, "message": "currDate must be null or provide a valid date and must be dd-mm-yyyy"}
    if ("currentRetirementAHAComposition" not in payload) or (
        "currentRetirementAHAComposition" in payload
        and payload.currentRetirementAHAComposition is not None
        and not isinstance(payload.currentRetirementAHAComposition, abc.MutableMapping)
    ):
        return {
            "isValid": False,
            "message": "currentRetirementAHAComposition is mandatory and can be null but when available must be a mapping object.",
        }
    if payload.currentRetirementAHAComposition is not None and (
        type(payload.currentRetirementAHAComposition.equity) not in [int, float]
        or not (0 <= payload.currentRetirementAHAComposition.equity <= 1)
    ):
        return {
            "isValid": False,
            "message": "equity of currentRetirementAHAComposition is mandatory and must be number between 0 and 1.",
        }
    if payload.currentRetirementAHAComposition is not None and (
        type(payload.currentRetirementAHAComposition.debt) not in [int, float]
        or not 0 <= payload.currentRetirementAHAComposition.debt <= 1
    ):
        return {
            "isValid": False,
            "message": "debt of currentRetirementAHAComposition is mandatory and must be number between 0 and 1.",
        }
    if payload.currentRetirementAHAComposition is not None and (
        type(payload.currentRetirementAHAComposition.other) not in [int, float]
        or not (0 <= payload.currentRetirementAHAComposition.other <= 1)
    ):
        return {
            "isValid": False,
            "message": "other of currentRetirementAHAComposition is mandatory and must be number between 0 and 1.",
        }
    if payload.currentRetirementAHAComposition is not None and (
        not (
            round(
                payload.currentRetirementAHAComposition.equity
                + payload.currentRetirementAHAComposition.debt
                + payload.currentRetirementAHAComposition.other,
                4,
            )
            == 1.0
        )
    ):
        return {
            "isValid": False,
            "message": "equity, debt and other in currentRetirementAHAComposition should add up to 1.",
        }

    if payload.endDate is not None and not isDateFormatValidV1(payload.endDate):
        return {"isValid": False, "message": "endDate is not valid and must be dd-mm-yyyy"}
    if payload.endDate:
        dateValidation = DictDefault(validateDates(payload.startDate, payload.endDate, payload.currDate))
        if not dateValidation.isValid:
            return dateValidation
    if "lastReallocationDate" in payload and not isDateFormatValid(payload.lastReallocationDate):
        return {
            "isValid": False,
            "message": "lastReallocationDate is optional if provided should follow format dd-mm-yyyy.",
        }

    return {"isValid": True, "message": None}


def validate_decumulation_api(ptf, payload):
    portfoliosRiskOn = ptf.get("portfoliosRiskOn")

    if (
        "dateOfBirth" not in payload
        or not payload.dateOfBirth
        or (payload.dateOfBirth and not isDateFormatValid(payload.dateOfBirth))
    ):
        return {
            "isValid": False,
            "message": "dateOfBirth is mandatory and date format is dd-mm-yyyy",
        }

    if "riskProfile" not in payload or not isinstance(payload.riskProfile, str):
        return {
            "isValid": False,
            "message": "riskProfile is mandatory and should be string.",
        }
    if payload.gender is not None and (
        not isinstance(payload.gender, str) or payload.get("gender", "").lower() not in ["male", "female", "unisex"]
    ):
        return {
            "isValid": False,
            "message": "Gender is optional when provided and should be either 'Male' or 'Female' or 'Unisex'.",
        }
    if "currentWealth" not in payload or (
        payload.currentWealth is not None
        and (type(payload.currentWealth) not in [float, int] or payload.currentWealth <= 0)
    ):
        return {
            "isValid": False,
            "message": "currentWealth should be number greater than 0.",
        }
    if "currentWealth" in payload and has_greater_precision(payload.currentWealth, 1):
        return {
            "isValid": False,
            "message": "currentWealth should have precision of one decimal place.",
        }

    if not isinstance(payload.isNewRiskProfile, bool):
        return {
            "isValid": False,
            "message": "isNewRiskProfile is mandatory and must be a boolean.",
        }
    if "currentPortfolioId" not in payload or (
        payload.currentPortfolioId is not None
        and (
            type(payload.currentPortfolioId) not in [int]
            or (payload.currentPortfolioId <= 0 or payload.currentPortfolioId > len(portfoliosRiskOn))
        )
    ):
        return {
            "isValid": False,
            "message": "CurrentPortfolioId must be a positive integer or null when provided should be less than maximum allowed number of portfolios.",
        }
    if payload.targetExpenditures is None or not isinstance(payload.targetExpenditures, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "targetExpenditures  must be a list of numbers",
        }

    if isinstance(payload.targetExpenditures, abc.MutableSequence):
        for i in payload.targetExpenditures:
            if type(i) not in (float, int) or has_greater_precision(i, 1):
                return {
                    "isValid": False,
                    "message": "Error in targetExpenditures  {0}, targetExpenditures values must be an number with a precision of 1 decimal place.".format(
                        i
                    ),
                }
            if i <= 0:
                return {
                    "isValid": False,
                    "message": "Error in targetExpenditures values, all values must be > 0",
                }
    if payload.reallocationFreq is None or payload.reallocationFreq not in ["yearly", "half-yearly", "quarterly"]:
        return {
            "isValid": False,
            "message": "reallocationFreq is a mandatory field and has to be 'yearly' or 'half-yearly' or 'quarterly'",
        }
    if "startDate" not in payload or not isDateFormatValidV1(payload.startDate):
        return {"isValid": False, "message": "startDate is mandatory and should be of format dd-mm-yyyy."}
    if "endDate" not in payload or not isDateFormatValidV1(payload.endDate):
        return {"isValid": False, "message": "endDate is mandatory and should be of format dd-mm-yyyy"}
    if payload.endDate:
        dateValidation = DictDefault(validateDates(payload.startDate, payload.endDate, payload.currDate))
        if not dateValidation.isValid:
            return dateValidation

    if datetime.datetime.strptime(payload.endDate, "%d-%m-%Y") < datetime.datetime.strptime(
        payload.startDate, "%d-%m-%Y"
    ):
        return {
            "isValid": False,
            "message": f"endDate  must be greater than startDate .",
        }

    if payload.includeAnnuities and (payload.annuityRate != 0 and not payload.annuityRate):
        return {
            "isValid": False,
            "message": "annuityRate is mandatory when includeAnnuities is true.",
        }
    if payload.annuityRate is not None and (  # TOCHECK
        type(payload.annuityRate) not in [float]
        or payload.annuityRate < 0
        or payload.annuityRate > 1
        or has_greater_precision(payload.annuityRate, 4)
    ):
        return {
            "isValid": False,
            "message": "annuityRate should be from 0 to 1 and should have precision <= 4 decimal places.",
        }
    if not payload.stateIncome or not isinstance(payload.stateIncome, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "stateIncome  must be a list of numbers",
        }
    if isinstance(payload.stateIncome, abc.MutableSequence):
        for i in payload.stateIncome:
            if type(i) not in (float, int):
                return {
                    "isValid": False,
                    "message": "Error in stateIncome  {0}, stateIncome values must be an number.".format(i),
                }
            if i < 0:
                return {
                    "isValid": False,
                    "message": "Error in stateIncome values, all values must be >= 0",
                }
            if has_greater_precision(i, 1):
                return {
                    "isValid": False,
                    "message": "Error in stateIncome values, all values must have a precision of 1 decimal place.",
                }
    if "retirementAge" not in payload:
        payload.retirementAge = 65

    if "retirementAge" in payload and (type(payload.retirementAge) is not int or payload.retirementAge < 65):
        return {
            "isValid": False,
            "message": "retirementAge should be number and greater than 65.",
        }
    if (
        not payload.existingAnnuitiesIncome
        or not isinstance(payload.existingAnnuitiesIncome, abc.MutableSequence)
        or len(payload.existingAnnuitiesIncome) > 100
    ):
        return {
            "isValid": False,
            "message": "existingAnnuitiesIncome  must be a list of numbers and length of existingAnnuitiesIncome should be less than 100",
        }
    if isinstance(payload.existingAnnuitiesIncome, abc.MutableSequence):
        for i in payload.existingAnnuitiesIncome:
            if type(i) not in (float, int):
                return {
                    "isValid": False,
                    "message": "Error in existingAnnuitiesIncome  {0}, existingAnnuitiesIncome values must be an number.".format(
                        i
                    ),
                }
            if i < 0:
                return {
                    "isValid": False,
                    "message": "Error in existingAnnuitiesIncome values, all values must be >= 0",
                }
            if has_greater_precision(i, 1):
                return {
                    "isValid": False,
                    "message": "Error in existingAnnuitiesIncome values must have a precision of 1 decimal place.",
                }

    if not isinstance(payload.includeAnnuities, bool):
        return {
            "isValid": False,
            "message": "includeAnnuities is mandatory and must be a boolean.",
        }
    if "cashflowDate" in payload and payload.cashflowDate is not None and not isDateFormatValid(payload.cashflowDate):
        return {
            "isValid": False,
            "message": "cashflowDate must be in ISO date format or null.",
        }
    if not payload.otherGuaranteedIncome or not isinstance(payload.otherGuaranteedIncome, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "otherGuaranteedIncome  must be a list of numbers",
        }
    if isinstance(payload.otherGuaranteedIncome, abc.MutableSequence):
        for i in payload.otherGuaranteedIncome:
            if type(i) not in (float, int):
                return {
                    "isValid": False,
                    "message": "Error in otherGuaranteedIncome  {0}, otherGuaranteedIncome values must be an number.".format(
                        i
                    ),
                }
            if i < 0:
                return {
                    "isValid": False,
                    "message": "Error in otherGuaranteedIncome values, all values must be >= 0",
                }
            if has_greater_precision(i, 1):
                return {
                    "isValid": False,
                    "message": "Error in otherGuaranteedIncome values must have a precision of 1 decimal place.",
                }
    if payload.infusionType not in ["yearly", "monthly"]:
        return {
            "isValid": False,
            "message": "infusionType is mandatory and should be 'yearly', 'monthly'.",
        }
    if payload.currDate is not None and not isDateFormatValidV1(payload.currDate):
        return {"isValid": False, "message": "currDate must be null or provide a valid date and must be dd-mm-yyyy"}

    if not isinstance(payload.isNewInvestmentTenure, bool):
        return {
            "isValid": False,
            "message": "isNewInvestmentTenure is mandatory and must be a boolean.",
        }
    if not isinstance(payload.isNewGoal, bool):
        return {
            "isValid": False,
            "message": "isNewGoal is mandatory and must be a boolean.",
        }
    if not payload.dbIncome or not isinstance(payload.dbIncome, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "dbIncome  must be a list of numbers",
        }
    if isinstance(payload.dbIncome, abc.MutableSequence):
        for i in payload.dbIncome:
            if type(i) not in (float, int):
                return {
                    "isValid": False,
                    "message": "Error in dbIncome  {0}, dbIncome values must be an number.".format(i),
                }
            if i < 0:
                return {
                    "isValid": False,
                    "message": "Error in dbIncome values, all values must be >= 0",
                }
            if has_greater_precision(i, 1):
                return {
                    "isValid": False,
                    "message": "Error in dbIncome values must have precision of 1 decimal place.",
                }
    if not isinstance(payload.isNewGoalPriority, bool):
        return {
            "isValid": False,
            "message": "isNewGoalPriority is mandatory and must be a boolean.",
        }
    if payload.reallocate and not isinstance(payload.reallocate, bool):
        return {
            "isValid": False,
            "message": "reallocate must be a boolean.",
        }
    if payload.initialInvestment is None:
        return {"isValid": False, "message": "initialInvestment is mandatory"}
    if payload.initialInvestment is not None and (
        type(payload.initialInvestment) not in [float, int]
        or payload.initialInvestment <= 0
        or has_greater_precision(payload.initialInvestment, 1)
    ):
        return {
            "isValid": False,
            "message": "initialInvestment should be number greater than 0 and must have precision of 1 decimal place.",
        }
    if "healthStatus" in payload and payload.healthStatus not in [0, 1, 2]:
        return {
            "isValid": False,
            "message": "healthStatus should be 0, 1, 2.",
        }
    if "lossThreshold" not in payload or (
        "lossThreshold" in payload
        and payload.lossThreshold is not None
        and (type(payload.lossThreshold) not in [float] or payload.lossThreshold < 0)
    ):
        return {
            "isValid": False,
            "message": "lossThreshold must be a number greater than 0 or null and should be a decimal value.",
        }
    date_of_birth = datetime.datetime.strptime(payload.dateOfBirth, "%d-%m-%Y")
    if payload.currDate:
        today_date = datetime.datetime.strptime(payload.currDate, "%d-%m-%Y")
    else:
        today_date = datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y")
        today_date = datetime.datetime.strptime(today_date, "%d-%m-%Y")
    curr_age = calculateAge(date_of_birth, today_date)
    if not (65 <= curr_age <= 120):
        return {"isValid": False, "message": "dateOfBirth is not valid, age must be between 65 and 120."}
    if "retirementAge" in payload and (curr_age < payload.retirementAge):
        return {
            "isValid": False,
            "message": "dateOfBirth is not valid must be greater than or equal to retirementAge",
        }
    if "futureAnnuityProj" in payload and not isinstance(payload.futureAnnuityProj, bool):
        return {
            "isValid": False,
            "message": "futureAnnuityProj must be a bool.",
        }
    if "inflation" in payload and (type(payload.inflation) not in [int, float] or not (0 <= payload.inflation <= 1)):
        return {
            "isValid": False,
            "message": "inflation must be between 0 and 1.",
        }
    if "lifeEventsList" in payload and (not isinstance(payload.lifeEventsList, abc.MutableSequence)):
        return {
            "isValid": False,
            "message": "lifeEventsList must be a sequence object.",
        }
    if payload.lifeEventsList:
        for index, event in enumerate(payload.lifeEventsList):
            if isinstance(event.lifeEventId, (bool)) or not isinstance(event.lifeEventId, (str, int)):
                return {
                    "isValid": False,
                    "message": "lifeEventId in lifeEventsList must be str or int.",
                }
            if not isDateFormatValid(event.startDate):
                return {
                    "isValid": False,
                    "message": "startDate in lifeEventsList is not valid.",
                }
            if not isDateFormatValid(event.endDate):
                return {
                    "isValid": False,
                    "message": "endDate in lifeEventsList is not valid.",
                }

            if datetime.datetime.strptime(event.endDate, "%d-%m-%Y") < datetime.datetime.strptime(
                event.startDate, "%d-%m-%Y"
            ):
                return {
                    "isValid": False,
                    "message": f"endDate  must be greater than startDate at item position {index}.",
                }
            if not isinstance(event.type, str) or event.type.lower() not in ["healthcare", "bequest", "other"]:
                return {
                    "isValid": False,
                    "message": f"type in lifeEventsList must be either 'healthcare', 'bequest', 'other' at item position {index}.",
                }
            if not isinstance(event.scenarioType, str) or event.scenarioType.lower() not in ["regular", "retirement"]:
                return {
                    "isValid": False,
                    "message": f"scenarioType in lifeEventsList must be either 'regular', 'retirement' at item position {index}.",
                }
            if (
                not isinstance(event.goalAmt, abc.MutableSequence)
                or len(event.goalAmt) == 0
                or len(
                    set(
                        [
                            isinstance(gamt, (int, float)) if not isinstance(gamt, bool) else False
                            for gamt in event.goalAmt
                        ]
                    )
                    - {True}
                )
                > 0
            ):
                return {
                    "isValid": False,
                    "message": "goalAmt must be a array of numbers in lifeEventsList and array should contain atleast one value.",
                }
        leids = [l.lifeEventId for l in payload.lifeEventsList]
        if len(leids) > len(set(leids)):
            return {
                "isValid": False,
                "message": "lifeEventId in lifeEventsList must not be repeated.",
            }

    return {"isValid": True, "message": None}


def validate_decumulation_uploads(name, payload):  # TODO:
    if name not in payload or not isinstance(payload.get(name), abc.MutableSequence) or len(payload.get(name)) < 1:
        return {
            "isValid": False,
            "message": f"{name} is required and should be an array.",
        }
    for ad in payload.get(name):
        if not isinstance(ad, abc.MutableMapping) or type(ad.age) not in [int] or type(ad.value) not in [float, int]:
            return {
                "isValid": False,
                "message": f"{name} value is not valid.",
            }
    return {"isValid": True, "message": None}


def validate_run_pipe_taxes(payload):
    if not isinstance(payload.reallocate, bool):
        return {
            "isValid": False,
            "message": "reallocate is mandatory and must be a boolean.",
        }
    if not isinstance(payload.isNewRiskProfile, bool):
        return {
            "isValid": False,
            "message": "isNewRiskProfile is mandatory and must be a boolean.",
        }
    if not isinstance(payload.isNewInvestmentTenure, bool):
        return {
            "isValid": False,
            "message": "isNewInvestmentTenure is mandatory and must be a boolean.",
        }
    if not isinstance(payload.isNewGoal, bool):
        return {
            "isValid": False,
            "message": "isNewGoal is mandatory and must be a boolean.",
        }
    if not isinstance(payload.isNewGoalPriority, bool):
        return {
            "isValid": False,
            "message": "isNewGoalPriority is mandatory and must be a boolean.",
        }
    if not isinstance(payload.isNearTermVolatility, bool):
        return {
            "isValid": False,
            "message": "isNearTermVolatility is mandatory and must be a boolean.",
        }
    if not isinstance(payload.getPath, bool):
        return {
            "isValid": False,
            "message": "getPath is mandatory and must be a boolean.",
        }
    if payload.reallocationFreq is None or payload.reallocationFreq not in ["yearly"]:
        return {
            "isValid": False,
            "message": "reallocationFreq is a mandatory field and has to be yearly",
        }
    if "currentPortfolioId" not in payload or (
        payload.currentPortfolioId is not None
        and (
            payload.currentPortfolioId is False
            or (isinstance(payload.currentPortfolioId, int) and payload.currentPortfolioId < 0)
            or type(payload.currentPortfolioId) not in [int, float]
        )
    ):
        return {
            "isValid": False,
            "message": "currentPortfolioId must be an integer or null.",
        }
    if (
        "lossThreshold" in payload
        and payload.lossThreshold is not None
        and (type(payload.lossThreshold) not in [float, int] or payload.lossThreshold < 0)
    ):
        return {
            "isValid": False,
            "message": "lossThreshold must be a number greater than equal to 0 or null",
        }

    if (
        "colaRate" in payload
        and payload.colaRate is not None
        and (type(payload.colaRate) not in [float, int])
        or (payload.colaRate is not None and payload.colaRate < 0)
    ):
        return {
            "isValid": False,
            "message": "colaRate must be a number greater than equal to 0 or null",
        }

    if "currDate" in payload and payload.currDate is None:
        return {"isValid": False, "message": "currDate is optional and cannt be null."}
    if payload.currDate is not None and not isDateFormatValidV1(payload.currDate):
        return {"isValid": False, "message": "currDate is optional, when provided must be of format dd-mm-yyyy"}

    # if "riskProfile" not in payload or not isinstance(payload.riskProfile, str):
    #     return {
    #         "isValid": False,
    #         "message": "riskProfile is mandatory and should be string.",
    #     }
    if "computeSocialSecurity" in payload and payload.computeSocialSecurity is None:
        return {
            "isValid": False,
            "message": "computeSocialSecurity is optional but is not nullable.",
        }
    if (
        "computeSocialSecurity" in payload
        and payload.computeSocialSecurity is not None
        and not isinstance(payload.computeSocialSecurity, bool)
    ):
        return {
            "isValid": False,
            "message": "computeSocialSecurity must be a boolean.",
        }
    if "useSocialSecurityForGoals" in payload and payload.useSocialSecurityForGoals is None:
        return {
            "isValid": False,
            "message": "useSocialSecurityForGoals is optional but is not nullable.",
        }

    if (
        "useSocialSecurityForGoals" in payload
        and payload.useSocialSecurityForGoals is not None
        and type(payload.useSocialSecurityForGoals) != bool
    ):
        return {
            "isValid": False,
            "message": "useSocialSecurityForGoals must be a boolean.",
        }
    if "useRMDForGoals" in payload and payload.useRMDForGoals is None:
        return {
            "isValid": False,
            "message": "useRMDForGoals is optional but is not nullable.",
        }
    if "cashflowDate" in payload and payload.cashflowDate is not None and not isDateFormatValid(payload.cashflowDate):
        return {
            "isValid": False,
            "message": "cashflowDate must be in ISO date format or null.",
        }
    if payload.infusionType not in ["yearly", "monthly"]:
        return {
            "isValid": False,
            "message": "infusionType must be one of yearly or monthly.",
        }

    if "taxRates" not in payload:
        return {
            "isValid": False,
            "message": "taxRates is mandatory.",
        }
    if "taxRates" in payload and not isinstance(payload.taxRates, abc.MutableMapping):
        return {
            "isValid": False,
            "message": "taxRates is not valid must be a mapping object.",
        }
    if "taxRates" in payload:
        if "LTCGPreRetirement" not in payload.taxRates or (
            type(payload.taxRates.LTCGPreRetirement) not in [float, int]
            or not (0 <= payload.taxRates.LTCGPreRetirement <= 1)
        ):
            return {
                "isValid": False,
                "message": "LTCGPreRetirement is mandatory and must be a number between 0 and 1.",
            }
        if "ETRPreRetirement" not in payload.taxRates or (
            (
                type(payload.taxRates.ETRPreRetirement) not in [float, int]
                or not (0 <= payload.taxRates.ETRPreRetirement <= 1)
            )
        ):
            return {
                "isValid": False,
                "message": "ETRPreRetirement is mandatory and must be a number between 0 and 1.",
            }
        if "LTCGPostRetirement" not in payload.taxRates or (
            type(payload.taxRates.LTCGPostRetirement) not in [float, int]
            or not (0 <= payload.taxRates.LTCGPostRetirement <= 1)
        ):
            return {
                "isValid": False,
                "message": "LTCGPostRetirement is mandatory and must be a number between 0 and 1.",
            }
        if "ETRPostRetirement" not in payload.taxRates or (
            type(payload.taxRates.ETRPostRetirement) not in [float, int]
            or not (0 <= payload.taxRates.ETRPostRetirement <= 1)
        ):
            return {
                "isValid": False,
                "message": "ETRPostRetirement is mandatory and must be a number between 0 and 1.",
            }

    if "household" not in payload:
        return {
            "isValid": False,
            "message": "household is mandatory.",
        }
    if "household" in payload and not isinstance(payload.household, abc.MutableMapping):
        return {
            "isValid": False,
            "message": "household is not valid must be a mapping object.",
        }
    if "household" in payload:
        if "householdID" not in payload.household or (not isinstance(payload.household.householdID, str)):
            return {
                "isValid": False,
                "message": "householdID is mandatory and must be a string.",
            }

        state_res_array = [
            "AK",
            "AL",
            "AR",
            "AZ",
            "CA",
            "CO",
            "CT",
            "DC",
            "DE",
            "FL",
            "GA",
            "HI",
            "IA",
            "ID",
            "IL",
            "IN",
            "KS",
            "KY",
            "LA",
            "MA",
            "MD",
            "ME",
            "MI",
            "MN",
            "MO",
            "MS",
            "MT",
            "NC",
            "ND",
            "NE",
            "NH",
            "NJ",
            "NM",
            "NV",
            "NY",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VA",
            "VT",
            "WA",
            "WI",
            "WV",
            "WY",
        ]
        if payload.household.stateOfResidence is not None and (
            type(payload.household.stateOfResidence) != str or payload.household.stateOfResidence not in state_res_array
        ):
            return {
                "isValid": False,
                "message": f"stateOfResidence is not valid, it shoud be any one of these values {state_res_array} ",
            }
        if "memberList" not in payload.household or (not isinstance(payload.household.memberList, abc.MutableSequence)):
            return {
                "isValid": False,
                "message": "memberList is not a valid. Must be an array",
            }

        member_ids = []
        for index, x in enumerate(payload.household.memberList):
            if not isinstance(x.memberType, str) or x.memberType.lower() not in ["primary", "secondary"]:
                return {
                    "isValid": False,
                    "message": f"memberType is mandatory and should be Primary or Secondary in memberList"
                    f" at item position {index}.",
                }
            if not isinstance(x.memberID, str) or x.memberID == "":
                return {
                    "isValid": False,
                    "message": f"memberID is mandatory and not valid in memberList at item position {index}.",
                }
            member_ids.append(x.memberID)
            if not is_valid_format_mmyyyy(x.DOB):
                return {
                    "isValid": False,
                    "message": f"DOB is mandatory and should be in 'MM-YYYY' format in memberList at item position {index}.",
                }
            if type(x.currentAge) != int or not (1 <= x.currentAge <= 100):
                return {
                    "isValid": False,
                    "message": "currentAge is mandatory and should be between 1 and 100 "
                    f"in memberList at item position {index}.",
                }
            if type(x.retirementAge) != int or not (1 <= x.retirementAge <= 100):
                return {
                    "isValid": False,
                    "message": "retirementAge is mandatory and should be between 1 and 100"
                    f" in memberList at item position {index}.",
                }
            if type(x.currentSalary) not in [int, float] or x.currentSalary <= 0:
                return {
                    "isValid": False,
                    "message": f"currentSalary should be greater than 0 in memberList at item position {index}.",
                }
            if type(x.socialSecurityStartAge) != int or not (0 <= x.socialSecurityStartAge <= 100):
                return {
                    "isValid": False,
                    "message": f"socialSecurityStartAge must be between 0 and 100 in memberList at item position {index}.",
                }
            if (
                "TDABalanceForRMD" in x
                and x.TDABalanceForRMD is not None
                and (type(x.TDABalanceForRMD) not in [int, float] or x.TDABalanceForRMD <= 0)
            ):
                return {
                    "isValid": False,
                    "message": "TDABalanceForRMD is not valid number and should be greater than 0.",
                }

            if (
                "RMDUtilized" in x
                and x.RMDUtilized is not None
                and (type(x.RMDUtilized) not in [int, float] or x.RMDUtilized < 0)
            ):
                return {
                    "isValid": False,
                    "message": "RMDUtilized is not valid number and should be greater than or equal to 0.",
                }
            if (
                x.existingMonthlySocialSecurityAmount is not None
                and type(x.existingMonthlySocialSecurityAmount) not in [int, float]
            ) or (x.existingMonthlySocialSecurityAmount is not None and x.existingMonthlySocialSecurityAmount < 0):
                return {
                    "isValid": False,
                    "message": "existingMonthlySocialSecurityAmount is not valid number and should be greater than or equal to 0.",
                }

    if not isinstance(payload.accounts, abc.MutableSequence):
        return {
            "isValid": False,
            "message": f"accounts object is not valid array at item position {index}.",
        }
    for index, x in enumerate(payload.accounts):
        if type(x.accountID) != str or x.accountID == "":
            return {
                "isValid": False,
                "message": f"accountID is mandatory and should be valid string in accounts at item position {index}.",
            }
        if type(x.taxabilityType) != str or x.taxabilityType not in ["T", "D", "F"]:
            return {
                "isValid": False,
                "message": f"taxabilityType is not valid in accounts at item position {index}. valid values are 'T', 'D', 'F'",
            }
        if x.taxabilityType in [
            "D",
            "F",
        ]:
            if type(x.accountType) != str or x.accountType not in ["401k", "IRA"]:
                return {
                    "isValid": False,
                    "message": f"accountType is not valid in accounts at item position {index}. valid values are '401k', 'IRA'",
                }

        if x.taxabilityType in ["T"]:
            if x.accountType is not None:
                return {
                    "isValid": False,
                    "message": f"accountType is not valid in accounts at item position {index}.",
                }

        if not isinstance(x.memberIDs, abc.MutableSequence):
            return {
                "isValid": False,
                "message": f"memberIDs is not valid and must be an array in accounts at item position {index}.",
            }
        if len(x.memberIDs) == 0:
            return {
                "isValid": False,
                "message": f"memberIDs should have atleast on value in accounts at item position {index}",
            }
        for mid, y in enumerate(x.memberIDs):
            if type(y) != str or y == "":
                return {
                    "isValid": False,
                    "message": f"memberIDs value must be non empty string at index {mid}"
                    f" in accounts > memberIDs at item position {index}",
                }
            if y not in member_ids:
                return {
                    "isValid": False,
                    "message": f"memberIDs value at index {mid} should match memberID in memberList,"
                    f" Issue in accounts > memberIDs at item position {index} .",
                }

        if type(x.currentBalance) not in [int, float] or x.currentBalance < 0:
            return {
                "isValid": False,
                "message": f"currentBalance must be integer or float in accounts at item position {index}.",
            }
        if not isinstance(x.cashflowDetails, abc.MutableMapping):
            return {
                "isValid": False,
                "message": f"cashflowDetails is not valid. Must be an mapping object in accounts at item position {index}.",
            }
        # if len(x.cashflowDetails.cashflowAmt) == 0:
        #     return {
        #         "isValid": False,
        #         "message": f"cashflowAmt cannt be empty in accounts at item position {index}.",
        #     }
        for y in x.cashflowDetails.cashflowAmt:
            if type(y) not in [float, int]:
                return {
                    "isValid": False,
                    "message": f"{y} in cashflowAmt is not valid integer or float in accounts at item position {index}.",
                }
        if not isDateFormatValidV1(x.cashflowDetails.startDate):
            return {
                "isValid": False,
                "message": f"startDate in cashflowDetails must be of format dd-mm-yyyy at item position {index}.",
            }
        if not isDateFormatValidV1(x.cashflowDetails.endDate):
            return (
                {
                    "isValid": False,
                    "message": f"endDate in cashflowDetails must be of format dd-mm-yyyy at item position {index}.",
                },
            )
        if datetime.datetime.strptime(x.cashflowDetails.endDate, "%d-%m-%Y") < datetime.datetime.strptime(
            x.cashflowDetails.startDate, "%d-%m-%Y"
        ):
            return {
                "isValid": False,
                "message": f"endDate in cashflowDetails must be greater than startDate at item position {index}.",
            }
        if not isinstance(x.currentHoldings, abc.MutableSequence):
            return {
                "isValid": False,
                "message": f"currentHoldings must be an array in accounts at item position {index}.",
            }
        if len(x.currentHoldings) == 0:
            return {
                "isValid": False,
                "message": f"currentHoldings in accounts must have atleast one object at item position {index}.",
            }

        for index, y in enumerate(x.currentHoldings):
            if not isinstance(y, abc.MutableMapping):
                return {
                    "isValid": False,
                    "message": f"Item must be mapping object in currentHoldings in accounts at item position {index}.",
                }
            if type(y.categoryName) != str:
                return {
                    "isValid": False,
                    "message": f"categoryName is not valid in currentHoldings in accounts at item position {index}.",
                }
            if not isinstance(y.categoryID, str) or y.categoryID == "":
                return {
                    "isValid": False,
                    "message": f"categoryID is not valid in currentHoldings in accounts at item position {index}.",
                }
            if type(y.categoryPrice) not in [int, float] or y.categoryPrice < 0:
                return {
                    "isValid": False,
                    "message": f"categoryPrice is not valid in currentHoldings in accounts at item position {index}.",
                }
            if type(y.quantity) not in [int, float] or y.quantity < 0:
                return {
                    "isValid": False,
                    "message": f"quantity is not valid in currentHoldings in accounts at item position {index}.",
                }
            if type(y.costBasis) not in [int, float] or y.costBasis < 0:
                return {
                    "isValid": False,
                    "message": f"costBasis is not valid in currentHoldings in accounts at item position {index}.",
                }

    if not isinstance(payload.goalProfileList, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goalProfileList must be an array.",
        }
    if len(payload.goalProfileList) == 0:
        return {
            "isValid": False,
            "message": "goalProfileList must have atleast one object.",
        }

    for index, x in enumerate(payload.goalProfileList):
        if not isinstance(x, abc.MutableMapping):
            return {
                "isValid": False,
                "message": f"goalProfileList must be a mapping object at item position {index}.",
            }
        if type(x.goalId) is not str or not re.match("^[ A-Za-z0-9]+$", x.goalId):
            return {
                "isValid": False,
                "message": "goalId in goalProfileList is mandatory and should only contain letters, numbers and"
                f" spaces at item position {index}.",
            }

        if not isinstance(x.goalAmt, abc.MutableSequence):
            return {
                "isValid": False,
                "message": f"goalAmt in goalProfileList must be array at item position {index}.",
            }
        for idx, amt in enumerate(x.goalAmt):
            if type(amt) not in [float, int] or amt < 0:
                return {
                    "isValid": False,
                    "message": "Every value in goalAmt must be integer or float in goalProfileList"
                    f" at item position {index}, {idx}.",
                }

        if type(x.scenarioType) != str:
            return {
                "isValid": False,
                "message": f"scenarioType in goalProfileList is not valid at item position {index}.",
            }
        if x.scenarioType not in ["retirement", "regular"]:
            return {
                "isValid": False,
                "message": f"scenarioType in goalProfileList must be 'retirement' or 'regular' at item position {index}.",
            }
        if not isinstance(x.startDate, str) or not isDateFormatValidV1(x.startDate):
            return {
                "isValid": False,
                "message": f"startDate in goalProfileList must be of format dd-mm-yyyy at item position {index}.",
            }
        if not isinstance(x.endDate, str) or not isDateFormatValidV1(x.endDate):
            return {
                "isValid": False,
                "message": f"endDate in goalProfileList must be of format dd-mm-yyyy at item position {index}.",
            }
        if datetime.datetime.strptime(x.endDate, "%d-%m-%Y") < datetime.datetime.strptime(x.startDate, "%d-%m-%Y"):
            return {
                "isValid": False,
                "message": f"endDate in goalProfileList must be greater than startDate at item position {index}.",
            }

        if x.priority not in ["Need", "Want", "Wish", "Dream"]:
            return {
                "isValid": False,
                "message": f"priority in goalProfileList must be 'Need', 'Want', 'Wish' or 'Dream' at item position {index}.",
            }
        if ("bequest" in x and x.bequest is not None) and type(x.bequest) != bool:
            return {
                "isValid": False,
                "message": f"bequest in goalProfileList must be a boolean at item position {index}.",
            }
        if not isinstance(x.goalPurpose, str) or x.goalPurpose.lower() not in ["education", "non-education"]:
            return {
                "isValid": False,
                "message": f"goalPurpose in goalProfileList must be 'education' or 'non-education' at item position {index}.",
            }

        # dateValidation = DictDefault(validateDates(x.startDate, x.endDate, payload.currDate))
        # if not dateValidation.isValid:
        #     dateValidation.update({"message": f'{dateValidation.get("message")} at goalProfileList item {index}.'})
        #     return dateValidation

    goalIds = Counter([x.goalId for x in payload.goalProfileList])
    duplicate_goalIds = [item for item, count in Counter(goalIds).items() if count > 1]
    if len(duplicate_goalIds) > 0:
        return {
            "isValid": False,
            "message": "goalId must be unique in goalProfileList.",
        }
    if "lastReallocationDate" in payload and not isDateFormatValid(payload.lastReallocationDate):
        return {
            "isValid": False,
            "message": "lastReallocationDate is optional if provided should follow format dd-mm-yyyy.",
        }

    return {"isValid": True, "message": None}


def validate_goal_simulation_engine_payload(payload):
    if not isinstance(payload.reallocate, bool):
        return {
            "isValid": False,
            "message": "reallocate is mandatory and must be a boolean.",
        }
    if not isinstance(payload.isNewRiskProfile, bool):
        return {
            "isValid": False,
            "message": "isNewRiskProfile is mandatory and must be a boolean.",
        }
    if "isNewInvestmentTenure" in payload and not isinstance(payload.isNewInvestmentTenure, bool):
        return {
            "isValid": False,
            "message": "isNewInvestmentTenure is mandatory and must be a boolean.",
        }
    if "isNewGoal" in payload and not isinstance(payload.isNewGoal, bool):
        return {
            "isValid": False,
            "message": "isNewGoal is mandatory and must be a boolean.",
        }
    if "isNewGoalPriority" in payload and not isinstance(payload.isNewGoalPriority, bool):
        return {
            "isValid": False,
            "message": "isNewGoalPriority is mandatory and must be a boolean.",
        }
    if "isNearTermVolatility" in payload and not isinstance(payload.isNearTermVolatility, bool):
        return {
            "isValid": False,
            "message": "isNearTermVolatility is mandatory and must be a boolean.",
        }
    if "getPath" in payload and not isinstance(payload.getPath, bool):
        return {
            "isValid": False,
            "message": "getPath is mandatory and must be a boolean.",
        }
    if payload.reallocationFreq is None or payload.reallocationFreq not in ["yearly"]:
        return {
            "isValid": False,
            "message": "reallocationFreq is a mandatory field and has to be yearly",
        }
    if "currentPortfolioId" not in payload or (
        payload.currentPortfolioId is not None
        and (
            payload.currentPortfolioId is False
            or (type(payload.currentPortfolioId) == int and payload.currentPortfolioId < 0)
            or type(payload.currentPortfolioId) not in [int]
        )
    ):
        return {
            "isValid": False,
            "message": "currentPortfolioId must be an integer or null.",
        }
    if (
        "lossThreshold" in payload
        and payload.lossThreshold is not None
        and (type(payload.lossThreshold) not in [float, int] or payload.lossThreshold < 0)
    ):
        return {
            "isValid": False,
            "message": "lossThreshold must be a number greater than equal to 0 or null",
        }

    if (
        "colaRate" in payload
        and payload.colaRate is not None
        and (type(payload.colaRate) not in [float, int])
        or (payload.colaRate is not None and (payload.colaRate < 0 or payload.colaRate > 1))
    ):
        return {
            "isValid": False,
            "message": "colaRate must be a number between 0 and 1 or null",
        }

    if "currDate" in payload and payload.currDate is None:
        return {"isValid": False, "message": "currDate is optional and cannt be null."}
    if payload.currDate is not None and not isDateFormatValidV1(payload.currDate):
        return {"isValid": False, "message": "currDate is optional, when provided must be of format dd-mm-yyyy"}

    if "riskProfile" not in payload or not isinstance(payload.riskProfile, str):
        return {
            "isValid": False,
            "message": "riskProfile is mandatory and should be string.",
        }
    if "computeSocialSecurity" in payload and payload.computeSocialSecurity is None:
        return {
            "isValid": False,
            "message": "computeSocialSecurity is optional but is not nullable.",
        }
    if (
        "computeSocialSecurity" in payload
        and payload.computeSocialSecurity is not None
        and not isinstance(payload.computeSocialSecurity, bool)
    ):
        return {
            "isValid": False,
            "message": "computeSocialSecurity must be a boolean.",
        }
    if "useSocialSecurityForGoals" in payload and payload.useSocialSecurityForGoals is None:
        return {
            "isValid": False,
            "message": "useSocialSecurityForGoals is optional but is not nullable.",
        }

    if (
        "useSocialSecurityForGoals" in payload
        and payload.useSocialSecurityForGoals is not None
        and not isinstance(payload.useSocialSecurityForGoals, bool)
    ):
        return {
            "isValid": False,
            "message": "useSocialSecurityForGoals must be a boolean.",
        }
    if "computeRMD" in payload and payload.computeRMD is None:
        return {
            "isValid": False,
            "message": "computeRMD is optional but is not nullable.",
        }

    if "computeRMD" in payload and payload.computeRMD is not None and type(payload.computeRMD) != bool:
        return {
            "isValid": False,
            "message": "computeRMD must be a boolean.",
        }
    if "useRMDForGoals" in payload and payload.useRMDForGoals is None:
        return {
            "isValid": False,
            "message": "useRMDForGoals is optional but is not nullable.",
        }
    if (
        "useRMDForGoals" in payload
        and payload.useRMDForGoals is not None
        and not isinstance(payload.useRMDForGoals, bool)
    ):
        return {
            "isValid": False,
            "message": "useRMDForGoals must be a boolean.",
        }
    if "cashflowDate" in payload and payload.cashflowDate is not None and not isDateFormatValid(payload.cashflowDate):
        return {
            "isValid": False,
            "message": "cashflowDate must be in ISO date format or null.",
        }
    if payload.infusionType not in ["yearly", "monthly"]:
        return {
            "isValid": False,
            "message": "infusionType must be one of yearly or monthly.",
        }

    if "taxRates" not in payload:
        return {
            "isValid": False,
            "message": "taxRates is mandatory.",
        }
    if "taxRates" in payload and not isinstance(payload.taxRates, abc.MutableMapping):
        return {
            "isValid": False,
            "message": "taxRates is not valid must be a mapping object.",
        }
    if "taxRates" in payload:
        if "LTCGPreRetirement" not in payload.taxRates or (
            type(payload.taxRates.LTCGPreRetirement) not in [float, int]
            or not (0 <= payload.taxRates.LTCGPreRetirement <= 1)
        ):
            return {
                "isValid": False,
                "message": "LTCGPreRetirement is mandatory and must be a number between 0 and 1.",
            }
        if "ETRPreRetirement" not in payload.taxRates or (
            (
                type(payload.taxRates.ETRPreRetirement) not in [float, int]
                or not (0 <= payload.taxRates.ETRPreRetirement <= 1)
            )
        ):
            return {
                "isValid": False,
                "message": "ETRPreRetirement is mandatory and must be a number between 0 and 1.",
            }
        if "LTCGPostRetirement" not in payload.taxRates or (
            type(payload.taxRates.LTCGPostRetirement) not in [float, int]
            or not (0 <= payload.taxRates.LTCGPostRetirement <= 1)
        ):
            return {
                "isValid": False,
                "message": "LTCGPostRetirement is mandatory and must be a number between 0 and 1.",
            }
        if "ETRPostRetirement" not in payload.taxRates or (
            type(payload.taxRates.ETRPostRetirement) not in [float, int]
            or not (0 <= payload.taxRates.ETRPostRetirement <= 1)
        ):
            return {
                "isValid": False,
                "message": "ETRPostRetirement is mandatory and must be a number between 0 and 1.",
            }

    if "household" not in payload:
        return {
            "isValid": False,
            "message": "household is mandatory.",
        }
    if "household" in payload and not isinstance(payload.household, abc.MutableMapping):
        return {
            "isValid": False,
            "message": "household is not valid must be a mapping object.",
        }
    if "household" in payload:
        if "householdID" not in payload.household or (not isinstance(payload.household.householdID, str)):
            return {
                "isValid": False,
                "message": "householdID is mandatory and must be a string.",
            }

        state_res_array = [
            "AK",
            "AL",
            "AR",
            "AZ",
            "CA",
            "CO",
            "CT",
            "DC",
            "DE",
            "FL",
            "GA",
            "HI",
            "IA",
            "ID",
            "IL",
            "IN",
            "KS",
            "KY",
            "LA",
            "MA",
            "MD",
            "ME",
            "MI",
            "MN",
            "MO",
            "MS",
            "MT",
            "NC",
            "ND",
            "NE",
            "NH",
            "NJ",
            "NM",
            "NV",
            "NY",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VA",
            "VT",
            "WA",
            "WI",
            "WV",
            "WY",
        ]
        if payload.household.stateOfResidence is not None and (
            not isinstance(payload.household.stateOfResidence, str)
            or payload.household.stateOfResidence not in state_res_array
        ):
            return {
                "isValid": False,
                "message": f"stateOfResidence is not valid, it shoud be any one of these values {state_res_array} ",
            }
        if "memberList" not in payload.household or (not isinstance(payload.household.memberList, abc.MutableSequence)):
            return {
                "isValid": False,
                "message": "memberList is not a valid. Must be an array",
            }

        member_ids = []
        for index, x in enumerate(payload.household.memberList):
            if not isinstance(x.memberType, str) or x.memberType.lower() not in ["primary", "secondary"]:
                return {
                    "isValid": False,
                    "message": f"memberType is mandatory and should be Primary or Secondary in memberList"
                    f" at item position {index}.",
                }
            if not isinstance(x.memberID, str) or x.memberID == "":
                return {
                    "isValid": False,
                    "message": f"memberID is mandatory and not valid in memberList at item position {index}.",
                }
            member_ids.append(x.memberID)
            if not is_valid_format_mmyyyy(x.DOB):
                return {
                    "isValid": False,
                    "message": f"DOB is mandatory and should be in 'MM-YYYY' format in memberList at item position {index}.",
                }
            if datetime.datetime.strptime(x.DOB, "%m-%Y").strftime("%Y-%m") > datetime.datetime.now().strftime("%Y-%m"):
                return {"isValid": False, "message": "DOB is less than the current Date"}
            if type(x.currentAge) != int or not (1 <= x.currentAge <= 100):
                return {
                    "isValid": False,
                    "message": "currentAge is mandatory and should be between 1 and 100 "
                    f"in memberList at item position {index}.",
                }
            if type(x.retirementAge) != int or not (1 <= x.retirementAge <= 100):
                return {
                    "isValid": False,
                    "message": "retirementAge is mandatory and should be between 1 and 100"
                    f" in memberList at item position {index}.",
                }
            if type(x.currentSalary) not in [int, float] or x.currentSalary <= 0:
                return {
                    "isValid": False,
                    "message": f"currentSalary should be greater than 0 in memberList at item position {index}.",
                }
            if type(x.socialSecurityStartAge) != int or not (62 <= x.socialSecurityStartAge <= 70):
                return {
                    "isValid": False,
                    "message": f"socialSecurityStartAge must be between 62 and 70 in memberList at item position {index}.",
                }
            if payload.computeRMD is True and x.TDABalanceForRMD is None:
                return {
                    "isValid": False,
                    "message": "TDABalanceForRMD is mandatory when computeRMD is True.",
                }
            if (
                "TDABalanceForRMD" in x
                and x.TDABalanceForRMD is not None
                and (type(x.TDABalanceForRMD) not in [int, float] or x.TDABalanceForRMD <= 0)
            ):
                return {
                    "isValid": False,
                    "message": "TDABalanceForRMD is not valid number and should be greater than 0.",
                }
            if payload.computeRMD is True and x.RMDUtilized is None:
                return {
                    "isValid": False,
                    "message": "RMDUtilized is mandatory when computeRMD is True.",
                }
            if (
                "RMDUtilized" in x
                and x.RMDUtilized is not None
                and (type(x.RMDUtilized) not in [int, float] or x.RMDUtilized < 0)
            ):
                return {
                    "isValid": False,
                    "message": "RMDUtilized is not valid number and should be greater than or equal to 0.",
                }

            if (
                x.existingMonthlySocialSecurityAmount is not None
                and type(x.existingMonthlySocialSecurityAmount) not in [int, float]
            ) or (x.existingMonthlySocialSecurityAmount is not None and x.existingMonthlySocialSecurityAmount < 0):
                return {
                    "isValid": False,
                    "message": "existingMonthlySocialSecurityAmount is not valid number and should be greater than or equal to 0.",
                }

    if not isinstance(payload.accounts, abc.MutableSequence):
        return {
            "isValid": False,
            "message": f"accounts object is not valid array at item position {index}.",
        }
    for index, x in enumerate(payload.accounts):
        if not isinstance(x.accountID, str) or x.accountID == "":
            return {
                "isValid": False,
                "message": f"accountID is mandatory and should be valid string in accounts at item position {index}.",
            }
        if not isinstance(x.taxabilityType, str) or x.taxabilityType not in ["T", "D", "F"]:
            return {
                "isValid": False,
                "message": f"taxabilityType is not valid in accounts at item position {index}. valid values are 'T', 'D', 'F'",
            }
        if x.taxabilityType in [
            "D",
            "F",
        ]:
            if not isinstance(x.accountType, str) or x.accountType not in ["401k", "IRA"]:
                return {
                    "isValid": False,
                    "message": f"accountType is not valid in accounts at item position {index}. valid values are '401k', 'IRA'",
                }

        if x.taxabilityType in ["T"]:
            if x.accountType is not None:
                return {
                    "isValid": False,
                    "message": f"accountType is not valid in accounts at item position {index}.",
                }

        if not isinstance(x.memberIDs, abc.MutableSequence):
            return {
                "isValid": False,
                "message": f"memberIDs is not valid and must be an array in accounts at item position {index}.",
            }
        if len(x.memberIDs) == 0:
            return {
                "isValid": False,
                "message": f"memberIDs should have atleast on value in accounts at item position {index}",
            }
        for mid, y in enumerate(x.memberIDs):
            if type(y) != str or y == "":
                return {
                    "isValid": False,
                    "message": f"memberIDs value must be non empty string at index {mid}"
                    f" in accounts > memberIDs at item position {index}",
                }
            if y not in member_ids:
                return {
                    "isValid": False,
                    "message": f"memberIDs value at index {mid} should match memberID in memberList,"
                    f" Issue in accounts > memberIDs at item position {index} .",
                }

        if type(x.currentBalance) not in [int, float] or x.currentBalance < 0:
            return {
                "isValid": False,
                "message": f"currentBalance must be integer or float in accounts at item position {index}.",
            }
        if not isinstance(x.cashflowDetails, abc.MutableMapping):
            return {
                "isValid": False,
                "message": f"cashflowDetails is not valid. Must be an mapping object in accounts at item position {index}.",
            }
        # if len(x.cashflowDetails.cashflowAmt) == 0:
        #     return {
        #         "isValid": False,
        #         "message": f"cashflowAmt cannt be empty in accounts at item position {index}.",
        #     }
        for y in x.cashflowDetails.cashflowAmt:
            if type(y) not in [float, int]:
                return {
                    "isValid": False,
                    "message": f"{y} in cashflowAmt is not valid integer or float in accounts at item position {index}.",
                }
        if not isDateFormatValidV1(x.cashflowDetails.startDate):
            return {
                "isValid": False,
                "message": f"startDate in cashflowDetails must be of format dd-mm-yyyy at item position {index}.",
            }
        if "cashflowDate" in payload:
            if not (
                datetime.datetime.strptime(x.cashflowDetails.startDate, "%d-%m-%Y").strftime("%d-%m")
                == datetime.datetime.strptime(payload.cashflowDate, "%d-%m-%Y").strftime("%d-%m")
            ):
                return {"isValid": False, "message": f"startdate must be cashflow date only at item position {index}."}
        else:
            if not (
                datetime.datetime.strptime(x.cashflowDetails.startDate, "%d-%m-%Y").strftime("%d-%m")
                == datetime.datetime.strptime("01-01", "%d-%m").strftime("%d-%m")
            ):
                return {"isValid": False, "message": f"startdate must be cashflow date only at item position {index}."}
        if not isDateFormatValidV1(x.cashflowDetails.endDate):
            return (
                {
                    "isValid": False,
                    "message": f"endDate in cashflowDetails must be of format dd-mm-yyyy at item position {index}.",
                },
            )
        if datetime.datetime.strptime(x.cashflowDetails.endDate, "%d-%m-%Y") < datetime.datetime.strptime(
            x.cashflowDetails.startDate, "%d-%m-%Y"
        ):
            return {
                "isValid": False,
                "message": f"endDate in cashflowDetails must be greater than startDate at item position {index}.",
            }

        if "cashflowDate" in payload:
            if not (
                datetime.datetime.strptime(x.cashflowDetails.endDate, "%d-%m-%Y").strftime("%d-%m")
                == datetime.datetime.strptime(payload.cashflowDate, "%d-%m-%Y").strftime("%d-%m")
            ):
                return {"isValid": False, "message": f"enddate must be cashflow date only at item position {index}."}
        else:
            if not (
                datetime.datetime.strptime(x.cashflowDetails.endDate, "%d-%m-%Y").strftime("%d-%m")
                == datetime.datetime.strptime("01-01", "%d-%m").strftime("%d-%m")
            ):
                return {"isValid": False, "message": f"enddate must be cashflow date only at item position {index}."}

        if not isinstance(x.currentHoldings, abc.MutableSequence):
            return {
                "isValid": False,
                "message": f"currentHoldings must be an array in accounts at item position {index}.",
            }
        if len(x.currentHoldings) == 0:
            return {
                "isValid": False,
                "message": f"currentHoldings in accounts must have atleast one object at item position {index}.",
            }

        for index, y in enumerate(x.currentHoldings):
            if not isinstance(y, abc.MutableMapping):
                return {
                    "isValid": False,
                    "message": f"Item must be mapping object in currentHoldings in accounts at item position {index}.",
                }
            if not isinstance(y.categoryName, str) or not y.categoryName:
                return {
                    "isValid": False,
                    "message": f"categoryName is not valid in currentHoldings in accounts at item position {index}.",
                }
            if not isinstance(y.categoryID, str) or y.categoryID == "":
                return {
                    "isValid": False,
                    "message": f"categoryID is not valid in currentHoldings in accounts at item position {index}.",
                }
            if type(y.categoryPrice) not in [int, float] or y.categoryPrice < 0:
                return {
                    "isValid": False,
                    "message": f"categoryPrice is not valid in currentHoldings in accounts at item position {index}.",
                }
            if type(y.quantity) not in [int, float] or y.quantity < 0:
                return {
                    "isValid": False,
                    "message": f"quantity is not valid in currentHoldings in accounts at item position {index}.",
                }
            if type(y.costBasis) not in [int, float] or y.costBasis < 0:
                return {
                    "isValid": False,
                    "message": f"costBasis is not valid in costBasis in accounts at item position {index}.",
                }

    if not isinstance(payload.goalProfileList, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goalProfileList must be an array.",
        }
    if len(payload.goalProfileList) == 0:
        return {
            "isValid": False,
            "message": "goalProfileList must have atleast one object.",
        }

    for index, x in enumerate(payload.goalProfileList):
        if not isinstance(x, abc.MutableMapping):
            return {
                "isValid": False,
                "message": f"goalProfileList must be a mapping object at item position {index}.",
            }
        if type(x.goalId) is not str or not re.match("^[ A-Za-z0-9]+$", x.goalId):
            return {
                "isValid": False,
                "message": "goalId in goalProfileList is mandatory and should only contain letters, numbers and"
                f" spaces at item position {index}.",
            }

        if not isinstance(x.goalAmt, abc.MutableSequence):
            return {
                "isValid": False,
                "message": f"goalAmt in goalProfileList must be array at item position {index}.",
            }
        for idx, amt in enumerate(x.goalAmt):
            if type(amt) not in [float, int] or amt < 0:
                return {
                    "isValid": False,
                    "message": "Every value in goalAmt must be integer or float in goalProfileList"
                    f" at item position {index}, {idx}.",
                }

        if type(x.scenarioType) != str:
            return {
                "isValid": False,
                "message": f"scenarioType in goalProfileList is not valid at item position {index}.",
            }
        if x.scenarioType not in ["retirement", "regular"]:
            return {
                "isValid": False,
                "message": f"scenarioType in goalProfileList must be 'retirement' or 'regular' at item position {index}.",
            }
        if type(x.startDate) != str or not isDateFormatValidV1(x.startDate):
            return {
                "isValid": False,
                "message": f"startDate in goalProfileList must be of format dd-mm-yyyy at item position {index}.",
            }
        if type(x.endDate) != str or not isDateFormatValidV1(x.endDate):
            return {
                "isValid": False,
                "message": f"endDate in goalProfileList must be of format dd-mm-yyyy at item position {index}.",
            }
        if datetime.datetime.strptime(x.endDate, "%d-%m-%Y") < datetime.datetime.strptime(x.startDate, "%d-%m-%Y"):
            return {
                "isValid": False,
                "message": f"endDate in goalProfileList must be greater than startDate at item position {index}.",
            }

        if x.priority not in ["Need", "Want", "Wish", "Dream"]:
            return {
                "isValid": False,
                "message": f"priority in goalProfileList must be 'Need', 'Want', 'Wish' or 'Dream' at item position {index}.",
            }
        if ("bequest" in x and x.bequest is not None) and type(x.bequest) != bool:
            return {
                "isValid": False,
                "message": f"bequest in goalProfileList must be a boolean at item position {index}.",
            }
        if not isinstance(x.goalPurpose, str) or x.goalPurpose.lower() not in ["education", "non-education"]:
            return {
                "isValid": False,
                "message": f"goalPurpose in goalProfileList must be 'education' or 'non-education' at item position {index}.",
            }

        # dateValidation = DictDefault(validateDates(x.startDate, x.endDate, payload.currDate))
        # if not dateValidation.isValid:
        #     dateValidation.update({"message": f'{dateValidation.get("message")} at goalProfileList item {index}.'})
        #     return dateValidation

    goalIds = Counter([x.goalId for x in payload.goalProfileList])
    duplicate_goalIds = [item for item, count in Counter(goalIds).items() if count > 1]
    if len(duplicate_goalIds) > 0:
        return {
            "isValid": False,
            "message": "goalId must be unique in goalProfileList.",
        }

    return {"isValid": True, "message": None}


async def hantz_translator_api(req, body):
    L = request.vars["L"]
    ptf = await prepare_portfolio(req, body)
    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    body = ptf.get("body")
    body = DictDefault(body)

    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/translator",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }

    validate_translator_payload = validate_translator_api(body)
    isValid = validate_translator_payload.get("isValid")
    message = validate_translator_payload.get("message")
    L.info(f"validate_translator_payload---------------- {isValid}, {message}")
    if not isValid:
        return {"statusCode": 400, "message": "Validation Error", "body": message}

    config = DictDefault(config)
    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    L.info(f"validateIfRiskProfileisRiskProfileValid-------------{isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return {"statusCode": 400, "message": "Validation Error", "body": riskProfileErrorMessage}

    body.requiredDataAvailable = False  # set here to use existing function.
    glide_path_data = await generateGlidePathData(body, config)
    if glide_path_data:
        glide_path_data = glide_path_data["actuarialData"]
    goe_tables = {}
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(body, config)
        if age_based_equity_data:
            goe_tables.update(age_based_equity_data["actuarialData"])
    portfolio_mapping_data = await generatePortfolioMappingData(body, config)
    if portfolio_mapping_data:
        portfolio_mapping_data = portfolio_mapping_data["actuarialData"]
    pay_load_response = generateTranslatorPayload(
        body, config, portfolios, glide_path_data, portfolio_mapping_data, goe_tables, ptf
    )
    error = pay_load_response.get("error")
    pipePayload = pay_load_response.get("data")
    L.info(f"generateTranslatorPayload ------------------------------ {error}")
    if error:
        return {"statusCode": 400, "message": error, "body": pipePayload}
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/translator",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    L.info(logData)
    if generatePayloadOnly:
        return {"statusCode": 200, "message": "Success", "body": pipePayload}
    else:
        return pipePayload
    # handler = goe_api_response_handler(logData, None)
    # return (pipePayload, handler)


async def goe_decumulation_api(request, req, body, res=None):
    L = request.state.vars["L"]
    ptf = await prepare_portfolio(req, body, request)
    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    body = ptf.get("body")
    body = DictDefault(body)

    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/goefordecumulation",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }

    validate_payload = validate_decumulation_api(ptf, body)
    isValid = validate_payload.get("isValid")
    message = validate_payload.get("message")
    L.info(f"validate_payload---------------- {isValid}, {message}")
    if not isValid:
        return {"statusCode": 400, "message": "Validation Error", "body": message}
    body.debug = False
    if req["headers"].get("debug") == "true":
        body.debug = True

    config = DictDefault(config)
    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    L.info(f"validateIfRiskProfileisRiskProfileValid-------------{isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return {"statusCode": 400, "message": "Validation Error", "body": riskProfileErrorMessage}

    body.requiredDataAvailable = False  # set here to use existing function.
    glide_path_data = await generateGlidePathData(body, config, request_type="decumulation", req=request)
    if glide_path_data:
        glide_path_data = glide_path_data["actuarialData"]
    portfolio_mapping_data = await generatePortfolioMappingData(body, config, request_type="decumulation", req=request)
    if portfolio_mapping_data:
        portfolio_mapping_data = portfolio_mapping_data["actuarialData"]
    goe_tables = await getDataTablesforDecumulation(body, config, request_type="decumulation", req=request)
    decumulation_uploads = await get_decumulation_uploads(body, config, request_type="decumulation", req=request)
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(
            body, config, request_type="decumulation", req=request
        )
        if age_based_equity_data:
            goe_tables.update(age_based_equity_data["actuarialData"])

    pay_load_response = generate_decumulation_payload(
        body, config, portfolios, goe_tables, decumulation_uploads, ptf
    )  # TODO change to Decumulation generate payload
    error = pay_load_response.get("error")
    pipePayload = pay_load_response.get("data")
    L.info(f"generateTranslatorPayload ------------------------------ {error}")
    if error:
        return {"statusCode": 400, "message": error, "body": pipePayload}
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/goefordecumulation",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    L.info(logData)
    if generatePayloadOnly:
        return {"statusCode": 200, "message": "Success", "body": pipePayload}
    else:
        return pipePayload


async def social_security_calculator_api(req, payload):
    """Get social security calc.

    Returns:
        str: json result
    """
    payload = DictDefault(payload)
    # Read only social security specific configurations.
    app_config = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppZoneSettings(
            request=rest_pb2.AppSettingsRequest(app="goe", zone="client-settings"),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    app_config = app_config["social_security_config"]

    response = await validate_social_security_calc(payload, app_config)
    if response.get("isValid"):
        return await generate_social_security_payload(req, payload, app_config)
    else:
        return {
            "body": response.get("body"),
            "message": response.get("message"),
            "errorCode": response.get("errorCode"),
            "statusCode": 400,
        }


def year_limits(lower, upper, date):
    date = datetime.datetime.strptime(date, "%d-%m-%Y")
    current_date = datetime.datetime.strptime(
        datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y"), "%d-%m-%Y"
    )
    return (current_date - relativedelta(years=upper)) <= date <= (current_date - relativedelta(years=lower))


def set_default_values_for_social_security_calc(payload, app_config):
    if "mortalityTableType" not in payload:
        payload.mortalityTableType = "2017 SSA Period Life Table"
    if "yearlyIncomeMethod" not in payload:
        payload.yearlyIncomeMethod = "ssaMethod"
    if "filingStrategyRecommendation" not in payload:
        payload.filingStrategyRecommendation = False
    # if "currentYear" not in payload:
    # check_if_default_keys_available= set(app_config["default_values"]) - set("currentYear", "ageOfFirstIncome")
    for i in app_config["default_values"]:
        payload[i] = app_config["default_values"][i]
    if "ageOfFirstIncome" in payload:
        payload["ageOfFirstIncome"] = int(payload["ageOfFirstIncome"])
    if "currentYear" in payload:
        payload["currentYear"] = int(payload["currentYear"])
    return payload


async def generate_tables_social_security_calc(req, app_config):
    social_security_config = app_config
    if social_security_config is None:
        return {"message": "social_security_config doc is missing in goe-settings in document db.", "statusCode": 400}
    else:
        configs = social_security_config.get("configs")
        if not configs:
            return {
                "body": "social_security_config doc is missing in goe-settings in document db.",
                "statusCode": 400,
                "message": "Config Error",
            }
    user, _ = await get_user_profile(req)

    profile = DictDefault(user.get("app_settings"))
    if not profile:
        return {"statusCode": 400, "body": "user dont have access or dont exist.", "message": "User Error"}
    config_names = dict([(c.get("name"), c.get("api_key")) for c in configs])
    social_sec_configs = [
        (i.get("id"), i.get("type"))
        for i in profile.goe.get("client-settings").config.goalPriority.generalSettings.actuarials
        if i.get("type") in config_names
    ]
    result = {}
    if len(social_sec_configs) != len(config_names):
        return {"body": "Not all data tables are configured for user.", "statusCode": 400, "message": "Config Error"}

    if social_sec_configs:
        data = zip(*social_sec_configs)
        if data:
            actuarial_ids, actuarial_types = data
            result = await read_actuarial_files(actuarial_ids, actuarial_types)

    input_files_payload = {}
    for key, val in result.items():
        if key in actuarial_types:
            input_files_payload[config_names[key]] = val
    return input_files_payload


async def generate_social_security_payload(req, payload, app_config):
    input_files_payload = await generate_tables_social_security_calc(req, app_config)
    currentYear = payload.currentYear if payload.currentYear is not None else 2022

    del payload["currentYear"]
    accepted_keys = [
        "dateOfBirth",
        "gender",
        "lifestyleStatus",
        "entitlementDate",
        "considerAWIGrowth",
        "considerBenefitsGrowth",
        "yearlyIncomeMethod",
        "ageOfFirstIncome",
        "firstIncomeAmount",
        "incomeGrowthPercentage",
        "yearlyEarningList",
        "latestIncome",
        "yearOfLatestIncome",
        "lastYearOfEarning",
        "growthRateAboveAWI",
        "filingStrategyRecommendation",
    ]
    pipe_payload = dict((key, payload.get(key)) for key in accepted_keys)

    return {
        "body": {"inputFileCollection": input_files_payload, "user_profile": pipe_payload, "currentYear": currentYear},
        "statusCode": 200,
    }


async def generate_social_security_data_tables(req):
    # Read only social security specific configurations.
    app_config = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppZoneSettings(
            request=rest_pb2.AppSettingsRequest(app="goe", zone="client-settings"),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    app_config = app_config["social_security_config"]

    return await generate_tables_social_security_calc(req, app_config)


async def validate_social_security_calc(payload, app_config):
    payload = set_default_values_for_social_security_calc(payload, app_config)
    validation_error_msg = "Validation Error."
    if "dateOfBirth" not in payload or (payload.dateOfBirth and not isDateFormatValid(payload.dateOfBirth)):
        return {
            "isValid": False,
            "errorCode": 5001,
            "body": "dateOfBirth is mandatory and date format dd-mm-yyyy",
            "message": validation_error_msg,
        }
    if payload.dateOfBirth and not year_limits(22, 98, payload.dateOfBirth):
        return {
            "isValid": False,
            "errorCode": 5002,
            "body": "User should be of age between 22 and 98 to access the calculator.",
            "message": validation_error_msg,
        }
    if "gender" not in payload:
        return {
            "isValid": False,
            "errorCode": 5003,
            "body": "gender is mandatory.",
            "message": validation_error_msg,
        }

    if payload.gender not in ["Male", "Female", "Non Disclosure"]:
        return {
            "isValid": False,
            "errorCode": 5004,
            "body": "Gender should be either 'Male' or 'Female'.",
            "message": validation_error_msg,
        }
    if "lifestyleStatus" not in payload:
        return {
            "isValid": False,
            "errorCode": 5005,
            "body": "lifestyleStatus is mandatory.",
            "message": validation_error_msg,
        }

    if "lifestyleStatus" not in payload or payload.lifestyleStatus not in [
        "General",
        "Non-smoker and super-preferred",
        "Non-smoker and preferred",
        "Smoker and preferred",
        "Smoker and residual-standard",
    ]:
        return {
            "isValid": False,
            "errorCode": 5006,
            "body": """Lifestylestatus should be one of the following: 'General', """
            """'Non-smoker and super-preferred', 'Non-smoker and preferred','Smoker and preferred',"""
            """'Smoker and residual-standard'.""",
            "message": validation_error_msg,
        }
    if "entitlementDate" not in payload:
        return {
            "isValid": False,
            "errorCode": 5007,
            "body": "entitlementDate is mandatory.",
            "message": validation_error_msg,
        }
    if "entitlementDate" in payload and isDateFormatValid(payload.entitlementDate):
        date_of_birth = datetime.datetime.strptime(payload.dateOfBirth, "%d-%m-%Y")
        entitlement_date = datetime.datetime.strptime(payload.entitlementDate, "%d-%m-%Y")

    if (
        "entitlementDate" not in payload
        or not isinstance(payload.entitlementDate, str)
        or not isDateFormatValid(payload.entitlementDate)
        or not (
            (entitlement_date - relativedelta(years=70))
            <= date_of_birth
            <= (entitlement_date - relativedelta(years=62))
        )
    ):
        return {
            "isValid": False,
            "errorCode": 5008,
            "body": "Age of entitlement should be between 62 and 70.",
            "message": validation_error_msg,
        }

    if "considerAWIGrowth" not in payload:
        return {
            "isValid": False,
            "errorCode": 5009,
            "body": "considerAWIGrowth is mandatory.",
            "message": validation_error_msg,
        }

    if not isinstance(payload.considerAWIGrowth, bool):
        return {
            "isValid": False,
            "errorCode": 5010,
            "body": "considerAWIGrowth should be either TRUE or FALSE.",
            "message": validation_error_msg,
        }

    if "considerBenefitsGrowth" not in payload:
        return {
            "isValid": False,
            "errorCode": 5011,
            "body": "considerBenefitsGrowth is mandatory.",
            "message": validation_error_msg,
        }

    if not isinstance(payload.considerBenefitsGrowth, bool):
        return {
            "isValid": False,
            "errorCode": 5012,
            "body": "considerBenefitsGrowth should be either TRUE or FALSE",
            "message": validation_error_msg,
        }

    if "yearlyIncomeMethod" in payload and payload.yearlyIncomeMethod not in [
        "ssaMethod",
        "IncomeGrowthMethod",
        "AWIMethod",
        "manualIncomeEntry",
    ]:
        return {
            "isValid": False,
            "errorCode": 5013,
            "body": 'YearlyIncomeMethod should be one of the following: "ssaMethod","IncomeGrowthMethod",\
                "AWIMethod","manualIncomeEntry".',
            "message": validation_error_msg,
        }

    # if ("ageOfFirstIncome" not in payload or not isinstance(payload.get("ageOfFirstIncome"), int)) or (
    #     payload.get("ageOfFirstIncome") != app_config["default_values"]["ageOfFirstIncome"]
    # ):
    #     return {
    #         "errorCode": 5009,
    #         "isValid": False,
    #         "body": f"ageOfFirstIncome should be {app_config['default_values']['ageOfFirstIncome']}.",
    #     }

    if payload.yearlyIncomeMethod == "IncomeGrowthMethod" and "firstIncomeAmount" not in payload:
        return {
            "isValid": False,
            "errorCode": 5014,
            "body": "firstIncomeAmount is mandatory when yearlyIncomeMethod is IncomeGrowthMethod.",
            "message": validation_error_msg,
        }
    if "firstIncomeAmount" in payload and (
        type(payload.firstIncomeAmount) not in [int, float] or not (payload.firstIncomeAmount >= 1)
    ):
        return {
            "isValid": False,
            "errorCode": 5015,
            "body": "FirstIncomeAmount should be a number greater than 0.",
            "message": validation_error_msg,
        }

    if payload.yearlyIncomeMethod == "IncomeGrowthMethod" and "incomeGrowthPercentage" not in payload:
        return {
            "isValid": False,
            "errorCode": 5016,
            "body": "IncomeGrowthPercentage is mandatory when yearlyIncomeMethod is IncomeGrowthMethod",
            "message": validation_error_msg,
        }
    if (
        "incomeGrowthPercentage" in payload
        and type(payload.incomeGrowthPercentage) not in [int, float]
        or ("incomeGrowthPercentage" in payload and not (0 <= payload.incomeGrowthPercentage <= 100))
    ):
        return {
            "isValid": False,
            "errorCode": 5017,
            "body": "IncomeGrowthPercentage should be between 0 to 100.",
            "message": validation_error_msg,
        }

    earning_list = datetime.datetime.strptime(payload.entitlementDate, "%d-%m-%Y").year - (
        datetime.datetime.strptime(payload.dateOfBirth, "%d-%m-%Y").year + payload.ageOfFirstIncome
    )
    earning_list += 1
    if payload.yearlyIncomeMethod == "manualIncomeEntry" and not payload.yearlyEarningList:
        return {
            "isValid": False,
            "errorCode": 5018,
            "body": "yearlyEarningList is mandatory if yearlyIncomeMethod is 'manualIncomeEntry' else Optional",
            "message": validation_error_msg,
        }
    if "yearlyEarningList" in payload and payload.yearlyEarningList is not None:
        if not isinstance(payload.yearlyEarningList, list) or len(payload.yearlyEarningList) > earning_list:
            return {
                "isValid": False,
                "errorCode": 5019,
                "body": "YearlyEarningList has more elements than required.",
                "message": validation_error_msg,
            }
        if not isinstance(payload.yearlyEarningList, list) or len(payload.yearlyEarningList) < earning_list:
            return {
                "isValid": False,
                "errorCode": 5020,
                "body": "YearlyEarningList has less elements than required.",
                "message": validation_error_msg,
            }
        for i in payload.yearlyEarningList:
            if type(i) not in [int, float]:
                return {"isValid": False, "errorCode": 5016, "body": "yearlyEarningList should contain numbers."}
    if payload.yearlyIncomeMethod in ["ssaMethod", "AWIMethod"] and "latestIncome" not in payload:
        return {
            "isValid": False,
            "errorCode": 5021,
            "body": "latestIncome is mandatory when yearlyIncomeMethod is ssaMethod, AWIMethod",
            "message": validation_error_msg,
        }

    if ("latestIncome" in payload and not type(payload.latestIncome) in [int, float]) or (
        "latestIncome" in payload and not (payload.latestIncome >= 1)
    ):
        return {
            "isValid": False,
            "errorCode": 5022,
            "body": "Latestincome should be a number greater than 0.",
            "message": validation_error_msg,
        }

    if payload.yearlyIncomeMethod in ["ssaMethod", "AWIMethod"] and "yearOfLatestIncome" not in payload:
        return {
            "isValid": False,
            "errorCode": 5023,
            "body": "yearOfLatestIncome is mandatory when yearlyIncomeMethod is ssaMethod, AWIMethod",
            "message": validation_error_msg,
        }

    if ("yearOfLatestIncome" in payload and not type(payload.yearOfLatestIncome) in [int]) or (
        "yearOfLatestIncome" in payload
        and not (
            payload.yearOfLatestIncome
            > (datetime.datetime.strptime(payload.dateOfBirth, "%d-%m-%Y").year + payload.ageOfFirstIncome)
        )
    ):
        return {
            "isValid": False,
            "errorCode": 5024,
            "body": "yearOfLatestIncome needs to be after the year of first income",
            "message": validation_error_msg,
        }
    if "yearOfLatestIncome" in payload and not (
        payload.yearOfLatestIncome
        < min(payload.currentYear, datetime.datetime.strptime(payload.entitlementDate, "%d-%m-%Y").year)
    ):
        return {
            "isValid": False,
            "errorCode": 5025,
            "body": "YearOfLatestIncome should be after the year of first income and"
            " ( less than the entitlement date) and (less than current year)",
            "message": validation_error_msg,
        }
    # if (
    #     payload.yearlyIncomeMethod in ["ssaMethod", "IncomeGrowthMethod", "AWIMethod"]
    #     and "lastYearOfEarning" not in payload
    # ):
    #     return {
    #         "isValid": False,
    #         "errorCode": 5021,
    #         "body": "lastYearOfEarning is mandatory when yearlyIncomeMethod is "
    #         "ssaMethod, IncomeGrowthMethod, AWIMethod",
    #     }

    # if ("lastYearOfEarning" in payload and not type(payload.lastYearOfEarning) in [int]) or (
    #     "lastYearOfEarning" in payload
    #     and not (
    #         payload.lastYearOfEarning
    #         > (datetime.datetime.strptime(payload.dateOfBirth, "%d-%m-%Y").year + payload.ageOfFirstIncome)
    #     )
    # ):
    #     return {
    #         "isValid": False,
    #         "errorCode": 5022,
    #         "body": "lastYearOfEarning needs to be after the year of first income.",
    #     }

    if payload.yearlyIncomeMethod in ["ssaMethod", "AWIMethod"] and "growthRateAboveAWI" not in payload:
        return {
            "isValid": False,
            "errorCode": 5026,
            "body": "growthRateAboveAWI is mandatory when yearlyIncomeMethod is ssaMethod, AWIMethod.",
            "message": validation_error_msg,
        }
    # if "lastYearOfEarning" in payload and payload.lastYearOfEarning != (
    #     datetime.datetime.strptime(payload.entitlementDate, "%d-%m-%Y").year - 1
    # ):
    #     return {
    #         "isValid": False,
    #         "errorCode": 5024,
    #         "body": "lastYearOfEarning must be one year prior to entitlementDate.",
    #     }
    if ("growthRateAboveAWI" in payload and not type(payload.growthRateAboveAWI) in [float, int]) or (
        "growthRateAboveAWI" in payload and not (0 <= payload.growthRateAboveAWI <= 100)
    ):
        return {
            "isValid": False,
            "errorCode": 5027,
            "body": "growthRateAboveAWI should be between 0 to 100.",
            "message": validation_error_msg,
        }

    if "filingStrategyRecommendation" in payload and not isinstance(payload.filingStrategyRecommendation, bool):
        return {
            "isValid": False,
            "errorCode": 5026,
            "body": "filingStrategyRecommendation should be either TRUE or FALSE.",
            "message": validation_error_msg,
        }
    # if (
    #     payload.currentYear is not None
    #     and not isinstance(payload.currentYear, int)
    #     and 2021 <= payload.currentYear <= 2199
    # ):
    #     return {
    #         "isValid": False,
    #         "errorCode": 5027,
    #         "body": "currentYear must be a valid year.",
    #     }
    return {"isValid": True, "body": ""}


def validate_replacement_calculator_api(payload):
    if not isDateFormatValidV1(payload.dateOfBirth):
        return {
            "isValid": False,
            "message": "dateOfBirth is mandatory and required format is dd-mm-yyyy.",
        }
    date_of_birth = datetime.datetime.strptime(payload.dateOfBirth, "%d-%m-%Y")
    curr_age = calculateAge(date_of_birth)
    if payload.retirementAge is None or (
        payload.retirementAge is not None
        and (type(payload.retirementAge) not in [int] or payload.retirementAge <= curr_age)
    ):
        return {"isValid": False, "message": "retirementAge is mandatory and must be greater than currentAge."}
    if (payload.planningAge is None) or (
        payload.planningAge is not None
        and (type(payload.planningAge) not in [int] or payload.planningAge <= payload.retirementAge)
    ):
        return {"isValid": False, "message": "planningAge is mandatory and must be greater than retirementAge."}
    if type(payload.currentSalary) not in [int, float] or payload.currentSalary < 0:
        return {
            "isValid": False,
            "message": "currentSalary is mandatory and should be greater than or equal to 0.",
        }
    if "salaryGrowthRate" not in payload:
        payload.salaryGrowthRate = 0
    if type(payload.salaryGrowthRate) not in [int, float] or payload.salaryGrowthRate < 0:
        return {
            "isValid": False,
            "message": "salaryGrowthRate when not provided default to 0 else should be greater than 0.",
        }
    if "outsideAccountBalance" not in payload:
        payload.outsideAccountBalance = 0
    if type(payload.outsideAccountBalance) not in [int, float] or payload.outsideAccountBalance < 0:
        return {
            "isValid": False,
            "message": "outsideAccountBalance when not provided default to 0 else should be greater than 0.",
        }
    if "companyContribution" not in payload:
        payload.companyContribution = 0

    if type(payload.companyContribution) not in [int, float] or payload.companyContribution < 0:
        return {
            "isValid": False,
            "message": "companyContribution when not provided default to 0 else should be greater than 0.",
        }

    if type(payload.traditionContribution) not in [int, float] or not (0 <= payload.traditionContribution <= 100):
        return {
            "isValid": False,
            "message": "traditionContribution is mandatory and should be between 0 and 100.",
        }

    if payload.rothContribution is not None and (
        type(payload.rothContribution) not in [int, float] or not (0 <= payload.rothContribution <= 100)
    ):
        return {
            "isValid": False,
            "message": "rothContribution is optional when provided should be between 0 and 100.",
        }

    if payload.considerAWIGrowth is not None and (not isinstance(payload.considerAWIGrowth, bool)):
        return {
            "isValid": False,
            "message": "considerAWIGrowth is optional when provided should be boolean.",
        }

    if payload.considerBenefitsGrowth is not None and (not isinstance(payload.considerBenefitsGrowth, bool)):
        return {
            "isValid": False,
            "message": "considerBenefitsGrowth is optional when provided should be boolean.",
        }

    if payload.autoEscalationRoth is not None and (
        type(payload.autoEscalationRoth) not in [int, float] or payload.autoEscalationRoth < 0
    ):
        return {
            "isValid": False,
            "message": "autoEscalationRoth is optional when provided should be greater than or equal to 0.",
        }
    if payload.autoEscalationTraditional is not None and (
        type(payload.autoEscalationTraditional) not in [int, float] or payload.autoEscalationTraditional < 0
    ):
        return {
            "isValid": False,
            "message": "autoEscalationTraditional is optional when provided should be greater than or equal to 0.",
        }
    if payload.replacementRate is None:
        payload.replacementRate = 100
    if type(payload.replacementRate) not in [int, float] or not (0 <= payload.replacementRate <= 100):
        return {
            "isValid": False,
            "message": "replacementRate should be between 0 and 100.",
        }

    if payload.socialSecurityIncome is not None and (
        type(payload.socialSecurityIncome) not in [int, float] or payload.socialSecurityIncome < 0
    ):
        return {
            "isValid": False,
            "message": "socialSecurityIncome is optional when provided must be greater than or equal to 0.",
        }
    if "outsideIncome" not in payload:
        payload.outsideIncome = 0
    if type(payload.outsideIncome) not in [int, float] or payload.outsideIncome < 0:
        return {
            "isValid": False,
            "message": "outsideIncome should be greater than 0.",
        }
    if "state" not in payload:
        payload.state = "default"
    if payload.state is not None and (type(payload.state) not in [str]):
        return {
            "isValid": False,
            "message": "state is not a valid value but this is optional and default value is default when not provided.",
        }
    if "inflation" not in payload:
        payload.inflation = 0
    if type(payload.inflation) not in [int, float] or payload.inflation < 0:
        return {
            "isValid": False,
            "message": "inflation should be greater than or equal to 0.",
        }

    return {"isValid": True, "message": None}


async def replacement_income_calculator_api(req, body):
    user, generatePayloadOnly = await get_user_profile(req)
    if not user.get("app_settings") or not user["app_settings"].get("goe"):
        ValidationError.messages = "app_settings not found user to process further"
        raise ValidationError
    user = DictDefault(user["app_settings"]["goe"]["client-settings"])
    config = user.config
    body = DictDefault(body)
    validate_replacement_cal_payload = validate_replacement_calculator_api(body)
    isValid = validate_replacement_cal_payload.get("isValid")
    message = validate_replacement_cal_payload.get("message")
    L = request.vars["L"]
    L.info(f"validate_replacement_cal_payload---------------- {isValid}, {message}")
    if not isValid:
        return {"statusCode": 400, "message": "Validation Error", "body": message}
    input_files_payload = await generate_social_security_data_tables(req)

    config = DictDefault(config)
    replacement_calc_data = await generateReplacementCalcData(body, config)
    if replacement_calc_data:
        replacement_calc_data = replacement_calc_data["actuarialData"]
    pay_load_response = generateReplacementCalculatorPayload(body, replacement_calc_data, input_files_payload)
    error = pay_load_response.get("error")
    pipePayload = pay_load_response.get("data")
    L.info(f"generateReplacementCalculatorPayload ------------------------------ {error}")
    if error:
        return {"statusCode": 400, "message": error, "body": pipePayload}
    if generatePayloadOnly:
        return {"statusCode": 200, "message": "Success", "body": pipePayload}
    else:
        return pipePayload


async def val_custom_portfolios_payload(payload):
    """Validate payload

    Args:
        payload (dict): {}

    Returns:
        dict: {"isValid": bool, "body": str}
    """
    payload = DictDefault(payload)
    if "portfolioSuiteName" not in payload or not isinstance(payload.portfolioSuiteName, str):
        return {
            "isValid": False,
            "message": "portfolioSuiteName is mandatory and should be string.",
        }
    if (
        "fundIdentifier" not in payload
        or not isinstance(payload.fundIdentifier, str)
        or payload.fundIdentifier not in ["CUSIP", "ISIN"]
    ):
        return {
            "isValid": False,
            "message": "fundIdentifier is mandatory, it should be string and should be either CUSIP or ISIN.",
        }
    if "GOEPortfolioName" not in payload or not isinstance(payload.GOEPortfolioName, str):
        return {
            "isValid": False,
            "message": "GOEPortfolioName is mandatory and should be string.",
        }
    if type(payload.compositePortfolio) != bool:
        return {
            "isValid": False,
            "message": "compositePortfolio is mandatory and must be a boolean.",
        }

    if "fundDetails" not in payload:
        return {
            "isValid": False,
            "message": "fundDetails is mandatory.",
        }
    if "fundDetails" in payload and not isinstance(payload.fundDetails, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "fundDetails is not valid must be a mapping object.",
        }

    if len(payload.fundDetails) == 0:
        return {
            "isValid": False,
            "message": "fundDetails length should not be empty.",
        }
    fund_list = []
    for index, fund_info in enumerate(payload.fundDetails):
        if fund_info.tickerName in fund_list:
            return {
                "isValid": False,
                "message": f"tickerName should be unique, but {fund_info.tickerName} id duplicate entry  in fundDetails at item position {index}.",
            }
        if "tickerName" not in fund_info or not isinstance(fund_info.tickerName, str):
            return {
                "isValid": False,
                "message": f"tickerName is mandatory and should be valid string in fundDetails at item position {index}.",
            }
        fund_list.append(fund_info.tickerName)
        if "name" not in fund_info or not isinstance(fund_info.name, str):
            return {
                "isValid": False,
                "message": f"name is mandatory and should be valid string in fundDetails at item position {index}.",
            }
        if (
            "class" not in fund_info
            or not isinstance(fund_info["class"], str)
            or fund_info["class"] not in ["equity", "fixedincome"]
        ):
            return {
                "isValid": False,
                "message": f"class is mandatory and should be valid string and it should be equity or fixedincome in fundDetails at item position {index}.",
            }
        if "id" not in fund_info or not isinstance(fund_info.id, str):
            return {
                "isValid": False,
                "message": f"ID is mandatory and should be valid string in fundDetails at item position {index}.",
            }
        if payload.fundIdentifier == "CUSIP" and len(fund_info.id) != 9:
            return {
                "isValid": False,
                "message": f"fund ID length should be nine if fundidentifier is CUSIP at item position {index}.",
            }

        if payload.fundIdentifier == "ISIN" and len(fund_info.id) != 12:
            return {
                "isValid": False,
                "message": f"fund ID length should be 12 if fundidentifier is ISIN at item position {index}.",
            }

    fund_list.sort()

    if "portfolios" not in payload:
        return {
            "isValid": False,
            "message": "portfolios is mandatory.",
        }
    if "portfolios" in payload and not isinstance(payload.portfolios, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "portfolios is not valid must be a mapping object.",
        }
    if len(payload.portfolios) == 0:
        return {
            "isValid": False,
            "message": "portfolios length should not be empty.",
        }

    portfolio_ids = []
    for index, portfolio_info in enumerate(payload.portfolios):
        if "name" in portfolio_info and portfolio_info.name is not None and not isinstance(portfolio_info.name, str):
            return {
                "isValid": False,
                "message": f"name is optional and should be valid string in portfolios at item position {index}.",
            }

        if "id" not in portfolio_info or not isinstance(portfolio_info.id, str):
            return {
                "isValid": False,
                "message": f"ID is mandatory and should be valid string in portfolios at item position {index}.",
            }

        if portfolio_info.id in portfolio_ids:
            return {
                "isValid": False,
                "message": f"ID should be unique in portfolios at item position {index}.",
            }

        portfolio_ids.append(portfolio_info.id)
        if "allocations" not in portfolio_info or not isinstance(portfolio_info.allocations, abc.MutableSequence):
            return {
                "isValid": False,
                "message": f"allocations is mandatory and should be valid string in portfolios at item position {index}.",
            }
        allocat_weight = 0
        portfolio_funds = []
        for all_index, allocation_info in enumerate(portfolio_info.allocations):
            if "ticker" not in allocation_info or not isinstance(allocation_info.ticker, str):
                return {
                    "isValid": False,
                    "message": f"ticker is mandatory and should be valid string in portfolios at item position {index}.",
                }
            portfolio_funds.append(allocation_info.ticker)
            if allocation_info.ticker not in fund_list:
                return {
                    "isValid": False,
                    "message": f"{allocation_info.ticker} not exist in fund list and it should be in fund list.ticker  in portfolios at item position {index}.",
                }

            if "weight" not in allocation_info or type(allocation_info.weight) not in [int, float]:
                return {
                    "isValid": False,
                    "message": f"weight is mandatory and should be valid string in portfolios at item position {index} .",
                }
            allocat_weight = allocat_weight + allocation_info.weight
        portfolio_funds.sort()
        if fund_list != portfolio_funds:
            return {
                "isValid": False,
                "message": f"some funds not exist in  fund allocations in portfolio at item position {index}.",
            }
        if allocat_weight != 1:
            return {
                "isValid": False,
                "message": f"sum of allocation weight is not one at item position {index}.",
            }

    if "cmedetails" in payload and not isinstance(payload.cmedetails, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "cmedetails is not valid must be a mapping object.",
        }

    if "cmedetails" in payload:
        cmedetails_tickers = []
        for index, cmedetails_info in enumerate(payload.cmedetails):
            if (
                "ticker" not in cmedetails_info
                or not isinstance(cmedetails_info.ticker, str)
                or cmedetails_info.ticker not in fund_list
            ):
                return {
                    "isValid": False,
                    "message": f"ticker is mandatory, should be valid string and ticker should be in fund list in cmedetails at item position {index}.",
                }
            cmedetails_tickers.append(cmedetails_info.ticker)
            if "return" not in cmedetails_info or type(cmedetails_info["return"]) not in [int, float]:
                return {
                    "isValid": False,
                    "message": f"ticker is mandatory and should be valid int or float in cmedetails at item position {index}.",
                }
            if "stdev" not in cmedetails_info or cmedetails_info.stdev:
                return {
                    "isValid": False,
                    "message": f"stdev is mandatory and should be nullable in cmedetails at item position {index}.",
                }
        cmedetails_tickers.sort()
        if fund_list != cmedetails_tickers:
            return {
                "isValid": False,
                "message": "some funds not exist in  cme details.",
            }

    if "covariance" in payload and not isinstance(payload.covariance, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "covariance is not valid must be a mapping object.",
        }

    if "covariance" in payload:
        covariance_tickers = []
        covariance_matrix = []
        for index, covariance_info in enumerate(payload.covariance):
            if (
                "ticker" not in covariance_info
                or not isinstance(covariance_info.ticker, str)
                or covariance_info.ticker not in fund_list
            ):
                return {
                    "isValid": False,
                    "message": f"ticker is mandatory and should be valid string and {covariance_info.ticker} must be in fund_list in covariance at item position {index}.",
                }
            covariance_tickers.append(covariance_info.ticker)
            if "cov" not in covariance_info or not isinstance(covariance_info.cov, abc.MutableSequence):
                return {
                    "isValid": False,
                    "message": f"cov must be mapping object in covariance  at item position {index}.",
                }
            weight_list = []
            cov_tickers = []
            for cov_index, cov_info in enumerate(covariance_info.cov):
                if "ticker" not in cov_info or not isinstance(cov_info.ticker, str) or cov_info.ticker not in fund_list:
                    return {
                        "isValid": False,
                        "message": f"ticker value must be str, it is mandatory and ticker name {cov_info.ticker} must be in  fund list covariance  at item position {index} and cov info item position {cov_index}.",
                    }
                cov_tickers.append(cov_info.ticker)
                if "value" not in cov_info or type(cov_info.value) not in [int, float]:
                    return {
                        "isValid": False,
                        "message": f"fund value must be int or float in covariance  at item position {index} and cov info item position {cov_index}.",
                    }
                weight_list.append(cov_info.value)
            cov_tickers.sort()
            if fund_list != cov_tickers:
                return {
                    "isValid": False,
                    "message": f"some funds does not exist in  cov mapping object at item positon {index}.",
                }
            covariance_matrix.append(weight_list)
        if fund_list != covariance_tickers:
            return {
                "isValid": False,
                "message": "some funds does not exist in  covariance  sequence object .",
            }

        for lower_index in range(len(covariance_matrix)):
            for outer_index in range(len(covariance_matrix[lower_index])):
                if lower_index != outer_index:
                    if covariance_matrix[lower_index][outer_index] != covariance_matrix[outer_index][lower_index]:
                        return {
                            "isValid": False,
                            "message": f"covariance fund weight does not match with these indexes {lower_index},{outer_index}",
                        }
                else:
                    if covariance_matrix[lower_index][outer_index] < 0:
                        return {
                            "isValid": False,
                            "message": f"covariance[{lower_index}][{outer_index}] value should be greater than zero. ",
                        }

    if "correlation" in payload and not isinstance(payload.correlation, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "correlation is not valid must be a mapping object.",
        }
    correlation_tickers = []
    correlation_matrix = []
    if "correlation" in payload:
        for index, correlation_info in enumerate(payload.correlation):
            if "ticker" not in correlation_info or not isinstance(correlation_info.ticker, str):
                return {
                    "isValid": False,
                    "message": f"ticker is mandatory and should be valid string in correlation at item position {index}.",
                }
            correlation_tickers.append(correlation_info.ticker)
            if "corr" not in correlation_info or not isinstance(correlation_info.corr, abc.MutableSequence):
                return {
                    "isValid": False,
                    "message": f"cov must be mapping object in correlation  at item position {index}.",
                }
            weight_list = []
            cor_tickers = []
            for cor_index, cor_info in enumerate(correlation_info.corr):
                if "ticker" not in cor_info or not isinstance(cor_info.ticker, str) or cor_info.ticker not in fund_list:
                    return {
                        "isValid": False,
                        "message": f"ticker name {cor_info.ticker} must be in  fund list correlation  at item position {index}.",
                    }
                cor_tickers.append(cor_info.ticker)
                if "value" not in cor_info or type(cor_info.value) not in [int, float]:
                    return {
                        "isValid": False,
                        "message": f"fund value must be int or float in covariance  at item position {index} and cov info item position {cov_index}.",
                    }
                weight_list.append(cor_info.value)
            correlation_matrix.append(weight_list)
            cor_tickers.sort()
            if fund_list != cor_tickers:
                return {
                    "isValid": False,
                    "message": f"some funds does not exist in  cor mapping object at item positon {index}.",
                }
        if fund_list != correlation_tickers:
            return {
                "isValid": False,
                "message": "some funds does not exist in  correlation  sequence object .",
            }
        for lower_index in range(len(correlation_matrix)):
            for outer_index in range(len(correlation_matrix[lower_index])):
                if lower_index != outer_index:
                    if correlation_matrix[lower_index][outer_index] != correlation_matrix[outer_index][lower_index]:
                        return {
                            "isValid": False,
                            "message": f"correlation fund weight does not match with these indexes {lower_index},{outer_index}",
                        }
                else:
                    if correlation_matrix[lower_index][outer_index] != 1:
                        return {
                            "isValid": False,
                            "message": f"correlation[{lower_index}][{outer_index}] value should be 1. ",
                        }

    return {"isValid": True, "message": None}


async def val_discretionary_calculator_payload(payload):
    """Validate payload

    Args:
        payload (dict): {}

    Returns:
        dict: {"isValid": bool, "body": str}
    """
    payload = DictDefault(payload)
    if type(payload.expense) not in [float, int] or payload.expense < 0:
        return {
            "isValid": False,
            "body": "Please enter yearly expenses greater than or equal to 0",
        }
    return {"isValid": True, "body": None}


async def custom_portfolios_api_payload(req, body):
    user, generatePayloadOnly = await get_user_profile(req)
    if not user.get("app_settings") or not user["app_settings"].get("goe"):
        ValidationError.messages = "app_settings not found user to process further"
        raise ValidationError
    user = DictDefault(user["app_settings"]["goe"]["client-settings"])
    config = user.config
    body = DictDefault(body)
    val_custom_portfolios_payloa = await val_custom_portfolios_payload(body)
    isValid = val_custom_portfolios_payloa.get("isValid")
    message = val_custom_portfolios_payloa.get("message")
    L = request.vars["L"]
    L.info(f"validate_replacement_cal_payload---------------- {isValid}, {message}")
    if not isValid:
        return {"statusCode": 400, "message": "Validation Error", "body": message}
    # input_files_payload = await generate_social_security_data_tables(req)

    config = DictDefault(config)
    # replacement_calc_data = await generateReplacementCalcData(body, config)
    # if replacement_calc_data:
    #    replacement_calc_data = replacement_calc_data["actuarialData"]

    input_files_payload = await getDataTablesforCustomPortfolio(body, config)
    pay_load_response = generateCustomPortfolioPayload(body, config, input_files_payload)
    error = pay_load_response.get("error")
    pipePayload = pay_load_response.get("data")
    L.info(f"generateReplacementCalculatorPayload ------------------------------ {error}")
    if error:
        return {"statusCode": 400, "message": error, "body": pipePayload}
    if generatePayloadOnly:
        return {"statusCode": 200, "message": "Success", "body": pipePayload}
    else:
        return pipePayload


async def fixed_discretionary_calculator_api(req, body):
    user, generatePayloadOnly = await get_user_profile(req)
    if not user.get("app_settings") or not user["app_settings"].get("goe"):
        ValidationError.messages = "app_settings not found user to process further"
        raise ValidationError
    user = DictDefault(user["app_settings"]["goe"]["client-settings"])
    config = user.config
    body = DictDefault(body)
    validate_discretionary_calculator_payload = await val_discretionary_calculator_payload(body)
    isValid = validate_discretionary_calculator_payload.get("isValid")
    message = validate_discretionary_calculator_payload.get("message")
    L = request.vars["L"]
    L.info(f"validate_replacement_cal_payload---------------- {isValid}, {message}")
    if not isValid:
        return {"statusCode": 400, "message": "Validation Error", "body": message}
    # input_files_payload = await generate_social_security_data_tables(req)

    config = DictDefault(config)
    # replacement_calc_data = await generateReplacementCalcData(body, config)
    # if replacement_calc_data:
    #    replacement_calc_data = replacement_calc_data["actuarialData"]
    input_files_payload = await getDataTablesforDiscretionaryCalculator(body, config)
    pay_load_response = generateFixedDiscretionaryCalculatorPayload(body, input_files_payload)
    error = pay_load_response.get("error")
    pipePayload = pay_load_response.get("data")
    L.info(f"generateReplacementCalculatorPayload ------------------------------ {error}")
    if error:
        return {"statusCode": 400, "message": error, "body": pipePayload}
    if generatePayloadOnly:
        return {"statusCode": 200, "message": "Success", "body": pipePayload}
    else:
        return pipePayload


async def read_data_from_csv(file_path):
    df = pd.read_csv(file_path)
    df.columns = map(str.lower, df.columns)
    records_info = df.to_dict("records")
    count = 0
    records_list = []
    for record_info in records_info:
        count = count + 1
        records_list.append(record_info)
    return records_list


async def goe_run_pipe_taxes(req, body):
    L = request.vars["L"]
    ptf = await prepare_portfolio(req, body)
    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    body = ptf.get("body")
    body = DictDefault(body)

    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/GOEforTaxes",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }

    validate_run_pipe_taxes_payload = validate_run_pipe_taxes(body)
    isValid = validate_run_pipe_taxes_payload.get("isValid")
    message = validate_run_pipe_taxes_payload.get("message")
    L.info(f"validate_run_pipe_taxes_payload---------------- {isValid}, {message}")
    if not isValid:
        return {"statusCode": 400, "message": "Validation Error", "body": message}

    config = DictDefault(config)
    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    L.info(f"validateIfRiskProfileisRiskProfileValid-------------{isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return {"statusCode": 400, "message": "Validation Error", "body": riskProfileErrorMessage}

    goe_tables = await getDataTablesforGOETaxes(body, config)

    debug_str = req["headers"].get("debug")
    if debug_str and debug_str == "true":
        body.debug = True
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(body, config)
        if age_based_equity_data:
            goe_tables.update(age_based_equity_data["actuarialData"])

    pay_load_response = generateTaxLiabilityPayload(body, config, portfolios, goe_tables, ptf=ptf)
    error = pay_load_response.get("error")
    pipePayload = pay_load_response.get("data")
    L.info(f"generateTaxLiabilityPayload ------------------------------ {error}")
    if error:
        return {"statusCode": 400, "message": error, "body": pipePayload}
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/runAggRetirementAccounts-H",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    L.info(logData)
    if generatePayloadOnly:
        return {"statusCode": 200, "message": "Success", "body": pipePayload}
    else:
        return pipePayload


async def goe_goal_simulation_engine_payload(req, body):
    L = request.vars["L"]
    ptf = await prepare_portfolio(req, body)
    config = ptf.get("config")
    portfolios = ptf.get("portfolios")
    sourceIp = ptf.get("sourceIp")
    clientId = ptf.get("clientId")
    name = ptf.get("name")
    email = ptf.get("email")
    generatePayloadOnly = ptf.get("generatePayloadOnly")
    body = ptf.get("body")
    body = DictDefault(body)

    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/GOEforTaxes",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }

    validate_goal_simulation_payload = validate_goal_simulation_engine_payload(body)
    isValid = validate_goal_simulation_payload.get("isValid")
    message = validate_goal_simulation_payload.get("message")
    L.info(f"validate_run_pipe_taxes_payload---------------- {isValid}, {message}")
    if not isValid:
        return {"statusCode": 400, "message": "Validation Error", "body": message}

    config = DictDefault(config)
    validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
    isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
    riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
        "message"
    )
    L.info(f"validateIfRiskProfileisRiskProfileValid-------------{isRiskProfileValid}, {riskProfileErrorMessage}")
    if not isRiskProfileValid:
        return {"statusCode": 400, "message": "Validation Error", "body": riskProfileErrorMessage}

    goe_tables = await getDataTablesforGOESimulationEngine(body, config)

    debug_str = req["headers"].get("debug")
    if debug_str and debug_str == "true":
        body.debug = True
    if body.useAgeBasedCap is True:
        age_based_equity_data = await get_data_tables_for_age_based_equity(body, config)
        if age_based_equity_data:
            goe_tables.update(age_based_equity_data["actuarialData"])
    pay_load_response = generateGoalSimulationPayload(body, config, portfolios, goe_tables, ptf)
    error = pay_load_response.get("error")
    pipePayload = pay_load_response.get("data")
    L.info(f"generateTaxLiabilityPayload ------------------------------ {error}")
    if error:
        return {"statusCode": 400, "message": error, "body": pipePayload}
    logData = {
        "sourceIp": sourceIp,
        "endpoint": "/runAggRetirementAccounts-H",
        "clientId": clientId,
        "name": name,
        "email": email,
        "req": json.dumps(body),
    }
    L.info(logData)
    if generatePayloadOnly:
        return {"statusCode": 200, "message": "Success", "body": pipePayload}
    else:
        return pipePayload
