import json

from quart import abort
from goelib.api.shared.user_utils import get_user_profile
from goelib.errors import ValidationError
from goelib.api.shared.common import DictDefault
from collections import namedtuple
from goelib.api.shared.common import genericResponse
from goelib.api.shared.case_conversion import convertToCamelCase

class PipePortfolio:
    def __init__(self, *args, **kwargs) -> None:
        for key in kwargs:
            setattr(self, key, kwargs[key])

class Allocation:
    def __init__(self, obj) -> None:
        if obj:
            self.data = {"equity": 0, "bond": 0, "money_market": 0}
            self._data = dict([(x.get("name"), x.get("weightPercent")) for x in obj])
            self.data.update(self._data)

async def prepare_portfolio(req, body, request=None):
    sourceIp = req.get("remote_addr")
    user, generatePayloadOnly = await get_user_profile(req)
    if not user:
        abort(400)
    if not user.get("app_settings") or not user["app_settings"].get("goe"):
        ValidationError.messages = "app_settings not found user to process further"
        raise ValidationError
    user = DictDefault(user["app_settings"]["goe"]["client-settings"])
    clientId = user.id
    config = user.config
    name = user.name
    email = user.email
    config_json = config.get("portfolioConfig").get("portfolioConfig")
    conservativeLimits = config_json.get("conservativeRiskProfiles")
    moderateLimits = config_json.get("moderateRiskProfiles")
    aggressiveLimits = config_json.get("aggressiveRiskProfiles")
    shortTermGoalProfiles = config_json.get("shortTermGoalProfiles")
    shortTermRetirementGoalProfiles = config_json.get("shortTermRetirementGoalProfiles")
    decumulationProfiles = config_json.get("decumulationScenarioProfiles")
    defaultRiskProfiles = config_json.get("defaultRiskProfiles")
    veryConservativeLimits = config_json.get("veryConservativeRiskProfiles")
    conservativelyModerateLimits = config_json.get("conservativelyModerateRiskProfiles")
    moderatelyAggressivelLimits = config_json.get("moderatelyAggressiveRiskProfiles")
    veryAggressiveLimits = config_json.get("veryAggressiveRiskProfiles")
    userConfigPortfolioArray = user.portfolio_bundle.portfolios
    portfolioRiskOnArrayClass = [e for e in userConfigPortfolioArray if e.riskOn is True]
    portfolioRiskOffArrayClass = [e for e in userConfigPortfolioArray if e.riskOn is False]
    portfoliosRiskOn = []
    portfoliosRiskOff = []
    for i in portfolioRiskOnArrayClass:
        riskType = None
        isShortTerm = False
        isRetirementShortTerm = False
        isDecumulation = False
        if defaultRiskProfiles and i.id in defaultRiskProfiles:
            riskType = "None"
        elif veryConservativeLimits and i.id in veryConservativeLimits:
            riskType = "VeryConservative"
        elif conservativeLimits and i.id in conservativeLimits:
            riskType = "Conservative"
        elif conservativelyModerateLimits and i.id in conservativelyModerateLimits:
            riskType = "ConservativelyModerate"
        elif moderateLimits and i.id in moderateLimits:
            riskType = "Moderate"
        elif moderatelyAggressivelLimits and i.id in moderatelyAggressivelLimits:
            riskType = "ModeratelyAggressive"
        elif aggressiveLimits and i.id in aggressiveLimits:
            riskType = "Aggressive"
        elif veryAggressiveLimits and i.id in veryAggressiveLimits:
            riskType = "VeryAggressive"
        if shortTermGoalProfiles and i.id in shortTermGoalProfiles:
            isShortTerm = True
        if shortTermRetirementGoalProfiles and i.id in shortTermRetirementGoalProfiles:
            isRetirementShortTerm = True
        if decumulationProfiles and i.id in decumulationProfiles:
            isDecumulation = True
        if riskType is None:
            continue
        kwargs = {
            "portfolio_return": i.meanPercent,
            "risk": i.sdPercent,
            # "riskType": riskType,
            "id": i.id,
            "isShortTerm": isShortTerm,
            "assetAllocation": Allocation(i.assetAllocations).data,
            "isRetirementShortTerm": isRetirementShortTerm,
            "isDecumulation": isDecumulation,
            "feesAdjuster": i.feesAdjuster,
        }
        pobject = PipePortfolio(**kwargs)
        portfoliosRiskOn.append(pobject)
    useAgeBasedCapPortfoliosRiskOn = []
    useAgeBasedCapPortfoliosRiskOff = []
    for i in portfolioRiskOnArrayClass:
        riskType = None
        isShortTerm = False
        isRetirementShortTerm = False
        isDecumulation = False
        kwargs = {
            "portfolio_return": i.meanPercent,
            "risk": i.sdPercent,
            "id": i.id,
            # "riskType": riskType,
            # "isShortTerm": isShortTerm,
            "assetAllocation": Allocation(i.assetAllocations).data,
            # "isRetirementShortTerm": isRetirementShortTerm,
            # "isDecumulation": isDecumulation,
            "feesAdjuster": i.feesAdjuster,
        }
        pobject = PipePortfolio(**kwargs)
        useAgeBasedCapPortfoliosRiskOn.append(pobject)

    maximumShortTermPortMaxIndex = 0
    maximumShortTermRetirementPortMaxIndex = 0
    maximumDecumulationPortMaxIndex = 0
    for i in portfolioRiskOnArrayClass:
        if i.id in shortTermGoalProfiles:
            maximumShortTermPortMaxIndex += 1
        if i.id in shortTermRetirementGoalProfiles:
            maximumShortTermRetirementPortMaxIndex += 1
        if i.id in decumulationProfiles:
            maximumDecumulationPortMaxIndex += 1
    for i in portfolioRiskOffArrayClass:
        riskType = None
        isShortTerm = False
        isRetirementShortTerm = False
        isDecumulation = False
        if defaultRiskProfiles and i.id in defaultRiskProfiles:
            riskType = "None"
        elif veryConservativeLimits and i.id in veryConservativeLimits:
            riskType = "VeryConservative"
        elif conservativeLimits and i.id in conservativeLimits:
            riskType = "Conservative"
        elif conservativelyModerateLimits and i.id in conservativelyModerateLimits:
            riskType = "ConservativelyModerate"
        elif moderateLimits and (i.id in moderateLimits):
            riskType = "Moderate"
        elif moderatelyAggressivelLimits and i.id in moderatelyAggressivelLimits:
            riskType = "ModeratelyAggressive"
        elif aggressiveLimits and i.id in aggressiveLimits:
            riskType = "Aggressive"
        elif veryAggressiveLimits and i.id in veryAggressiveLimits:
            riskType = "VeryAggressive"
        if shortTermGoalProfiles and i.id in shortTermGoalProfiles:
            isShortTerm = True
        if shortTermRetirementGoalProfiles and i.id in shortTermRetirementGoalProfiles:
            isRetirementShortTerm = True
        if decumulationProfiles and i.id in decumulationProfiles:
            isDecumulation = True
        if riskType is None:
            continue
        kwargs = {
            "portfolio_return": i.meanPercent,
            "risk": i.sdPercent,
            "id": i.id,
            # "riskType": riskType,
            "isShortTerm": isShortTerm,
            "assetAllocation": Allocation(i.assetAllocations).data,
            "isRetirementShortTerm": isRetirementShortTerm,
            "isDecumulation": isDecumulation,
            "feesAdjuster": i.feesAdjuster,
        }
        pobject = PipePortfolio(**kwargs)
        portfoliosRiskOff.append(pobject)
    for i in portfolioRiskOffArrayClass:
        riskType = None
        isShortTerm = False
        isRetirementShortTerm = False
        isDecumulation = False
        kwargs = {
            "portfolio_return": i.meanPercent,
            "risk": i.sdPercent,
            "id": i.id,
            # "riskType": riskType,
            "isShortTerm": isShortTerm,
            "assetAllocation": Allocation(i.assetAllocations).data,
            "isRetirementShortTerm": isRetirementShortTerm,
            "isDecumulation": isDecumulation,
            "feesAdjuster": i.feesAdjuster,
        }
        pobject = PipePortfolio(**kwargs)
        useAgeBasedCapPortfoliosRiskOff.append(pobject)

    portfolios = [
        portfoliosRiskOff,
        portfoliosRiskOn,
        maximumShortTermPortMaxIndex,
        maximumShortTermRetirementPortMaxIndex,
        maximumDecumulationPortMaxIndex,
        useAgeBasedCapPortfoliosRiskOn,
        useAgeBasedCapPortfoliosRiskOff,
    ]
    _portfolios = namedtuple(
        "portfolios",
        [
            "portfoliosRiskOff",
            "portfoliosRiskOn",
            "maximumShortTermPortMaxIndex",
            "maximumShortTermRetirementPortMaxIndex",
            "maximumDecumulationPortMaxIndex",
            "useAgeBasedCapPortfoliosRiskOn",
            "useAgeBasedCapPortfoliosRiskOff",
        ],
    )
    portfolios = _portfolios(*portfolios)
    return locals()

def goe_api_response_handler(logData, version):
    def wrapper(pipe_result):
        res = None
        if isinstance(pipe_result, str):  # if pipe result is json string convert it. else not required
            pipe_result = json.loads(pipe_result)
        data, statusCode = pipe_result.get("data"), pipe_result.get("statusCode")
        pipeMessage = pipe_result.get("message")
        if pipe_result.get("outputObject"):
            data = pipe_result.get("outputObject").get("data")
            statusCode = pipe_result.get("outputObject").get("statusCode")
            pipeMessage = pipe_result.get("outputObject").get("message")
        if not (statusCode in [200, 200.0]):
            message = "Internal Server Error"
            data = "Unexpected error: Please contact FT GOE Business team."
            if statusCode != 500:
                statusCode = 400
                message = "Validation Error"
                data = pipeMessage
            json_data = {
                "logData": logData,
                "statusCode": statusCode,
                "message": message,
                "body": data,
            }
            if pipe_result.get("outputObject"):
                json_data.update({"requestId": pipe_result.get("requestId")})
            return genericResponse(
                res,
                json_data,
            )
        data = json.loads(data)
        if version in ["4", "v4"]:
            data = convertToCamelCase(data)
        json_data = {
            "logData": logData,
            "statusCode": int(statusCode),
            "message": "Success",
            "body": data,
        }
        if pipe_result.get("outputObject"):
            json_data.update({"requestId": pipe_result.get("requestId")})
        return genericResponse(
            res,
            json_data,
        )

    return wrapper

