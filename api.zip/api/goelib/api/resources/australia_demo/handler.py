# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from goelib.api.shared.common import DictDefault
import datetime
import numpy as np

from goelib.api.shared.common import isDateFormatValidV1
from goelib.api.resources.australia_demo import australia as AU
from goelib.api.resources.australia_demo import goe as GO

import json

from google.protobuf.json_format import MessageToJson
import rest_pb2
import rest_pb2_grpc
import uip_grpc

from datetime import date
from quart import request

grpc_channels = uip_grpc.GRPC(async_mode=True)


def calculate_age(add_dob):
    today = date.today()
    age = today.year - add_dob.year - ((today.month, today.day) < (add_dob.month, add_dob.day))
    return age


def calculateUtility():
    return float(1000)


def empty_fill(n, num):
    a = np.empty(n)
    a.fill(num)
    return a


def retirementIncome(age, age_pen_array, acc_pen_array, target_income, min_withd_array):
    # st.subheader("Projected Retirement Income")
    x_axis = np.arange(age, age + len(age_pen_array), 1)
    data = [
        {"id": "age", "title": "Age", "data": x_axis.tolist()},
        {"id": "super_drawdown", "title": "Super drawdown", "data": acc_pen_array.tolist()},
        {"id": "age_pension", "title": "Age Pension", "data": age_pen_array.tolist()},
        {
            "id": "retirement_income",
            "title": "Retirement Income",
            "data": empty_fill(len(age_pen_array), target_income).tolist(),
        },
        {"id": "minimum_drawdown", "title": "Minimum Drawdown", "data": min_withd_array.tolist()},
    ]

    return json.dumps(data)


def yourWealth(age, acc_pen_array, wealthPath):
    x_axis1 = np.arange(age, age + len(acc_pen_array) + 1, 1)
    x_axis1 = x_axis1.tolist()
    chart_data = [dict([("Age", i), ("Wealth", j)]) for i, j in zip(x_axis1, wealthPath)]
    data = [{"id": "wealth", "title": "Your Wealth", "data": chart_data}]
    return json.dumps(data)


def yourPortfolio(age, acc_pen_array, portfolioPath):
    x_axis1 = np.arange(age, age + len(acc_pen_array) + 1, 1)
    x_axis1 = x_axis1.tolist()
    chart_data = [dict([("Age", i), ("Portfolio", j)]) for i, j in zip(x_axis1, portfolioPath)]
    data = [{"id": "portfolio", "title": "Your Portfolio", "data": chart_data}]
    return json.dumps(data)


def yourAssetAllocation(portArray, allotedArray, assetArray, assetAllotedArray, portNum):
    data = [
        {
            "data": dict(zip(assetArray.tolist(), assetAllotedArray.tolist())),
            "id": "asset_allocation",
            "title": "Asset Allocation",
        },
        {
            "data": dict(zip(portArray.tolist(), allotedArray.tolist())),
            "id": "portfolio_composition",
            "title": "Portfolio Composition",
        },
    ]
    return json.dumps(data)


async def main(payload, context):
    logger = request.vars["L"]

    st = {
        "gender": payload.get("gender"),
        "home_owner": payload.get("home_owner"),
        "date_of_birth": datetime.datetime.strptime(payload["date_of_birth"], "%d-%m-%Y"),
        "risk_profile": payload.get("risk_profile"),
        "current_super_balance": payload.get("current_super_balance"),
        "other_income": payload.get("other_income"),
        "other_assets": payload.get("other_assets"),
        "optimize_retirement_income": payload.get("optimize_retirement_income"),
        "desired_retirement_income": payload.get("desired_retirement_income"),
    }

    add_homeOwner = st.get("home_owner")

    add_dob = st["date_of_birth"]
    age = calculate_age(add_dob)

    if not (65 <= age <= 99):
        logger.error("Age should be between 65 and 99")
        res = {"message": "Age should be between 65 and 99", "statusCode": 400}
        return res
    add_riskProfile = st.get("risk_profile")

    # st.subheader("Assets/Income")

    add_currentSuperBalance = st.get("current_super_balance")
    add_otherIncome = st.get("other_income")
    add_otherAssets = st.get("other_assets")
    add_return = 1.025

    # st.subheader("Retirement Income")

    add_optimizebutton = st.get("optimize_retirement_income", "Yes")
    if add_optimizebutton == "Yes":
        AU1 = AU.Australia(age, add_currentSuperBalance, add_return, add_homeOwner, add_otherIncome, add_otherAssets)
        target_income, age_pen_array, acc_pen_array, total_income_array, min_withd_array = AU1.retirement_income()
        # add_optimizedRetirementIncome = st.metric(label="Optimized Retirement Income :", value=target_income)
    else:
        add_desiredRetirmentIncome = st.get("desired_retirement_income")
        AU2 = AU.Australia(
            age,
            add_currentSuperBalance,
            add_return,
            add_homeOwner,
            add_otherIncome,
            add_otherAssets,
            add_desiredRetirmentIncome,
        )
        target_income, age_pen_array, acc_pen_array, total_income_array, min_withd_array = AU2.retirement_income()
    # add_Calculate = st.get("Calculate")
    if add_riskProfile == "Conservative":
        Risk_Profile = "conservative"
    elif add_riskProfile == "Aggressive":
        Risk_Profile = "aggressive"
    else:
        Risk_Profile = "moderate"
    retirement_data = retirementIncome(age, age_pen_array, acc_pen_array, target_income, min_withd_array)

    retirement_data = json.loads(retirement_data)
    # retirement_data = {"data": retirement_data.get("data"), "name": retirement_data.get("name")}
    # with st.spinner("In Progress...."):
    australia_db_config = payload["config"]["db_config"]
    client_email = payload["config"]["email"]
    GO1 = GO.GOE(add_currentSuperBalance, acc_pen_array, Risk_Profile, client_email, context)
    run_pipe_response = await GO1.run_each_scenario()
    if run_pipe_response.get("statusCode") == 200:
        output = run_pipe_response["body"]["analysisReport"]
        output1 = run_pipe_response["body"]["pathReport"]
        portfolioPath, wealthPath, portNum, currentGoalProb = (
            output1["portfolioPath"],
            output1["wealthPath"],
            output["recommendedPortfolioId"],
            output["currentGoalProbability"],
        )
    else:
        return run_pipe_response
    # portfolioPath, wealthPath, portNum, currentGoalProb = await GO1.run_each_scenario()

    portArray, allotedArray = GO1.portDetails(australia_db_config, portNum)

    assetArray, assetAllotedArray = GO1.assetDetails(australia_db_config, portNum)

    your_wealth_data = yourWealth(age, acc_pen_array, wealthPath)
    your_asset_alloc_data = yourAssetAllocation(portArray, allotedArray, assetArray, assetAllotedArray, portNum)

    val = int(currentGoalProb * 100)
    print(val)
    your_portfoilio_data = yourPortfolio(age, acc_pen_array, portfolioPath)
    data = {
        "retirement_income": retirement_data,
        "wealth": json.loads(your_wealth_data),
        "asset_allocation": json.loads(your_asset_alloc_data),
        "portfolio": json.loads(your_portfoilio_data),
        "probability_of_reaching_goal": f"{val} %",
    }
    return data


async def validate_payload(payload):
    """Validate payload

    Args:
        payload (dict): {}

    Returns:
        dict: {"isValid": bool, "body": str}
    """
    payload = DictDefault(payload)
    if payload.gender not in ["Male", "Female"]:
        return {"isValid": False, "errorCode": 6000, "body": "Gender must be Male or Female."}
    if payload.home_owner not in ["Y", "N"]:
        return {"isValid": False, "errorCode": 6001, "body": "Home Owner must be Y or N."}
    if payload.risk_profile not in ["Conservative", "Moderate", "Aggressive"]:
        return {
            "isValid": False,
            "errorCode": 6002,
            "body": "Risk Profile should be either Conservative, Moderate or Aggressive.",
        }
    if type(payload.current_super_balance) not in [float, int] or payload.current_super_balance < 0:
        return {
            "isValid": False,
            "errorCode": 6003,
            "body": "Current Super Balance should be greater than zero.",
        }
    if type(payload.other_income) not in [float, int] or payload.other_income < 0:
        return {
            "isValid": False,
            "errorCode": 6004,
            "body": "Other Income should be >=0.",
        }
    if type(payload.other_assets) not in [float, int] or payload.other_assets < 0:
        return {
            "isValid": False,
            "errorCode": 6005,
            "body": "Other Assets should be >=0.",
        }
    if payload.optimize_retirement_income not in ["Yes", "No"]:
        return {"isValid": False, "errorCode": 6006, "body": "optimize_retirement_income must be Yes or No."}
    if payload.optimize_retirement_income in ["No"]:
        if type(payload.desired_retirement_income) not in [int, float]:
            return {"isValid": False, "errorCode": 6007, "body": "desired_retirement_income must be number."}
        if payload.current_super_balance < payload.desired_retirement_income:
            return {
                "isValid": False,
                "errorCode": 6011,
                "body": "current_super_balance should be greater than equal to the desired_retirement_income.",
            }

    if type(payload.date_of_birth) != str or not isDateFormatValidV1(payload.date_of_birth):
        return {"isValid": False, "errorCode": 6008, "body": "date_of_birth must be a valid date."}
    if not (65 <= calculate_age(datetime.datetime.strptime(payload.date_of_birth, "%d-%m-%Y")) <= 99):
        return {"isValid": False, "errorCode": 6009, "body": "Age should be between 65 and 99"}
    return {"isValid": True, "body": None}


async def get_configs():
    """Get configs required from db."""
    try:
        australia_config = MessageToJson(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppZoneSettings(
                request=rest_pb2.AppSettingsRequest(app="goe", zone="client-settings"),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        australia_config = json.loads(australia_config)
        australia_db_config = australia_config.get("australia")
        if australia_db_config is None:
            return {
                "message": "Config Error",
                "body": "australia config is not updated in db.",
                "errorCode": 6100,
                "statusCode": 400,
            }
        client_email = australia_config.get("australia_calculator_config").get("email")
        return {"config": {"db_config": australia_db_config["config"], "email": client_email}, "statusCode": 200}
    except Exception as e:
        request.vars["L"].error(e)
        return {
            "message": "Config Error",
            "body": "australia config is not updated in db.",
            "errorCode": 6100,
            "statusCode": 400,
        }


async def get_retirement_income(payload):
    """calculate retirement income when add_optimizebutton is Yes."""
    add_dob = payload["date_of_birth"]
    add_dob = datetime.datetime.strptime(add_dob, "%d-%m-%Y")
    age = calculate_age(add_dob)
    add_return = 1.025
    add_homeOwner = payload.get("home_owner")
    add_optimizebutton = payload.get("optimize_retirement_income")
    if add_optimizebutton == "Yes":
        AU1 = AU.Australia(
            age,
            payload.get("current_super_balance"),
            add_return,
            add_homeOwner,
            payload.get("other_income"),
            payload.get("other_assets"),
        )
        target_income, age_pen_array, acc_pen_array, total_income_array, min_withd_array = AU1.retirement_income()
        # add_optimizedRetirementIncome = payload.metric(label="Optimized Retirement Income :", value=target_income)
        return {"optimized_retirement_income": target_income}
    else:
        return {"isValid": False, "errorCode": 6010, "body": "optimized retirement income must be Yes."}
