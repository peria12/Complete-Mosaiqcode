import numpy as np

# without target_income
# output = Australia(65, 1000000, 1.025, "Y", 5000, 100000)
# or with target_income
# output = Australia(65, 1000000, 1.025, "Y", 5000, 100000, 50000)
# output.target_income
# output.acc_pension_array
# output.age_pension_array
# output.total_income_array

male_array = np.array(
    [
        [
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            33,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            46,
            47,
            48,
            49,
            50,
            51,
            52,
            53,
            54,
            55,
            56,
            57,
            58,
            59,
            60,
            61,
            62,
            63,
            64,
            65,
            66,
            67,
            68,
            69,
            70,
            71,
            72,
            73,
            74,
            75,
            76,
            77,
            78,
            79,
            80,
            81,
            82,
            83,
            84,
            85,
            86,
            87,
            88,
            89,
            90,
            91,
            92,
            93,
            94,
            95,
            96,
            97,
            98,
            99,
            100,
        ],
        [
            0.99641,
            0.99978,
            0.99986,
            0.99988,
            0.9999,
            0.99992,
            0.99993,
            0.99994,
            0.99994,
            0.99994,
            0.99994,
            0.99993,
            0.99991,
            0.99987,
            0.99982,
            0.99976,
            0.99968,
            0.99959,
            0.99951,
            0.99946,
            0.99942,
            0.99939,
            0.99938,
            0.99937,
            0.99936,
            0.99935,
            0.99934,
            0.99932,
            0.9993,
            0.99928,
            0.99925,
            0.99922,
            0.99919,
            0.99914,
            0.99909,
            0.99903,
            0.99897,
            0.9989,
            0.99883,
            0.99875,
            0.99868,
            0.9986,
            0.99851,
            0.9984,
            0.99826,
            0.9981,
            0.99793,
            0.99775,
            0.99756,
            0.99737,
            0.99717,
            0.99695,
            0.9967,
            0.99642,
            0.9961,
            0.99575,
            0.99536,
            0.99494,
            0.99447,
            0.99398,
            0.99346,
            0.9929,
            0.99231,
            0.99167,
            0.99101,
            0.9903,
            0.98952,
            0.98866,
            0.98764,
            0.98647,
            0.98514,
            0.98366,
            0.98201,
            0.98016,
            0.97808,
            0.97566,
            0.97288,
            0.96967,
            0.96593,
            0.96163,
            0.95676,
            0.95127,
            0.94505,
            0.93799,
            0.92989,
            0.92066,
            0.91033,
            0.89873,
            0.8857,
            0.87106,
            0.85514,
            0.83837,
            0.82125,
            0.80459,
            0.78928,
            0.77317,
            0.75565,
            0.7378,
            0.71645,
            0.68595,
            0.65723,
        ],
    ]
)
female_array = np.array(
    [
        [
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            33,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            46,
            47,
            48,
            49,
            50,
            51,
            52,
            53,
            54,
            55,
            56,
            57,
            58,
            59,
            60,
            61,
            62,
            63,
            64,
            65,
            66,
            67,
            68,
            69,
            70,
            71,
            72,
            73,
            74,
            75,
            76,
            77,
            78,
            79,
            80,
            81,
            82,
            83,
            84,
            85,
            86,
            87,
            88,
            89,
            90,
            91,
            92,
            93,
            94,
            95,
            96,
            97,
            98,
            99,
            100,
        ],
        [
            0.99703,
            0.99978,
            0.99989,
            0.99991,
            0.99992,
            0.99993,
            0.99994,
            0.99995,
            0.99995,
            0.99995,
            0.99994,
            0.99993,
            0.99991,
            0.99989,
            0.99987,
            0.99985,
            0.99982,
            0.9998,
            0.99978,
            0.99977,
            0.99977,
            0.99977,
            0.99977,
            0.99977,
            0.99976,
            0.99976,
            0.99975,
            0.99973,
            0.99972,
            0.9997,
            0.99969,
            0.99967,
            0.99964,
            0.9996,
            0.99956,
            0.99952,
            0.99947,
            0.99943,
            0.99938,
            0.99933,
            0.99928,
            0.99922,
            0.99913,
            0.99905,
            0.99896,
            0.99887,
            0.99878,
            0.99867,
            0.99856,
            0.99844,
            0.99832,
            0.99817,
            0.998,
            0.99781,
            0.99762,
            0.99743,
            0.99723,
            0.99702,
            0.99678,
            0.99648,
            0.99614,
            0.99576,
            0.99541,
            0.99509,
            0.99477,
            0.99438,
            0.9939,
            0.99331,
            0.9926,
            0.99178,
            0.99085,
            0.98979,
            0.9886,
            0.98727,
            0.98579,
            0.98412,
            0.98227,
            0.98021,
            0.9777,
            0.97468,
            0.97108,
            0.96686,
            0.96206,
            0.95653,
            0.95006,
            0.94272,
            0.93443,
            0.92491,
            0.91418,
            0.9017,
            0.88744,
            0.87159,
            0.85501,
            0.83732,
            0.81843,
            0.79919,
            0.77623,
            0.75094,
            0.73072,
            0.71209,
            0.69487,
        ],
    ]
)

min_withdrawal_array = np.array(
    [
        [
            65,
            66,
            67,
            68,
            69,
            70,
            71,
            72,
            73,
            74,
            75,
            76,
            77,
            78,
            79,
            80,
            81,
            82,
            83,
            84,
            85,
            86,
            87,
            88,
            89,
            90,
            91,
            92,
            93,
            94,
            95,
            96,
            97,
            98,
            99,
            100,
        ],
        [
            0.05,
            0.05,
            0.05,
            0.05,
            0.05,
            0.05,
            0.05,
            0.05,
            0.05,
            0.05,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.07,
            0.07,
            0.07,
            0.07,
            0.07,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.11,
            0.11,
            0.11,
            0.11,
            0.11,
            0.14,
            0.14,
            0.14,
            0.14,
            0.14,
            0.14,
        ],
    ]
)


class Australia:
    def __init__(self, age, sup_balance, req_return, homeowner, other_income, other_assets, target_income=None):

        self.age = age
        self.sup_balance = sup_balance
        self.req_return = req_return
        self.homeowner = homeowner
        self.other_income = other_income
        self.other_assets = other_assets
        self.target_income = target_income

    def retirement_income(self):
        # self.age_pension= 12345
        # optimal_income = 50000
        if self.target_income is None:
            optimal_income = self.optimum_income()
            target_income, age_pension_array, acc_pension_array, total_income_array, min_withd_array = self.data_return(
                optimal_income
            )
        else:
            target_income, age_pension_array, acc_pension_array, total_income_array, min_withd_array = self.data_return(
                self.target_income
            )
        return target_income, age_pension_array, acc_pension_array, total_income_array, min_withd_array

    def age_pension(self, s_balance):
        # Asset_test
        total_assets = s_balance + self.other_assets
        if self.homeowner == "Y":
            if total_assets <= 270500:
                asset_test_ap = 967.5 * 26
            else:
                asset_test_ap = np.maximum((967.5 - ((total_assets - 270500) * 3 / 1000)) * 26, 0)
        else:
            if total_assets <= 487000:
                asset_test_ap = 967.5 * 26
            else:
                asset_test_ap = np.maximum((967.5 - ((total_assets - 487000) * 3 / 1000)) * 26, 0)

        # income_test
        if self.other_income <= 180 * 26:
            income_test_ap = 967.5 * 26
        else:
            income_test_ap = (967.5 - (0.5 * ((self.other_income / 26) - 180))) * 26

        # return 25000
        return np.minimum(asset_test_ap, income_test_ap)

    def utility_a(self, target_income):
        util_value = 0
        s_balance = self.sup_balance
        for x in range(self.age, 100):
            prob_age = male_array[1, self.age]
            prob_x = male_array[1, x]
            if x == self.age:
                cum_prob_x = prob_age
            else:
                cum_prob_x = cum_prob_x * prob_x
            min_withd_perc = min_withdrawal_array[1, min_withdrawal_array[0] == x][0]
            min_withdrawal = s_balance * min_withd_perc
            # call function age_pension
            age_based_pension = self.age_pension(s_balance)
            # acc_based_pension_need = target_income - age_based_pension
            acc_based_pension_calc = np.minimum(target_income - age_based_pension, s_balance)
            acc_based_pension_recvd = np.maximum(acc_based_pension_calc, min_withdrawal)
            s_balance = np.maximum(0, (s_balance - acc_based_pension_recvd)) * (self.req_return)
            total_income = age_based_pension + acc_based_pension_recvd
            util_value = util_value + np.sqrt(total_income * cum_prob_x)

        return util_value, target_income

    def optimum_income(self):
        mydict = {}
        for i in range(30000, 150000, 200):
            u, i = self.utility_a(i)
            mydict.update({i: u})
            # print(u, i)

        return max(mydict, key=mydict.get)
        # return 10900

    def data_return(self, target_income):
        util_value = 0
        s_balance = self.sup_balance
        age_pen_array = np.array([])
        acc_pen_array = np.array([])
        total_income_array = np.array([])
        min_withd_array = np.array([])
        for x in range(self.age, 100):
            prob_age = male_array[1, self.age]
            prob_x = male_array[1, x]
            if x == self.age:
                cum_prob_x = prob_age
            else:
                cum_prob_x = cum_prob_x * prob_x
            min_withd_perc = min_withdrawal_array[1, min_withdrawal_array[0] == x][0]
            min_withdrawal = s_balance * min_withd_perc
            # call age_pension function
            age_based_pension = self.age_pension(s_balance)
            # acc_based_pension_need = target_income - age_based_pension
            acc_based_pension_calc = np.minimum(target_income - age_based_pension, s_balance)
            acc_based_pension_recvd = np.maximum(acc_based_pension_calc, min_withdrawal)
            s_balance = np.maximum(0, (s_balance - acc_based_pension_recvd)) * (self.req_return)
            total_income = age_based_pension + acc_based_pension_recvd + self.other_income
            util_value = util_value + np.sqrt(total_income * cum_prob_x)
            age_pen_array = np.append(age_pen_array, age_based_pension)
            if acc_based_pension_recvd > 0.1:
                acc_pen_array = np.append(acc_pen_array, acc_based_pension_recvd)
            total_income_array = np.append(total_income_array, total_income)
            min_withd_array = np.append(min_withd_array, min_withdrawal)

        return target_income, age_pen_array, acc_pen_array, total_income_array, min_withd_array
