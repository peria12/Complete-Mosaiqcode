# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 15:29:06 2022

@author: pgupta8
"""
import json

# os.chdir(r"C:\Users\hparama\Documents\GBWM\New logic_goe_threshold\New logic")
import numpy as np

from dateutil.relativedelta import relativedelta
from datetime import date
from quart import request

# from goelib.api.resources.common import run_pipe
import uip_config
from goelib.api.resources.pipeserverless import pipe_serverless_controller_run_pipe_version3
from goelib.api.shared.common import DictDefault
import rest_pb2
from google.protobuf.json_format import MessageToJson
import uip_grpc

svc_client = uip_grpc.ServiceClient()

cfg = uip_config.ConfigDict()


class GOE:
    def __init__(self, add_currentSuperBalance, acc_pen_array, add_riskProfile, client_email, context):
        self.add_currentSuperBalance = add_currentSuperBalance
        self.acc_pen_array = acc_pen_array
        self.add_riskProfile = add_riskProfile
        self.client_email = client_email
        self.context = dict(context)
        self.token = self.context["authorization"]

    async def run_pipe(self, payload):
        logger = request.vars["L"]
        req = {}
        req["headers"] = request.headers
        req["remote_addr"] = request.remote_addr
        req["request_meta_data"] = request.vars["metadata_t"]
        req["requester_oid"] = request.vars["metadata_d"]["user-id"]
        request.headers["clientemail"] = self.client_email
        request.headers["version"] = 4
        logger.info(f"Run Pipe payload {payload}")
        result = await pipe_serverless_controller_run_pipe_version3(req, payload)
        if isinstance(result, tuple):
            pipePayload, handler = result
        else:
            pipePayload = result
        pipePayload = DictDefault(pipePayload)
        if pipePayload.statusCode in [400, 200]:
            return pipePayload
        elif pipePayload.statusCode is None:
            req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
            goe_response = MessageToJson(
                await svc_client.call_queue_based_service(
                    "goe-service",
                    "CoreGOE",
                    rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            res, _ = handler(goe_response)
        logger.info(f"Run Pipe payload Response {res}")
        return res

    async def run_each_scenario(self):
        c_date = "01-01-2022"
        e_date = date(2022, 1, 1) + relativedelta(years=len(self.acc_pen_array))
        e_datep = e_date.strftime("%d-%m-%Y")
        goal_priority = "Need"
        goal_amount = 0
        scenario_type = "retirement"
        infu = np.append(np.negative(self.acc_pen_array), 0)
        infusions = list(infu)
        infusion_type = "yearly"
        payload = {
            "isNewGoalPriority": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNearTermVolatility": True,
            "isNewGoal": True,
            "getPath": True,
            "currentPortfolioId": None,
            "riskProfile": self.add_riskProfile,
            "initialInvestment": self.add_currentSuperBalance,
            "cashflowDate": c_date,
            "currentWealth": self.add_currentSuperBalance,
            "goalPriority": goal_priority,
            "reallocationFreq": "yearly",
            "goalAmount": goal_amount,
            "startDate": c_date,
            "endDate": e_datep,
            "infusions": infusions,
            "scenarioType": scenario_type,
            "infusionType": infusion_type,
            "currDate": c_date,
            "lossThreshold": None,
            "reallocate": False,
            "calibrateRecommendations": False,
        }
        return await self.run_pipe(payload)

    def portDetails(self, config, portfolioNum):
        names = config["Table"]["Row"]
        portArray = np.array([])
        allotedArray = np.array([])
        for name in names:
            # details = json.loads(name.firstChild.nodeValue)
            details = name["portfolio_data"]
            if details["portfolioId"] == portfolioNum:
                y = details["assets"][0]["subAssets"]
                for i in range(len(y)):
                    portArray = np.append(portArray, y[i]["tickerName"])
                    allotedArray = np.append(allotedArray, (y[i]["allocatedValue"]))
                y = details["assets"][1]["subAssets"]
                for i in range(len(y)):
                    portArray = np.append(portArray, y[i]["tickerName"])
                    allotedArray = np.append(allotedArray, (y[i]["allocatedValue"]))
        return portArray, allotedArray

    def assetDetails(self, config, portfolioNum):
        names = config["Table"]["Row"]
        assetArray = np.array([])
        assetAllotedArray = np.array([])
        for name in names:
            details = name["portfolio_data"]
            if details["portfolioId"] == portfolioNum:
                for i in range(2):
                    y = details["assets"][i]["type"]
                    z = details["assets"][i]["totalAllocatedvalue"]
                    assetArray = np.append(assetArray, y)
                    assetAllotedArray = np.append(assetAllotedArray, z)
        return assetArray, assetAllotedArray
