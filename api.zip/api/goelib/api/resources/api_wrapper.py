import json
import uuid
import uip_grpc

from collections import abc

from quart import request

from goelib.api.shared.common import (
    genericResponse,
    prepare_generate_payload,
    DictDefault,
    # get_data_tables_for_age_based_equity,
)
from goelib.api.shared.validate_risk_profile import validateIfRiskProfileisRiskProfileValid
from goelib.errors import InternalServerError
from goelib.api.resources.common import prepare_portfolio, goe_api_response_handler

grpc_channels = uip_grpc.GRPC(async_mode=True)


class GoalDiscovery:
    async def validate_goal_discovery_payload(self, payload):  # noqa: E501.
        """validate goal discovery api."""
        if not isinstance(payload.goalType, str) or payload.goalType.lower() not in ["retirement", "wealth"]:
            return {
                "isValid": False,
                "message": "goalType must be one of retirement or wealth.",
            }

        if not isinstance(payload.riskProfile, str) or payload.riskProfile.lower() not in [
            "conservative",
            "moderate",
            "aggressive",
            "conservatively moderate",
            "moderately aggressive",
        ]:
            return {
                "isValid": False,
                "message": "riskProfile must be one of 'conservative', 'moderate', 'aggressive', 'conservatively moderate' or 'moderately aggressive'.",
            }
        if (
            not isinstance(payload.initialInvestment, abc.MutableMapping)
            or isinstance(payload.initialInvestment.min, (bool))
            or isinstance(payload.initialInvestment.max, (bool))
            or not isinstance(payload.initialInvestment.min, (int, float))
            or not isinstance(payload.initialInvestment.max, (int, float))
        ):
            return {
                "isValid": False,
                "message": "initialInvestment must be a mapping object with min and max values should be a number.",
            }
        if isinstance(payload.initialInvestment, abc.MutableMapping) and payload.initialInvestment.min < 100000:
            return {
                "isValid": False,
                "message": "min value for initialInvestment must be greater than 100000.",
            }
        if (
            isinstance(payload.initialInvestment, abc.MutableMapping)
            and payload.initialInvestment.max < payload.initialInvestment.min
        ):
            return {
                "isValid": False,
                "message": "max value for initialInvestment must be greater than min value.",
            }
        if not isinstance(payload.infusionType, str) or payload.infusionType not in ["monthly", "yearly"]:
            return {
                "isValid": False,
                "message": "infusionType must be string and should be either monthly or yearly.",
            }
        if (
            not isinstance(payload.infusions, abc.MutableMapping)
            or isinstance(payload.infusions.min, (bool))
            or isinstance(payload.infusions.max, (bool))
            or not isinstance(payload.infusions.min, (int, float))
            or not isinstance(payload.infusions.max, (int, float))
        ):
            return {
                "isValid": False,
                "message": "infusions must be a mapping object with min and max values should be a number.",
            }
        if isinstance(payload.infusions, abc.MutableMapping) and payload.infusions.min < 0:
            return {
                "isValid": False,
                "message": "min value for infusions must be greater than 0.",
            }
        if isinstance(payload.infusions, abc.MutableMapping) and payload.infusions.max < payload.infusions.min:
            return {
                "isValid": False,
                "message": "max value for infusions must be greater than min value.",
            }
        if not isinstance(payload.goalPriority, abc.MutableSequence):
            return {
                "isValid": False,
                "message": "goalPriority must be array and can have these values 'need', 'want', 'wish', 'dream'.",
            }
        goal_priorty = [g.lower() for g in payload.goalPriority]
        allowed_goal_priority = {"need", "want", "wish", "dream"}
        input_goal_priority = set(goal_priorty) - allowed_goal_priority
        if (
            not isinstance(payload.goalPriority, abc.MutableSequence)
            or not goal_priorty
            or len(input_goal_priority) > 0
        ):
            return {
                "isValid": False,
                "message": "goalPriority must be array and can have these values 'need', 'want', 'wish', 'dream'.",
            }
        if (
            not isinstance(payload.goalTenure, abc.MutableMapping)
            or isinstance(payload.goalTenure.min, (bool))
            or isinstance(payload.goalTenure.max, (bool))
            or not isinstance(payload.goalTenure.min, (int, float))
            or not isinstance(payload.goalTenure.max, (int, float))
        ):
            return {
                "isValid": False,
                "message": "goalTenure must be a mapping object with min and max values should be a number.",
            }
        if isinstance(payload.goalTenure, abc.MutableMapping) and payload.goalTenure.min < 0:
            return {
                "isValid": False,
                "message": "min value for goalTenure must be greater than 0.",
            }
        if isinstance(payload.goalTenure, abc.MutableMapping) and payload.goalTenure.max < payload.goalTenure.min:
            return {
                "isValid": False,
                "message": "max value for goalTenure must be greater than min value.",
            }
        if (
            not isinstance(payload.targetWealth, abc.MutableMapping)
            or isinstance(payload.targetWealth.min, (bool))
            or isinstance(payload.targetWealth.max, (bool))
            or not isinstance(payload.targetWealth.min, (int, float))
            or not isinstance(payload.targetWealth.max, (int, float))
        ):
            return {
                "isValid": False,
                "message": "targetWealth must be a mapping object with min and max values should be a number.",
            }
        if isinstance(payload.targetWealth, abc.MutableMapping) and payload.targetWealth.min < 0:
            return {
                "isValid": False,
                "message": "min value for targetWealth must be greater than 0.",
            }
        if isinstance(payload.targetWealth, abc.MutableMapping) and payload.targetWealth.max < payload.targetWealth.min:
            return {
                "isValid": False,
                "message": "max value for targetWealth must be greater than min value.",
            }
        if not isinstance(payload.pageSize, int) or payload.pageSize < 500:
            return {
                "isValid": False,
                "message": "pageSize must be int and should be greater than or equal to 500.",
            }
        return {"isValid": True, "message": None}

    async def generate_goal_discovery(self, userInput, adminConfig, portfolios, ptf=None):
        try:
            # # pld = prepare_generate_payload("goaldiscovery", userInput, adminConfig, portfolios, "", ptf=ptf)
            # pld = DictDefault(pld)
            newPipePayload = {
                "user_profile": {
                    "goalType": userInput.goalType,
                    "riskProfile": userInput.riskProfile,
                    "initialInvestment": {
                        "min": userInput.initialInvestment.min,
                        "max": userInput.initialInvestment.max,
                    },
                    "infusionType": userInput.infusionType,
                    "infusions": {"min": userInput.infusions.min, "max": userInput.infusions.max},
                    "goalPriority": userInput.goalPriority,
                    "goalTenure": {"min": userInput.goalTenure.min, "max": userInput.goalTenure.max},
                    "targetWealth": {"min": userInput.targetWealth.min, "max": userInput.targetWealth.max},
                },
                "oid": ptf["user"]["id"],
                "pipe_config": {
                    "goalDiscoveryLookUp": True
                    if list(
                        filter(
                            lambda x: x.type == "GoalDiscoveryLookUp",
                            adminConfig["goalPriority"]["generalSettings"]["actuarials"],
                        )
                    )
                    else False
                },
            }
            newPipePayload = DictDefault(newPipePayload)

            return {"error": None, "data": newPipePayload}
        except Exception as e:
            L = request.vars["L"]
            L.error(e)
            InternalServerError.messages = str(e)
            raise InternalServerError

    async def goal_discovery_api(self, req, body):
        """Generate goal discovery payload."""
        L = req["vars"]["L"]
        ptf = await prepare_portfolio(req, body)
        config = ptf.get("config")
        body = ptf.get("body")
        sourceIp = ptf.get("sourceIp")
        clientId = ptf.get("clientId")
        name = ptf.get("name")
        email = ptf.get("email")
        body = DictDefault(ptf.get("body"))
        portfolios = ptf.get("portfolios")
        generatePayloadOnly = ptf.get("generatePayloadOnly")
        requestId = "{}".format(uuid.uuid4())
        if not body.request_id:
            body.request_id = requestId
        headers = req.get("headers")
        req = DictDefault(req)
        body.debug = False
        if headers.get("debug") == "true":
            body.debug = True
        portfolios = ptf.get("portfolios")
        generatePayloadOnly = ptf.get("generatePayloadOnly")
        logData = {
            "sourceIp": sourceIp,
            "endpoint": "/api/goe-api/goaldiscovery",
            "clientId": clientId,
            "name": name,
            "email": email,
            "req": json.dumps(body),
        }
        validate_goal_discovery = await self.validate_goal_discovery_payload(body)
        isValid = validate_goal_discovery.get("isValid")
        message = validate_goal_discovery.get("message")
        L.info(f"validate_goal_discovery_payload---------------- {isValid}, {message}")
        if not isValid:
            return genericResponse(
                None,
                {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": message},
            )
        config = DictDefault(config)

        validate_risk_profile = validateIfRiskProfileisRiskProfileValid(config.portfolioConfig, body)
        isRiskProfileValid = validate_risk_profile.get("isRiskProfileValid")
        riskProfileErrorMessage = validate_risk_profile.get("riskProfileErrorMessage") or validate_risk_profile.get(
            "message"
        )
        L.info(f"validateIfRiskProfileisRiskProfileValid------------- {isRiskProfileValid}, {riskProfileErrorMessage}")
        if not isRiskProfileValid:
            return genericResponse(
                None,
                {"logData": logData, "statusCode": 400, "message": "Validation Error", "data": riskProfileErrorMessage},
            )
        pay_load_response = await self.generate_goal_discovery(body, config, portfolios, ptf=ptf)
        error = pay_load_response.get("error")
        pipePayload = pay_load_response.get("data")
        L.info(f"generateGoalDiscoveryPayload {error}")

        if error:
            return genericResponse(
                None,
                {"logData": logData, "statusCode": 400, "message": error, "data": None},
            )
        if generatePayloadOnly:
            return genericResponse(
                None,
                {"logData": logData, "statusCode": 200, "message": "Success", "data": pipePayload},
            )

        handler = goe_api_response_handler(logData, "")
        return (pipePayload, handler)
