import enum
import time
import asyncio
import json

from collections import abc

# from pymongo import settings

from sqlalchemy import select
from sqlalchemy.ext.declarative import declarative_base

from quart import request

import rest_pb2
import rest_pb2_grpc

import uip_grpc

from uip_dbs_async import Db

from google.protobuf.json_format import MessageToDict

from goelib import GenerateTables

from goelib.api.shared.common import DictDefault
from transcoder_libs import check_access

from goelib.errors import BadRequest

from goelib.errors import ValidationError

from uip_access import AccessControl

grpc_channels = uip_grpc.GRPC(async_mode=True)
METADATA = GenerateTables.generate_metadata()

# db_con = DbAccess()
DBase = declarative_base()


class UserStatus(enum.Enum):
    ACTIVE = "Active"
    INACTIVE = "Inactive"


async def get_enums(table_name, name=None, table_id=None, as_dataframe=False):
    """Get all records from given table_name with filter as name or table_id
     in json format and returns.
    Args:
        table_name (str): [Name of table to query]
        name (str, optional): [query filter table results based on name column value]. Defaults to None.
        table_id (int, optional): [query filter on table results based on]. Defaults to None.

    Returns:
        json: [json table results]
    """
    METADATA = GenerateTables.generate_metadata()
    table = METADATA.metadata.tables.get(table_name)
    stmt = select(table)
    if name:
        stmt = stmt.where(table.c.name == name)
    if table_id and isinstance(table_id, int):
        stmt = stmt.where(table.c.id == table_id)

    db = await Db.Create("goe_db")
    result = await db.get_data(stmt, as_dataframe=True)
    if result is None or result.empty:
        return None
    if as_dataframe:
        return result
    else:
        data = result.to_json(orient="records", date_format="iso")
        return data


def cast_doc_object(data):
    # data = DictDefault(data)
    if data.statusId:
        data["statusId"] = int(data.statusId)
    if data.countryId:
        data["countryId"] = int(data.countryId)
    if data.segmentId:
        data["segmentId"] = int(data.segmentId)
    if data.portfolioBundleId:
        data["portfolioBundleId"] = int(data.portfolioBundleId)
    if (
        isinstance(data.config, abc.MutableMapping)
        and data.config
        and data.config.goalPriority
        and data.config.goalPriority.generalSettings
    ):
        if data.config.goalPriority.generalSettings.actuarials:
            actuarials = []
            for actuarial in data.config.goalPriority.generalSettings.actuarials:
                actuarial["id"] = int(actuarial["id"])
                actuarials.append(actuarial)
            data.config.goalPriority.generalSettings.actuarials = actuarials
        if data.config.goalPriority.generalSettings.maxAge:
            data.config.goalPriority.generalSettings.maxAge = int(data.config.goalPriority.generalSettings.maxAge)
        if data.config.goalPriority.generalSettings.feesAdjuster:
            data.config.goalPriority.generalSettings.feesAdjuster = int(
                data.config.goalPriority.generalSettings.feesAdjuster
            )
        if data.config.goalPriority.generalSettings.minPortfoliosForLastYear:
            data.config.goalPriority.generalSettings.minPortfoliosForLastYear = int(
                data.config.goalPriority.generalSettings.minPortfoliosForLastYear
            )
        if data.config.goalPriority.generalSettings.swingConstraintNumber:
            data.config.goalPriority.generalSettings.swingConstraintNumber = int(
                data.config.goalPriority.generalSettings.swingConstraintNumber
            )
        if data.config.goalPriority.generalSettings.planningAge:
            data.config.goalPriority.generalSettings.planningAge = int(
                data.config.goalPriority.generalSettings.planningAge
            )
        if data.config.goalPriority.generalSettings.minimumPlanningAge:
            data.config.goalPriority.generalSettings.minimumPlanningAge = int(
                data.config.goalPriority.generalSettings.minimumPlanningAge
            )
    if (
        isinstance(data.config, abc.MutableMapping)
        and data.config
        and data.config.goalPriority
        and data.config.goalPriority.performance
    ):
        if data.config.goalPriority.performance.sigma:
            data.config.goalPriority.performance.sigma = int(data.config.goalPriority.performance.sigma)
        if data.config.goalPriority.performance.alternativeSigma:
            data.config.goalPriority.performance.alternativeSigma = int(
                data.config.goalPriority.performance.alternativeSigma
            )
        if data.config.goalPriority.performance.nodesPerSd:
            data.config.goalPriority.performance.nodesPerSd = int(data.config.goalPriority.performance.nodesPerSd)
        if data.config.goalPriority.performance.longTenureThreshold:
            data.config.goalPriority.performance.longTenureThreshold = int(
                data.config.goalPriority.performance.longTenureThreshold
            )
        if data.config.goalPriority.performance.altNodesPerSd:
            data.config.goalPriority.performance.altNodesPerSd = int(data.config.goalPriority.performance.altNodesPerSd)
    if isinstance(data.config, abc.MutableMapping) and data.config and data.config.portfolioConfig:
        if data.config.portfolioConfig.shortTermGoalTenure:
            data.config.portfolioConfig.shortTermGoalTenure = int(data.config.portfolioConfig.shortTermGoalTenure)
        if data.config.portfolioConfig.shortTermRetirementGoalTenure:
            data.config.portfolioConfig.shortTermRetirementGoalTenure = int(
                data.config.portfolioConfig.shortTermRetirementGoalTenure
            )
        if data.config.portfolioConfig.shortTermRetirementGoalTenureUnengaged:
            data.config.portfolioConfig.shortTermRetirementGoalTenureUnengaged = int(
                data.config.portfolioConfig.shortTermRetirementGoalTenureUnengaged
            )
        if data.config.portfolioConfig.portfolioConfig:
            if data.config.portfolioConfig.portfolioConfig.conservativeRisksettings:
                data.config.portfolioConfig.portfolioConfig.conservativeRisksettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.conservativeRisksettings)
                )
            if data.config.portfolioConfig.portfolioConfig.veryConservativeRisksettings:
                data.config.portfolioConfig.portfolioConfig.veryConservativeRisksettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.veryConservativeRisksettings)
                )
            if data.config.portfolioConfig.portfolioConfig.moderateRisksettings:
                data.config.portfolioConfig.portfolioConfig.moderateRisksettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.moderateRisksettings)
                )
            if data.config.portfolioConfig.portfolioConfig.conservativelyModerateRisksettings:
                data.config.portfolioConfig.portfolioConfig.conservativelyModerateRisksettings = list(
                    map(
                        lambda x: int(x), data.config.portfolioConfig.portfolioConfig.conservativelyModerateRisksettings
                    )
                )
            if data.config.portfolioConfig.portfolioConfig.moderatelyAggressiveRisksettings:
                data.config.portfolioConfig.portfolioConfig.moderatelyAggressiveRisksettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.moderatelyAggressiveRisksettings)
                )
            if data.config.portfolioConfig.portfolioConfig.aggressiveRisksettings:
                data.config.portfolioConfig.portfolioConfig.aggressiveRisksettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.aggressiveRisksettings)
                )
            if data.config.portfolioConfig.portfolioConfig.veryAggressiveRisksettings:
                data.config.portfolioConfig.portfolioConfig.veryAggressiveRisksettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.veryAggressiveRisksettings)
                )
            if data.config.portfolioConfig.portfolioConfig.shortTermGoalsettings:
                data.config.portfolioConfig.portfolioConfig.shortTermGoalsettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.shortTermGoalsettings)
                )
            if data.config.portfolioConfig.portfolioConfig.decumulationScenariosettings:
                data.config.portfolioConfig.portfolioConfig.decumulationScenariosettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.decumulationScenariosettings)
                )
            if data.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalsettings:
                data.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalsettings = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalsettings)
                )
            if data.config.portfolioConfig.portfolioConfig.decumulationScenarioProfiles:
                data.config.portfolioConfig.portfolioConfig.decumulationScenarioProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.decumulationScenarioProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.aggressiveRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.aggressiveRiskProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.aggressiveRiskProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.defaultRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.defaultRiskProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.defaultRiskProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.veryConservativeRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.veryConservativeRiskProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.veryConservativeRiskProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.shortTermGoalProfiles:
                data.config.portfolioConfig.portfolioConfig.shortTermGoalProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.shortTermGoalProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.veryAggressiveRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.veryAggressiveRiskProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.veryAggressiveRiskProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.conservativelyModerateRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.conservativelyModerateRiskProfiles = list(
                    map(
                        lambda x: int(x), data.config.portfolioConfig.portfolioConfig.conservativelyModerateRiskProfiles
                    )
                )
            if data.config.portfolioConfig.portfolioConfig.moderatelyAggressiveRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.moderatelyAggressiveRiskProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.moderatelyAggressiveRiskProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.conservativeRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.conservativeRiskProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.conservativeRiskProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalProfiles:
                data.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.shortTermRetirementGoalProfiles)
                )
            if data.config.portfolioConfig.portfolioConfig.moderateRiskProfiles:
                data.config.portfolioConfig.portfolioConfig.moderateRiskProfiles = list(
                    map(lambda x: int(x), data.config.portfolioConfig.portfolioConfig.moderateRiskProfiles)
                )

    return data


# In Memory cache
portfolio_bundles = None
portfolios = None
lock = None
cache_ttl = 0


async def get_users_data(users, includeCountriesAndSegments=False):
    global portfolio_bundles
    global portfolios
    global lock
    global cache_ttl

    if lock is None:
        lock = asyncio.Lock()

    users = list(
        filter(
            lambda x: "app_settings" in x
            and "goe" in x["app_settings"]
            and "client-settings" in x["app_settings"]["goe"],
            users,
        )
    )
    if not users:
        return {"data": users, "count": len(users)}

    portfolio_bundle = METADATA.metadata.tables.get("portfolio_bundle")
    portfolio = METADATA.metadata.tables.get("portfolio")

    # if users and isinstance(users, abc.MutableSequence):
    #    settings = [cast_doc_object(DictDefault(d['app_settings'])) for d in users]

    # Get all countries, all segments and related portfoliobundles from database at one shot.
    countries = None
    segments = None
    if includeCountriesAndSegments:
        countries = await get_enums("country", as_dataframe=True)
        segments = await get_enums("segment", as_dataframe=True)
        if countries is None or countries.empty:
            ValidationError.messages = "no country found in database"
            raise ValidationError
        if segments is None or segments.empty:
            ValidationError.messages = "no segments found in database"
            raise ValidationError

    async with lock:
        if time.time() > cache_ttl:
            db = await Db.Create("goe_db")
            portfolio_bundle_stmt = select(portfolio_bundle)
            portfolio_bundles = await db.get_data(portfolio_bundle_stmt, as_dataframe=True)
            portfolio_stmt = select(portfolio)
            portfolios = await db.get_data(portfolio_stmt, as_dataframe=True)
            cache_ttl = time.time() + 60

    for user in users:
        user["app_settings"]["goe"]["client-settings"] = cast_doc_object(
            DictDefault(user["app_settings"]["goe"]["client-settings"])
        )
        settings = user["app_settings"]["goe"]["client-settings"]
        if includeCountriesAndSegments:
            country_item = json.loads(
                countries[countries.id == settings.get("countryId")].to_json(orient="records", date_format="iso")
            )
            if country_item:
                settings["country"] = country_item[0]

            segment_item = json.loads(
                segments[segments.id == settings.get("segmentId")].to_json(orient="records", date_format="iso")
            )
            if segment_item:
                settings["segment"] = segment_item[0]

        if portfolio_bundles is not None and not portfolio_bundles.empty:
            portfolio_bundle_item = json.loads(
                portfolio_bundles[portfolio_bundles.id == settings.get("portfolioBundleId")].to_json(
                    orient="records", date_format="iso"
                )
            )
            if portfolio_bundle_item:
                settings["portfolioBundle"] = portfolio_bundle_item[0]

            # # generate status of user by passing roles. If user has any one of these he is goe active user.
            # has_access = check_access(
            #     profile.get("id"),
            #     (("goe", "roles", "admin"), ("goe", "roles", "view"), ("goe", "roles", "client")),
            # )
        settings["status"] = {"name": UserStatus.ACTIVE.value}  # if has_access else {"name": UserStatus.INACTIVE.value}

    for user in users:
        settings = user["app_settings"]["goe"]["client-settings"]
        if settings and "portfolioBundle" in settings and (portfolios is not None and not portfolios.empty):
            portfolio_id = settings["portfolioBundle"]["id"]
            settings["portfolioBundle"]["portfolios"] = json.loads(
                portfolios[portfolios.bundleId == portfolio_id].to_json(orient="records", date_format="iso")
            )
            for pt in settings["portfolioBundle"]["portfolios"]:
                if pt.get("assetAllocations"):
                    pt["assetAllocations"] = json.loads(pt["assetAllocations"])
        if settings:
            settings["name"] = user.get("name")
            settings["id"] = user.get("_id")

    return {"data": users, "count": len(users)}


async def get_user_profile(req):
    user = None
    generatePayloadOnly = False
    requester_oid = req.get("requester_oid")
    request_meta_data = req.get("request_meta_data")
    ac = await AccessControl.Create()
    async def check_uaccess(access, needed_access):
        try:
            user_access = access["users"][user_id]["access"]
            needed_access = set(needed_access)
            residual_needed_access = needed_access - user_access
            if (
                access["is_super_user"]
                or len(residual_needed_access) == 0
                or (len(residual_needed_access) < len(needed_access))
            ):
                return True
            else:
                return False
        except Exception as e:
            print(e)
            if "L" in req:
                req["L"].error(e)
            return False
    user_id = req["requester_oid"]
    access = await ac.get_access(user_id)

    is_admin = await check_uaccess(access, (("goe", "client-settings", "admin"), ("goe", "client-settings", "view")))
    is_client = await check_uaccess(access, (("goe", "client-settings", "client"),))
    is_super = await check_uaccess(access, (("admin", "acl", "admin"),))
    # If user is is_super allow him to access as admin.
    if is_super is True:
        is_client = False
    if not is_admin and not is_client and not is_super:
        ValidationError.messages = f"User dont have any proper access to GOE."
        raise ValidationError
    headers = req.get("headers")
    # Admin cannt be client. if is_admin true consider he is admin
    # allow to access to impersonate both for admin and view users

    if is_client:  # if user is client get email from request metadata
        user = await get_user_from_oid(requester_oid, request_meta_data, True)
    elif is_admin:  # if user is admin get email from headers
        if not headers.get("clientemail") or type(headers.get("clientemail")) is not str:
            BadRequest.messages = (
                "400 Bad Request: The browser (or proxy) sent a request that this server could not understand."
            )
            raise BadRequest
        oid = await get_oid_by_email(headers.get("clientemail"), request_meta_data)
        user = await get_user_from_oid(oid, request_meta_data, True)
        if headers.get("generatepayloadonly") == "true":
            generatePayloadOnly = True
    return user, generatePayloadOnly


async def getUserWithEmail(email, includePortfolios=False):
    # now get GOE app settings for the above email
    user_settings = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
            request=rest_pb2.AppUserSettingsRequest(emails=[email]),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    if not user_settings:
        ValidationError.messages = f"No GOE settings found for requested user {email}"
        raise ValidationError

    for oid, data in user_settings:
        data["id"] = oid
        break

    user = await get_users_data(data=[data])
    if not user.get("data"):
        return user
    user = user["data"][0]
    user["portfolio_bundle"] = user["portfolioBundle"]
    return user


async def get_user_with_oid(oid, request_meta_data, includePortfolios=False):
    # now get GOE app settings for the above users
    user_settings = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
            request=rest_pb2.AppUserSettingsRequest(user_ids=[oid]),
            metadata=request_meta_data,
        ),
        preserving_proto_field_name=True,
    )
    if not user_settings:
        ValidationError.messages = f"No GOE settings found for requested user {oid}"
        raise ValidationError

    user_data = user_settings[oid]
    user_data["id"] = oid

    user = await get_users_data(users=[user_data])
    if not user.get("data"):
        return user
    user = user["data"][0]
    # user["user_status"] = user["status"]
    user["app_settings"]["goe"]["client-settings"]["portfolio_bundle"] = user["app_settings"]["goe"]["client-settings"][
        "portfolioBundle"
    ]
    return user


async def get_user_from_oid(oid, request_meta_data, includePortfolios=False):
    return await get_user_with_oid(oid, request_meta_data, includePortfolios)


async def getUserFromEmail(email, includePortfolios=False):
    return await getUserWithEmail(email, includePortfolios)


async def get_oid_by_email(email, metadata_t):
    oid = None
    if not email:
        return None
    req = {
        "join": "or",
        "access": [
            ["goe", "client-settings", "client"],
        ],
    }
    users = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUsersWithAccess(
            request=rest_pb2.JSON(str=json.dumps(req)),
            metadata=metadata_t,
        ),
        preserving_proto_field_name=True,
    )
    if "error" in users:
        ValidationError.messages = users["error"]
        raise ValidationError
    users = dict([(u, users[u]["email"].lower()) for u in users if users[u].get("email", "").lower() == email.lower()])
    if not users:
        ValidationError.messages = f"User doesnt exist with this email {email}"
        raise ValidationError
    oid = list(users.keys())
    return oid[0]


def has_greater_precision(num, n):
    num_str = str(num)
    decimal_index = num_str.find(".")
    if decimal_index != -1:
        num_digits_after_decimal = len(num_str) - decimal_index - 1
        return num_digits_after_decimal > n
    return False
