import datetime
import json
import pandas as pd
import re
import io
import traceback
from io import StringIO
from quart import request

from sqlalchemy.sql import func, or_
from sqlalchemy import select

from goelib import GenerateTables
from goelib import DbAccess

# from goelib.api.resources.admin import generate_social_security_data_tables

from goelib.errors import ValidationError, InternalServerError, GoeException

# from goe_transcoder_libs import read_file as goe_read_file
from transcoder_libs import read_file

db_con = DbAccess()
# currently accepts d-mm-yyyy and dd-mm-yyyy
DDMMYYYY_FORMAT = re.compile(r"^((3[01]|[12][0-9]|0?[1-9])-(1[0-2]|0[1-9])-((?:18|19|20|21|22|23)\d{2})$)")

# accept only dd-mm-yyyy
DDMMYYYY_FORMAT_ONLY = re.compile(r"^((3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-((?:18|19|20|21|22|23)\d{2})$)")

MM_YYYY_FORMAT_ONLY = re.compile(r"^((1[0-2]|0[1-9])-((?:18|19|20|21|22|23)\d{2}))")


async def get_meta_data_for_tables(tables_metadata):
    tables = {}
    METADATA = GenerateTables.generate_metadata()
    for table in tables_metadata:
        if table not in METADATA.metadata.tables:
            raise ValueError(f"Table not found table_name: {table}")
        tables[table] = METADATA.metadata.tables.get(table)
    return tables


class DictDefault(dict):
    def __init__(__self, *args, **kwargs):
        for arg in args:
            if not arg:
                continue
            elif isinstance(arg, dict):
                for key, val in arg.items():
                    __self[key] = __self._getval(val)
            elif isinstance(arg, tuple) and (not isinstance(arg[0], tuple)):
                __self[arg[0]] = __self._getval(arg[1])
            else:
                for key, val in iter(arg):
                    __self[key] = __self._getval(val)

        for key, val in kwargs.items():
            __self[key] = __self._getval(val)

    def __setattr__(self, name, value):
        if hasattr(self.__class__, name):
            raise AttributeError("'Dict' object attribute " "'{0}' is cant set".format(name))
        else:
            self[name] = value

    @classmethod
    def _getval(cls, item):
        if isinstance(item, dict):
            return cls(item)
        elif isinstance(item, (list, tuple)):
            return type(item)(cls._getval(elem) for elem in item)
        return item

    def __getattr__(self, item):
        return self.__getitem__(item)

    def __missing__(self, name):
        return None


def validateDates(startDate, endDate, currDate=None):
    currentDate = datetime.datetime.strptime(currDate, "%d-%m-%Y") if currDate else datetime.datetime.now()
    startDate = datetime.datetime.strptime(startDate, "%d-%m-%Y")
    endDate = datetime.datetime.strptime(endDate, "%d-%m-%Y")
    if currentDate < startDate:
        return {"isValid": False, "message": "currDate must be greater than or equal to startDate."}
    if currentDate > endDate:
        return {"isValid": False, "message": "currDate must be less than endDate."}
    return {"isValid": True, "message": None}


def calculateAge(birthDate, today_date=datetime.date.today()):
    today = today_date
    age = today.year - birthDate.year - ((today.month, today.day) < (birthDate.month, birthDate.day))

    return age


def isDateFormatValid(date):
    if isinstance(date, str):
        if DDMMYYYY_FORMAT.match(date) is not None:
            try:
                day, month, year = date.split("-")
                datetime.datetime(int(year), int(month), int(day))
            except ValueError:
                return False
            return True
    return False


def isDateFormatValidV1(date):
    if isinstance(date, str):
        if DDMMYYYY_FORMAT_ONLY.match(date) is not None:
            try:
                day, month, year = date.split("-")
                datetime.datetime(int(year), int(month), int(day))
            except ValueError:
                return False
            return True
    return False


def is_valid_format_mmyyyy(date):
    if isinstance(date, str):
        if MM_YYYY_FORMAT_ONLY.match(date) is not None:
            try:
                month, year = date.split("-")
                datetime.datetime(int(year), int(month), 10)
            except ValueError:
                return False
            return True
    return False


def genericResponse(res, logobj):
    del logobj["logData"]
    if logobj.get("data"):
        logobj["body"] = logobj["data"]
        del logobj["data"]
    return logobj, logobj.get("statusCode")


async def read_actuarial_files(actuarial_ids, actuarial_types):
    result = await get_actuarials(actuarial_ids, actuarial_types)
    x = {}
    for f in result.to_dict(orient="records"):
        actuarial_files = {
            "actuarial_type": f.get("actuarial_type"),
            "path": f.get("path"),
            "actuarial_file_exists": True,
        }
        actuarial_data = await readDataFromActuarial(**actuarial_files)
        x.update({f.get("actuarial_type"): actuarial_data.get("actuarialData")[f.get("actuarial_type")]})
    return x


async def get_actuarials(actuarial_ids, actuarial_types=None):
    tables = await get_meta_data_for_tables(
        [
            "actuarial",
            "country",
            "segment",
            "actuarial_type",
            "actuarial_file",
        ]
    )

    Country, Segment, Actuarial, ActuarialType, ActuarialFile = (
        tables["country"],
        tables["segment"],
        tables["actuarial"],
        tables["actuarial_type"],
        tables["actuarial_file"],
    )

    stmt = (
        select(Actuarial, ActuarialType.c.name.label("actuarial_type"), ActuarialFile.c.path)
        .join_from(Actuarial, Country, Actuarial.c.countryId == Country.c.id, isouter=True)
        .join_from(Actuarial, ActuarialType, Actuarial.c.typeId == ActuarialType.c.id, isouter=True)
        .join_from(Actuarial, Segment, Actuarial.c.segmentId == Segment.c.id, isouter=True)
        .join_from(Actuarial, ActuarialFile, Actuarial.c.id == ActuarialFile.c.actuarialId, isouter=True)
        .where(Actuarial.c.id.in_(actuarial_ids))
    )
    stmt = stmt.where(or_(ActuarialFile.c.active == True, ActuarialFile.c.active == None))  # noqa: E711
    if actuarial_types:
        stmt = stmt.where(ActuarialType.c.name.in_(actuarial_types))
    print("stmt", stmt)
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    return result


async def actuarial_get_one(actuarial_id):
    """Get actuarial for given id"""
    METADATA = GenerateTables.generate_metadata()
    Actuarial = METADATA.metadata.tables.get("actuarial")
    ActuarialType = METADATA.metadata.tables.get("actuarial_type")
    ActuarialFile = METADATA.metadata.tables.get("actuarial_file")
    Country = METADATA.metadata.tables.get("country")
    Segment = METADATA.metadata.tables.get("segment")
    stmt = (
        select(
            Actuarial,
            func.row_to_json(ActuarialFile.table_valued()).label("files"),
            ActuarialType.c.name.label("actuarial_type"),
        )
        .join_from(Actuarial, Country, Actuarial.c.countryId == Country.c.id, isouter=True)
        .join_from(Actuarial, ActuarialType, Actuarial.c.typeId == ActuarialType.c.id, isouter=True)
        .join_from(Actuarial, Segment, Actuarial.c.segmentId == Segment.c.id, isouter=True)
        .join_from(Actuarial, ActuarialFile, Actuarial.c.id == ActuarialFile.c.actuarialId, isouter=True)
    )
    stmt = stmt.where(
        Actuarial.c.id == actuarial_id, or_(ActuarialFile.c.active.is_(None), ActuarialFile.c.active == True)
    )
    db = await db_con.get_access()
    result = await db.get_data(stmt, as_dataframe=True)
    return result


async def validateRequiredDataCheck(payload):
    requiredDataAvailable = (
        True
        if ("requiredDataAvailable" in payload and payload.requiredDataAvailable is True)
        else payload.requiredDataAvailable
    )
    if "requiredDataAvailable" not in payload:
        requiredDataAvailable = True
    currentAge = payload.currentAge
    if currentAge is not None and (type(currentAge) is not int or currentAge < 0):
        return {
            "isValid": False,
            "message": "currentAge must be an integer or null.",
        }
    if not isinstance(requiredDataAvailable, bool):
        return {
            "isValid": False,
            "message": "requiredDataAvailable must be a boolean.",
        }
    return {"isValid": True, "message": None}


async def readDataFromActuarial(**kwargs):
    """Read actuarial file from simple storage service aws"""
    try:
        if not kwargs.get("actuarial_file_exists"):  # If file not exist in kwargs get file using actuarial id
            actuarial = await actuarial_get_one(kwargs.get("actuarials")[0].id)
            if actuarial is None or actuarial.empty:
                return kwargs.get("default_payload")
            filePath = actuarial.files[0].get("path") if len(actuarial.files) and actuarial.files[0] else ""

        else:
            filePath = kwargs.get("path")
        if filePath:
            _, file_id = filePath.split("actuarialTypeFile-")
            if kwargs.get("request_type"):
                from goe_transcoder_libs import read_file as goe_read_file

                file = await goe_read_file(kwargs["request"], file_id)
            else:
                file = await read_file(file_id)
            fileBody = file["data"]
            if file["file_type"] != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                data = fileBody.decode()
                if not data:
                    return kwargs.get("default_payload")
                file_body = StringIO(data)
                file_data = pd.read_csv(file_body, delimiter=",")
                file_data.to_json(orient="records")
                return {
                    "actuarialData": {kwargs.get("actuarial_type"): json.loads(file_data.to_json(orient="records"))}
                }
            else:
                xl = pd.ExcelFile(io.BytesIO(file["data"]))
                xl_data = {}
                for sheet in xl.sheet_names:
                    file_data = pd.read_excel(io.BytesIO(file["data"]), sheet_name=sheet)
                    xl_data[sheet] = json.loads(file_data.to_json(orient="records"))
                return {"actuarialData": {kwargs.get("actuarial_type"): xl_data}}
        else:
            return kwargs.get("default_payload")
    except Exception as e:
        if "request" in kwargs and kwargs["request"]:
            L = kwargs["request"].vars["L"]
        else:
            L = request.vars["L"]
        L.info(f"Error in generating actuarial json data {str(e)}")
        return kwargs.get("default_payload")


async def getDataTablesforGOETaxes(userInput, adminConfig):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "LYTargetAllocations": None,
                "LYCMEPackage": None,
                "LifeExpectancy": None,
            },
        }
    )
    lycme_package = []
    lytarget_allocations = []
    ly_expectancy = []
    if adminConfig.goalPriority.generalSettings.taxActuarialData:
        lycme_package = list(
            filter(lambda e: e.type == "LYCMEPackage", adminConfig.goalPriority.generalSettings.taxActuarialData)
        )
        lytarget_allocations = list(
            filter(lambda e: e.type == "LYTargetAllocations", adminConfig.goalPriority.generalSettings.taxActuarialData)
        )
    if adminConfig.goalPriority.generalSettings.actuarials:
        ly_expectancy = list(
            filter(lambda e: e.type == "LifeExpectancy", adminConfig.goalPriority.generalSettings.actuarials)
        )
    if not lycme_package and not lytarget_allocations and not ly_expectancy:
        return defaultPayload
    else:
        if lycme_package:
            kwargs = {"actuarial_type": "LYCMEPackage", "default_payload": defaultPayload, "actuarials": lycme_package}
            lycme_package_data = await readDataFromActuarial(**kwargs)
        if lytarget_allocations:
            kwargs = {
                "actuarial_type": "LYTargetAllocations",
                "default_payload": defaultPayload,
                "actuarials": lytarget_allocations,
            }
            lytarget_allocations_data = await readDataFromActuarial(**kwargs)
        if ly_expectancy:
            kwargs = {
                "actuarial_type": "LifeExpectancy",
                "default_payload": defaultPayload,
                "actuarials": ly_expectancy,
            }
            ly_expectancy_data = await readDataFromActuarial(**kwargs)
        datatable = {
            "actuarialData": {
                "LYTargetAllocations": lytarget_allocations_data["actuarialData"]["LYTargetAllocations"]
                if lytarget_allocations
                else None,
                "LYCMEPackage": lycme_package_data["actuarialData"]["LYCMEPackage"] if lycme_package else None,
                "LifeExpectancy": ly_expectancy_data["actuarialData"]["LifeExpectancy"] if ly_expectancy else None,
            }
        }
        defaultPayload.update(datatable)
        return defaultPayload


async def getDataTablesforGOESimulationEngine(userInput, adminConfig):
    datatables = await getDataTablesforGOETaxes(userInput, adminConfig)
    glidepath_table = await generateGlidePathData(userInput, adminConfig)
    datatables["actuarialData"].update(glidepath_table["actuarialData"])
    return datatables


async def getDataTablesforDiscretionaryCalculator(userInput, adminConfig):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "FixedDiscretionary": None,
            },
        }
    )
    actuarials = list(
        filter(lambda e: e.type == "FixedDiscretionary", adminConfig.goalPriority.generalSettings.actuarials)
    )
    if not actuarials:
        return defaultPayload

    kwargs = {"actuarial_type": "FixedDiscretionary", "default_payload": defaultPayload, "actuarials": actuarials}
    data = await readDataFromActuarial(**kwargs)
    defaultPayload.update(data)
    return defaultPayload


async def getDataTablesforCustomPortfolio(userInput, adminConfig):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "HistoricalIndexList": None,
            },
        }
    )
    actuarials = list(
        filter(lambda e: e.type == "HistoricalIndexList", adminConfig.goalPriority.generalSettings.actuarials)
    )
    if not actuarials:
        return defaultPayload
    kwargs = {"actuarial_type": "HistoricalIndexList", "default_payload": defaultPayload, "actuarials": actuarials}
    data = await readDataFromActuarial(**kwargs)
    defaultPayload.update(data)

    actuarials = list(filter(lambda e: e.type == "FTLongTermCME", adminConfig.goalPriority.generalSettings.actuarials))
    if not actuarials:
        return defaultPayload
    kwargs = {"actuarial_type": "FTLongTermCME", "default_payload": defaultPayload, "actuarials": actuarials}
    long_term_cme_data = await readDataFromActuarial(**kwargs)
    defaultPayload["actuarialData"].update(long_term_cme_data["actuarialData"])

    return defaultPayload


async def get_data_tables_for_age_based_equity(userInput, adminConfig, request_type=None, req=None):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "ageBasedEquityCap": None,
            },
        }
    )
    actuarials = list(
        filter(lambda e: e.type == "AgeBasedEquityCap", adminConfig.goalPriority.generalSettings.actuarials)
    )
    if not actuarials:
        return defaultPayload

    kwargs = {
        "actuarial_type": "ageBasedEquityCap",
        "default_payload": defaultPayload,
        "actuarials": actuarials,
        "request_type": request_type,
        "request": req,
    }
    data = await readDataFromActuarial(**kwargs)
    defaultPayload.update(data)
    return defaultPayload


async def getDataTablesforDecumulation(userInput, adminConfig, request_type=None, req=None):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "mortality": None,
            },
        }
    )
    actuarials = list(filter(lambda e: e.type == "Mortality", adminConfig.goalPriority.generalSettings.actuarials))
    if not actuarials:
        return defaultPayload

    kwargs = {
        "actuarial_type": "mortality",
        "default_payload": defaultPayload,
        "actuarials": actuarials,
        "request_type": request_type,
        "request": req,
    }
    data = await readDataFromActuarial(**kwargs)
    for x in data["actuarialData"]["mortality"]:
        if "Health" in x and x["Health"] is None:
            x["Health"] = ""
        if "health" in x and x["health"] is None:
            x["health"] = ""
        if "Gender" in x and x["Gender"] is None:
            x["Gender"] = ""
        if "gender" in x and x["gender"] is None:
            x["gender"] = ""
    defaultPayload.update(data)
    return defaultPayload


async def get_decumulation_uploads(body, config, request_type=None, req=None):
    res = {}
    if config.decummulationFiles:
        for dt in config.decummulationFiles:
            # [
            # config.decummulationFiles.additionalConsumptionCap,
            # config.decummulationFiles.minConsumptionFloor,
            # config.decummulationFiles.ageBasedGICap, config.decummulationFiles.ageBasedAnnuityCap,
            # config.decummulationFiles.maxEquityExposure]:
            field_name, file_id = dt, config.decummulationFiles[dt]
            if request_type:
                from goe_transcoder_libs import read_file as goe_read_file

                file = await goe_read_file(req, file_id)
            else:
                file = await read_file(file_id)
            fileBody = file["data"]
            if file["file_type"] != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                data = fileBody.decode()
                if not data:
                    return {}
                file_body = StringIO(data)
                file_data = pd.read_csv(file_body, delimiter=",")
                file_data.to_json(orient="records")
                res[field_name] = json.loads(file_data.to_json(orient="records"))
            else:
                xl = pd.ExcelFile(io.BytesIO(file["data"]))
                xl_data = {}
                for sheet in xl.sheet_names:
                    file_data = pd.read_excel(io.BytesIO(file["data"]), sheet_name=sheet)
                    xl_data[sheet] = json.loads(file_data.to_json(orient="records"))
                res[field_name] = xl_data
    return res


async def generateGlidePathData(userInput, adminConfig, request_type=None, req=None):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "ageBasedGlidePath": None,
            },
        }
    )
    actuarials = []
    if not userInput.requiredDataAvailable and adminConfig.goalPriority.generalSettings.actuarials:
        actuarials = list(
            filter(lambda e: e.type == "AgeBasedGlidePath", adminConfig.goalPriority.generalSettings.actuarials)
        )
    if not actuarials:
        return defaultPayload
    else:
        kwargs = {
            "actuarial_type": "ageBasedGlidePath",
            "default_payload": defaultPayload,
            "actuarials": actuarials,
            "request_type": request_type,
            "request": req,
        }
        data = await readDataFromActuarial(**kwargs)
        defaultPayload.update(data)
        return defaultPayload


async def generatePortfolioMappingData(userInput, adminConfig, request_type=None, req=None):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "PortfolioMapping": None,
            },
        }
    )
    actuarials = []
    if adminConfig.goalPriority.generalSettings.actuarials:
        actuarials = list(
            filter(
                lambda e: e.type == "PortfolioMapAggRetirementAccounts-H",
                adminConfig.goalPriority.generalSettings.actuarials,
            )
        )
    if not actuarials:
        return defaultPayload
    else:
        kwargs = {
            "actuarial_type": "PortfolioMapping",
            "default_payload": defaultPayload,
            "actuarials": actuarials,
            "request_type": request_type,
            "request": req,
        }
        data = await readDataFromActuarial(**kwargs)
        defaultPayload.update(data)
        return defaultPayload


async def generateReplacementCalcData(userInput, adminConfig):
    defaultPayload = DictDefault(
        {
            "actuarialData": {
                "RIConfigParam": None,
                "TaxBracket": None,
            },
        }
    )
    taxbracket = []
    riconfig = []
    if adminConfig.goalPriority.generalSettings.actuarials:
        riconfig = list(
            filter(lambda e: e.type == "RIConfigParam", adminConfig.goalPriority.generalSettings.actuarials)
        )
        taxbracket = list(filter(lambda e: e.type == "TaxBracket", adminConfig.goalPriority.generalSettings.actuarials))
    if not taxbracket and not riconfig:
        return defaultPayload
    else:
        if riconfig:
            kwargs = {"actuarial_type": "RIConfigParam", "default_payload": defaultPayload, "actuarials": riconfig}
            riconfig_data = await readDataFromActuarial(**kwargs)
        if taxbracket:
            kwargs = {"actuarial_type": "TaxBracket", "default_payload": defaultPayload, "actuarials": taxbracket}
            taxbracket_data = await readDataFromActuarial(**kwargs)
        datatable = {
            "actuarialData": {
                "riConfigParam": riconfig_data["actuarialData"]["RIConfigParam"] if riconfig else None,
                "taxBracket": taxbracket_data["actuarialData"]["TaxBracket"] if taxbracket else None,
            }
        }
        defaultPayload.update(datatable)
        return defaultPayload


async def generateMortalityPayload(userInput, adminConfig, request_type=None, req=None):
    defaultPayload = DictDefault(
        {
            "considerMortality": False,
            "actuarialData": {
                "mortality": None,
                # Will add lifeExpetancy too in the future
            },
        }
    )
    considerMortality = False
    if userInput.considerMortality:
        defaultPayload.considerMortality = True
        considerMortality = True
    actuarials = []
    if considerMortality and adminConfig.goalPriority.generalSettings.actuarials:
        actuarials = list(filter(lambda e: e.type == "Mortality", adminConfig.goalPriority.generalSettings.actuarials))
    if not actuarials:
        return defaultPayload
    kwargs = {
        "actuarial_type": "mortality",
        "default_payload": defaultPayload,
        "actuarials": actuarials,
        "request_type": request_type,
        "request": req,
    }
    data = await readDataFromActuarial(**kwargs)
    defaultPayload.update(data)
    return defaultPayload


def generatePipePayload(userInput, adminConfig, portfolios, actuarialData, version="2", ptf={}, request=None):
    # /* eslint-disable camelcase */
    try:
        required_data_available = (
            True
            if (userInput.requiredDataAvailable is None or userInput.requiredDataAvailable is True)
            else userInput.requiredDataAvailable
        )
        init_inv = userInput.initialInvestment
        infusions = userInput.infusions
        start_date = userInput.startDate
        end_date = userInput.endDate
        current_age = userInput.currentAge
        retirement_age = userInput.retirementAge
        consider_mortality = userInput.considerMortality
        if required_data_available is False:
            consider_mortality = userInput.considerMortality or None
        engaged_participant = True if userInput.engagedParticipant is None else userInput.engagedParticipant
        pmort_data = actuarialData.mortality if actuarialData.mortality else actuarialData.mortality
        age_based_glide_path = (
            actuarialData.ageBasedGlidePath
            if required_data_available is False and actuarialData.ageBasedGlidePath
            else None
        )
        risk_override = userInput.riskOverride or False
        calibrate_recommendations = userInput.calibrateRecommendations or False
        curr_date = userInput.currDate or datetime.datetime.strftime(
            datetime.datetime.now(), "%d-%m-%Y"
        )  # getFormattedDateNow()
        curr_port_id = userInput.currentPortfolioId
        if curr_port_id is not None and type(curr_port_id) in [float, int] and curr_port_id < 1:
            curr_port_id = None
        # const currDateSplit = curr_date.valueOf().split('-');
        curr_wealth = userInput.currentWealth
        getPath, rebalancing = userInput.getPath, userInput.rebalancing  # noqa: F841
        scenario_type = userInput.scenario_type
        infusion_type = userInput.infusion_type
        if version == "4":
            rebalancing = userInput.reallocationFreq
            scenario_type = userInput.scenarioType
            infusion_type = userInput.infusionType
        reallocationDatesByFrequency = adminConfig.allocationConfiguration.reallocationDatesByFrequency or {}
        reallocationDates = []
        if rebalancing == "yearly":
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
        elif rebalancing == "half-yearly":
            reallocationDates = reallocationDatesByFrequency["halfyearly"]
            rebalancing = "half-yearly_"
        elif rebalancing == "quarterly":
            reallocationDates = reallocationDatesByFrequency["quarterly"]
            rebalancing = "quarterly_"
        else:
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
        realloc_schedules = []
        for dt in reallocationDates:
            t = datetime.datetime.strptime(dt, "%a %b %d %Y")
            realloc_schedules.append(
                datetime.datetime.strftime(datetime.datetime(int(curr_date.split("-")[2]), t.month, t.day), "%d-%m-%Y")
            )

        # reallocationDates: 'Fri Jan 01 2021'
        # tenure = None
        # if start_date and end_date:
        #     tenure = int(
        #         (
        #             datetime.datetime.strptime(end_date, "%d-%m-%Y")
        #             - datetime.datetime.strptime(start_date, "%d-%m-%Y")
        #         ).days
        #         / 365
        #     )
        # if scenario_type == "retirement":
        #     tenure = int(
        #         (
        #             datetime.datetime.strptime(end_date, "%d-%m-%Y") - datetime.datetime.strptime(
        # curr_date, "%d-%m-%Y")
        #         ).days
        #         / 365
        #     )
        shortTermGoalTenure = adminConfig.portfolioConfig.shortTermGoalTenure or 3
        shortTermRetirementGoalTenure = adminConfig.portfolioConfig.shortTermRetirementGoalTenure or 3
        shortTermRetirementGoalTenureUnengaged = adminConfig.portfolioConfig.shortTermRetirementGoalTenureUnengaged or 5
        useFTPortfolios = adminConfig.portfolioConfig.usingFtPortfolio or False  # noqa: F841
        portfolioMapping = adminConfig.portfolioConfig.portfolioMapping
        max_age = adminConfig.goalPriority.generalSettings.maxAge or 120
        grid_freq = adminConfig.goalPriority.generalSettings.gridFrequency or None
        # TODO to fix in future
        # const isRiskOn = adminConfig.goalPriority.performance.riskOverlay || false;
        isRiskOn = False  # noqa: F841
        # TODO to fix in future
        ifNewRiskProfile = False
        ifNewInvestmentTenure = False
        ifNearTermVolatility = False
        ifGoalPriorityChanged = False
        ifNewGoal = False
        ifWantsToReallocate = False
        if "reallocate" not in userInput:
            userInput.reallocate = False
        if version == "4" and "isNearTermVolatility" not in userInput:
            userInput.isNearTermVolatility = False
        if version == "4" and "isNewRiskProfile" not in userInput:
            userInput.isNearTermVolatility = False

        if version == "2":
            userInput.isNewGoalPriority = True
            ifGoalPriorityChanged = True
        for triggers in adminConfig.allocationConfiguration.reallocationTriggers:
            if triggers.name == "newRiskProfile" and triggers.value is True:
                ifNewRiskProfile = True
            if triggers.name == "changesInvestmentTenure" and triggers.value is True:
                ifNewInvestmentTenure = True
            if triggers.name == "newGoal" and triggers.value is True:
                ifNewGoal = True
            if triggers.name == "riskIndicatorFlashes" and triggers.value is True:
                ifNearTermVolatility = True
            if triggers.name == "rePrioritizesGoal" and triggers.value is True:
                ifGoalPriorityChanged = True
            if triggers.name == "wantsToReallocate" and triggers.value is True:
                ifWantsToReallocate = True
        lossThresholdValueForPriorityNeed = list(
            filter(lambda e: e.name == "need", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWant = list(
            filter(lambda e: e.name == "want", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWish = list(
            filter(lambda e: e.name == "wish", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        levelsOfGoalPriorityNeed = list(filter(lambda e: e.name == "need", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWant = list(filter(lambda e: e.name == "want", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWish = list(filter(lambda e: e.name == "wish", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.probabilityLevels)
        )[0]
        realistic_goal_prob = adminConfig.goalPriority.generalSettings.unrealisticProbability
        # TODO Fix in future
        # For now always select risk on portfolios
        if not portfolios or (not portfolios[1]):
            ValidationError.messages = "Default risk on portfolios not found."
            raise ValidationError
        # change logic to use portfolios rather than user input
        usedPortfolios = portfolios.portfoliosRiskOn
        maximumDecumulationPortMaxIndex = portfolios.maximumDecumulationPortMaxIndex
        maximumShortTermPortMaxIndex = portfolios.maximumShortTermPortMaxIndex
        maximumShortTermRetirementPortMaxIndex = portfolios.maximumShortTermRetirementPortMaxIndex
        # TODO: Fix in future
        configRiskType = "None"
        if userInput.riskProfile:
            sanitizedPortfolioMapping = dict((key.lower(), val) for key, val in portfolioMapping.items())
            riskProfileInLowerCase = userInput.riskProfile.lower()
            configRiskType = sanitizedPortfolioMapping.get(riskProfileInLowerCase)
        allowedProfiles = []
        if configRiskType == "VeryConservative":
            # allowedProfiles = ["VeryConservative"]
            allowedProfiles = ptf["veryConservativeLimits"]
        elif configRiskType == "Conservative":
            # allowedProfiles = ["VeryConservative", "Conservative"]
            allowedProfiles = ptf["conservativeLimits"]
        elif configRiskType == "ConservativelyModerate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate"]
            allowedProfiles = ptf["conservativelyModerateLimits"]
        elif configRiskType == "Moderate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate", "Moderate"]
            allowedProfiles = ptf["moderateLimits"]
        elif configRiskType == "ModeratelyAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            # ]
            allowedProfiles = ptf["moderatelyAggressivelLimits"]
        elif configRiskType == "Aggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            # ]
            allowedProfiles = ptf["aggressiveLimits"]
        elif configRiskType == "VeryAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            #     "VeryAggressive",
            # ]
            allowedProfiles = ptf["veryAggressiveLimits"]
        else:
            allowedProfiles = []
        # In case of required_data_available is False. Ignore risk based/check calc

        if required_data_available is False:
            portfolio_nos = range(1, len(usedPortfolios) + 1)
            expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, usedPortfolios))
            expected_risks = list(map(lambda e: e.risk / 100, usedPortfolios))
            asset_allocations = list(map(lambda e: e.assetAllocation, usedPortfolios))
            fees_adjuster = list(map(lambda e: e.feesAdjuster, usedPortfolios))
        elif userInput.useAgeBasedCap:
            portfolio_nos = range(1, len(portfolios.useAgeBasedCapPortfoliosRiskOn) + 1)
            expected_returns = list(
                map(lambda e: getattr(e, "portfolio_return") / 100, portfolios.useAgeBasedCapPortfoliosRiskOn)
            )
            expected_risks = list(map(lambda e: e.risk / 100, portfolios.useAgeBasedCapPortfoliosRiskOn))
            asset_allocations = list(map(lambda e: e.assetAllocation, portfolios.useAgeBasedCapPortfoliosRiskOn))
            fees_adjuster = list(map(lambda e: e.feesAdjuster, portfolios.useAgeBasedCapPortfoliosRiskOn))
        else:
            # expected_returns = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            # expected_risks = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            # asset_allocations = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            # fees_adjuster = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # fees_adjuster = list(map(lambda e: e.feesAdjuster, fees_adjuster))
            portfolio_nos = [
                [p.id for p in portfolios.useAgeBasedCapPortfoliosRiskOn].index(value.id) + 1
                for index, value in enumerate(usedPortfolios)
                if (lambda e: allowedProfiles and e.id in allowedProfiles)(value)
            ]
            expected_returns = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            expected_risks = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            asset_allocations = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            fees_adjuster = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            fees_adjuster = list(map(lambda e: e.feesAdjuster, fees_adjuster))

        short_term_port_maxindex = None
        if maximumShortTermPortMaxIndex > 0:
            short_term_port_maxindex = maximumShortTermPortMaxIndex
        short_term_port_maxindex_retirement = None
        if maximumShortTermRetirementPortMaxIndex > 0:
            short_term_port_maxindex_retirement = maximumShortTermRetirementPortMaxIndex
        dec_port_maxindex = None
        if maximumDecumulationPortMaxIndex > 0:
            dec_port_maxindex = maximumDecumulationPortMaxIndex
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        port_dict = []
        for ret, risk, asset_allocation, fees_adjuster, portfolio_no in zip(
            expected_returns, expected_risks, asset_allocations, fees_adjuster, portfolio_nos
        ):
            port_data = {
                "mu": ret,
                "sigma": risk,
                "equity": asset_allocation["equity"],
                "bond": asset_allocation["bond"],
                "money_market": asset_allocation["money_market"],
                "id": portfolio_no,
            }
            if adjust_fees and adjust_fees.lower() == "variable":
                port_data.update({"fees_adjuster": fees_adjuster})
            elif adjust_fees and adjust_fees.lower() == "common":
                port_data.update({"fees_adjuster": adminConfig.goalPriority.generalSettings.annualInBPS})
            port_dict.append(port_data)
        goal_amt = userInput.goalAmount
        downside_alternate_max_goal = False
        goal_priority = False
        if adminConfig.goalPriority.generalSettings.downsideProtection == "Maximize Goal Probability":
            downside_alternate_max_goal = True

        if downside_alternate_max_goal is True:
            goal_priority = True
        loss_amt = None
        if userInput.lossThreshold is not None:
            loss_amt = userInput.lossThreshold
        exec_change = False
        if version != "4" and type(userInput.isNewRTQ) in [bool] and userInput.isNewRTQ and ifNewRiskProfile:
            exec_change = True
        if (
            version == "4"
            and type(userInput.isNewRiskProfile) in [bool]
            and userInput.isNewRiskProfile
            and ifNewRiskProfile
        ):
            exec_change = True
        if (
            type(userInput.isNewInvestmentTenure) in [bool]
            and userInput.isNewInvestmentTenure
            and ifNewInvestmentTenure
        ):
            exec_change = True
        if type(userInput.isNearTermVolatility) in [bool] and userInput.isNearTermVolatility and ifNearTermVolatility:
            exec_change = True
        if type(userInput.isNewGoalPriority) in [bool] and userInput.isNewGoalPriority and ifGoalPriorityChanged:
            exec_change = True
        if version == "4" and type(userInput.isNewGoal) in [bool] and userInput.isNewGoal and ifNewGoal:
            exec_change = True
        if type(userInput.reallocate) in [bool] and userInput.reallocate and ifWantsToReallocate:
            exec_change = True
        if curr_date in realloc_schedules:
            exec_change = True
        LT_Factor = {
            "Acc_Need": lossThresholdValueForPriorityNeed.accumulation,
            "Acc_Want": lossThresholdValueForPriorityWant.accumulation,
            "Acc_Wish": lossThresholdValueForPriorityWish.accumulation,
            "Acc_Dream": lossThresholdValueForPriorityDream.accumulation,
            "Dec_Need": lossThresholdValueForPriorityNeed.decumulation,
            "Dec_Want": lossThresholdValueForPriorityWant.decumulation,
            "Dec_Wish": lossThresholdValueForPriorityWish.decumulation,
            "Dec_Dream": lossThresholdValueForPriorityDream.decumulation,
        }
        goal_priority_prob_list = {
            "Need": levelsOfGoalPriorityNeed.value,
            "Want": levelsOfGoalPriorityWant.value,
            "Wish": levelsOfGoalPriorityWish.value,
            "Dream": levelsOfGoalPriorityDream.value,
        }
        goal_priority_prob = None
        if userInput.goalPriority == "Need":
            goal_priority_prob = levelsOfGoalPriorityNeed.value
        elif userInput.goalPriority == "Want":
            goal_priority_prob = levelsOfGoalPriorityWant.value
        elif userInput.goalPriority == "Wish":
            goal_priority_prob = levelsOfGoalPriorityWish.value
        elif userInput.goalPriority == "Dream":
            goal_priority_prob = levelsOfGoalPriorityDream.value
        get_path = userInput.getPath
        sigma_thd = adminConfig.goalPriority.performance.sigma
        nodes_per_sd = adminConfig.goalPriority.performance.nodesPerSd
        infln = adminConfig.goalPriority.generalSettings.inflation
        inf_measure = None
        if adminConfig.goalPriority.generalSettings.inflationMeasureForInfusions == "NOMINAL":
            inf_measure = "nominal"
        else:
            inf_measure = "real"
        irr_thresh = adminConfig.goalPriority.performance.irrForRangeAdjustment
        safeguard = adminConfig.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear
        safeguard_min = adminConfig.goalPriority.generalSettings.minPortfoliosForLastYear
        swing_constraint = adminConfig.goalPriority.generalSettings.swingConstraint
        swing = adminConfig.goalPriority.generalSettings.swingConstraintNumber
        downside_protect = adminConfig.goalPriority.lossThreshold
        protect_thd = adminConfig.goalPriority.lossThresholdProbability
        long_tenure_thresh = adminConfig.goalPriority.performance.longTenureThreshold or 30
        irr_perf_thd = adminConfig.goalPriority.performance.irrPerformanceThreshold or 0.0339
        alt_nodes_per_sd = adminConfig.goalPriority.performance.altNodesPerSd or 4
        alt_sigma_thd = adminConfig.goalPriority.performance.alternativeSigma or 4
        topup_recommendation = adminConfig.goalPriority.generalSettings.recommendTopUpInfusion
        tenure_recommendation = adminConfig.goalPriority.generalSettings.recommendTenure
        recommend_escalated_goal = adminConfig.goalPriority.generalSettings.recommendEscalatedGoal
        back_pass_only = adminConfig.goalPriority.generalSettings.backPassOnly
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        pdict = []
        for i in port_dict:
            ptdict = {}
            for j in i:
                ptdict[j] = round(i[j], 4) if i[j] is not None else i[j]
            pdict.append(ptdict)

        wealth_path_probs = []
        if adminConfig.goalPriority.generalSettings.additionalWealthPaths == "Yes":
            if userInput.wealthPathProbabilities is None:
                wealth_path_probs.append(adminConfig.goalPriority.generalSettings.pessimisticPathProbability)
                wealth_path_probs.append(adminConfig.goalPriority.generalSettings.optimisticPathProbability)
            else:
                wealth_path_probs = userInput.wealthPathProbabilities
        if adminConfig.goalPriority.probabilityThresholds:
            derisking_prob_thresh = {
                "min_prob1": adminConfig.goalPriority.probabilityThresholds[0].labelValue,
                "max_prob1": adminConfig.goalPriority.probabilityThresholds[0].value,
                "threshold1": adminConfig.goalPriority.probabilityThresholds[0].val,
                "min_prob2": adminConfig.goalPriority.probabilityThresholds[1].labelValue,
                "max_prob2": adminConfig.goalPriority.probabilityThresholds[1].value,
                "threshold2": adminConfig.goalPriority.probabilityThresholds[1].val,
                "min_prob3": adminConfig.goalPriority.probabilityThresholds[2].labelValue,
                "max_prob3": adminConfig.goalPriority.probabilityThresholds[2].value,
                "threshold3": adminConfig.goalPriority.probabilityThresholds[2].val,
            }
        else:
            derisking_prob_thresh = {
                "min_prob1": 0.0,
                "max_prob1": 0.9,
                "threshold1": 0.00075,
                "min_prob2": 0.90,
                "max_prob2": 1.00,
                "threshold2": 0.0015,
                "min_prob3": 0.65,
                "max_prob3": 0.90,
                "threshold3": 0.00075,
            }

        newPipePayload = {
            "user_profile": {
                "engaged_participant": engaged_participant,
                "goal_amt": goal_amt,
                "init_inv": init_inv,
                "infusions": infusions,
                "start_date": start_date,
                "end_date": end_date,
                "curr_date": curr_date,
                "curr_wealth": curr_wealth,
                "curr_port_id": curr_port_id,
                "loss_amt": loss_amt,
                "rebalancing": rebalancing,
                "infusion_type": infusion_type,
                "scenario_type": scenario_type,
                "priority": userInput.goalPriority,
                "bequest_priority": userInput.bequestPriority,
                "consider_mortality": consider_mortality,
                "current_age": current_age,
                "retirement_age": retirement_age,
                "risk_override": risk_override,
                "calibrate_recommendations": calibrate_recommendations,
                "required_data_available": required_data_available,
                "is_new_goal_priority": userInput.isNewGoalPriority,
                "is_new_investment_tenure": userInput.isNewInvestmentTenure,
                "reallocate": userInput.reallocate,
                "is_near_term_volatality": userInput.isNearTermVolatility,
                "wealth_path_probs": wealth_path_probs if wealth_path_probs else None,
                "participant_id": userInput.participantID,
                "plan_ID": userInput.planID,
                "source_ID": userInput.sourceID,
                "last_realloc_prob": userInput.lastReallocationProbability,
                "use_age_based_cap": userInput.useAgeBasedCap or False,
                "inflation": userInput.inflation,
                "stepup_date": userInput.stepupDate if "stepupDate" in userInput else None,
            },
            "pipe_config": {
                "version": int(version),
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                # "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                "realloc_schedules": realloc_schedules,
                "exec_change": exec_change,
                "swing_constraint": swing_constraint,
                "swing": swing,
                "safeguard": safeguard,
                "downside_protect": downside_protect,
                "protect_thd": protect_thd,
                "goal_priority": goal_priority,
                "downside_alternate_max_goal": downside_alternate_max_goal,
                "get_path": get_path,
                "realistic_goal_prob": realistic_goal_prob,
                "goal_priority_prob": goal_priority_prob,
                # "loss_priority_prob": loss_priority_prob,
                "goal_priority_prob_list": goal_priority_prob_list,
                "infln": infln,
                "sigma_thd": sigma_thd,
                "nodes_per_sd": nodes_per_sd,
                "inf_measure": inf_measure,
                "irr_thresh": irr_thresh,
                "safeguard_min": safeguard_min,
                "LT_Factor": LT_Factor,
                "long_tenure_thresh": long_tenure_thresh,
                "irr_perf_thd": irr_perf_thd,
                "alt_nodes_per_sd": alt_nodes_per_sd,
                "alt_sigma_thd": alt_sigma_thd,
                "topup_recommendation": topup_recommendation,
                "tenure_recommendation": tenure_recommendation,
                "recommend_escalated_goal": recommend_escalated_goal,
                "back_pass_only": back_pass_only,
                "short_term_tenure": shortTermGoalTenure,
                "short_term_port_maxindex": short_term_port_maxindex,
                "short_term_tenure_retirement": shortTermRetirementGoalTenure,
                "short_term_tenure_retirement_unengaged": shortTermRetirementGoalTenureUnengaged,
                "short_term_port_maxindex_retirement": short_term_port_maxindex_retirement,
                "dec_port_maxindex": dec_port_maxindex,
                "max_age": max_age,
                "grid_freq": grid_freq,
                "adjust_fees": adjust_fees,
                "derisking_prob_thresh": derisking_prob_thresh,
            },
            "port_dict": pdict,
            "pmort_data": pmort_data,
            "age_based_glide_path": age_based_glide_path,
        }
        newPipePayload = DictDefault(newPipePayload)
        if userInput.useAgeBasedCap is True:
            newPipePayload["age_based_risk_mapper"] = actuarialData.ageBasedEquityCap

        if version == "4":
            newPipePayload["user_profile"]["is_new_goal"] = userInput.isNewGoal
            newPipePayload["user_profile"]["is_new_risk_profile"] = userInput.isNewRiskProfile
            newPipePayload["user_profile"]["last_reallocation_date"] = userInput.lastReallocationDate
        if version == "3":
            newPipePayload["user_profile"]["is_new_goal"] = None
            newPipePayload["user_profile"]["is_new_risk_profile"] = userInput.isNewRTQ

        if version == "3" or version == "4":
            if required_data_available is False:
                newPipePayload.user_profile.debug = userInput.debug
            else:
                newPipePayload.user_profile.debug = userInput.debug or False
            newPipePayload.user_profile.cashflow_date = None
            if required_data_available is False or userInput.cashflowDate:
                newPipePayload.user_profile.cashflow_date = userInput.cashflowDate

            if not safeguard:
                del newPipePayload.pipe_config["safeguard_min"]
        if version >= "5":
            newPipePayload.pipe_config.long_tenure_thresh = long_tenure_thresh
            newPipePayload.pipe_config.irr_performance_thresh = irr_perf_thd
            newPipePayload.pipe_config.alt_nodes_per_sd = alt_nodes_per_sd
        return {"error": None, "data": newPipePayload}
    except GoeException as e:
        if request:
            L = request.state.vars["L"]
            L.error(e)
        raise e
    except Exception as e:
        if request:
            L = request.state.vars["L"]
            L.error(e)
        return {"error": str(e), "data": None}


def generate_agg_retirement_investments(investment):
    asset_held_away = []
    if investment.assetsHeldAway:
        for i in investment.assetsHeldAway:
            asset_held_away.append(
                {
                    "accountId": i.accountId,
                    "accountOwnership": i.accountOwnership,
                    "accountType": i.accountType,
                    "assetCategory": i.assetCategory,
                    "assetValue": i.assetValue,
                }
            )
    assets_under_management = []
    for j in investment.assetsUnderManagement:
        assets_under_management.append(
            {
                "accountId": j.accountId,
                "GOEAUM": j.GOEAUM,
                "accountOwnership": j.accountOwnership,
                "accountType": j.accountType,
                "advisorAUM": j.advisorAUM,
                "assetCategory": j.assetCategory,
                "assetValue": j.assetValue,
                "model": j.model,
            }
        )
    return {
        "asset_held_away": asset_held_away or investment.assetsHeldAway,
        "assets_under_management": assets_under_management,
    }


def generateTranslatorPayload(
    userInput, adminConfig, portfolios, glide_path_data, portfolio_mapping_data, goe_tables, ptf
):
    try:
        goe_tables = DictDefault(goe_tables)
        # * eslint-disable camelcase */
        pgl = prepare_generate_payload("runAggRetirementAccounts-H", userInput, adminConfig, portfolios, "", ptf=ptf)
        pgl = DictDefault(pgl)
        glide_path_data = DictDefault(glide_path_data)
        age_based_glide_path = glide_path_data.ageBasedGlidePath if glide_path_data.ageBasedGlidePath else None
        # curr_date = userInput.currDate or datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y")

        # reallocationDatesByFrequency = adminConfig.allocationConfiguration.reallocationDatesByFrequency or {}
        model_mapping = None
        if adminConfig.goalPriority.generalSettings.aggregatedRetirementAccounts is True:
            portfolio_mapping_data = DictDefault(portfolio_mapping_data)
            model_mapping = portfolio_mapping_data.PortfolioMapping if portfolio_mapping_data.PortfolioMapping else None
        # reallocationDates = reallocationDatesByFrequency["yearly"]
        # realloc_schedules = []
        # for dt in reallocationDates:
        #     t = datetime.datetime.strptime(dt, "%a %b %d %Y")
        #     realloc_schedules.append(
        #         datetime.datetime.strftime(datetime.datetime(int(curr_date.split("-")[2]), t.month, t.day), "%d-%m-%Y")
        #     )

        shortTermGoalTenure = adminConfig.portfolioConfig.shortTermGoalTenure or 3
        shortTermRetirementGoalTenure = adminConfig.portfolioConfig.shortTermRetirementGoalTenure or 3
        shortTermRetirementGoalTenureUnengaged = adminConfig.portfolioConfig.shortTermRetirementGoalTenureUnengaged or 5

        max_age = adminConfig.goalPriority.generalSettings.maxAge or 120
        grid_freq = adminConfig.goalPriority.generalSettings.gridFrequency or None

        # exec_change = False
        # get_path = True  # userInput.getPath
        sigma_thd = adminConfig.goalPriority.performance.sigma
        nodes_per_sd = adminConfig.goalPriority.performance.nodesPerSd
        infln = adminConfig.goalPriority.generalSettings.inflation
        inf_measure = None
        if adminConfig.goalPriority.generalSettings.inflationMeasureForInfusions == "NOMINAL":
            inf_measure = "nominal"
        else:
            inf_measure = "real"
        irr_thresh = adminConfig.goalPriority.performance.irrForRangeAdjustment
        safeguard = adminConfig.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear
        safeguard_min = adminConfig.goalPriority.generalSettings.minPortfoliosForLastYear
        swing_constraint = adminConfig.goalPriority.generalSettings.swingConstraint
        swing = adminConfig.goalPriority.generalSettings.swingConstraintNumber
        downside_protect = adminConfig.goalPriority.lossThreshold
        protect_thd = adminConfig.goalPriority.lossThresholdProbability
        long_tenure_thresh = adminConfig.goalPriority.performance.longTenureThreshold or 30
        irr_perf_thd = adminConfig.goalPriority.performance.irrPerformanceThreshold or 0.0339
        alt_nodes_per_sd = adminConfig.goalPriority.performance.altNodesPerSd or 4
        alt_sigma_thd = adminConfig.goalPriority.performance.alternativeSigma or 4
        topup_recommendation = adminConfig.goalPriority.generalSettings.recommendTopUpInfusion
        tenure_recommendation = adminConfig.goalPriority.generalSettings.recommendTenure
        recommend_escalated_goal = adminConfig.goalPriority.generalSettings.recommendEscalatedGoal
        back_pass_only = adminConfig.goalPriority.generalSettings.backPassOnly
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees

        current_investment = generate_agg_retirement_investments(userInput.currentInvestment)
        initial_investment = generate_agg_retirement_investments(userInput.initialInvestment)
        current_retirement_ahacomposition = None
        if userInput.currentRetirementAHAComposition is not None:
            current_retirement_ahacomposition = {
                "equity": userInput.currentRetirementAHAComposition.equity,
                "debt": userInput.currentRetirementAHAComposition.debt,
                "other": userInput.currentRetirementAHAComposition.other,
            }
        if adminConfig.goalPriority.probabilityThresholds:
            derisking_prob_thresh = {
                "min_prob1": adminConfig.goalPriority.probabilityThresholds[0].labelValue,
                "max_prob1": adminConfig.goalPriority.probabilityThresholds[0].value,
                "threshold1": adminConfig.goalPriority.probabilityThresholds[0].val,
                "min_prob2": adminConfig.goalPriority.probabilityThresholds[1].labelValue,
                "max_prob2": adminConfig.goalPriority.probabilityThresholds[1].value,
                "threshold2": adminConfig.goalPriority.probabilityThresholds[1].val,
                "min_prob3": adminConfig.goalPriority.probabilityThresholds[2].labelValue,
                "max_prob3": adminConfig.goalPriority.probabilityThresholds[2].value,
                "threshold3": adminConfig.goalPriority.probabilityThresholds[2].val,
            }
        else:
            derisking_prob_thresh = {
                "min_prob1": 0.0,
                "max_prob1": 0.9,
                "threshold1": 0.00075,
                "min_prob2": 0.90,
                "max_prob2": 1.00,
                "threshold2": 0.0015,
                "min_prob3": 0.65,
                "max_prob3": 0.90,
                "threshold3": 0.00075,
            }

        newPipePayload = {
            "user_profile": {
                "clientId": userInput.clientId,
                "last_realloc_prob": userInput.lastReallocationProbability,
                "currDate": userInput.currDate,
                "currentInvestment": {
                    "assetsHeldAway": current_investment["asset_held_away"],
                    "assetsUnderManagement": current_investment["assets_under_management"],
                },
                "currentPortfolioId": userInput.currentPortfolioId,
                "currentPortfolioRiskScore": userInput.currentPortfolioRiskScore,
                "currentRetirementGoal": userInput.currentRetirementGoal,
                "currentRetirementAHAComposition": current_retirement_ahacomposition,
                "endDate": userInput.endDate,
                "householdProfile": {
                    "clientProfile": {
                        "currentAge": userInput.householdProfile.clientProfile.currentAge,
                        "retirementAge": userInput.householdProfile.clientProfile.retirementAge,
                        "salary": userInput.householdProfile.clientProfile.salary,
                        "socialSecurityAge": userInput.householdProfile.clientProfile.socialSecurityAge,
                        "socialSecurityIncome": userInput.householdProfile.clientProfile.socialSecurityIncome,
                    },
                    "comfortZone": userInput.householdProfile.comfortZone,
                    "riskScore": userInput.householdProfile.riskScore,
                },
                "initialInvestment": {
                    "assetsHeldAway": initial_investment["asset_held_away"],
                    "assetsUnderManagement": initial_investment["assets_under_management"],
                },
                "reallocate": userInput.reallocate,
                "requiredDataAvailable": userInput.requiredDataAvailable,
                "riskProfile": userInput.riskProfile,
                "startDate": userInput.startDate,
                "last_reallocation_date": userInput.lastReallocationDate,
                "use_age_based_cap": userInput.useAgeBasedCap or False,
            },
            "pipe_config": {
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                # "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                "realloc_schedules": pgl.realloc_schedules,
                "exec_change": False,
                "swing_constraint": swing_constraint,
                "swing": swing,
                "safeguard": safeguard,
                "downside_protect": downside_protect,
                "protect_thd": protect_thd,
                "goal_priority": pgl.goal_priority,
                "downside_alternate_max_goal": pgl.downside_alternate_max_goal,
                "get_path": True,
                "realistic_goal_prob": pgl.realistic_goal_prob,
                "goal_priority_prob": pgl.goal_priority_prob,
                # "loss_priority_prob": loss_priority_prob,
                "goal_priority_prob_list": pgl.goal_priority_prob_list,
                "infln": infln,
                "sigma_thd": sigma_thd,
                "nodes_per_sd": nodes_per_sd,
                "inf_measure": inf_measure,
                "irr_thresh": irr_thresh,
                "safeguard_min": safeguard_min,
                "LT_Factor": pgl.LT_Factor,
                "long_tenure_thresh": long_tenure_thresh,
                "irr_perf_thd": irr_perf_thd,
                "alt_nodes_per_sd": alt_nodes_per_sd,
                "alt_sigma_thd": alt_sigma_thd,
                "topup_recommendation": topup_recommendation,
                "tenure_recommendation": tenure_recommendation,
                "recommend_escalated_goal": recommend_escalated_goal,
                "back_pass_only": back_pass_only,
                "short_term_tenure": shortTermGoalTenure,
                "short_term_port_maxindex": pgl.short_term_port_maxindex,
                "short_term_tenure_retirement": shortTermRetirementGoalTenure,
                "short_term_tenure_retirement_unengaged": shortTermRetirementGoalTenureUnengaged,
                "short_term_port_maxindex_retirement": pgl.short_term_port_maxindex_retirement,
                "dec_port_maxindex": pgl.dec_port_maxindex,
                "max_age": max_age,
                "grid_freq": grid_freq,
                "adjust_fees": adjust_fees,
                "contrib_rate": pgl.contrib_rate,
                "fixed_benefits": pgl.fixed_benefits,
                "calc_goals": pgl.calc_goals,
                "derisking_prob_thresh": derisking_prob_thresh,
            },
            "port_dict": pgl.pdict,
            "age_based_glide_path": age_based_glide_path,
            "model_mapping": model_mapping,
        }
        if userInput.householdProfile.spouseProfile:
            newPipePayload["user_profile"]["householdProfile"]["spouseProfile"] = {
                "currentAge": userInput.householdProfile.spouseProfile.currentAge,
                "retirementAge": userInput.householdProfile.spouseProfile.retirementAge,
                "salary": userInput.householdProfile.spouseProfile.salary,
                "socialSecurityAge": userInput.householdProfile.spouseProfile.socialSecurityAge,
                "socialSecurityIncome": userInput.householdProfile.spouseProfile.socialSecurityIncome,
            }
        else:
            if userInput.householdProfile:
                newPipePayload["user_profile"]["householdProfile"][
                    "spouseProfile"
                ] = userInput.householdProfile.spouseProfile
        if userInput.useAgeBasedCap is True:
            newPipePayload["age_based_risk_mapper"] = goe_tables.ageBasedEquityCap

        newPipePayload = DictDefault(newPipePayload)

        return {"error": None, "data": newPipePayload}
    except Exception as e:
        L = request.vars["L"]
        L.error(e)
        L.error(traceback.format_exc())
        return {"error": str(e), "data": None}


def prepare_generate_payload(request_type, userInput, adminConfig, portfolios, version="4", ptf={}):
    curr_date = userInput.currDate or datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y")
    curr_port_id = userInput.currentPortfolioId
    if curr_port_id is not None and type(curr_port_id) in [float, int] and curr_port_id < 1:
        curr_port_id = None

    reallocationDatesByFrequency = adminConfig.allocationConfiguration.reallocationDatesByFrequency or {}
    contrib_rate = None
    fixed_benefits = None
    calc_goals = None
    if adminConfig.goalPriority.generalSettings.aggregatedRetirementAccounts is True:
        contrib_rate = adminConfig.goalPriority.generalSettings.contributionRate
        fixed_benefits = adminConfig.goalPriority.generalSettings.fixedBenefits
        calc_goals = adminConfig.goalPriority.generalSettings.calculateGoals
    reallocationDates = reallocationDatesByFrequency["yearly"]
    rebalancing = userInput.reallocationFreq
    if version == "4":
        rebalancing = userInput.reallocationFreq
        # scenario_type = userInput.scenarioType
        # infusion_type = userInput.infusionType
    if request_type != "runAggRetirementAccounts-H":
        reallocationDates = []
        if rebalancing == "yearly":
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
        elif rebalancing == "half-yearly":
            reallocationDates = reallocationDatesByFrequency["halfyearly"]
            rebalancing = "half-yearly_"
        elif rebalancing == "quarterly":
            reallocationDates = reallocationDatesByFrequency["quarterly"]
            rebalancing = "quarterly_"
        else:
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
    realloc_schedules = []
    for dt in reallocationDates:
        t = datetime.datetime.strptime(dt, "%a %b %d %Y")
        realloc_schedules.append(
            datetime.datetime.strftime(datetime.datetime(int(curr_date.split("-")[2]), t.month, t.day), "%d-%m-%Y")
        )

    portfolioMapping = adminConfig.portfolioConfig.portfolioMapping
    lossThresholdValueForPriorityNeed = list(
        filter(lambda e: e.name == "need", adminConfig.goalPriority.lossthresholdValues)
    )[0]
    lossThresholdValueForPriorityWant = list(
        filter(lambda e: e.name == "want", adminConfig.goalPriority.lossthresholdValues)
    )[0]
    lossThresholdValueForPriorityWish = list(
        filter(lambda e: e.name == "wish", adminConfig.goalPriority.lossthresholdValues)
    )[0]
    lossThresholdValueForPriorityDream = list(
        filter(lambda e: e.name == "dream", adminConfig.goalPriority.lossthresholdValues)
    )[0]
    levelsOfGoalPriorityNeed = list(filter(lambda e: e.name == "need", adminConfig.goalPriority.probabilityLevels))[0]
    levelsOfGoalPriorityWant = list(filter(lambda e: e.name == "want", adminConfig.goalPriority.probabilityLevels))[0]
    levelsOfGoalPriorityWish = list(filter(lambda e: e.name == "wish", adminConfig.goalPriority.probabilityLevels))[0]
    levelsOfGoalPriorityDream = list(filter(lambda e: e.name == "dream", adminConfig.goalPriority.probabilityLevels))[0]
    realistic_goal_prob = adminConfig.goalPriority.generalSettings.unrealisticProbability
    if not portfolios or (not portfolios[1]):
        ValidationError.messages = "Default risk on portfolios not found."
        raise ValidationError
    # change logic to use portfolios rather than user input
    usedPortfolios = portfolios.portfoliosRiskOn
    maximumDecumulationPortMaxIndex = portfolios.maximumDecumulationPortMaxIndex
    maximumShortTermPortMaxIndex = portfolios.maximumShortTermPortMaxIndex
    maximumShortTermRetirementPortMaxIndex = portfolios.maximumShortTermRetirementPortMaxIndex

    configRiskType = "None"
    if userInput.riskProfile:
        sanitizedPortfolioMapping = dict((key.lower(), val) for key, val in portfolioMapping.items())
        riskProfileInLowerCase = userInput.riskProfile.lower()
        configRiskType = sanitizedPortfolioMapping.get(riskProfileInLowerCase)
    allowedProfiles = ["None"]
    if configRiskType:
        allowedProfiles = [configRiskType]

        allowedProfiles = []
        if configRiskType == "VeryConservative":
            # allowedProfiles = ["VeryConservative"]
            allowedProfiles = ptf["veryConservativeLimits"]
        elif configRiskType == "Conservative":
            # allowedProfiles = ["VeryConservative", "Conservative"]
            allowedProfiles = ptf["conservativeLimits"]
        elif configRiskType == "ConservativelyModerate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate"]
            allowedProfiles = ptf["conservativelyModerateLimits"]
        elif configRiskType == "Moderate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate", "Moderate"]
            allowedProfiles = ptf["moderateLimits"]
        elif configRiskType == "ModeratelyAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            # ]
            allowedProfiles = ptf["moderatelyAggressivelLimits"]
        elif configRiskType == "Aggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            # ]
            allowedProfiles = ptf["aggressiveLimits"]
        elif configRiskType == "VeryAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            #     "VeryAggressive",
            # ]
            allowedProfiles = ptf["veryAggressiveLimits"]
        else:
            allowedProfiles = []
    # In case of required_data_available is False. Ignore risk based/check calc
    if userInput.useAgeBasedCap or (
        request_type == "goeforsimulation" and adminConfig.goalPriority.generalSettings.simulationType == "GlidePath"
    ):
        portfolio_nos = range(1, len(portfolios.useAgeBasedCapPortfoliosRiskOn) + 1)
        expected_returns = list(
            map(lambda e: getattr(e, "portfolio_return") / 100, portfolios.useAgeBasedCapPortfoliosRiskOn)
        )
    else:
        portfolio_nos = [
            [p.id for p in portfolios.useAgeBasedCapPortfoliosRiskOn].index(value.id) + 1
            for index, value in enumerate(usedPortfolios)
            if (lambda e: allowedProfiles and e.id in allowedProfiles)(value)
        ]
        expected_returns = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
        expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
    if userInput.useAgeBasedCap or (
        request_type == "goeforsimulation" and adminConfig.goalPriority.generalSettings.simulationType == "GlidePath"
    ):
        expected_risks = list(map(lambda e: e.risk / 100, portfolios.useAgeBasedCapPortfoliosRiskOn))
    else:
        expected_risks = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
        expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
    if userInput.useAgeBasedCap or (
        request_type == "goeforsimulation" and adminConfig.goalPriority.generalSettings.simulationType == "GlidePath"
    ):
        asset_allocations = list(map(lambda e: e.assetAllocation, portfolios.useAgeBasedCapPortfoliosRiskOn))
    else:
        asset_allocations = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
        asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
    if userInput.useAgeBasedCap or (
        request_type == "goeforsimulation" and adminConfig.goalPriority.generalSettings.simulationType == "GlidePath"
    ):
        fees_adjuster = list(map(lambda e: e.feesAdjuster, portfolios.useAgeBasedCapPortfoliosRiskOn))
    else:
        fees_adjuster = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
        fees_adjuster = list(map(lambda e: e.feesAdjuster, fees_adjuster))
    adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
    port_dict = []
    for ret, risk, asset_allocation, fees_adjuster, portfolio_no in zip(
        expected_returns, expected_risks, asset_allocations, fees_adjuster, portfolio_nos
    ):
        port_data = {
            "mu": ret,
            "sigma": risk,
            "equity": asset_allocation["equity"],
            "bond": asset_allocation["bond"],
            "money_market": asset_allocation["money_market"],
            "id": portfolio_no,
        }
        if adjust_fees and adjust_fees.lower() == "variable":
            port_data.update({"fees_adjuster": fees_adjuster})
        elif adjust_fees and adjust_fees.lower() == "common":
            port_data.update({"fees_adjuster": adminConfig.goalPriority.generalSettings.annualInBPS})
        port_dict.append(port_data)
    short_term_port_maxindex = None
    if maximumShortTermPortMaxIndex > 0:
        short_term_port_maxindex = maximumShortTermPortMaxIndex
    short_term_port_maxindex_retirement = None
    if maximumShortTermRetirementPortMaxIndex > 0:
        short_term_port_maxindex_retirement = maximumShortTermRetirementPortMaxIndex
    dec_port_maxindex = None
    if maximumDecumulationPortMaxIndex > 0:
        dec_port_maxindex = maximumDecumulationPortMaxIndex
    downside_alternate_max_goal = False
    goal_priority = False
    if adminConfig.goalPriority.generalSettings.downsideProtection == "Maximize Goal Probability":
        downside_alternate_max_goal = True
    if downside_alternate_max_goal is True:
        goal_priority = True
    ifNewRiskProfile = False
    ifNewInvestmentTenure = False
    ifNearTermVolatility = False
    ifGoalPriorityChanged = False
    ifNewGoal = False
    ifWantsToReallocate = False
    if "reallocate" not in userInput:
        userInput.reallocate = False
    if "isNearTermVolatility" not in userInput:
        userInput.isNearTermVolatility = False
    if "isNewRiskProfile" not in userInput:
        userInput.isNearTermVolatility = False
    for triggers in adminConfig.allocationConfiguration.reallocationTriggers:
        if triggers.name == "newRiskProfile" and triggers.value is True:
            ifNewRiskProfile = True
        if triggers.name == "changesInvestmentTenure" and triggers.value is True:
            ifNewInvestmentTenure = True
        if triggers.name == "newGoal" and triggers.value is True:
            ifNewGoal = True
        if triggers.name == "riskIndicatorFlashes" and triggers.value is True:
            ifNearTermVolatility = True
        if triggers.name == "rePrioritizesGoal" and triggers.value is True:
            ifGoalPriorityChanged = True
        if triggers.name == "wantsToReallocate" and triggers.value is True:
            ifWantsToReallocate = True
    exec_change = False
    if type(userInput.isNewRiskProfile) in [bool] and userInput.isNewRiskProfile and ifNewRiskProfile:
        exec_change = True
    if type(userInput.isNewInvestmentTenure) in [bool] and userInput.isNewInvestmentTenure and ifNewInvestmentTenure:
        exec_change = True
    if type(userInput.isNearTermVolatility) in [bool] and userInput.isNearTermVolatility and ifNearTermVolatility:
        exec_change = True
    if type(userInput.isNewGoalPriority) in [bool] and userInput.isNewGoalPriority and ifGoalPriorityChanged:
        exec_change = True
    if type(userInput.isNewGoal) in [bool] and userInput.isNewGoal and ifNewGoal:
        exec_change = True
    if type(userInput.reallocate) in [bool] and userInput.reallocate and ifWantsToReallocate:
        exec_change = True
    # Enable this by checking with Debashis.
    # exec_change = False
    if curr_date in realloc_schedules:
        exec_change = True
    LT_Factor = {
        "Acc_Need": lossThresholdValueForPriorityNeed.accumulation,
        "Acc_Want": lossThresholdValueForPriorityWant.accumulation,
        "Acc_Wish": lossThresholdValueForPriorityWish.accumulation,
        "Acc_Dream": lossThresholdValueForPriorityDream.accumulation,
        "Dec_Need": lossThresholdValueForPriorityNeed.decumulation,
        "Dec_Want": lossThresholdValueForPriorityWant.decumulation,
        "Dec_Wish": lossThresholdValueForPriorityWish.decumulation,
        "Dec_Dream": lossThresholdValueForPriorityDream.decumulation,
    }
    goal_priority_prob_list = {
        "Need": levelsOfGoalPriorityNeed.value,
        "Want": levelsOfGoalPriorityWant.value,
        "Wish": levelsOfGoalPriorityWish.value,
        "Dream": levelsOfGoalPriorityDream.value,
    }
    goal_priority_prob = None
    # if userInput.goalPriority == "Need":
    #     goal_priority_prob = levelsOfGoalPriorityNeed.value
    # elif userInput.goalPriority == "Want":
    #     goal_priority_prob = levelsOfGoalPriorityWant.value
    # elif userInput.goalPriority == "Wish":
    #     goal_priority_prob = levelsOfGoalPriorityWish.value
    # elif userInput.goalPriority == "Dream":
    #     goal_priority_prob = levelsOfGoalPriorityDream.
    if adminConfig.goalPriority.probabilityThresholds:
        derisking_prob_thresh = {
            "min_prob1": adminConfig.goalPriority.probabilityThresholds[0].labelValue,
            "max_prob1": adminConfig.goalPriority.probabilityThresholds[0].value,
            "threshold1": adminConfig.goalPriority.probabilityThresholds[0].val,
            "min_prob2": adminConfig.goalPriority.probabilityThresholds[1].labelValue,
            "max_prob2": adminConfig.goalPriority.probabilityThresholds[1].value,
            "threshold2": adminConfig.goalPriority.probabilityThresholds[1].val,
            "min_prob3": adminConfig.goalPriority.probabilityThresholds[2].labelValue,
            "max_prob3": adminConfig.goalPriority.probabilityThresholds[2].value,
            "threshold3": adminConfig.goalPriority.probabilityThresholds[2].val,
        }
    else:
        derisking_prob_thresh = {
            "min_prob1": 0.0,
            "max_prob1": 0.9,
            "threshold1": 0.00075,
            "min_prob2": 0.90,
            "max_prob2": 1.00,
            "threshold2": 0.0015,
            "min_prob3": 0.65,
            "max_prob3": 0.90,
            "threshold3": 0.00075,
        }

    get_path = True  # userInput.getPath
    inf_measure = None
    if adminConfig.goalPriority.generalSettings.inflationMeasureForInfusions == "NOMINAL":
        inf_measure = "nominal"
    else:
        inf_measure = "real"
    pdict = []
    for i in port_dict:
        ptdict = {}
        for j in i:
            ptdict[j] = round(i[j], 4) if i[j] is not None else i[j]
        pdict.append(ptdict)
    minimum_social_security_filing_age = None
    maximum_social_security_filing_age = None
    total_allowed_contribution = None
    total_allowed_catchup_contribution = None
    if adminConfig.goalPriority.generalSettings.socialSecurityFilingAge and (
        adminConfig.goalPriority.generalSettings.socialSecurityFilingAge.minimumSocialSecurityFilingAge is not None
        and adminConfig.goalPriority.generalSettings.socialSecurityFilingAge.minimumSocialSecurityFilingAge >= 0
    ):
        minimum_social_security_filing_age = int(
            adminConfig.goalPriority.generalSettings.socialSecurityFilingAge.minimumSocialSecurityFilingAge
        )
    if adminConfig.goalPriority.generalSettings.socialSecurityFilingAge and (
        adminConfig.goalPriority.generalSettings.socialSecurityFilingAge.maximumSocialSecurityFilingAge is not None
        and adminConfig.goalPriority.generalSettings.socialSecurityFilingAge.maximumSocialSecurityFilingAge >= 0
    ):
        maximum_social_security_filing_age = int(
            adminConfig.goalPriority.generalSettings.socialSecurityFilingAge.maximumSocialSecurityFilingAge
        )
    if (
        adminConfig.goalPriority.generalSettings.totalAllowedContribution is not None
        and adminConfig.goalPriority.generalSettings.totalAllowedContribution != ""
    ):
        total_allowed_contribution = int(adminConfig.goalPriority.generalSettings.totalAllowedContribution)
    if not adminConfig.goalPriority.generalSettings.totalAllowedContribution:
        total_allowed_contribution = 22500
    if (
        adminConfig.goalPriority.generalSettings.totalAllowedCatchupContribution is not None
        and adminConfig.goalPriority.generalSettings.totalAllowedCatchupContribution != ""
    ):
        total_allowed_catchup_contribution = int(
            adminConfig.goalPriority.generalSettings.totalAllowedCatchupContribution
        )
    if not adminConfig.goalPriority.generalSettings.totalAllowedCatchupContribution:
        total_allowed_catchup_contribution = 30000

    wealth_path_probs = []
    if adminConfig.goalPriority.generalSettings.additionalWealthPaths == "Yes":
        if userInput.wealthPathProbabilities is None:
            wealth_path_probs.append(adminConfig.goalPriority.generalSettings.pessimisticPathProbability)
            wealth_path_probs.append(adminConfig.goalPriority.generalSettings.optimisticPathProbability)
        else:
            wealth_path_probs = userInput.wealthPathProbabilities

    return {
        "curr_date": curr_date,
        "curr_port_id": curr_port_id,
        "irr_thresh": adminConfig.goalPriority.performance.irrForRangeAdjustment,
        "safeguard": adminConfig.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear,
        "safeguard_min": adminConfig.goalPriority.generalSettings.minPortfoliosForLastYear,
        "swing_constraint": adminConfig.goalPriority.generalSettings.swingConstraint,
        "swing": adminConfig.goalPriority.generalSettings.swingConstraintNumber,
        "downside_protect": adminConfig.goalPriority.lossThreshold,
        "protect_thd": adminConfig.goalPriority.lossThresholdProbability,
        "long_tenure_thresh": adminConfig.goalPriority.performance.longTenureThreshold or 30,
        "irr_perf_thd": adminConfig.goalPriority.performance.irrPerformanceThreshold or 0.0339,
        "alt_nodes_per_sd": adminConfig.goalPriority.performance.altNodesPerSd or 4,
        "alt_sigma_thd": adminConfig.goalPriority.performance.alternativeSigma or 4,
        "topup_recommendation": adminConfig.goalPriority.generalSettings.recommendTopUpInfusion,
        "tenure_recommendation": adminConfig.goalPriority.generalSettings.recommendTenure,
        "recommend_escalated_goal": adminConfig.goalPriority.generalSettings.recommendEscalatedGoal,
        "back_pass_only": adminConfig.goalPriority.generalSettings.backPassOnly,
        "adjust_fees": adminConfig.goalPriority.generalSettings.adjustFees,
        "inf_measure": inf_measure,
        "get_path": get_path,
        "sigma_thd": adminConfig.goalPriority.performance.sigma,
        "nodes_per_sd": adminConfig.goalPriority.performance.nodesPerSd,
        "infln": adminConfig.goalPriority.generalSettings.inflation,
        "goal_priority_prob": goal_priority_prob,
        "LT_Factor": LT_Factor,
        "goal_priority_prob_list": goal_priority_prob_list,
        "exec_change": exec_change,
        "goal_priority": goal_priority,
        "downside_alternate_max_goal": downside_alternate_max_goal,
        "pdict": pdict,
        "dec_port_maxindex": dec_port_maxindex,
        "short_term_port_maxindex": short_term_port_maxindex,
        "maximumShortTermPortMaxIndex": maximumShortTermPortMaxIndex,
        "short_term_port_maxindex_retirement": short_term_port_maxindex_retirement,
        "expected_risks": expected_risks,
        "asset_allocations": asset_allocations,
        "fees_adjuster": fees_adjuster,
        "max_age": adminConfig.goalPriority.generalSettings.maxAge or 120,
        "grid_freq": adminConfig.goalPriority.generalSettings.gridFrequency or None,
        "realistic_goal_prob": realistic_goal_prob,
        "shortTermGoalTenure": adminConfig.portfolioConfig.shortTermGoalTenure or 3,
        "shortTermRetirementGoalTenure": adminConfig.portfolioConfig.shortTermRetirementGoalTenure or 3,
        "shortTermRetirementGoalTenureUnengaged": adminConfig.portfolioConfig.shortTermRetirementGoalTenureUnengaged
        or 5,
        "contrib_rate": contrib_rate,
        "fixed_benefits": fixed_benefits,
        "calc_goals": calc_goals,
        "realloc_schedules": realloc_schedules,
        "ly_package_id": adminConfig.goalPriority.generalSettings.LYPackageID,
        "rebalancing": rebalancing,
        "derisking_prob_thresh": derisking_prob_thresh,
        "socialSecurityFilingAge": {
            "minimumSocialSecurityFilingAge": minimum_social_security_filing_age,
            "maximumSocialSecurityFilingAge": maximum_social_security_filing_age,
        },
        "totalAllowedContributions": total_allowed_contribution,
        "totalAllowedCatchupContribution": total_allowed_catchup_contribution,
        "wealth_path_probs": wealth_path_probs,
        "simulation_type": adminConfig.goalPriority.generalSettings.simulationType or "RiskProfile",
        "simulation_count": int(adminConfig.goalPriority.generalSettings.simulationCount)
        if adminConfig.goalPriority.generalSettings.simulationCount
        else 10000,
    }


def generateTaxLiabilityPayload(userInput, adminConfig, portfolios, goe_tables, ptf):
    try:
        pld = prepare_generate_payload("goefortaxes", userInput, adminConfig, portfolios, "", ptf)
        pld = DictDefault(pld)
        member_list = []
        for m in userInput.household.memberList:
            member_list.append(
                {
                    "memberType": m.memberType,
                    "memberID": m.memberID,
                    "DOB": m.DOB,
                    "currentAge": m.currentAge,
                    "retirementAge": m.retirementAge,
                    "currentSalary": m.currentSalary,
                    "socialSecurityStartAge": m.socialSecurityStartAge,
                    "TDABalanceForRMD": m.TDABalanceForRMD if "TDABalanceForRMD" in m else None,
                    "RMDUtilized": m.RMDUtilized if "RMDUtilized" in m else None,
                    "existingMonthlySocialSecurityAmount": m.existingMonthlySocialSecurityAmount,
                }
            )
        accounts_list = []
        for m in userInput.accounts:
            current_holdings_list = []
            for ch in m.currentHoldings:
                current_holdings_list.append(
                    {
                        "categoryName": ch.categoryName,
                        "categoryID": ch.categoryID,
                        "categoryPrice": ch.categoryPrice,
                        "quantity": ch.quantity,
                        "costBasis": ch.costBasis,
                    }
                )
            accounts_list.append(
                {
                    "accountID": m.accountID,
                    "taxabilityType": m.taxabilityType,
                    "accountType": m.accountType,
                    "memberIDs": m.memberIDs,
                    "currentBalance": m.currentBalance,
                    "cashflowDetails": {
                        "cashflowAmt": m.cashflowDetails.cashflowAmt,
                        "startDate": m.cashflowDetails.startDate,
                        "endDate": m.cashflowDetails.endDate,
                    },
                    "currentHoldings": current_holdings_list,
                }
            )
        goal_profile_list = []
        for m in userInput.goalProfileList:
            goal_profile_list.append(
                {
                    "goalId": m.goalId,
                    "goalAmt": m.goalAmt,
                    "scenarioType": m.scenarioType,
                    "startDate": m.startDate,
                    "endDate": m.endDate,
                    "priority": m.priority,
                    "bequest": m.bequest,
                    "goalPurpose": m.goalPurpose,
                }
            )
        newPipePayload = {
            "user_profile": {
                "currDate": pld.curr_date,
                "currentPortfolioId": pld.curr_port_id,
                "reallocate": userInput.reallocate,
                "riskProfile": userInput.riskProfile,
                "isNewRiskProfile": userInput.isNewRiskProfile,
                "isNewInvestmentTenure": userInput.isNewInvestmentTenure,
                "isNewGoal": userInput.isNewGoal,
                "isNewGoalPriority": userInput.isNewGoalPriority,
                "isNearTermVolatility": userInput.isNearTermVolatility,
                "getPath": userInput.getPath,
                "reallocationFreq": userInput.reallocationFreq,
                "lossThreshold": userInput.lossThreshold,
                "computeSocialSecurity": userInput.computeSocialSecurity or False,
                "useSocialSecurityForGoals": userInput.useSocialSecurityForGoals or False,
                "cashflowDate": userInput.cashflowDate,
                "infusionType": userInput.infusionType,
                "colaRate": userInput.colaRate,
                "taxRates": {
                    "LTCGPreRetirement": userInput.taxRates.LTCGPreRetirement if "taxRates" in userInput else None,
                    "ETRPreRetirement": userInput.taxRates.ETRPreRetirement if "taxRates" in userInput else None,
                    "LTCGPostRetirement": userInput.taxRates.LTCGPostRetirement if "taxRates" in userInput else None,
                    "ETRPostRetirement": userInput.taxRates.ETRPostRetirement if "taxRates" in userInput else None,
                },
                "household": {
                    "householdID": userInput.household.householdID,
                    "stateOfResidence": userInput.household.stateOfResidence,
                    "memberList": member_list,
                },
                "accounts": accounts_list,
                "goalProfileList": goal_profile_list,
                "debug": userInput.debug or False,
                "last_reallocation_date": userInput.lastReallocationDate,
                "use_age_based_cap": userInput.useAgeBasedCap or False,
            },
            "pipe_config": {
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                # "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                "realloc_schedules": pld.realloc_schedules,
                "exec_change": pld.exec_change,
                "swing_constraint": pld.swing_constraint,
                "swing": pld.swing,
                "safeguard": pld.safeguard,
                "downside_protect": pld.downside_protect,
                "protect_thd": pld.protect_thd,
                "goal_priority": pld.goal_priority,
                "downside_alternate_max_goal": pld.downside_alternate_max_goal,
                "get_path": pld.get_path,
                "realistic_goal_prob": pld.realistic_goal_prob,
                "goal_priority_prob": pld.goal_priority_prob,
                "goal_priority_prob_list": pld.goal_priority_prob_list,
                "infln": pld.infln,
                "sigma_thd": pld.sigma_thd,
                "nodes_per_sd": pld.nodes_per_sd,
                "inf_measure": pld.inf_measure,
                "irr_thresh": pld.irr_thresh,
                "safeguard_min": pld.safeguard_min,
                "LT_Factor": pld.LT_Factor,
                "long_tenure_thresh": pld.long_tenure_thresh,
                "irr_perf_thd": pld.irr_perf_thd,
                "alt_nodes_per_sd": pld.alt_nodes_per_sd,
                "alt_sigma_thd": pld.alt_sigma_thd,
                "topup_recommendation": pld.topup_recommendation,
                "tenure_recommendation": pld.tenure_recommendation,
                "recommend_escalated_goal": pld.recommend_escalated_goal,
                "back_pass_only": pld.back_pass_only,
                "short_term_tenure": pld.shortTermGoalTenure,
                "short_term_port_maxindex": pld.short_term_port_maxindex,
                "short_term_tenure_retirement": pld.shortTermRetirementGoalTenure,
                "short_term_tenure_retirement_unengaged": pld.shortTermRetirementGoalTenureUnengaged,
                "short_term_port_maxindex_retirement": pld.short_term_port_maxindex_retirement,
                "dec_port_maxindex": pld.dec_port_maxindex,
                "max_age": pld.max_age,
                "grid_freq": pld.grid_freq,
                "adjust_fees": pld.adjust_fees,
                "contrib_rate": pld.contrib_rate,
                "fixed_benefits": pld.fixed_benefits,
                "calc_goals": pld.calc_goals,
                "ly_package_id": pld.ly_package_id,
                "derisking_prob_thresh": pld.derisking_prob_thresh,
                "socialSecurityFilingAge": pld.socialSecurityFilingAge,
                "totalAllowedContributions": pld.totalAllowedContributions,
                "totalAllowedCatchupContribution": pld.totalAllowedCatchupContribution,
                "lifeYieldEnvironment": adminConfig.goalPriority.generalSettings.lifeYieldEnvironment,
                "wealth_path_probs": pld.wealth_path_probs,
            },
            "port_dict": pld.pdict,
            "lyCMEPackage": goe_tables["actuarialData"]["LYCMEPackage"],
            "lyTargetAllocations": goe_tables["actuarialData"]["LYTargetAllocations"],
            "LifeExpectancy": goe_tables["actuarialData"]["LifeExpectancy"],
        }
        if userInput.useAgeBasedCap is True:
            newPipePayload["age_based_risk_mapper"] = goe_tables.ageBasedEquityCap
        newPipePayload = DictDefault(newPipePayload)

        return {"error": None, "data": newPipePayload}
    except Exception as e:
        L = request.vars["L"]
        L.error(e)
        L.error(traceback.format_exc())
        InternalServerError.messages = str(e)
        raise InternalServerError


def generateGoalSimulationPayload(userInput, adminConfig, portfolios, goe_tables, ptf):
    try:
        pld = prepare_generate_payload("goeforsimulation", userInput, adminConfig, portfolios, "", ptf=ptf)
        pld = DictDefault(pld)
        member_list = []
        for m in userInput.household.memberList:
            member_list.append(
                {
                    "memberType": m.memberType,
                    "memberID": m.memberID,
                    "DOB": m.DOB,
                    "currentAge": m.currentAge,
                    "retirementAge": m.retirementAge,
                    "currentSalary": m.currentSalary,
                    "socialSecurityStartAge": m.socialSecurityStartAge,
                    "TDABalanceForRMD": m.TDABalanceForRMD,
                    "RMDUtilized": m.RMDUtilized,
                    "existingMonthlySocialSecurityAmount": m.existingMonthlySocialSecurityAmount,
                }
            )
        accounts_list = []
        for m in userInput.accounts:
            current_holdings_list = []
            for ch in m.currentHoldings:
                current_holdings_list.append(
                    {
                        "categoryName": ch.categoryName,
                        "categoryID": ch.categoryID,
                        "categoryPrice": ch.categoryPrice,
                        "quantity": ch.quantity,
                        "costBasis": ch.costBasis,
                    }
                )
            accounts_list.append(
                {
                    "accountID": m.accountID,
                    "taxabilityType": m.taxabilityType,
                    "accountType": m.accountType,
                    "memberIDs": m.memberIDs,
                    "currentBalance": m.currentBalance,
                    "cashflowDetails": {
                        "cashflowAmt": m.cashflowDetails.cashflowAmt,
                        "startDate": m.cashflowDetails.startDate,
                        "endDate": m.cashflowDetails.endDate,
                    },
                    "currentHoldings": current_holdings_list,
                }
            )
        goal_profile_list = []
        for m in userInput.goalProfileList:
            goal_profile_list.append(
                {
                    "goalId": m.goalId,
                    "goalAmt": m.goalAmt,
                    "scenarioType": m.scenarioType,
                    "startDate": m.startDate,
                    "endDate": m.endDate,
                    "priority": m.priority,
                    "bequest": m.bequest,
                    "goalPurpose": m.goalPurpose,
                }
            )
        newPipePayload = {
            "user_profile": {
                "currDate": pld.curr_date,
                "currentPortfolioId": pld.curr_port_id,
                "reallocate": userInput.reallocate,
                "riskProfile": userInput.riskProfile,
                "isNewRiskProfile": userInput.isNewRiskProfile,
                "isNewInvestmentTenure": userInput.isNewInvestmentTenure,
                "isNewGoal": userInput.isNewGoal,
                "isNewGoalPriority": userInput.isNewGoalPriority,
                "isNearTermVolatility": userInput.isNearTermVolatility,
                "getPath": userInput.getPath,
                "reallocationFreq": userInput.reallocationFreq,
                "lossThreshold": userInput.lossThreshold,
                "computeSocialSecurity": userInput.computeSocialSecurity or False,
                "useSocialSecurityForGoals": userInput.useSocialSecurityForGoals or False,
                "computeRMD": userInput.computeRMD or False,
                "useRMDForGoals": userInput.useRMDForGoals or False,
                "cashflowDate": userInput.cashflowDate,
                "infusionType": userInput.infusionType,
                "colaRate": userInput.colaRate,
                "taxRates": {
                    "LTCGPreRetirement": userInput.taxRates.LTCGPreRetirement if "taxRates" in userInput else None,
                    "ETRPreRetirement": userInput.taxRates.ETRPreRetirement if "taxRates" in userInput else None,
                    "LTCGPostRetirement": userInput.taxRates.LTCGPostRetirement if "taxRates" in userInput else None,
                    "ETRPostRetirement": userInput.taxRates.ETRPostRetirement if "taxRates" in userInput else None,
                },
                "household": {
                    "householdID": userInput.household.householdID,
                    "stateOfResidence": userInput.household.stateOfResidence,
                    "memberList": member_list,
                },
                "accounts": accounts_list,
                "goalProfileList": goal_profile_list,
                "debug": userInput.debug or False,
                "last_reallocation_date": userInput.lastReallocationDate,
                "use_age_based_cap": userInput.useAgeBasedCap or False,
            },
            "pipe_config": {
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                # "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                "realloc_schedules": pld.realloc_schedules,
                "exec_change": pld.exec_change,
                "swing_constraint": pld.swing_constraint,
                "swing": pld.swing,
                "safeguard": pld.safeguard,
                "downside_protect": pld.downside_protect,
                "protect_thd": pld.protect_thd,
                "goal_priority": pld.goal_priority,
                "downside_alternate_max_goal": pld.downside_alternate_max_goal,
                "get_path": pld.get_path,
                "realistic_goal_prob": pld.realistic_goal_prob,
                "goal_priority_prob": pld.goal_priority_prob,
                "goal_priority_prob_list": pld.goal_priority_prob_list,
                "infln": pld.infln,
                "sigma_thd": pld.sigma_thd,
                "nodes_per_sd": pld.nodes_per_sd,
                "inf_measure": pld.inf_measure,
                "irr_thresh": pld.irr_thresh,
                "safeguard_min": pld.safeguard_min,
                "LT_Factor": pld.LT_Factor,
                "long_tenure_thresh": pld.long_tenure_thresh,
                "irr_perf_thd": pld.irr_perf_thd,
                "alt_nodes_per_sd": pld.alt_nodes_per_sd,
                "alt_sigma_thd": pld.alt_sigma_thd,
                "topup_recommendation": pld.topup_recommendation,
                "tenure_recommendation": pld.tenure_recommendation,
                "recommend_escalated_goal": pld.recommend_escalated_goal,
                "back_pass_only": pld.back_pass_only,
                "short_term_tenure": pld.shortTermGoalTenure,
                "short_term_port_maxindex": pld.short_term_port_maxindex,
                "short_term_tenure_retirement": pld.shortTermRetirementGoalTenure,
                "short_term_tenure_retirement_unengaged": pld.shortTermRetirementGoalTenureUnengaged,
                "short_term_port_maxindex_retirement": pld.short_term_port_maxindex_retirement,
                "dec_port_maxindex": pld.dec_port_maxindex,
                "max_age": pld.max_age,
                "grid_freq": pld.grid_freq,
                "adjust_fees": pld.adjust_fees,
                "contrib_rate": pld.contrib_rate,
                "fixed_benefits": pld.fixed_benefits,
                "calc_goals": pld.calc_goals,
                "ly_package_id": pld.ly_package_id,
                "derisking_prob_thresh": pld.derisking_prob_thresh,
                "socialSecurityFilingAge": pld.socialSecurityFilingAge,
                "totalAllowedContributions": pld.totalAllowedContributions,
                "totalAllowedCatchupContribution": pld.totalAllowedCatchupContribution,
                "lifeYieldEnvironment": adminConfig.goalPriority.generalSettings.lifeYieldEnvironment,
                "wealth_path_probs": pld.wealth_path_probs,
                "simulation_type": pld.simulation_type,
                "simulation_count": pld.simulation_count,
            },
            "port_dict": pld.pdict,
            "lyCMEPackage": goe_tables["actuarialData"]["LYCMEPackage"],
            "lyTargetAllocations": goe_tables["actuarialData"]["LYTargetAllocations"],
            "LifeExpectancy": goe_tables["actuarialData"]["LifeExpectancy"],
            "age_based_glide_path": goe_tables["actuarialData"]["ageBasedGlidePath"],
        }
        newPipePayload = DictDefault(newPipePayload)

        return {"error": None, "data": newPipePayload}
    except Exception as e:
        L = request.vars["L"]
        L.error(e)
        L.error(traceback.format_exc())
        InternalServerError.messages = str(e)
        raise InternalServerError


def generateReplacementCalculatorPayload(userInput, replacement_calc_data, input_files_payload):
    try:
        repl_calc_data = DictDefault(replacement_calc_data)
        newPipePayload = {
            "user_profile": {
                "dateOfBirth": userInput.dateOfBirth,
                "retirementAge": userInput.retirementAge,
                "planningAge": userInput.planningAge,
                "currentSalary": userInput.currentSalary,
                "salaryGrowthRate": userInput.salaryGrowthRate,
                "outsideAccountBalance": userInput.outsideAccountBalance,
                "companyContribution": userInput.companyContribution,
                "traditionContribution": userInput.traditionContribution,
                "rothContribution": userInput.rothContribution,
                "autoEscalationRoth": userInput.autoEscalationRoth,
                "autoEscalationTraditional": userInput.autoEscalationTraditional,
                "replacementRate": userInput.replacementRate,
                "socialSecurityIncome": userInput.socialSecurityIncome,
                "outsideIncome": userInput.outsideIncome,
                "state": userInput.state,
                "inflation": userInput.inflation,
                "considerAWIGrowth": userInput.considerAWIGrowth if "considerAWIGrowth" in userInput else False,
                "considerBenefitsGrowth": userInput.considerBenefitsGrowth
                if "considerBenefitsGrowth" in userInput
                else False,
            },
            "riconfigParam": repl_calc_data["riConfigParam"],
            "taxBracket": repl_calc_data["taxBracket"],
            "inputFileCollection": input_files_payload,
        }
        newPipePayload = DictDefault(newPipePayload)
        return {"error": None, "data": newPipePayload}
    except Exception as e:
        L = request.vars["L"]
        L.error(e)
        L.error(traceback.format_exc())
        return {"error": str(e), "data": None}


def generateCustomPortfolioPayload(userInput, admin_configuration, custon_portfolio_tables):
    try:
        # repl_calc_data = DictDefault(replacement_calc_data)
        fund_details_list = []
        for fund_info in userInput.fundDetails:
            fund_details_list.append(
                {
                    "tickerName": fund_info.tickerName,
                    "name": fund_info.name,
                    "class": fund_info["class"],
                    "id": fund_info.id,
                }
            )
        portfolios_list = []
        for portfolio_info in userInput.portfolios:
            allocation_list = []
            for allocation_info in portfolio_info.allocations:
                allocation_list.append({"ticker": allocation_info.ticker, "value": allocation_info.value})
            if "name" not in portfolio_info:
                portfolios_list.append({"id": portfolio_info.id, "allocations": allocation_list})
            else:
                portfolios_list.append(
                    {"name": portfolio_info.name, "id": portfolio_info.id, "allocations": allocation_list}
                )

        if "cmedetails" in userInput:
            cmedetails_list = []
            for cmedetails_info in userInput.cmedetails:
                cmedetails_list.append(
                    {
                        "ticker": cmedetails_info.ticker,
                        "return": cmedetails_info["return"],
                        "stdev": cmedetails_info.stdev,
                    }
                )

        if "covariance" in userInput:
            covariance_list = []
            for covariance_info in userInput.covariance:
                cov_list = []
                for cov_info in covariance_info.cov:
                    cov_list.append({"ticker": cov_info.ticker, "value": cov_info.value})
                covariance_list.append({"ticker": covariance_info.ticker, "cov": cov_list})

        if "correlation" in userInput:
            correlation_list = []
            for correlation_info in userInput.correlation:
                cor_list = []
                for cor_info in correlation_info.corr:
                    cor_list.append({"ticker": cor_info.ticker, "value": cor_info.value})
                correlation_list.append({"ticker": correlation_info.ticker, "corr": cor_list})
        newPipePayload = {
            "user_profile": {
                "portfolioSuiteName": userInput.portfolioSuiteName,
                "fundIdentifier": userInput.fundIdentifier,
                "GOEPortfolioName": userInput.GOEPortfolioName,
                "compositePortfolio": userInput.compositePortfolio,
                "fundDetails": fund_details_list,
                "portfolios": portfolios_list,
            },
            "pipe_config": {
                "composite_portfolios": admin_configuration.goalPriority.generalSettings.composite_portfolios
            },
            "historicalIndexList": custon_portfolio_tables["actuarialData"]["HistoricalIndexList"],
            "FTLongTermCME": custon_portfolio_tables["actuarialData"]["FTLongTermCME"]
            # "lookup_data": input_files_payload.get("actuarialData").get("FixedDiscretionary"),
        }
        if "cmedetails" in userInput:
            newPipePayload["user_profile"]["cmedetails"] = cmedetails_list
        if "covariance" in userInput:
            newPipePayload["user_profile"]["covariance"] = covariance_list
        if "correlation" in userInput:
            newPipePayload["user_profile"]["correlation"] = correlation_list
        newPipePayload = DictDefault(newPipePayload)
        return {"error": None, "data": newPipePayload}
    except Exception as e:
        L = request.vars["L"]
        L.error(e)
        L.error(traceback.format_exc())
        return {"error": str(e), "data": None}


def generateFixedDiscretionaryCalculatorPayload(userInput, input_files_payload):
    try:
        # repl_calc_data = DictDefault(replacement_calc_data)
        newPipePayload = {
            "user_profile": {"expense": userInput.expense},
            "lookup_data": input_files_payload.get("actuarialData").get("FixedDiscretionary"),
        }
        newPipePayload = DictDefault(newPipePayload)
        return {"error": None, "data": newPipePayload}
    except Exception as e:
        L = request.vars["L"]
        L.error(e)
        L.error(traceback.format_exc())
        return {"error": str(e), "data": None}


def generate_decumulation_payload(userInput, adminConfig, portfolios, goe_tables, decumulation_uploads, ptf):
    try:
        pld = prepare_generate_payload("goefordecumulation", userInput, adminConfig, portfolios, "", ptf=ptf)
        pld = DictDefault(pld)
        newPipePayload = {
            "user_profile": {
                # "riskProfile": userInput.riskProfile,
                "gender": userInput.gender.capitalize() if userInput.gender else userInput.gender,
                "currentPortfolioId": pld.curr_port_id,
                # "currentAge": userInput.currentAge,
                "dateOfBirth": userInput.dateOfBirth,
                "retirementAge": userInput.retirementAge,
                "dbIncome": userInput.dbIncome,
                "otherGuaranteedIncome": userInput.otherGuaranteedIncome,
                "existingAnnuitiesIncome": userInput.existingAnnuitiesIncome,
                "stateIncome": userInput.stateIncome,
                "targetExpenditures": userInput.targetExpenditures,
                "currentWealth": userInput.currentWealth,
                "initialInvestment": userInput.initialInvestment,
                "infusionType": userInput.infusionType,
                "cashflowDate": userInput.cashflowDate,
                "startDate": userInput.startDate,
                "endDate": userInput.endDate,
                "currDate": pld.curr_date,
                "healthStatus": userInput.healthStatus,
                # "reallocationFreq": userInput.reallocationFreq, # shown as rebalancing.
                "reallocate": userInput.reallocate,
                "riskProfile": userInput.riskProfile.capitalize() if userInput.riskProfile else userInput.riskProfile,
                "isNewRiskProfile": userInput.isNewRiskProfile,
                "isNewInvestmentTenure": userInput.isNewInvestmentTenure,
                "isNewGoal": userInput.isNewGoal,
                "isNewGoalPriority": userInput.isNewGoalPriority,
                "isNearTermVolatility": userInput.isNearTermVolatility,
                "getPath": userInput.getPath,
                "lossThreshold": userInput.lossThreshold,
                "rebalancing": pld.rebalancing,  # reallocationFreq is shown as rebalancing
                "debug": userInput.debug or False,
                "includeAnnuities": userInput.includeAnnuities,
                "futureAnnuityProj": userInput.get("futureAnnuityProj", False),
                "use_age_based_cap": userInput.useAgeBasedCap or False,
            },
            "pipe_config": {
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                "derisking_prob_thresh": pld.derisking_prob_thresh,
                "realloc_schedules": pld.realloc_schedules,
                "exec_change": pld.exec_change,
                "swing_constraint": pld.swing_constraint,
                "swing": pld.swing,
                "safeguard": pld.safeguard,
                "downside_protect": pld.downside_protect,
                "protect_thd": pld.protect_thd,
                "goal_priority": pld.goal_priority,
                "downside_alternate_max_goal": pld.downside_alternate_max_goal,
                "get_path": pld.get_path,
                "realistic_goal_prob": pld.realistic_goal_prob,
                "goal_priority_prob": pld.goal_priority_prob,
                "goal_priority_prob_list": pld.goal_priority_prob_list,
                "infln": pld.infln,
                "sigma_thd": pld.sigma_thd,
                "nodes_per_sd": pld.nodes_per_sd,
                "inf_measure": pld.inf_measure,
                "irr_thresh": pld.irr_thresh,
                "safeguard_min": pld.safeguard_min,
                "LT_Factor": pld.LT_Factor,
                "long_tenure_thresh": pld.long_tenure_thresh,
                "irr_perf_thd": pld.irr_perf_thd,
                "alt_nodes_per_sd": pld.alt_nodes_per_sd,
                "alt_sigma_thd": pld.alt_sigma_thd,
                "topup_recommendation": pld.topup_recommendation,
                "tenure_recommendation": pld.tenure_recommendation,
                "recommend_escalated_goal": pld.recommend_escalated_goal,
                "back_pass_only": pld.back_pass_only,
                "short_term_tenure": pld.shortTermGoalTenure,
                "short_term_port_maxindex": pld.short_term_port_maxindex,
                "short_term_tenure_retirement": pld.shortTermRetirementGoalTenure,
                "short_term_tenure_retirement_unengaged": pld.shortTermRetirementGoalTenureUnengaged,
                "short_term_port_maxindex_retirement": pld.short_term_port_maxindex_retirement,
                "dec_port_maxindex": pld.dec_port_maxindex,
                "max_age": pld.max_age,
                "grid_freq": pld.grid_freq,
                "adjust_fees": pld.adjust_fees,
                "contrib_rate": pld.contrib_rate,
                "fixed_benefits": pld.fixed_benefits,
                "calc_goals": pld.calc_goals,
                "ly_package_id": pld.ly_package_id,
            },
            "port_dict": pld.pdict,
            "retirementConfig": {
                "Use Fixed Planning Age": adminConfig.goalPriority.generalSettings.useAFixedPlanningAge,
                "Type of Mortality Table": adminConfig.goalPriority.generalSettings.typeOfMortalityTable,
                "Minimum Annuitisation Amount": adminConfig.goalPriority.generalSettings.minimumAnnuitisationAmount,
                "additionalConsumptionCap": decumulation_uploads.get("additionalConsumptionCap", {}),
                "minimumConsumptionFloor": decumulation_uploads.get("minConsumptionFloor", {}),
                "ageBasedGICap": decumulation_uploads.get("ageBasedGICap", {}),
                "maximumEquityExposure": decumulation_uploads.get("maxEquityExposure", {}),
                "additionalAnnuityCapFactor": decumulation_uploads.get("ageBasedAnnuityCap", {}),
                "ageBasedPortCap": adminConfig.goalPriority.generalSettings.derisking,
            },
            "pmort_data": goe_tables["actuarialData"]["mortality"],
        }
        lfe_evets = []
        if userInput.lifeEventsList:
            for event in userInput.lifeEventsList:
                lfe_evets.append(
                    {
                        "lifeEventId": event.lifeEventId,
                        "startDate": event.startDate,
                        "endDate": event.endDate,
                        "type": event.type,
                        "scenarioType": event.scenarioType,
                        "goalAmt": event.goalAmt,
                    }
                )
            newPipePayload["user_profile"]["lifeEventsList"] = lfe_evets
        if userInput.inflation is not None:
            newPipePayload["user_profile"]["inflation"] = userInput.inflation

        if userInput.useAgeBasedCap is True:
            newPipePayload["age_based_risk_mapper"] = goe_tables.ageBasedEquityCap

        # if adminConfig.goalPriority.generalSettings.typeOfMortalityTable == "Unisex":
        #     del newPipePayload["user_profile"]["healthStatus"]
        if adminConfig.goalPriority.generalSettings.useAFixedPlanningAge:
            newPipePayload["retirementConfig"]["Planning Age"] = adminConfig.goalPriority.generalSettings.planningAge
        else:
            newPipePayload["retirementConfig"][
                "Minimum Planning Age"
            ] = adminConfig.goalPriority.generalSettings.minimumPlanningAge
        if adminConfig.goalPriority.guaranteedIncomePercent:
            income_percent = {}
            for idx, ipt in enumerate(adminConfig.goalPriority.guaranteedIncomePercent):
                income_percent[ipt.name.capitalize()] = ipt.min
            newPipePayload["retirementConfig"]["guaranteedIncomePerc"] = income_percent
        if userInput.includeAnnuities is True:
            newPipePayload["user_profile"]["annuityRate"] = userInput.annuityRate
        newPipePayload = DictDefault(newPipePayload)

        return {"error": None, "data": newPipePayload}
    except Exception as e:
        L = request.vars["L"]
        L.error(e)
        L.error(traceback.format_exc())
        InternalServerError.messages = str(e)
        raise InternalServerError
