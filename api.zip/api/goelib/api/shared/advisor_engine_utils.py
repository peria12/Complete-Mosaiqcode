import re
import datetime

from collections import abc

from goelib.api.shared.common import DictDefault, isDateFormatValid

from goelib.api.shared.case_conversion import converToSnakeCase


def validateAdvisorEnginePayloadVersion3dot8(payload):
    isNearTermVolatility = payload.isNearTermVolatility
    cashflowDate = payload.cashflowDate
    goalProfileList = payload.goalProfileList
    infusionType = payload.infusionType

    isNewRiskProfile = payload.isNewRiskProfile
    isNewGoal = payload.isNewGoal
    currentAge = payload.currentAge
    retirementAge = payload.retirementAge
    if payload.reallocationFreq is None or payload.reallocationFreq not in ["yearly", "half-yearly", "quarterly"]:
        return {
            "isValid": False,
            "message": "reallocationFreq is a mandatory field and has to be one of yearly, half-yearly or quarterly",
        }

    if not isinstance(isNewGoal, bool):
        return {
            "isValid": False,
            "message": "isNewGoal must be a boolean.",
        }

    if not isinstance(isNewRiskProfile, bool):
        return {"isValid": False, "message": "isNewRiskProfile must be a boolean"}

    # currDate = payload.currDate
    if "cashflowDate" in payload and cashflowDate is not None and not isDateFormatValid(cashflowDate):
        return {
            "isValid": False,
            "message": "cashflowDate must be in ISO date format or null.",
        }
    # isNearTermVolatility is optional and if provided should be boolean
    if "isNearTermVolatility" in payload and (
        isNearTermVolatility is not None and type(isNearTermVolatility) is not bool
    ):
        return {
            "isValid": False,
            "message": "isNearTermVolatility must be a boolean.",
        }

    if not isinstance(goalProfileList, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goalProfileList must be a list of objects.",
        }
    if isinstance(goalProfileList, abc.MutableSequence):
        for i in goalProfileList:
            goalID = i.goalID
            goalAmount = i.goalAmt
            startDate = i.startDate
            endDate = i.endDate
            goalPriority = i.priority
            scenarioType = i.scenarioType
            if type(goalID) is not str or not re.match("^[ A-Za-z0-9]+$", goalID):
                return {
                    "isValid": False,
                    "message": "goalID is required and should only contain letters, numbers and spaces.",
                }
            if type(goalAmount) is list:
                for amt in goalAmount:
                    if type(amt) not in [float, int] or amt < 0:
                        return {
                            "isValid": False,
                            "message": "goalAmt list must consist of a non negative floating number.",
                        }
                    if scenarioType == "regular" and len(goalAmount) > 1:
                        return {
                            "isValid": False,
                            "message": f"Please check scenarioType for {goalID}.",
                        }
            else:
                return {
                    "isValid": False,
                    "message": "goalAmt must be a list.",
                }
            if type(startDate) is not str or not isDateFormatValid(startDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for startDate should be between 1-01-1800 to 31-12-2399",
                }
            if type(endDate) is not str or not isDateFormatValid(endDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399",
                }
            if datetime.datetime.strptime(startDate, "%d-%m-%Y") > datetime.datetime.strptime(endDate, "%d-%m-%Y"):
                return {"isValid": False, "message": "StartDate must be less than endDate."}

            if goalPriority not in ["Need", "Want", "Wish", "Dream"]:
                return {
                    "isValid": False,
                    "message": "priority must be one of Need, Want, Wish, or Dream.",
                }
            if scenarioType not in ["regular", "retirement"]:
                return {
                    "isValid": False,
                    "message": "scenarioType must be regular or retirement",
                }
    if infusionType not in ["yearly", "monthly"]:
        return {
            "isValid": False,
            "message": "infusionType must be one of yearly or monthly.",
        }

    if currentAge is not None and (type(currentAge) is not int or currentAge < 0):
        return {
            "isValid": False,
            "message": "currentAge must be an integer or null.",
        }
    if retirementAge is not None and (type(retirementAge) is not int or retirementAge < 0):
        return {
            "isValid": False,
            "message": "retirementAge must be an integer or null.",
        }
    if "calibrateGoalRec" in payload and not isinstance(payload.calibrateGoalRec, bool):
        return {
            "isValid": False,
            "message": "calibrateGoalRec must be a boolean. If not specified default to False.",
        }
    if "lastReallocationDate" in payload and not isDateFormatValid(payload.lastReallocationDate):
        return {
            "isValid": False,
            "message": "lastReallocationDate is optional if provided should follow format dd-mm-yyyy.",
        }
    return {
        "isValid": True,
        "message": None,
    }


def validateAdvisorEnginePayloadUIPV4(payload):
    isNearTermVolatility = payload.isNearTermVolatility
    cashflowDate = payload.cashflowDate
    goalProfileList = payload.goalProfileList
    infusionType = payload.infusionType

    isNewRiskProfile = payload.isNewRiskProfile
    isNewGoal = payload.isNewGoal
    currentAge = payload.currentAge
    retirementAge = payload.retirementAge
    # if "useAgeBasedCap" in payload and type(payload.useAgeBasedCap) != bool:
    #     return {"isValid": False, "message": "useAgeBasedCap must be boolean."}
    if payload.reallocationFreq is None or payload.reallocationFreq not in ["yearly", "half-yearly", "quarterly"]:
        return {
            "isValid": False,
            "message": "reallocationFreq is a mandatory field and has to be one of yearly, half-yearly or quarterly",
        }

    if not isinstance(isNewGoal, bool):
        return {
            "isValid": False,
            "message": "isNewGoal must be a boolean.",
        }

    if not isinstance(isNewRiskProfile, bool):
        return {"isValid": False, "message": "isNewRiskProfile must be a boolean"}

    # currDate = payload.currDate
    if "cashflowDate" in payload and cashflowDate is not None and not isDateFormatValid(cashflowDate):
        return {
            "isValid": False,
            "message": "cashflowDate must be in ISO date format or null.",
        }
    # isNearTermVolatility is optional and if provided should be boolean
    if "isNearTermVolatility" in payload and (
        isNearTermVolatility is not None and type(isNearTermVolatility) is not bool
    ):
        return {
            "isValid": False,
            "message": "isNearTermVolatility must be a boolean.",
        }

    if not isinstance(goalProfileList, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goalProfileList must be a list of objects.",
        }
    if isinstance(goalProfileList, abc.MutableSequence):
        for i in goalProfileList:
            goalID = i.goalID
            goalAmount = i.goalAmt
            startDate = i.startDate
            endDate = i.endDate
            goalPriority = i.priority
            scenarioType = i.scenarioType
            if type(goalID) is not str or not re.match("^[ A-Za-z0-9]+$", goalID):
                return {
                    "isValid": False,
                    "message": "goalID is required and should only contain letters, numbers and spaces.",
                }
            if type(goalAmount) is list:
                for amt in goalAmount:
                    if type(amt) not in [float, int] or amt < 0:
                        return {
                            "isValid": False,
                            "message": "goalAmt list must consist of a non negative floating number.",
                        }
                    if scenarioType == "regular" and len(goalAmount) > 1:
                        return {
                            "isValid": False,
                            "message": f"Please check scenarioType for {goalID}.",
                        }
            else:
                return {
                    "isValid": False,
                    "message": "goalAmt must be a list.",
                }
            if type(startDate) is not str or not isDateFormatValid(startDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for startDate should be between 1-01-1800 to 31-12-2399",
                }
            if type(endDate) is not str or not isDateFormatValid(endDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399",
                }
            if datetime.datetime.strptime(startDate, "%d-%m-%Y") > datetime.datetime.strptime(endDate, "%d-%m-%Y"):
                return {"isValid": False, "message": "StartDate must be less than endDate."}

            if goalPriority not in ["Need", "Want", "Wish", "Dream"] and goalPriority not in ["P1", "P2", "P3"]:
                return {
                    "isValid": False,
                    "message": "priority must be one of [Need, Want, Wish, Dream] or one of [P1, P2, P3]",
                }

            if scenarioType not in ["regular", "retirement"]:
                return {
                    "isValid": False,
                    "message": "scenarioType must be regular or retirement",
                }
    if infusionType not in ["yearly", "monthly"]:
        return {
            "isValid": False,
            "message": "infusionType must be one of yearly or monthly.",
        }

    if currentAge is not None and (type(currentAge) is not int or currentAge < 0):
        return {
            "isValid": False,
            "message": "currentAge must be an integer or null.",
        }
    if retirementAge is not None and (type(retirementAge) is not int or retirementAge < 0):
        return {
            "isValid": False,
            "message": "retirementAge must be an integer or null.",
        }
    if "calibrateGoalRec" in payload and not isinstance(payload.calibrateGoalRec, bool):
        return {
            "isValid": False,
            "message": "calibrateGoalRec must be a boolean. If not specified default to False.",
        }
    if payload.assetsHeldAway is not None:
        if not isinstance(payload.assetsHeldAway, abc.MutableSequence):
            return {"isValid": False, "message": "assetsHeldAway must be a array object."}
        for ast in payload.assetsHeldAway:
            if "name" in ast and type(ast.name) != str:
                return {
                    "isValid": False,
                    "message": "name of assetsHeldAway is optional if provided must be string .",
                }
            if "currentValue" not in ast or type(ast.currentValue) not in [int, float] or ast.currentValue < 0:
                return {
                    "isValid": False,
                    "message": "currentValue of assetsHeldAway must be a number greater than or equal to zero.",
                }
            if "currentComposition" not in ast or not isinstance(ast.currentComposition, abc.MutableMapping):
                return {"isValid": False, "message": "currentComposition must be a mapping object."}
            if type(ast.currentComposition.equity) not in [int, float] or not (0 <= ast.currentComposition.equity <= 1):
                return {"isValid": False, "message": "equity of currentComposition must be a number between 0 and 1."}
            if type(ast.currentComposition.debt) not in [int, float] or not (0 <= ast.currentComposition.debt <= 1):
                return {"isValid": False, "message": "debt of currentComposition must be a number between 0 and 1."}
            if type(ast.currentComposition.other) not in [int, float] or not (0 <= ast.currentComposition.other <= 1):
                return {"isValid": False, "message": "other of currentComposition must be a number between 0 and 1."}
            if ast.currentComposition.equity + ast.currentComposition.debt + ast.currentComposition.other != 1.0:
                return {"isValid": False, "message": "equity, debt and other in currentComposition should add up to 1."}

            if (
                "expectedDateOfConversionToAUM" not in ast
                or type(ast.expectedDateOfConversionToAUM) != str
                or not isDateFormatValid(ast.expectedDateOfConversionToAUM)
            ):
                return {"isValid": False, "message": "expectedDateOfConversionToAUM must be a string in dd-mm-yyyy."}
    if payload.fixedAssets is not None:
        if not isinstance(payload.fixedAssets, abc.MutableSequence):
            return {"isValid": False, "message": "fixedAssets can either be null or an array of objects."}
        for x in payload.fixedAssets:
            if x.name is not None and type(x.name) != str:
                return {"isValid": False, "message": "name of fixedAssets must be a string."}
            if x.expectedDateOfLiquidity is None or not isDateFormatValid(x.expectedDateOfLiquidity):
                return {
                    "isValid": False,
                    "message": "expectedDateOfLiquidity of fixedAssets must be a string in dd-mm-yyyy.",
                }
            if (
                x.expectedValueAtLiquidity is None
                or type(x.expectedValueAtLiquidity) not in [int, float]
                or x.expectedValueAtLiquidity < 0
            ):
                return {
                    "isValid": False,
                    "message": "expectedValueAtLiquidity of fixedAssets must a number greater than or equal to zero.",
                }
    if "lastReallocationDate" in payload and not isDateFormatValid(payload.lastReallocationDate):
        return {
            "isValid": False,
            "message": "lastReallocationDate is optional if provided should follow format dd-mm-yyyy.",
        }
    return {
        "isValid": True,
        "message": None,
    }


def validateAdvisorEnginePayload(payload, version="3"):
    cashflow_date = payload.cashflow_date
    isNewRTQ = payload.isNewRTQ
    isNewInvestmentTenure = payload.isNewInvestmentTenure
    isNearTermVolatility = payload.isNearTermVolatility
    isNewGoalPriority = payload.isNewGoalPriority
    goal_profile_list = payload.goal_profile_list
    initialInvestment = payload.initialInvestment
    infusions = payload.infusions
    accountsCashflowList = payload.accountsCashflowList
    currDate = payload.currDate
    currentWealth = payload.currentWealth
    currentPortfolioId = payload.currentPortfolioId if "currentPortfolioId" in payload else False
    getPath = payload.getPath
    infusion_type = payload.infusion_type
    scenario_type = payload.scenario_type
    riskOverride = payload.riskOverride
    reallocate = payload.reallocate
    lossThreshold = payload.lossThreshold
    rebalancing = payload.rebalancing
    # if "useAgeBasedCap" in payload and type(payload.useAgeBasedCap) != bool:
    #     return {"isValid": False, "message": "useAgeBasedCap must be boolean."}
    if payload.participantID is not None and type(payload.participantID) not in [str]:
        return {
            "isValid": False,
            "message": "participantID must be a alphanumeric.",
        }
    if isinstance(payload.participantID, str) and not payload.participantID.isalnum():
        return {
            "isValid": False,
            "message": "participantID must be a alphanumeric.",
        }
    if payload.planID is not None and type(payload.planID) not in [str]:
        return {
            "isValid": False,
            "message": "planID must be a alphanumeric.",
        }
    if isinstance(payload.planID, str) and not payload.planID.isalnum():
        return {
            "isValid": False,
            "message": "planID must be a alphanumeric.",
        }
    if payload.sourceID is not None and type(payload.sourceID) not in [str]:
        return {
            "isValid": False,
            "message": "sourceID must be a alphanumeric.",
        }
    if isinstance(payload.sourceID, str) and not payload.sourceID.isalnum():
        return {
            "isValid": False,
            "message": "sourceID must be a alphanumeric.",
        }
    if "lastReallocationProbability" in payload and (
        type(payload.lastReallocationProbability) not in [float, int]
        or not (0 <= payload.lastReallocationProbability <= 0.99)
    ):
        return {
            "isValid": False,
            "message": "lastReallocationProbability must be float and between 0 and 0.99.",
        }
    if version == "4":
        result3dot8 = validateAdvisorEnginePayloadVersion3dot8(payload)

        if not result3dot8.get("isValid"):
            return result3dot8
    elif version == "v4":
        resultuipv4 = validateAdvisorEnginePayloadUIPV4(payload)
        if not resultuipv4.get("isValid"):
            return resultuipv4
    else:
        if "cashflow_date" in payload and cashflow_date is not None and not isDateFormatValid(cashflow_date):
            return {
                "isValid": False,
                "message": "cashflow_date must be in ISO date format or null.",
            }
        if not goal_profile_list:
            return {
                "isValid": False,
                "message": "goal_profile_list must be a list of objects.",
            }
        if type(goal_profile_list) is list:
            for i in goal_profile_list:
                goal_id = i.goal_id
                goalAmount = i.goal_amt
                startDate = i.start_date
                endDate = i.end_date
                goalPriority = i.priority
                if type(startDate) is not str or not isDateFormatValid(startDate):
                    return {
                        "isValid": False,
                        "message": "Valid date range for startDate should be between 1-01-1800 to 31-12-2399",
                    }
                if type(endDate) is not str or not isDateFormatValid(endDate):
                    return {
                        "isValid": False,
                        "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399",
                    }
                if datetime.datetime.strptime(startDate, "%d-%m-%Y") > datetime.datetime.strptime(endDate, "%d-%m-%Y"):
                    return {"isValid": False, "message": "StartDate must be less than endDate."}
                if type(goal_id) is not str or not re.match("^[ A-Za-z0-9]+$", goal_id):
                    return {
                        "isValid": False,
                        "message": "goal_id is required and should only contain letters, numbers and spaces.",
                    }
                if type(goalAmount) is list:
                    for amt in goalAmount:
                        if type(amt) not in [float, int] or amt < 0:
                            return {
                                "isValid": False,
                                "message": "goal_amt list must consist of a non negative floating number.",
                            }
                else:
                    return {
                        "isValid": False,
                        "message": "goal_amt must be a list.",
                    }
                if goalPriority not in ["Need", "Want", "Wish", "Dream"]:
                    return {
                        "isValid": False,
                        "message": "priority must be one of Need, Want, Wish, or Dream.",
                    }
        if infusion_type not in ["yearly", "monthly"]:
            return {
                "isValid": False,
                "message": "infusion_type must be one of yearly or monthly.",
            }
        if scenario_type != "AE":
            return {
                "isValid": False,
                "message": "scenario_type must be AE",
            }
        if type(isNewRTQ) is not bool:
            return {
                "isValid": False,
                "message": "isNewRTQ must be boolean.",
            }
        if type(isNearTermVolatility) is not bool:
            return {
                "isValid": False,
                "message": "isNearTermVolatility must be boolean.",
            }
    if type(isNewInvestmentTenure) is not bool:
        return {
            "isValid": False,
            "message": "isNewInvestmentTenure must be a boolean.",
        }

    if type(isNewGoalPriority) is not bool:
        return {
            "isValid": False,
            "message": "isNewGoalPriority must be a boolean.",
        }
    if type(initialInvestment) not in [float, int] or initialInvestment < 0:
        return {
            "isValid": False,
            "message": "initialInvestment must be a number greater than or equal to 0.",
        }
    if version == "4":
        if infusions is not None and accountsCashflowList is not None:
            return {
                "isValid": False,
                "message": "Both infusions and accountsCashflowList can not be accepted",
            }
        if (infusions is None or not isinstance(infusions, abc.MutableSequence)) and accountsCashflowList is None:
            return {
                "isValid": False,
                "message": "infusions must be a list of numbers",
            }
        if infusions is not None and isinstance(infusions, abc.MutableSequence):
            for i in infusions:
                if type(i) not in (float, int):
                    return {"isValid": False, "message": "Elements within infusions must be in number format"}
        if infusions is None and (
            accountsCashflowList is not None and not isinstance(accountsCashflowList, abc.MutableSequence)
        ):
            return {
                "isValid": False,
                "message": "accountsCashflowList must be a array",
            }
        if infusions is None and isinstance(accountsCashflowList, abc.MutableSequence):
            for i in accountsCashflowList:
                if "AccountId" not in i:
                    return {"isValid": False, "message": "AccountId within accountsCashflowList is mandatory"}
                elif "AccountId" in i and i.get("AccountId") not in [
                    "Taxable",
                    "TDA",
                    "Roth",
                    "SocialSecurity",
                    "TaxableIncome",
                ]:
                    return {
                        "isValid": False,
                        "message": "AccountId must be one of Taxable, TDA, Roth, SocialSecurity, TaxableIncome",
                    }
                if i.get("AccountId") in ["Taxable", "TDA", "Roth"] and "currentAccountBalance" not in i:
                    return {
                        "isValid": False,
                        "message": "currentAccountBalance is mandatory when AccountId is one of Taxable, TDA, Roth",
                    }
                if i.get("currentAccountBalance") is not None and (
                    type(i.get("currentAccountBalance")) not in [float, int] or i.get("currentAccountBalance") < 0
                ):
                    return {"isValid": False, "message": "currentAccountBalance must be a positive number"}
                if "cashflowList" not in i or not isinstance(i.get("cashflowList"), abc.MutableSequence):
                    return {"isValid": False, "message": "cashflowList must be array of numbers"}
                for x in i.get("cashflowList"):
                    if type(x) not in [float, int]:
                        return {"isValid": False, "message": "cashflowList must be array of numbers"}
    else:
        if infusions is None:
            return {
                "isValid": False,
                "message": "infusions must be a list of numbers",
            }
        if isinstance(infusions, abc.MutableSequence):
            for i in infusions:
                if type(i) not in (float, int):
                    return {"isValid": False, "message": "Elements within infusions must be in number format"}

    if currDate and (type(currDate) != str or not isDateFormatValid(currDate)):
        return {"isValid": False, "message": "Valid date range for currDate should be between 1-01-1800 to 31-12-2399."}
    if "currentWealth" not in payload or (
        currentWealth is not None and (type(currentWealth) not in (float, int) or currentWealth < 0)
    ):
        return {
            "isValid": False,
            "message": "currentWealth must be a number greater or equal 0 or null",
        }
    if currentPortfolioId is not None and (
        currentPortfolioId is False
        or (type(currentPortfolioId) == int and currentPortfolioId < 0)
        or type(currentPortfolioId) not in [int]
    ):
        return {
            "isValid": False,
            "message": "currentPortfolioId must be an integer or null.",
        }
    if type(getPath) != bool:
        return {
            "isValid": False,
            "message": "getPath must be a boolean.",
        }
    if riskOverride is not None and not isinstance(riskOverride, bool):
        return {
            "isValid": False,
            "message": "riskOverride must be a boolean. When not specificed, default value is false",
        }
    if "reallocate" in payload and not isinstance(reallocate, bool):
        return {
            "isValid": False,
            "message": "reallocate must be a boolean. When not specificed, default value is false",
        }
    if (
        "lossThreshold" in payload
        and payload.lossThreshold is not None
        and (type(lossThreshold) not in [float, int] or lossThreshold < 0)
    ):
        return {
            "isValid": False,
            "message": "lossThreshold must be a number greater than equal to 0 or null",
        }

    if version == "3":
        if rebalancing is None or rebalancing not in ["yearly", "half-yearly", "quarterly"]:
            return {
                "isValid": False,
                "message": "rebalancing is a mandatory field and has to be one of yearly, half-yearly or quarterly",
            }
    return {
        "isValid": True,
        "message": None,
    }


def generateAdvisorEnginePayload(userInput, adminConfig, portfolios, actuarialData, version="stable", ptf={}):
    # * eslint-disable camelcase */
    try:
        init_inv = userInput.initialInvestment
        infusions = userInput.infusions
        curr_date = userInput.currDate or datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y")
        goal_profile_list = userInput.goal_profile_list
        cashflow_date = userInput.cashflow_date
        if version == "4":
            goalProfileList = {
                "payload": userInput.goalProfileList,
            }
            goal_profile_list = converToSnakeCase(goalProfileList.get("payload"))
            cashflow_date = userInput.cashflowDate

        curr_port_id = userInput.currentPortfolioId
        if curr_port_id is not None and curr_port_id < 1:
            curr_port_id = None
        curr_wealth = userInput.currentWealth

        scenario_type = userInput.scenario_type
        infusion_type = userInput.infusion_type

        # const currDateSplit = curr_date.valueOf().split('-');_
        # const momentCurrDate = moment(currDateSplit[2] + currDateSplit[1] + currDateSplit[0]);
        shortTermGoalTenure = adminConfig.portfolioConfig.shortTermGoalTenure or 3
        shortTermRetirementGoalTenure = adminConfig.portfolioConfig.shortTermRetirementGoalTenure or 3
        # useFTPortfolios = adminConfig.portfolioConfig.usingFtPortfolio or False

        portfolioMapping = adminConfig.portfolioConfig.portfolioMapping
        grid_freq = adminConfig.goalPriority.generalSettings.gridFrequency or None
        risk_override = userInput.riskOverride or False

        # getPath = userInput.getPath
        rebalancing = userInput.rebalancing
        if version == "4":
            rebalancing = userInput.reallocationFreq
            scenario_type = userInput.scenarioType
            infusion_type = userInput.infusionType
        current_age = userInput.currentAge
        retirement_age = userInput.retirementAge
        max_age = adminConfig.goalPriority.generalSettings.maxAge or 120
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        reallocationDatesByFrequency = adminConfig.allocationConfiguration.reallocationDatesByFrequency or {}
        reallocationDates = []
        if rebalancing == "yearly":
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
        elif rebalancing == "half-yearly":
            reallocationDates = reallocationDatesByFrequency["halfyearly"]
            rebalancing = "half-yearly_"
        elif rebalancing == "quarterly":
            reallocationDates = reallocationDatesByFrequency["quarterly"]
            rebalancing = "quarterly_"
        else:
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
        reallocation_date_format = "%a %b %d %Y"
        realloc_schedules = []
        for dt in reallocationDates:
            t = datetime.datetime.strptime(dt, reallocation_date_format)
            realloc_schedules.append(
                datetime.datetime.strftime(datetime.datetime(int(curr_date.split("-")[2]), t.month, t.day), "%d-%m-%Y")
            )

        # TODO to fix in future
        # isRiskOn = False
        # //TODO to fix in future
        ifNewRiskProfile = False
        ifNewInvestmentTenure = False
        ifNearTermVolatility = False
        ifGoalPriorityChanged = False
        ifNewGoal = False
        ifWantsToReallocate = False
        for triggers in adminConfig.allocationConfiguration.reallocationTriggers:
            if triggers.name == "newRiskProfile" and triggers.value is True:
                ifNewRiskProfile = True
            if triggers.name == "changesInvestmentTenure" and triggers.value is True:
                ifNewInvestmentTenure = True
            if triggers.name == "newGoal" and triggers.value is True:
                ifNewGoal = True
            if triggers.name == "riskIndicatorFlashes" and triggers.value is True:
                ifNearTermVolatility = True
            if triggers.name == "rePrioritizesGoal" and triggers.value is True:
                ifGoalPriorityChanged = True
            if triggers.name == "wantsToReallocate" and triggers.value is True:
                ifWantsToReallocate = True
        lossThresholdValueForPriorityNeed = list(
            filter(lambda e: e.name == "need", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWant = list(
            filter(lambda e: e.name == "want", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWish = list(
            filter(lambda e: e.name == "wish", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        levelsOfGoalPriorityNeed = list(filter(lambda e: e.name == "need", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWant = list(filter(lambda e: e.name == "want", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWish = list(filter(lambda e: e.name == "wish", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.probabilityLevels)
        )[0]
        goalModificationNeed = list(filter(lambda e: e.name == "need", adminConfig.goalPriority.goalModification))[0]
        goalModificationWant = list(filter(lambda e: e.name == "want", adminConfig.goalPriority.goalModification))[0]
        goalModificationWish = list(filter(lambda e: e.name == "wish", adminConfig.goalPriority.goalModification))[0]
        goalModificationDream = list(filter(lambda e: e.name == "dream", adminConfig.goalPriority.goalModification))[0]
        # goalModificationDesire = list(
        #     filter(lambda e: e.name == "desire", adminConfig.goalPriority.goalModification)
        # )[0]
        realistic_goal_prob = adminConfig.goalPriority.generalSettings.unrealisticProbability
        # TODO Fix in future
        # For now always select risk on portfolios
        if not portfolios or (not portfolios[1]):
            raise ValueError("Default risk on portfolios not found.")

        # change logic to use portfolios rather than user input
        usedPortfolios = portfolios.portfoliosRiskOn
        maximumDecumulationPortMaxIndex = portfolios.maximumDecumulationPortMaxIndex
        maximumShortTermPortMaxIndex = portfolios.maximumShortTermPortMaxIndex
        maximumShortTermRetirementPortMaxIndex = portfolios.maximumShortTermRetirementPortMaxIndex
        configRiskType = "None"
        if userInput.riskProfile:
            sanitizedPortfolioMapping = dict((key.lower(), val) for key, val in portfolioMapping.items())
            riskProfileInLowerCase = userInput.riskProfile.lower()
            configRiskType = sanitizedPortfolioMapping.get(riskProfileInLowerCase)

        allowedProfiles = []
        if configRiskType == "VeryConservative":
            # allowedProfiles = ["VeryConservative"]
            allowedProfiles = ptf["veryConservativeLimits"]
        elif configRiskType == "Conservative":
            # allowedProfiles = ["VeryConservative", "Conservative"]
            allowedProfiles = ptf["conservativeLimits"]
        elif configRiskType == "ConservativelyModerate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate"]
            allowedProfiles = ptf["conservativelyModerateLimits"]
        elif configRiskType == "Moderate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate", "Moderate"]
            allowedProfiles = ptf["moderateLimits"]
        elif configRiskType == "ModeratelyAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            # ]
            allowedProfiles = ptf["moderatelyAggressivelLimits"]
        elif configRiskType == "Aggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            # ]
            allowedProfiles = ptf["aggressiveLimits"]
        elif configRiskType == "VeryAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            #     "VeryAggressive",
            # ]
            allowedProfiles = ptf["veryAggressiveLimits"]
        else:
            allowedProfiles = []
        if userInput.useAgeBasedCap:
            portfolio_nos = range(1, len(portfolios.useAgeBasedCapPortfoliosRiskOn) + 1)

            expected_returns = list(
                map(lambda e: getattr(e, "portfolio_return") / 100, portfolios.useAgeBasedCapPortfoliosRiskOn)
            )
            expected_risks = list(map(lambda e: e.risk / 100, portfolios.useAgeBasedCapPortfoliosRiskOn))
            asset_allocations = list(map(lambda e: e.assetAllocation, portfolios.useAgeBasedCapPortfoliosRiskOn))
            fees_adjuster_data = list(map(lambda e: e.feesAdjuster, portfolios.useAgeBasedCapPortfoliosRiskOn))
        else:
            # expected_returns = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            # expected_risks = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            # asset_allocations = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            # fees_adjuster_data = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # fees_adjuster_data = list(map(lambda e: e.feesAdjuster, fees_adjuster_data))
            portfolio_nos = [
                [p.id for p in portfolios.useAgeBasedCapPortfoliosRiskOn].index(value.id) + 1
                for index, value in enumerate(usedPortfolios)
                if (lambda e: allowedProfiles and e.id in allowedProfiles)(value)
            ]
            expected_returns = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            expected_risks = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            asset_allocations = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            fees_adjuster_data = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            fees_adjuster_data = list(map(lambda e: e.feesAdjuster, fees_adjuster_data))

        short_term_port_maxindex = None
        dec_port_maxindex = None
        if maximumShortTermPortMaxIndex > 0:
            short_term_port_maxindex = maximumShortTermPortMaxIndex
        short_term_port_maxindex_retirement = None
        if maximumShortTermRetirementPortMaxIndex > 0:
            short_term_port_maxindex_retirement = maximumShortTermRetirementPortMaxIndex
        dec_port_maxindex = None
        if maximumDecumulationPortMaxIndex > 0:
            dec_port_maxindex = maximumDecumulationPortMaxIndex
        port_dict = []
        for ret, risk, asset_allocation, portfolio_no in zip(
            expected_returns, expected_risks, asset_allocations, portfolio_nos
        ):
            port_data = {
                "mu": round(ret, 4) if ret is not None else ret,
                "sigma": round(risk, 4) if risk is not None else risk,
                "equity": asset_allocation["equity"],
                "bond": asset_allocation["bond"],
                "money_market": asset_allocation["money_market"],
                "id": portfolio_no,
            }
            if adjust_fees and adjust_fees.lower() == "variable":
                port_data.update({"fees_adjuster": fees_adjuster_data})
            elif adjust_fees and adjust_fees.lower() == "common":
                port_data.update({"fees_adjuster": adminConfig.goalPriority.generalSettings.annualInBPS})
            port_dict.append(port_data)

        downside_alternate_max_goal = False
        goal_priority = False
        if adminConfig.goalPriority.generalSettings.downsideProtection == "Maximize Goal Probability":
            downside_alternate_max_goal = True
        if downside_alternate_max_goal is True:
            goal_priority = True
        loss_amt = None
        if userInput.lossThreshold is not None:
            loss_amt = userInput.lossThreshold
        exec_change = False
        if version != "4" and userInput.isNewRTQ and ifNewRiskProfile:
            exec_change = True
        if version == "4" and userInput.isNewRiskProfile and ifNewRiskProfile:
            exec_change = True
        if userInput.isNewInvestmentTenure and ifNewInvestmentTenure:
            exec_change = True
        if userInput.isNearTermVolatility and ifNearTermVolatility:
            exec_change = True
        if userInput.isNewGoalPriority and ifGoalPriorityChanged:
            exec_change = True
        if version == "4" and userInput.isNewGoal and ifNewGoal:
            exec_change = True
        if userInput.reallocate and ifWantsToReallocate:
            exec_change = True
        if curr_date in realloc_schedules:
            exec_change = True
        LT_Factor = {
            "Acc_Need": lossThresholdValueForPriorityNeed.accumulation,
            "Acc_Want": lossThresholdValueForPriorityWant.accumulation,
            "Acc_Wish": lossThresholdValueForPriorityWish.accumulation,
            "Acc_Dream": lossThresholdValueForPriorityDream.accumulation,
            "Dec_Need": lossThresholdValueForPriorityNeed.decumulation,
            "Dec_Want": lossThresholdValueForPriorityWant.decumulation,
            "Dec_Wish": lossThresholdValueForPriorityWish.decumulation,
            "Dec_Dream": lossThresholdValueForPriorityDream.decumulation,
        }

        goal_priority_prob_list = {
            "Need": levelsOfGoalPriorityNeed.value,
            "Want": levelsOfGoalPriorityWant.value,
            "Wish": levelsOfGoalPriorityWish.value,
            "Dream": levelsOfGoalPriorityDream.value,
        }
        goal_drop_priority = {
            "Need": goalModificationNeed.value,
            "Want": goalModificationWant.value,
            "Wish": goalModificationWish.value,
            "Dream": goalModificationDream.value,
            # "Desire": goalModificationDesire.value,
        }
        get_path = userInput.getPath
        sigma_thd = adminConfig.goalPriority.performance.sigma
        nodes_per_sd = adminConfig.goalPriority.performance.nodesPerSd
        infln = adminConfig.goalPriority.generalSettings.inflation
        inf_measure = None
        if adminConfig.goalPriority.generalSettings.inflationMeasureForInfusions == "NOMINAL":
            inf_measure = "nominal"
        else:
            inf_measure = "real"
        irr_thresh = adminConfig.goalPriority.performance.irrForRangeAdjustment
        safeguard = adminConfig.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear
        safeguard_min = adminConfig.goalPriority.generalSettings.minPortfoliosForLastYear
        swing_constraint = adminConfig.goalPriority.generalSettings.swingConstraint
        swing = adminConfig.goalPriority.generalSettings.swingConstraintNumber
        downside_protect = adminConfig.goalPriority.lossThreshold
        protect_thd = adminConfig.goalPriority.lossThresholdProbability
        long_tenure_thresh = adminConfig.goalPriority.performance.longTenureThreshold or 30
        irr_perf_thd = adminConfig.goalPriority.performance.irrPerformanceThreshold or 0.0339
        alt_nodes_per_sd = adminConfig.goalPriority.performance.altNodesPerSd or 4
        alt_sigma_thd = adminConfig.goalPriority.performance.alternativeSigma or 4
        topup_recommendation = adminConfig.goalPriority.generalSettings.recommendTopUpInfusion
        tenure_recommendation = adminConfig.goalPriority.generalSettings.recommendTenure
        back_pass_only = adminConfig.goalPriority.generalSettings.backPassOnly
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        if "reallocate" not in userInput:
            userInput.reallocate = False
        if version == "4" and "isNearTermVolatility" not in userInput:
            userInput.isNearTermVolatility = False
        if version == "4" and "isNewRiskProfile" not in userInput:
            userInput.isNearTermVolatility = False
        wealth_path_probs = []
        if adminConfig.goalPriority.generalSettings.additionalWealthPaths == "Yes":
            if userInput.wealthPathProbabilities is None:
                wealth_path_probs.append(adminConfig.goalPriority.generalSettings.pessimisticPathProbability)
                wealth_path_probs.append(adminConfig.goalPriority.generalSettings.optimisticPathProbability)
            else:
                wealth_path_probs = userInput.wealthPathProbabilities

        if adminConfig.goalPriority.probabilityThresholds:
            derisking_prob_thresh = {
                "min_prob1": adminConfig.goalPriority.probabilityThresholds[0].labelValue,
                "max_prob1": adminConfig.goalPriority.probabilityThresholds[0].value,
                "threshold1": adminConfig.goalPriority.probabilityThresholds[0].val,
                "min_prob2": adminConfig.goalPriority.probabilityThresholds[1].labelValue,
                "max_prob2": adminConfig.goalPriority.probabilityThresholds[1].value,
                "threshold2": adminConfig.goalPriority.probabilityThresholds[1].val,
                "min_prob3": adminConfig.goalPriority.probabilityThresholds[2].labelValue,
                "max_prob3": adminConfig.goalPriority.probabilityThresholds[2].value,
                "threshold3": adminConfig.goalPriority.probabilityThresholds[2].val,
            }
        else:
            derisking_prob_thresh = {
                "min_prob1": 0.0,
                "max_prob1": 0.9,
                "threshold1": 0.00075,
                "min_prob2": 0.90,
                "max_prob2": 1.00,
                "threshold2": 0.0015,
                "min_prob3": 0.65,
                "max_prob3": 0.90,
                "threshold3": 0.00075,
            }
        newPipePayload = {
            "user_profile": {
                "participant_id": userInput.participantID,
                "plan_ID": userInput.planID,
                "source_ID": userInput.sourceID,
                "last_realloc_prob": userInput.lastReallocationProbability,
                "init_inv": init_inv,
                "infusions": infusions,
                "curr_date": curr_date,
                "curr_wealth": curr_wealth,
                "curr_port_id": curr_port_id,
                "loss_amt": loss_amt,
                "rebalancing": rebalancing,
                "cashflow_date": cashflow_date,
                "infusion_type": infusion_type,
                "scenario_type": scenario_type,
                "goal_profile_list": goal_profile_list,
                "risk_override": risk_override,
                "is_new_goal_priority": userInput.isNewGoalPriority,
                "is_new_investment_tenure": userInput.isNewInvestmentTenure,
                "reallocate": userInput.reallocate,
                "is_near_term_volatality": userInput.isNearTermVolatility,
                "use_age_based_cap": userInput.useAgeBasedCap or False,
                "wealth_path_probs": wealth_path_probs if wealth_path_probs else None,
            },
            "pipe_config": {
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                "useCase": adminConfig.goalPriority.generalSettings.useCase,
                # "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                "realloc_schedules": realloc_schedules,
                "exec_change": exec_change,
                "swing_constraint": swing_constraint,
                "swing": swing,
                "safeguard": safeguard,
                "downside_protect": downside_protect,
                "protect_thd": protect_thd,
                "goal_priority": goal_priority,
                "downside_alternate_max_goal": downside_alternate_max_goal,
                "get_path": get_path,
                "realistic_goal_prob": realistic_goal_prob,
                "infln": infln,
                "sigma_thd": sigma_thd,
                "nodes_per_sd": nodes_per_sd,
                "inf_measure": inf_measure,
                "irr_thresh": irr_thresh,
                "safeguard_min": safeguard_min,
                "short_term_port_maxindex": short_term_port_maxindex,
                "goal_priority_prob_list": goal_priority_prob_list,
                "goal_drop_priority": goal_drop_priority,
                "LT_Factor": LT_Factor,
                "long_tenure_thresh": long_tenure_thresh,
                "irr_perf_thd": irr_perf_thd,
                "alt_nodes_per_sd": alt_nodes_per_sd,
                "alt_sigma_thd": alt_sigma_thd,
                "topup_recommendation": topup_recommendation,
                "tenure_recommendation": tenure_recommendation,
                "back_pass_only": back_pass_only,
                "short_term_tenure": shortTermGoalTenure,
                "short_term_port_maxindex": short_term_port_maxindex,
                "short_term_tenure_retirement": shortTermRetirementGoalTenure,
                "short_term_port_maxindex_retirement": short_term_port_maxindex_retirement,
                "dec_port_maxindex": dec_port_maxindex,
                "max_age": max_age,
                "grid_freq": grid_freq,
                "adjust_fees": adjust_fees,
                "derisking_prob_thresh": derisking_prob_thresh,
                "goalDropStep": adminConfig.goalPriority.generalSettings.goalDropStep,
                "decFactor": float(adminConfig.goalPriority.generalSettings.goalDropStepSize) if adminConfig.goalPriority.generalSettings.goalDropStepSize else 0.25,
                "maxTenureDropLimit": float(adminConfig.goalPriority.generalSettings.maxTenureDropLimit) if adminConfig.goalPriority.generalSettings.maxTenureDropLimit else 0.5,
                "heuristics": adminConfig.goalPriority.generalSettings.heuristics or False
            },
            "port_dict": port_dict,
            "request_id": userInput.request_id,
        }
        newPipePayload = DictDefault(newPipePayload)
        if userInput.useAgeBasedCap is True:
            newPipePayload["age_based_risk_mapper"] = actuarialData.ageBasedEquityCap

        if version == "4":
            if current_age is None or current_age >= 0:
                newPipePayload.user_profile.current_age = current_age
            if retirement_age is None or retirement_age >= 0:
                newPipePayload.user_profile.retirement_age = retirement_age
            # delete it if there only in case of older versions this required in user_profile level
            if "scenario_type" in newPipePayload.user_profile:
                del newPipePayload["user_profile"]["scenario_type"]
            newPipePayload.user_profile.debug = userInput.debug or False
            if userInput.accountsCashflowList:
                del newPipePayload.user_profile["infusions"]
                newPipePayload.user_profile["accountsCashflowList"] = userInput.accountsCashflowList
        if not safeguard:
            del newPipePayload.pipe_config["safeguard_min"]
        if version == "4":
            newPipePayload["user_profile"]["is_new_goal"] = userInput.isNewGoal
            newPipePayload["user_profile"]["is_new_risk_profile"] = userInput.isNewRiskProfile
            newPipePayload["user_profile"]["calibrateGoalRec"] = userInput.calibrateGoalRec or False
            newPipePayload["user_profile"]["last_reallocation_date"] = userInput.lastReallocationDate
        else:
            newPipePayload["user_profile"]["is_new_goal"] = None
            newPipePayload["user_profile"]["is_new_risk_profile"] = userInput.isNewRTQ
        return {"error": None, "data": newPipePayload}
    except Exception as e:
        print(e)
        return {"error": str(e), "data": None}


def generateAdvisorEnginePayload_v4(userInput, adminConfig, portfolios, actuarialData, version="stable", ptf={}):
    # * eslint-disable camelcase */
    try:
        init_inv = userInput.initialInvestment
        infusions = userInput.infusions
        curr_date = userInput.currDate or datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y")
        goal_profile_list = userInput.goal_profile_list
        cashflow_date = userInput.cashflow_date
        if version == "v4":
            goalProfileList = {
                "payload": userInput.goalProfileList,
            }
            goal_profile_list = converToSnakeCase(goalProfileList.get("payload"))
            cashflow_date = userInput.cashflowDate

        curr_port_id = userInput.currentPortfolioId
        if curr_port_id is not None and curr_port_id < 1:
            curr_port_id = None
        curr_wealth = userInput.currentWealth

        scenario_type = userInput.scenario_type
        infusion_type = userInput.infusion_type

        # const currDateSplit = curr_date.valueOf().split('-');_
        # const momentCurrDate = moment(currDateSplit[2] + currDateSplit[1] + currDateSplit[0]);
        shortTermGoalTenure = adminConfig.portfolioConfig.shortTermGoalTenure or 3
        shortTermRetirementGoalTenure = adminConfig.portfolioConfig.shortTermRetirementGoalTenure or 3
        # useFTPortfolios = adminConfig.portfolioConfig.usingFtPortfolio or False

        portfolioMapping = adminConfig.portfolioConfig.portfolioMapping
        grid_freq = adminConfig.goalPriority.generalSettings.gridFrequency or None
        risk_override = userInput.riskOverride or False

        # getPath = userInput.getPath
        rebalancing = userInput.rebalancing
        if version == "v4":
            rebalancing = userInput.reallocationFreq
            scenario_type = userInput.scenarioType
            infusion_type = userInput.infusionType
        current_age = userInput.currentAge
        retirement_age = userInput.retirementAge
        max_age = adminConfig.goalPriority.generalSettings.maxAge or 120
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        reallocationDatesByFrequency = adminConfig.allocationConfiguration.reallocationDatesByFrequency or {}
        reallocationDates = []
        if rebalancing == "yearly":
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
        elif rebalancing == "half-yearly":
            reallocationDates = reallocationDatesByFrequency["halfyearly"]
            rebalancing = "half-yearly_"
        elif rebalancing == "quarterly":
            reallocationDates = reallocationDatesByFrequency["quarterly"]
            rebalancing = "quarterly_"
        else:
            reallocationDates = reallocationDatesByFrequency["yearly"]
            rebalancing = "yearly_"
        reallocation_date_format = "%a %b %d %Y"
        realloc_schedules = []
        for dt in reallocationDates:
            t = datetime.datetime.strptime(dt, reallocation_date_format)
            realloc_schedules.append(
                datetime.datetime.strftime(datetime.datetime(int(curr_date.split("-")[2]), t.month, t.day), "%d-%m-%Y")
            )

        # TODO to fix in future
        # isRiskOn = False
        # //TODO to fix in future
        ifNewRiskProfile = False
        ifNewInvestmentTenure = False
        ifNearTermVolatility = False
        ifGoalPriorityChanged = False
        ifNewGoal = False
        ifWantsToReallocate = False
        for triggers in adminConfig.allocationConfiguration.reallocationTriggers:
            if triggers.name == "newRiskProfile" and triggers.value is True:
                ifNewRiskProfile = True
            if triggers.name == "changesInvestmentTenure" and triggers.value is True:
                ifNewInvestmentTenure = True
            if triggers.name == "newGoal" and triggers.value is True:
                ifNewGoal = True
            if triggers.name == "riskIndicatorFlashes" and triggers.value is True:
                ifNearTermVolatility = True
            if triggers.name == "rePrioritizesGoal" and triggers.value is True:
                ifGoalPriorityChanged = True
            if triggers.name == "wantsToReallocate" and triggers.value is True:
                ifWantsToReallocate = True
        lossThresholdValueForPriorityNeed = list(
            filter(lambda e: e.name == "need", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWant = list(
            filter(lambda e: e.name == "want", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWish = list(
            filter(lambda e: e.name == "wish", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        levelsOfGoalPriorityNeed = list(filter(lambda e: e.name == "need", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWant = list(filter(lambda e: e.name == "want", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWish = list(filter(lambda e: e.name == "wish", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.probabilityLevels)
        )[0]
        goalModificationNeed = list(filter(lambda e: e.name == "need", adminConfig.goalPriority.goalModification))[0]
        goalModificationWant = list(filter(lambda e: e.name == "want", adminConfig.goalPriority.goalModification))[0]
        goalModificationWish = list(filter(lambda e: e.name == "wish", adminConfig.goalPriority.goalModification))[0]
        goalModificationDream = list(filter(lambda e: e.name == "dream", adminConfig.goalPriority.goalModification))[0]
        # goalModificationDesire = list(
        #     filter(lambda e: e.name == "desire", adminConfig.goalPriority.goalModification)
        # )[0]
        realistic_goal_prob = adminConfig.goalPriority.generalSettings.unrealisticProbability
        # TODO Fix in future
        # For now always select risk on portfolios
        if not portfolios or (not portfolios[1]):
            raise ValueError("Default risk on portfolios not found.")

        # change logic to use portfolios rather than user input
        usedPortfolios = portfolios.portfoliosRiskOn
        maximumDecumulationPortMaxIndex = portfolios.maximumDecumulationPortMaxIndex
        maximumShortTermPortMaxIndex = portfolios.maximumShortTermPortMaxIndex
        maximumShortTermRetirementPortMaxIndex = portfolios.maximumShortTermRetirementPortMaxIndex
        configRiskType = "None"
        if userInput.riskProfile:
            sanitizedPortfolioMapping = dict((key.lower(), val) for key, val in portfolioMapping.items())
            riskProfileInLowerCase = userInput.riskProfile.lower()
            configRiskType = sanitizedPortfolioMapping.get(riskProfileInLowerCase)

        allowedProfiles = []
        if configRiskType == "VeryConservative":
            # allowedProfiles = ["VeryConservative"]
            allowedProfiles = ptf["veryConservativeLimits"]
        elif configRiskType == "Conservative":
            # allowedProfiles = ["VeryConservative", "Conservative"]
            allowedProfiles = ptf["conservativeLimits"]
        elif configRiskType == "ConservativelyModerate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate"]
            allowedProfiles = ptf["conservativelyModerateLimits"]
        elif configRiskType == "Moderate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate", "Moderate"]
            allowedProfiles = ptf["moderateLimits"]
        elif configRiskType == "ModeratelyAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            # ]
            allowedProfiles = ptf["moderatelyAggressivelLimits"]
        elif configRiskType == "Aggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            # ]
            allowedProfiles = ptf["aggressiveLimits"]
        elif configRiskType == "VeryAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            #     "VeryAggressive",
            # ]
            allowedProfiles = ptf["veryAggressiveLimits"]
        else:
            allowedProfiles = []
        if userInput.useAgeBasedCap:
            portfolio_nos = range(1, len(portfolios.useAgeBasedCapPortfoliosRiskOn) + 1)

            expected_returns = list(
                map(lambda e: getattr(e, "portfolio_return") / 100, portfolios.useAgeBasedCapPortfoliosRiskOn)
            )
            expected_risks = list(map(lambda e: e.risk / 100, portfolios.useAgeBasedCapPortfoliosRiskOn))
            asset_allocations = list(map(lambda e: e.assetAllocation, portfolios.useAgeBasedCapPortfoliosRiskOn))
            fees_adjuster_data = list(map(lambda e: e.feesAdjuster, portfolios.useAgeBasedCapPortfoliosRiskOn))
        else:
            # expected_returns = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            # expected_risks = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            # asset_allocations = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            # fees_adjuster_data = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # fees_adjuster_data = list(map(lambda e: e.feesAdjuster, fees_adjuster_data))
            portfolio_nos = [
                [p.id for p in portfolios.useAgeBasedCapPortfoliosRiskOn].index(value.id) + 1
                for index, value in enumerate(usedPortfolios)
                if (lambda e: allowedProfiles and e.id in allowedProfiles)(value)
            ]
            expected_returns = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            expected_risks = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            asset_allocations = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            fees_adjuster_data = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            fees_adjuster_data = list(map(lambda e: e.feesAdjuster, fees_adjuster_data))

        short_term_port_maxindex = None
        dec_port_maxindex = None
        if maximumShortTermPortMaxIndex > 0:
            short_term_port_maxindex = maximumShortTermPortMaxIndex
        short_term_port_maxindex_retirement = None
        if maximumShortTermRetirementPortMaxIndex > 0:
            short_term_port_maxindex_retirement = maximumShortTermRetirementPortMaxIndex
        dec_port_maxindex = None
        if maximumDecumulationPortMaxIndex > 0:
            dec_port_maxindex = maximumDecumulationPortMaxIndex
        port_dict = []
        for ret, risk, asset_allocation, portfolio_no in zip(
            expected_returns, expected_risks, asset_allocations, portfolio_nos
        ):
            port_data = {
                "mu": round(ret, 4) if ret is not None else ret,
                "sigma": round(risk, 4) if risk is not None else risk,
                "equity": asset_allocation["equity"],
                "bond": asset_allocation["bond"],
                "money_market": asset_allocation["money_market"],
                "id": portfolio_no,
            }
            if adjust_fees and adjust_fees.lower() == "variable":
                port_data.update({"fees_adjuster": fees_adjuster_data})
            elif adjust_fees and adjust_fees.lower() == "common":
                port_data.update({"fees_adjuster": adminConfig.goalPriority.generalSettings.annualInBPS})
            port_dict.append(port_data)

        downside_alternate_max_goal = False
        goal_priority = False
        if adminConfig.goalPriority.generalSettings.downsideProtection == "Maximize Goal Probability":
            downside_alternate_max_goal = True
        if downside_alternate_max_goal is True:
            goal_priority = True
        loss_amt = None
        if userInput.lossThreshold is not None:
            loss_amt = userInput.lossThreshold
        exec_change = False
        if version != "v4" and userInput.isNewRTQ and ifNewRiskProfile:
            exec_change = True
        if version == "v4" and userInput.isNewRiskProfile and ifNewRiskProfile:
            exec_change = True
        if userInput.isNewInvestmentTenure and ifNewInvestmentTenure:
            exec_change = True
        if userInput.isNearTermVolatility and ifNearTermVolatility:
            exec_change = True
        if userInput.isNewGoalPriority and ifGoalPriorityChanged:
            exec_change = True
        if version == "v4" and userInput.isNewGoal and ifNewGoal:
            exec_change = True
        if userInput.reallocate and ifWantsToReallocate:
            exec_change = True
        if curr_date in realloc_schedules:
            exec_change = True
        LT_Factor = {
            "Acc_Need": lossThresholdValueForPriorityNeed.accumulation,
            "Acc_Want": lossThresholdValueForPriorityWant.accumulation,
            "Acc_Wish": lossThresholdValueForPriorityWish.accumulation,
            "Acc_Dream": lossThresholdValueForPriorityDream.accumulation,
            "Dec_Need": lossThresholdValueForPriorityNeed.decumulation,
            "Dec_Want": lossThresholdValueForPriorityWant.decumulation,
            "Dec_Wish": lossThresholdValueForPriorityWish.decumulation,
            "Dec_Dream": lossThresholdValueForPriorityDream.decumulation,
        }

        goal_priority_prob_list = {
            "Need": levelsOfGoalPriorityNeed.value,
            "Want": levelsOfGoalPriorityWant.value,
            "Wish": levelsOfGoalPriorityWish.value,
            "Dream": levelsOfGoalPriorityDream.value,
        }
        goal_drop_priority = {
            "Need": goalModificationNeed.value,
            "Want": goalModificationWant.value,
            "Wish": goalModificationWish.value,
            "Dream": goalModificationDream.value,
            # "Desire": goalModificationDesire.value,
        }
        get_path = userInput.getPath
        sigma_thd = adminConfig.goalPriority.performance.sigma
        nodes_per_sd = adminConfig.goalPriority.performance.nodesPerSd
        infln = adminConfig.goalPriority.generalSettings.inflation
        inf_measure = None
        if adminConfig.goalPriority.generalSettings.inflationMeasureForInfusions == "NOMINAL":
            inf_measure = "nominal"
        else:
            inf_measure = "real"
        irr_thresh = adminConfig.goalPriority.performance.irrForRangeAdjustment
        safeguard = adminConfig.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear
        safeguard_min = adminConfig.goalPriority.generalSettings.minPortfoliosForLastYear
        swing_constraint = adminConfig.goalPriority.generalSettings.swingConstraint
        swing = adminConfig.goalPriority.generalSettings.swingConstraintNumber
        downside_protect = adminConfig.goalPriority.lossThreshold
        protect_thd = adminConfig.goalPriority.lossThresholdProbability
        long_tenure_thresh = adminConfig.goalPriority.performance.longTenureThreshold or 30
        irr_perf_thd = adminConfig.goalPriority.performance.irrPerformanceThreshold or 0.0339
        alt_nodes_per_sd = adminConfig.goalPriority.performance.altNodesPerSd or 4
        alt_sigma_thd = adminConfig.goalPriority.performance.alternativeSigma or 4
        topup_recommendation = adminConfig.goalPriority.generalSettings.recommendTopUpInfusion
        tenure_recommendation = adminConfig.goalPriority.generalSettings.recommendTenure
        back_pass_only = adminConfig.goalPriority.generalSettings.backPassOnly
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        if "reallocate" not in userInput:
            userInput.reallocate = False
        if version == "v4" and "isNearTermVolatility" not in userInput:
            userInput.isNearTermVolatility = False
        if version == "v4" and "isNewRiskProfile" not in userInput:
            userInput.isNearTermVolatility = False
        wealth_path_probs = []
        if adminConfig.goalPriority.generalSettings.additionalWealthPaths == "Yes":
            if userInput.wealthPathProbabilities is None:
                wealth_path_probs.append(adminConfig.goalPriority.generalSettings.pessimisticPathProbability)
                wealth_path_probs.append(adminConfig.goalPriority.generalSettings.optimisticPathProbability)
            else:
                wealth_path_probs = userInput.wealthPathProbabilities

        if adminConfig.goalPriority.probabilityThresholds:
            derisking_prob_thresh = {
                "min_prob1": adminConfig.goalPriority.probabilityThresholds[0].labelValue,
                "max_prob1": adminConfig.goalPriority.probabilityThresholds[0].value,
                "threshold1": adminConfig.goalPriority.probabilityThresholds[0].val,
                "min_prob2": adminConfig.goalPriority.probabilityThresholds[1].labelValue,
                "max_prob2": adminConfig.goalPriority.probabilityThresholds[1].value,
                "threshold2": adminConfig.goalPriority.probabilityThresholds[1].val,
                "min_prob3": adminConfig.goalPriority.probabilityThresholds[2].labelValue,
                "max_prob3": adminConfig.goalPriority.probabilityThresholds[2].value,
                "threshold3": adminConfig.goalPriority.probabilityThresholds[2].val,
            }
        else:
            derisking_prob_thresh = {
                "min_prob1": 0.0,
                "max_prob1": 0.9,
                "threshold1": 0.00075,
                "min_prob2": 0.90,
                "max_prob2": 1.00,
                "threshold2": 0.0015,
                "min_prob3": 0.65,
                "max_prob3": 0.90,
                "threshold3": 0.00075,
            }
        fixed_assets = []
        if userInput.fixedAssets:
            for at in userInput.fixedAssets:
                fixed_assets.append(
                    {
                        "name": at.name,
                        "expectedDateOfLiquidity": at.expectedDateOfLiquidity,
                        "expectedValueAtLiquidity": at.expectedValueAtLiquidity,
                    }
                )
        else:
            fixed_assets = userInput.fixedAssets
        if userInput.assetsHeldAway:
            asset_held_away = [
                {
                    "name": x.name,
                    "currentValue": x.currentValue,
                    "currentComposition": {
                        "equity": x.currentComposition.equity,
                        "debt": x.currentComposition.debt,
                        "other": x.currentComposition.other,
                    },
                    "expectedDateOfConversionToAUM": x.expectedDateOfConversionToAUM,
                }
                for x in userInput.assetsHeldAway
            ]
        else:
            asset_held_away = userInput.assetsHeldAway
        newPipePayload = {
            "user_profile": {
                "participant_id": userInput.participantID,
                "plan_ID": userInput.planID,
                "source_ID": userInput.sourceID,
                "last_realloc_prob": userInput.lastReallocationProbability,
                "init_inv": init_inv,
                "infusions": infusions,
                "curr_date": curr_date,
                "curr_wealth": curr_wealth,
                "curr_port_id": curr_port_id,
                "loss_amt": loss_amt,
                "rebalancing": rebalancing,
                "cashflow_date": cashflow_date,
                "infusion_type": infusion_type,
                "scenario_type": scenario_type,
                "goal_profile_list": goal_profile_list,
                "risk_override": risk_override,
                "is_new_goal_priority": userInput.isNewGoalPriority,
                "is_new_investment_tenure": userInput.isNewInvestmentTenure,
                "reallocate": userInput.reallocate,
                "is_near_term_volatality": userInput.isNearTermVolatility,
                "calibrateGoalRec": userInput.calibrateGoalRec or False,
                "assetsHeldAway": asset_held_away,
                "fixedAssets": fixed_assets,
                "detailed_response": userInput.detailedResponse,
                "use_age_based_cap": userInput.useAgeBasedCap or False,
                "wealth_path_probs": wealth_path_probs if wealth_path_probs else None,
            },
            "pipe_config": {
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                "useCase": adminConfig.goalPriority.generalSettings.useCase,
                # "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                "realloc_schedules": realloc_schedules,
                "exec_change": exec_change,
                "swing_constraint": swing_constraint,
                "swing": swing,
                "safeguard": safeguard,
                "downside_protect": downside_protect,
                "protect_thd": protect_thd,
                "goal_priority": goal_priority,
                "downside_alternate_max_goal": downside_alternate_max_goal,
                "get_path": get_path,
                "realistic_goal_prob": realistic_goal_prob,
                "infln": infln,
                "sigma_thd": sigma_thd,
                "nodes_per_sd": nodes_per_sd,
                "inf_measure": inf_measure,
                "irr_thresh": irr_thresh,
                "safeguard_min": safeguard_min,
                "short_term_port_maxindex": short_term_port_maxindex,
                "goal_priority_prob_list": goal_priority_prob_list,
                "goal_drop_priority": goal_drop_priority,
                "LT_Factor": LT_Factor,
                "long_tenure_thresh": long_tenure_thresh,
                "irr_perf_thd": irr_perf_thd,
                "alt_nodes_per_sd": alt_nodes_per_sd,
                "alt_sigma_thd": alt_sigma_thd,
                "topup_recommendation": topup_recommendation,
                "tenure_recommendation": tenure_recommendation,
                "back_pass_only": back_pass_only,
                "short_term_tenure": shortTermGoalTenure,
                "short_term_port_maxindex": short_term_port_maxindex,
                "short_term_tenure_retirement": shortTermRetirementGoalTenure,
                "short_term_port_maxindex_retirement": short_term_port_maxindex_retirement,
                "dec_port_maxindex": dec_port_maxindex,
                "max_age": max_age,
                "grid_freq": grid_freq,
                "adjust_fees": adjust_fees,
                "derisking_prob_thresh": derisking_prob_thresh,
                "goalDropStep": adminConfig.goalPriority.generalSettings.goalDropStep,
                "decFactor": float(adminConfig.goalPriority.generalSettings.goalDropStepSize) if adminConfig.goalPriority.generalSettings.goalDropStepSize else 0.25,
                "maxTenureDropLimit": float(adminConfig.goalPriority.generalSettings.maxTenureDropLimit) if adminConfig.goalPriority.generalSettings.maxTenureDropLimit else 0.5,
                "heuristics": adminConfig.goalPriority.generalSettings.heuristics or False
            },
            "port_dict": port_dict,
            "request_id": userInput.request_id,
        }
        newPipePayload = DictDefault(newPipePayload)
        if userInput.useAgeBasedCap is True:
            newPipePayload["age_based_risk_mapper"] = actuarialData.ageBasedEquityCap
        if version == "v4":
            if current_age is None or current_age >= 0:
                newPipePayload.user_profile.current_age = current_age
            if retirement_age is None or retirement_age >= 0:
                newPipePayload.user_profile.retirement_age = retirement_age
            # delete it if there only in case of older versions this required in user_profile level
            if "scenario_type" in newPipePayload.user_profile:
                del newPipePayload["user_profile"]["scenario_type"]
            newPipePayload.user_profile.debug = userInput.debug or False
            if userInput.accountsCashflowList:
                del newPipePayload.user_profile["infusions"]
                newPipePayload.user_profile["accountsCashflowList"] = userInput.accountsCashflowList
        if not safeguard:
            del newPipePayload.pipe_config["safeguard_min"]
        if version == "v4":
            newPipePayload["user_profile"]["is_new_goal"] = userInput.isNewGoal
            newPipePayload["user_profile"]["is_new_risk_profile"] = userInput.isNewRiskProfile
            newPipePayload["user_profile"]["last_reallocation_date"] = userInput.lastReallocationDate
        else:
            newPipePayload["user_profile"]["is_new_goal"] = None
            newPipePayload["user_profile"]["is_new_risk_profile"] = userInput.isNewRTQ
        return {"error": None, "data": newPipePayload}
    except Exception as e:
        print(e)
        return {"error": str(e), "data": None}
