def getRiskProfileLabels(portfolioMapping):
    riskProfiles = ""
    flag = ""
    for key in portfolioMapping:
        riskProfiles += f"{flag}'{key}'"
        flag = " or "
    return riskProfiles


def validateIfRiskProfileisRiskProfileValid(portfolioConfig, body, useMapping=True):
    portfolioLevel = portfolioConfig.level
    if "useAgeBasedCap" in body and type(body.useAgeBasedCap) != bool:
            return {"isValid": False, "message": "useAgeBasedCap must be boolean."}        
    if portfolioLevel == "1":
        if not portfolioConfig.portfolioConfig.defaultRiskProfiles:
            return {
                "isRiskProfileValid": False,
                "riskProfileErrorMessage": "Level one risk portfolios are empty in your profile",
            }
        if not body.useAgeBasedCap:
            if "riskProfile" in body and body.riskProfile is not None:
                return {
                    "isRiskProfileValid": False,
                    "riskProfileErrorMessage": f"'{body.riskProfile}' risk profile is not a valid choice.",
                }
        return {"isRiskProfileValid": True, "riskProfileErrorMessage": None}
    if not body.useAgeBasedCap:
        if "riskProfile" not in body or not body.riskProfile:
            return {
                "isRiskProfileValid": False,
                "riskProfileErrorMessage": "riskProfile is a required field",
            }
        if "riskProfile" not in body or type(body.riskProfile) != str:
            return {
                "isRiskProfileValid": False,
                "riskProfileErrorMessage": "riskProfile is mandatory and should be string.",
            }


    portfolioMapping = portfolioConfig.portfolioMapping
    sanitizedPortfolioMapping = dict((key.lower(), val) for key, val in portfolioMapping.items())
    allowedProfiles = []
    if portfolioLevel == "3":
        allowedProfiles = ["Conservative", "Moderate", "Aggressive"]
    elif portfolioLevel == "5":
        allowedProfiles = ["Conservative", "ConservativelyModerate", "Moderate", "ModeratelyAggressive", "Aggressive"]
    elif portfolioLevel == "7":
        allowedProfiles = [
            "VeryConservative",
            "Conservative",
            "ConservativelyModerate",
            "Moderate",
            "ModeratelyAggressive",
            "Aggressive",
            "VeryAggressive",
        ]
    else:
        allowedProfiles = []
    riskProfile = body.riskProfile
    mappedRiskProfile = riskProfile
    if useMapping:
        if type(riskProfile) is str:
            mappedRiskProfile = sanitizedPortfolioMapping.get(riskProfile.lower())
    validRiskProfiles = getRiskProfileLabels(sanitizedPortfolioMapping)
    if not body.useAgeBasedCap:
        if mappedRiskProfile not in allowedProfiles:
            return {
                "isRiskProfileValid": False,
                "riskProfileErrorMessage": f"{riskProfile} risk profile is not a valid choice."
                f"Please select from {validRiskProfiles}",
            }
    veryConservativeLimits = portfolioConfig.portfolioConfig.veryConservativeRiskProfiles
    conservativeLimits = portfolioConfig.portfolioConfig.conservativeRiskProfiles
    conservativelyModerateLimits = portfolioConfig.portfolioConfig.conservativelyModerateRiskProfiles
    moderateLimits = portfolioConfig.portfolioConfig.moderateRiskProfiles
    moderatelyAggressivelLimits = portfolioConfig.portfolioConfig.moderatelyAggressiveRiskProfiles
    aggressiveLimits = portfolioConfig.portfolioConfig.aggressiveRiskProfiles
    veryAggressiveLimits = portfolioConfig.portfolioConfig.veryAggressiveRiskProfiles
    if mappedRiskProfile == "VeryConservative" and not veryConservativeLimits:
        return {
            "isRiskProfileValid": False,
            "riskProfileErrorMessage": f"{riskProfile} portfolios are not available in your profile",
        }
    if mappedRiskProfile == "Conservative" and not conservativeLimits:
        return {
            "isRiskProfileValid": False,
            "riskProfileErrorMessage": f"{riskProfile} portfolios are not available in your profile",
        }
    if mappedRiskProfile == "ConservativelyModerate" and not conservativelyModerateLimits:
        return {
            "isRiskProfileValid": False,
            "riskProfileErrorMessage": f"{riskProfile} portfolios are not available in your profile",
        }
    if mappedRiskProfile == "Moderate" and not moderateLimits:
        return {
            "isRiskProfileValid": False,
            "riskProfileErrorMessage": f"{riskProfile} portfolios are not available in your profile",
        }
    if mappedRiskProfile == "ModeratelyAggressive" and not moderatelyAggressivelLimits:
        return {
            "isRiskProfileValid": False,
            "riskProfileErrorMessage": f"{riskProfile} portfolios are not available in your profile",
        }
    if mappedRiskProfile == "Aggressive" and not aggressiveLimits:
        return {
            "isRiskProfileValid": False,
            "riskProfileErrorMessage": f"{riskProfile} portfolios are not available in your profile",
        }
    if mappedRiskProfile == "VeryAggressive" and not veryAggressiveLimits:
        return {
            "isRiskProfileValid": False,
            "riskProfileErrorMessage": f"{riskProfile} portfolios are not available in your profile",
        }
    return {
        "isRiskProfileValid": True,
        "riskProfileErrorMessage": None,
    }
