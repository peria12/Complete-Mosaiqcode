from goelib.api.shared.common import isDateFormatValid
import datetime
from collections import abc
from collections import Counter
from goelib.api.shared.common import DictDefault


def validateGoalProfileDates(goalProfileList, startDate, currDate=None):
    returnPayload = {"isValid": True, "message": ""}
    currentDate = datetime.datetime.strptime(currDate, "%d-%m-%Y") if currDate else datetime.datetime.now()
    startDate = datetime.datetime.strptime(startDate, "%d-%m-%Y")
    for profile in goalProfileList:
        goalId = profile.goal_id
        endDate = datetime.datetime.strptime(profile.endDate, "%d-%m-%Y")
        if currentDate > endDate:
            returnPayload = {"isValid": False, "message": f"currDate must be less than endDate for goal_id {goalId}."}
            break
        if startDate > endDate:
            returnPayload = {"isValid": False, "message": f"start_date must be less than endDate for goal_id {goalId}."}
        break
    return returnPayload


def validateWealthSplitterPayload(payload):  # pragma: no cover
    """Validate wealth splitter payload"""
    initial_lumpsum = payload.initial_lumpsum
    riskProfile = payload.riskProfile
    goal_profile_list = payload.goal_profile_list
    cashflow_type = payload.cashflow_type
    start_date = payload.start_date
    if not initial_lumpsum or type(initial_lumpsum) not in [float, int]:
        return {
            "isValid": False,
            "message": "initial_lumpsum must be a number",
        }
    if riskProfile not in ["Conservative", "Moderate", "Aggressive"]:
        return {
            "isValid": False,
            "message": "riskProfile must be one of Conservative, Moderate, and Aggressive.",
        }
    if not cashflow_type or (cashflow_type not in ["yearly", "monthly"]):
        return {
            "isValid": False,
            "message": "cashflow_type must be a number",
        }
    if "start_date" not in payload:
        return {"isValid": False, "message": "start_date is required."}
    if type(start_date) is not str or isDateFormatValid(start_date):
        return {
            "isValid": False,
            "message": "Valid date range for start_date should be between 1-01-1800 to 31-12-2399",
        }
    if "goal_profile_list" not in payload or not isinstance(goal_profile_list, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goal_profile_list is required and must be array",
        }

    try:
        for x in goal_profile_list:
            if not x.goalValue or type(x.goalValue) not in [float, int] or (x.goalValue <= 0):
                return {"isValid": False, "message": "goalValue must be a number greater than 0."}
            if not x.purpose or not isinstance(x.purpose, str):
                return {
                    "isValid": False,
                    "message": "purpose must be a string",
                }
            if not x.goalPriority or (x.goalPriority not in ["Need", "Want", "Wish", "Dream"]):
                return {
                    "isValid": False,
                    "message": "goalPriority must be one of Need, Want, Wish, and Dream.",
                }
            if not x.cashflow or not type(x.cashflow) is not abc.MutableSequence:
                return {
                    "isValid": False,
                    "message": "cashflow must be an array",
                }
            if "endDate" not in x:
                return {"isValid": False, "message": "endDate is required."}
            if type(x.endDate) is not str or not isDateFormatValid(x.endDate):
                return {
                    "isValid": False,
                    "message": "Valid date range  for endDate should be between 1-01-1800 to 31-12-2399",
                }

            if not x.goal_id or type(x.goal_id) is not str:
                return {
                    "isValid": False,
                    "message": "goal_id must be a string",
                }

    except Exception as e:
        raise (e)

    return {
        "isValid": True,
        "message": None,
    }


def validateWealthSplitterPayloadV2(payload):  # pragma: no cover
    """
    Validates Wealth splitter payload version2.
    """
    initial_lumpsum = payload.initial_lumpsum
    riskProfile = payload.riskProfile
    goal_profile_list = payload.goal_profile_list
    start_date = payload.start_date
    currDate = payload.currDate
    # if "useAgeBasedCap" in payload and type(payload.useAgeBasedCap) != bool:
    #     return {"isValid": False, "message": "useAgeBasedCap must be boolean."}

    if not initial_lumpsum or type(initial_lumpsum) is not [float, int]:
        return {
            "isValid": False,
            "message": "initial_lumpsum must be a number",
        }

    if not riskProfile or (riskProfile not in ["Conservative", "Moderate", "Aggressive"]):
        return {
            "isValid": False,
            "message": "riskProfile must be one of Conservative, Moderate, and Aggressive.",
        }
    if "start_date" not in payload:
        return {"isValid": False, "message": "start_date is required."}
    if type(start_date) is not str or not isDateFormatValid(start_date):
        return {
            "isValid": False,
            "message": "Valid date range for start_date should be between 1-01-1800 to 31-12-2399",
        }
    if currDate and (type(currDate) is not str or not isDateFormatValid(currDate)):
        return {
            "isValid": False,
            "message": "Valid date range for currDate should be between 1-01-1800 to 31-12-2399",
        }
    if "goal_profile_list" not in payload or not isinstance(goal_profile_list, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goal_profile_list is required and must be array",
        }

    try:
        for x in goal_profile_list:
            if not x.purpose or type(x.purpose) is not str:
                return {
                    "isValid": False,
                    "message": "purpose must be a string",
                }
            if not x.goalPriority or (x.goalPriority not in ["Need", "Want", "Wish", "Dream"]):
                return {
                    "isValid": False,
                    "message": "goalPriority must be one of Need, Want, Wish, and Dream.",
                }
            if not x.cashflowType or (x.cashflowType not in ["yearly", "monthly"]):
                return {
                    "isValid": False,
                    "message": "cashflowType must be one of yearly or monthly.",
                }
            if not x.scenarioType or (x.scenarioType not in ["regular", "retirement"]):
                return {
                    "isValid": False,
                    "message": "scenarioType must be one of regular or retirement.",
                }
            if not x.cashflow or not type(x.cashflow) is abc.MutableSequence:
                return {
                    "isValid": False,
                    "message": "cashflow must be an array",
                }
            if "endDate" not in x:
                return {"isValid": False, "message": "endDate is required."}
            if type(x.endDate) is not str or not isDateFormatValid(x.endDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399",
                }
            if not x.goal_id or type(x.goal_id) != str:
                return {
                    "isValid": False,
                    "message": "goal_id must be a string",
                }

            if not x.goalValue or type(x.goalValue) not in [float, int] or (x.goalValue <= 0):
                return {
                    "isValid": False,
                    "message": "goalValue must be a number greater than 0.",
                }
    except Exception as e:
        raise e
    return {
        "isValid": True,
        "message": None,
    }


def generateWealthSplitterPayload(userInput, adminConfig, portfolios, actuarialData, version="stable", ptf={}):
    try:
        exec_change = True
        swing_constraint = adminConfig.goalPriority.generalSettings.swingConstraint
        swing = adminConfig.goalPriority.generalSettings.swingConstraintNumber
        safeguard = adminConfig.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear
        downside_protect = adminConfig.goalPriority.lossThreshold
        protect_thd = adminConfig.goalPriority.lossThresholdProbability
        goal_priority = False
        downside_alternate_max_goal = False
        if adminConfig.goalPriority.generalSettings.downsideProtection == "Maximize Goal Probability":
            downside_alternate_max_goal = True
        if downside_alternate_max_goal is True:
            goal_priority = True
        goal_priority_prob = 0.85
        infln = adminConfig.goalPriority.generalSettings.inflation
        sigma_thd = adminConfig.goalPriority.performance.sigma
        nodes_per_sd = adminConfig.goalPriority.performance.nodesPerSd
        long_tenure_thresh = adminConfig.goalPriority.performance.longTenureThreshold or 30
        irr_perf_thd = adminConfig.goalPriority.performance.irrPerformanceThreshold or 0.0339
        alt_nodes_per_sd = adminConfig.goalPriority.performance.altNodesPerSd or 4
        alt_sigma_thd = adminConfig.goalPriority.performance.alternativeSigma or 4
        topup_recommendation = adminConfig.goalPriority.generalSettings.recommendTopUpInfusion
        tenure_recommendation = adminConfig.goalPriority.generalSettings.recommendTenure
        back_pass_only = adminConfig.goalPriority.generalSettings.backPassOnly
        inf_measure = None
        if adminConfig.goalPriority.generalSettings.inflationMeasureForInfusions == "NOMINAL":
            inf_measure = "nominal"
        else:
            inf_measure = "real"
        irr_thresh = adminConfig.goalPriority.performance.irrForRangeAdjustment
        safeguard_min = adminConfig.goalPriority.generalSettings.minPortfoliosForLastYear
        # useFTPortfolios = adminConfig.portfolioConfig.usingFtPortfolio or False
        grid_freq = adminConfig.goalPriority.generalSettings.gridFrequency or None
        # isRiskOn = adminConfig.goalPriority.performance.riskOverlay or False
        portfolioMapping = adminConfig.portfolioConfig.portfolioMapping
        risk_override = userInput.riskOverride or False
        cashflow_type = userInput.cashflow_type or None
        engaged_participant = True
        if userInput.engagedParticipant is not None:
            engaged_participant = userInput.engagedParticipant
        curr_date = userInput.currDate or datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y")
        reallocationDates = adminConfig.allocationConfiguration.reallocationDatesByFrequency["yearly"][0]
        reallocationDates = datetime.datetime.strptime(reallocationDates, "%a %b %d %Y")
        reallocationDates = reallocationDates.replace(year=int(curr_date.split("-")[2]))
        realloc_schedules = datetime.datetime.strftime(reallocationDates, "%d-%m-%Y")
        start_date = userInput.start_date
        goal_profile_list = userInput.goal_profile_list or []
        if version == "4":
            start_date = userInput.startDate
            goal_profile_list = userInput.goalProfileList
        shortTermGoalTenure = adminConfig.portfolioConfig.shortTermGoalTenure or 3
        shortTermRetirementGoalTenure = adminConfig.portfolioConfig.shortTermRetirementGoalTenure or 3
        shortTermRetirementGoalTenureUnengaged = adminConfig.portfolioConfig.shortTermRetirementGoalTenureUnengaged or 5
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees

        number_of_goals = len(goal_profile_list)
        goal_list = []
        purpose_list = []
        priority_list = []
        goal_id_list = []
        cashflow_list = []
        end_date_list = []
        port_dict_list = []
        cashflow_type_list = []
        priority_prob_list = []
        cashflow_date_list = []
        scenario_type_list = []
        # support v3
        # curr_portfolio_list = []
        # curr_probability_list = []
        curr_wealth_list = []
        loss_amt_list = []
        lossThresholdValueForPriorityNeed = list(
            filter(lambda e: e.name == "need", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWant = list(
            filter(lambda e: e.name == "want", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityWish = list(
            filter(lambda e: e.name == "wish", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        lossThresholdValueForPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.lossthresholdValues)
        )[0]
        levelsOfGoalPriorityNeed = list(filter(lambda e: e.name == "need", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWant = list(filter(lambda e: e.name == "want", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityWish = list(filter(lambda e: e.name == "wish", adminConfig.goalPriority.probabilityLevels))[
            0
        ]
        levelsOfGoalPriorityDream = list(
            filter(lambda e: e.name == "dream", adminConfig.goalPriority.probabilityLevels)
        )[0]
        realistic_goal_prob = adminConfig.goalPriority.generalSettings.unrealisticProbability
        LT_Factor = {
            "Acc_Need": lossThresholdValueForPriorityNeed.accumulation,
            "Acc_Want": lossThresholdValueForPriorityWant.accumulation,
            "Acc_Wish": lossThresholdValueForPriorityWish.accumulation,
            "Acc_Dream": lossThresholdValueForPriorityDream.accumulation,
            "Dec_Need": lossThresholdValueForPriorityNeed.decumulation,
            "Dec_Want": lossThresholdValueForPriorityWant.decumulation,
            "Dec_Wish": lossThresholdValueForPriorityWish.decumulation,
            "Dec_Dream": lossThresholdValueForPriorityDream.decumulation,
        }
        goal_priority_prob_list = {
            "Need": levelsOfGoalPriorityNeed.value,
            "Want": levelsOfGoalPriorityWant.value,
            "Wish": levelsOfGoalPriorityWish.value,
            "Dream": levelsOfGoalPriorityDream.value,
        }
        request_type = "initial_wealth_split"
        # support v3
        # TODO Fix in future
        # For now always select risk on portfolios
        if not portfolios or (not portfolios.portfoliosRiskOn) or (len(portfolios.portfoliosRiskOn) == 0):
            raise ValueError("Default risk on portfolios not found.")
        # TODO Fix in future
        maximumDecumulationPortMaxIndex = portfolios.maximumDecumulationPortMaxIndex
        maximumShortTermPortMaxIndex = portfolios.maximumShortTermPortMaxIndex
        maximumShortTermRetirementPortMaxIndex = portfolios.maximumShortTermRetirementPortMaxIndex
        for goal in goal_profile_list:
            x = DictDefault(goal)
            if version == "4":
                goal_id_list.append(x.goalId)
                curr_wealth_list.append(x.currWealth)
            else:
                goal_id_list.append(x.goal_id)
                curr_wealth_list.append(x.curr_wealth)
            goal_list.append(x.goalValue)
            purpose_list.append(x.purpose)
            priorityValue = list(
                filter(lambda e: e.name == x.goalPriority.lower(), adminConfig.goalPriority.probabilityLevels)
            )[0].value
            if version == "lts" or version == "4":
                priority_list.append(x.goalPriority)
            else:
                priority_list.append(priorityValue)
            # //support v3
            # //Temp remove cross goal optimizer
            # // curr_portfolio_list.append(x.curr_portfolio);
            # // curr_probability_list.append(x.curr_probability);
            loss_amt_list.append(x.lossThreshold)
            #   //support v3
            priority_prob_list.append(priorityValue)
            cashflow_type_list.append(x.cashflowType)
            cashflow_date_list.append(x.cashflowDate)
            cashflow_list.append(x.cashflow)
            scenario_type_list.append(x.scenarioType)
            tenure = int(
                (
                    datetime.datetime.strptime(x.endDate, "%d-%m-%Y")
                    - datetime.datetime.strptime(start_date, "%d-%m-%Y")
                ).days
                / 365
            )
            if x.scenarioType == "retirement":
                tenure = int(  # noqa: F841
                    (
                        datetime.datetime.strptime(x.endDate, "%d-%m-%Y")
                        - datetime.datetime.strptime(curr_date, "%d-%m-%Y")
                    ).days
                    / 365
                )
            # //TODO Fix in future
            # //For now always select risk on portfolios
            # //change logic to use portfolios rather than user input
            usedPortfolios = portfolios.portfoliosRiskOn
            # //TODO Fix in future
            configRiskType = "None"
            if userInput.riskProfile:
                sanitizedPortfolioMapping = dict((key.lower(), val) for key, val in portfolioMapping.items())
                riskProfileInLowerCase = userInput.riskProfile.lower()
                configRiskType = sanitizedPortfolioMapping.get(riskProfileInLowerCase)
            allowedProfiles = ["None"]
            if configRiskType:
                allowedProfiles = [configRiskType]
            allowedProfiles = []
            if configRiskType == "VeryConservative":
                # allowedProfiles = ["VeryConservative"]
                allowedProfiles = ptf["veryConservativeLimits"]
            elif configRiskType == "Conservative":
                # allowedProfiles = ["VeryConservative", "Conservative"]
                allowedProfiles = ptf["conservativeLimits"]
            elif configRiskType == "ConservativelyModerate":
                # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate"]
                allowedProfiles = ptf["conservativelyModerateLimits"]
            elif configRiskType == "Moderate":
                # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate", "Moderate"]
                allowedProfiles = ptf["moderateLimits"]
            elif configRiskType == "ModeratelyAggressive":
                # allowedProfiles = [
                #     "VeryConservative",
                #     "Conservative",
                #     "ConservativelyModerate",
                #     "Moderate",
                #     "ModeratelyAggressive",
                # ]
                allowedProfiles = ptf["moderatelyAggressivelLimits"]
            elif configRiskType == "Aggressive":
                # allowedProfiles = [
                #     "VeryConservative",
                #     "Conservative",
                #     "ConservativelyModerate",
                #     "Moderate",
                #     "ModeratelyAggressive",
                #     "Aggressive",
                # ]
                allowedProfiles = ptf["aggressiveLimits"]
            elif configRiskType == "VeryAggressive":
                # allowedProfiles = [
                #     "VeryConservative",
                #     "Conservative",
                #     "ConservativelyModerate",
                #     "Moderate",
                #     "ModeratelyAggressive",
                #     "Aggressive",
                #     "VeryAggressive",
                # ]
                allowedProfiles = ptf["veryAggressiveLimits"]
            else:
                allowedProfiles = []
            if userInput.useAgeBasedCap:
                expected_returns = list(
                    map(lambda e: getattr(e, "portfolio_return") / 100, portfolios.useAgeBasedCapPortfoliosRiskOn)
                )
                expected_risks = list(map(lambda e: e.risk / 100, portfolios.useAgeBasedCapPortfoliosRiskOn))
                asset_allocations = list(map(lambda e: e.assetAllocation, portfolios.useAgeBasedCapPortfoliosRiskOn))
                fees_adjuster_data = list(map(lambda e: e.feesAdjuster, portfolios.useAgeBasedCapPortfoliosRiskOn))
            else:
                # expected_returns = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
                # expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
                # expected_risks = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
                # expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
                # asset_allocations = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
                # asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
                # fees_adjuster_data = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
                # fees_adjuster_data = list(map(lambda e: e.feesAdjuster, fees_adjuster_data))
                portfolio_nos = [
                    [p.id for p in portfolios.useAgeBasedCapPortfoliosRiskOn].index(value.id) + 1
                    for index, value in enumerate(usedPortfolios)
                    if (lambda e: allowedProfiles and e.id in allowedProfiles)(value)
                ]
                expected_returns = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
                expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
                expected_risks = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
                expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
                asset_allocations = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
                asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
                fees_adjuster_data = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
                fees_adjuster_data = list(map(lambda e: e.feesAdjuster, fees_adjuster_data))

            port_dict = []
            for i in range(len(expected_returns)):
                port_data = {
                    "mu": round(expected_returns[i], 4) if expected_returns[i] is not None else expected_returns[i],
                    "sigma": round(expected_risks[i], 4) if expected_risks[i] is not None else expected_risks[i],
                    "equity": asset_allocations[i]["equity"],
                    "bond": asset_allocations[i]["bond"],
                    "money_market": asset_allocations[i]["money_market"],
                    "id": portfolio_nos[i],
                }
                if adjust_fees and adjust_fees.lower() == "variable":
                    port_data.update({"fees_adjuster": fees_adjuster_data[i]})
                elif adjust_fees and adjust_fees.lower() == "common":
                    port_data.update({"fees_adjuster": adminConfig.goalPriority.generalSettings.annualInBPS})
                port_dict.append(port_data)
            end_date_list.append(x.endDate)
            port_dict_list.append(port_dict)
        short_term_port_maxindex = None
        if maximumShortTermPortMaxIndex > 0:
            short_term_port_maxindex = maximumShortTermPortMaxIndex
        short_term_port_maxindex_retirement = None
        if maximumShortTermRetirementPortMaxIndex > 0:
            short_term_port_maxindex_retirement = maximumShortTermRetirementPortMaxIndex
        dec_port_maxindex = None
        if maximumDecumulationPortMaxIndex > 0:
            dec_port_maxindex = maximumDecumulationPortMaxIndex
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        if adminConfig.goalPriority.probabilityThresholds:
            derisking_prob_thresh = {
                "min_prob1": adminConfig.goalPriority.probabilityThresholds[0].labelValue,
                "max_prob1": adminConfig.goalPriority.probabilityThresholds[0].value,
                "threshold1": adminConfig.goalPriority.probabilityThresholds[0].val,
                "min_prob2": adminConfig.goalPriority.probabilityThresholds[1].labelValue,
                "max_prob2": adminConfig.goalPriority.probabilityThresholds[1].value,
                "threshold2": adminConfig.goalPriority.probabilityThresholds[1].val,
                "min_prob3": adminConfig.goalPriority.probabilityThresholds[2].labelValue,
                "max_prob3": adminConfig.goalPriority.probabilityThresholds[2].value,
                "threshold3": adminConfig.goalPriority.probabilityThresholds[2].val,
            }
        else:
            derisking_prob_thresh = {
                "min_prob1": 0.0,
                "max_prob1": 0.9,
                "threshold1": 0.00075,
                "min_prob2": 0.90,
                "max_prob2": 1.00,
                "threshold2": 0.0015,
                "min_prob3": 0.65,
                "max_prob3": 0.90,
                "threshold3": 0.00075,
            }

        wealthSplitterPayload = {
            "goal_profile": {
                "participant_id": userInput.participantID,
                "plan_ID": userInput.planID,
                "source_ID": userInput.sourceID,
                "number_of_goals": number_of_goals,
                "goal_id_list": goal_id_list,
                "goal_list": goal_list,
                "purpose_list": purpose_list,
                "priority_list": priority_list,
                "cashflow_type": cashflow_type,
                "cashflow_list": cashflow_list,
                "start_date": start_date,
                "curr_date": curr_date,
                "end_date_list": end_date_list,
                "realloc_date": [realloc_schedules],
                "port_dict_list": port_dict_list,
            }
        }
        if version == "lts" or version == "4":
            wealthSplitterPayload = {
                "goal_profile": {
                    "participant_id": userInput.participantID,
                    "plan_ID": userInput.planID,
                    "source_ID": userInput.sourceID,
                    "number_of_goals": number_of_goals,
                    "goal_id_list": goal_id_list,
                    "goal_list": goal_list,
                    "purpose_list": purpose_list,
                    "priority_list": priority_list,
                    "cashflow_list": cashflow_list,
                    "start_date": start_date,
                    "curr_date": curr_date,
                    "end_date_list": end_date_list,
                    "realloc_date": [realloc_schedules],
                    "port_dict_list": port_dict_list,
                    "cashflow_type_list": cashflow_type_list,
                    "priority_prob_list": priority_prob_list,
                    "cashflow_date_list": cashflow_date_list,
                    "scenario_type_list": scenario_type_list,
                    "curr_wealth_list": curr_wealth_list,
                    "loss_amt_list": loss_amt_list,
                    "request_type": request_type,
                    "risk_override": risk_override,
                    "engaged_participant": engaged_participant,
                    "use_age_based_cap": userInput.useAgeBasedCap or False,
                },
                "pipe_config": {
                    "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                    if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                    else None,
                    # "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                    "realloc_schedules": [realloc_schedules],
                    "exec_change": exec_change,
                    "swing_constraint": swing_constraint,
                    "swing": swing,
                    "safeguard": safeguard,
                    "downside_protect": downside_protect,
                    "protect_thd": protect_thd,
                    "goal_priority": goal_priority,
                    "downside_alternate_max_goal": downside_alternate_max_goal,
                    "realistic_goal_prob": realistic_goal_prob,
                    "goal_priority_prob": goal_priority_prob,
                    "goal_priority_prob_list": goal_priority_prob_list,
                    "infln": infln,
                    "sigma_thd": sigma_thd,
                    "nodes_per_sd": nodes_per_sd,
                    "inf_measure": inf_measure,
                    "irr_thresh": irr_thresh,
                    "safeguard_min": safeguard_min,
                    "LT_Factor": LT_Factor,
                    "long_tenure_thresh": long_tenure_thresh,
                    "irr_perf_thd": irr_perf_thd,
                    "alt_nodes_per_sd": alt_nodes_per_sd,
                    "alt_sigma_thd": alt_sigma_thd,
                    "topup_recommendation": topup_recommendation,
                    "tenure_recommendation": tenure_recommendation,
                    "back_pass_only": back_pass_only,
                    "short_term_tenure": shortTermGoalTenure,
                    "short_term_port_maxindex": short_term_port_maxindex,
                    "short_term_tenure_retirement": shortTermRetirementGoalTenure,
                    "short_term_tenure_retirement_unengaged": shortTermRetirementGoalTenureUnengaged,
                    "short_term_port_maxindex_retirement": short_term_port_maxindex_retirement,
                    "dec_port_maxindex": dec_port_maxindex,
                    "grid_freq": grid_freq,
                    "adjust_fees": adjust_fees,
                    "derisking_prob_thresh": derisking_prob_thresh,
                },
            }
        if userInput.useAgeBasedCap is True:
            wealthSplitterPayload["age_based_risk_mapper"] = actuarialData.ageBasedEquityCap
        if version == "lts" or version == "4":
            wealthSplitterPayload = DictDefault(wealthSplitterPayload)
            wealthSplitterPayload.goal_profile.debug = userInput.debug if "debug" in userInput else False
            if not safeguard:
                del wealthSplitterPayload.pipe_config["safeguard_min"]

            return {"error": None, "data": wealthSplitterPayload}
    except Exception as e:
        print(e)
        return {"error": str(e), "data": None}


def validateWealthSplitterPayloadV3dot8(payload):
    # currDate = payload.currDate
    goalProfileList = payload.goalProfileList
    startDate = payload.startDate
    riskOverride = payload.riskOverride
    engagedParticipant = payload.engagedParticipant
    if "startDate" not in payload:
        return {
            "isValid": False,
            "message": "startDate is required.",
        }
    if type(startDate) is not str or not isDateFormatValid(startDate):
        return {
            "isValid": False,
            "message": "Valid date range should be startDate be between 1-01-1800 to 31-12-2399",
        }

    if riskOverride and type(riskOverride) is not bool:
        return {
            "isValid": False,
            "message": "riskOverride must be a boolean. When not specificed, default value is false",
        }
    if engagedParticipant is not None and not isinstance(engagedParticipant, bool):
        return {
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true",
        }
    if "goalProfileList" not in payload or not isinstance(goalProfileList, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goalProfileList is required and must be array",
        }
    try:
        goal_ids = dict(Counter([x.goalId for x in goalProfileList if x.goalId]))
        duplicates_goalids = {key: value for key, value in goal_ids.items() if value > 1}
        if duplicates_goalids:
            return {"isValid": False, "message": "Goal ids must be unique."}
        for x in goalProfileList:
            if not x.purpose or type(x.purpose) is not str:
                return {
                    "isValid": False,
                    "message": "purpose must be a string",
                }
            if not x.goalPriority or (x.goalPriority not in ["Need", "Want", "Wish", "Dream"]):
                return {
                    "isValid": False,
                    "message": "goalPriority must be one of Need, Want, Wish, and Dream.",
                }
            if not x.cashflowType or (x.cashflowType not in ["yearly", "monthly"]):
                return {
                    "isValid": False,
                    "message": "cashflowType must be one of yearly or monthly.",
                }
            if not x.scenarioType or (x.scenarioType not in ["regular", "retirement"]):
                return {
                    "isValid": False,
                    "message": "scenarioType must be one of regular or retirement.",
                }

            if not x.cashflow or not type(x.cashflow) is not abc.MutableSequence:
                return {
                    "isValid": False,
                    "message": "cashflow must be an array",
                }
            if "endDate" not in x:
                return {
                    "isValid": False,
                    "message": "endDate is required.",
                }
            if type(x.endDate) is not str or not isDateFormatValid(x.endDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399",
                }
            if "cashflowDate" not in x:
                return {
                    "isValid": False,
                    "message": "cashflowDate is required.",
                }
            if type(x.cashflowDate) is not str or not isDateFormatValid(x.cashflowDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for cashflowDate should be between 1-01-1800 to 31-12-2399",
                }

            if not x.goalId or type(x.goalId) is not str:
                return {
                    "isValid": False,
                    "message": "goalId must be a string",
                }

            if not x.currWealth or type(x.currWealth) not in (float, int) or (x.currWealth < 0):
                return {
                    "isValid": False,
                    "message": "currWealth must be a number",
                }

            if x.goalValue is None or type(x.goalValue) not in (float, int) or (x.goalValue < 0):
                return {
                    "isValid": False,
                    "message": "goalValue must be a number greater than or equal to 0.",
                }

            if (
                "lossThreshold" in x
                and x.lossThreshold is not None
                and (type(x.lossThreshold) not in [float, int] or x.lossThreshold < 0)
            ):
                return {
                    "isValid": False,
                    "message": "lossThreshold must be a number greater than equal to 0 or null",
                }
    except Exception as e:
        return e
    return {
        "isValid": True,
        "message": None,
    }


def validateWealthSplitterPayloadV3(payload, version="3"):
    currDate = payload.currDate
    goal_profile_list = payload.goal_profile_list
    start_date = payload.start_date

    riskOverride = payload.riskOverride
    engagedParticipant = payload.engagedParticipant
    if payload.participantID is not None and type(payload.participantID) not in [str]:
        return {
            "isValid": False,
            "message": "participantID must be a alphanumeric.",
        }
    if isinstance(payload.participantID, str) and not payload.participantID.isalnum():
        return {
            "isValid": False,
            "message": "participantID must be a alphanumeric.",
        }
    if payload.planID is not None and type(payload.planID) not in [str]:
        return {
            "isValid": False,
            "message": "planID must be a alphanumeric.",
        }
    if isinstance(payload.planID, str) and not payload.planID.isalnum():
        return {
            "isValid": False,
            "message": "planID must be a alphanumeric.",
        }
    if payload.sourceID is not None and type(payload.sourceID) not in [str]:
        return {
            "isValid": False,
            "message": "sourceID must be a alphanumeric.",
        }
    if isinstance(payload.sourceID, str) and not payload.sourceID.isalnum():
        return {
            "isValid": False,
            "message": "sourceID must be a alphanumeric.",
        }
    # if "useAgeBasedCap" in payload and type(payload.useAgeBasedCap) != bool:
    #     return {"isValid": False, "message": "useAgeBasedCap must be boolean."}

    if version == "4":
        return validateWealthSplitterPayloadV3dot8(payload)
    if "start_date" not in payload:
        return {
            "isValid": False,
            "message": "start_date is required",
        }
    if type(start_date) is not str or not isDateFormatValid(start_date):
        return {
            "isValid": False,
            "message": "Valid date range for start_date between 1-01-1800 to 31-12-2399",
        }
    if "currDate" in payload and not isDateFormatValid(payload.currDate):
        return {
            "isValid": False,
            "message": "Valid date range for currDate should be between 1-01-1800 to 31-12-2399",
        }
    if riskOverride and type(riskOverride) is not bool:
        return {
            "isValid": False,
            "message": "riskOverride must be a boolean. When not specificed, default value is false",
        }
    if engagedParticipant is not None and not isinstance(engagedParticipant, bool):
        return {
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true",
        }
    if "goal_profile_list" not in payload or not isinstance(goal_profile_list, abc.MutableSequence):
        return {
            "isValid": False,
            "message": "goal_profile_list is required and must be array",
        }
    try:
        goal_ids = dict(Counter([x.goal_id for x in goal_profile_list if x.goal_id]))
        duplicates_goalids = {key: value for key, value in goal_ids.items() if value > 1}
        if duplicates_goalids:
            return {"isValid": False, "message": "Goal ids must be unique."}

        for x in goal_profile_list:
            if not x.purpose or type(x.purpose) is not str:
                return {
                    "isValid": False,
                    "message": "purpose must be a string",
                }
            if not x.goalPriority or (x.goalPriority not in ["Need", "Want", "Wish", "Dream"]):
                return {
                    "isValid": False,
                    "message": "goalPriority must be one of Need, Want, Wish, and Dream.",
                }
            if not x.cashflowType or (x.cashflowType not in ["yearly", "monthly"]):
                return {
                    "isValid": False,
                    "message": "cashflowType must be one of yearly or monthly.",
                }
            if not x.scenarioType or (x.scenarioType not in ["regular", "retirement"]):
                return {
                    "isValid": False,
                    "message": "scenarioType must be one of regular or retirement.",
                }

            if not x.cashflow or not type(x.cashflow) is not abc.MutableSequence:
                return {
                    "isValid": False,
                    "message": "cashflow must be an array",
                }

            if "endDate" not in x:
                return {
                    "isValid": False,
                    "message": "endDate is required.",
                }
            if type(x.endDate) is not str or not isDateFormatValid(x.endDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399",
                }
            if "cashflowDate" not in x:
                return {
                    "isValid": False,
                    "message": "cashflowDate is required.",
                }

            if type(x.cashflowDate) is not str or not isDateFormatValid(x.cashflowDate):
                return {
                    "isValid": False,
                    "message": "Valid date range for cashflowDate should be between 1-01-1800 to 31-12-2399",
                }

            if not x.goal_id or type(x.goal_id) is not str:
                return {
                    "isValid": False,
                    "message": "goal_id must be a string",
                }

            if x.curr_wealth is not None and (type(x.curr_wealth) not in (float, int) or (x.curr_wealth < 0)):
                return {
                    "isValid": False,
                    "message": "curr_wealth must be a number greater than equal to 0 or null",
                }

            if x.goalValue is None or type(x.goalValue) not in (float, int) or (x.goalValue < 0):
                return {
                    "isValid": False,
                    "message": "goalValue must be a number greater than or equal to 0.",
                }

            if (
                "lossThreshold" in x
                and x.lossThreshold is not None
                and (type(x.lossThreshold) not in [float, int] or x.lossThreshold < 0)
            ):
                return {
                    "isValid": False,
                    "message": "lossThreshold must be a number greater than equal to 0 or null",
                }
    except Exception as e:
        return e
    dateValidation = validateGoalProfileDates(goal_profile_list, start_date, currDate)
    if not dateValidation.get("isValid"):
        return dateValidation
    return {
        "isValid": True,
        "message": None,
    }
