from collections import abc
from re import sub
import re

SPLITTHIS_RE = re.compile(r"([\-_\s]*[A-Z]+?[^A-Z\-_\s]*[\-_\s]*)")
FIX_STR_RE = re.compile(r"([A-Z]+)$|([A-Z]+)(?=[A-Z0-9])")


def converToSnakeCase(str_or_iter):
    """
    Convert a string, dict, or list of dicts to snake case.
    :param str_or_iter:
        A string or iterable.
    :type str_or_iter: Union[list, dict, str]
    :rtype: Union[list, dict, str]
    :returns:
        snake cased string, dictionary, or list of dictionaries.
    """
    if isinstance(str_or_iter, (list, abc.Mapping)):
        return _process(str_or_iter, converToSnakeCase)

    s = str(str_or_iter)
    if s.isupper() or s.isnumeric():
        return str_or_iter
    separator = "_"
    w = separator.join(w for w in SPLITTHIS_RE.split(_fix_string(s)) if w)
    return w.lower().replace(".", "_").replace(" ", "_").replace("__", "_")


def _fix_string(string):
    """
    given the string "goalID" this function is responsible for ensuring the output is
    "goal_id" instead of "goal_I_d".

    :param string: A string may contain an incorrectly cased.
    :type string: str
    :rtype: str
    :returns:
        A rewritten string that can be decamelize.
    """
    return FIX_STR_RE.sub(lambda m: m.group(0).title(), string)


def _process(str_or_iter, fn):
    if isinstance(str_or_iter, list):
        return [_process(k, fn) for k in str_or_iter]
    if isinstance(str_or_iter, abc.Mapping):
        return {fn(k): _process(v, fn) for k, v in str_or_iter.items()}
    return str_or_iter


def camel_case(s):
    s = sub(r"(_|-)+", " ", s)
    s = "".join([x[0].upper() + x[1:] for x in s.split()])
    return "".join([s[0].lower(), s[1:]])


def convertToCamelCase(payload):
    if type(payload) in [float, str, bool, int, None]:
        return payload
    if isinstance(payload, abc.MutableSequence):
        list_data = []
        for data in payload:
            list_data.append(convertToCamelCase(data))
        return list_data
    elif isinstance(payload, abc.Mapping):
        new_dict = {}
        for key in payload:
            if key == "Goal_ID":
                new_dict["goalId"] = convertToCamelCase(payload[key])
            else:
                new_dict[camel_case(key)] = convertToCamelCase(payload[key])
        return new_dict
