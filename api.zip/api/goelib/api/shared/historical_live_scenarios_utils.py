import datetime

from goelib.api.shared.common import DictDefault


def generateHistoricalLiveScenariosPayload(userInput, adminConfig, portfolios, actuarialData, version="3", ptf={}):
    try:
        curr_date = userInput.currDate or datetime.datetime.strftime(datetime.datetime.now(), "%d-%m-%Y")  # noqa: F841
        # const currDateSplit = curr_date.valueOf().split('-');
        initial_wealth = userInput.initialWealth
        rebalancing = userInput.rebalancing
        if version == "4":
            rebalancing = userInput.reallocationFreq
        risk_override = userInput.riskOverride or False

        reallocationDatesByFrequency = adminConfig.allocationConfiguration.reallocationDatesByFrequency or {}
        reallocationDates = []
        if rebalancing == "yearly":
            reallocationDates = reallocationDatesByFrequency["yearly"]
        elif rebalancing == "half-yearly":
            reallocationDates = reallocationDatesByFrequency["halfyearly"]
        elif rebalancing == "quarterly":
            reallocationDates = reallocationDatesByFrequency["quarterly"]
        else:
            reallocationDates = reallocationDatesByFrequency["yearly"]
        reallocation_date_format = "%a %b %d %Y"
        realloc_schedules = [
            datetime.datetime.strftime(datetime.datetime.strptime(dt, reallocation_date_format), "%d-%m-%Y")
            for dt in reallocationDates
        ]
        debug = userInput.debug or False
        tenure = userInput.tenure
        engaged_participant = True if userInput.engagedParticipant is None else userInput.engagedParticipant
        shortTermGoalTenure = adminConfig.portfolioConfig.shortTermGoalTenure or 3
        shortTermRetirementGoalTenure = adminConfig.portfolioConfig.shortTermRetirementGoalTenure or 3
        shortTermRetirementGoalTenureUnengaged = adminConfig.portfolioConfig.shortTermRetirementGoalTenureUnengaged or 5
        # useFTPortfolios = adminConfig.portfolioConfig.usingFtPortfolio or False
        grid_freq = adminConfig.goalPriority.generalSettings.gridFrequency or None
        portfolioMapping = adminConfig.portfolioConfig.portfolioMapping

        # //TODO to fix in future
        # //const isRiskOn = adminConfig.goalPriority.performance.riskOverlay || False
        # isRiskOn = False
        # //TODO to fix in future
        ifNewRiskProfile = False
        ifNewInvestmentTenure = False
        ifNearTermVolatility = False
        ifGoalPriorityChanged = False
        ifNewGoal = False
        ifWantsToReallocate = False
        for triggers in adminConfig.allocationConfiguration.reallocationTriggers:
            if triggers.name == "newRiskProfile" and triggers.value is True:
                ifNewRiskProfile = True  # noqa: F841
            if triggers.name == "changesInvestmentTenure" and triggers.value is True:
                ifNewInvestmentTenure = True  # noqa: F841
            if version == "4" and triggers.name == "newGoal" and triggers.value is True:
                ifNewGoal = True  # noqa: F841
            if triggers.name == "riskIndicatorFlashes" and triggers.value is True:
                ifNearTermVolatility = True  # noqa: F841
            if triggers.name == "rePrioritizesGoal" and triggers.value is True:
                ifGoalPriorityChanged = True  # noqa: F841
            if triggers.name == "wantsToReallocate" and triggers.value is True:
                ifWantsToReallocate = True  # noqa: F841
            lossThresholdValueForPriorityNeed = list(
                filter(lambda e: e.name == "need", adminConfig.goalPriority.lossthresholdValues)
            )[0]
            lossThresholdValueForPriorityWant = list(
                filter(lambda e: e.name == "want", adminConfig.goalPriority.lossthresholdValues)
            )[0]
            lossThresholdValueForPriorityWish = list(
                filter(lambda e: e.name == "wish", adminConfig.goalPriority.lossthresholdValues)
            )[0]
            lossThresholdValueForPriorityDream = list(
                filter(lambda e: e.name == "dream", adminConfig.goalPriority.lossthresholdValues)
            )[0]
            levelsOfGoalPriorityNeed = list(
                filter(lambda e: e.name == "need", adminConfig.goalPriority.probabilityLevels)
            )[0]
            levelsOfGoalPriorityWant = list(
                filter(lambda e: e.name == "want", adminConfig.goalPriority.probabilityLevels)
            )[0]
            levelsOfGoalPriorityWish = list(
                filter(lambda e: e.name == "wish", adminConfig.goalPriority.probabilityLevels)
            )[0]
            levelsOfGoalPriorityDream = list(
                filter(lambda e: e.name == "dream", adminConfig.goalPriority.probabilityLevels)
            )[0]
        realistic_goal_prob = adminConfig.goalPriority.generalSettings.unrealisticProbability
        # TODO Fix in future
        # For now always select risk on portfolios
        if not portfolios or (not portfolios[1]):
            raise ValueError("Default risk on portfolios not found.")
        # change logic to use portfolios rather than user input
        usedPortfolios = portfolios.portfoliosRiskOn
        maximumDecumulationPortMaxIndex = portfolios.maximumDecumulationPortMaxIndex
        maximumShortTermPortMaxIndex = portfolios.maximumShortTermPortMaxIndex
        maximumShortTermRetirementPortMaxIndex = portfolios.maximumShortTermRetirementPortMaxIndex
        configRiskType = "None"
        if userInput.riskProfile:
            sanitizedPortfolioMapping = dict((key.lower(), val) for key, val in portfolioMapping.items())
            riskProfileInLowerCase = userInput.riskProfile.lower()
            configRiskType = sanitizedPortfolioMapping.get(riskProfileInLowerCase)

        # allowedProfiles = []
        # if configRiskType:
        #     allowedProfiles = [configRiskType]
        allowedProfiles = []
        if configRiskType == "VeryConservative":
            # allowedProfiles = ["VeryConservative"]
            allowedProfiles = ptf["veryConservativeLimits"]
        elif configRiskType == "Conservative":
            # allowedProfiles = ["VeryConservative", "Conservative"]
            allowedProfiles = ptf["conservativeLimits"]
        elif configRiskType == "ConservativelyModerate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate"]
            allowedProfiles = ptf["conservativelyModerateLimits"]
        elif configRiskType == "Moderate":
            # allowedProfiles = ["VeryConservative", "Conservative", "ConservativelyModerate", "Moderate"]
            allowedProfiles = ptf["moderateLimits"]
        elif configRiskType == "ModeratelyAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            # ]
            allowedProfiles = ptf["moderatelyAggressivelLimits"]
        elif configRiskType == "Aggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            # ]
            allowedProfiles = ptf["aggressiveLimits"]
        elif configRiskType == "VeryAggressive":
            # allowedProfiles = [
            #     "VeryConservative",
            #     "Conservative",
            #     "ConservativelyModerate",
            #     "Moderate",
            #     "ModeratelyAggressive",
            #     "Aggressive",
            #     "VeryAggressive",
            # ]
            allowedProfiles = ptf["veryAggressiveLimits"]
        else:
            allowedProfiles = []
        if userInput.useAgeBasedCap:
            portfolio_nos = range(1, len(portfolios.useAgeBasedCapPortfoliosRiskOn) + 1)

            expected_returns = list(
                map(lambda e: getattr(e, "portfolio_return") / 100, portfolios.useAgeBasedCapPortfoliosRiskOn)
            )
            expected_risks = list(map(lambda e: e.risk / 100, portfolios.useAgeBasedCapPortfoliosRiskOn))
            asset_allocations = list(map(lambda e: e.assetAllocation, portfolios.useAgeBasedCapPortfoliosRiskOn))
            fees_adjuster = list(map(lambda e: e.feesAdjuster, portfolios.useAgeBasedCapPortfoliosRiskOn))
        else:
            # expected_returns = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            # expected_risks = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            # asset_allocations = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            # fees_adjuster = filter(lambda e: allowedProfiles and e.riskType in allowedProfiles, usedPortfolios)
            # fees_adjuster = list(map(lambda e: e.feesAdjuster, fees_adjuster))
            portfolio_nos = [
                [p.id for p in portfolios.useAgeBasedCapPortfoliosRiskOn].index(value.id) + 1
                for index, value in enumerate(usedPortfolios)
                if (lambda e: allowedProfiles and e.id in allowedProfiles)(value)
            ]
            expected_returns = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_returns = list(map(lambda e: getattr(e, "portfolio_return") / 100, expected_returns))
            expected_risks = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            expected_risks = list(map(lambda e: e.risk / 100, expected_risks))
            asset_allocations = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            asset_allocations = list(map(lambda e: e.assetAllocation, asset_allocations))
            fees_adjuster = filter(lambda e: allowedProfiles and e.id in allowedProfiles, usedPortfolios)
            fees_adjuster = list(map(lambda e: e.feesAdjuster, fees_adjuster))

        short_term_port_maxindex = None
        if maximumShortTermPortMaxIndex > 0:
            short_term_port_maxindex = maximumShortTermPortMaxIndex
        short_term_port_maxindex_retirement = None
        if maximumShortTermRetirementPortMaxIndex > 0:
            short_term_port_maxindex_retirement = maximumShortTermRetirementPortMaxIndex
        dec_port_maxindex = None
        if maximumDecumulationPortMaxIndex > 0:
            dec_port_maxindex = maximumDecumulationPortMaxIndex
        adjust_fees = adminConfig.goalPriority.generalSettings.adjustFees
        port_dict = []
        for ret, risk, asset_allocation, fees_adjuster, portfolio_no in zip(
            expected_returns, expected_risks, asset_allocations, fees_adjuster, portfolio_nos
        ):
            port_data = {
                "mu": round(ret, 4) if ret is not None else ret,
                "sigma": round(risk, 4) if risk is not None else risk,
                "equity": asset_allocation["equity"],
                "bond": asset_allocation["bond"],
                "money_market": asset_allocation["money_market"],
                "id": portfolio_no,
            }
            if adjust_fees and adjust_fees.lower() == "variable":
                port_data.update({"fees_adjuster": fees_adjuster})
            elif adjust_fees and adjust_fees.lower() == "common":
                port_data.update({"fees_adjuster": adminConfig.goalPriority.generalSettings.annualInBPS})
            port_dict.append(port_data)

        benchmark_port = userInput.benchmarkPortfolio or None
        if benchmark_port is not None and benchmark_port > len(port_dict):
            maxIndex = len(port_dict)
            raise ValueError(
                f"Benchmark portfolio {userInput.benchmarkPortfolio} must be an integer between 1-{maxIndex}"
            )
        final_wealth = userInput.finalWealth
        downside_alternate_max_goal = False
        goal_priority = False
        if adminConfig.goalPriority.generalSettings.downsideProtection == "Maximize Goal Probability":
            downside_alternate_max_goal = True
        if downside_alternate_max_goal is True:
            goal_priority = True
        loss_amt = None
        if userInput.lossThreshold is not None:
            loss_amt = userInput.lossThreshold

        # TODO make exec change always true
        exec_change = True
        LT_Factor = {
            "Acc_Need": lossThresholdValueForPriorityNeed.accumulation,
            "Acc_Want": lossThresholdValueForPriorityWant.accumulation,
            "Acc_Wish": lossThresholdValueForPriorityWish.accumulation,
            "Acc_Dream": lossThresholdValueForPriorityDream.accumulation,
            "Dec_Need": lossThresholdValueForPriorityNeed.decumulation,
            "Dec_Want": lossThresholdValueForPriorityWant.decumulation,
            "Dec_Wish": lossThresholdValueForPriorityWish.decumulation,
            "Dec_Dream": lossThresholdValueForPriorityDream.decumulation,
        }
        goal_priority_prob_list = {
            "Need": levelsOfGoalPriorityNeed.value,
            "Want": levelsOfGoalPriorityWant.value,
            "Wish": levelsOfGoalPriorityWish.value,
            "Dream": levelsOfGoalPriorityDream.value,
        }
        goal_priority_prob = None
        if userInput.goalPriority == "Need":
            goal_priority_prob = levelsOfGoalPriorityNeed.value
        elif userInput.goalPriority == "Want":
            goal_priority_prob = levelsOfGoalPriorityWant.value
        elif userInput.goalPriority == "Wish":
            goal_priority_prob = levelsOfGoalPriorityWish.value
        elif userInput.goalPriority == "Dream":
            goal_priority_prob = levelsOfGoalPriorityDream.value
        get_path = False
        sigma_thd = adminConfig.goalPriority.performance.sigma
        nodes_per_sd = adminConfig.goalPriority.performance.nodesPerSd
        infln = adminConfig.goalPriority.generalSettings.inflation
        inf_measure = None
        if adminConfig.goalPriority.generalSettings.inflationMeasureForInfusions == "NOMINAL":
            inf_measure = "nominal"
        else:
            inf_measure = "real"
        irr_thresh = adminConfig.goalPriority.performance.irrForRangeAdjustment
        safeguard = adminConfig.goalPriority.generalSettings.safeGuardAchievedWealthInLastYear
        safeguard_min = adminConfig.goalPriority.generalSettings.minPortfoliosForLastYear
        swing_constraint = adminConfig.goalPriority.generalSettings.swingConstraint
        swing = adminConfig.goalPriority.generalSettings.swingConstraintNumber
        downside_protect = adminConfig.goalPriority.lossThreshold
        protect_thd = adminConfig.goalPriority.lossThresholdProbability
        long_tenure_thresh = adminConfig.goalPriority.performance.longTenureThreshold or 30
        irr_perf_thd = adminConfig.goalPriority.performance.irrPerformanceThreshold or 0.0339
        alt_nodes_per_sd = adminConfig.goalPriority.performance.altNodesPerSd or 4
        alt_sigma_thd = adminConfig.goalPriority.performance.alternativeSigma or 4
        topup_recommendation = adminConfig.goalPriority.generalSettings.recommendTopUpInfusion
        tenure_recommendation = adminConfig.goalPriority.generalSettings.recommendTenure
        back_pass_only = adminConfig.goalPriority.generalSettings.backPassOnly
        if adminConfig.goalPriority.probabilityThresholds:
            derisking_prob_thresh = {
                "min_prob1": adminConfig.goalPriority.probabilityThresholds[0].labelValue,
                "max_prob1": adminConfig.goalPriority.probabilityThresholds[0].value,
                "threshold1": adminConfig.goalPriority.probabilityThresholds[0].val,
                "min_prob2": adminConfig.goalPriority.probabilityThresholds[1].labelValue,
                "max_prob2": adminConfig.goalPriority.probabilityThresholds[1].value,
                "threshold2": adminConfig.goalPriority.probabilityThresholds[1].val,
                "min_prob3": adminConfig.goalPriority.probabilityThresholds[2].labelValue,
                "max_prob3": adminConfig.goalPriority.probabilityThresholds[2].value,
                "threshold3": adminConfig.goalPriority.probabilityThresholds[2].val,
            }
        else:
            derisking_prob_thresh = {
                "min_prob1": 0.0,
                "max_prob1": 0.9,
                "threshold1": 0.00075,
                "min_prob2": 0.90,
                "max_prob2": 1.00,
                "threshold2": 0.0015,
                "min_prob3": 0.65,
                "max_prob3": 0.90,
                "threshold3": 0.00075,
            }

        newPipePayload = {
            "user_profile": {
                "final_wealth": final_wealth,
                "initial_wealth": initial_wealth,
                "tenure": int(tenure),
                "goal_priority": userInput.goalPriority,
                "infusion_percentage": userInput.infusionPercentage,
                "historical_start_year": int(userInput.historicalStartYear),
                "loss_amt": loss_amt,
                "benchmark_port": benchmark_port,
                "rebalancing": rebalancing,
                "risk_override": risk_override,
                "debug": debug,
                "engaged_participant": engaged_participant,
                "use_age_based_cap": userInput.useAgeBasedCap or False,
            },
            "pipe_config": {
                "realloc_schedules": realloc_schedules,
                "wealth_path_prob": adminConfig.goalPriority.generalSettings.wealthPathProbability
                if adminConfig.goalPriority.generalSettings.wealthPath == "Custom"
                else None,
                "wealth_path_freq": adminConfig.goalPriority.generalSettings.wealthPathFrequency,
                "exec_change": exec_change,
                "swing_constraint": swing_constraint,
                "swing": swing,
                "safeguard": safeguard,
                "downside_protect": downside_protect,
                "protect_thd": protect_thd,
                "goal_priority": goal_priority,
                "downside_alternate_max_goal": downside_alternate_max_goal,
                "get_path": get_path,
                "realistic_goal_prob": realistic_goal_prob,
                "goal_priority_prob": goal_priority_prob,
                "infln": infln,
                "sigma_thd": sigma_thd,
                "nodes_per_sd": nodes_per_sd,
                "inf_measure": inf_measure,
                "irr_thresh": irr_thresh,
                "safeguard_min": safeguard_min,
                "LT_Factor": LT_Factor,
                "long_tenure_thresh": long_tenure_thresh,
                "irr_perf_thd": irr_perf_thd,
                "alt_nodes_per_sd": alt_nodes_per_sd,
                "alt_sigma_thd": alt_sigma_thd,
                "topup_recommendation": topup_recommendation,
                "tenure_recommendation": tenure_recommendation,
                "back_pass_only": back_pass_only,
                "goal_priority_prob_list": goal_priority_prob_list,
                "short_term_tenure": shortTermGoalTenure,
                "short_term_port_maxindex": short_term_port_maxindex,
                "short_term_tenure_retirement": shortTermRetirementGoalTenure,
                "short_term_tenure_retirement_unengaged": shortTermRetirementGoalTenureUnengaged,
                "short_term_port_maxindex_retirement": short_term_port_maxindex_retirement,
                "dec_port_maxindex": dec_port_maxindex,
                "grid_freq": grid_freq,
                "adjust_fees": adjust_fees,
                "derisking_prob_thresh": derisking_prob_thresh,
            },
            "port_dict": port_dict,
        }
        newPipePayload = DictDefault(newPipePayload)
        if userInput.useAgeBasedCap is True:
            newPipePayload["age_based_risk_mapper"] = actuarialData.ageBasedEquityCap

        newPipePayload = DictDefault(newPipePayload)
        if userInput.cashflowDate is not None:
            newPipePayload.user_profile.cashflow_date = userInput.cashflowDate
        else:
            newPipePayload.user_profile.cashflow_date = None
        if not safeguard:
            del newPipePayload.pipe_config["safeguard_min"]
        return {"error": None, "data": newPipePayload}
    except Exception as e:
        print(e)
        return {"error": str(e), "data": None}


def validateHistoricalLiveScenariosPayload(payload, version="3"):
    finalWealth = payload.finalWealth
    initialWealth = payload.initialWealth
    currDate = payload.currDate
    goalPriority = payload.goalPriority
    rebalancing = payload.rebalancing
    infusionPercentage = payload.infusionPercentage
    tenure = payload.tenure
    historicalStartYear = payload.historicalStartYear
    benchmarkPortfolio = payload.benchmarkPortfolio
    lossThreshold = payload.lossThreshold
    riskOverride = payload.riskOverride
    engagedParticipant = payload.engagedParticipant
    reallocationFreq = payload.reallocationFreq
    if type(finalWealth) not in [float, int] or finalWealth <= 0:
        return {
            "isValid": False,
            "message": "finalWealth must be a number and greater than 0",
        }
    # if "useAgeBasedCap" in payload and type(payload.useAgeBasedCap) != bool:
    #     return {"isValid": False, "message": "useAgeBasedCap must be boolean."}

    if type(initialWealth) not in [float, int] or initialWealth <= 0:
        return {
            "isValid": False,
            "message": "initialWealth must be a number and greater than 0",
        }

    if currDate and (type(currDate) != str):  # or (type(currDate) == str #and  not isDateFormatValid(currDate))
        return {"isValid": False, "message": "Valid date range for currDate should be between 1-01-1800 to 31-12-2399."}

    if goalPriority not in ["Need", "Want", "Wish", "Dream"]:
        return {
            "isValid": False,
            "message": "goalPriority must be one of Need, Want, Wish, and Dream.",
        }
    if version == "3":
        if rebalancing is None or rebalancing not in ["yearly", "quarterly", "half-yearly"]:
            return {
                "isValid": False,
                "message": "rebalancing is a mandatory field and has to be one of yearly, half-yearly or quarterly.",
            }

    if type(infusionPercentage) not in [float, int] or (infusionPercentage < -0.3 or infusionPercentage > 0.3):
        return {
            "isValid": False,
            "message": "infusionPercentage must be a number and must be between -0.3 and 0.3",
        }

    if type(tenure) not in [float, int] or tenure <= 2:
        return {
            "isValid": False,
            "message": "tenure must be a positive integer value greater than or equal to 3",
        }

    if type(historicalStartYear) not in [float, int] or historicalStartYear <= 0:
        return {
            "isValid": False,
            "message": "historicalStartYear must be a positive integer value greater than 0",
        }
    if benchmarkPortfolio is not None and (type(benchmarkPortfolio) not in [float, int] or benchmarkPortfolio < 1):
        return {
            "isValid": False,
            "message": "benchmarkPortfolio must either be null or an integer greater than 0",
        }

    if (
        "lossThreshold" in payload
        and payload.lossThreshold is not None
        and (type(lossThreshold) not in [float, int] or lossThreshold < 0)
    ):
        return {
            "isValid": False,
            "message": "lossThreshold must be a number greater than equal to 0 or null",
        }
    if riskOverride and type(riskOverride) is not bool:
        return {
            "isValid": False,
            "message": "riskOverride must be a boolean. When not specificed, default value is false",
        }
    if engagedParticipant is not None and not isinstance(engagedParticipant, bool):
        return {
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true",
        }
    if version == "4":
        if reallocationFreq is None or reallocationFreq not in ["yearly", "half-yearly", "quarterly"]:
            return {
                "isValid": False,
                "message": "reallocationFreq is a mandatory field and has to be one of yearly,\
                     half-yearly or quarterly",
            }

    return {
        "isValid": True,
        "message": None,
    }
