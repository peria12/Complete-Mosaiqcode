from uip_dbs_async import Db
from sqlalchemy.ext.automap import generate_relationship
from sqlalchemy.ext.automap import automap_base


class DbAccess:
    """async connection to database."""

    @classmethod
    async def get_access(cls):
        if hasattr(cls, "_conn"):
            return cls._conn
        else:
            cls._conn = await Db.Create("goe_db")
            return cls._conn

    @classmethod
    async def get_writer_access(cls):
        if hasattr(cls, "_writerconn"):
            return cls._writerconn
        else:
            cls._writerconn = await Db.Create("goe_db_write")
            return cls._writerconn


class GenerateTables:
    """generate table and relationship from schema.
    This need sync db engine as async engine is not supported.
    Base is prepared once this goelib is imported.
    """

    @classmethod
    def generate_metadata(cls):
        from uip_dbs import Db

        if hasattr(cls, "_basemetadata"):
            return cls._basemetadata
        else:
            db = Db("goe_db")
            engine = db.conn.engine
            Base = automap_base()
            Base.prepare(engine, reflect=True, generate_relationship=generate_relationship)
            cls._basemetadata = Base
        return cls._basemetadata
