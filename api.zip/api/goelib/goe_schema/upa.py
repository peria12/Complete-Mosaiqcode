from pydantic import BaseModel, Field, model_validator
from typing import Any, List, Dict, Literal


class GoalProfile(BaseModel):
    goalID: str = Field(example="Goal1", description="Goal identifier for individual goal.")
    goalAmt: List[float] = Field(
        example=[41400.0, 41400.0, 41400.0, 41400.0, 41400.0],
        description="Accumulation only Goals:\
              Target wealth value associated with the goal at end of goal tenure.<br><br>\
              Accumulation & Decumulation, and decumulation/income goals: goal value (withdrawal) each year\
                  during the decumulation period. For subsequent calls, the goalAmt list needs to be updated based on the time that has elapsed.",
    )
    startDate: str = Field(
        example="01-01-2022",
        description="Accumulation Goals: beginning date of the goal - this is typically the date of initial investment for accumulation goals. For subsequent calls, the original start date for the goal needs to be passed.\
                           <br>Accumulation & Decumulation, and decumulation/income goals: date when the first withdrawal/income starts. For subsequent calls, the original start date (date of first withdrawal) for the goal needs to be passed.",
    )
    endDate: str = Field(
        example="01-01-2026",
        description="Accumulation Goals: end date of the goal - when a lumpsum is due.\
                         <br>Accumulation & Decumulation, and decumulation/income goals: date of last withdrawal.",
    )
    priority: str = Field(
        example="Need",
        description="Defines the importance a goal holds for a specific user.\
          Order of priority is Need > Want > Wish > Dream. Goal priority defines the target probabilities and \
            the loss threshold values. For example, goals with a higher priority (e.g. Need) would have a\
                  higher target goal probability (85%) with a higher (aggressive) loss threshold value.",
    )
    scenarioType: str = Field(
        example="retirement",
        description="‘regular’ for regular goals accumulation goals where cash flows are positive (contributions) \
            and with a typical target wealth.<br><br>\
            ‘retirement’ for scenarios where a decumulation period is included: <br>\
            1. Scenarios with an accumulation period (and an initial wealth) & positive cash flows followed by \
                a decumulation period with withdrawals (negative cash flows) with or without an inheritance.<br>\
                    2. Scenarios with an initial wealth followed by a decumulation period with or without an inheritance.",
    )

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class UnifiedPortfolioAdviceInputModelV4(BaseModel):
    isNewGoalPriority: bool = Field(
        title="",
        description="If the investor/end user changes the priority of any of the goals within the plan, \
            in between the re-allocation dates, this should be set to ‘true’. \
            For new plans, this needs to be ‘true’.",
        examples=[True],
    )
    isNewRiskProfile: bool = Field(
        title="",
        description="If the risk profile of the investor/end user  has changed, this should be set to ‘true’. \
                     For new plans, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewInvestmentTenure: bool = Field(
        title="",
        description="If the investor/end user changes the goal investment tenure of any of the goals within the plan, \
                     in between re-allocation dates, this should be set to ‘true’.For new plans, this needs to be ‘true’.",
        examples=[True],
    )
    isNearTermVolatility: bool = Field(
        default=False,
        title="",
        description="When the near-term volatility indicator flashes, this is set to ‘true’. For first time calls to GOE, \
                                                this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewGoal: bool = Field(
        title="",
        description="If the investor/end user changes the goal amount in between the re-allocation dates,\
              this is set to ‘true’. For retirement scenarios, this would be a change in the retirement income goal,\
                  while for a capital accumulation goal, this would be a change in the lump sum accumulation target.\
                      For new plans, this needs to be set to ‘true’.",
        examples=[True],
    )
    cashflowDate: str = Field(
        examples=["01-01-2021"],
        default=None,
        title="",
        nullable=True,
        description='Cashflow date of the plan - this is typically the date (year is ignored) on which infusions/withdrawals would happen for the goals. \
                                                                Format is "dd-mm-yyyy". <br> \
                                                                If the cashflowDate parameter is set to null, the algorithm would consider the first reallocation date as the cashflow date.',
    )
    getPath: bool = Field(
        title="",
        description="If this parameter is set to False, GOE would not compute the portfolio path ,wealth path and cashflow recommendations.",
        examples=[True],
    )
    reallocationFreq: Literal["yearly", "half-yearly", "quarterly"] = Field(
        title="",
        description="Describes the frequency of re-allocation. If set to 'yearly', \
            GOE would assume the re-allocation to happen once a year.",
        examples=["yearly"],
    )
    initialInvestment: float = Field(
        title="", examples=[86000], ge=0, description="Defines the lump sum initial welath of the plan."
    )
    currentWealth: float = Field(
        title="",
        examples=[None],
        ge=0,
        nullable=True,
        description="Current wealth of the plan/combined goal when the GOE is being called or executed At the time of initial onboarding, currentWealth is null. On subsequent dates, currentWealth would be the portfolio account value at the time.",
    )
    currentPortfolioId: int = Field(
        examples=[None],
        title="",
        nullable=True,
        description="Current portfolio index that the combined plan is allocated to; if algo is getting executed for the first time (onboarding call), it should be null.\
        For cases where updated probability is needed in between the scheduled re-allocation dates, this parameter should be set to the portfolio index the investor is assigned to.",
    )
    infusions: list[float] = Field(
        example=[
            0.0,
            4000.0,
            4000.0,
            4000.0,
            4000.0,
            4000.0,
            4000.0,
            4000.0,
            4000.0,
            4000.0,
            -21000.0,
            -19000.0,
            -85000.0,
            -23000.0,
            -23000.0,
            -23000.0,
        ],
        title="",
        description="Net cash flow array for the plan/combined goal. Positive in the case of infusions; negative in \
            case of withdrawals; zero in case of no cashflows; frequency depends on ‘infusionType’.\
            For subsequent calls, the infusions array needs to be adjusted based on the time that has elapsed.",
    )
    riskProfile: Literal["Conservative", "Moderate", "Aggressive"] = Field(
        examples=["Aggressive"],
        title="",
        description="Defines the user’s risk profile. Note that Risk Profiles are mapped to portfolio access. For example, a Conservative investor has access to portfolios 1-8 (or 50% Equity) while an Aggressive investor has access to all 16 portfolios (up to 90% Equity). <br> On a default basis, GOE is configured for three Risk Profile levels, but it can be customized for up to five levels.",
    )
    infusionType: str = Field(
        example="yearly", description="Indicates the frequency of cash flows – Determines the cash flow array. "
    )
    currDate: str = Field(
        default="System Date",
        examples=["13-01-2021"],
        title="",
        description="This is an optional parameter that can be used to simulate the current date being the specified value. <br> \
                                                    GOE will process the request as if you are making the API call on the specified date. If not passed, the current system date will be used as the current date.",
    )
    lossThreshold: float = Field(
        examples=[None],
        default=None,
        title="",
        ge=0,
        nullable=True,
        description="Loss threshold value – the wealth amount that the investor does not want to end up below at the end of the goal tenure.<br> \
                                                If not passed or value is ‘null’, the GOE algo would calculate the loss threshold. If a number value is passed, GOE would consider that amount as the loss threshold.<br> \
                                                If loss threshold is not available, this needs to be passed as ‘null’, and GOE would calculate the loss threshold and return as a part of the response ‘loss threshold’. <br> \
                                                This amount needs to be stored, and should be passed as ‘lossThreshold’ on subsequent GOE calls.",
    )
    goalProfileList: List[GoalProfile] = Field(
        examples=[None],
        title="",
        description="A list containing parameters for different goals. Each goal in the list would have a goal ID,\
              goal amount, start date, end date, and priority.For subsequent calls, \
                the goalProfileList needs to be updated based on the time that has elapsed. If a goal has expired, then it needs to be removed from the goalProfileList.",
    )
    """ calibrateGoalRec: bool = Field(
        examples=[True], description="Flag indicating whether to calibrate goal recommendations"
    )
    participantID: str = Field(
        examples=["C9768"],
        default=None,
        title="",
        description="ID of the partipant.",
    )
    useAgeBasedCap: bool | None = Field(
        examples=[False], description="Flag indicating whether to use age-based capital"
    )
    callibrateGoalRec: bool = Field(
        examples=[False], description="Flag indicating whether to calibrate goal recommendations"
    ) """
    goalProfileList: List[GoalProfile] = Field(
        example=[
            {
                "goalID": "Goal1",
                "goalAmt": [25000],
                "startDate": "01-01-2021",
                "endDate": "01-01-2031",
                "priority": "Dream",
                "scenarioType": "regular",
            },
            {
                "goalID": "Goal2",
                "goalAmt": [62000],
                "startDate": "01-01-2021",
                "endDate": "01-01-2033",
                "priority": "Wish",
                "scenarioType": "regular",
            },
            {
                "goalID": "Goal3",
                "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000],
                "startDate": "01-01-2022",
                "endDate": "01-01-2036",
                "priority": "Need",
                "scenarioType": "retirement",
            },
            {
                "goalID": "Goal4",
                "goalAmt": [21000, 21000, 21000, 21000, 21000],
                "startDate": "01-01-2032",
                "endDate": "01-01-2036",
                "priority": "Need",
                "scenarioType": "retirement",
            },
        ],
        description="List of goal profiles",
    )

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class CashflowRecommendation(BaseModel):
    cashFlowMonthly: float = Field(
        title="",
        examples=[""],
        description="Suggested monthly cashflow amount that aims to improve the plan probability to meet the target probability.\
                Note: - Empty in case of yearly infusions.",
    )
    cashFlowYearly: float = Field(
        title="",
        examples=[2503],
        description="Suggested yearly cashflow amount that aims to improve the plan probability to meet the target\
              probability. Note: - Empty in case of monthly infusions. ",
    )
    startDate: str = Field(
        title="",
        examples=["01-01-2022"],
        description="Suggested start date of the cashflows considering cashflow recommendation.",
    )
    endDate: str = Field(
        title="",
        examples=["01-01-2036"],
        description="Suggested end date of the cashflows considering cashflow recommendation.",
    )
    newPlanProb: float = Field(
        title="",
        examples=[0.85],
        description="New plan probability as per the suggested tenure recommendation. ",
    )


class UPAAnalysisReport(BaseModel):
    currentGoalProbability: float = Field(
        title="",
        examples=[10000],
        ge=0,
        nullable=True,
        description="GOE’s estimated probability to achieve the goal target wealth.",
    )
    currentLossThresholdProbability: float = Field(
        title="",
        examples=[0.4233],
        description="GOE’s estimated probability to remain above the loss threshold amount by the end of the plan tenure.",
    )
    pDeltaCurrentGoalProbability: float = Field(
        title="",
        examples=[0.3288],
        description="Estimated goal probability considering the swing constraint. Since this is a simulation, \
            the output might differ slightly on each simulation run.",
    )
    pDeltaCurrentLossThresholdProbability: float = Field(
        title="",
        examples=[0.4175],
        description="Similar to above, this is the loss threshold probability considering swing constraint. \
                    Since this is a simulation, the output might differ slightly on each simulation run.",
    )
    recommendedPortfolioId: int = Field(
        title="", examples=[6], description="GOE’s current recommended portfolio index."
    )
    meetGoalPriority: bool = Field(
        title="",
        examples=[False],
        description="Checks if goal probability is more than the target probability corresponding to the goal \
            priority – Target probabilities for all goal priorities (Need, Want, Wish and Dream) are set in the GOE config.",
    )
    isGoalRealistic: bool = Field(
        title="",
        examples=[False],
        description="To understand if the goal probability is more than 35% (This is a configurable field).",
    )
    meetLossPriority: bool = Field(
        title="",
        examples=[False],
        description="Checks if loss probability is at least 95% (target can be set in the GOE config).",
    )
    oneTimeTopUp: float = Field(
        title="",
        examples=[38859],
        description="Suggested one-time top-up amount that aims to improve the goal probability to meet the target goal probability.",
    )
    cashflowRecommendation: CashflowRecommendation = Field(
        title="",
        description="Cashflow recommendation is at the plan level.Note: - \
              Empty in case plan meets the target probability.",
    )
    bankruptcyMsg: str = Field(
        title="",
        examples=["NA"],
        description="Message flagging an expected bankruptcy (goal running out of money) in any year.",
    )
    advisorDiscretionReport: Dict[str, float] = Field(
        title="",
        examples=["{'6': 0.3344}"],
        description="Recommended Portfolio and corresponding probability. In case where current portfolio is not null,\
                    it provides the following:<br> 1. Probability of attaining goal \
                    (using the current portfolio sent as an input and a constant portfolio path)\
                          – Monte Carlo simulations.<br>2. Current Goal Probability (dynamic asset allocation by GOE)\
                              and the recommended portfolio.<br>In case the current portfolio is null, \
                                the current goal probability is displayed (using dynamic asset allocation\
                                      by GOE and not assuming a constant portfolio path) along with \
                                        the recommended portfolio",
    )
    lossThreshold: int = Field(
        title="",
        examples=[11500],
        nullable=True,
        description="Loss threshold value – the wealth amount that the investor does not want to end up below at \
            the end of the goal tenure.The GOE algo calculates the loss threshold if not provided.",
    )


class UPAPathReport(BaseModel):
    portfolioPath: List[int] = Field(
        title="",
        examples=[6] * 18,
        description="GOE’s expected portfolio path across the investment tenure.",
    )
    wealthPath: List[float] = Field(
        title="",
        examples=[6] * 18,
        nullable=True,
        description="Priority based path across the investment tenure.",
    )
    worstCasePath: List[float] = Field(
        title="",
        examples=[6] * 18,
        nullable=True,
        description="Represents the pessimistic scenario of a wealth path. \
                    The default value corresponds to 1% probability (99 percentile). This could be customized using the admin portal.",
    )
    bestCasePath: List[float] = Field(
        title="",
        examples=[6] * 18,
        nullable=True,
        description="Represents the optimistic scenario of a wealth path. The default value corresponds to 1% probability (99 percentile). \
                    This could be customized using the admin portal.",
    )


class UPAPathReportMod(BaseModel):
    portfolioPath: List[int] = Field(
        title="",
        examples=[6] * 18,
        nullable=True,
        description="GOE’s expected portfolio path across the investment tenure.",
    )


class UPAGoalResponse(BaseModel):
    goalID: str = Field(
        title="",
        examples=["Goal1"],
        description="Goal identifier for individual goal.",
    )

    goalAmt: List[float] = Field(
        title="",
        examples=[25000],
        description="Accumulation only Goals: Target wealth value associated with the goal at end of goal tenure. \
            Accumulation & Decumulation, and decumulation/income goals: Goal value (withdrawal) \
                each year during decumulation period.",
    )

    startDate: str = Field(
        title="",
        examples=["01-01-2021"],
        description="Accumulation Goals: Beginning date of the goal - this is typically the date of initial \
            investment for accumulation goals.<br> Accumulation & Decumulation, and decumulation/income goals: \
                Date when the first withdrawal/income starts.",
    )

    endDate: str = Field(
        title="",
        examples=["01-01-2031"],
        description="Accumulation Goals: End date of the goal - when a lumpsum is due. <br> Accumulation & Decumulation, and decumulation/income goals: Date of last withdrawal.",
    )

    priority: str = Field(
        title="",
        examples=["Dream"],
        description="Goal priority.",
    )

    modifiedGoalAmt: List[float] = Field(
        title="",
        examples=[6] * 18,
        description="Modified goal.",
    )


class UPAAnalysisReportMod(BaseModel):
    currentGoalProbability: float = Field(
        title="",
        examples=[10000],
        ge=0,
        nullable=True,
        description="GOE’s estimated probability to achieve the goal target wealth",
    )
    currentLossThresholdProbability: float = Field(
        title="",
        description="GOE’s estimated probability to remain above the loss threshold amount by the end of the goal tenure.",
    )
    pDeltaCurrentGoalProbability: float = Field(
        title="",
        examples=[0.3288],
        description="Estimated goal probability considering the swing constraint. Since this is a simulation, \
            the output might differ slightly on each simulation run.",
    )
    pDeltaCurrentLossThresholdProbability: float = Field(
        title="",
        examples=[0.4175],
        description="Similar to above, this is the loss threshold probability considering swing constraint. \
                    Since this is a simulation, the output might differ slightly on each simulation run.",
    )
    recommendedPortfolioId: int = Field(
        title="", examples=[6], description="GOE’s current recommended portfolio index."
    )
    meetGoalPriority: bool = Field(
        title="",
        examples=[False],
        description="Checks if goal probability is more than the target probability corresponding to the goal \
            priority – Target probabilities for all goal priorities (Need, Want, Wish and Dream) are set in the GOE config.",
    )
    isGoalRealistic: bool = Field(
        title="",
        examples=[False],
        description="To understand if the goal probability is more than 35% (This is a configurable field).",
    )
    meetLossPriority: bool = Field(
        title="",
        examples=[False],
        description="Checks if loss probability is at least 95% (target can be set in the GOE config).",
    )
    oneTimeTopUp: float = Field(
        title="",
        examples=[38859],
        description="Suggested one-time top-up amount that aims to improve the goal probability to meet the target goal probability.",
    )
    cashflowRecommendation: CashflowRecommendation = Field(
        title="",
        description="Cashflow recommendation is at the plan level.Note: - \
              Empty in case plan meets the target probability.",
    )
    bankruptcyMsg: str = Field(
        title="",
        examples=["NA"],
        description="Message flagging an expected bankruptcy (goal running out of money) in any year.",
    )
    advisorDiscretionReport: Dict[str, float] = Field(
        title="",
        examples=["{'6': 0.3344}"],
        description="Recommended Portfolio and corresponding probability. In case where current portfolio is not null,\
                    it provides the following:<br> 1. Probability of attaining goal \
                    (using the current portfolio sent as an input and a constant portfolio path)\
                          – Monte Carlo simulations.<br>2. Current Goal Probability (dynamic asset allocation by GOE)\
                              and the recommended portfolio.<br>In case the current portfolio is null, \
                                the current goal probability is displayed (using dynamic asset allocation\
                                      by GOE and not assuming a constant portfolio path) along with \
                                        the recommended portfolio",
    )
    lossThreshold: int = Field(
        title="",
        examples=[11500],
        nullable=True,
        description="Loss threshold value – the wealth amount that the investor does not want to end up below \
            at the end of the goal tenure. The GOE algo calculates the loss threshold if not provided.",
    )

    goalsResponse: List[UPAGoalResponse] = Field(title="", description="")
    comments: str = Field(
        title="",
        examples=[
            "To meet all goals optimally as per their assigned priorities Goal1 has been reduced by 100.0%, Goal2 has been reduced by 50.0% of its original value. The allocated portfolio has an 94.316% probability of meeting the modified goals"
        ],
        description="Comment would describe the modifications or % change in goal amount made to original goal amounts to meet the target goal probability.",
    )


class UPAResponseBody(BaseModel):
    analysisReport: UPAAnalysisReport = Field(
        title="",
        description="<b>For the Original Plan:</b><br>\
            GOE’s outputs including probability, portfolio advice, etc.",
    )
    pathReport: UPAPathReport = Field(
        title="",
        description="<b>For the Original Plan:</b>\
            GOE’s outputs including estimated portfolio path, wealth path, etc.",
    )
    analysisReportMod: UPAAnalysisReportMod = Field(
        title="",
        description="<b>For the modified Plan:</b><br>\
            GOE’s outputs including probability, portfolio advice, etc.",
    )
    pathReportMod: UPAPathReportMod = Field(
        title="",
        description="<b>For the Modified Plan:</b><br>\
            GOE’s outputs including estimated portfolio path, wealth path, etc.",
    )


class UPAv4ResponseModel(BaseModel):
    statusCode: int
    message: str
    body: UPAResponseBody


upav4_response_model = {
    "model": UPAv4ResponseModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {
                        "statusCode": 200,
                        "message": "Success",
                        "body": {
                            "analysisReport": {
                                "advisorDiscretionReport": {"16": 0.6193},
                                "bankruptcyMsg": "NA",
                                "cashflowRecommendation": {
                                    "cashFlowMonthly": "",
                                    "cashFlowYearly": 2503.0,
                                    "endDate": "01-01-2036",
                                    "newPlanProb": 0.85,
                                    "startDate": "01-01-2022",
                                },
                                "currentGoalProbability": 0.6193,
                                "currentLossThresholdProbability": 0.6509,
                                "isGoalRealistic": True,
                                "lossThreshold": 11500,
                                "meetGoalPriority": False,
                                "meetLossPriority": False,
                                "oneTimeTopUp": 29886.0,
                                "pDeltaCurrentGoalProbability": 0.5937,
                                "pDeltaCurrentLossThresholdProbability": 0.6327,
                                "recommendedPortfolioId": 16,
                                "tenureRecommendation": {
                                    "goalEndDate": "01-01-2034",
                                    "goalId": "Goal1",
                                    "goalStartDate": "13-01-2021",
                                    "newPlanProbability": 0.6383,
                                },
                            },
                            "analysisReportMod": {
                                "advisorDiscretionReport": {"8": 0.8766},
                                "bankruptcyMsg": "NA",
                                "cashflowRecommendation": {},
                                "comments": "To meet all goals optimally as per their assigned priorities Goal1 has been reduced by 100.0%, Goal2 has been reduced by 25.0% of its original value. The allocated portfolio has an 87.657% probability of meeting the modified goals",
                                "currentGoalProbability": 0.8766,
                                "currentLossThresholdProbability": 0.9048,
                                "goalsResponse": [
                                    {
                                        "endDate": "01-01-2031",
                                        "goalAmt": [25000],
                                        "goalId": "Goal1",
                                        "modifiedGoalAmt": [0.0],
                                        "priority": "Dream",
                                        "startDate": "01-01-2021",
                                    },
                                    {
                                        "endDate": "01-01-2033",
                                        "goalAmt": [62000],
                                        "goalId": "Goal2",
                                        "modifiedGoalAmt": [46500.0],
                                        "priority": "Wish",
                                        "startDate": "01-01-2021",
                                    },
                                    {
                                        "endDate": "01-01-2036",
                                        "goalAmt": [
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                        ],
                                        "goalId": "Goal3",
                                        "modifiedGoalAmt": [
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                            2000,
                                        ],
                                        "priority": "Need",
                                        "startDate": "01-01-2022",
                                    },
                                    {
                                        "endDate": "01-01-2036",
                                        "goalAmt": [21000, 21000, 21000, 21000, 21000],
                                        "goalId": "Goal4",
                                        "modifiedGoalAmt": [21000, 21000, 21000, 21000, 21000],
                                        "priority": "Need",
                                        "startDate": "01-01-2032",
                                    },
                                ],
                                "isGoalRealistic": True,
                                "lossThreshold": 11500,
                                "meetGoalPriority": True,
                                "meetLossPriority": False,
                                "oneTimeTopUp": -3145.0,
                                "pDeltaCurrentGoalProbability": 0.8676,
                                "pDeltaCurrentLossThresholdProbability": 0.9061,
                                "recommendedPortfolioId": 8,
                            },
                            "pathReport": {
                                "bestCasePath": [
                                    86000.0,
                                    127207.9761677005,
                                    147666.60905012494,
                                    162092.25955168568,
                                    177927.16156739573,
                                    188161.26977537488,
                                    202728.22345570617,
                                    214388.8522061468,
                                    230986.27676325428,
                                    244272.2671096913,
                                    258322.44804770465,
                                    244272.2671096913,
                                    235332.6435835653,
                                    153276.04712971285,
                                    134524.79155187192,
                                    115886.906239491,
                                ],
                                "portfolioPath": [16, 16, 16, 16, 16, 16, 14, 11, 8, 4, 1, 1, 1, 1, 1],
                                "wealthPath": [
                                    86000.0,
                                    90947.0,
                                    97987.0,
                                    107560.0,
                                    118067.0,
                                    129602.0,
                                    142262.0,
                                    153276.0,
                                    168250.0,
                                    181275.0,
                                    191702.0,
                                    174641.0,
                                    162092.0,
                                    78346.0,
                                    56013.0,
                                    33861.0,
                                ],
                                "worstCasePath": [
                                    86000.0,
                                    63820.84257832782,
                                    61485.19345810165,
                                    60349.62127093149,
                                    60349.62127093149,
                                    61485.19345810165,
                                    62642.13320591445,
                                    65021.731204759264,
                                    66245.21642244268,
                                    68761.68539251604,
                                    70055.543677461,
                                    49160.76196353458,
                                    29718.490368845898,
                                    12.044947185986102,
                                    12.044947185986102,
                                    12.044947185986102,
                                ],
                            },
                            "pathReportMod": {
                                "bestCasePath": [
                                    86000.0,
                                    109564.25546198961,
                                    120259.40791725351,
                                    131998.57135547,
                                    142209.74784115516,
                                    153210.8429157394,
                                    165062.96328695258,
                                    174549.95419295735,
                                    188052.83054631334,
                                    198861.16366789828,
                                    210290.70554517052,
                                    226558.4233361328,
                                    214244.71227383916,
                                    147607.84307609856,
                                    129562.46344048432,
                                    109564.25546198961,
                                ],
                                "portfolioPath": [8, 8, 8, 8, 8, 8, 8, 6, 4, 2, 1, 1, 1, 1, 1],
                                "wealthPath": [
                                    86000.0,
                                    89264.0,
                                    97978.0,
                                    105557.0,
                                    115861.0,
                                    122521.0,
                                    131999.0,
                                    139585.0,
                                    147608.0,
                                    156092.0,
                                    165063.0,
                                    174550.0,
                                    159027.0,
                                    90943.0,
                                    68773.0,
                                    46508.0,
                                ],
                                "worstCasePath": [
                                    86000.0,
                                    74093.1706955856,
                                    71383.54508668424,
                                    70066.12159187142,
                                    70066.12159187142,
                                    70066.12159187142,
                                    71383.54508668424,
                                    74093.1706955856,
                                    75486.31308254565,
                                    78351.67437556674,
                                    81325.8010196067,
                                    84412.82160452646,
                                    65035.119539598556,
                                    12.584106524912224,
                                    12.584106524912224,
                                    12.584106524912224,
                                ],
                            },
                        },
                    },
                }
            }
        }
    },
}
