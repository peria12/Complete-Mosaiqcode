from pydantic import BaseModel, Field, model_validator
from typing import Any


class InternalServerMessage(BaseModel):
    message: str = Field(title="message", description="error message", examples=["Internal Server Error"])
    statusCode: int = Field(title="statuscode", description="statuscode", examples=[500])


class SignInInputModel(BaseModel):
    email: str = Field(
        title="",
        description="Email to login.",
        examples=["abc@abc.com"],
    )
    password: str = Field(
        title="",
        description="Password to login.",
        examples=["Gpattm@#124"],
    )

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class AuthenticationResult(BaseModel):
    AccessToken: str
    ExpiresIn: int
    IdToken: str
    RefreshToken: str
    Scope: str
    TokenType: str


class SignInOutputModel(BaseModel):
    AuthenticationResult: AuthenticationResult

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


signin_response_model = {
    "model": SignInOutputModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {
                        "AuthenticationResult": {
                            "AccessToken": "eyJraWQiOiJFSDZuN3p5S1UzNjZNaWtoTEphVkVIMWpsR29SWWllOGZWQWl3aHg4cWdNIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULjdfUE1hVDZ5SjJBQ0FuRWZlTzN5cmhCTGJ4OTBPdGk2TWg0NVVyZjgyeDgub2Fyenc0amV3U3RxVndneGI2OTYiLCJpc3MiOiJodHRwczovL2Z0ZXh0Lm9rdGEuY29tL29hdXRoMi9kZWZhdWx0IiwiYXVkIjoiYXBpOi8vZGVmYXVsdCIsImlhdCI6MTY5NzYzMDkzOCwiZXhwIjoxNjk3NjM0NTM4LCJjaWQiOiIwb2FkZjN4MmJzZktTMWIxOTY5NiIsInVpZCI6IjAwdWNxbDRvcENpaHV4VDBYNjk2Iiwic2NwIjpbIm9mZmxpbmVfYWNjZXNzIiwib3BlbmlkIl0sImF1dGhfdGltZSI6MTY5NzYzMDkzOCwic3ViIjoiZ2Rhc2FyYUBmcmsuY29tIn0.OhzixTj3lI8jbrt-du4ycWTF4TATTW93esgh3GTFi5qVFk97GCCWUw-BC7WRKoWptU3LdIm3keYcevDQwp8BqhX2xI6jRPz-B_zCn9Lpf4BLOF5o2KvbJQexLLB9s4jR5GFjXMtZwLTvk9Z_HWRLHS_JoxrIfy_Gaub6K-_iXF2hjiSwwNHWfssux5bwUZ9QSzbay-x_wyfrQR-FAAhxpgqTc6IqliZk9zAhJ6X9pFm44dfxKyl0pmWhYF8Ls_zQX7waBzq3tH2vX5_MIPDN3_xEaqngfFZdJulNaTBOsndvTQmyQvm9VyETocrIoeL4Dr8pd5VVLBYKKARcIl7g3w",
                            "ExpiresIn": 3600,
                            "IdToken": "eyJraWQiOiJFSDZuN3p5S1UzNjZNaWtoTEphVkVIMWpsR29SWWllOGZWQWl3aHg4cWdNIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiIwMHVjcWw0b3BDaWh1eFQwWDY5NiIsInZlciI6MSwiaXNzIjoiaHR0cHM6Ly9mdGV4dC5va3RhLmNvbS9vYXV0aDIvZGVmYXVsdCIsImF1ZCI6IjBvYWRmM3gyYnNmS1MxYjE5Njk2IiwiaWF0IjoxNjk3NjMwOTM4LCJleHAiOjE2OTc2MzQ1MzgsImp0aSI6IklELmFqcDAya0tOdlRSX3E4N3ZYYkN4NXpWNU1tVUJVQlJOZXBTTmFnLUpkX2siLCJhbXIiOlsicHdkIl0sImlkcCI6IjAwbzF6MHlpNE9MaURidzNTNjk2IiwiYXV0aF90aW1lIjoxNjk3NjMwOTM4LCJhdF9oYXNoIjoiSjY2ckNmRG05bkExQ0gzUVdrZUc4dyJ9.o2fv3RRzemrggEFUO575GdDl7l0keOVAM-YxINcKGf4iLWd1BFpaOwtubUe6EKReRZAZdEsG8jH2P2rbYoGDDG7OIwRIQGV1zMgEN3FrtOXNRFakdHFkJUOYoRuxOjXerj9ejDznoovcH_zerKhCtaNnP_r40TDyqLYO_DLldWhAJXNVc0GQWYCYr0cyQV3bgY9r_jTr1MejxkgavmSsEQxIhtV9fMNo3kf368mvFptPkaQgum52dXlJjz6K1zol0v6RkIUXNStUXdQ58tdyPl3u23_ifG1BbY0bYZqVgeWF3CymrpWmdeHTXrDvm4hZjoqMtyKz6HK9gHj433RX1A",
                            "RefreshToken": "PYYDABEu2kvD2x78cwrIi7SbS8ykP-lotcFbmaVMlPc",
                            "Scope": "offline_access openid",
                            "TokenType": "Bearer",
                        }
                    },
                }
            }
        }
    },
}


class ForgotPasswordInputModel(BaseModel):
    email: str = Field(
        title="",
        description="Registered email to recieve password.",
        examples=["abc@abc.com"],
    )

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class ForgotPasswordOutputModel(BaseModel):
    success: bool = Field(description="Returns either ‘true’ or ‘false’")


forgotpwd_response_model = {
    "model": ForgotPasswordOutputModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {"success": True},
                }
            }
        }
    },
}


class ChangePasswordInputModel(BaseModel):
    email: str = Field(
        title="",
        description="Email of the user for change password.",
        examples=["abc@abc.com"],
    )
    oldPassword: str = Field(
        title="",
        description="oldPassword for password change.",
        examples=["oldpass@#&7"],
    )
    newPassword: str = Field(title="", description="newPassword which will be used from now.", examples=["newpass@#&7"])

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class ChangePasswordOutputModel(BaseModel):
    success: bool = Field(
        title="",
        description="Returns ‘true’ when successful and ‘false’ when failed.",
        examples=["abc@abc.com"],
    )


changepasswd_response_model = {
    "model": ChangePasswordOutputModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {"success": True},
                }
            }
        }
    },
}


class RefreshTokenStatus(BaseModel):
    body: None
    message: str = Field(description="message", examples=["Invalid Refresh Token"])
    statusCode: int = Field(description="status code", examples=[400])


class RefreshTokenInputModel(BaseModel):
    refreshToken: str = Field(
        title="Refresh Token",
        description="Refresh Token.",
        examples=["HEpb6yNYH68XTFING3a_RkqLHOgFosQv5-7W0_So3VE"],
    )

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class RefreshTokenOutputModel(BaseModel):
    success: bool = Field(
        title="",
        description="Returns ‘true’ when successful and ‘false’ when failed.",
        examples=["abc@abc.com"],
    )


refresh_token_response_model = {
    "model": RefreshTokenOutputModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {"success": True},
                }
            }
        }
    },
}
