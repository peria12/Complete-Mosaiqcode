from pydantic import BaseModel, Field, model_validator
from typing import Any, Literal, Optional


class GoeForDecumulationInputModel(BaseModel):
    futureAnnuityProj: bool = Field(
        title="",
        description="If set to True, provides an array of future annuity projections.",
        examples=[True],
    )

    riskProfile: Literal["Conservative", "Moderate", "Aggressive"] = Field(
        examples=["Aggressive"],
        title="",
        description="Defines the user’s risk profile – does not vary by goal for each investor. <br> \
        On a default basis, GOE is configured for three Risk Profile levels, but it can be customized for up to five levels.",
    )
    currentPortfolioId: int = Field(
        examples=[None],
        title="",
        nullable=True,
        description="Displays the current portfolio index that the goal is allocated to; \
                    if GOE is getting executed for the first time, it should be null.\
                    For cases where updated probability is needed in between the scheduled re-allocation dates,\
                    this parameter should be set to the portfolio index the investor is assigned to.",
    )
    dateOfBirth: str = Field(
        examples=["15-06-2020"],
        title="",
        nullable=False,
        description="Investor’s DOB",
    )
    gender: str = Field(
        examples=["unisex"],
        default=None,
        title="",
        nullable=False,
        description="Gender is mandatory if the type of mortality table to be used is 'Unisex', 'GenderBased', 'GenderAndHealthStatusBased'. Gender should not be passed if the type of mortality table to be used is 'HealthStatusBased'.",
    )
    healthStatus: int = Field(
        examples=[0],
        default=None,
        title="",
        nullable=False,
        description="Health status is mandatory if the type of mortality table to be used is 'HealthStatusBased', 'GenderAndHealthStatusBased'",
    )
    dbIncome: list[float] = Field(
        examples=[[1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0]],
        title="",
        description="Income from DB plans, if any. All the values in the array must be rounded off to one decimal.",
    )
    otherGuaranteedIncome: list[float] = Field(
        examples=[[1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0]],
        title="",
        description="Other guaranteed income, if any. All the values in the array must be rounded off to one decimal.",
    )
    existingAnnuitiesIncome: list[float] = Field(
        examples=[[1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0]],
        title="",
        description="Income from existing annuities, if any. All the values in the array must be rounded off to one decimal.",
    )
    stateIncome: list[float] = Field(
        examples=[[1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0]],
        title="",
        description="Income from State Pension or Social Security. All the values in the array must be rounded off to one decimal.",
    )
    targetExpenditures: list[float] = Field(
        examples=[[20400.0, 20808.0, 21224.2, 21648.7, 22081.7]],
        title="",
        description="Total expenditure goals of the investor. All the values in the array must be rounded off to one decimal.",
    )
    currentWealth: float = Field(
        title="",
        examples=[10000],
        ge=0,
        nullable=True,
        description="Current wealth when the GOE is being called or executed. At the time of initial onboarding, currentWealth = initialInvestment. \
                                                            At subsequent re-allocation dates, currentWealth would be the portfolio account value at the time.",
    )
    initialInvestment: float = Field(
        title="",
        examples=[100000],
        ge=0,
        description="Defines the initial investment amount to the goal. Its value must be rounded to one decimal place.",
    )
    includeAnnuities: bool = Field(
        title="",
        description="Flag to include annuitisation and annuity income in recommendation. If client needs annuitisation , this needs to be set to true when calling GOE on each re-allocation date.",
        examples=[True],
    )
    infusionType: Literal["yearly", "monthly"] = Field(
        examples=["yearly"],
        title="",
        description="Indicates the frequency of cash flows – determines the cash flow array corresponding to the ‘infusions’ parameter.<br> ",
    )
    cashflowDate: str = Field(
        examples=["01-01-2024"],
        default=None,
        title="",
        nullable=True,
        description='Cashflow date of the goal - this is the date (year is ignored) on which infusions/withdrawals \
                    would be realized for the goal. Format is "dd-mm-yyyy" <br> \
                    If not passed or value is null, the algorithm would consider the first reallocation date as the cashflow date.',
    )
    startDate: str = Field(
        examples=["01-01-2023"],
        title="",
        description="Defines the start date of goal.Valid input format is date – ‘dd-mm-yyyy’ ",
    )
    endDate: str = Field(
        examples=["01-01-2052"],
        title="",
        description="Defines the end date of goal.Valid input format is date – ‘dd-mm-yyyy’ ",
    )
    currDate: Optional[str] = Field(
        default=None,
        title="",
        description="This is an optional parameter that can be used to simulate the current date to be the specified value. <br> \
                    GOE will process the request as if you are making the API call on the specified date. If not passed, the current system date will be used as the current date.",
    )
    annuityRate: float = Field(
        title="",
        examples=[0.0865],
        description="Annuity payout rate for the investor. Its value must be rounded to four decimal places.",
    )
    reallocationFreq: Literal["yearly", "half-yearly", "quarterly"] = Field(
        examples=["yearly"],
        title="",
        description="Describes the frequency of re-allocation. If set to 'yearly', GOE would assume the re-allocation to happen once a year. Response parameters such as portfolio path and wealth path would have one value each year.",
    )
    retirementAge: int = Field(
        examples=[65],
        default=65,
        title="",
        description="Captures the retirement age of the investor.",
    )
    isNewGoalPriority: bool = Field(
        title="",
        description="If investor/end user changes the goal priority in between the re-allocation dates, this is set to ‘true’. \
                                    For new plans, this needs to be ‘true’.",
        examples=[True],
    )
    isNewRiskProfile: bool = Field(
        title="",
        description="If investor/end user changes the risk profile in between the re-allocation dates, this is set to ‘true’. \
                                                For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewInvestmentTenure: bool = Field(
        title="",
        description="If investor/end user changes the goal investment tenure after onboarding and before the next immediate re-allocation date, \
                                    this is set to ‘true’. For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewGoal: bool = Field(
        title="",
        description="If investor/end user changes the target expenditures, state income, income from existing annuities, income from defined benefits or other guaranteed income in between the re-allocation dates, this is set to ‘true’.",
        examples=[True],
    )
    reallocate: bool = Field(
        default=False,
        title="",
        description="If the client wants GOE to reallocate between the scheduled re-allocation dates, this should be set to ‘true’. ",
    )
    lossThreshold: float = Field(
        examples=[100000],
        title="",
        ge=0,
        nullable=True,
        description="Loss threshold value – the wealth amount that the investor does not want to end up below at the end of the goal tenure.<br> \
                                                If not passed or value is ‘null’, the GOE algo would calculate the loss threshold. If a number value is passed, GOE would consider that amount as the loss threshold.<br> \
                                                If loss threshold is not available, this needs to be passed as ‘null’, and GOE would calculate the loss threshold and return as a part of the response ‘loss threshold’. <br> \
                                                This amount needs to be stored, and should be passed as ‘lossThreshold’ on subsequent GOE calls.",
    )

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class DecumulationResponseBody(BaseModel):
    wealthPath: list[float] = Field(
        examples=[[5000.0, 5200.0, 5400.0, 5600.0]],
        title="",
        description="Projected Wealth Path",
    )
    riskThreshold: str = Field(
        title="",
        examples=["High"],
        description="Solvency Risk/ Risk Threshold",
    )
    goalProbability: float = Field(
        examples=[0.62],
        description="Probability of meeting the GOE Payout without adjusting for Longevity.",
    )
    currentGoalProbability: float = Field(
        examples=[0.2947],
        description="",
    )
    allocationAnnuity: float = Field(
        examples=[100001.0],
        description="Wealth allocated to Annuities",
    )
    allocationGOE: float = Field(
        examples=[200000.5],
        description="Wealth allocated to GOE",
    )
    goalProbabilityLongevityAdjusted: float = Field(
        examples=[0.8],
        description="Probability of meeting the GOE Payout after adjusting for Longevity",
    )
    payoutGOE: list[float] = Field(
        examples=[[5000.0, 5200.0, 5400.0, 5600.0]],
        title="",
        description="Estimated Payout from GOE. The first element of the array represents the suggested payout from GOE on the current date, while the next elements represent the suggested payout from GOE on following cashflow dates.",
    )
    recommendedPortfolioId: int = Field(
        examples=[10],
        description="recommended portfolio index from GOE",
    )
    fundedness: str = Field(
        title="",
        examples=["UnderFunded"],
        description="Current Fundedness status",
    )
    guaranteedIncomePercent: float = Field(
        examples=[0.91],
        description="% of expenditures from Guaranteed Income based on input parameters.",
    )
    isGoalRealistic: bool = Field(
        title="",
        description="To understand if the goal can be met with a reasonable probability (set by the ‘unrealistic’ goal probability value in the GOE config).\
                    If current goal probability < desired target goal probability (defined by the goal priority), the goal is termed unrealistic.",
        examples=[True],
    )
    bankruptcyMessage: str = Field(
        title="",
        examples=["NA"],
        description="Message about bankruptcy probability",
    )
    additionalPayoutAnnuity: float = Field(
        examples=[1007.5],
        description="Estimated additional Payout from annuities this year.",
    )
    portfolioPath: list[float] = Field(
        examples=[[15, 15, 14, 13, 12, 11, 10, 8, 5, 4, 2, 1]],
        title="",
        description="Projected Portfolio Path",
    )
    payoutAnnuity: list[float] = Field(
        examples=[[5000.0, 5200.0, 5400.0, 5600.0]],
        title="",
        description="Estimated Payout from Annuities. The first element of the array represents the payout from annuities on the current date, while the next elements represent the payout from annuities on following cashflow dates.",
    )
    consumptionGoal: list[float] = Field(
        examples=[[10000.0, 10200.0, 10400.0, 10600.0]],
        title="",
        description="Consumption goal for GOE. The first element of the array represents the consumption goal on the current date, while the next elements represent the consumption goal on following cashflow dates.",
    )
    recommendedConsumption: list[float] = Field(
        examples=[[10000.0, 10200.0, 10400.0, 10600.0]],
        title="",
        description="Total recommended consumption/Income from all income sources. The first element of the array represents the recommended consumption on the current date, while the next elements represent the recommended consumptions on following cashflow dates.",
    )


class DecumulationResponseModel(BaseModel):
    statusCode: int
    message: str
    body: DecumulationResponseBody


decumulation_response_model = {
    "model": DecumulationResponseModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {
                        "statusCode": 200,
                        "message": "Success",
                        "body": {
                            "wealthPath": [89716.0, 91018.0, 78018.0, 64508.0, 51157.0, 37804.0, 23502.0, 7865.0, 9.0],
                            "riskThreshold": "High",
                            "goalProbability": 0.3448,
                            "currentGoalProbability": 0.2947,
                            "allocationAnnuity": 0.0,
                            "allocationGOE": 89716.0,
                            "goalProbabilityLongevityAdjusted": 0.6138,
                            "payoutGOE": [10284.0, 13000.0, 13510.0, 14030.2, 14560.8, 15102.0, 15654.0, 7865.0, 9.0],
                            "recommendedPortfolioId": 11.0,
                            "fundedness": "UnderFunded",
                            "guaranteedIncomePercent": 0.5,
                            "isGoalRealistic": False,
                            "bankruptcyMessage": "NA",
                            "additionalPayoutAnnuity": 0.0,
                            "portfolioPath": [11.0, 11.0, 11.0, 11.0, 11.0, 11.0, 11.0, 8.0],
                            "payoutAnnuity": [1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0, 1000.0],
                            "consumptionGoal": [
                                12500.0,
                                13000.0,
                                13510.0,
                                14030.2,
                                14560.8,
                                15102.0,
                                15654.0,
                                16217.1,
                                16791.4,
                            ],
                            "recommendedConsumption": [
                                22784.0,
                                25500.0,
                                26010.0,
                                26530.2,
                                27060.8,
                                27602.0,
                                28154.0,
                                20365.0,
                                12509.0,
                            ],
                        },
                    },
                }
            }
        }
    },
}
