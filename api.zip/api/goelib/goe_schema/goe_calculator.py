from pydantic import BaseModel, Field, model_validator
from typing import Any, Literal, Optional


class GoalCalculatorInputModel(BaseModel):
    isNewGoal: bool = Field(
        title="",
        description="If investor/end user changes the goal amount, in between the re-allocation dates, this is set to ‘true’. For retirement scenarios, this would be a change in retirement income goal, while for a capital accumulation goal, \
                                                this would be a change in the lumpsum accumulation target. For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewRiskProfile: bool = Field(
        title="",
        description="If investor/end user changes the goal priority in between the re-allocation dates, this is set to ‘true’. \
                                                For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewInvestmentTenure: bool = Field(
        title="",
        description="If investor/end user changes the goal investment tenure after onboarding and before the next immediate re-allocation date, \
                                    this is set to ‘true’. For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewGoalPriority: bool = Field(
        title="",
        description="If investor/end user changes the goal priority in between the re-allocation dates, this is set to ‘true’. \
                                    For new plans, this needs to be ‘true’.",
        examples=[True],
    )
    reallocate: bool = Field(
        default=False,
        title="",
        description="If the client wants GOE to reallocate between the scheduled re-allocation dates, this should be set to ‘true’. ",
    )
    useAgeBasedCap: bool = Field(
        default=False,
        title="",
        description="By default, the risk profile of the participant is considered while determining the max equity exposure \
                                available for GOE to optimize. When opted for this feature, the risk profile of the participant is ignored and the max equity allocation (available for GOE to optimize) is determined using the participant’s current age, retirement age and a mapper table determining the maximum equity allocation",
    )

    reallocationFreq: Literal["yearly", "half-yearly", "quarterly"] = Field(
        examples=["yearly"], title="", description="Describes the frequency of re-allocation."
    )

    # isNearTermVolatility: bool = Field(
    #     default=False,
    #     title="",
    #     description="When the near-term volatility indicator flashes, this is set to ‘true’. For first time calls to GOE, \
    #                                             this needs to be set to ‘true’.",
    #     examples=[True],
    # )
    getPath: bool = Field(
        title="",
        description="Show ideal portfolio path over time. If getPath parameter is set to False, the portfolio path would not be returned in the response payload",
        examples=[True],
    )
    currentPortfolioId: int = Field(
        examples=[None],
        title="",
        nullable=True,
        description="Displays the current portfolio index that the goal is allocated to; \
                                                     if GOE is getting executed for the first time, it should be null.",
    )
    lossThreshold: int = Field(
        examples=[None],
        title="",
        nullable=True,
        ge=0,
        description="Loss threshold value – the wealth amount that the investor does not want to end up below at the end of the goal tenure.<br> \
        If the input parameter ‘lossThreshold’ is not passed or value is ‘null’, this parameter is calculated by GOE. \
        If the input parameter ‘lossThreshold’ is a number value, GOE will consider this as the loss threshold.",
    )

    scenarioType: Literal["regular", "retirement"] = Field(
        examples=["regular"],
        title="",
        description="Determines the type of the scenario, the suggested portfolio and the wealth glide path is created accordingly. <br> ",
    )

    currDate: Optional[str] = Field(
        default=None,
        examples=["19-09-2023"],
        title="",
        description="This is an optional parameter that can be used to simulate the current date to be the specified value. <br> \
                                                    GOE will process the request as if you are making the API call on the specified date. If not passed, the current system date will be used as the current date.",
    )
    riskProfile: Literal["Conservative", "Moderate", "Aggressive"] = Field(
        examples=["Aggressive"],
        title="",
        description="Defines the user’s risk profile – does not vary by goal for each investor. <br> \
        On a default basis, GOE is configured for three Risk Profile levels, but it can be customized for up to five levels.",
    )
    initialInvestment: float = Field(
        title="", examples=[100000], ge=0, description="Defines the initial investment amount to the goal."
    )
    currentWealth: float = Field(
        title="",
        examples=[100000],
        ge=0,
        nullable=True,
        description="Current wealth when the GOE is being called or executed. At the time of initial onboarding, currentWealth = initialInvestment. \
                                                            At subsequent re-allocation dates, currentWealth would be the portfolio account value at the time.",
    )
    cashflowDate: str = Field(
        examples=[None],
        default=None,
        title="",
        nullable=True,
        description='Cashflow date of the goal - this is the date (year is ignored) on which infusions/withdrawals \
                                                                would be realized for the goal. Format is "dd-mm-yyyy" <br> \
                                                                If not passed or value is null, the algorithm would consider the first reallocation date as the cashflow date.',
    )
    calibrateRecommendations: bool = Field(
        examples=[True],
        default=False,
        title="",
        description="Setting this parameter to true will ensure that GOE runs a calibration logic for the recommendations so \
                    that incorporating the recommendations would result in reaching the goal probability target (for example, 85% for a Need priority).",
    )
    goalPriority: Literal["Need", "Want", "Wish", "Dream"] = Field(
        examples=["Need"],
        title="",
        description="Defines the importance a goal holds for a specific user. Order of priority is Need > Want > Wish > Dream <br> \
        goalPriority can be from 1 to 4 levels. However, note that Goal priority defines the target probabilities and the loss threshold values. ",
    )
    goalAmount: float = Field(
        examples=[0],
        title="",
        ge=0,
        # nullable=True,
        description="For regular scenarios, either the goal amount field shouldn't be provided in the input payload, or if provided, it should either be 'null' or '0.<br> \
        For retirement cases where  the intent is to calculate an appropriate bequest amount, the bequest (“goal_amt”) should be specified as ‘null’ or ‘0’. For other cases, it can any number greater than zero.",
    )
    startDate: str = Field(
        examples=["19-09-2023"],
        title="",
        description="Defines the start date of goal.Valid input format is date – ‘dd-mm-yyyy’ ",
    )
    endDate: str = Field(
        examples=["01-11-2032"],
        title="",
        description="Defines the end date of goal.Valid input format is date – ‘dd-mm-yyyy’ ",
    )
    infusionType: Literal["yearly", "monthly"] = Field(
        examples=["yearly"],
        title="",
        description="Indicates the frequency of cash flows – determines the cash flow array corresponding to the ‘infusions’ parameter.<br> ",
    )
    infusions: list[float] = Field(
        examples=[[0, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 0]],
        title="",
        description="Cash flows from the user, recurring payments yearly <br>\
                                                        The length for this parameter is dynamic depending on the goal tenure, start date and end date.\
                                                        The reference will always be on the created date. So, the first infusion will be on the first day of the goal \
                                                        followed by infusions every year/month followed by the last infusion/withdrawal on the last day of the goal.<br> <br> \
                                                        The values are positive in case of infusions; negative in case of withdrawals; zero in case of no cashflows; frequency depends on ‘infusion_type’ parameter",
    )
    stepupDate: str = Field(
        examples=["01-01-2024"],  # Revert to null once this field is setup to nullable
        title="",
        default=None,
        # nullable=True,
        description=" This is a optional parameter used for determining the stepup date in case of monthly cashflows that are supposed to be inflation adjusted. The trigger would be through passing the 'inflation' parameter in the user payload. ",
    )

    inflation: float = Field(
        examples=[0.0],
        nullable=True,
        default=None,
        ge=0,
        le=1,
        title="",
        description="This is a optional parameter which captures the user-provided inflation number, to be considered (only) in the yearly/monthly recommendations.",
    )
    currentAge: int = Field(
        examples=[None],
        default=None,
        title="",
        description="Captures the current age of the investor.<br> \
        Optional Parameter.Need to be passed if ‘considerMortality’ is set to True or ‘requiredDataAvailable’ is set to False.",
    )
    retirementAge: int = Field(
        examples=[None],
        default=None,
        title="",
        description="Captures the retirement age of the investor.<br> \
        Optional Parameter.Need to be passed if ‘considerMortality’ is set to True or ‘requiredDataAvailable’ is set to False.",
    )

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class GoalCalculatorOutputModel(BaseModel):
    statusCode: int = Field(
        title="",
        examples=[200],
        description="Status code for the response.",
    )
    message: str = Field(
        title="",
        examples=["Success"],
        description="Returns appropriate message for each status code.",
    )
    body: dict
    infusions: list[float] = Field(
        examples=[[7500.0, 7500.0, 7500.0, 7500.0, 7500.0, 7500.0]], title="", description=""
    )
    requestType: str
    goalAmt: float


goal_calculator_response_model = {
    "model": GoalCalculatorOutputModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {
                        "message": "Success",
                        "statusCode": 200,
                        "body": {
                            "goalAmt": 162010.0,
                            "infusions": [
                                0.0,
                                5000.0,
                                5000.0,
                                5000.0,
                                5000.0,
                                5000.0,
                                5000.0,
                                5000.0,
                                5000.0,
                                5000.0,
                                0.0,
                            ],
                        },
                    },
                }
            }
        }
    },
}
