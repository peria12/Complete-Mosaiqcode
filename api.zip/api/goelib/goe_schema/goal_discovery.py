from pydantic import BaseModel, model_validator, Field
from typing import Any, List, Literal

from pydantic import BaseModel, Field

class TargetWealth(BaseModel):
    min: float = Field(..., description="Minimum target wealth")
    max: float = Field(..., description="Maximum target wealth")

class GoalTenure(BaseModel):
    min: int = Field(..., description="Minimum goal tenure (in years)")
    max: int = Field(..., description="Maximum goal tenure (in years)")

class InitialInvestment(BaseModel):
    min: float = Field(..., description="Minimum initial investment")
    max: float = Field(..., description="Maximum initial investment")

class Infusions(BaseModel):
    min: int = Field(..., description="Minimum yearly infusions")
    max: int = Field(..., description="Maximum yearly infusions")

class GoalPriority(BaseModel):
    need: bool = Field(..., description="Priority for needs")
    want: bool = Field(..., description="Priority for wants")

class GoalDiscoveryInputModel(BaseModel):
    goalType: str = Field(..., description="Type of financial goal (e.g., 'retirement', 'wealth')")
    riskProfile: str = Field(..., description="Risk profile (e.g., 'conservative')")
    initialInvestment: InitialInvestment = Field(..., description="Initial investment range")
    currency: str = Field(..., description="Currency (e.g., 'USD')")
    infusionType: str = Field(..., description="Type of infusions (e.g., 'yearly')")
    infusions: Infusions = Field(..., description="Yearly infusions range")
    goalPriority: list = Field(..., description="Priority for needs, wants, wish, dream")
    goalTenure: GoalTenure = Field(..., description="Goal tenure range")
    targetWealth: TargetWealth = Field(..., description="Target wealth range")
    pageSize: int = Field(..., description="Page size")

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class GoalDiscoveryGetInputModel(BaseModel):
    requestId: str = Field(..., description="requestId to look up for paginated results for the request made in goaldiscovery post request.")
    pageId: str = Field(..., description="is a page number which user like to visit.")




class GoalDiscoveryOutputModel(BaseModel):
    statusCode: int = Field(
        title="",
        examples=[200],
        description="Status code for the response.",
    )
    message: str = Field(
        title="",
        examples=["Success"],
        description="Returns appropriate message for each status code.",
    )
    body: dict
    # goal_response_list: List[GoalResponseItem] = Field(
    #     title="",
    #     examples=[
    #         {
    #             "Goal_ID": "Goal_1",
    #             "Goal": "Saving",
    #             "Orig_Curr_Wealth": 141412.0,
    #             "Min_Initial_Needed": 1114000.0,
    #             "Wealth_Split": 1038906.0,
    #             "Shortfall": -75094.0,
    #             "Funded_Status": "Underfunded",
    #         },
    #         {
    #             "Goal_ID": "Goal_2",
    #             "Goal": "Fixed",
    #             "Orig_Curr_Wealth": 897494.0,
    #             "Min_Initial_Needed": 906800.0,
    #             "Wealth_Split": 0.0,
    #             "Shortfall": -906800.0,
    #             "Funded_Status": "Underfunded",
    #         },
    #     ],
    #     description="Optimal wealth split details for all goals",
    # )
    # requestType: str
    # respTime: float


goal_discovery_response_model_v4 = {
    "model": GoalDiscoveryOutputModel,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {
                        "statusCode": 200,
                        "message": "Success",
                        "body": {
                            "goal_response_list": [
                                {
                                    "Goal_ID": "Goal_1",
                                    "Goal": "Saving",
                                    "Orig_Curr_Wealth": 141412.0,
                                    "Min_Initial_Needed": 1114000.0,
                                    "Wealth_Split": 1038906.0,
                                    "Shortfall": -75094.0,
                                    "Funded_Status": "Underfunded",
                                },
                                {
                                    "Goal_ID": "Goal_2",
                                    "Goal": "Fixed",
                                    "Orig_Curr_Wealth": 897494.0,
                                    "Min_Initial_Needed": 906800.0,
                                    "Wealth_Split": 0.0,
                                    "Shortfall": -906800.0,
                                    "Funded_Status": "Underfunded",
                                },
                            ],
                            "request_type": "initial_wealth_split",
                            "respTime": 19.845118045806885,
                        },
                    },
                }
            }
        }
    },
}
