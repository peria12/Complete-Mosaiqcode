from pydantic import BaseModel, Field, model_validator, confloat
from typing import Any, Literal, Dict, Optional


class RunPipeInputModel(BaseModel):
    isNewGoalPriority: bool = Field(
        title="",
        description="If investor/end user changes the goal priority in between the re-allocation dates, this is set to ‘true’. \
                                    For new plans, this needs to be ‘true’.",
        examples=[True],
    )
    isNewInvestmentTenure: bool = Field(
        title="",
        description="If investor/end user changes the goal investment tenure after onboarding and before the next immediate re-allocation date, \
                                    this is set to ‘true’. For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNearTermVolatility: bool = Field(
        default=False,
        title="",
        description="When the near-term volatility indicator flashes, this is set to ‘true’. For first time calls to GOE, \
                                                this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewRiskProfile: bool = Field(
        title="",
        description="If investor/end user changes the goal priority in between the re-allocation dates, this is set to ‘true’. \
                                                For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    isNewGoal: bool = Field(
        title="",
        description="If investor/end user changes the goal amount, in between the re-allocation dates, this is set to ‘true’. For retirement scenarios, this would be a change in retirement income goal, while for a capital accumulation goal, \
                                                this would be a change in the lumpsum accumulation target. For first time calls to GOE, this needs to be set to ‘true’.",
        examples=[True],
    )
    reallocate: bool = Field(
        default=False,
        title="",
        description="If the client wants GOE to reallocate between the scheduled re-allocation dates, this should be set to ‘true’. ",
    )
    cashflowDate: str = Field(
        examples=["01-01-2024"],
        default=None,
        title="",
        nullable=True,
        description='Cashflow date of the goal - this is the date (year is ignored) on which infusions/withdrawals \
                                                                would be realized for the goal. Format is "dd-mm-yyyy" <br> \
                                                                If not passed or value is null, the algorithm would consider the first reallocation date as the cashflow date.',
    )

    lossThreshold: float = Field(
        examples=[None],
        default=None,
        title="",
        ge=0,
        nullable=True,
        description="Loss threshold value – the wealth amount that the investor does not want to end up below at the end of the goal tenure.<br> \
                                                If not passed or value is ‘null’, the GOE algo would calculate the loss threshold. If a number value is passed, GOE would consider that amount as the loss threshold.<br> \
                                                If loss threshold is not available, this needs to be passed as ‘null’, and GOE would calculate the loss threshold and return as a part of the response ‘loss threshold’. <br> \
                                                This amount needs to be stored, and should be passed as ‘lossThreshold’ on subsequent GOE calls.",
    )
    getPath: bool = Field(
        title="",
        description="Show ideal portfolio path over time. If getPath parameter is set to False, the portfolio path would not be returned in the response payload",
    )
    reallocationFreq: Literal["yearly", "half-yearly", "quarterly"] = Field(
        examples=["yearly"], title="", description="Describes the frequency of re-allocation."
    )
    goalAmount: float = Field(
        examples=[200000],
        title="",
        ge=0,
        description="Defines the target wealth value associated with the goal at end of goal tenure. \
                                        The application accepts up to 7 digits of precision, but it might make sense to cap it at 2 decimal places.",
    )
    initialInvestment: float = Field(
        title="", examples=[140000], ge=0, description="Defines the initial investment amount to the goal."
    )
    currentWealth: float = Field(
        title="",
        examples=[150000],
        ge=0,
        nullable=True,
        description="Current wealth when the GOE is being called or executed. At the time of initial onboarding, currentWealth = initialInvestment. \
                                                            At subsequent re-allocation dates, currentWealth would be the portfolio account value at the time.",
    )
    startDate: str = Field(
        examples=["19-09-2023"],
        title="",
        description="Defines the start date of goal.Valid input format is date – ‘dd-mm-yyyy’ ",
    )
    endDate: str = Field(
        examples=["01-11-2032"],
        title="",
        description="Defines the end date of goal.Valid input format is date – ‘dd-mm-yyyy’ ",
    )
    currDate: Optional[str] = Field(
        default=None,
        examples=["19-09-2023"],
        title="",
        description="This is an optional parameter that can be used to simulate the current date to be the specified value. <br> \
                                                    GOE will process the request as if you are making the API call on the specified date. If not passed, the current system date will be used as the current date.",
    )
    goalPriority: Literal["Need", "Want", "Wish", "Dream"] = Field(
        examples=["Want"],
        title="",
        description="Defines the importance a goal holds for a specific user. Order of priority is Need > Want > Wish > Dream <br> \
        goalPriority can be from 1 to 4 levels. However, note that Goal priority defines the target probabilities and the loss threshold values. ",
    )
    currentPortfolioId: int = Field(
        examples=[None],
        title="",
        nullable=True,
        description="Displays the current portfolio index that the goal is allocated to; \
                                                     if GOE is getting executed for the first time, it should be null.",
    )

    infusions: list[float] = Field(
        examples=[[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
        title="",
        description="Cash flows from the user, recurring payments yearly <br>\
                                                        The length for this parameter is dynamic depending on the goal tenure, start date and end date.\
                                                        The reference will always be on the created date. So, the first infusion will be on the first day of the goal \
                                                        followed by infusions every year/month followed by the last infusion/withdrawal on the last day of the goal.<br> <br> \
                                                        The values are positive in case of infusions; negative in case of withdrawals; zero in case of no cashflows; frequency depends on ‘infusion_type’ parameter",
    )
    riskProfile: Literal["Conservative", "Moderate", "Aggressive"] = Field(
        examples=["Aggressive"],
        title="",
        description="Defines the user’s risk profile – does not vary by goal for each investor. <br> \
        On a default basis, GOE is configured for three Risk Profile levels, but it can be customized for up to five levels.",
    )
    scenarioType: Literal["regular", "retirement"] = Field(
        examples=["regular"],
        title="",
        description="Determines the type of the scenario, the suggested portfolio and the wealth glide path is created accordingly. <br> ",
    )

    infusionType: Literal["yearly", "monthly"] = Field(
        examples=["yearly"],
        title="",
        description="Indicates the frequency of cash flows – determines the cash flow array corresponding to the ‘infusions’ parameter.<br> ",
    )

    currentAge: int = Field(
        examples=[None],
        default=None,
        title="",
        description="Captures the current age of the investor.<br> \
        Optional Parameter.Need to be passed if ‘considerMortality’ is set to True or ‘requiredDataAvailable’ is set to False.",
    )

    retirementAge: int = Field(
        examples=[None],
        default=None,
        title="",
        description="Captures the retirement age of the investor.<br> \
        Optional Parameter.Need to be passed if ‘considerMortality’ is set to True or ‘requiredDataAvailable’ is set to False.",
    )

    considerMortality: bool = Field(
        default=False,
        title="",
        description="Defines whether the probability of mortality should be accounted for while calculating the probability of reaching \
                    the goal and the allocation advice <br> \
                    When set to False, GOE computes the goal probability without accounting for probability of mortality.<br> \
                    When set to True, the actuarial tables must be configured for the investor.",
    )

    riskOverride: bool = Field(
        default=False,
        title="",
        description="This is an optional parameter to disable GOE’s default de-risking logic.  \
                    When set to False, GOE considers the default de-risking logic.the goal and the allocation advice <br> \
                    When set to True, GOE will not consider the default de-risking logic and will consider the risk profile of the participant for portfolio access.",
    )

    calibrateRecommendations: bool = Field(
        default=False,
        title="",
        description="Setting this parameter to true will ensure that GOE runs a calibration logic for the recommendations so \
                    that incorporating the recommendations would result in reaching the goal probability target (for example, 85% for a Need priority).",
    )

    calibrateRecommendations: bool = Field(
        examples=[True],
        default=False,
        title="",
        description="Setting this parameter to true will ensure that GOE runs a calibration logic for the recommendations so \
                    that incorporating the recommendations would result in reaching the goal probability target (for example, 85% for a Need priority).",
    )
    engagedParticipant: bool = Field(
        default=True,
        title="",
        description="This applies only to retirement use cases which specifies whether a participant is engaged or unengaged. If the “currentAge” and the \
        “retirementAge” are passed, they will be used to determine the de-risking criteria; If set to true GOE \
        will de-risk 5 years before retirement and if set to false GOE will de-risk 1 year before retirement as per the default admin configuration settings ",
    )
    requiredDataAvailable: bool = Field(
        default=True,
        title="",
        description="This indicates to GOE if all the mandatory data parameters that are required to run the GOE algorithm are available or not.<br> \
         If all the mandatory fields are available, this parameter is set to true, and they need be passed to run GOE. <br> \
        If all the mandatory fields are not available, this parameter is set to false, and they need not be passed to run GOE except the 'currentAge' and \
        the “retirementAge”; The API response body would contain only the recommended portfolio and the portfolio path, which is derived from a pre-determined glide path \
        based on the current age and the retirement age (this would be defaulted to 65 if not passed). All other response parameters would be null.",
    )

    wealthPathProbabilities: list[confloat(ge=0, le=1)] = Field(
        default=None,
        # examples=[[0.1, 0.9]],
        examples=[None],
        min_items=2,
        max_items=2,
        title="",
        description="This is an optional input parameter. If this input is passed, instead of one wealth path, the GOE output will \
        have 3 wealth paths –one path at the goal priority probability level and one path for each of the 2 probability values passed in this input array.",
    )

    lastReallocationProbability: float = Field(
        default=None,
        examples=[None],
        ge=0,
        le=1,
        title="",
        description="The goal probability as of last reallocation needs to be passed.",
    )
    lastReallocationDate: Optional[str] = Field(
        examples=["01-01-2024"],
        default=None,
        title="",
        description="The date on which last reallocation call was made to GOE.Format - dd-mm-yyyy ",
    )
    planID: str = Field(
        examples=["P4778"],
        default=None,
        title="",
        description="Plan ID of the partipant.",
    )
    participantID: str = Field(
        examples=["C9768"],
        default=None,
        title="",
        description="ID of the partipant.",
    )
    sourceID: str = Field(
        examples=["MX9768"],
        default=None,
        title="",
        description="Source ID of the plan",
    )
    useAgeBasedCap: bool = Field(
        default=False,
        title="",
        description="By default, the risk profile of the participant is considered while determining the max equity exposure \
                                available for GOE to optimize. When opted for this feature, the risk profile of the participant is ignored and the max equity allocation (available for GOE to optimize) is determined using the participant’s current age, retirement age and a mapper table determining the maximum equity allocation",
    )
    # engagedParticipant: bool = Field(None, description="engagedParticipant")

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data


class RunPipeAnalysisReport(BaseModel):
    # currentGoalProbability: float
    currentGoalProbability: float = Field(
        title="",
        ge=0,
        le=0.99,
        nullable=True,
        description="GOE’s estimated probability to achieve the goal target wealth. This is rounded to 4 decimal places. ",
    )
    currentLossThresholdProbability: float = Field(
        title="",
        ge=0,
        le=0.99,
        nullable=True,
        description="GOE’s estimated probability to remain above the loss threshold amount by the end of the goal tenure. This is rounded to 4 decimal places.",
    )
    pDeltaCurrentGoalProbability: float = Field(
        title="",
        ge=0,
        le=0.99,
        nullable=True,
        description="This probability refers to the goal probability simulation results. This parameter uses a random variable, \
        and each run returns a slightly different result. This is rounded to 4 decimal places.",
    )  # Revisit description
    pDeltaCurrentLossThresholdProbability: float = Field(
        title="",
        ge=0,
        le=0.99,
        nullable=True,
        description="Like the p-delta goal probability, this is only used for simulation purposes. It simulates the goal's loss threshold probability.\
         This is rounded to 4 decimal places.",
    )  # Revisit description
    recommendedPortfolioId: int = Field(
        title="",
        ge=1,
        description="GOE’s current recommended portfolio index.",
    )
    meetGoalPriority: bool = Field(
        title="",
        nullable=True,
        description="Checks if goal probability is more than the target probability corresponding to \
        the goal priority – Target probabilities for all goal priorities (Need, Want, Wish and Dream) are set in the GOE config. <br> \
        Note: If ‘true’, goal probability achieves the target probability – goal probability to be shown on the front end. \
        If ‘false’, goal probability falls short of the target probability –goal probability to be shown along with infusion and tenure recommendations",
    )
    isGoalRealistic: bool = Field(
        title="",
        nullable=True,
        description="To understand if the goal can be met with a reasonable probability (set by the ‘unrealistic’ goal probability value in the GOE config).\
        If current goal probability < desired target goal probability (defined by the goal priority), the goal is termed unrealistic <br> \
        Note: Flag will be set to False if the current goal probability is less than the probability threshold for realistic goal for all cases irrespective.\
        If ‘false’, goal is unrealistic - need to alert the user on the front end with a message such as ‘Goal is not realistic, please try reducing your target \
        goal amount or increasing your initial investment’",
    )
    meetLossPriority: bool = Field(
        title="",
        nullable=True,
        description="Checks if loss probability is more than the target loss probability (target set in the GOE config) <br> \
        Note: If true, estimated loss probability meets the target loss probability",
    )
    oneTimeTopUp: float = Field(
        title="",
        ge=0,
        nullable=True,
        description="Suggested one-time top-up amount that aims to improve the goal probability to meet the target goal probability.This is rounded to the nearest integer.",
    )
    yearlyTopUpAccumulation: float = Field(
        title="",
        ge=0,
        nullable=True,
        description="Suggested recurring yearly top-up amount that aims to improve the goal probability to meet the target goal probability.\
         This would be returned with a value if the infusionType is annual. This is rounded to the nearest integer. This would be 0 if infusionType is monthly.<br> \
         Note: Zero in cases where meet goal priority = ‘true’; Non-zero otherwise.To be denoted as a rounded number with a currency suffix ($16.0)",
    )  # default the output to 0.0 instead of 0 for cases where the field is not applicable -- controller code --all cashflow outputs
    monthlyTopUpAccumulation: float = Field(
        title="",
        ge=0,
        nullable=True,
        description="Suggested recurring monthly top-up amount during the accumulation period that aims to improve the goal probability to meet the target goal probability.\
         This would be returned only if the infusionType is monthly. This is rounded to the nearest integer.<br> \
         Note:Zero in cases where meet goal priority = ‘true’; Non-zero otherwise.To be denoted as a rounded number with a currency suffix ($1,152)",
    )
    yearlyTopUpDecumulation: float = Field(
        title="",
        nullable=True,
        description="Suggested recurring yearly decumulation amount that aims to improve the goal probability to meet the target goal probability. \
        This would be returned only if the infusionType is annual. This is rounded to the nearest integer<br> \
        Note:Zero in cases where meet goal priority = ‘true’; Non-zero otherwise.To be denoted as a rounded number with a currency suffix ($0)",
    )
    monthlyTopUpDecumulation: float = Field(
        title="",
        nullable=True,
        description="Suggested recurring monthly top-up decumulation amount that aims to improve the goal probability to meet the target \
        goal probability, this value would be populated only in cases of decumulation of withdrawal scenario. This would be returned only \
        if the infusionType is monthly. This is rounded to the nearest integer. <br> \
        Note:Zero in cases where meet goal priority = ‘true’; Non-zero otherwise.To be denoted as a rounded number with a currency suffix ($1,152)",
    )
    recommendedTenure: str = Field(
        title="",
        nullable=True,
        description="For scenarios with goal probability less than 50%: <br> \
                    • If original tenure between 1 - 8 years –extended/reduced tenure 2 years to 4 years <br> \
                    • If original tenure between 9 – 14 years – extended/reduced tenure 4 years to 8 years <br> \
                    • If original tenure greater than equal to 15 years –extended/reduced tenure 5 years to 10 years <br> \
        For scenarios with goal probability greater than or equal to 50%, extended/reduced tenure = 2 years to 4 years for all cases.<br> \
        The algorithm recommends standard tenure increments/decrements based on the tenure input and the goal probability (calculated using current and end date).\
        Cases where tenure recommendation isn’t valid/required will show the recommendation as NA. \
        For retirement cases, where there is accumulation followed by decumulation, the extension is based on years to retirement and not on original tenure",
    )
    bankruptcyMsg: str = Field(
        title="",
        nullable=True,
        description="Message flagging an expected bankruptcy (goal running out of money) in any year.<br> \
        The algorithm recommends standard tenure increments/decrements based on the tenure input and the goal probability (calculated using current and end date). <br>\
        Note: If ‘NA’, bankruptcy is unlikely to happen during the goal tenure.In bankruptcy cases, response would be similar to \
        ‘Bankruptcy is likely to happen in year 1’.",
    )

    recommendedFinalWealthAt75: float = Field(
        title="",
        default=None,
        description="This is an optional parameter .If the target wealth were to be reduced by 25% of the difference between the target and the current wealth.<br> \
        Applicable for non-retirement scenarios with tenures less than or equal to 30 years. This is rounded to the nearest integer <br>\
        Note: To be denoted as a rounded number with a currency suffix ($980,384) on the front end.",
    )
    recommendedProbAt75: float = Field(
        title="",
        ge=0,
        le=0.99,
        default=None,
        description="Goal probability corresponding to ‘recommended final wealth at 75%’ above.<br> \
        Applicable for non-retirement scenarios with tenures less than or equal to 30 years. This is rounded to the nearest integer.<br>\
        Note: To be denoted as a rounded number with no decimals, on the front end.",
    )
    recommendedFinalWealthAt50: float = Field(
        title="",
        default=None,
        description="This is an optional parameter .If the target wealth were to be reduced by 50% of the difference between the target and the current wealth.<br> \
        Applicable for non-retirement scenarios with tenures less than or equal to 30 years. This is rounded to the nearest integer <br>\
        Note: To be denoted as a rounded number with a currency suffix ($960,769) on the front end.",
    )
    recommendedProbAt50: float = Field(
        title="",
        ge=0,
        le=0.99,
        default=None,
        description="Goal probability corresponding to ‘recommended final wealth at 50%’ above.<br> \
        Applicable for non-retirement scenarios with tenures less than or equal to 30 years. This is rounded to the nearest integer.<br>\
        Note: To be denoted as a rounded number with no decimals, on the front end.",
    )
    advisorDiscretionReport: Dict[str, float] = Field(
        title="",
        nullable=True,
        description="Recommended Portfolio and corresponding probability.<br> \
        In case where current portfolio is not null, it provides the following:<br>\
        1. Probability of attaining goal (using the current portfolio sent as an input and a constant portfolio path) – Monte Carlo simulations \
        2. 2. Current Goal Probability (dynamic asset allocation by GOE) and the recommended portfolio <br> \
        In case the current portfolio is null, the current goal probability is displayed (using dynamic asset allocation by GOE \
        and not assuming a constant portfolio path) along with the recommended portfolio.",
    )
    message: str = Field(
        title="",
        nullable=True,
        description="Captures any message from the API after it is done processing the request.",
    )
    lossThreshold: int = Field(
        title="",
        nullable=True,
        ge=0,
        description="Loss threshold value – the wealth amount that the investor does not want to end up below at the end of the goal tenure.<br> \
        If the input parameter ‘lossThreshold’ is not passed or value is ‘null’, this parameter is calculated by GOE. \
        If the input parameter ‘lossThreshold’ is a number value, GOE will consider this as the loss threshold.",
    )


class WealthPath(BaseModel):
    default: list[float] = Field(
        title="",
        nullable=True,
        description="Wealth paths corresponding to the priority-based probability level are returned.",
    )
    pessimistic: list[float] = Field(
        title="",
        nullable=True,
        description="Wealth paths corresponding to the Pessimistic probability level are returned",
    )
    optimistic: list[float] = Field(
        title="",
        nullable=True,
        description="Wealth paths corresponding to the Optimistic probability level are returned",
    )
    defaultPercentile: str = Field(
        title="",
        nullable=True,
        description="Percentile values corresponding to default path.",
    )
    pessimisticPercentile: str = Field(
        title="",
        nullable=True,
        description="Percentile values corresponding to Pessimistic path.",
    )
    optimisticPercentile: str = Field(
        title="",
        nullable=True,
        description="Percentile values corresponding to Optimistic path.",
    )


class PathReport(BaseModel):
    portfolioPath: list[int] = Field(
        title="",
        description="GOE’s expected portfolio path across the goal tenure (corresponding to the beginning of each reallocation date). <br> \
        Note: Represents the portfolios to be allocated into at the beginning of each re-allocation date.Asset class allocations \
        corresponding to the portfolio indexes to be shown on the front end",
    )
    wealthPath: WealthPath = Field(
        title="",
        nullable=True,
        description="Priority based path of wealth across the investment tenure \
        (corresponding to the end of each reallocation date).  If additional wealth paths are \
        requested, a dictionary of 3 wealth paths and wealth path percentiles is returned – covered in the next 2 rows<br> \
        The probability levels can be configured.<br> \
        Note: Values are denoted as rounded numbers with a currency suffix ($921,537)",
    )


class RunPipeResponseBody(BaseModel):
    analysis_report: RunPipeAnalysisReport = Field(
        title="", description="Captures various important recommendations and outputs from the GOE engine."
    )
    path_report: PathReport = Field(
        title="", description="Captures lookforward portfolio and wealth paths as calcualted by the GOE engine."
    )


class RunPipeResponseModelV4(BaseModel):
    statusCode: int
    message: str
    body: RunPipeResponseBody


runpipe_response_model_v4 = {
    "model": RunPipeResponseModelV4,
    "description": "Successful response",
    "content": {
        "application/json": {
            "examples": {
                "example_1": {
                    "summary": "Example 1",
                    "value": {
                        "statusCode": 200,
                        "message": "Success",
                        "body": {
                            "analysisReport": {
                                "currentGoalProbability": 0.5857,
                                "currentLossThresholdProbability": 0.9126,
                                "pDeltaCurrentGoalProbability": 0.5669,
                                "pDeltaCurrentLossThresholdProbability": 0.9231,
                                "recommendedPortfolioId": 7,
                                "meetGoalPriority": False,
                                "isGoalRealistic": False,
                                "meetLossPriority": False,
                                "oneTimeTopUp": 27500.0,
                                "yearlyTopUpAccumulation": 3202.0,
                                "monthlyTopUpAccumulation": 0,
                                "yearlyTopUpDecumulation": 0,
                                "monthlyTopUpDecumulation": 0,
                                "recommendedTenure": "Goal probability at T+2 years : 70% ; Goal probability at T+4 years : 79%",
                                "bankruptcyMsg": "NA",
                                "recommendedFinalWealthAt75%": 187500.0,
                                "recommendedProbAt75%": 0.7029,
                                "recommendedFinalWealthAt50%": 175000.0,
                                "recommendedProbAt50%": 0.8072,
                                "advisorDiscretionReport": {"7": 0.5857},
                                "message": None,
                                "lossThreshold": 154441,
                            },
                            "pathReport": {
                                "portfolioPath": [7, 7, 7, 6, 6, 6, 4, 4, 2, 1],
                                "wealthPath": [
                                    150000.0,
                                    150178.0,
                                    150713.0,
                                    151603.0,
                                    152851.0,
                                    154454.0,
                                    156414.0,
                                    158730.0,
                                    161402.0,
                                    164431.0,
                                    167816.0,
                                ],
                            },
                        },
                    },
                }
            }
        }
    },
}
