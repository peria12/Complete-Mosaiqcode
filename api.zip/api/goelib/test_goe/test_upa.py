from www.api import goelib
from unittest.mock import MagicMock
from deepdiff import DeepDiff
import pytest
import json
from unittest import mock
from www.api.goelib.api.resources.pipeserverless import pipe_serverless_controller_run_advisor_engine, pipe_controller_run_wealth_splitter, prepare_portfolio, validateRunPipePayload
from www.api.goelib.api.shared.user_utils import get_user_profile
from www.api.goelib.api.shared.advisor_engine_utils import validateAdvisorEnginePayload, validateAdvisorEnginePayloadVersion3dot8
from www.api.goelib.api.shared.common import DictDefault
from google.protobuf.json_format import MessageToJson
import rest_pb2
import uip_grpc

svc_client = uip_grpc.ServiceClient()
import logging

LOGGER = logging.getLogger(__name__)


@pytest.fixture()
def header():
    """
        Header parameters
    """
    return {"version": "3", "clientemail": "gdasara@frk.com", "generatepayloadonly": False}


@pytest.fixture()
def user():
    """Return answer to ultimate question."""
    return {
        "email": "gdasara@frk.com",
        "app_settings": {
            "goe": {
                "client-settings": {
                    "segmentId": 1,
                    "portfolioBundleId": 336,
                    "phone": "123344651",
                    "config": {
                        "allocationConfiguration": {
                            "reallocationDatesByFrequency": {
                                "halfyearly": ["Sat Jan 01 2022", "Fri Jul 01 2022"],
                                "yearly": ["Sat Jan 01 2022"],
                                "quarterly": [
                                    "Sat Jan 01 2022",
                                    "Fri Apr 01 2022",
                                    "Fri Jul 01 2022",
                                    "Sat Oct 01 2022",
                                ],
                            },
                            "reallocationTriggers": [
                                {"value": True, "name": "newRiskProfile"},
                                {"name": "changesInvestmentTenure", "value": True},
                                {"name": "riskIndicatorFlashes", "value": True},
                                {"value": True, "name": "rePrioritizesGoal"},
                                {"value": True, "name": "newGoal"},
                                {"name": "wantsToReallocate", "value": True},
                            ],
                            "reallocationFrequency": "yearly",
                        },
                        "portfolioConfig": {
                            "portfolioMapping": {
                                "Conservative": "Conservative",
                                "Aggressive": "Aggressive",
                                "Moderate": "Moderate",
                            },
                            "shortTermRetirementGoalTenureUnengaged": 50,
                            "shortTermRetirementGoalTenure": 10,
                            "shortTermGoalTenure": 3,
                            "portfolioConfig": {
                                "defaultRiskProfiles": [],
                                "veryAggressiveRiskProfiles": [],
                                "shortTermGoalProfiles": [1064, 1065],
                                "veryConservativeRiskProfiles": [],
                                "conservativeRiskProfiles": [1064, 1065, 1066],
                                "moderateRiskProfiles": [1064, 1065, 1066, 1067],
                                "decumulationScenarioProfiles": [1064, 1065, 1066, 1067],
                                "shortTermRetirementGoalProfiles": [1064, 1065],
                                "aggressiveRiskProfiles": [1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071],
                                "moderatelyAggressiveRiskProfiles": [],
                                "conservativelyModerateRiskProfiles": [],
                            },
                            "level": "3",
                            "usingFtPortfolio": True,
                            "distributionChannel": "",
                        },
                        "configuration": "Configuration1",
                        "goalPriority": {
                            "lossThreshold": True,
                            "performance": {
                                "longTenureThreshold": 40,
                                "alternativeSigma": 4,
                                "nodesPerSd": 6,
                                "sigma": 5,
                                "irrForRangeAdjustment": 0.03,
                                "irrPerformanceThreshold": 0.0339,
                                "altNodesPerSd": 4,
                                "riskOverlay": False,
                            },
                            "probabilityLevels": [
                                {"name": "need", "value": 0.9},
                                {"value": 0.6, "name": "want"},
                                {"value": 0.6, "name": "wish"},
                                {"name": "dream", "value": 0.5},
                                {"name": "desire", "value": 0.4},
                            ],
                            "lossthresholdValues": [
                                {"accumulation": 0.05, "name": "need", "decumulation": 0.5},
                                {"accumulation": -0.01, "name": "want", "decumulation": 0.25},
                                {"decumulation": 0.0, "name": "wish", "accumulation": 0.8},
                                {"name": "dream", "decumulation": 0.0, "accumulation": 0.6},
                                {"decumulation": 0.0, "name": "desire", "accumulation": 0.4},
                            ],
                            "generalSettings": {
                                "backPassOnly": False,
                                "swingConstraintNumber": 2,
                                "gridFrequency": "yearly",
                                "recommendEscalatedGoal": False,
                                "actuarials": [
                                    {"id": 13, "type": "LifeExpectancy", "name": "Test Mortality_HNW"},
                                    {"type": "Mortality", "name": "US_mortality_2021_TEST", "id": 7},
                                    {"id": 7, "name": "US_mortality_2021_TEST", "type": "AgeBasedGlidePath"},
                                ],
                                "maxAge": 121,
                                "unrealisticProbability": 0.35,
                                "inflation": 2.5000000000000003e-12,
                                "recommendInitialWealth": False,
                                "inflationMeasureForInfusions": "REAL",
                                "recommendTenure": True,
                                "recommendTopUpInfusion": True,
                                "downsideProtection": "Maximize Loss Threshold Probability",
                                "safeGuardAchievedWealthInLastYear": False,
                                "swingConstraint": True,
                                "splitWealthAcrossGoalOptimally": True,
                            },
                            "lossThresholdProbability": 0.91,
                        },
                        "goalLevel": "3",
                        "channelName": "US_Default",
                    },
                    "status": {"name": "Active"},
                    "contactId": "contact test",
                    "countryId": 3,
                    "notes": "test",
                    "contactName": "contact test name",
                    "country": {
                        "id": 3,
                        "name": "US",
                        "description": "US",
                        "createdAt": "2020-03-25T06:05:22.868Z",
                        "updatedAt": "2020-03-25T06:05:22.868Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "segment": {
                        "id": 1,
                        "name": "Default",
                        "description": "Default",
                        "createdAt": "2020-04-27T07:28:00.630Z",
                        "updatedAt": "2020-04-27T07:28:00.630Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "portfolioBundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                    "name": "Gopi OktaTest",
                    "id": "00ucql4opCihuxT0X696",
                    "portfolio_bundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                }
            }
        },
        "__meta": {
            "action": "edit",
            "comment": "edit",
            "user": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
            "timestamp": "2022-04-06 13:02:47.414562",
            "id": "00ucql4opCihuxT0X696",
            "author": "Dasarathula, Gopi",
        },
        "name": "Gopi OktaTest",
        "__doc": {},
        "first-name": "Gopi",
        "_id": "00ucql4opCihuxT0X696",
        "id": "00ucql4opCihuxT0X696",
    }


@pytest.fixture()
def upa_request_v2():
    return {
        "isNewRTQ": True,
        "isNewInvestmentTenure": True,
        "isNewGoalPriority": True,
        "isNearTermVolatility": True,
        "getPath": True,
        "rebalancing": "yearly",
        "initialInvestment": 86000,
        "currentWealth": None,
        "currentPortfolioId": None,
        "currDate": "04-01-2021",
        "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
        "riskProfile": "Aggressive",
        "cashflow_date": "01-01-2021",
        "scenario_type": "AE",
        "infusion_type": "yearly",
        "goal_profile_list": [
            {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
            {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
             "end_date": "01-01-2033", "priority": "Need"},
            {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                              2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
            {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
             "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
        ]
    }


@pytest.fixture()
def upa_v2_response():
    return (
        {
            "statusCode": 200,
            "message": "Success",
            "body": {
                "user_profile": {
                    "init_inv": 86000,
                    "infusions": [
                        0.0,
                        4000.0,
                        4000.0,
                        4000.0,
                        4000.0,
                        4000.0,
                        4000.0,
                        4000.0,
                        4000.0,
                        4000.0,
                        -21000.0,
                        -19000.0,
                        -75000.0,
                        -23000.0,
                        -23000.0,
                        -23000.0,
                    ],
                    "curr_date": "04-01-2021",
                    "curr_wealth": None,
                    "curr_port_id": None,
                    "loss_amt": None,
                    "rebalancing": "yearly_",
                    "cashflow_date": "01-01-2021",
                    "infusion_type": "yearly",
                    "scenario_type": "AE",
                    "goal_profile_list": [
                        {
                            "goal_id": "Goal1",
                            "goal_amt": [25000],
                            "start_date": "01-01-2021",
                            "end_date": "01-01-2031",
                            "priority": "Need",
                        },
                        {
                            "goal_id": "Goal2",
                            "goal_amt": [52000],
                            "start_date": "01-01-2021",
                            "end_date": "01-01-2033",
                            "priority": "Need",
                        },
                        {
                            "goal_id": "Goal3",
                            "goal_amt": [
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                                2000,
                            ],
                            "start_date": "01-01-2022",
                            "end_date": "01-01-2036",
                            "priority": "Need",
                        },
                        {
                            "goal_id": "Goal4",
                            "goal_amt": [21000, 21000, 21000, 21000, 21000],
                            "start_date": "01-01-2032",
                            "end_date": "01-01-2036",
                            "priority": "Need",
                        },
                    ],
                    "risk_override": False,
                    "is_new_goal_priority": True,
                    "is_new_investment_tenure": True,
                    "reallocate": False,
                    "is_near_term_volatality": True,
                    "is_new_goal": None,
                    "is_new_risk_profile": True,
                },
                "pipe_config": {
                    "wealth_path_prob": None,
                    "realloc_schedules": ["01-01-2021"],
                    "exec_change": True,
                    "swing_constraint": True,
                    "swing": 2,
                    "safeguard": False,
                    "downside_protect": True,
                    "protect_thd": 0.91,
                    "goal_priority": False,
                    "downside_alternate_max_goal": False,
                    "get_path": True,
                    "realistic_goal_prob": 0.35,
                    "infln": 2.5000000000000003e-12,
                    "sigma_thd": 5,
                    "nodes_per_sd": 6,
                    "inf_measure": "real",
                    "irr_thresh": 0.03,
                    "short_term_port_maxindex": 2,
                    "goal_priority_prob_list": {
                        "Need": 0.9,
                        "Want": 0.6,
                        "Wish": 0.6,
                        "Dream": 0.5,
                    },
                    "LT_Factor": {
                        "Acc_Need": 0.05,
                        "Acc_Want": -0.01,
                        "Acc_Wish": 0.8,
                        "Acc_Dream": 0.6,
                        "Dec_Need": 0.5,
                        "Dec_Want": 0.25,
                        "Dec_Wish": 0.0,
                        "Dec_Dream": 0.0,
                    },
                    "long_tenure_thresh": 40,
                    "irr_perf_thd": 0.0339,
                    "alt_nodes_per_sd": 4,
                    "alt_sigma_thd": 4,
                    "topup_recommendation": True,
                    "tenure_recommendation": True,
                    "back_pass_only": False,
                    "short_term_tenure": 3,
                    "short_term_tenure_retirement": 10,
                    "short_term_port_maxindex_retirement": 2,
                    "dec_port_maxindex": 4,
                    "max_age": 121,
                    "grid_freq": "yearly",
                    "adjust_fees": None,
                },
                "port_dict": [
                    {
                        "mu": 0.0258,
                        "sigma": 0.0391,
                        "equity": 15,
                        "bond": 85,
                        "money_market": 0,
                    },
                    {
                        "mu": 0.0276,
                        "sigma": 0.0429,
                        "equity": 20,
                        "bond": 80,
                        "money_market": 0,
                    },
                    {
                        "mu": 0.0286,
                        "sigma": 0.0474,
                        "equity": 25,
                        "bond": 75,
                        "money_market": 0,
                    },
                    {"mu": 0.0311, "sigma": 0.054, "equity": 30, "bond": 70, "money_market": 0},
                    {
                        "mu": 0.0328,
                        "sigma": 0.0606,
                        "equity": 35,
                        "bond": 65,
                        "money_market": 0,
                    },
                    {
                        "mu": 0.0346,
                        "sigma": 0.0678,
                        "equity": 40,
                        "bond": 60,
                        "money_market": 0,
                    },
                    {
                        "mu": 0.0364,
                        "sigma": 0.0753,
                        "equity": 45,
                        "bond": 55,
                        "money_market": 0,
                    },
                    {"mu": 0.0381, "sigma": 0.083, "equity": 50, "bond": 50, "money_market": 0},
                ],
                "request_id": None,
            },
        }, 200)
# @pytest.mark.asyncio
# async def test_upa_payload_v2(upa_request_v2, version="2"):
#     """Test age based glide path"""
#     LOGGER.info('eggs info')
#     payload = upa_request_v2
#     body = DictDefault(payload)
#     result = validateAdvisorEnginePayload(body, version="4")
#     # LOGGER.info("1111111111111111111111111111111111111111111111")
#     # LOGGER.info(result)
#     assert result == {'isValid': True, 'message': None}


@pytest.mark.asyncio
async def test_upa_call(mocker, header, upa_request_v2, user, upa_v2_response):
    """Test age based glide path"""
    LOGGER.info('eggs info')
    req = {
        "headers": {"version": "3", "clientemail": "gdasara@frk.com", "generatepayloadonly": False},
        "remote_addr": "10.203.83.121",
        "request_meta_data": [
            ("request-id", "sD1kLKSt"),
            ("user-id", "5b299b49-34c4-4a11-8ad1-5e60ac1d906f"),
            ("ipaddr", "52.12.44.45"),
            ("user-full-name", "Dasarathula, Gopi"),
            ("user-name", "Gopi.Dasarathula"),
            ("authorization", "Bearer m342w"),
        ],
        "requester_oid": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
    }
    request_json = upa_request_v2
    mocker.patch("www.api.goelib.api.resources.pipeserverless.get_user_profile", return_value=(user, True))
    request = MagicMock()
    request.environ = {"user_info": ""}
    mocker.patch("www.api.goelib.api.resources.pipeserverless.request", new=request)
    result = await pipe_serverless_controller_run_advisor_engine(req, request_json)
    LOGGER.info("************************************************************")
    LOGGER.info(result)
    assert result == upa_v2_response


upa_req_res = [
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-20213",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "cashflow_date must be in ISO date format or null.",
        },
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": None
        },
        {
            "isValid": False,
            "message": "goal_profile_list must be a list of objects."
        },
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-20213",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "Valid date range for startDate should be between 1-01-1800 to 31-12-2399"
        },
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-20332", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399"
        },
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2011", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "StartDate must be less than endDate."
        },
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal : 1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "goal_id is required and should only contain letters, numbers and spaces."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [-25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "goal_amt list must consist of a non negative floating number."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": 25000, "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "goal_amt must be a list."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Needs"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "priority must be one of Need, Want, Wish, or Dream."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "quarterly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "infusion_type must be one of yearly or monthly."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "UIP",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "scenario_type must be AE"},
        "3"
    ),
    (
        {
            "isNewRTQ": "True",
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "isNewRTQ must be boolean."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": "True",
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "isNearTermVolatility must be boolean."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": "True",
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "isNewInvestmentTenure must be a boolean."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": "True",
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "isNewGoalPriority must be a boolean."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": -86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "initialInvestment must be a number greater than or equal to 0."},
        "3"
    ),
    (
        {
            "isNewRTQ": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "rebalancing": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenario_type": "AE",
            "infusion_type": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": True, "message": None},
        "3"
    )
]


@pytest.mark.parametrize(
    "upa_request, upa_response, version", upa_req_res
)
def test_validate_advisor_engine_payload(upa_request, upa_response, version):
    payload = upa_request
    body = DictDefault(payload)
    result = validateAdvisorEnginePayload(body, version)
    assert result == upa_response


upa_req_res_v3dot8 = [
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-20213",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goal_profile_list": [
                {"goal_id": "Goal1", "goal_amt": [25000], "start_date": "01-01-2021",
                    "end_date": "01-01-2031", "priority": "Need"},
                {"goal_id": "Goal2", "goal_amt": [52000], "start_date": "01-01-2021",
                    "end_date": "01-01-2033", "priority": "Need"},
                {"goal_id": "Goal3", "goal_amt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "start_date": "01-01-2022", "end_date": "01-01-2036", "priority": "Need"},
                {"goal_id": "Goal4", "goal_amt": [21000, 21000, 21000, 21000, 21000],
                    "start_date": "01-01-2032", "end_date": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "cashflowDate must be in ISO date format or null.",
        }
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": None
        },
        {
            "isValid": False,
            "message": "goalProfileList must be a list of objects."
        }
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-20213",
                    "endDate": "01-01-2031", "priority": "Need"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "Valid date range for startDate should be between 1-01-1800 to 31-12-2399"
        }
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-20313", "priority": "Need"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399"
        }
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2041",
                    "endDate": "01-01-2031", "priority": "Need"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need"}
            ]
        },
        {
            "isValid": False,
            "message": "StartDate must be less than endDate."
        }
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal : 1", "goalAmt": [25000], "startDate": "01-01-2041",
                    "endDate": "01-01-2031", "priority": "Need"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "goalID is required and should only contain letters, numbers and spaces."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": 25000, "startDate": "01-01-2041",
                    "endDate": "01-01-2031", "priority": "Need"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "goalAmt must be a list."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [-25000], "startDate": "01-01-2041",
                    "endDate": "01-01-2031", "priority": "Need"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "goalAmt list must consist of a non negative floating number."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-2031", "priority": "Needs"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need"}
            ]
        },
        {"isValid": False, "message": "priority must be one of Need, Want, Wish, or Dream."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "quarterly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-2031", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need","scenarioType": "regular"}
            ]
        },
        {"isValid": False, "message": "Please check scenarioType for Goal3."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-2031", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need", "scenarioType": "retirement"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need","scenarioType": "retirement"}
            ]
        },
        {"isValid": True, "message": None}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": "True",
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflow_date": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-2031", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need", "scenarioType": "retirement"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need","scenarioType": "retirement"}
            ]
        },
        {"isValid": False, "message": "isNearTermVolatility must be a boolean."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": "True",
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-2031", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need", "scenarioType": "retirement"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need","scenarioType": "retirement"}
            ],
            "currentAge": 26,
            "retirementAge": -10
        },
        {"isValid": False, "message": "retirementAge must be an integer or null."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": True,
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-2031", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need", "scenarioType": "retirement"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need","scenarioType": "retirement"}
            ],
            "currentAge": -1,
            "retirementAge": 60
        },
        {"isValid": False, "message": "currentAge must be an integer or null."}
    ),
    (
        {
            "isNewRTQ": True,
            "isNewGoal": True,
            "isNewRiskProfile": True,
            "isNewInvestmentTenure": True,
            "isNewGoalPriority": "True",
            "isNearTermVolatility": True,
            "getPath": True,
            "reallocationFreq": "yearly",
            "initialInvestment": 86000,
            "currentWealth": None,
            "currentPortfolioId": None,
            "currDate": "04-01-2021",
            "infusions": [0.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, 4000.0, -21000.0, -19000.0, -75000.0, -23000.0, -23000.0, -23000.0],
            "riskProfile": "Aggressive",
            "cashflowDate": "01-01-2021",
            "scenarioType": "AE",
            "infusionType": "yearly",
            "goalProfileList": [
                {"goalID": "Goal1", "goalAmt": [25000], "startDate": "01-01-2021",
                    "endDate": "01-01-2031", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal2", "goalAmt": [52000], "startDate": "01-01-2021",
                    "endDate": "01-01-2033", "priority": "Need", "scenarioType": "regular"},
                {"goalID": "Goal3", "goalAmt": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000,
                                                  2000, 2000, 2000, 2000], "startDate": "01-01-2022", "endDate": "01-01-2036", "priority": "Need", "scenarioType": "retirement"},
                {"goalID": "Goal4", "goalAmt": [21000, 21000, 21000, 21000, 21000],
                    "startDate": "01-01-2032", "endDate": "01-01-2036", "priority": "Need","scenarioType": "retirement"}
            ]
        },
        {"isValid": True, "message": None}
    )
]
@pytest.mark.parametrize(
    "upa_request, upa_response", upa_req_res_v3dot8
)
def test_validate_advisor_engine_payload_v3dot8(upa_request, upa_response):
    payload = upa_request
    body = DictDefault(payload)
    result = validateAdvisorEnginePayloadVersion3dot8(body)
    assert result == upa_response
