from www.api import goelib
from unittest.mock import MagicMock
from deepdiff import DeepDiff
import pytest
import json
from unittest import mock
from www.api.goelib.api.resources.pipeserverless import pipe_serverless_controller_run_pipe_version3, pipe_controller_run_wealth_splitter, prepare_portfolio, validateRunPipePayload
from www.api.goelib.api.shared.user_utils import get_user_profile
from www.api.goelib.api.shared.wealthsplit import validateWealthSplitterPayload, validateWealthSplitterPayloadV3, validateWealthSplitterPayloadV3dot8, generateWealthSplitterPayload
from www.api.goelib.api.shared.common import DictDefault
from google.protobuf.json_format import MessageToJson
import rest_pb2
import uip_grpc

svc_client = uip_grpc.ServiceClient()
import logging

LOGGER = logging.getLogger(__name__)

@pytest.fixture()
def header():
    """
        Header parameters
    """
    return {"version": "3", "clientemail": "gdasara@frk.com", "generatepayloadonly": False}

@pytest.fixture()
def user():
    """Return answer to ultimate question."""
    return {
        "email": "gdasara@frk.com",
        "app_settings": {
            "goe": {
                "client-settings": {
                    "segmentId": 1,
                    "portfolioBundleId": 336,
                    "phone": "123344651",
                    "config": {
                        "allocationConfiguration": {
                            "reallocationDatesByFrequency": {
                                "halfyearly": ["Sat Jan 01 2022", "Fri Jul 01 2022"],
                                "yearly": ["Sat Jan 01 2022"],
                                "quarterly": [
                                    "Sat Jan 01 2022",
                                    "Fri Apr 01 2022",
                                    "Fri Jul 01 2022",
                                    "Sat Oct 01 2022",
                                ],
                            },
                            "reallocationTriggers": [
                                {"value": True, "name": "newRiskProfile"},
                                {"name": "changesInvestmentTenure", "value": True},
                                {"name": "riskIndicatorFlashes", "value": True},
                                {"value": True, "name": "rePrioritizesGoal"},
                                {"value": True, "name": "newGoal"},
                                {"name": "wantsToReallocate", "value": True},
                            ],
                            "reallocationFrequency": "yearly",
                        },
                        "portfolioConfig": {
                            "portfolioMapping": {
                                "Conservative": "Conservative",
                                "Aggressive": "Aggressive",
                                "Moderate": "Moderate",
                            },
                            "shortTermRetirementGoalTenureUnengaged": 50,
                            "shortTermRetirementGoalTenure": 10,
                            "shortTermGoalTenure": 3,
                            "portfolioConfig": {
                                "defaultRiskProfiles": [],
                                "veryAggressiveRiskProfiles": [],
                                "shortTermGoalProfiles": [1064, 1065],
                                "veryConservativeRiskProfiles": [],
                                "conservativeRiskProfiles": [1064, 1065, 1066],
                                "moderateRiskProfiles": [1064, 1065, 1066, 1067],
                                "decumulationScenarioProfiles": [1064, 1065, 1066, 1067],
                                "shortTermRetirementGoalProfiles": [1064, 1065],
                                "aggressiveRiskProfiles": [1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071],
                                "moderatelyAggressiveRiskProfiles": [],
                                "conservativelyModerateRiskProfiles": [],
                            },
                            "level": "3",
                            "usingFtPortfolio": True,
                            "distributionChannel": "",
                        },
                        "configuration": "Configuration1",
                        "goalPriority": {
                            "lossThreshold": True,
                            "performance": {
                                "longTenureThreshold": 40,
                                "alternativeSigma": 4,
                                "nodesPerSd": 6,
                                "sigma": 5,
                                "irrForRangeAdjustment": 0.03,
                                "irrPerformanceThreshold": 0.0339,
                                "altNodesPerSd": 4,
                                "riskOverlay": False,
                            },
                            "probabilityLevels": [
                                {"name": "need", "value": 0.9},
                                {"value": 0.6, "name": "want"},
                                {"value": 0.6, "name": "wish"},
                                {"name": "dream", "value": 0.5},
                                {"name": "desire", "value": 0.4},
                            ],
                            "lossthresholdValues": [
                                {"accumulation": 0.05, "name": "need", "decumulation": 0.5},
                                {"accumulation": -0.01, "name": "want", "decumulation": 0.25},
                                {"decumulation": 0.0, "name": "wish", "accumulation": 0.8},
                                {"name": "dream", "decumulation": 0.0, "accumulation": 0.6},
                                {"decumulation": 0.0, "name": "desire", "accumulation": 0.4},
                            ],
                            "generalSettings": {
                                "backPassOnly": False,
                                "swingConstraintNumber": 2,
                                "gridFrequency": "yearly",
                                "recommendEscalatedGoal": False,
                                "actuarials": [
                                    {"id": 13, "type": "LifeExpectancy", "name": "Test Mortality_HNW"},
                                    {"type": "Mortality", "name": "US_mortality_2021_TEST", "id": 7},
                                    {"id": 7, "name": "US_mortality_2021_TEST", "type": "AgeBasedGlidePath"},
                                ],
                                "maxAge": 121,
                                "unrealisticProbability": 0.35,
                                "inflation": 2.5000000000000003e-12,
                                "recommendInitialWealth": False,
                                "inflationMeasureForInfusions": "REAL",
                                "recommendTenure": True,
                                "recommendTopUpInfusion": True,
                                "downsideProtection": "Maximize Loss Threshold Probability",
                                "safeGuardAchievedWealthInLastYear": False,
                                "swingConstraint": True,
                                "splitWealthAcrossGoalOptimally": True,
                            },
                            "lossThresholdProbability": 0.91,
                        },
                        "goalLevel": "3",
                        "channelName": "US_Default",
                    },
                    "status": {"name": "Active"},
                    "contactId": "contact test",
                    "countryId": 3,
                    "notes": "test",
                    "contactName": "contact test name",
                    "country": {
                        "id": 3,
                        "name": "US",
                        "description": "US",
                        "createdAt": "2020-03-25T06:05:22.868Z",
                        "updatedAt": "2020-03-25T06:05:22.868Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "segment": {
                        "id": 1,
                        "name": "Default",
                        "description": "Default",
                        "createdAt": "2020-04-27T07:28:00.630Z",
                        "updatedAt": "2020-04-27T07:28:00.630Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "portfolioBundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                    "name": "Gopi OktaTest",
                    "id": "00ucql4opCihuxT0X696",
                    "portfolio_bundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                }
            }
        },
        "__meta": {
            "action": "edit",
            "comment": "edit",
            "user": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
            "timestamp": "2022-04-06 13:02:47.414562",
            "id": "00ucql4opCihuxT0X696",
            "author": "Dasarathula, Gopi",
        },
        "name": "Gopi OktaTest",
        "__doc": {},
        "first-name": "Gopi",
        "_id": "00ucql4opCihuxT0X696",
        "id": "00ucql4opCihuxT0X696",
    }

@pytest.fixture()
def generateWealthSplitterPayloadResponse():
    return {
        'error': None, 
        'data': {
            'goal_profile': {
                'number_of_goals': 2, 
                'goal_id_list': ['Goal_1', 'Goal_2'], 
                'goal_list': [1000000.0, 1000000.0], 
                'purpose_list': ['Saving', 'Fixed'], 
                'priority_list': ['Need', 'Dream'], 
                'cashflow_list': [
                    [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0],
                    [0, 4000.0, -30000.0, 0]
                ], 
                'start_date': '01-01-2020', 
                'curr_date': '13-01-2021', 
                'end_date_list': ['10-10-2080', '10-10-2023'], 
                'realloc_date': ['01-01-2021'], 
                'port_dict_list': [
                    [
                        {
                            'mu': 0.0333, 
                            'sigma': 0.0364, 
                            'equity': 15, 
                            'bond': 85, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0349, 
                            'sigma': 0.0417, 
                            'equity': 20, 
                            'bond': 80, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0366, 
                            'sigma': 0.0486, 
                            'equity': 25, 
                            'bond': 75, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0382, 
                            'sigma': 0.0564, 
                            'equity': 30, 
                            'bond': 70, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0399, 
                            'sigma': 0.0648, 
                            'equity': 35, 
                            'bond': 65, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0415, 
                            'sigma': 0.0736, 
                            'equity': 40, 
                            'bond': 60, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0431, 
                            'sigma': 0.0827, 
                            'equity': 45, 
                            'bond': 55, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0448, 
                            'sigma': 0.092, 
                            'equity': 50, 
                            'bond': 50, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }
                    ], 
                    [
                        {
                            'mu': 0.0333, 
                            'sigma': 0.0364, 
                            'equity': 15, 
                            'bond': 85, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0349, 
                            'sigma': 0.0417, 
                            'equity': 20, 
                            'bond': 80, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0366, 
                            'sigma': 0.0486, 
                            'equity': 25, 
                            'bond': 75, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0382, 
                            'sigma': 0.0564, 
                            'equity': 30,
                            'bond': 70, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0399, 
                            'sigma': 0.0648, 
                            'equity': 35, 
                            'bond': 65, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0415, 
                            'sigma': 0.0736, 
                            'equity': 40, 
                            'bond': 60, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0431, 
                            'sigma': 0.0827, 
                            'equity': 45, 
                            'bond': 55, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }, 
                        {
                            'mu': 0.0448, 
                            'sigma': 0.092, 
                            'equity': 50, 
                            'bond': 50, 
                            'money_market': 0, 
                            'fees_adjuster': None
                        }
                    ]
                ], 
                'cashflow_type_list': ['monthly', 'yearly'], 
                'priority_prob_list': [0.85, 0.5], 
                'cashflow_date_list': ['15-06-2020', '11-10-2020'], 
                'scenario_type_list': ['retirement', 'retirement'], 
                'curr_wealth_list': [141412.0, 897494.0], 
                'loss_amt_list': [None, None], 
                'request_type': 'initial_wealth_split', 
                'risk_override': False, 
                'engaged_participant': True, 
                'debug': False
            }, 
            'pipe_config': {
                'realloc_schedules': ['01-01-2021'], 
                'exec_change': True, 
                'swing_constraint': True, 
                'swing': 4, 
                'safeguard': True, 
                'downside_protect': True, 
                'protect_thd': 0.99, 
                'goal_priority': False, 
                'downside_alternate_max_goal': False, 
                'realistic_goal_prob': 0.35, 
                'goal_priority_prob': 0.85, 
                'goal_priority_prob_list': {
                    'Need': 0.85, 
                    'Want': 0.7, 
                    'Wish': 0.6, 
                    'Dream': 0.5
                }, 
                'infln': 0.025, 
                'sigma_thd': 5, 
                'nodes_per_sd': 8, 
                'inf_measure': 'nominal', 
                'irr_thresh': -1.0, 
                'safeguard_min': 5, 
                'LT_Factor': {
                    'Acc_Need': 0.1, 
                    'Acc_Want': -0.2, 
                    'Acc_Wish': -0.5, 
                    'Acc_Dream': -1.0, 
                    'Dec_Need': 0.5, 
                    'Dec_Want': 0.25, 
                    'Dec_Wish': 0.0, 
                    'Dec_Dream': 0.0
                }, 
                'long_tenure_thresh': 30, 
                'irr_perf_thd': 0.0339, 
                'alt_nodes_per_sd': 4, 
                'alt_sigma_thd': 4, 
                'topup_recommendation': True, 
                'tenure_recommendation': None, 
                'back_pass_only': False, 
                'short_term_tenure': 3, 
                'short_term_port_maxindex': 8, 
                'short_term_tenure_retirement': 1, 
                'short_term_tenure_retirement_unengaged': 5, 
                'short_term_port_maxindex_retirement': 12, 
                'dec_port_maxindex': 12, 
                'grid_freq': 'yearly', 
                'adjust_fees': 'Variable'
            }
        }
    }

@pytest.fixture()
def wealth_splitter_output():
    return (
        {
            'statusCode': 200, 
            'message': 'Success', 
            'body': {
                'goal_profile': {
                    'number_of_goals': 2, 
                    'goal_id_list': ['Goal_1', 'Goal_2'], 
                    'goal_list': [1000000.0, 1000000.0], 
                    'purpose_list': ['Saving', 'Fixed'], 
                    'priority_list': ['Need', 'Dream'], 
                    'cashflow_list': [
                        [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                        [0, 4000.0, -30000.0, 0]
                    ], 
                    'start_date': '01-01-2020', 
                    'curr_date': '13-01-2021', 
                    'end_date_list': ['10-10-2080', '10-10-2023'], 
                    'realloc_date': ['01-01-2021'], 
                    'port_dict_list': [
                        [
                            {
                                'mu': 0.0333, 
                                'sigma': 0.0364, 
                                'equity': 15, 
                                'bond': 85, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0349, 
                                'sigma': 0.0417, 
                                'equity': 20, 
                                'bond': 80, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0366, 
                                'sigma': 0.0486, 
                                'equity': 25, 
                                'bond': 75, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0382, 
                                'sigma': 0.0564, 
                                'equity': 30, 
                                'bond': 70, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0399, 
                                'sigma': 0.0648, 
                                'equity': 35, 
                                'bond': 65, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0415, 
                                'sigma': 0.0736, 
                                'equity': 40, 
                                'bond': 60, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0431, 
                                'sigma': 0.0827, 
                                'equity': 45, 
                                'bond': 55, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0448, 
                                'sigma': 0.092, 
                                'equity': 50, 
                                'bond': 50, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }
                        ],
                        [
                            {
                                'mu': 0.0333, 
                                'sigma': 0.0364, 
                                'equity': 15, 
                                'bond': 85, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0349, 
                                'sigma': 0.0417, 
                                'equity': 20, 
                                'bond': 80, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0366, 
                                'sigma': 0.0486, 
                                'equity': 25, 
                                'bond': 75, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0382, 
                                'sigma': 0.0564, 
                                'equity': 30, 
                                'bond': 70, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0399, 
                                'sigma': 0.0648, 
                                'equity': 35, 
                                'bond': 65, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0415, 
                                'sigma': 0.0736, 
                                'equity': 40, 
                                'bond': 60, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0431,
                                'sigma': 0.0827, 
                                'equity': 45, 
                                'bond': 55, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }, 
                            {
                                'mu': 0.0448, 
                                'sigma': 0.092, 
                                'equity': 50, 
                                'bond': 50, 
                                'money_market': 0, 
                                'fees_adjuster': None
                            }
                        ]
                    ], 
                    'cashflow_type_list': ['monthly', 'yearly'], 
                    'priority_prob_list': [0.85, 0.5], 
                    'cashflow_date_list': ['15-06-2020', '11-10-2020'], 
                    'scenario_type_list': ['retirement', 'retirement'], 
                    'curr_wealth_list': [141412.0, 897494.0], 
                    'loss_amt_list': [None, None], 
                    'request_type': 'initial_wealth_split', 
                    'risk_override': False, 
                    'engaged_participant': True, 
                    'debug': False
                }, 
                'pipe_config': {
                    'realloc_schedules': ['01-01-2021'], 
                    'exec_change': True, 
                    'swing_constraint': True, 
                    'swing': 4, 
                    'safeguard': True, 
                    'downside_protect': True, 
                    'protect_thd': 0.99, 
                    'goal_priority': False, 
                    'downside_alternate_max_goal': False, 
                    'realistic_goal_prob': 0.35, 
                    'goal_priority_prob': 0.85, 
                    'goal_priority_prob_list': {
                        'Need': 0.85, 
                        'Want': 0.7, 
                        'Wish': 0.6, 
                        'Dream': 0.5
                    }, 
                    'infln': 0.025, 
                    'sigma_thd': 5, 
                    'nodes_per_sd': 8, 
                    'inf_measure': 'nominal', 
                    'irr_thresh': -1.0, 
                    'safeguard_min': 5, 
                    'LT_Factor': {
                        'Acc_Need': 0.1, 
                        'Acc_Want': -0.2, 
                        'Acc_Wish': -0.5, 
                        'Acc_Dream': -1.0, 
                        'Dec_Need': 0.5, 
                        'Dec_Want': 0.25, 
                        'Dec_Wish': 0.0, 
                        'Dec_Dream': 0.0
                    }, 
                    'long_tenure_thresh': 30, 
                    'irr_perf_thd': 0.0339, 
                    'alt_nodes_per_sd': 4, 
                    'alt_sigma_thd': 4, 
                    'topup_recommendation': True, 
                    'tenure_recommendation': None, 
                    'back_pass_only': False, 
                    'short_term_tenure': 3, 
                    'short_term_port_maxindex': 8, 
                    'short_term_tenure_retirement': 1, 
                    'short_term_tenure_retirement_unengaged': 5, 
                    'short_term_port_maxindex_retirement': 12, 
                    'dec_port_maxindex': 12, 
                    'grid_freq': 'yearly', 
                    'adjust_fees': 'Variable'
                }
            }
        }, 
    200
)

@pytest.fixture()
def wealth_splitter_request_v3():
    return {
        "start_date": "01-01-2020", 
        "currDate": "13-01-2021", 
        "riskProfile": "Conservative", 
        "goal_profile_list": [
            {
                "goal_id": "Goal_1", 
                "goalValue": 1, 
                "purpose": "Saving", 
                "curr_wealth": 141412.0, 
                "lossThreshold": None, 
                "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                "endDate": "10-10-2080", 
                "goal_priority_prob": 0.85, 
                "cashflowType": "monthly", 
                "scenarioType": "retirement", 
                "goalPriority": "Need", 
                "cashflowDate": "15-06-2020"
            }, 
            {
                "goal_id": "Goal_2", 
                "goalValue": 1000000.0, 
                "purpose": "Fixed", 
                "curr_wealth": 897494.0, 
                "lossThreshold": None, 
                "cashflow": [0, 4000.0, -30000.0, 0], 
                "endDate": "10-10-2023", 
                "goal_priority_prob": 0.5, 
                "cashflowType": "yearly", 
                "scenarioType": "retirement", 
                "goalPriority": "Dream", 
                "cashflowDate": "11-10-2020"
            }
        ]
    }

@pytest.fixture()
def wealth_splitter_request_v4():
    return {
        "startDate": "01-01-2020", 
        "currDate": "13-01-2021", 
        "riskProfile": "Conservative", 
        "goalProfileList": [
            {
                "goalId": "Goal_1", 
                "goalValue": 1, 
                "purpose": "Saving", 
                "currWealth": 141412.0, 
                "lossThreshold": None, 
                "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                "endDate": "10-10-2080", 
                "goal_priority_prob": 0.85, 
                "cashflowType": "monthly", 
                "scenarioType": "retirement", 
                "goalPriority": "Need", 
                "cashflowDate": "15-06-2020"
            }, 
            {
                "goalId": "Goal_2", 
                "goalValue": 1000000.0, 
                "purpose": "Fixed", 
                "currWealth": 897494.0, 
                "lossThreshold": None, 
                "cashflow": [0, 4000.0, -30000.0, 0], 
                "endDate": "10-10-2023", 
                "goal_priority_prob": 0.5, 
                "cashflowType": "yearly", 
                "scenarioType": "retirement", 
                "goalPriority": "Dream", 
                "cashflowDate": "11-10-2020"
            }
        ]
    }

@pytest.fixture()
def wealth_splitter_v4_response():
    return (
        {
            'statusCode': 200, 
            'message': 'Success', 
            'body': {
                'user_profile': {
                    'engaged_participant': True, 
                    'goal_amt': 1000000.0, 
                    'init_inv': 33170.0, 
                    'infusions': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
                    'start_date': '13-01-2021', 
                    'end_date': '10-10-2090', 
                    'curr_date': '13-01-2021', 
                    'curr_wealth': 33170.0, 
                    'curr_port_id': None, 
                    'loss_amt': 112403.0, 
                    'rebalancing': 'yearly_', 
                    'infusion_type': 'yearly', 
                    'scenario_type': 'regular',
                    'priority': 'Need', 
                    'bequest_priority': None, 
                    'consider_mortality': False, 
                    'current_age': None, 
                    'retirement_age': None, 
                    'risk_override': False, 
                    'calibrate_recommendations': True, 
                    'required_data_available': True, 
                    'debug': False, 
                    'cashflow_date': '01-06-2020'
                }, 
                'pipe_config': {
                    'version': 3, 
                    'realloc_schedules': ['01-01-2021'], 
                    'exec_change': True, 
                    'swing_constraint': True, 
                    'swing': 2, 
                    'safeguard': False, 
                    'downside_protect': True, 
                    'protect_thd': 0.91, 
                    'goal_priority': False, 
                    'downside_alternate_max_goal': False, 
                    'get_path': True, 
                    'realistic_goal_prob': 0.35, 
                    'goal_priority_prob': 0.9, 
                    'goal_priority_prob_list': {
                        'Need': 0.9, 
                        'Want': 0.6, 
                        'Wish': 0.6, 
                        'Dream': 0.5
                    }, 
                    'infln': 2.5000000000000003e-12, 
                    'sigma_thd': 5, 
                    'nodes_per_sd': 6, 
                    'inf_measure': 'real', 
                    'irr_thresh': 0.03, 
                    'LT_Factor': {
                        'Acc_Need': 0.05, 
                        'Acc_Want': -0.01, 
                        'Acc_Wish': 0.8, 
                        'Acc_Dream': 0.6, 
                        'Dec_Need': 0.5, 
                        'Dec_Want': 0.25, 
                        'Dec_Wish': 0.0, 
                        'Dec_Dream': 0.0
                    }, 
                    'long_tenure_thresh': 40, 
                    'irr_perf_thd': 0.0339, 
                    'alt_nodes_per_sd': 4, 
                    'alt_sigma_thd': 4, 
                    'topup_recommendation': True, 
                    'tenure_recommendation': True, 
                    'recommend_escalated_goal': False, 
                    'back_pass_only': False, 
                    'short_term_tenure': 3, 
                    'short_term_port_maxindex': 2, 
                    'short_term_tenure_retirement': 10, 
                    'short_term_tenure_retirement_unengaged': 50, 
                    'short_term_port_maxindex_retirement': 2, 
                    'dec_port_maxindex': 4, 
                    'max_age': 121, 
                    'grid_freq': 'yearly', 
                    'adjust_fees': None
                }, 
                'port_dict': [
                    {
                        'mu': 0.0258, 
                        'sigma': 0.0391, 
                        'equity': 15, 
                        'bond': 85, 
                        'money_market': 0
                    }, 
                    {
                        'mu': 0.0276, 
                        'sigma': 0.0429, 
                        'equity': 20, 
                        'bond': 80, 
                        'money_market': 0
                    }, 
                    {
                        'mu': 0.0286, 
                        'sigma': 0.0474, 
                        'equity': 25, 
                        'bond': 75, 
                        'money_market': 0
                    }, 
                    {
                        'mu': 0.0311, 
                        'sigma': 0.054, 
                        'equity': 30, 
                        'bond': 70, 
                        'money_market': 0
                    }
                ], 
                'pmort_data': None, 
                'age_based_glide_path': None
            }
        }, 200)

req_resp_v3 = [
    (
        {
            "start_date": "01-01-2020s", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "Valid date range for start_date between 1-01-1800 to 31-12-2399"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2091", 
            "riskProfile": "Conservative", 
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "currDate must be less than endDate for goal_id Goal_1."
        },
        "3"
    ),
        (
        {
            "start_date": "01-01-2090", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "start_date must be less than endDate for goal_id Goal_1."
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": "True",
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "riskOverride must be a boolean. When not specificed, default value is false"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": "True",
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": 123, 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "purpose must be a string"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": "True",
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Needs", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "goalPriority must be one of Need, Want, Wish, and Dream."
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "quarterly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "cashflowType must be one of yearly or monthly."
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirements", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "scenarioType must be one of regular or retirement."
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": None, 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "cashflow must be an array"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080s", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020s"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "Valid date range for cashflowDate should be between 1-01-1800 to 31-12-2399"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": 1, 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "goal_id must be a string"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": "NA", 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "curr_wealth must be a number greater than equal to 0 or null"
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": True,
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": -1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "goalValue must be a number greater than or equal to 0."
        },
        "3"
    ),
    (
        {
            "start_date": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goal_profile_list": [
                {
                    "goal_id": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "curr_wealth": 141412.0, 
                    "lossThreshold": -100, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020",
                }, 
                {
                    "goal_id": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "curr_wealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        { 
            "isValid": False,
            "message": "lossThreshold must be a number greater than equal to 0 or null"
        },
        "3"
    )
]



@pytest.mark.parametrize(
    "wealth_splitter_request_v3, wealth_splitter_response, version", req_resp_v3
)
@pytest.mark.asyncio
async def test_wealth_splitter_payload_version_3(wealth_splitter_request_v3, wealth_splitter_response, version):
    """Test age based glide path"""
    LOGGER.info('eggs info')
    payload = wealth_splitter_request_v3
    body = DictDefault(payload)
    result = validateWealthSplitterPayloadV3(body, version)
    # LOGGER.info("************************************************************")
    # LOGGER.info(result)
    assert result == wealth_splitter_response

req_resp_v4 = [
    (
        {
            "startDate": "01-01-2020s", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "Valid date range should be startDate be between 1-01-1800 to 31-12-2399"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": "True",
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "riskOverride must be a boolean. When not specificed, default value is false"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "riskOverride": True,
            "engagedParticipant": "True",
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "engagedParticipant must be a boolean. When not specificed, default value is true"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative",
            "riskOverride": True,
            "engagedParticipant": True, 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": 1, 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "purpose must be a string"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Needs", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "goalPriority must be one of Need, Want, Wish, and Dream."
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "quarterly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "cashflowType must be one of yearly or monthly."
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "XXXX", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "scenarioType must be one of regular or retirement."
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": None,
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "cashflow must be an array"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080s", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "Valid date range for endDate should be between 1-01-1800 to 31-12-2399"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020s"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "Valid date range for cashflowDate should be between 1-01-1800 to 31-12-2399"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": 1, 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "goalId must be a string"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": -141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "currWealth must be a number"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": -1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "goalValue must be a number greater than or equal to 0."
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": -1, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": False,
            "message": "lossThreshold must be a number greater than equal to 0 or null"
        }
    ),
    (
        {
            "startDate": "01-01-2020", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "isValid": True,
            "message": None
        }
    )
]

@pytest.mark.parametrize(
    "wealth_splitter_request_v4, wealth_splitter_v4_response", req_resp_v4
)
@pytest.mark.asyncio
async def test_wealth_splitter_payload_version_4(wealth_splitter_request_v4, wealth_splitter_v4_response):
    """Test age based glide path"""
    LOGGER.info('eggs info')
    payload = wealth_splitter_request_v4
    body = DictDefault(payload)
    result = validateWealthSplitterPayloadV3dot8(body)
    # LOGGER.info("************************************************************")
    # LOGGER.info(result)
    assert result == wealth_splitter_v4_response


@pytest.mark.asyncio
async def test_wealth_splitter_call(mocker, header, wealth_splitter_request_v3, user, generateWealthSplitterPayloadResponse, wealth_splitter_output):
    """Test age based glide path"""
    LOGGER.info('eggs info')
    req = {
        "headers": header,
        "remote_addr": "10.203.83.121",
        "request_meta_data": [
            ("request-id", "sD1kLKSt"),
            ("user-id", "5b299b49-34c4-4a11-8ad1-5e60ac1d906f"),
            ("ipaddr", "52.12.44.45"),
            ("user-full-name", "Dasarathula, Gopi"),
            ("user-name", "Gopi.Dasarathula"),
            ("authorization", "Bearer m342w"),
        ],
        "requester_oid": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
    }
    request_json = wealth_splitter_request_v3
    mocker.patch("www.api.goelib.api.resources.pipeserverless.get_user_profile", return_value=(user, True))
    request = MagicMock()
    request.environ = {"user_info": ""}
    mocker.patch("www.api.goelib.api.resources.pipeserverless.request", new=request)
    mocker.patch("www.api.goelib.api.resources.pipeserverless.validateWealthSplitterPayloadV3", return_value={'isValid': True, 'message': None})
    mocker.patch("www.api.goelib.api.resources.pipeserverless.validateIfRiskProfileisRiskProfileValid", return_value={'isRiskProfileValid': True, 'riskProfileErrorMessage': None})
    mocker.patch("www.api.goelib.api.resources.pipeserverless.generateWealthSplitterPayload", return_value=generateWealthSplitterPayloadResponse)
    result = await pipe_controller_run_wealth_splitter(req, request_json)
    # LOGGER.info("************************************************************")
    # LOGGER.info(result)
    assert result == wealth_splitter_output


generate_req_resp = [
    (
        {
            "startDate": "01-01-2020s", 
            "currDate": "13-01-2021", 
            "riskProfile": "Conservative", 
            "goalProfileList": [
                {
                    "goalId": "Goal_1", 
                    "goalValue": 1, 
                    "purpose": "Saving", 
                    "currWealth": 141412.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, 400.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, -15000.0, 0], 
                    "endDate": "10-10-2080", 
                    "goal_priority_prob": 0.85, 
                    "cashflowType": "monthly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Need", 
                    "cashflowDate": "15-06-2020"
                }, 
                {
                    "goalId": "Goal_2", 
                    "goalValue": 1000000.0, 
                    "purpose": "Fixed", 
                    "currWealth": 897494.0, 
                    "lossThreshold": None, 
                    "cashflow": [0, 4000.0, -30000.0, 0], 
                    "endDate": "10-10-2023", 
                    "goal_priority_prob": 0.5, 
                    "cashflowType": "yearly", 
                    "scenarioType": "retirement", 
                    "goalPriority": "Dream", 
                    "cashflowDate": "11-10-2020"
                }
            ]
        },
        {
            "allocationConfiguration": {
                "reallocationDatesByFrequency": {
                    "halfyearly": ["Sat Jan 01 2022", "Fri Jul 01 2022"],
                    "yearly": ["Sat Jan 01 2022"],
                    "quarterly": [
                        "Sat Jan 01 2022",
                        "Fri Apr 01 2022",
                        "Fri Jul 01 2022",
                        "Sat Oct 01 2022",
                    ],
                },
                "reallocationTriggers": [
                    {"value": True, "name": "newRiskProfile"},
                    {"name": "changesInvestmentTenure", "value": True},
                    {"name": "riskIndicatorFlashes", "value": True},
                    {"value": True, "name": "rePrioritizesGoal"},
                    {"value": True, "name": "newGoal"},
                    {"name": "wantsToReallocate", "value": True},
                ],
                "reallocationFrequency": "yearly",
            },
            "portfolioConfig": {
                "portfolioMapping": {
                    "Conservative": "Conservative",
                    "Aggressive": "Aggressive",
                    "Moderate": "Moderate",
                },
                "shortTermRetirementGoalTenureUnengaged": 50,
                "shortTermRetirementGoalTenure": 10,
                "shortTermGoalTenure": 3,
                "portfolioConfig": {
                    "defaultRiskProfiles": [],
                    "veryAggressiveRiskProfiles": [],
                    "shortTermGoalProfiles": [1064, 1065],
                    "veryConservativeRiskProfiles": [],
                    "conservativeRiskProfiles": [1064, 1065, 1066],
                    "moderateRiskProfiles": [1064, 1065, 1066, 1067],
                    "decumulationScenarioProfiles": [1064, 1065, 1066, 1067],
                    "shortTermRetirementGoalProfiles": [1064, 1065],
                    "aggressiveRiskProfiles": [1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071],
                    "moderatelyAggressiveRiskProfiles": [],
                    "conservativelyModerateRiskProfiles": [],
                },
                "level": "3",
                "usingFtPortfolio": True,
                "distributionChannel": "",
            },
            "configuration": "Configuration1",
            "goalPriority": {
                "lossThreshold": True,
                "performance": {
                    "longTenureThreshold": 40,
                    "alternativeSigma": 4,
                    "nodesPerSd": 6,
                    "sigma": 5,
                    "irrForRangeAdjustment": 0.03,
                    "irrPerformanceThreshold": 0.0339,
                    "altNodesPerSd": 4,
                    "riskOverlay": False,
                },
                "probabilityLevels": [
                    {"name": "need", "value": 0.9},
                    {"value": 0.6, "name": "want"},
                    {"value": 0.6, "name": "wish"},
                    {"name": "dream", "value": 0.5},
                    {"name": "desire", "value": 0.4},
                ],
                "lossthresholdValues": [
                    {"accumulation": 0.05, "name": "need", "decumulation": 0.5},
                    {"accumulation": -0.01, "name": "want", "decumulation": 0.25},
                    {"decumulation": 0.0, "name": "wish", "accumulation": 0.8},
                    {"name": "dream", "decumulation": 0.0, "accumulation": 0.6},
                    {"decumulation": 0.0, "name": "desire", "accumulation": 0.4},
                ],
                "generalSettings": {
                    "backPassOnly": False,
                    "swingConstraintNumber": 2,
                    "gridFrequency": "yearly",
                    "recommendEscalatedGoal": False,
                    "actuarials": [
                        {"id": 13, "type": "LifeExpectancy", "name": "Test Mortality_HNW"},
                        {"type": "Mortality", "name": "US_mortality_2021_TEST", "id": 7},
                        {"id": 7, "name": "US_mortality_2021_TEST", "type": "AgeBasedGlidePath"},
                    ],
                    "maxAge": 121,
                    "unrealisticProbability": 0.35,
                    "inflation": 2.5000000000000003e-12,
                    "recommendInitialWealth": False,
                    "inflationMeasureForInfusions": "REAL",
                    "recommendTenure": True,
                    "recommendTopUpInfusion": True,
                    "downsideProtection": "Maximize Loss Threshold Probability",
                    "safeGuardAchievedWealthInLastYear": False,
                    "swingConstraint": True,
                    "splitWealthAcrossGoalOptimally": True,
                },
                "lossThresholdProbability": 0.91,
            },
            "goalLevel": "3",
            "channelName": "US_Default",
        },
        {
            "portfoliosRiskOff": [],
        },
        {
            'error': "Default risk on portfolios not found.", 
            'data': None
        }
    )
]

@pytest.mark.parametrize(
    "payload, config, portfolios, response", generate_req_resp
)
def test_generate_wealth_splitter_payload(payload, config, portfolios, response):
    """Test age based glide path"""
    LOGGER.info('eggs info')
    payload = DictDefault(payload)
    config = DictDefault(config)
    portfolios = DictDefault(portfolios)
    result = generateWealthSplitterPayload(payload, config, portfolios)
    # LOGGER.info("************************************************************")
    # LOGGER.info(result)
    assert result == response

