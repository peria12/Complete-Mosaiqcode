from www.api import goelib
from unittest.mock import MagicMock
from deepdiff import DeepDiff
import pytest
import json
from unittest import mock
from www.api.goelib.api.resources.pipeserverless import (
    pipe_serverless_controller_run_pipe_version3, 
    prepare_portfolio, 
    validateRunPipePayload,
    validateRunPipePayloadV3dot8,
    validate_translator_api,
    hantz_translator_api
)
from www.api.goelib.api.shared.user_utils import get_user_profile
from www.api.goelib.api.shared.common import DictDefault
from google.protobuf.json_format import MessageToJson
import rest_pb2
import uip_grpc

svc_client = uip_grpc.ServiceClient()
import logging

LOGGER = logging.getLogger(__name__)

@pytest.fixture()
def header():
    """
        Header parameters
    """
    return {"version": "3", "clientemail": "gdasara@frk.com", "generatepayloadonly": False}

@pytest.fixture()
def user():
    """Return answer to ultimate question."""
    return {
        "email": "gdasara@frk.com",
        "app_settings": {
            "goe": {
                "client-settings": {
                    "segmentId": 1,
                    "portfolioBundleId": 336,
                    "phone": "123344651",
                    "config": {
                        "allocationConfiguration": {
                            "reallocationDatesByFrequency": {
                                "halfyearly": ["Sat Jan 01 2022", "Fri Jul 01 2022"],
                                "yearly": ["Sat Jan 01 2022"],
                                "quarterly": [
                                    "Sat Jan 01 2022",
                                    "Fri Apr 01 2022",
                                    "Fri Jul 01 2022",
                                    "Sat Oct 01 2022",
                                ],
                            },
                            "reallocationTriggers": [
                                {"value": True, "name": "newRiskProfile"},
                                {"name": "changesInvestmentTenure", "value": True},
                                {"name": "riskIndicatorFlashes", "value": True},
                                {"value": True, "name": "rePrioritizesGoal"},
                                {"value": True, "name": "newGoal"},
                                {"name": "wantsToReallocate", "value": True},
                            ],
                            "reallocationFrequency": "yearly",
                        },
                        "portfolioConfig": {
                            "portfolioMapping": {
                                "Conservative": "Conservative",
                                "Aggressive": "Aggressive",
                                "Moderate": "Moderate",
                            },
                            "shortTermRetirementGoalTenureUnengaged": 50,
                            "shortTermRetirementGoalTenure": 10,
                            "shortTermGoalTenure": 3,
                            "portfolioConfig": {
                                "defaultRiskProfiles": [],
                                "veryAggressiveRiskProfiles": [],
                                "shortTermGoalProfiles": [1064, 1065],
                                "veryConservativeRiskProfiles": [],
                                "conservativeRiskProfiles": [1064, 1065, 1066],
                                "moderateRiskProfiles": [1064, 1065, 1066, 1067],
                                "decumulationScenarioProfiles": [1064, 1065, 1066, 1067],
                                "shortTermRetirementGoalProfiles": [1064, 1065],
                                "aggressiveRiskProfiles": [1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071],
                                "moderatelyAggressiveRiskProfiles": [],
                                "conservativelyModerateRiskProfiles": [],
                            },
                            "level": "3",
                            "usingFtPortfolio": True,
                            "distributionChannel": "",
                        },
                        "configuration": "Configuration1",
                        "goalPriority": {
                            "lossThreshold": True,
                            "performance": {
                                "longTenureThreshold": 40,
                                "alternativeSigma": 4,
                                "nodesPerSd": 6,
                                "sigma": 5,
                                "irrForRangeAdjustment": 0.03,
                                "irrPerformanceThreshold": 0.0339,
                                "altNodesPerSd": 4,
                                "riskOverlay": False,
                            },
                            "probabilityLevels": [
                                {"name": "need", "value": 0.9},
                                {"value": 0.6, "name": "want"},
                                {"value": 0.6, "name": "wish"},
                                {"name": "dream", "value": 0.5},
                                {"name": "desire", "value": 0.4},
                            ],
                            "lossthresholdValues": [
                                {"accumulation": 0.05, "name": "need", "decumulation": 0.5},
                                {"accumulation": -0.01, "name": "want", "decumulation": 0.25},
                                {"decumulation": 0.0, "name": "wish", "accumulation": 0.8},
                                {"name": "dream", "decumulation": 0.0, "accumulation": 0.6},
                                {"decumulation": 0.0, "name": "desire", "accumulation": 0.4},
                            ],
                            "generalSettings": {
                                "backPassOnly": False,
                                "swingConstraintNumber": 2,
                                "gridFrequency": "yearly",
                                "recommendEscalatedGoal": False,
                                "actuarials": [
                                    {"id": 13, "type": "LifeExpectancy", "name": "Test Mortality_HNW"},
                                    {"type": "Mortality", "name": "US_mortality_2021_TEST", "id": 7},
                                    {"id": 7, "name": "US_mortality_2021_TEST", "type": "AgeBasedGlidePath"},
                                ],
                                "maxAge": 121,
                                "unrealisticProbability": 0.35,
                                "inflation": 2.5000000000000003e-12,
                                "recommendInitialWealth": False,
                                "inflationMeasureForInfusions": "REAL",
                                "recommendTenure": True,
                                "recommendTopUpInfusion": True,
                                "downsideProtection": "Maximize Loss Threshold Probability",
                                "safeGuardAchievedWealthInLastYear": False,
                                "swingConstraint": True,
                                "splitWealthAcrossGoalOptimally": True,
                            },
                            "lossThresholdProbability": 0.91,
                        },
                        "goalLevel": "3",
                        "channelName": "US_Default",
                    },
                    "status": {"name": "Active"},
                    "contactId": "contact test",
                    "countryId": 3,
                    "notes": "test",
                    "contactName": "contact test name",
                    "country": {
                        "id": 3,
                        "name": "US",
                        "description": "US",
                        "createdAt": "2020-03-25T06:05:22.868Z",
                        "updatedAt": "2020-03-25T06:05:22.868Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "segment": {
                        "id": 1,
                        "name": "Default",
                        "description": "Default",
                        "createdAt": "2020-04-27T07:28:00.630Z",
                        "updatedAt": "2020-04-27T07:28:00.630Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "portfolioBundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                    "name": "Gopi OktaTest",
                    "id": "00ucql4opCihuxT0X696",
                    "portfolio_bundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                }
            }
        },
        "__meta": {
            "action": "edit",
            "comment": "edit",
            "user": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
            "timestamp": "2022-04-06 13:02:47.414562",
            "id": "00ucql4opCihuxT0X696",
            "author": "Dasarathula, Gopi",
        },
        "name": "Gopi OktaTest",
        "__doc": {},
        "first-name": "Gopi",
        "_id": "00ucql4opCihuxT0X696",
        "id": "00ucql4opCihuxT0X696",
    }

@pytest.fixture()
def hantz_api_payload():
    """
        Runpipe Payload
    """
    req = {
        "clientId": "711152",
        "reallocate": True,
        "currentPortfolioId": None,
        "currentPortfolioRiskScore": 66,
        "riskProfile": "Aggressive",
        "initialInvestment": {
            "assetsUnderManagement": [
                {
                    "accountType": "_403b",
                    "model": "TIAA - Univ OF Michigan",
                    "assetCategory": "Retirement",
                    "GOEAUM": True,
                    "assetValue": 17051.06,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "_403b",
                    "model": "TIAA - Univ OF Michigan",
                    "assetCategory": "Retirement",
                    "GOEAUM": True,
                    "assetValue": 22817.99,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "VariableAnnuity",
                    "model": "Jackson National",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 189577.04,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 77704.94,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 43660.07,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 52165.6,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 4601.25,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 43255.99,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 51244.66,
                    "accountOwnership": "Client"
                }
            ],
            "assetsHeldAway": [
                {
                    "accountType": "Qualified Retirement - _403b",
                    "assetCategory": "Wealth",
                    "assetValue": 7984.0,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Cash Equivalent - MoneyMarket",
                    "assetCategory": "Wealth",
                    "assetValue": 100000.0,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Health Savings Account",
                    "assetCategory": "Wealth",
                    "assetValue": 14938.0,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Qualified Retirement - IRA",
                    "assetCategory": "Wealth",
                    "assetValue": 9619.0,
                    "accountOwnership": "Client"
                }
            ]
        },
        "currentInvestment": {
            "assetsUnderManagement": [
                {
                    "accountType": "_403b",
                    "model": "TIAA - Univ OF Michigan",
                    "assetCategory": "Retirement",
                    "GOEAUM": True,
                    "assetValue": 17051.06,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "_403b",
                    "model": "TIAA - Univ OF Michigan",
                    "assetCategory": "Retirement",
                    "GOEAUM": True,
                    "assetValue": 22817.99,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "VariableAnnuity",
                    "model": "Jackson National",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 189577.04,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 77704.94,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 43660.07,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 52165.6,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 4601.25,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 43255.99,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Taxable",
                    "model": "Charles Schwab",
                    "assetCategory": "Wealth",
                    "GOEAUM": False,
                    "assetValue": 51244.66,
                    "accountOwnership": "Client"
                }
            ],
            "assetsHeldAway": [
                {
                    "accountType": "Qualified Retirement - _403b",
                    "assetCategory": "Wealth",
                    "assetValue": 7984.0,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Cash Equivalent - MoneyMarket",
                    "assetCategory": "Wealth",
                    "assetValue": 100000.0,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Health Savings Account",
                    "assetCategory": "Wealth",
                    "assetValue": 14938.0,
                    "accountOwnership": "Client"
                },
                {
                    "accountType": "Qualified Retirement - IRA",
                    "assetCategory": "Wealth",
                    "assetValue": 9619.0,
                    "accountOwnership": "Client"
                }
            ]
        },
        "householdProfile": {
            "clientProfile": {
                "salary": 100000.0,
                "retirementAge": 69,
                "currentAge": 68
            },
            "spouseProfile": {
                "salary": 0.0,
                "retirementAge": 69,
                "currentAge":50
            },
            "comfortZone": 2,
            "riskScore": 66
        },
        "startDate": "12-08-2022",
        "endDate": "15-07-2044",
        "currDate": "12-08-2022"
    }
    return req

@pytest.fixture()
def validate_translator_api_payload():
    return {
        'clientId': '711152', 
        'reallocate': True,
        'currentPortfolioId': None, 
        'currentPortfolioRiskScore': 66, 
        'riskProfile': 'Aggressive', 
        'initialInvestment': {
            'assetsUnderManagement': [
                {
                    'accountType': '_403b', 
                    'model': 'TIAA - Univ OF Michigan', 
                    'assetCategory': 'Retirement', 
                    'GOEAUM': True, 
                    'assetValue': 17051.06, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': '_403b', 
                    'model': 'TIAA - Univ OF Michigan', 
                    'assetCategory': 'Retirement', 
                    'GOEAUM': True, 
                    'assetValue': 22817.99, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'VariableAnnuity', 
                    'model': 'Jackson National', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 189577.04, 
                    'accountOwnership': 'Client'
                },
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 77704.94, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable',
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 43660.07, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 52165.6, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 4601.25, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 43255.99, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 51244.66, 
                    'accountOwnership': 'Client'
                }
            ], 
            'assetsHeldAway': [
                {
                    'accountType': 'Qualified Retirement - _403b', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 7984.0, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Cash Equivalent - MoneyMarket', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 100000.0, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Health Savings Account', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 14938.0, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Qualified Retirement - IRA', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 9619.0, 
                    'accountOwnership': 'Client'
                }
            ]
        }, 
        'currentInvestment': {
            'assetsUnderManagement': [
                {
                    'accountType': '_403b', 
                    'model': 'TIAA - Univ OF Michigan', 
                    'assetCategory': 'Retirement', 
                    'GOEAUM': True, 
                    'assetValue': 17051.06, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': '_403b', 
                    'model': 'TIAA - Univ OF Michigan', 
                    'assetCategory': 'Retirement', 
                    'GOEAUM': True, 
                    'assetValue': 22817.99, 
                    'accountOwnership': 'Client'
                },
                {
                    'accountType': 'VariableAnnuity', 
                    'model': 'Jackson National', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 189577.04, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 77704.94, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 43660.07, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 52165.6, 
                    'accountOwnership': 'Client'
                },
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 4601.25, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 43255.99, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Taxable', 
                    'model': 'Charles Schwab', 
                    'assetCategory': 'Wealth', 
                    'GOEAUM': False, 
                    'assetValue': 51244.66, 
                    'accountOwnership': 'Client'
                }
            ], 
            'assetsHeldAway': [
                {
                    'accountType': 'Qualified Retirement - _403b', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 7984.0, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Cash Equivalent - MoneyMarket', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 100000.0, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Health Savings Account', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 14938.0, 
                    'accountOwnership': 'Client'
                }, 
                {
                    'accountType': 'Qualified Retirement - IRA', 
                    'assetCategory': 'Wealth', 
                    'assetValue': 9619.0, 
                    'accountOwnership': 'Client'
                }
            ]
        }, 
        'householdProfile': {
            'clientProfile': {
                'salary': 100000.0, 
                'retirementAge': 69, 
                'currentAge': 68
            }, 
            'spouseProfile': {
                'salary': 0.0, 
                'retirementAge': 69, 
                'currentAge': 50
            }, 
            'comfortZone': 2, 
            'riskScore': 66
        }, 
        'startDate': '12-08-2022', 
        'endDate': '15-07-2044', 
        'currDate': '12-08-2022'
    }

    

validate_translator_req_resp_list = [
    (
        {
            "clientId": 711152,
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "clientId must be a alphanumeric."}
    ),
    (
        {
            "clientId": "711152$",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "clientId must be a alphanumeric."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": "True",
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "reallocate must be a boolean."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": -1,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "currentPortfolioId must be an integer or null."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 200,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "currentPortfolioRiskScore is not valid. Must be a number between 1 to 100."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": None,
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "riskProfile is mandatory and should be string."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': True, 'message': None}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": [],
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "clientProfile must be mapping object."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": [
            ],
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "householdProfile must have atleast clientProfile or spouseProfile."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": [],
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "spouseProfile must be mapping object."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": None,
                "spouseProfile": None,
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "Either householdProfile or spouseProfile should be available."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": "NA",
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "salary of ClientProfile must be non negative number."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": "NA"
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "Current Age of ClientProfile is not valid."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": "NA",
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "retirementAge of Client Profile is not valid."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": -9900,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "salary of spouseProfile must be non negative."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge": -20
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "Current Age of spouseProfile is not valid."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": -69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "retirementAge of spouseProfile is not valid."}
    ),  
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 8,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "comfortZone range from 1 to 3."}
    ),  
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": "NA"
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "riskScore range from 1 to 100."}
    ),  
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 200
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "riskScore range from 1 to 100."}
    ),    
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": [],
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "initialInvestment is mandatory and a mapping object."}
    ),   
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": [],
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "currentInvestment is mandatory and should be a mapping object."}
    ),   
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "2022-08-11",
            "endDate": "15-07-2044",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "startDate is not valid and must be dd-mm-yyyy."}
    ),
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "2022-10-10",
            "currDate": "12-08-2022"
        },
        {'isValid': False, 'message': "endDate  is not valid and must be dd-mm-yyyy"}
    ),   
    (
        {
            "clientId": "711152",
            "reallocate": True,
            "currentPortfolioId": None,
            "currentPortfolioRiskScore": 66,
            "riskProfile": "Aggressive",
            "initialInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "currentInvestment": {
                "assetsUnderManagement": [
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 17051.06,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "_403b",
                        "model": "TIAA - Univ OF Michigan",
                        "assetCategory": "Retirement",
                        "GOEAUM": True,
                        "assetValue": 22817.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "VariableAnnuity",
                        "model": "Jackson National",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 189577.04,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 77704.94,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43660.07,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 52165.6,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 4601.25,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 43255.99,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Taxable",
                        "model": "Charles Schwab",
                        "assetCategory": "Wealth",
                        "GOEAUM": False,
                        "assetValue": 51244.66,
                        "accountOwnership": "Client"
                    }
                ],
                "assetsHeldAway": [
                    {
                        "accountType": "Qualified Retirement - _403b",
                        "assetCategory": "Wealth",
                        "assetValue": 7984.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Cash Equivalent - MoneyMarket",
                        "assetCategory": "Wealth",
                        "assetValue": 100000.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Health Savings Account",
                        "assetCategory": "Wealth",
                        "assetValue": 14938.0,
                        "accountOwnership": "Client"
                    },
                    {
                        "accountType": "Qualified Retirement - IRA",
                        "assetCategory": "Wealth",
                        "assetValue": 9619.0,
                        "accountOwnership": "Client"
                    }
                ]
            },
            "householdProfile": {
                "clientProfile": {
                    "salary": 100000.0,
                    "retirementAge": 69,
                    "currentAge": 68
                },
                "spouseProfile": {
                    "salary": 0.0,
                    "retirementAge": 69,
                    "currentAge":50
                },
                "comfortZone": 2,
                "riskScore": 66
            },
            "startDate": "12-08-2022",
            "endDate": "15-07-2044",
            "currDate": "2022-08-10"
        },
        {'isValid': False, 'message': "currDate must be null or provide a valid date and must be dd-mm-yyyy"}
    )
]

@pytest.mark.parametrize(
    "validate_translator_api_payload, validate_translator_api_resp", validate_translator_req_resp_list
)
def test_validate_translator_api_func(validate_translator_api_payload, validate_translator_api_resp):
    payload = DictDefault(validate_translator_api_payload)
    result = validate_translator_api(payload)
    assert result == validate_translator_api_resp

@pytest.mark.asyncio
async def test_hantz_call(mocker, header, user, validate_translator_api_payload):
    """Test age based glide path"""
    req = {
        "headers": header,
        "remote_addr": "10.203.83.121",
        "request_meta_data": [
            ("request-id", "sD1kLKSt"),
            ("user-id", "5b299b49-34c4-4a11-8ad1-5e60ac1d906f"),
            ("ipaddr", "52.12.44.45"),
            ("user-full-name", "Dasarathula, Gopi"),
            ("user-name", "Gopi.Dasarathula"),
            ("authorization", "Bearer m342w"),
        ],
        "requester_oid": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
    }
    request_json = validate_translator_api_payload
    mocker.patch("www.api.goelib.api.resources.pipeserverless.get_user_profile", return_value=(user, True))
    request = MagicMock()
    request.environ = {"user_info": ""}
    mocker.patch("www.api.goelib.api.resources.pipeserverless.request", new=request)
    mocker.patch("www.api.goelib.api.resources.pipeserverless.validate_translator_api", return_value={'isValid': True, 'message': None})
    mocker.patch("www.api.goelib.api.resources.pipeserverless.generateGlidePathData", return_value={'actuarialData': {'ageBasedGlidePath': None}})
    mocker.patch("www.api.goelib.api.resources.pipeserverless.generateTranslatorPayload", return_value={'actuarialData': {'PortfolioMapping': None}})
    # mocker.patch("www.api.goelib.api.resources.pipeserverless.pay_load_response", return_value={'isValid': True, 'message': None})
    result = await hantz_translator_api(req, request_json)
    assert result == {'body': None, 'message': 'Success', 'statusCode': 200}