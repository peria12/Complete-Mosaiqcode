import enum


class Roles(enum.Enum):
    SUPER_ADMIN = "SUPER_ADMIN"
    WRITE_ADMIN = "Level 1 User"
    READ_ADMIN = "Level 2 User"
    CLIENT = "CLIENT"


def verifyToken(token):
    return "06597872-486e-4e1c-b704-aa9c774dadde"  # TODO: need to remove this principalId
