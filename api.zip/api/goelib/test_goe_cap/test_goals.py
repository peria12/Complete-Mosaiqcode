
from unittest.mock import MagicMock
from deepdiff import DeepDiff
import pytest
import json
from unittest import mock
from google.protobuf.json_format import MessageToJson
from www.api.goe_capabilities import svc_goals
import rest_pb2
import uip_grpc

svc_client = uip_grpc.ServiceClient()
import logging

LOGGER = logging.getLogger(__name__)

# @pytest.fixture()
# def header():
#     """
#         Header parameters
#     """
#     return {"version": "3", "clientemail": "gdasara@frk.com", "generatepayloadonly": False}

@pytest.fixture()
def user():
    """Return answer to ultimate question."""
    return {
        "email": "gdasara@frk.com",
        "app_settings": {
            "goe": {
                "client-settings": {
                    "segmentId": 1,
                    "portfolioBundleId": 336,
                    "phone": "123344651",
                    "config": {
                        "allocationConfiguration": {
                            "reallocationDatesByFrequency": {
                                "halfyearly": ["Sat Jan 01 2022", "Fri Jul 01 2022"],
                                "yearly": ["Sat Jan 01 2022"],
                                "quarterly": [
                                    "Sat Jan 01 2022",
                                    "Fri Apr 01 2022",
                                    "Fri Jul 01 2022",
                                    "Sat Oct 01 2022",
                                ],
                            },
                            "reallocationTriggers": [
                                {"value": True, "name": "newRiskProfile"},
                                {"name": "changesInvestmentTenure", "value": True},
                                {"name": "riskIndicatorFlashes", "value": True},
                                {"value": True, "name": "rePrioritizesGoal"},
                                {"value": True, "name": "newGoal"},
                                {"name": "wantsToReallocate", "value": True},
                            ],
                            "reallocationFrequency": "yearly",
                        },
                        "portfolioConfig": {
                            "portfolioMapping": {
                                "Conservative": "Conservative",
                                "Aggressive": "Aggressive",
                                "Moderate": "Moderate",
                            },
                            "shortTermRetirementGoalTenureUnengaged": 50,
                            "shortTermRetirementGoalTenure": 10,
                            "shortTermGoalTenure": 3,
                            "portfolioConfig": {
                                "defaultRiskProfiles": [],
                                "veryAggressiveRiskProfiles": [],
                                "shortTermGoalProfiles": [1064, 1065],
                                "veryConservativeRiskProfiles": [],
                                "conservativeRiskProfiles": [1064, 1065, 1066],
                                "moderateRiskProfiles": [1064, 1065, 1066, 1067],
                                "decumulationScenarioProfiles": [1064, 1065, 1066, 1067],
                                "shortTermRetirementGoalProfiles": [1064, 1065],
                                "aggressiveRiskProfiles": [1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071],
                                "moderatelyAggressiveRiskProfiles": [],
                                "conservativelyModerateRiskProfiles": [],
                            },
                            "level": "3",
                            "usingFtPortfolio": True,
                            "distributionChannel": "",
                        },
                        "configuration": "Configuration1",
                        "goalPriority": {
                            "lossThreshold": True,
                            "performance": {
                                "longTenureThreshold": 40,
                                "alternativeSigma": 4,
                                "nodesPerSd": 6,
                                "sigma": 5,
                                "irrForRangeAdjustment": 0.03,
                                "irrPerformanceThreshold": 0.0339,
                                "altNodesPerSd": 4,
                                "riskOverlay": False,
                            },
                            "probabilityLevels": [
                                {"name": "need", "value": 0.9},
                                {"value": 0.6, "name": "want"},
                                {"value": 0.6, "name": "wish"},
                                {"name": "dream", "value": 0.5},
                                {"name": "desire", "value": 0.4},
                            ],
                            "lossthresholdValues": [
                                {"accumulation": 0.05, "name": "need", "decumulation": 0.5},
                                {"accumulation": -0.01, "name": "want", "decumulation": 0.25},
                                {"decumulation": 0.0, "name": "wish", "accumulation": 0.8},
                                {"name": "dream", "decumulation": 0.0, "accumulation": 0.6},
                                {"decumulation": 0.0, "name": "desire", "accumulation": 0.4},
                            ],
                            "generalSettings": {
                                "backPassOnly": False,
                                "swingConstraintNumber": 2,
                                "gridFrequency": "yearly",
                                "recommendEscalatedGoal": False,
                                "actuarials": [
                                    {"id": 13, "type": "LifeExpectancy", "name": "Test Mortality_HNW"},
                                    {"type": "Mortality", "name": "US_mortality_2021_TEST", "id": 7},
                                    {"id": 7, "name": "US_mortality_2021_TEST", "type": "AgeBasedGlidePath"},
                                ],
                                "maxAge": 121,
                                "unrealisticProbability": 0.35,
                                "inflation": 2.5000000000000003e-12,
                                "recommendInitialWealth": False,
                                "inflationMeasureForInfusions": "REAL",
                                "recommendTenure": True,
                                "recommendTopUpInfusion": True,
                                "downsideProtection": "Maximize Loss Threshold Probability",
                                "safeGuardAchievedWealthInLastYear": False,
                                "swingConstraint": True,
                                "splitWealthAcrossGoalOptimally": True,
                            },
                            "lossThresholdProbability": 0.91,
                        },
                        "goalLevel": "3",
                        "channelName": "US_Default",
                    },
                    "status": {"name": "Active"},
                    "contactId": "contact test",
                    "countryId": 3,
                    "notes": "test",
                    "contactName": "contact test name",
                    "country": {
                        "id": 3,
                        "name": "US",
                        "description": "US",
                        "createdAt": "2020-03-25T06:05:22.868Z",
                        "updatedAt": "2020-03-25T06:05:22.868Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "segment": {
                        "id": 1,
                        "name": "Default",
                        "description": "Default",
                        "createdAt": "2020-04-27T07:28:00.630Z",
                        "updatedAt": "2020-04-27T07:28:00.630Z",
                        "createdBy": None,
                        "updatedBy": None,
                    },
                    "portfolioBundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                    "name": "Gopi OktaTest",
                    "id": "00ucql4opCihuxT0X696",
                    "portfolio_bundle": {
                        "id": 336,
                        "createdAt": "2022-02-01T10:48:36.869Z",
                        "updatedAt": "2022-02-01T10:48:36.869Z",
                        "countryId": 3,
                        "segmentId": 1,
                        "createdById": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "name": "FT_US_Retail_2021CME_Test_Set",
                        "isFtPortfolio": True,
                        "description": "GOE Portfolios with 2021 CMEs for US Retail",
                        "createdBy": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
                        "updatedBy": None,
                        "portfolios": [
                            {
                                "id": 1064,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.5799999237,
                                "sdPercent": 3.9100000858,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 85},
                                    {"name": "equity", "weightPercent": 15},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1065,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.7599999905,
                                "sdPercent": 4.2899999619,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 80},
                                    {"name": "equity", "weightPercent": 20},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1066,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 2.8599998951,
                                "sdPercent": 4.7399997711,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 75},
                                    {"name": "equity", "weightPercent": 25},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1067,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.1099998951,
                                "sdPercent": 5.4000000954,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 70},
                                    {"name": "equity", "weightPercent": 30},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1068,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.2799999714,
                                "sdPercent": 6.0599999428,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 65},
                                    {"name": "equity", "weightPercent": 35},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1069,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.4600000381,
                                "sdPercent": 6.7800002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 60},
                                    {"name": "equity", "weightPercent": 40},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1070,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.6400001049,
                                "sdPercent": 7.5300002098,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 55},
                                    {"name": "equity", "weightPercent": 45},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1071,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.8099999428,
                                "sdPercent": 8.3000001907,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 50},
                                    {"name": "equity", "weightPercent": 50},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1072,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 3.9900000095,
                                "sdPercent": 9.0900001526,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 45},
                                    {"name": "equity", "weightPercent": 55},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1073,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.1599998474,
                                "sdPercent": 9.8800001144,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 40},
                                    {"name": "equity", "weightPercent": 60},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1074,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.3400001526,
                                "sdPercent": 10.6999998093,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 35},
                                    {"name": "equity", "weightPercent": 65},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1075,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.5100002289,
                                "sdPercent": 11.5200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 30},
                                    {"name": "equity", "weightPercent": 70},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1076,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.6900000572,
                                "sdPercent": 12.3500003815,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 25},
                                    {"name": "equity", "weightPercent": 75},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1077,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 4.8600001335,
                                "sdPercent": 13.1800003052,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 20},
                                    {"name": "equity", "weightPercent": 80},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1078,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.0399999619,
                                "sdPercent": 14.0200004578,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 15},
                                    {"name": "equity", "weightPercent": 85},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                            {
                                "id": 1079,
                                "name": "FT_US_Retail_2021CME_Test_Set",
                                "riskOn": True,
                                "meanPercent": 5.2199997902,
                                "sdPercent": 14.8699998856,
                                "assetAllocations": [
                                    {"name": "bond", "weightPercent": 10},
                                    {"name": "equity", "weightPercent": 90},
                                ],
                                "createdAt": "2022-02-01T10:48:36.869Z",
                                "updatedAt": "2022-02-01T10:48:36.869Z",
                                "bundleId": 336,
                                "createdBy": "uip_goe_user",
                                "updatedBy": None,
                            },
                        ],
                    },
                }
            }
        },
        "__meta": {
            "action": "edit",
            "comment": "edit",
            "user": "5b299b49-34c4-4a11-8ad1-5e60ac1d906f",
            "timestamp": "2022-04-06 13:02:47.414562",
            "id": "00ucql4opCihuxT0X696",
            "author": "Dasarathula, Gopi",
        },
        "name": "Gopi OktaTest",
        "__doc": {},
        "first-name": "Gopi",
        "_id": "00ucql4opCihuxT0X696",
        "id": "00ucql4opCihuxT0X696",
    }


test_svc_goals_request_response = [

    (
        None,
        {
            "body": [
                {
                    "goal_key": "own_house",
                    "goal_name": "Own a House",
                    "id": 1
                },
                {
                    "goal_key": "save_collage",
                    "goal_name": "Save for College",
                    "id": 2
                },
                {
                    "goal_key": "buy_car",
                    "goal_name": "Buy a Car",
                    "id": 3
                },
                {
                    "goal_key": "take_vacation",
                    "goal_name": "Take a Vacation",
                    "id": 4
                },
                {
                    "goal_key": "plan_retirement",
                    "goal_name": "Plan for Retirement",
                    "id": 5
                },
                {
                    "goal_key": "draw_income",
                    "goal_name": "Draw Income",
                    "id": 6
                },
                {
                    "goal_key": "custom_goal",
                    "goal_name": "Custom Goal",
                    "id": 7
                }
            ],
            "message": "Success",
            "statusCode": 200
        }
    ),
]

try:
    from www.api.transcoder import app
    import unittest
    from unittest.mock import AsyncMock
except Exception as e:
    print("Some issues in code")

import pytest
from httpx import AsyncClient

from www.api.transcoder import app

@pytest.mark.parametrize(
    "goals_api_request, goals_api_response", test_svc_goals_request_response
)
@pytest.mark.asyncio
async def test_goals(goals_api_request, goals_api_response):
    async with AsyncClient(app=app, base_url="http://172.21.80.46:4016") as ac:
        yield ac
        request = MagicMock()
        request.environ = {"user_info": ""}
        result = {
            "body": [
                {
                    "goal_key": "own_house",
                    "goal_name": "Own a House",
                    "id": 1
                },
                {
                    "goal_key": "save_collage",
                    "goal_name": "Save for College",
                    "id": 2
                },
                {
                    "goal_key": "buy_car",
                    "goal_name": "Buy a Car",
                    "id": 3
                },
                {
                    "goal_key": "take_vacation",
                    "goal_name": "Take a Vacation",
                    "id": 4
                },
                {
                    "goal_key": "plan_retirement",
                    "goal_name": "Plan for Retirement",
                    "id": 5
                },
                {
                    "goal_key": "draw_income",
                    "goal_name": "Draw Income",
                    "id": 6
                },
                {
                    "goal_key": "custom_goal",
                    "goal_name": "Custom Goal",
                    "id": 7
                }
            ],
            "message": "Success",
            "statusCode": 200
        }
        req = {}
        req["headers"] = request.headers
        req["remote_addr"] = request.remote_addr
        req["request_meta_data"] = request.vars["metadata_t"]
        req["requester_oid"] = request.vars["metadata_d"]["user-id"]
        response = await ac.get("/goe_capabilities/v1/goals", headers= {
                'clientemail': 'droutray@frk.com',
                'version': '4',
                'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJhcGk6Ly9mMmRiYjRmZS04MGU1LTRjOWMtYjExZC0zMzI1YmZlNjFmZTMiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9iOWI4MzFhOS02YzEwLTQwYmYtODZmMy00ODllZDgzYzgxZTgvIiwiaWF0IjoxNjc2MDE5MTMzLCJuYmYiOjE2NzYwMTkxMzMsImV4cCI6MTY3NjAyNDQ5MywiYWNyIjoiMSIsImFpbyI6IkFUUUF5LzhUQUFBQXVvdmN4QURSN3BpWjJGRzdESHFxSHpidXZqTmpKc3A1VHBJOUVORHdEcUZHNGYzODNISGR0eGtjbjNvTVM1eCsiLCJhbXIiOlsicHdkIl0sImFwcGlkIjoiZjJkYmI0ZmUtODBlNS00YzljLWIxMWQtMzMyNWJmZTYxZmUzIiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJEZXZhZGlnYSIsImdpdmVuX25hbWUiOiJVbWVzaCIsImlwYWRkciI6IjQ0LjIzNi4zNy4xMzEiLCJuYW1lIjoiRGV2YWRpZ2EsIFVtZXNoIiwib2lkIjoiMGUyMmUyZWUtODhhMi00M2NlLWEwZjAtNzI2OTBlNDk4NjgxIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTg2MTU2NzUwMS0xOTYwNDA4OTYxLTY4MjAwMzMzMC00NzA2MjkiLCJyaCI6IjAuQVEwQXFURzR1UkJzdjBDRzgwaWUyRHlCNlA2MDJfTGxnSnhNc1IwekpiX21ILU1OQUdnLiIsInNjcCI6IlJlYWQiLCJzdWIiOiJncmthaWtvVWZJcmRHTVltbENzWktNV0JHWkk0R01NS3dTWnVUWm9XZVdzIiwidGlkIjoiYjliODMxYTktNmMxMC00MGJmLTg2ZjMtNDg5ZWQ4M2M4MWU4IiwidW5pcXVlX25hbWUiOiJVbWVzaC5EZXZhZGlnYUBmcmFua2xpbnRlbXBsZXRvbi5jb20iLCJ1cG4iOiJVbWVzaC5EZXZhZGlnYUBmcmFua2xpbnRlbXBsZXRvbi5jb20iLCJ1dGkiOiI0Tm1zNWpZeXZVLTV4TmIwYWpQMkFRIiwidmVyIjoiMS4wIn0.sTmPR29D9PmbIOmXED1Smlibs1Ru4wQf3s7Kxh4rQ9IXpVVAG6FD8hd0xQOG5vMz7SXAybXmOWg_QCn54jWgYHofut2SvpC2-8xoPxiEfvww9ti2uahKsJtHkNiZ5aDD3BX5i3n6YJnEaUElJM4JR04J69P0OhPF7aurubNFlx41wQk33pjowM0cSxTf0i4XTTPt_1qeK2GhEzM4uqwmfsuvsXEu9IsuD7K3DLRMoyDaqXhHb4NT6CBN1QdyqQWjuyWPH2EzZiRGSTl5iuQHGvKUuc7jcIg4iHy_XpN2FZyqMbT7EWVC83gUf2jNvhtWZkmiwN1dAFuqWKplKlCHVw',
                'Content-Type': 'application/json'
        })
    assert goals_api_response == json.loads(response.text)

test_svc_goal_input_req_resp = [
    (
        1,
        {
            "body": {
                "state": [
                    "Nevada",
                    "Colorado",
                    "New Mexico",
                    "Montana",
                    "Arizona",
                    "South Dakota",
                    "Arkansas",
                    "Nebraska",
                    "Iowa",
                    "New Jersey",
                    "Mississippi",
                    "Massachusetts",
                    "North Carolina",
                    "Virginia",
                    "Illinois",
                    "Kansas",
                    "Tennessee",
                    "Texas",
                    "Alaska",
                    "West Virginia",
                    "Rhode Island",
                    "Florida",
                    "Vermont",
                    "Indiana",
                    "Pennsylvania",
                    "Idaho",
                    "Kentucky",
                    "Washington",
                    "Ohio",
                    "Maine",
                    "Georgia",
                    "Wyoming",
                    "Delaware",
                    "Utah",
                    "Missouri",
                    "California",
                    "Alabama",
                    "Oklahoma",
                    "South Carolina",
                    "Wisconsin",
                    "New York",
                    "New Hampshire",
                    "Michigan",
                    "Oregon",
                    "Maryland",
                    "Louisiana",
                    "North Dakota",
                    "District of Columbia",
                    "Minnesota",
                    "Connecticut",
                    "Hawaii"
                ],
                "type_of_house": [
                    "Single-Family Home",
                    "Semi-Detached Home",
                    "Multifamily Home",
                    "Townhome",
                    "Apartment",
                    "Condominium",
                    "Co-Op"
                ]
            },
            "message": "Success",
            "statusCode": 200
        }
    ),
    (
        2,
        {
            "body": {
                "state": [
                    "Florida",
                    "Wyoming",
                    "North Carolina",
                    "Montana",
                    "Utah",
                    "Idaho",
                    "Georgia",
                    "New York",
                    "Nevada",
                    "District of Columbia",
                    "New Mexico",
                    "West Virginia",
                    "Alaska",
                    "Mississippi",
                    "Nebraska",
                    "Wisconsin",
                    "South Dakota",
                    "Kansas",
                    "Oklahoma",
                    "Arkansas",
                    "Indiana",
                    "Iowa",
                    "Louisiana",
                    "Missouri",
                    "California",
                    "North Dakota",
                    "Maryland",
                    "Tennessee",
                    "United States",
                    "Hawaii",
                    "Washington",
                    "Texas",
                    "Maine",
                    "Kentucky",
                    "Alabama",
                    "Colorado",
                    "Arizona",
                    "Ohio",
                    "Oregon",
                    "Minnesota",
                    "South Carolina",
                    "Delaware",
                    "Massachusetts",
                    "Rhode Island",
                    "Virginia",
                    "Michigan",
                    "Illinois",
                    "New Jersey",
                    "Pennsylvania",
                    "Connecticut",
                    "New Hampshire",
                    "Vermont"
                ],
                "type": [
                    "Public Four-Year In-State",
                    "Public Four-Year Out-Of-State",
                    "Private Four-Year"
                ],
                "type_of_program": [
                    "Associate Degree",
                    "Bachelors Degree",
                    "Graduate Degree",
                    "Professional Degree"
                ]
            },
            "message": "Success",
            "statusCode": 200
        }
    ),
    (
        3,
        {
            "body": {
                "vehicle_category": [
                    "Small Car",
                    "Subcompact SUVs",
                    "Midsize Car",
                    "Midsize SUV",
                    "Minivan",
                    "Small Luxury Car",
                    "Small Luxury SUV",
                    "Pickup Truck",
                    "Large Luxury SUV",
                    "Large Luxury Car"
                ]
            },
            "message": "Success",
            "statusCode": 200
        }
    )
]

@pytest.mark.parametrize(
    "goal_input_api_request, goal_input_api_response", test_svc_goal_input_req_resp
)
@pytest.mark.asyncio
async def test_goal_input(goal_input_api_request, goal_input_api_response):
    async with AsyncClient(app=app, base_url="http://172.21.80.46:4016") as ac:
        yield ac
        request = MagicMock()
        request.environ = {"user_info": ""}
        req = {}
        req["headers"] = request.headers
        req["remote_addr"] = request.remote_addr
        req["request_meta_data"] = request.vars["metadata_t"]
        req["requester_oid"] = request.vars["metadata_d"]["user-id"]
        url = "/goe_capabilities/v1/goalInput/{}".format(goal_input_api_request)
        response = await ac.get(url, headers= {
                'clientemail': 'droutray@frk.com',
                'version': '4',
                'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJhcGk6Ly9mMmRiYjRmZS04MGU1LTRjOWMtYjExZC0zMzI1YmZlNjFmZTMiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9iOWI4MzFhOS02YzEwLTQwYmYtODZmMy00ODllZDgzYzgxZTgvIiwiaWF0IjoxNjc2MDIzNjMxLCJuYmYiOjE2NzYwMjM2MzEsImV4cCI6MTY3NjAyODE2NCwiYWNyIjoiMSIsImFpbyI6IkFUUUF5LzhUQUFBQVZ5cHpybmhHYjJHVjZxSzNUV1FEbEJIVjlWdWZPWEhkY2VSRlRXRk5Wc1kxeVRobWFWcGZXOEM4TmtjSTRxOTkiLCJhbXIiOlsicHdkIl0sImFwcGlkIjoiZjJkYmI0ZmUtODBlNS00YzljLWIxMWQtMzMyNWJmZTYxZmUzIiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJEZXZhZGlnYSIsImdpdmVuX25hbWUiOiJVbWVzaCIsImlwYWRkciI6IjQ0LjIzNi4zNy4xMzEiLCJuYW1lIjoiRGV2YWRpZ2EsIFVtZXNoIiwib2lkIjoiMGUyMmUyZWUtODhhMi00M2NlLWEwZjAtNzI2OTBlNDk4NjgxIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTg2MTU2NzUwMS0xOTYwNDA4OTYxLTY4MjAwMzMzMC00NzA2MjkiLCJyaCI6IjAuQVEwQXFURzR1UkJzdjBDRzgwaWUyRHlCNlA2MDJfTGxnSnhNc1IwekpiX21ILU1OQUdnLiIsInNjcCI6IlJlYWQiLCJzdWIiOiJncmthaWtvVWZJcmRHTVltbENzWktNV0JHWkk0R01NS3dTWnVUWm9XZVdzIiwidGlkIjoiYjliODMxYTktNmMxMC00MGJmLTg2ZjMtNDg5ZWQ4M2M4MWU4IiwidW5pcXVlX25hbWUiOiJVbWVzaC5EZXZhZGlnYUBmcmFua2xpbnRlbXBsZXRvbi5jb20iLCJ1cG4iOiJVbWVzaC5EZXZhZGlnYUBmcmFua2xpbnRlbXBsZXRvbi5jb20iLCJ1dGkiOiJBZmlpSWRad19FYTFOdzdfYzNhWEFRIiwidmVyIjoiMS4wIn0.gGARABAFHAPb-LVhpnNC8dimr6feiUgc5PKftuKzGoLfZZ6Vztxx2qRDkdwtXld4f5KUlprwO2PS-tZ3Gc_4WImbDgcfClKEhCfCHbnBY_FJcxF7v_e9Omf84AqxcLlbwXoE9ZFixE6pYZd3iXY7N9mPo9WUH8V42ti3wHRyy_8FfmboZkQTGZb8AEWRhH3EWY6RtumIDTCzMTDdRliHJVsGBdsSjGdPEf4N3-UMAUxKHpC4PO4FgbrFhpEzN5Wr6sQaYmzl2XaiW5A_QBf0sdIY5TidASzwcyUfVr0FuWkOmZV7i8AeJK_rw9VlH8hqzMm4UslqnR4VgA1kkjJ5QA',
                'Content-Type': 'application/json'
        })
        assert goal_input_api_response == json.loads(response.text)


test_svc_calculate_goal_amount_req_resp = [
    (
        {
            "goal_id": 1,
            "type_of_house": "Single-Family Home",
            "state": "Nevada",
            "perc_cost": 0.22,
            "year": "01-01-2030"
        },
        {
            "body": {
                "goal_amount": 99000
            },
            "message": "Success",
            "statusCode": 200
        }
    ),
    (
        {
            "goal_id": 2,
            "type_of_college": "Public Four-Year In-State",
            "type_of_program": "Associate Degree",
            "include_room_and_board_cost": True,
            "state": "Florida",
            "year": "01-01-2030"
        },
        {
            "body": {
                "goal_amount": 35672
            },
            "message": "Success",
            "statusCode": 200
        }
    ),
    (
        {
            "goal_id": 3,
            "vehicle_category": "Small Car",
            "perc_cost": 0.20,
            "year": "01-01-2030"
        },
        {
            "body": {
                "goal_amount": 7787
            },
            "message": "Success",
            "statusCode": 200
        }
    ),
]

@pytest.mark.parametrize(
    "goal_amount_api_request, goal_amount_api_response", test_svc_calculate_goal_amount_req_resp
)
@pytest.mark.asyncio
async def test_calculate_goal_amount(goal_amount_api_request, goal_amount_api_response):
    async with AsyncClient(app=app, base_url="http://172.21.80.46:4016") as ac:
        yield ac
        request = MagicMock()
        request.environ = {"user_info": ""}
        req = {}
        req["headers"] = request.headers
        req["remote_addr"] = request.remote_addr
        req["request_meta_data"] = request.vars["metadata_t"]
        req["requester_oid"] = request.vars["metadata_d"]["user-id"]
        url = "/goe_capabilities/v1/goalAmount"
        response = await ac.post(url, headers= {
                'clientemail': 'droutray@frk.com',
                'version': '4',
                'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJhcGk6Ly9mMmRiYjRmZS04MGU1LTRjOWMtYjExZC0zMzI1YmZlNjFmZTMiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9iOWI4MzFhOS02YzEwLTQwYmYtODZmMy00ODllZDgzYzgxZTgvIiwiaWF0IjoxNjc2MDIzNjMxLCJuYmYiOjE2NzYwMjM2MzEsImV4cCI6MTY3NjAyODE2NCwiYWNyIjoiMSIsImFpbyI6IkFUUUF5LzhUQUFBQVZ5cHpybmhHYjJHVjZxSzNUV1FEbEJIVjlWdWZPWEhkY2VSRlRXRk5Wc1kxeVRobWFWcGZXOEM4TmtjSTRxOTkiLCJhbXIiOlsicHdkIl0sImFwcGlkIjoiZjJkYmI0ZmUtODBlNS00YzljLWIxMWQtMzMyNWJmZTYxZmUzIiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJEZXZhZGlnYSIsImdpdmVuX25hbWUiOiJVbWVzaCIsImlwYWRkciI6IjQ0LjIzNi4zNy4xMzEiLCJuYW1lIjoiRGV2YWRpZ2EsIFVtZXNoIiwib2lkIjoiMGUyMmUyZWUtODhhMi00M2NlLWEwZjAtNzI2OTBlNDk4NjgxIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTg2MTU2NzUwMS0xOTYwNDA4OTYxLTY4MjAwMzMzMC00NzA2MjkiLCJyaCI6IjAuQVEwQXFURzR1UkJzdjBDRzgwaWUyRHlCNlA2MDJfTGxnSnhNc1IwekpiX21ILU1OQUdnLiIsInNjcCI6IlJlYWQiLCJzdWIiOiJncmthaWtvVWZJcmRHTVltbENzWktNV0JHWkk0R01NS3dTWnVUWm9XZVdzIiwidGlkIjoiYjliODMxYTktNmMxMC00MGJmLTg2ZjMtNDg5ZWQ4M2M4MWU4IiwidW5pcXVlX25hbWUiOiJVbWVzaC5EZXZhZGlnYUBmcmFua2xpbnRlbXBsZXRvbi5jb20iLCJ1cG4iOiJVbWVzaC5EZXZhZGlnYUBmcmFua2xpbnRlbXBsZXRvbi5jb20iLCJ1dGkiOiJBZmlpSWRad19FYTFOdzdfYzNhWEFRIiwidmVyIjoiMS4wIn0.gGARABAFHAPb-LVhpnNC8dimr6feiUgc5PKftuKzGoLfZZ6Vztxx2qRDkdwtXld4f5KUlprwO2PS-tZ3Gc_4WImbDgcfClKEhCfCHbnBY_FJcxF7v_e9Omf84AqxcLlbwXoE9ZFixE6pYZd3iXY7N9mPo9WUH8V42ti3wHRyy_8FfmboZkQTGZb8AEWRhH3EWY6RtumIDTCzMTDdRliHJVsGBdsSjGdPEf4N3-UMAUxKHpC4PO4FgbrFhpEzN5Wr6sQaYmzl2XaiW5A_QBf0sdIY5TidASzwcyUfVr0FuWkOmZV7i8AeJK_rw9VlH8hqzMm4UslqnR4VgA1kkjJ5QA',
                'Content-Type': 'application/json'
        }, data=goal_amount_api_request)
        assert goal_amount_api_response == json.loads(response.text)

