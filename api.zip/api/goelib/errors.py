from werkzeug.exceptions import HTTPException


class GoeException(Exception):
    pass


class BadRequest(GoeException):
    code = 400
    name = "BadRequest"
    description = "Invalid Request"
    messages = "BadRequest"


class RecordDoesNotExist(GoeException):
    code = 404
    name = "RecordDoesNotExist"
    description = "Record Does Not Exist"
    messages = "Record Does Not Exist"


class Unauthorized(GoeException):
    code = 400
    name = "Unauthorized"
    description = "Unauthorized Request"
    messages = "Unauthorized"


class ValidationError(GoeException):
    code = 400
    name = "validationError"
    description = "validationError"
    messages = "validationError"


class InternalServerError(GoeException):
    code = 500
    name = "InternalServerError"
    description = "InternalServerError"
    messages = "InternalServerError"


# class UserConfigNotFoundException(GoeException):
#     code = 400
#     name = "UserConfigNotFoundException"
#     description = "User Config Not Found."


class BadRequestError(GoeException):
    code = 400
    name = "BadRequestError"
    messages = "Invalid body, check 'errors' property for more info."
    name = "BadRequestError"
    errors = []


class UserConfigNotFoundException(HTTPException):
    status_code = 400

    def __init__(self, message="UserConfigNotFoundException", status_code=None, payload=None):
        super().__init__()
        self.message = message or "UserConfigNotFoundException"
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload

    def to_dict(self):
        rv = dict(self.payload or ())
        rv["message"] = self.message
        return rv
