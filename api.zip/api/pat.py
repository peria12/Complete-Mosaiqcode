import uip_grpc
import rest_pb2
import rest_pb2_grpc
from quart import request, Response
import json
import uip_config
import uip_auth_c
import uip_dbs
from quart.blueprints import Blueprint
import httpx
import io
import base64
import libs.pat.pat_sync as pat_sync
from uip_utils import get_eom

app = Blueprint("pat", __name__)

svc_client = uip_grpc.ServiceClient()
grpc_channels = uip_grpc.GRPC(async_mode=True)
cfg = uip_config.ConfigDict()

auth = uip_auth_c.UIPAuth()


def create_portfolio_obj(data):
    positions = []
    for pos in data.get("positions", []):
        posi = rest_pb2.PatPosition(
            # class = pos.get('class', ""),
            asset_id=pos.get("asset_id", ""),
            category=pos.get("category", ""),
            instrument=pos.get("instrument", ""),
            name=pos.get("name", ""),
            ticker=pos.get("ticker", ""),
            cluster=pos.get("cluster", ""),
            weight=pos.get("weight", 0),
            value=pos.get("value", 0),
        )
        positions.append(posi)

    req = rest_pb2.PatPortfolio(
        portfolio_id=data.get("portfolio_id"),
        name=data.get("name"),
        type=data.get("type"),
        dateStart=data.get("dateStart"),
        dateEnd=data.get("dateEnd"),
        weightType=data.get("weightType"),
    )
    req.positions.extend(positions)
    return req


def create_watchlist_obj(data):
    assets = []
    for ast in data.get("assets", []):
        asset = rest_pb2.PatAsset(asset_id=ast.get("asset_id", ""))
        assets.append(asset)
    filters = json.dumps(data.get("filters", []))

    req = rest_pb2.PatWatchlist(
        watchlist_id=data.get("watchlist_id", ""),
        name=data.get("name"),
        dateStart=data.get("dateStart"),
        dateEnd=data.get("dateEnd"),
        filters=filters,
    )
    req.assets.extend(assets)
    # req.filters.extend(filters)
    return req


@app.route("/api/pat-api/benchmarks", methods=["GET"])
async def get_benchmarks():
    benchmarks = []
    benchmarks_map = pat_sync.benchmarks

    for bm in benchmarks_map:
        if bm["id_type"] == "fs_bm_id":
            source = "Factset"
        else:
            source = "Morningstar"

        item = {"source": source, "id": bm["id_value"], "official_name": bm["official_name"], "name": bm["name"]}
        benchmarks.append(item)

    return Response(
        response=json.dumps(benchmarks),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/user/portfolio/list", methods=["GET"])
async def portfolios_list():
    args = request.args
    req = rest_pb2.PatPortfolioListInput(
        type=args.get("type", ""),
        page_size=int(args.get("page_size", 50)),
        page_number=int(args.get("page_number", 0)),
        sort=args.get("sort", ""),
        assetClassSort=args.get("assetClassSort"),
        asset_source=args.get("asset_source", ""),
    )

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).GetPortfolioList(
        request=req, metadata=request.vars["metadata_t"]
    )

    dic = json.loads(resp.str)
    return Response(
        response=json.dumps(dic),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/portfolio/<portfolio_id>", methods=["GET"])
async def portfolios_get(portfolio_id):
    req = rest_pb2.PatGetPortfolioInput(portfolio_id=portfolio_id)

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).GetPortfolio(
        request=req, metadata=request.vars["metadata_t"]
    )

    dict = json.loads(resp.str)
    if dict is None:
        return Response(
            response=f"{portfolio_id} Not found",
            status=404,
        )

    return Response(
        response=json.dumps(dict),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/portfolio/<portfolio_id>", methods=["PUT"])
async def portfolios_update(portfolio_id):
    data = await request.json
    req = create_portfolio_obj(data)

    req.portfolio_id = portfolio_id

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).UpdatePortfolio(
        request=req, metadata=request.vars["metadata_t"]
    )

    dic = json.loads(resp.str)
    if dic is None or "error" in dic:
        return Response(
            response=f"{portfolio_id} update failed {dic.get('error', '')}",
            status=500,
        )

    return Response(
        response=json.dumps(dic),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/portfolio", methods=["POST"])
async def portfolios_create():
    data = await request.json

    req = create_portfolio_obj(data)
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).CreatePortfolio(
        request=req, metadata=request.vars["metadata_t"]
    )

    dic = json.loads(resp.str)
    if dic is None or "error" in dic:
        return Response(
            response=f"Portfolio creation failed {dic.get('error', '')}",
            status=500,
        )

    return Response(
        response=json.dumps(dic),
        status=201,
        mimetype="application/json",
    )


@app.route("/api/pat/portfolio/<portfolio_uuid>", methods=["DELETE"])
async def portfolios_delete(portfolio_uuid):
    req = rest_pb2.PatDeletePortfolioInput(portfolio_id=portfolio_uuid)

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).DeletePortfolio(
        request=req, metadata=request.vars["metadata_t"]
    )

    dict = json.loads(resp.str)
    success = dict.get("success")
    if success:
        return Response(
            status=204,
            mimetype="application/json",
        )

    return Response(status=dict.get("code"), response=dict.get("msg"), mimetype="application/json")


@app.route("/api/pat/portfolio/removePortfolios", methods=["POST"])
async def portfolios_delete_many():
    data = await request.json
    portfolios_to_remove = data.get("portfolios_to_remove", [])

    if portfolios_to_remove:
        req = rest_pb2.PatDeletePortfolioInput(portfolio_id=portfolios_to_remove)

        resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).DeletePortfolio(
            request=req, metadata=request.vars["metadata_t"]
        )

        dic = json.loads(resp.str)
        return Response(
            response=json.dumps(dic),
            status=204,
            mimetype="application/json",
        )
    else:
        return Response(
            response="invalid input",
            status=400,
            mimetype="application/json",
        )


@app.route("/api/pat/portfolio/analyze", methods=["POST"])
async def portfolios_analyze():
    data = await request.json
    req = rest_pb2.JSON(str=json.dumps(data))

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).Analyze(
        request=req, metadata=request.vars["metadata_t"]
    )

    return Response(
        response=resp.str,
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/portfolio/presentationAnalyze", methods=["POST"])
async def portfolios_presentation_analyze():
    data = await request.json
    req = rest_pb2.JSON(str=json.dumps(data))

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).PresentationAnalyze(
        request=req, metadata=request.vars["metadata_t"]
    )

    return Response(
        response=resp.str,
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/user/portfolio/scatter", methods=["GET"])
async def portfolios_scatter():
    req = rest_pb2.JSON(str=json.dumps(request.args.to_dict()))

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).Scatter(
        request=req, metadata=request.vars["metadata_t"]
    )

    return Response(
        response=resp.str,
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/asset/invalid/portfolios", methods=["GET"])
async def portfolios_invalid_portfolios():
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).InvalidPortfolios(
        request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(), metadata=request.vars["metadata_t"]
    )

    dict = json.loads(resp.str)
    return Response(
        response=json.dumps(dict),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/asset/invalid/portfolios/<portfolio_uuid>", methods=["GET"])
async def portfolios_invalid_portfolio(portfolio_uuid):
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).InvalidPortfolio(
        request=rest_pb2.PatInvalidPortfolioInput(portfolio_id=portfolio_uuid), metadata=request.vars["metadata_t"]
    )

    print("response is ", resp.str)
    return Response(
        status=204,
        mimetype="application/json",
    )


@app.route("/api/pat/asset/inactive/portfolios", methods=["GET"])
async def portfolios_inative_portfolios():
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).InactivePortfolios(
        request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(), metadata=request.vars["metadata_t"]
    )

    dict = json.loads(resp.str)
    return Response(
        response=json.dumps(dict),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/asset/inactive/portfolios/<portfolio_uuid>", methods=["GET"])
async def portfolios_inactive_portfolio(portfolio_uuid):
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).InactivePortfolio(
        request=rest_pb2.PatInvalidPortfolioInput(portfolio_id=portfolio_uuid), metadata=request.vars["metadata_t"]
    )
    dict = json.loads(resp.str)
    return Response(
        response=json.dumps(dict),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/asset/traffic-lights", methods=["POST"])
async def portfolios_trafficlight():
    data = await request.json
    args = request.args
    req = rest_pb2.PatTrafficLightInput(
        grouped=data.get("grouped", False),
        paged=data.get("paged", False),
        franklinProductsFirst=data.get("franklinProductsFirst", False),
        includeStandardizedPerformance=data.get("includeStandardizedPerformance", False),
        portfolioIds=data.get("portfolioIds", False),
        sharedPortfolioIds=data.get("sharedPortfolioIds", False),
        pageSize=int(args.get("page_size", 20)),
        pageNumber=int(args.get("page_number", 0)),
    )

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).TrafficLight(
        request=req, metadata=request.vars["metadata_t"]
    )

    dic = json.loads(resp.str)
    return Response(
        response=json.dumps(dic),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/feature-flags", methods=["POST"])
async def auth_feature_flags():
    payload = await request.json

    req = rest_pb2.JSON(str=json.dumps(payload))

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).FeatureFlags(
        request=req, metadata=request.vars["metadata_t"]
    )

    response = json.loads(resp.str)
    status = response.pop("status")
    return Response(response=json.dumps(response.pop("result")), status=status)


@app.route("/api/pat/asset/search-full-text", methods=["POST"])
async def asset_search():
    L = request.vars["L"]
    rslt = list()
    index_name = cfg["open_search"]["search_indexes"]["mi_product_index_name"]
    op_url = f"https://{cfg['open_search']['host']}/{index_name}/_search"
    req_js = await request.json
    from_ = request.args.get("from", 0)
    search_term = req_js.get("search_term", "")
    multiple_match = {"multi_match": {"query": search_term.lower(), "fields": ["name.ngram", "ticker.ngram"]}}
    id_match = {"term": {"id.keyword": {"value": search_term.lower(), "boost": 10}}}
    multiple_match = {"bool": {"should": [id_match, multiple_match]}}
    src_filter = {"match": {"source": "morningstar_stocks,morningstar"}}
    query = {"query": {"bool": {"must": [multiple_match, src_filter]}}, "size": req_js.get("size", 50), "from": from_}
    L.info(f"search query: {query}")
    async with httpx.AsyncClient() as client:
        resp = await client.post(op_url, json=query, auth=(cfg["open_search"]["user"], cfg["open_search"]["cred"]))
        data = resp.json()
    if "error" in data:
        err = data["error"]["root_cause"][0]["reason"]
        L.error(f"\nerror resp from ES query: **** {err} ****\n{query}")
    else:
        for r in [h["_source"] for h in data["hits"]["hits"]]:
            _id = r.pop("id")
            price_start_date = get_eom(r.pop("price_start_date", None))
            end_date = r.pop("as_of_date", None)
            stats = {"PRICE_FIRST_DATE": price_start_date, "END_DATE": end_date}
            rslt.append({**r, **{"asset_id": _id, "stats": stats, "morningstar_id": _id}})

    return Response(
        response=json.dumps(rslt),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/portfolio/<portfolio_id>/audit")
async def get_portfolio_audit(portfolio_id):
    mdb = uip_dbs.Db("uip_meta").conn["uip"]
    docs = mdb["pat"].find({"__meta.id": portfolio_id, "__meta.archived": True})
    portfolio_position_audit_results = []
    portfolio_audit_results = []
    response = {
        "portfolio_audit_results": portfolio_audit_results,
        "portfolio_position_audit_results": portfolio_position_audit_results,
    }
    for doc in docs:
        meta = doc["__meta"]

        changed_by = meta.get(
            "changed_by",
            {
                "sid": meta["user"],
                "name": meta["author"],
                "security_provider": None,
                "provider": None,
            },
        )
        date_changed = meta["timestamp"].isoformat()
        par = {
            "portfolio_id": portfolio_id,
            "name": doc.get("portfolio_name", ""),
            "type": doc.get("type", None),
            "date_changed": date_changed,
            "action": meta["action"],
            "changed_by": changed_by,
        }
        portfolio_audit_results.append(par)

        diff = meta.get("diff", {})
        for key, values in diff.items():
            for diff_value in values:
                ppar = {
                    "asset_id": diff_value["asset_id"],
                    "weight": diff_value["weight"],
                    "date_changed": date_changed,
                    "action": meta["action"],
                    "changed_by": changed_by,
                }
                portfolio_position_audit_results.append(ppar)

    return response


@app.route("/api/pat/document", methods=["POST"])
async def create_document():
    # req_js = await request.json
    files = await request.files
    form = await request.form
    if len(files) != 1 or "content" not in files:
        return Response(
            response=json.dumps(dict(message=f"Expecting 1 file, found {len(files)} files under key content.")),
            status=400,
            mimetype="application/json",
        )
    content = files["content"]
    file_name = content.filename

    req_keys = ["report_type", "document_audience", "customization_options", "build_version"]

    if not all(key in form for key in req_keys):
        return Response(
            response=json.dumps(dict(message=f"One of the required keys, {req_keys} ,is not present")),
            status=400,
            mimetype="application/json",
        )
    binary_io = io.BytesIO()
    content.save(binary_io)
    content_encoded = base64.b64encode(binary_io.getvalue()).decode("utf-8")
    complete_data = dict(form)
    complete_data["file_content"] = content_encoded
    complete_data["file_name"] = file_name

    req = rest_pb2.JSON(str=json.dumps(complete_data))

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).createDocument(
        request=req, metadata=request.vars["metadata_t"]
    )

    response = json.loads(resp.str)
    status = response.pop("status")
    return Response(response=json.dumps(response.pop("result")), status=status)


@app.route("/api/pat/document/<document_id>/content", methods=["GET"])
async def get_document(document_id):
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).DocumentContent(
        request=rest_pb2.PatDocumentContentInput(document_id=document_id), metadata=request.vars["metadata_t"]
    )
    content = json.loads(resp.str)
    decoded_content = base64.b64decode(content)

    response = Response(response=decoded_content, status=200, mimetype="application/pdf")
    response.headers["Content-Type"] = "application/pdf"
    response.headers["Content-Disposition"] = "inline; filename={}.pdf".format(document_id)
    return response


@app.route("/api/pat/document/<document_id>", methods=["GET"])
async def get_document_info(document_id):
    req = rest_pb2.PatDocumentInput(document_id=document_id)

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).DocumentInfo(
        request=req, metadata=request.vars["metadata_t"]
    )

    dict = json.loads(resp.str)
    if dict is None:
        return Response(
            response=f"{document_id} Not found",
            status=404,
        )

    return Response(
        response=json.dumps(dict),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/product-screener/screen", methods=["POST"])
async def screener_screen():
    data = await request.json
    req = rest_pb2.PatScreenerInput(
        from_=int(request.args.get("from", -1)),
        max=int(request.args.get("max", -1)),
        payload=rest_pb2.JSON(str=json.dumps(data)),
    )

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).ScreenerScreen(
        request=req, metadata=request.vars["metadata_t"]
    )

    print("-------------- SCREEN -----------", request.args, request.args.get("type", "N/A"))
    return Response(
        response=resp.str,
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/watchlist", methods=["GET"])
async def watchlist_list():
    args = request.args
    req = rest_pb2.PatWatchlistListInput(
        watchlist_type=args.get("watchlist_type", ""),
        page_size=int(args.get("page_size", 20)),
        page_number=int(args.get("page_number", 0)),
        sort=args.get("sort", ""),
    )

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).GetWatchlists(
        request=req, metadata=request.vars["metadata_t"]
    )

    dic = json.loads(resp.str)
    return Response(
        response=json.dumps(dic),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/product-screener/traffic-lights", methods=["POST"])
async def screener_traffic_lights():
    data = await request.json
    req = rest_pb2.PatScreenerInput(
        from_=int(request.args.get("from", -1)),
        max=int(request.args.get("max", -1)),
        payload=rest_pb2.JSON(str=json.dumps(data)),
    )

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).ScreenerTrafficLights(
        request=req, metadata=request.vars["metadata_t"]
    )

    return Response(
        response=resp.str,
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/watchlist/<watchlist_id>", methods=["GET"])
async def watchlist_get(watchlist_id):
    req = rest_pb2.PatGetwatchlistInput(watchlist_id=watchlist_id)

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).GetWatchlist(
        request=req, metadata=request.vars["metadata_t"]
    )

    print('------------- sending watchlist ___', resp.str)
    dict = json.loads(resp.str)
    if dict is None:
        return Response(
            response=json.dumps({"message": f"Watchlist id {watchlist_id} not found"}),
            status=404,
        )

    return Response(
        response=json.dumps(dict),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/product-screener/counts", methods=["POST"])
async def screener_counts():
    data = await request.json
    req = rest_pb2.PatScreenerInput(
        from_=int(request.args.get("from", -1)),
        max=int(request.args.get("max", -1)),
        payload=rest_pb2.JSON(str=json.dumps(data)),
    )

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).ScreenerCounts(
        request=req, metadata=request.vars["metadata_t"]
    )

    print("-------------- COUNTS -----------", request.args)
    return Response(
        response=resp.str,
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/watchlist/<watchlist_id>", methods=["PUT"])
async def watchlist_update(watchlist_id):
    data = await request.json

    req = create_watchlist_obj(data)
    req.watchlist_id = watchlist_id

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).UpdateWatchlist(
        request=req, metadata=request.vars["metadata_t"]
    )

    dic = json.loads(resp.str)
    if dic is None or "error" in dic:
        return Response(
            response=f"{watchlist_id} update failed {dic.get('error', '')}",
            status=500,
        )

    return Response(
        response=json.dumps(dic),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/product-screener/list-values", methods=["POST"])
async def screener_list_values():
    data = await request.json
    req = rest_pb2.PatScreenerInput(
        from_=int(request.args.get("from", -1)),
        max=int(request.args.get("max", -1)),
        payload=rest_pb2.JSON(str=json.dumps(data)),
    )

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).ScreenerListValues(
        request=req, metadata=request.vars["metadata_t"]
    )

    return Response(
        response=resp.str,
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/watchlist", methods=["POST"])
async def watchlist_create():
    data = await request.json

    req = create_watchlist_obj(data)
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).CreateWatchlist(
        request=req, metadata=request.vars["metadata_t"]
    )

    dic = json.loads(resp.str)
    if dic is None or "error" in dic:
        return Response(
            response=f"Watchlist creation failed {dic.get('error', '') if dic else ''}",
            status=500,
        )

    return Response(
        response=json.dumps(dic),
        status=201,
        mimetype="application/json",
    )


@app.route("/api/pat/watchlist/<watchlist_uuid>", methods=["DELETE"])
async def watchlists_delete(watchlist_uuid):
    req = rest_pb2.PatGetwatchlistInput(watchlist_id=watchlist_uuid)

    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).DeleteWatchlist(
        request=req, metadata=request.vars["metadata_t"]
    )

    dict = json.loads(resp.str)
    success = dict.get("success")
    if success:
        return Response(
            status=204,
            mimetype="application/json",
        )

    return Response(status=dict.get("code"), response=dict.get("msg"), mimetype="application/json")


@app.route("/api/pat/watchlist/<watchlist_id>/assets/remove", methods=["PATCH"])
async def watchlist_remove_assets(watchlist_id):
    data = await request.json
    assets_to_remove = data.get("assets", [])

    if assets_to_remove:
        req = rest_pb2.PatAssetsInput(assets=json.dumps(assets_to_remove))

        req.watchlist_id = watchlist_id

        resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).RemoveAssetFromWatchlist(
            request=req, metadata=request.vars["metadata_t"]
        )

        dic = json.loads(resp.str)
        if dic:
            return Response(
                response=json.dumps(dic),
                status=202,
                mimetype="application/json",
            )
        else:
            return Response(
                response=json.dumps({"message": f"Watchlist with id {watchlist_id} not found"}),
                status=404,
                mimetype="application/json",
            )
    else:
        return Response(
            response="invalid input",
            status=400,
            mimetype="application/json",
        )


@app.route("/api/pat/watchlist/<watchlist_id>/assets/add", methods=["PATCH"])
async def watchlist_add_assets(watchlist_id):
    data = await request.json
    assets_to_add = data.get("assets", [])

    if assets_to_add:
        req = rest_pb2.PatAssetsInput(assets=json.dumps(assets_to_add))

        req.watchlist_id = watchlist_id

        resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).AddAssetToWatchlist(
            request=req, metadata=request.vars["metadata_t"]
        )

        dic = json.loads(resp.str)
        if dic:
            return Response(
                response=json.dumps(dic),
                status=202,
                mimetype="application/json",
            )
        else:
            return Response(
                response=json.dumps({"message": f"Watchlist with id {watchlist_id} not found"}),
                status=404,
                mimetype="application/json",
            )
    else:
        return Response(
            response="invalid input",
            status=400,
            mimetype="application/json",
        )


@app.route("/api/pat/asset/invalid/watchlists", methods=["GET"])
async def invalid_watchlists():
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).GetWatchlistsWithInvalidAssets(
        request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(), metadata=request.vars["metadata_t"]
    )
    dic = json.loads(resp.str)
    return Response(
        response=json.dumps(dic),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/pat/asset/invalid/watchlists/<watchlist_id>", methods=["GET"])
async def invalid_watchlist(watchlist_id):
    req = rest_pb2.PatGetwatchlistInput(watchlist_id=watchlist_id)
    resp = await rest_pb2_grpc.PatStub(grpc_channels.get_channel("pat")).CheckWatchListForInvalidAssets(
        request=req, metadata=request.vars["metadata_t"]
    )
    return Response(
        response="",
        status=204,
        mimetype="application/json",
    )
