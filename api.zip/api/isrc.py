import uip_grpc

import rest_pb2
import rest_pb2_grpc

from quart.blueprints import Blueprint
from quart import request

from google.protobuf.json_format import MessageToJson


grpc_channels = uip_grpc.GRPC(async_mode=True)

app = Blueprint(
    "isrc",
    __name__,
)


@app.route("/api/isrc-portfolio", methods=["GET"])
async def isrc_policy_portfolio_request():
    """Fetches data from isrc_policy_portfolio_request"""
    L = request.vars["L"]

    date = None
    if request.args:
        date = request.args.get("date", "")

    L.info("GET Request for /api/isrc-portfolio")

    return MessageToJson(
        await rest_pb2_grpc.ISRCStub(grpc_channels.get_channel("isrc")).isrcAnalysis(
            request=rest_pb2.ISRCAnalysisRequest(date=date),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/isrc-portfolio/latest-available-date", methods=["GET"])
async def isrc_latest_available_date():
    """Fetches data from isrc_latest_available_date"""
    L = request.vars["L"]

    all_available_dates = False

    if request.args:
        all_available_dates = request.args.get("all_available_dates", False, type=bool)
    L.info("GET Request for /api/isrc-portfolio/latest-available-date")

    return MessageToJson(
        await rest_pb2_grpc.ISRCStub(grpc_channels.get_channel("isrc")).latest_available_date(
            request=rest_pb2.ISRCAvailableDatesRequest(all_available_dates=all_available_dates),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
