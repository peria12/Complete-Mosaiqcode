import uip_grpc
import json
import rest_pb2
import rest_pb2_grpc
from quart import request
from quart.blueprints import Blueprint
from google.protobuf.json_format import MessageToDict

grpc_channels = uip_grpc.GRPC(async_mode=True)

app = Blueprint(
    "sharedobject",
    __name__,
)


@app.route("/api/sharedobject", methods=["POST"])
async def create_sharedobject():
    L = request.vars["L"]
    req_payload = await request.data
    L.info("Request payload: %s", req_payload)
    sharedobjectSvcRes = MessageToDict(
        await rest_pb2_grpc.SharedObjectStub(grpc_channels.get_channel("sharedobject")).CreateSharedObject(
            request=rest_pb2.CreateSharedObjectRequest(
                app=request.args.get("app"), zone=request.args.get("zone"), payload=rest_pb2.JSON(str=req_payload)
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(sharedobjectSvcRes["str"])
    if strVal["status"] == "ok":
        return strVal
    else:
        return strVal, 500


@app.route("/api/sharedobject/id/<oid>", methods=["GET"])
async def read_sharedobject(oid):
    sharedobjectSvcRes = MessageToDict(
        await rest_pb2_grpc.SharedObjectStub(grpc_channels.get_channel("sharedobject")).ReadSharedObject(
            request=rest_pb2.ReadSharedObjectRequest(id=oid),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(sharedobjectSvcRes["str"])
    return strVal


@app.route("/api/sharedobject/id/<oid>/audithistory", methods=["GET"])
async def get_sharedobjecthistory(oid):
    sharedobjectSvcRes = MessageToDict(
        await rest_pb2_grpc.SharedObjectStub(grpc_channels.get_channel("sharedobject")).GetSharedObjectAuditHistory(
            request=rest_pb2.ReadSharedObjectRequest(id=oid),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(sharedobjectSvcRes["str"])
    return strVal


@app.route("/api/sharedobject/id/<oid>", methods=["PUT"])
async def update_sharedobject(oid):
    L = request.vars["L"]
    req_payload = await request.data
    L.info("Request payload: %s", req_payload)
    sharedobjectSvcRes = MessageToDict(
        await rest_pb2_grpc.SharedObjectStub(grpc_channels.get_channel("sharedobject")).UpdateSharedObject(
            request=rest_pb2.UpdateSharedObjectRequest(id=oid, payload=rest_pb2.JSON(str=req_payload)),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(sharedobjectSvcRes["str"])
    if strVal["status"] == "ok":
        return strVal
    else:
        return strVal, 500


@app.route("/api/sharedobject/id/<oid>", methods=["DELETE"])
async def delete_sharedobject(oid):
    L = request.vars["L"]
    L.info("Deleting shared-object: %s", oid)
    sharedobjectSvcRes = MessageToDict(
        await rest_pb2_grpc.SharedObjectStub(grpc_channels.get_channel("sharedobject")).DeleteSharedObject(
            request=rest_pb2.DeleteSharedObjectRequest(id=oid),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(sharedobjectSvcRes["str"])
    if strVal["status"] == "ok":
        return strVal
    else:
        return strVal, 500


@app.route("/api/sharedobject", methods=["GET"])
async def get_all_sharedobjects():
    sharedobjectSvcRes = MessageToDict(
        await rest_pb2_grpc.SharedObjectStub(grpc_channels.get_channel("sharedobject")).FetchAllSharedObjects(
            request=rest_pb2.FetchAllSharedObjectsRequest(app=request.args.get("app"), zone=request.args.get("zone")),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(sharedobjectSvcRes["str"])
    return strVal


@app.route("/api/dept/users", methods=["GET"])
async def fetch_users_dept():
    L = request.vars["L"]
    sharedobjectSvcRes = MessageToDict(
        await rest_pb2_grpc.SharedObjectStub(grpc_channels.get_channel("sharedobject")).FetchDeptUserList(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(sharedobjectSvcRes)
    strVal = json.loads(sharedobjectSvcRes["str"])
    return strVal, {"Content-Type": "application/json"}
