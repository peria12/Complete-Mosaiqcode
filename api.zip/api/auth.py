from quart import request
from quart.blueprints import Blueprint

from uip_auth_s import Okta

from transcoder_libs import authorize, search_okta_accounts
from uip_auth_c import UIPAuth
import uip_config
import humps
import time
from fastapi import APIRouter, Request, Response
from fastapi import Depends, status
from pydantic import BaseModel, Field, model_validator
from typing import Any, Literal, Dict, Optional
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from goe_schema import (
    Message,
    ValidationMessage,
    ValidationMessageOne,
    ValidationMessageTwo,
    InternalServerMessage,
)

import goelib.goe_schema.auth

app = Blueprint(
    "auth",
    __name__,
)

okta = Okta()
cfg = uip_config.ConfigDict()

usage = {}
usage_minute = time.time() // 60

auth_router = APIRouter()


def usage_count(user):
    global usage
    global usage_minute

    now = time.time() // 60
    if now > usage_minute:
        usage_minute = now
        usage = {}

    if user in usage:
        usage[user] += 1
    else:
        usage[user] = 1

    return usage[user]


@app.route("/api/auth/generate_token", methods=["POST"])
def generate_token_with_user_pass():
    """
    Returns the access token to client
    """
    uipauth = UIPAuth(use_cache=False)
    L = request.vars["L"]
    username = request.headers.get("username", None)
    password = request.headers.get("password", None)
    access_token = None
    info = None

    if username and password:
        try:
            access_token = uipauth.get_access_token_username_password(username, password)
        except Exception as exc:
            print(exc)
            L.info("Get access token with api: Something went wrong.")

        if access_token:
            L.info("Get access token with api: Access token generated")
            info = "Access token generated"
        else:
            info = "Authentication Failed"
    else:
        L.info("Get access token with api: No username and/or password provided.")
        info = "No username and/or password provided"

    return {"access_token": access_token, "info": info}


@app.route("/api/okta/search_users", methods=["GET"])
async def okta_search_users():
    """
    Okta search users using search string
    filterstring, limit results (max 60)
    """
    L = request.vars["L"]

    text = request.args.get("text")
    limit = request.args.get("limit", 10)
    if not text:
        return "Param <text> is required", 400

    L.info(f"Okta search_users {limit}")
    return await search_okta_accounts(text, limit)


@app.route("/api/okta/reset_password", methods=["POST"])
@authorize((("goe", "client-settings", "admin"),))
async def send_password_reset_link():
    """
    Send user a link to reset password
    """
    L = request.vars["L"]

    data = await request.json
    username = data.get("username")
    if not username:
        return "Username is required", 400

    L.info(f"Okta reset_password {username}")

    try:
        return await okta.reset_password(username)
    except Exception as exc:
        L.info(f"Okta resetPassword Failed {str(exc)}")
        return {"message": str(exc)}, 400


@auth_router.post("/SIGNIN", include_in_schema=False, status_code=status.HTTP_200_OK, name="Sign In", tags=["Auth"])
@auth_router.post("/signin", include_in_schema=False, status_code=status.HTTP_200_OK, name="Sign In", tags=["Auth"])
@auth_router.post(
    "/signIn",
    status_code=status.HTTP_200_OK,
    response_model=goelib.goe_schema.auth.SignInOutputModel,
    responses={
        200: goelib.goe_schema.auth.signin_response_model,
        400: {"model": ValidationMessageTwo},
        500: {"model": goelib.goe_schema.auth.InternalServerMessage},
    },
    name="Sign In",
    tags=["Auth"],
)
async def okta_signin(request: Request, json_request: goelib.goe_schema.auth.SignInInputModel):
    """
    Okta signin
    """
    L = request.state.vars["L"]
    data = json_request

    email = data.get("email", None)
    password = data.get("password", None)

    if not email:
        L.info("Okta signin API: email not provided.")
        return JSONResponse({"statusCode": 400, "message": "Email not provided", "body": None}, status_code=400)

    if not password:
        L.info("Okta signin API: password not provided.")
        return JSONResponse(
            {"statusCode": 400, "message": "Missing required parameter PASSWORD", "body": None}, status_code=400
        )

    L.info(f"Okta signIn {email}")

    count = usage_count(email)
    if count > cfg["okta"]["rate_limit"]:
        L.info(f"Okta signIn {email}, blocked, count {count}")
        return JSONResponse({"statusCode": 400, "message": "Too many signIn attempts.", "body": None}, status_code=400)

    try:
        result = await okta.signin(username=email, password=password)
        return JSONResponse({"AuthenticationResult": humps.pascalize(result)})
    except Exception as exc:
        L.info(f"Okta signin API Failed {str(exc)}")
        return JSONResponse(
            {"statusCode": 400, "message": "Incorrect username or password.", "body": None}, status_code=400
        )


@auth_router.post(
    "/FORGOTPASSWORD", include_in_schema=False, status_code=status.HTTP_200_OK, name="Forgot Password", tags=["Auth"]
)
@auth_router.post(
    "/forgotpassword", include_in_schema=False, status_code=status.HTTP_200_OK, name="Forgot Password", tags=["Auth"]
)
@auth_router.post(
    "/forgotPassword",
    status_code=status.HTTP_200_OK,
    response_model=goelib.goe_schema.auth.ForgotPasswordOutputModel,
    responses={
        200: goelib.goe_schema.auth.forgotpwd_response_model,
        400: {"model": ValidationMessageTwo},
        500: {"model": goelib.goe_schema.auth.InternalServerMessage},
    },
    name="Forgot Password",
    tags=["Auth"],
)
async def okta_forgot_password(request: Request, json_request: goelib.goe_schema.auth.ForgotPasswordInputModel):
    """
    Okta forgot password
    """
    L = request.state.vars["L"]
    data = json_request
    email = data.get("email", None)
    if not email:
        L.info("Okta forgotPassword API: email not provided")
        return JSONResponse({"message": "email not provided"}, status_code=400)

    L.info(f"Okta forgotPassword {email}")

    try:
        await okta.forgot_password(email)
        return {"success": True}
    except Exception as exc:
        L.info(f"Okta forgotPassword API Failed {str(exc)}")
        return JSONResponse({"message": str(exc)}, status_code=400)


# Will change password
@auth_router.post(
    "/CHANGEPASSWORD", include_in_schema=False, status_code=status.HTTP_200_OK, name="Change Password", tags=["Auth"]
)
@auth_router.post(
    "/changepassword", include_in_schema=False, status_code=status.HTTP_200_OK, name="Change Password", tags=["Auth"]
)
@auth_router.post(
    "/changePassword",
    status_code=status.HTTP_200_OK,
    response_model=goelib.goe_schema.auth.ChangePasswordOutputModel,
    responses={
        200: goelib.goe_schema.auth.changepasswd_response_model,
        400: {"model": ValidationMessageTwo},
        500: {"model": goelib.goe_schema.auth.InternalServerMessage},
    },
    name="Change Password",
    tags=["Auth"],
)
async def okta_change_password(request: Request, json_request: goelib.goe_schema.auth.ChangePasswordInputModel):
    """
    Okta forgot password
    """
    L = request.state.vars["L"]
    data = json_request
    email = data.get("email", None)
    if not email:
        L.info("Okta changePassword API: email not provided")
        return JSONResponse({"message": "email not provided"}, status_code=400)

    oldPassword = data.get("oldPassword", None)
    if not oldPassword:
        L.info("Okta changePassword API: oldPassword not provided")
        return JSONResponse({"message": "email not provided"}, status_code=400)

    newPassword = data.get("newPassword", None)
    if not newPassword:
        L.info("Okta changePassword API: newPassword not provided")
        return JSONResponse({"message": "email not provided"}, status_code=400)

    L.info(f"Okta changePassword {email}")

    try:
        await okta.change_password(email, oldPassword, newPassword)
        return {"success": True}
    except Exception as exc:
        L.info(f"Okta changePassword API Failed {str(exc)}")
        return JSONResponse({"message": str(exc)}, status_code=400)


@auth_router.post(
    "/REFRESHTOKEN", include_in_schema=False, status_code=status.HTTP_200_OK, name="Refresh Token", tags=["Auth"]
)
@auth_router.post(
    "/refreshtoken", include_in_schema=False, status_code=status.HTTP_200_OK, name="Refresh Token", tags=["Auth"]
)
@auth_router.post(
    "/refreshToken",
    status_code=status.HTTP_200_OK,
    response_model=goelib.goe_schema.auth.RefreshTokenOutputModel,
    responses={
        200: goelib.goe_schema.auth.forgotpwd_response_model,
        400: {"model": goelib.goe_schema.auth.RefreshTokenStatus},
        500: {"model": goelib.goe_schema.auth.InternalServerMessage},
    },
    name="Refresh Token",
    tags=["Auth"],
)
async def okta_refresh_auth(request: Request, json_request: goelib.goe_schema.auth.RefreshTokenInputModel):
    """
    Okta refresh token
    """
    L = request.state.vars["L"]
    data = json_request
    refreshToken = data.get("refreshToken", None)
    if not refreshToken:
        return JSONResponse({"message": "Refresh Token missing"}, status_code=400)

    L.info("Okta refreshToken")

    try:
        result = await okta.refresh_auth(refreshToken)
        return JSONResponse({"AuthenticationResult": humps.pascalize(result)})
    except Exception as exc:
        L.info(f"Okta refreshToken API: Something went wrong. {str(exc)}")
        return JSONResponse({"statusCode": 400, "message": "Invalid Refresh Token", "body": None}, status_code=400)
