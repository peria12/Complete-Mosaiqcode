class RioException(Exception):
    pass


class ValidationError(RioException):
    def __init__(self, message, success=False):
        self.error_code = 400
        self.name = "ValidationError"
        self.message = message
        self.success = success
        super().__init__(self.message)


class UnAuthorizedError(RioException):
    def __init__(self, message, success=False):
        self.error_code = 403
        self.name = "UnAuthorizedError"
        self.message = message
        self.success = success
        super().__init__(self.message)


class CommunicationFailureError(RioException):
    def __init__(self, message, success=False):
        self.error_code = 500
        self.name = "CommunicationFailureError"
        self.message = message
        self.success = success
        super().__init__(self.message)
