import uip_grpc

import rest_pb2
import rest_pb2_grpc

from quart.blueprints import Blueprint
from quart import request

from google.protobuf.json_format import MessageToJson, ParseDict
from google.protobuf.struct_pb2 import Struct
from transcoder_libs import process_post_data
import json

grpc_channels = uip_grpc.GRPC(async_mode=True)

app = Blueprint(
    "alerts",
    __name__,
)


@app.route("/api/alerts/defs/<def_id>", methods=["GET"])
async def svc_alerts_def_get(def_id):
    r = rest_pb2.AlertID(_id=def_id)
    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).GetAlert(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/defs", methods=["GET"])
async def svc_alerts_defs_get():
    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).GetAlerts(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/subscriptions/<user_id>", methods=["GET"])
async def svc_alerts_user_subscriptions(user_id):
    r = rest_pb2.SubscriptionReq(user_id=user_id)
    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).GetUserSubcriptions(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/users/<def_id>", methods=["GET"])
async def svc_alerts_alert_subscribers(def_id):
    r = rest_pb2.SubscriptionReq(def_id=def_id)
    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).GetAlertSubcribers(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/defs/<def_id>", methods=["DELETE"])
async def svc_alerts_def_delete(def_id):
    r = rest_pb2.AlertID(_id=def_id)
    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).DeleteAlert(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/defs", methods=["POST"])
async def svc_alerts_def_create():
    L = request.vars["L"]

    data = await process_post_data(request)

    if "_id" in data:
        del data["_id"]

    r = Struct()
    r.update(data)

    L.info(data)

    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).CreateAlert(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/defs/<def_id>", methods=["PUT"])
async def svc_alerts_def_update(def_id):
    if not def_id:
        raise Exception("Alert definition ID cannot be null")

    L = request.vars["L"]

    data = await process_post_data(request)

    data["_id"] = def_id

    r = Struct()
    r.update(data)

    L.info(data)

    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).UpdateAlert(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


# Subscribe/unsubscribe
@app.route("/api/alerts/defs/<def_id>/mode/<alert_mode>/subscribe/<user_id>", methods=["POST"])
async def svc_alerts_subscribe(def_id, alert_mode, user_id):
    if not def_id:
        raise Exception("Alert definition ID cannot be null")
    if not alert_mode:
        raise Exception("Alert mode cannot be null")

    r = rest_pb2.SubscriptionReq(def_id=def_id, alert_mode=alert_mode, user_id="" if user_id is None else user_id)

    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).SubscribeToAlert(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/defs/<def_id>/mode/<alert_mode>/unsubscribe/<user_id>", methods=["POST"])
async def svc_alerts_unsubscribe(def_id, alert_mode, user_id):
    if not def_id:
        raise Exception("Alert definition ID cannot be null")
    if not alert_mode:
        raise Exception("Alert mode cannot be null")

    r = rest_pb2.SubscriptionReq(def_id=def_id, alert_mode=alert_mode, user_id="" if user_id is None else user_id)

    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).UnsubscribeFromAlert(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/events/<def_id>", methods=["POST"])
async def svc_alerts_create_event(def_id):
    if not def_id:
        raise Exception("Alert definition ID cannot be null")

    data = await process_post_data(request)

    r = Struct()
    r.update(data)

    r["def_id"] = def_id

    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).CreateAlertEvent(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/events", methods=["GET"])
async def svc_alerts_get_events():
    L = request.vars["L"]

    req = rest_pb2.AlertEventsRequest()

    json_obj = await request.json
    if json_obj:
        req = ParseDict(json_obj, req)
    if request.args:
        req = ParseDict(request.args, req)

    if req.page_size == 0:
        req.page_size = 50

    L.info(
        (
            f"GET request for entities, Page: {req.page}, Page size: {req.page_size}"
            f", Filters: {req.filters}, Sort Fields: {req.sort_fields}"
        )
    )

    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).GetEvents(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/recent_events_count", methods=["GET"])
async def svc_alerts_get_events_count():
    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).GetRecentEventsCount(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(), metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/events/clear/<event_id>", methods=["POST"])
async def svc_alerts_clear_event(event_id):
    if not event_id:
        raise Exception("Dont know which event to clear")

    return MessageToJson(
        await rest_pb2_grpc.AlertsStub(grpc_channels.get_channel("alerts")).ClearAlertEvent(
            request=rest_pb2.AlertID(_id=event_id), metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/alerts/announcements", methods=["POST"])
async def svc_alerts_announcements():
    L = request.vars["L"]
    folder = request.args.get("folder", "announcements")
    file = await process_post_data(request, folder=folder)
    file_path = file.get("filePath")
    data = json.loads(file["json"])
    L.info((f"Create announcements, data: {data}" f", FilePath: {file_path}"))

    return {"statusCode": 201, "message": "Created successfully"}
