from pydantic import BaseModel, Field, model_validator, confloat
from typing import Any, List, Literal, Optional, Dict, Union

class GoalProfileList(BaseModel):
    goalID: str
    goalAmt: list
    startDate: str
    endDate: str
    priority: str
    scenarioType: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class UnifiedPortfolioAdviceInputModel(BaseModel):
    participantID: bool | None
    useRiskProfile: bool | None
    isNewRiskProfile: bool
    isNewInvestmentTenure: bool
    isNewGoalPriority: bool
    isNearTermVolatility: bool
    isNewGoal: bool
    getPath: bool
    reallocationFreq: str
    initialInvestment: int
    currentWealth: int
    currentPortfolioId: int
    currDate: str
    infusions: list
    riskProfile: str
    cashflowDate: str
    infusionType: str
    goalProfileList: List[GoalProfileList]

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class UnifiedPortfolioAdviceInputModelV3(BaseModel):
    participantID: bool | None
    useRiskProfile: bool | None
    callibrateGoalRec: bool | None
    calibrateGoalRec: bool | None
    isNewRiskProfile: bool
    isNewInvestmentTenure: bool
    isNewGoalPriority: bool
    isNearTermVolatility: bool
    isNewGoal: bool
    getPath: bool
    reallocationFreq: str
    initialInvestment: int
    currentWealth: int
    currentPortfolioId: int
    currDate: str | None
    infusions: list
    riskProfile: str
    cashflowDate: str
    infusionType: str
    goalProfileList: List[GoalProfileList]

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class TaxRateModel(BaseModel):
    LTCGPreRetirement: float
    ETRPreRetirement: float
    LTCGPostRetirement: float
    ETRPostRetirement: float

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class MemberListModel(BaseModel):
    memberType: str
    memberID: str
    DOB: str
    currentAge: int
    retirementAge: int
    stateOfResidence: str
    currentSalary: int
    socialSecurityStartAge: int
    TDABalanceForRMD: int
    RMDUtilized: int
    existingMonthlySocialSecurityAmount: int

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class HouseHoldModel(BaseModel):
    householdID: str
    stateOfResidence: str
    memberList: list[MemberListModel]

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class CurrentHoldingsModel(BaseModel):
    categoryName: str
    categoryID: str
    categoryPrice: int
    quantity: float
    costBasis: float

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class CashFlowDetailsModel(BaseModel):
    cashflowAmt: list[float | int]
    startDate: str
    endDate: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class AccountsModel(BaseModel):
    accountID: str
    accountType: str
    taxabilityType: str
    memberIDs: list
    currentBalance: float
    currentHoldings: list[CurrentHoldingsModel]
    cashflowDetails: CashFlowDetailsModel

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class GoalProfileListModel(BaseModel):
    goalId: str
    goalAmt: list[float]
    scenarioType: str
    startDate: str
    endDate: str
    priority: str
    bequest: bool
    goalPurpose: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class GoeForTaxesInputModel(BaseModel):
    reallocate: bool
    isNewRiskProfile: bool
    colaRate: float
    isNewInvestmentTenure: bool
    isNewGoal: bool
    isNewGoalPriority: bool
    isNearTermVolatility: bool
    getPath: bool
    reallocationFreq: str
    currentPortfolioId: str | None
    lossThreshold: str | None
    currDate: str
    riskProfile: str
    riskProfile: str
    computeSocialSecurity: bool
    useSocialSecurityForGoals: bool
    computeRMD: bool
    useRMDForGoals: bool
    cashflowDate: str
    infusionType: str
    taxRates: TaxRateModel | None = None
    household: HouseHoldModel
    accounts: list[AccountsModel]
    goalProfileList: list[GoalProfileListModel]

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class HistoricalLiveScenarios(BaseModel):
    useRiskProfile: bool | None
    historicalStartYear: int
    rebalancing: str
    lossThreshold: int | float
    riskProfile: str
    initialWealth: int | float
    infusionPercentage: int | float
    tenure: int
    finalWealth: int | float
    goalPriority: str
    benchmarkPortfolio: int

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class ReplacementIncomeCalculatorInputModel(BaseModel):
    autoEscalationRoth: int | float | None
    autoEscalationTraditional: int | float | None
    companyContribution: int | float
    currentSalary: int | float
    dateOfBirth: str
    inflation: int | float
    outsideAccountBalance: int | float
    outsideIncome: int | float
    planningAge: int | float
    replacementRate: int | float
    retirementAge: int | float
    rothContribution: int | float
    salaryGrowthRate: int | float
    socialSecurityIncome: int | float
    state: str
    traditionContribution: int | float

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

# class RunPipeResponseModel(BaseModel):
#     analysis_report: dict
#     path_report: dict

#     @model_validator(mode="wrap")
#     def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
#         return data


# class RunPipeOutputModel(BaseModel):
#     statusCode: int
#     message: str
#     body: RunPipeResponseModel

class currentRetirementAHAComposition(BaseModel):
    equity: float | None
    debt: float | None
    other: float | None

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class AssetsUnderManagement(BaseModel):
    accountId: str
    accountType: str
    model: str
    assetCategory: str
    GOEAUM: bool
    advisorAUM: bool
    assetValue: int | float
    accountOwnership: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class AssetsHeldAway(BaseModel):
    accountType: str
    assetCategory: str
    assetValue: int | float
    accountOwnership: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Investment(BaseModel):
    assetsUnderManagement: List[AssetsUnderManagement]
    assetsHeldAway: List[AssetsHeldAway]

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Profile(BaseModel):
    salary: float
    retirementAge: int
    currentAge: int
    socialSecurityAge: int
    socialSecurityIncome: int | float | None

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class householdProfile(BaseModel):
    clientProfile: Profile
    spouseProfile: Profile

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class RunAggRetirementAccounts(BaseModel):
    useAgeBasedCap: bool | None
    clientId: str | None
    lastReallocationProbability: int | float
    reallocate: bool
    currentPortfolioId: int
    currentPortfolioRiskScore: int
    riskProfile: str
    currentRetirementGoal: int | float | None
    lastReallocationDate: str
    currentRetirementAHAComposition: currentRetirementAHAComposition
    initialInvestment: Investment
    currentInvestment: Investment
    householdProfile: householdProfile
    comfortZone: int
    riskScore: int
    startDate: str
    currDate: str
    endDate: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Mc4TaxesTaxRateModel(BaseModel):
    LTCGPreRetirement: float
    ETRPreRetirement: float
    LTCGPostRetirement: float
    ETRPostRetirement: float

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Mc4TaxesMemberListModel(BaseModel):
    memberType: str
    memberID: str
    DOB: str
    currentAge: int
    retirementAge: int
    stateOfResidence: str
    currentSalary: int
    socialSecurityStartAge: int
    TDABalanceForRMD: int
    RMDUtilized: int
    existingMonthlySocialSecurityAmount: int

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Mc4TaxesHouseHoldModel(BaseModel):
    householdID: str
    stateOfResidence: str
    memberList: list[Mc4TaxesMemberListModel]

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Mc4TaxesCurrentHoldingsModel(BaseModel):
    categoryName: str
    categoryID: str
    categoryPrice: int
    quantity: float
    costBasis: float

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Mc4TaxesCashFlowDetailsModel(BaseModel):
    cashflowAmt: list[float | int]
    startDate: str
    endDate: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Mc4TaxesAccountsModel(BaseModel):
    accountID: str
    accountType: str
    taxabilityType: str
    memberIDs: list
    currentBalance: float
    currentHoldings: list[Mc4TaxesCurrentHoldingsModel]
    cashflowDetails: Mc4TaxesCashFlowDetailsModel

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class Mc4TaxesGoalProfileListModel(BaseModel):
    goalId: str
    goalAmt: list[float]
    scenarioType: str
    startDate: str
    endDate: str
    priority: str
    bequest: bool
    goalPurpose: str

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data

class GoalSimulationEngineInputModel(BaseModel):
    reallocate: bool
    isNewRiskProfile: bool
    colaRate: float
    isNewInvestmentTenure: bool
    isNewGoal: bool
    isNewGoalPriority: bool
    isNearTermVolatility: bool
    getPath: bool
    reallocationFreq: str
    currentPortfolioId: str | None
    lossThreshold: str | None
    currDate: str
    riskProfile: str
    riskProfile: str
    computeSocialSecurity: bool
    useSocialSecurityForGoals: bool
    computeRMD: bool
    useRMDForGoals: bool
    cashflowDate: str
    infusionType: str
    taxRates: TaxRateModel | None = None
    household: HouseHoldModel
    accounts: list[Mc4TaxesAccountsModel]
    goalProfileList: list[Mc4TaxesGoalProfileListModel]

    @model_validator(mode="wrap")
    def skip_validation(cls, data: Any, ModelWrapValidatorHandler):
        return data



class Message(BaseModel):
    message: str

class InternalServerMessage(BaseModel):
    message: str = Field(title="message", description="message", examples=["Internal Server Error"])
    statusCode: int = Field(title="statuscode", description="statuscode", examples=[500])
    body: str = Field(title="body", description="body", examples=["Unexpected error: Please contact FT GOE Business team."])

class ValidationMessage(BaseModel):
    statusCode: int = Field(title="statuscode", description="statuscode", examples=[400])
    message: str = Field(title="message", description="ValidationError", examples=["ValidationError"])
    body: str = Field(title="body", description="Validation error message", examples=["error description"])

class ValidationMessageOne(BaseModel):
    statusCode: int = Field(title="statuscode", description="statuscode", examples=[400])
    message: str = Field(title="message", description="Validation Error", examples=["Validation Error"])
    body: str = Field(title="body", description="Validation error message", examples=["error description"])

class ValidationMessageTwo(BaseModel):
    statusCode: int = Field(title="statuscode", description="statuscode", examples=[400])
    message: str = Field(title="message", description="Validation Error", examples=["Validation Error"])
    body: str = Field(title="body", description="Validation error message", examples=["error description"])

class AuthError(BaseModel):
    name: str = Field(title="name", description="name", examples=["TokenExpiredError"])
    message: str = Field(title="message", description="message", examples=["jwt expired"])
    expiredAt: str = Field(title="expiredAt", description="expiredAt", examples=["2023-09-07T15:44:06"])
    
    
