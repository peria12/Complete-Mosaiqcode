import os
import json
import jwt

import time

from uip_auth_s import Validater, validate_pat_token, get_metadata, validate_session

import uip_logging

uip_logging.initialize("transcoder")


import uip_config
import uip_grpc
import uip_files
import logging

import rest_pb2
import rest_pb2_grpc

from uip_utils import generate_request_id
from quart import Quart, request
from uip_reports.powerbi.pbiembedservice import PbiEmbedService
from google.protobuf.json_format import MessageToJson

import goe_admin
import goe_capabilities
import goe_advisor_portal
import goe_rio
import www.api.auth as auth
import saa
import admin
import alerts
import entity_master
import file
import metrics
import model_portfolio
import isrc
import optimizer
import portfolios
import sharedobject
import pat
import market_intelligence
from datetime import datetime
import pat_auth
import boto3

import transcoder_libs

cfg = uip_config.ConfigDict()
from uip_auth_c import UIPAuth

port = os.environ.get("REST_API_PORT")
app = Quart(__name__)


# TODO make sure this is spawning processes and NOT threads as the code assumes variables can be shared

fio = uip_files.Files()
grpc_channels = uip_grpc.GRPC(async_mode=True)
validater = Validater()

app.register_blueprint(goe_advisor_portal.goe_advisor_portal_app)
app.register_blueprint(goe_rio.goe_rio_app)
app.register_blueprint(goe_admin.goe_app)
app.register_blueprint(goe_capabilities.goe_capabilities_app)
app.register_blueprint(auth.app)
app.register_blueprint(admin.app)
app.register_blueprint(saa.app)
app.register_blueprint(alerts.app)
app.register_blueprint(entity_master.app)
app.register_blueprint(file.app)
app.register_blueprint(metrics.app)
app.register_blueprint(model_portfolio.app)
app.register_blueprint(isrc.app)
app.register_blueprint(optimizer.app)
app.register_blueprint(portfolios.app)
app.register_blueprint(sharedobject.app)
app.register_blueprint(pat.app)
app.register_blueprint(market_intelligence.app)
app.register_blueprint(pat_auth.app)

app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024


def get_svc_token():
    account = cfg["uip_svc_account"]
    (username, password) = account.get("user"), account.get("password")
    uipauth = UIPAuth(use_cache=True)
    return uipauth.get_access_token_username_password(username, password)


@app.before_request
async def check_headers():
    auth = request.headers.get("authorization")
    if not auth:
        auth = request.args.get("access_token", "")

    token = auth.replace("Bearer ", "")

    source_ip = request.headers.get("HTTP_X_REAL_IP", request.remote_addr)
    if (
        request.path.lower()
        in [
            "/api/healthcheck",
            "/api/auth/generate_token",
            "/resetpassword",
            "/api/advisorportal/gettenantinfo",
            "/api/opensearch",
            "/api/es_holdings",
            "/api/entity-master/return-based",
            "/api/advisorportal/getbanner",
            "/api/pat/feature-flags",
        ]
        or request.path.startswith("/api/rio/cms/")  # allow all bloomreach CMS APIs for RIO
        or request.path.startswith("/api/file-name/public/")
        or request.path.startswith("/api/pat/mi/search")
        # or request.path.startswith("/api/pat/")  # Allow PAT apis until we do saml auth
        or request.path.startswith("/apis/custom.metrics.k8s.io/")
        or (request.path.startswith("/api/file-id/") and fio.is_file_public(request.path.split("/")[-1]))
        or (source_ip in cfg["safe_hosts"] and request.path.startswith("/api/file/"))
    ):
        # this request is coming from a safe host,
        # we allow file requests from safe hosts
        # TODO remove the DAL overide when SEnthil's demo is done
        svc_account = cfg["uip_svc_account"].get("user")

        metadata_d = {
            "ipaddr": source_ip,
            "email": svc_account,
            "target-email": request.headers.get("target-email", svc_account),
        }
    elif request.path.startswith("/api/pat/"):
        try:
            if request.path == "/api/pat/auth/login":
                # Validate the SAML token
                token = request.headers.get("Authorization").split(" ")[1]
                response, status_code = validate_pat_token(token)
                if status_code != 200:
                    return response, status_code
                else:
                    metadata_d = get_metadata(response, request, source_ip)
            else:
                # Validate the session id
                response_, status_code = await validate_session(request, source_ip)
                print(response_)
                if status_code != 200:
                    return response_, status_code
                else:
                    metadata_d = response_
        except Exception as e:
            return {"name": "authentication error", "message": str(e)}, 401
    else:
        try:
            auth_data = await validater.validate_token_and_return_data(token)
            metadata_d = {
                "first-name": auth_data.get("given_name"),
                "ipaddr": auth_data.get("ipaddr") or source_ip,
                "user-full-name": auth_data.get("name"),
                "user-name": auth_data["unique_name"].replace("@franklintempleton.com", ""),
                "user-id": auth_data["oid"],
                "email": auth_data.get("username") or auth_data["unique_name"],
                "target-email": request.headers.get("target-email", auth_data["unique_name"]),
            }
        except Exception as e:
            try:
                print(e)
                if "Signature has expired" in str(e):
                    data = jwt.decode(token, options={"verify_signature": False})
                    return {
                        "name": "TokenExpiredError",
                        "message": "jwt expired",
                        "expiredAt": datetime.utcfromtimestamp(data["exp"]).isoformat(),
                    }, 500
            except Exception as e:
                return {"name": "authentication error", "message": str(e)}, 401
            return {"name": "authentication error", "message": str(e)}, 401

    metadata_d["request-id"] = request.headers.get("request-id", generate_request_id())

    if request.path.startswith("/api/pat/"):
        if os.getenv("UIP_ENV") == "user":
            logging.LoggerAdapter(logging.getLogger("user"), metadata_d).info("using svc account on local env")
            metadata_d["authorization"] = get_svc_token()
    else:
        metadata_d["authorization"] = request.headers.get("authorization", request.args.get("access_token", ""))

    attributes = metadata_d.pop("attributes", {})
    metadata_d["security_provider"] = attributes.get("security_provider")
    metadata_d["provider"] = attributes.get("provider")
    request.vars = {
        "user": metadata_d.get("target-email"),
        "metadata_d": metadata_d,
        "metadata_t": tuple(metadata_d.items()),
        "L": logging.LoggerAdapter(logging.getLogger("user"), metadata_d),
        "attributes": attributes,
    }

    # we can do that as only one requests is served at a time
    # grpc_channels.set_request_vars(request.vars["metadata_d"])


@app.after_request
async def after_request_func(response):
    request_id = request.headers.get("Request-Id")
    response.headers["Request-Id"] = request_id
    return response


@app.route("/api/healthcheck", methods=["GET"])
def healthcheck():
    version = os.getenv("UIP_VERSION") or "na"
    env = os.getenv("UIP_ENV") or "user"

    return json.dumps({"healthcheck": "OK", "version": version, "env": env})


@app.route("/api/powerbi/embedinfo/workspace/<workspace_id>/report/<report_id>", methods=["GET"])
async def get_embed_info(workspace_id, report_id):
    """Returns report embed configuration"""
    request.vars["L"].info("GET Request for /api/powerbi/embedinfo")

    try:
        embed_info = PbiEmbedService().get_embed_params_for_single_report(workspace_id, report_id)
        return embed_info
    except Exception as ex:
        return json.dumps({"errorMsg": str(ex)}), 500


@app.route("/api/dal/get-data", methods=["GET"])
async def dal_request():
    """Fetches data from DAL"""
    req = request.args.get("req")

    request.vars["L"].info("GET Request for /api/dal/get-data")

    json = await rest_pb2_grpc.DALStub(grpc_channels.get_channel("dal")).GetDataJSON(
        request=rest_pb2.JSON(str=req), metadata=request.vars["metadata_t"]
    )

    return json.str


@app.route("/api/dal/delete-factor", methods=["PUT"])
async def delete_factor():
    """Delete factor"""
    req_payload = await request.data
    request.vars["L"].info("PUT Request for /api/dal/delete-factor")
    json = await rest_pb2_grpc.DALStub(grpc_channels.get_channel("dal")).DeleteFactor(
        request=rest_pb2.JSON(str=req_payload), metadata=request.vars["metadata_t"]
    )
    return json.str


@app.route("/api/dal/fields", methods=["GET"])
async def dal_fields():
    """Fetches DAL Fields"""

    request.vars["L"].info("GET Request for /api/dal/fields")

    resp = MessageToJson(
        await rest_pb2_grpc.DALStub(grpc_channels.get_channel("dal")).GetFields(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(), metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )

    return resp


@app.route("/api/screenshot", methods=["POST"])
async def svc_take_screenshot():
    # L = request.vars["L"]
    t1 = time.time()
    print("START", t1)

    app = request.args.get("app")
    zone = request.args.get("zone")

    body = await request.json
    html = body.get("html")
    print("CALLING SCREENSHOT", app, zone, time.time())

    response = MessageToJson(
        await rest_pb2_grpc.ScreenshotStub(grpc_channels.get_channel("screenshot")).TakeScreenshot(
            request=rest_pb2.ScreenshotRequest(app=app, zone=zone, html=html),
            metadata=request.vars["metadata_t"],
        )
    )
    print("GOT RESP", time.time() - t1)

    return response


@app.route("/api/export/pdf", methods=["POST"])
async def svc_export_pdf():
    body = await request.json
    html = body.get("html")
    id = body.get("id")
    option = body.get("option", {})

    response = MessageToJson(
        await rest_pb2_grpc.ScreenshotStub(grpc_channels.get_channel("screenshot")).DownloadPDF(
            request=rest_pb2.ExportPDFRequest(id=id, option=option, html=html),
            metadata=request.vars["metadata_t"],
        )
    )
    return response


@app.route("/api/aws_auth_keys", methods=["POST"])
async def svc_aws_signature():
    L = request.vars["L"]
    L.info("Generating aws keys.")
    access_key = cfg["open_search"]["access_key"]
    secret_key = cfg["open_search"]["password"]
    sts_client = boto3.client("sts", aws_access_key_id=access_key, aws_secret_access_key=secret_key)
    response = sts_client.assume_role(RoleArn=cfg["open_search"]["aws_role"], RoleSessionName="my_session")
    return {
        "access_key": response["Credentials"]["AccessKeyId"],
        "secret_key": response["Credentials"]["SecretAccessKey"],
        "region": "us-west-2",
        "service": "es",
        "session_token": response["Credentials"]["SessionToken"],
    }


@app.route("/api/opensearch", methods=["POST"])
async def svc_open_search():
    request_json = await request.json
    index_name = request_json["index_name"]
    query = request_json.get("query", {})
    scroll = request_json.get("scroll")
    search_string = request_json.get("search_string")
    return await transcoder_libs.open_search_query(
        request_json, request.vars, index_name, query=query, search_string=search_string, scroll=scroll
    )


@app.route("/api/es_holdings", methods=["POST"])
async def es_holdings_search():
    request_json = await request.json
    req_keys = ["date", "search_string"]
    # Check if keys are presetn
    for key in req_keys:
        if key not in request_json:
            return json.dumps({"error": f"{key} is missing in the payload"}), 400
    # Check if date is in correct format
    try:
        parsed_date = datetime.strptime(request_json["date"], "%Y-%m-%d")  # NOQA
    except Exception as e:
        return json.dumps({"error": f"Incorrect date format. Date needs to be in YYYY-MM-DD. {e}"}), 400
    return await transcoder_libs.es_holdings_query(request_json, request.vars)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=port)
