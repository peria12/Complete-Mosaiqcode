import pandas as pd
from pandas.tseries.offsets import BDay

import uip_grpc
import json

import rest_pb2
import rest_pb2_grpc

from quart.blueprints import Blueprint
from quart import request
from google.protobuf.json_format import MessageToDict

from uipmodel.saa.app.callbacks import (
    factset_indices_list_callback,
    sample_input_file_callback,
    sample_returns_file_callback,
    update_universe_callback,
    cme_callback,
    optimization_callback,
)
from uipmodel.daa.tilts import IsrcPolicy
from uipmodel.daa.callbacks import gen_isrc_table, gen_isrc_table_2, gen_isrc_tilt_table
from transcoder_libs import process_files

grpc_channels = uip_grpc.GRPC(async_mode=True)

app = Blueprint(
    "saa",
    __name__,
)


@app.route("/api/saa/<request_id>/run_optimization", methods=["POST"])
async def saa_run_optimization(request_id):
    L = request.vars["L"]
    L.info("saa run_optimization")

    return await optimization_callback(request_id, await request.json)


@app.route("/api/saa/<request_id>/cme", methods=["POST"])
async def saa_cme(request_id):
    L = request.vars["L"]
    L.info("saa cme")

    return await cme_callback(request_id, await request.json)


@app.route("/api/saa", methods=["POST"])
async def saa_file():
    L = request.vars["L"]

    L.info("saa: load new file")

    req_data = await process_files(request)
    files = req_data.get("attachments", [])

    data = {}
    form = await request.form
    if form:
        data.update(form.to_dict())
        data = json.loads(data.get("json", {}))
    use_all_values = data.get("use_all_values", False)

    if not files:
        return "Please upload a file", 400
    elif len(files) > 2:
        return "Maximum 2 files can be uploaded", 400

    request_id = request.vars["metadata_d"]["request-id"]

    file_list = []
    for f in files:
        file_list.append(f["buf"])

    resp = await update_universe_callback(file_list, request_id, use_all_values)
    resp["request_id"] = request_id

    return resp


@app.route("/api/daa", methods=["GET"])
async def daa_reports():
    """Create DAA tables for UIP portal, with one retry."""

    table1 = "isrc_summary_table"
    table2 = "isrc_summary_table_2"
    table3 = "isrc_tilt_table"

    date = pd.Timestamp("today").normalize() - BDay(1)

    try:
        p = IsrcPolicy(date=date.strftime("%Y-%m-%d"))

        resp = {
            table1: gen_isrc_table(p),
            table2: gen_isrc_table_2(p),
            table3: gen_isrc_tilt_table(p),
        }

    except Exception:
        try:
            date = date - BDay(1)
            p = IsrcPolicy(date=date.strftime("%Y-%m-%d"))

            resp = {
                table1: gen_isrc_table(p),
                table2: gen_isrc_table_2(p),
                table3: gen_isrc_tilt_table(p),
            }

        except Exception:
            resp = {
                table1: {"columns": [], "data": []},
                table2: {"columns": [], "data": []},
                table3: {"columns": [], "data": []},
            }

            request.vars["L"].info("DAA table creation has failed.")

    return resp


@app.route("/api/saa/sample_input_file", methods=["GET"])
async def saa_sample_input_file():
    L = request.vars["L"]
    L.info("saa sample")

    return await sample_input_file_callback()


@app.route("/api/saa/sample_returns_file", methods=["GET"])
async def saa_sample_returns_file():
    L = request.vars["L"]
    L.info("saa sample")

    return await sample_returns_file_callback()


@app.route("/api/saa/factset_indices_list", methods=["GET"])
async def saa_factset_indices_list():
    L = request.vars["L"]
    L.info("saa sample")

    return await factset_indices_list_callback()


@app.route("/api/saa/classifications", methods=["GET"])
async def saa_get_classifications():
    json = await rest_pb2_grpc.SAAStub(grpc_channels.get_channel("saa")).GetClassifications(
        request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
        metadata=request.vars["metadata_t"],
    )

    return json.str


@app.route("/api/saa/evaluate_constraints", methods=["GET"])
async def saa_evaluate_constraints():
    req = request.args.get("req")

    json = await rest_pb2_grpc.SAAStub(grpc_channels.get_channel("saa")).EvaluateConstraints(
        request=rest_pb2.JSON(str=req), metadata=request.vars["metadata_t"]
    )

    return json.str


@app.route("/api/saa/invokeapo", methods=["POST"])
async def invoke_APO():
    L = request.vars["L"]
    req_payload = await request.data
    L.info("Request payload: %s", req_payload)
    invokeAPORes = MessageToDict(
        await rest_pb2_grpc.SAAStub(grpc_channels.get_channel("saa")).InvokeAPO(
            request=rest_pb2.InvokeAPORequest(payload=rest_pb2.JSON(str=req_payload)),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(invokeAPORes["str"])
    if "status" in strVal and strVal["status"] == "error":
        return strVal, 500
    else:
        return strVal


@app.route("/api/saa/calculate_analytics", methods=["POST"])
async def calculate_analytics():
    L = request.vars["L"]
    req_payload = await request.data
    L.info("Request payload: %s", req_payload)
    calcAnalyticsRes = MessageToDict(
        await rest_pb2_grpc.SAAStub(grpc_channels.get_channel("saa")).CalculateAnalytics(
            request=rest_pb2.CalculateAnalyticsRequest(payload=rest_pb2.JSON(str=req_payload)),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(calcAnalyticsRes["str"])
    if "status" in strVal and strVal["status"] == "error":
        return strVal, 500
    else:
        return strVal
