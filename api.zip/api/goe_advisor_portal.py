import traceback
import json
import rest_pb2
import rest_pb2_grpc
from datetime import datetime

# import requests
import httpx

import uip_grpc
import uip_config

from quart import Blueprint, request, jsonify


from goeadvisorportal import common
from google.protobuf.json_format import MessageToDict, ParseDict
from google.protobuf.struct_pb2 import Struct


grpc_channels = uip_grpc.GRPC(async_mode=True)

goe_advisor_portal_app = Blueprint(
    "goe_advisor_portal",
    __name__,
)

cfg = uip_config.ConfigDict()


def handle_exception(func):
    async def wrapper(*args, **kwargs):
        res = await func(*args, **kwargs)
        if res.get("exc_type") == "ValidationError":
            raise common.ValidationError(message=res.get("message"), success=res.get("success", False))
        elif res.get("exc_type") == "Exception":
            raise Exception(res.get("message", ""))
        return res

    wrapper.__name__ = func.__name__
    return wrapper


@goe_advisor_portal_app.route("/api/advisorportal/adduser", methods=["POST"])
@handle_exception
async def goeap_add_user():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/advisorportal/adduser {request_json}")
    # res = await common.create_user(request_json, request.vars["metadata_d"], request.vars["metadata_t"])
    client_id = request_json.get("tenant", "")

    settings = request_json.get("settings", {})
    app_settings = {
        "hierarchy": {
            "manager_id": settings["hierarchy"].get("managerId", "")
            if "hierarchy" in settings and "managerId" in settings["hierarchy"]
            else "",
            "regional_office_id": settings["hierarchy"].get("regionalOfficeId", "")
            if "hierarchy" in settings and "regionalOfficeId" in settings["hierarchy"]
            else "",
        },
        "freemium": settings.get("freemium", False),
        "eulaVersion": settings.get("eulaVersion", ""),
    }
    time_stamp = str(datetime.utcnow())
    req = rest_pb2.AdvisorPortalUserRequest(
        first_name=request_json["firstName"],
        last_name=request_json.get("lastName", ""),
        email=request_json["email"],
        phone_number=request_json["phoneNumber"],
        role=request_json["role"],
        createdOn=time_stamp,
        client_id=client_id,
        settings=app_settings,
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).CreateUser(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/advisorportal/adduser {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/userexists", methods=["POST"])
@handle_exception
async def goeap_is_user_exists():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/userexist {request_json}")
    req = rest_pb2.UserExistsRequest(
        email=request_json["email"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).CheckUserExists(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/advisorportal/userexist {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/changeuserstatus", methods=["POST"])
@handle_exception
async def goeapi_change_user_status():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/changeuserstatus {request_json}")
    req = rest_pb2.ChangeUserStatusRequest(
        role=request_json["role"],
        client_id=request_json["clientId"],
        userId=request_json["userId"],
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).ChangeUserStatus(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/advisorportal/changeuserstatus {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updateuser", methods=["POST"])
@handle_exception
async def goeap_update_user():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/advisorportal/updateuser {request_json}")
    request_json = await request.json
    settings = request_json.get("settings", {})
    app_settings = {
        "hierarchy": {
            "manager_id": settings["hierarchy"].get("managerId", "")
            if "hierarchy" in settings and "managerId" in settings["hierarchy"]
            else "",
            "regional_office_id": settings["hierarchy"].get("regionalOfficeId", "")
            if "hierarchy" in settings and "regionalOfficeId" in settings["hierarchy"]
            else "",
        },
        "freemium": settings.get("freemium", False),
        "eulaVersion": settings.get("eulaVersion", ""),
    }

    req = rest_pb2.AdvisorPortalUserRequest(
        role=request_json["role"],
        doc_id=request_json["id"],
        client_id=request_json.get("tenant", ""),
        phone_number=request_json["phoneNumber"],
        createdOn=request_json["createdOn"],
        settings=app_settings,
    )
    # res = await common.update_user(request_json, request.vars["metadata_d"], request.vars["metadata_t"])
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).UpdateUser(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/advisorportal/updateuser {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updateeula", methods=["POST"])
@handle_exception
async def goeap_update_eula_version():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/advisorportal/updateeula {request_json}")
    request_json = await request.json

    req = rest_pb2.AdvisorPortalEulaVerRequest(
        role=request_json["role"],
        doc_id=request_json["id"],
        client_id=request_json.get("tenant", ""),
        eula_version=request_json["eulaVersion"],
        userAgreementVersion=request_json["userAgreementVersion"],
        isEulaVersion=request_json["isEulaVersion"],
        isUserAgreementVersion=request_json["isUserAgreementVersion"],
    )
    # res = await common.update_user(request_json, request.vars["metadata_d"], request.vars["metadata_t"])
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).UpdateEula(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/advisorportal/updateeula {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/deleteuser", methods=["POST"])
@handle_exception
async def goeap_delete_user():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/deleteuser {request_json}")
    request_json = await request.json
    req = rest_pb2.DeleteAdvisorPortalUserRequest(doc_id=request_json.get("id"), client_id=request_json.get("tenant"))
    # res = await common.delete_user(request_json, request.vars["metadata_d"], request.vars["metadata_t"])
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).DeleteUser(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Respone /api/advisorportal/deleteuser {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/getusers", methods=["POST"])
@handle_exception
async def goeap_getusers():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/getusers {request_json}")
    request_json = await request.json
    req = rest_pb2.GetAdvisorPortalUsers(
        doc_ids=request_json.get("ids") if request_json else [],
        emails=request_json.get("emails") if request_json else [],
        noCache=request_json.get("noCache", False),
    )
    # res = await common.get_users(request_json, request.vars["metadata_d"], request.vars["metadata_t"])
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).GetUsers(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Respone /api/advisorportal/getusers {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/addclient", methods=["POST"])
@handle_exception
async def goeap_create_end_user():
    """Add client/enduser(in context of uip)

    Returns:
        dict: res
    """
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/addclient {request_json}")
    external_data = request_json.get("externalData", {})
    if "data" in external_data:
        struc_obj = Struct()
        struc_obj.update(external_data["data"])
        external_data["data"] = struc_obj
    else:
        external_data["data"] = Struct()
    req = rest_pb2.AdvisorEndUserRequest(
        firstName=request_json["firstName"],
        lastName=request_json.get("lastName", ""),
        email=request_json["email"],
        dob=request_json["dob"],
        user_id=request_json.get("userId", ""),
        riskTolerance=request_json.get("riskTolerance", None),
        externalData=external_data,
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AddAdvisorEndUser(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/addclient {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updateclient", methods=["POST"])
@handle_exception
async def goeap_update_end_user():
    """update client/enduser(in context of uip)

    Returns:
        dict: res
    """
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/updateclient {request_json}")
    request_json = await request.json
    external_data = request_json.get("externalData", {})
    if "data" in external_data:
        struc_obj = Struct()
        struc_obj.update(external_data["data"])
        external_data["data"] = struc_obj
    else:
        external_data["data"] = Struct()
    req = rest_pb2.AdvisorEndUserRequest(
        doc_id=request_json["id"],
        firstName=request_json["firstName"],
        lastName=request_json.get("lastName", ""),
        email=request_json["email"],
        dob=request_json["dob"],
        user_id=request_json["userId"],
        riskTolerance=request_json.get("riskTolerance", None),
        externalData=external_data,
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).UpdateAdvisorEndUser(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/updateclient {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/associateclientgoalstofa", methods=["POST"])
@handle_exception
async def goeap_update_advisor_to_client():
    """update client/enduser(in context of uip)

    Returns:
        dict: res
    """
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/associateclienttofa {request_json}")
    request_json = await request.json

    req = rest_pb2.AssociateClienttoFARequest(clientId=request_json["clientId"], userId=request_json["userId"])
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AssociateClienttoFA(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/associateclientgoalstofa {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/deleteclient/<doc_id>", methods=["DELETE"])
@handle_exception
async def goeap_delete_end_user(doc_id):
    """Delete client/end user(in context of uip)

    Args:
        doc_id (str): doc id of client/enduser

    Returns:
        dict: res
    """
    L = request.vars["L"]
    L.info(f"POST /api/advisorportal/deleteclient {doc_id}")
    req = rest_pb2.DeleteEndUserRequest(doc_id=doc_id)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).DeleteAdvisorEndUsers(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/deleteclient {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/actionsaudit", methods=["POST"])
async def goeap_actions_audit():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/advisorportal/actionsaudit {request_json}")
    req = rest_pb2.ActionsAuditRequest(
        action=request_json.get("action"),
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(
            grpc_channels.get_channel("goe-advisor-portal")
        ).AdvisorPortalActionsAudit(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/actionsaudit {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/getclients", methods=["GET"])
@handle_exception
async def goeap_get_end_users():
    """Get all clients/endusers(in context of uip clients are considered as endusers.)

    Returns:
        dict: res
    """
    L = request.vars["L"]
    # params = {}
    client_id = ""
    email = ""
    if request.args.get("id"):
        # params = json.loads(request.args.get("req"))
        client_id = request.args.get("id")
    if request.args.get("email"):
        # params = json.loads(request.args.get("req"))
        email = request.args.get("email")

    L.info(f"POST /api/advisorportal/getclients {request.args}")
    req = rest_pb2.EndUserRequest(id=client_id, email=email)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).GetAdvisorEndUsers(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/getclients {res}")
    return res


async def goe_api_response(request_json, url):
    max_retries = 3
    retry = 0
    while retry < max_retries:
        L = request.vars["L"]
        if "clientemail" not in request.headers:
            L.info("clientemail is mandatory in headers.")
            raise common.ValidationError(message="clientemail is mandatory in headers.", success=False)
        client_email = request.headers["clientemail"]
        version = request.headers.get("version")
        token = MessageToDict(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).SignInExternalApp(
                request=rest_pb2.SignInExternalAppRequest(name="goe"),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )["AuthenticationResult"]["AccessToken"]
        if version:
            headers = {
                "clientemail": client_email,
                "Content-Type": "application/json",
                "version": "4",
                "Authorization": token,
            }
        else:
            headers = {
                "clientemail": client_email,
                "Content-Type": "application/json",
                "Authorization": token,
            }
        req = request_json
        if not req:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, headers=headers)
        else:
            payload = json.dumps(req)
            async with httpx.AsyncClient() as client:
                response = await client.post(url, headers=headers, data=payload, timeout=600)
        res = json.loads(response.text)
        if "name" in res and "TokenExpiredError" in res["name"]:
            L.error(f"Token Expired Retrying new token. {res}")
            token = MessageToDict(
                await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).SignInExternalApp(
                    request=rest_pb2.SignInExternalAppRequest(
                        name="goe",
                        refresh=True,
                    ),
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )["AuthenticationResult"]["AccessToken"]
            L.info("Retrying api")
            retry += 1
            continue

        L.info(f"Got Resp {res}")
        return res


@goe_advisor_portal_app.route("/api/advisorportal/runpipe", methods=["POST"])
@handle_exception
async def goeap_runpipe():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/runpipe {request_json}")
    url = cfg["goe_advisor_portal"]["run_pipe_url"]  # 'https://api.uip.frk.com/v3/runPipe'
    res = await goe_api_response(request_json, url)
    L.info(f"Response /api/advisorportal/runpipe {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/iws", methods=["POST"])
@handle_exception
async def goeap_iws():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/iws {request_json}")

    url = cfg["goe_advisor_portal"]["iws_url"]  # 'https://api.uip.frk.com/v3/runWealthSplitter'
    # client_email = "FTT_WM_PIPEDemo@franklintempleton.com"
    # version = True
    res = await goe_api_response(request_json, url)
    L.info(f"Response /api/advisorportal/runpipe {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/getproposal", methods=["GET"])
@handle_exception
async def goeap_read_goal_info():
    L = request.vars["L"]
    L.info("GET /api/advisorportal/getproposal")
    req = rest_pb2.GetEndUserGoalRequest()
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).GetEndUserGoals(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/advisorportal/getproposal {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/saveproposal", methods=["POST"])
@handle_exception
async def goeap_create_goal():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/saveproposal {request_json}")

    form_filed_list = []
    requests_list = []
    response_list = []

    for form_field, request_data, response_data in zip(
        request_json["formFields"], request_json["request"], request_json["response"]
    ):
        form_filed_list.append(ParseDict(form_field, Struct()))
        requests_list.append(ParseDict(request_data, Struct()))
        response_list.append(ParseDict(response_data, Struct()))

    req = rest_pb2.EndUserGoalRequest(
        api_ver=request_json["apiVer"],
        api_name=request_json["apiName"],
        is_multi_goal=request_json["isMultiGoal"],
        iws_applied=request_json["iwsApplied"],
        form_fields=form_filed_list,
        request=requests_list,
        response=response_list,
        domain_email=request_json["domainEmail"],
        # client_email=request_json["clientEmail"],
        end_user_id=request_json["assignedClientId"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AddEndUserGoal(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/saveproposal {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updateproposal", methods=["POST"])
@handle_exception
async def goeap_update_goal():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/updateproposal {request_json}")

    form_filed_list = []
    requests_list = []
    response_list = []

    for form_field, request_data, response_data in zip(
        request_json["formFields"], request_json["request"], request_json["response"]
    ):
        form_filed_list.append(ParseDict(form_field, Struct()))
        requests_list.append(ParseDict(request_data, Struct()))
        response_list.append(ParseDict(response_data, Struct()))

    req = rest_pb2.EndUserGoalRequest(
        api_ver=request_json["apiVer"],
        api_name=request_json["apiName"],
        is_multi_goal=request_json["isMultiGoal"],
        iws_applied=request_json["iwsApplied"],
        form_fields=form_filed_list,
        request=requests_list,
        response=response_list,
        domain_email=request_json["domainEmail"],
        # client_email=request_json["clientEmail"],
        end_user_id=request_json["assignedClientId"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).UpdateEndUserGoal(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/updateproposal {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/deleteproposal/<doc_id>", methods=["DELETE"])
@handle_exception
async def goeap_delete_goal(doc_id):
    L = request.vars["L"]
    L.info(f"POST /api/advisorportal/deleteproposal {doc_id}")
    req = rest_pb2.DeleteEndUserGoalRequest(doc_id=doc_id)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).DeleteEndUserGoals(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/deleteproposal {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/addorganizationconfig", methods=["POST"])
@handle_exception
async def goeap_add_org_config_info():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/addorganizationconfig {request_json}")
    request_json = await request.json
    orgInfo = Struct()
    req = rest_pb2.AddUpdOrganizationConfigRequest(
        tenantId=request_json["tenantId"],
        orgInfo=orgInfo.update(request_json["orgInfo"]),
        action="ADD",
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(
            grpc_channels.get_channel("goe-advisor-portal")
        ).AddUpdOrganizationConfig(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/addorganizationconfig {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updateorganizationconfig", methods=["POST"])
@handle_exception
async def goeap_update_org_config_info():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/updateorganizationconfig {request_json}")
    request_json = await request.json
    org_info = Struct()
    org_info.update(request_json["orgInfo"])
    req = rest_pb2.AddUpdOrganizationConfigRequest(tenantId=request_json["tenantId"], orgInfo=org_info, action="UPDATE")
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(
            grpc_channels.get_channel("goe-advisor-portal")
        ).AddUpdOrganizationConfig(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/updateorganizationconfig {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/getorganizationconfig", methods=["GET"])
@handle_exception
async def goeap_get_org_config():
    L = request.vars["L"]
    tenant = request.args.get("tenant")
    L.info(f"GET /api/advisorportal/getorganizationconfig params: {tenant}")
    req = rest_pb2.GetOrganizationConfigRequest(tenantId=tenant)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).GetOrganizationConfig(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/getorganizationconfig {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/deleteorganizationconfig/<doc_id>", methods=["DELETE"])
@handle_exception
async def goeap_delete_org_config(doc_id):
    L = request.vars["L"]

    L.info(f"DELETE /api/advisorportal/deleteorganizationconfig doc_id: {doc_id}")
    req = rest_pb2.DeleteOrganizationRequest(doc_id=doc_id)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(
            grpc_channels.get_channel("goe-advisor-portal")
        ).DeleteOrganizationConfig(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/deleteorganizationconfig {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/addtenantinfo", methods=["POST"])
@handle_exception
async def goeap_add_tenant_info():
    L = request.vars["L"]
    request_json = await request.json
    disclaimers = Struct()
    disclaimers.update(request_json["disclaimers"])
    styles = Struct()
    styles.update(request_json["disclaimers"])
    L.info(f"POST /api/advisorportal/addtenantinfo {request_json}")
    request_json = await request.json
    req = rest_pb2.AddUpdTenantInfoRequest(
        subdomain=request_json["subdomain"],
        disclaimers=disclaimers,
        favicon=request_json["favicon"],
        logo=request_json["logo"],
        styles=styles,
        action="ADD",
        language=request_json.get("language", ["en"]),
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AddUpdTenantInfo(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/addtenantinfo {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/deletetenantinfo/<doc_id>", methods=["DELETE"])
@handle_exception
async def goeap_delete_tenant_info(doc_id):
    L = request.vars["L"]

    L.info(f"DELETE /api/advisorportal/deltenantinfo doc_id: {doc_id}")
    req = rest_pb2.DelTenantInfoRequest(doc_id=doc_id)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).DelTenantInfo(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/deltenantinfo {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updatetenantinfo", methods=["POST"])
@handle_exception
async def goeap_update_tenant_info():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/updatetenantinfo {request_json}")
    disclaimers = Struct()
    disclaimers.update(request_json["disclaimers"])
    styles = Struct()
    styles.update(request_json["styles"])
    request_json = await request.json
    req = rest_pb2.AddUpdTenantInfoRequest(
        subdomain=request_json["subdomain"],
        disclaimers=disclaimers,
        favicon=request_json["favicon"],
        logo=request_json["logo"],
        styles=styles,
        action="UPDATE",
        language=request_json.get("language", ["en"]),
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AddUpdTenantInfo(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/updatetenantinfo {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/gettenantinfo", methods=["GET"])
@handle_exception
async def goeap_get_tenant_info():
    L = request.vars["L"]
    params = {}
    if request.args.get("subdomain"):
        params = request.args.get("subdomain")
    L.info(f"POST /api/advisorportal/gettenantinfo {params}")
    req = rest_pb2.GetTenantInfoRequest(subdomain=params)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).GetTenantInfo(
            request=req,
            # metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/gettenantinfo {res}")
    return res


@goe_advisor_portal_app.errorhandler(common.AdvisorPortalException)
async def handle_advisor_portal_error(e):
    """Return json error for AdvisorPortalException errors defined .
    This will avoid having to try/catch Errors in all endpoints, returning
    correct JSON response with associated HTTP Status Code
    """
    L = request.vars["L"]
    L.info("Advisor portal api failed")
    data = {"message": e.message, "name": e.name, "statusCode": e.error_code}
    return jsonify(data), e.error_code


@goe_advisor_portal_app.errorhandler(Exception)
async def handle_error(exception):
    """Return json error for errors not handled in handle_advisor_portal_error fn.
    This will avoid having to try/catch Errors in all endpoints, returning
    correct JSON response with associated HTTP 500 Status
    """
    L = request.vars["L"]
    L.error(exception)
    L.error(traceback.format_exc())
    if "Permission Denied" in str(exception):
        msg = jsonify({"message": str(exception), "statusCode": 403, "name": "UnAuthorized"})
        return msg, 403
    msg = jsonify({"message": str(exception), "statusCode": 500, "name": "InternalError"})
    return msg, 500


@goe_advisor_portal_app.route("/api/advisorportal/saveportfolio", methods=["POST"])
@handle_exception
async def goeap_save_market_portfolio():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"Request /api/advisorportal/saveportfolio {request_json}")

    port_struc_obj = Struct()
    port_struc_obj.update(request_json["portfolioData"])

    # request_json["portfolio_data"]
    req = rest_pb2.PortfolioRequest(
        org_email=request_json["orgEmail"],
        country=request_json["country"],
        portfolio_data=port_struc_obj,
        client_id=request_json["tenant"],
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).SaveMarketPortfolio(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/saveportfolio {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updateportfolio", methods=["POST"])
@handle_exception
async def goeap_update_market_portfolio():
    L = request.vars["L"]

    request_json = await request.json

    port_struc_obj = Struct()
    port_struc_obj.update(request_json["portfolioData"])

    # request_json["portfolio_data"]
    req = rest_pb2.PortfolioRequest(
        doc_id=request_json.get("doc_id", ""),
        org_email=request_json["orgEmail"],
        country=request_json["country"],
        portfolio_data=port_struc_obj,
        client_id=request_json["tenant"],
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).UpdateMarketPortfolio(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/updateportfolio {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/marketportfolios", methods=["GET"])
@handle_exception
async def goeap_get_market_portfolio():
    L = request.vars["L"]
    L.info("GET /api/advisorportal/marketportfolios {request.args}")
    params = {}
    if request.args.get("req"):
        params = json.loads(request.args.get("req"))
    L.info(f"GET /api/advisorportal/marketportfolios {params}")
    req = rest_pb2.GetPortfolioRequest(ids=params.get("ids"))
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).GetMarketPortfolios(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    if "end_users" in res:
        res["market_portfolio_list"] = res["end_users"]
        del res["end_users"]
    L.info(f"Respone /api/advisorportal/marketportfolios {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/deleteportfolio/<doc_id>", methods=["DELETE"])
@handle_exception
async def goeap_delete_marketportfolio(doc_id):
    L = request.vars["L"]
    L.info(f"POST /api/advisorportal/deleteportfolio {doc_id}")
    req = rest_pb2.DeleteEndUserGoalRequest(doc_id=doc_id)
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).DeleteMarketPortfolio(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/deleteportfolio {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/loginuserinfo", methods=["GET"])
@handle_exception
async def goeap_test_api():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/advisorportal/loginuserinfo {request_json}")
    req = rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(
            grpc_channels.get_channel("goe-advisor-portal")
        ).AdvisorPortalLoginUserInfo(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    return res


@goe_advisor_portal_app.route("/api/advisorportal/metrics", methods=["GET"])
@handle_exception
async def goeap_metrics():
    L = request.vars["L"]
    L.info("GET /api/advisorportal/metrics")
    pastndays = 0
    if request.args.get("pastndays", "").isnumeric():
        pastndays = int(request.args.get("pastndays"))
        if pastndays <= 0:
            raise common.ValidationError(message="pastndays should be greater than 0.")
    req = rest_pb2.MetricsRequest(pastndays=int(pastndays))
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).Metrics(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    if "end_users" in res:
        res["market_portfolio_list"] = res["end_users"]
        del res["end_users"]
    L.info(f"Respone /api/advisorportal/metrics {res}")
    return res


# @goe_advisor_portal_app.route("/api/advisorportal/updateclientid", methods=["POST"])
# @handle_exception
# async def goeap_delete_client_id():
#     L = request.vars["L"]
#     request_json = await request.json
#     L.info(f"POST /api/advisorportal/updateclientid {request_json}")
#     request_json = await request.json
#     req = rest_pb2.TenantRequest(doc_id=request_json.get("id"), client_id=request_json.get("tenant"))
#     res = MessageToDict(
#         await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AddOrUpdateClientId(
#             request=req,
#             metadata=request.vars["metadata_t"],
#         ),
#         preserving_proto_field_name=True,
#     )
#     L.info(f"Respone /api/advisorportal/updateclientid {res}")
#     return res


# # @goe_advisor_portal_app.route("/api/advisorportal/deleteclientid", methods=["POST"])
# @handle_exception
# async def goeap_update_client_id():
#     L = request.vars["L"]
#     request_json = await request.json
#     L.info(f"POST /api/advisorportal/deleteclientid {request_json}")
#     request_json = await request.json
#     req = rest_pb2.TenantRequest(doc_id=request_json.get("id"), client_id=request_json.get("clientId"))
#     res = MessageToDict(
#         await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AddOrUpdateClientId(
#             request=req,
#             metadata=request.vars["metadata_t"],
#         ),
#         preserving_proto_field_name=True,
#     )
#     L.info(f"Respone /api/advisorportal/deleteclientid {res}")
#     return res


# @goe_advisor_portal_app.route("/api/advisorportal/getclientid", methods=["POST"])
# @handle_exception
# async def goeap_get_client_id():
#     L = request.vars["L"]
#     L.info(f"POST /api/advisorportal/getclientid {request.args}")
#     pass


@goe_advisor_portal_app.route("/api/advisorportal/documenthistory", methods=["GET"])
@handle_exception
async def goeap_get_document_history():
    L = request.vars["L"]
    L.info("GET /api/advisorportal/documenthistory {request.args}")
    req = rest_pb2.AdvisiorPortalHistoryRequest(collection_name=request.args.get("collection_name"))

    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(
            grpc_channels.get_channel("goe-advisor-portal")
        ).GetAdvrPortalDocumentHistory(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/documenthistory {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/updatebanner", methods=["POST"])
@handle_exception
async def goeap_add_banner_data():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/addclient {request_json}")

    req = rest_pb2.AddBannerDataRequest(
        bannerStartTime=request_json["bannerStartTime"],
        bannerEndTime=request_json["bannerEndTime"],
        bannerMessage=request_json["bannerMessage"],
        bannerStatus=request_json["bannerStatus"],
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).AddBannerData(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/advisorportal/addclient {res}")
    return res


@goe_advisor_portal_app.route("/api/advisorportal/getbanner", methods=["GET"])
@handle_exception
async def goeap_get_banner_data():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/advisorportal/loginuserinfo {request_json}")
    req = rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(grpc_channels.get_channel("goe-advisor-portal")).GetBannerData(
            request=req,
        ),
        preserving_proto_field_name=True,
    )
    return res
