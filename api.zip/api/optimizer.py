import uip_grpc
import rest_pb2
import rest_pb2_grpc
from google.protobuf.json_format import MessageToDict
from quart import request

from quart.blueprints import Blueprint

app = Blueprint("optimizer", __name__)

svc_client = uip_grpc.ServiceClient()
grpc_channels = uip_grpc.GRPC(async_mode=True)


@app.route("/api/optimizer/accounts", methods=["GET"])
async def list_accounts():
    return MessageToDict(
        await rest_pb2_grpc.PConStub(grpc_channels.get_channel("pcon")).GetAccounts(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/optimizer/status/<date>", methods=["GET"])
async def get_status(date):
    return MessageToDict(
        await rest_pb2_grpc.PConStub(grpc_channels.get_channel("pcon")).GetStatus(
            request=rest_pb2.PConStatusInput(date=date),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/optimizer/generate_reports", methods=["POST"])
async def generate_reports():
    request_json = await request.json

    if "account_id" not in request_json:
        return {"success": False, "error": "Input should contain account_id"}
    if "date" not in request_json:
        return {"success": False, "error": "Input should contain date"}
    if "wsp_files" not in request_json:
        return {"success": False, "error": "Input should contain wsp_files"}

    account_id = request_json["account_id"]
    date = request_json["date"]
    wsp_files = request_json["wsp_files"]

    resp = await svc_client.call_queue_based_service(
        "optimizer",
        "GenerateSummaryReport",
        {"account_id": account_id, "date": date, "wsp_files": wsp_files},
        metadata=request.vars["metadata_t"],
    )

    # pass through response
    return resp

@app.route("/api/optimizer/run/<job>", methods=["POST"])
async def run_optimization(job):
    return MessageToDict(
        await rest_pb2_grpc.PConStub(grpc_channels.get_channel("pcon")).RunOptimization(
            request=rest_pb2.RunOptInput(job=job),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


 