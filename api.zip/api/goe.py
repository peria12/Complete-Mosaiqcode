"""
    Goe apis entry point is defined here.
    for external urls which will be defined from now
    will use this prefix /api/goe-api
"""
import json
import uuid
import rest_pb2
import uip_grpc
import uip_dbs_async

from google.protobuf.json_format import MessageToJson


from goelib.errors import ValidationError, RecordDoesNotExist

from goelib.api.resources.pipeserverless import (
    pipe_serverless_controller_run_pipe_version3,
    pipe_controller_run_wealth_splitter,
    # pipe_serverless_controller_run_advisor_engine,
    # pipe_serverless_controller_run_advisor_engine_v2,
    pipe_serverless_controller_run_advisor_engine_v4,
    # pipe_serverless_controller_historical_live_scenarios,
    # pipe_serverless_historical_live_scenarios_get_status,
    # hantz_translator_api,
    # replacement_income_calculator_api,
    # goe_run_pipe_taxes,
    # goe_goal_simulation_engine_payload,
    # social_security_calculator_api,
    goe_decumulation_api,
    # fixed_discretionary_calculator_api,
    goal_calculator_api,
)
from goelib.api.shared.common import DictDefault
from goelib.api.resources.api_wrapper import GoalDiscovery
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from fastapi import APIRouter, Request, Response
from fastapi import Depends, status
from uip_access import AccessControl
from fastapi import Header
from fastapi import HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from goelib.api.shared.case_conversion import convertToCamelCase

# from fastapi import FastAPI, File, UploadFile
from goe_schema import (
    Message,
    ValidationMessage,
    ValidationMessageOne,
    InternalServerMessage,
)
import goelib.goe_schema.runpipe
import goelib.goe_schema.upa
import goelib.goe_schema.iws
import goelib.goe_schema.goe_decumulation
import goelib.goe_schema.goe_calculator
import goelib.goe_schema.goal_discovery
from fastapi.encoders import jsonable_encoder
from typing import Callable
from goelib import DbAccess
import sqlalchemy as sa
from goelib.api.shared.common import get_meta_data_for_tables
from sqlalchemy import select, and_, func, between


class GoeDataResults:
    @staticmethod
    async def Create():
        w = GoeDataResults()
        w.cache = (await uip_dbs_async.Db.Create("cache")).conn

        return w

    async def save_results(self, data, size):
        identifier = ("goe", uuid.uuid4().hex)
        start = 0
        expire = 1000
        chunk_ids = []
        iter_count = 0
        while start < len(data):
            iter_count += 1
            chunk_data = data[start : start + size]
            start = start + size
            chunk_id = ("goe", uuid.uuid4().hex)
            chunk_ids.append(chunk_id)
            await self.cache.set_value(chunk_id, chunk_data, expiry=expire)
        await self.cache.set_value(
            identifier,
            {"chunk_ids": chunk_ids, "total_records": len(data), "total_pages": iter_count, "per_page": size},
            expiry=expire,
        )
        return identifier[1]

    async def get_results(self, identifier, slice_number):
        if not isinstance(slice_number, int) or slice_number <= 0:
            ValidationError.messages = "slice_number must be int and must be greater than equal to 1."
            raise ValidationError

        identifier = ("goe", identifier)
        data = await self.cache.get_value(identifier)
        if data:
            chunk_ids = data.get("chunk_ids", [])
            total_records = data.get("total_records", 0)
            total_pages = data.get("total_pages", 0)
            per_page = data.get("per_page", 0)
            if not chunk_ids:
                return {"data": [], "total_records": total_records, "total_pages": total_pages}
            if len(chunk_ids) > slice_number - 1:
                chunk_id = chunk_ids[slice_number - 1]
                return {
                    "data": await self.cache.get_value(chunk_id),
                    "total_records": total_records,
                    "total_pages": total_pages,
                    "per_page": per_page,
                }
            else:
                return {"data": [], "total_records": total_records, "total_pages": total_pages}
        RecordDoesNotExist.messages = "requestId doesnot exist."
        raise RecordDoesNotExist


class GoeAPIRequest(Request):
    async def body(self) -> bytes:
        if not hasattr(self, "_body"):
            body = await super().body()
            self._body = body
        return self._body


class ContextIncludedRoute(APIRoute):
    async def body(self) -> bytes:
        if not hasattr(self, "_body"):
            body = await super().body()
            self._body = body
        return self._body

    def get_route_handler(self) -> Callable:
        original_route_handler = super().get_route_handler()

        async def custom_route_handler(request: Request) -> Response:
            request.vars = request.state.vars
            request = GoeAPIRequest(request.scope, request.receive)
            response: Response = await original_route_handler(request)
            return response

        return custom_route_handler


router = APIRouter(route_class=ContextIncludedRoute)

grpc_channels = uip_grpc.GRPC(async_mode=True)

svc_client = uip_grpc.ServiceClient()

from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi import Depends, FastAPI, HTTPException, status
from typing import Annotated
from pydantic import BaseModel


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: str | None = None


def authenticate_user(fake_db, username: str, password: str):
    return True


from datetime import datetime, timedelta
from jose import JWTError, jwt

fake_users_db = {}
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# def create_access_token(data: dict, expires_delta: timedelta | None = None):
#     to_encode = data.copy()
#     if expires_delta:
#         expire = datetime.utcnow() + expires_delta
#     else:
#         expire = datetime.utcnow() + timedelta(minutes=15)
#     to_encode.update({"exp": expire})
#     encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
#     return encoded_jwt


class JWTBearer(HTTPBearer):
    def __init__(self, auto_error: bool = False):
        super(JWTBearer, self).__init__(auto_error=auto_error)


async def check_user_is_avc(request: Request):
    roles = (
        ("goe", "client-settings", "admin"),
        ("goe", "client-settings", "view"),
        ("goe", "client-settings", "client"),
    )
    ac = await AccessControl.Create()
    user_id = request.state.vars["metadata_d"]["user-id"]
    ok, msg = await ac.request_access(user_id, roles, False)
    if not ok:
        raise HTTPException(status_code=403, detail="Access denied:" + msg)


@router.post(
    "/v3/RUNPIPE", status_code=status.HTTP_200_OK, dependencies=[Depends(check_user_is_avc)], include_in_schema=False
)
@router.post(
    "/v3/runpipe", status_code=status.HTTP_200_OK, dependencies=[Depends(check_user_is_avc)], include_in_schema=False
)
@router.post(
    "/v3/runPipe",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc), Depends(JWTBearer())],
    response_model=goelib.goe_schema.runpipe.RunPipeResponseModelV4,
    responses={
        200: goelib.goe_schema.runpipe.runpipe_response_model_v4,
        404: {"model": Message},
        400: {"model": ValidationMessageOne},
        500: {"model": InternalServerMessage},
    },
    name="run pipe",
    tags=["GOE"],
)
async def svc_run_pipe_v3(
    request: Request,
    json_request: goelib.goe_schema.runpipe.RunPipeInputModel,
    # clientemail: str = Header(None),
    # generatepayloadonly: str = Header(None),
    # debug: str = Header(None),
    version: str = Header(None),
):
    L = request.state.vars["L"]
    L.info("control is here")
    request.vars = request.state.vars
    request_json = json_request
    # request_json = await request.json
    L.info(f"POST /v3/runPipe {request_json}")
    L.info("User is accessing app in UI: GOE API:/v3/runPipe")
    req = {}
    req["headers"] = request.headers
    req["remote_addr"] = request.client.host
    req["request_meta_data"] = request.state.vars["metadata_t"]
    req["requester_oid"] = request.state.vars["metadata_d"]["user-id"]
    result = await pipe_serverless_controller_run_pipe_version3(req, request_json, request)
    if isinstance(result, tuple):
        pipePayload, handler = result
    else:
        pipePayload = result
    pipePayload = DictDefault(pipePayload)
    if pipePayload.statusCode in [400, 200]:
        json_payload = json.dumps(pipePayload)
        data = JSONResponse(pipePayload, status_code=pipePayload.statusCode)
        # data = await make_response(json_payload)
        # data.headers.set("Content-Type", "application/json")
        L.info(f"RESPONSE PAYLOAD POST /v3/runPipe {json_payload}")
        return data
    # if payload has no statuscode it means generatePipePayload is False and proceed further for next steps
    # return json.dumps(pipePayload), 200
    elif pipePayload.statusCode is None:
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "CoreGOE",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        res, status_code = handler(goe_response)
        L.info(f"RESPONSE POST /v3/runPipe {res}")
        json_compatible_item_data = jsonable_encoder(res)
        if "statusCode" in json_compatible_item_data:
            json_compatible_item_data["statusCode"] = int(json_compatible_item_data["statusCode"])
        return JSONResponse(content=json_compatible_item_data, status_code=int(status_code))


@router.post(
    "/v4/unifiedPortfolioAdvice",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc)],
    include_in_schema=False,
)
@router.post(
    "/v4/unifiedportfolioadvice",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc), Depends(JWTBearer())],
    response_model=goelib.goe_schema.upa.UnifiedPortfolioAdviceInputModelV4,
    responses={
        200: goelib.goe_schema.upa.upav4_response_model,
        404: {"model": Message},
        400: {"model": ValidationMessageOne},
        500: {"model": InternalServerMessage},
    },
    name="unified portfolio advice - v4",
    tags=["GOE"],
)
async def goe_unified_portfolio_advice_v4(
    request: Request,
    json_request: goelib.goe_schema.upa.UnifiedPortfolioAdviceInputModelV4,
    detailedResponse: str = Header(None),
):
    L = request.state.vars["L"]

    L.info("control is here")
    request.vars = request.state.vars
    request_json = json_request
    L.info(f"POST /v4/unifiedportfolioadvice {request_json}")
    L.info("User is accessing app in UI: GOE API:/v4/unifiedportfolioadvice")
    req = {}
    req["remote_addr"] = request.client.host
    req["headers"] = request.headers
    req["request_meta_data"] = request.state.vars["metadata_t"]
    req["requester_oid"] = request.state.vars["metadata_d"]["user-id"]
    result = await pipe_serverless_controller_run_advisor_engine_v4(request, req, request_json)
    if isinstance(result, tuple):
        pipePayload, handler = result
    else:
        pipePayload = result
    pipePayload = DictDefault(pipePayload)
    if pipePayload.statusCode in [400, 200]:
        json_data = json.dumps(pipePayload)
        L.info(f"RESPONSE ERROR POST /v4/unifiedPortfolioAdvice {json_data}")
        data = JSONResponse(pipePayload, status_code=pipePayload.statusCode)
        return data
    elif pipePayload and pipePayload.statusCode is None:
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "UnifiedPortfolioAdvice4",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        if request.headers.get("version") == "4":
            # Delete 'Wealth Node Prob' from response specific to version 4 of UPA 2 api
            new_goe_reponse = json.loads(goe_response)
            if new_goe_reponse.get("statusCode") != 200:
                res = handler(goe_response)
                L.info(f"RESPONSE ERROR POST /v4/unifiedPortfolioAdvice {pipePayload}")
                return JSONResponse(res, status_code=new_goe_reponse.get("statusCode"))
            new_goe_reponse["data"] = json.loads(new_goe_reponse["data"])
            if "Wealth Node Prob" in new_goe_reponse["data"]["path_report_mod"]:
                del new_goe_reponse["data"]["path_report_mod"]["Wealth Node Prob"]
            if "Wealth Node Prob" in new_goe_reponse["data"]["path_report"]:
                del new_goe_reponse["data"]["path_report"]["Wealth Node Prob"]
            new_goe_reponse["data"] = json.dumps(new_goe_reponse["data"])
            goe_response = json.dumps(new_goe_reponse)
        res, status_code = handler(goe_response)
        L.info(f"RESPONSE POST /v4/unifiedPortfolioAdvice {res}")
        return JSONResponse(res, status_code=int(status_code))
    else:
        L.info(f"RESPONSE ERROR POST /v4/unifiedPortfolioAdvice {pipePayload}")
        return JSONResponse(pipePayload, int(pipePayload.statusCode))


@router.post(
    "/v3/RUNWEALTHSPLITTER",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc)],
    include_in_schema=False,
)
@router.post(
    "/v3/runwealthsplitter",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc)],
    include_in_schema=False,
)
@router.post(
    "/v3/runWealthSplitter",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc), Depends(JWTBearer())],
    response_model=goelib.goe_schema.iws.WealthSplitterOutputModel,
    responses={
        200: goelib.goe_schema.iws.iws_response_model_v4,
        404: {"model": Message},
        400: {"model": ValidationMessageOne},
        500: {"model": InternalServerMessage},
    },
    name="Initial Wealth Splitter",
    tags=["GOE"],
)
async def svc_goe_initial_wealth_splitter(
    request: Request,
    json_request: goelib.goe_schema.iws.WealthSplitterInputModel,
):
    L = request.state.vars["L"]

    request_json = json_request
    L.info(f"POST /v3/runWealthSplitter {request_json}")
    L.info("User is accessing app in UI: GOE API:/v3/runWealthSplitter")
    req = {}
    req["headers"] = request.headers
    req["remote_addr"] = request.client.host
    req["request_meta_data"] = request.state.vars["metadata_t"]
    req["requester_oid"] = request.state.vars["metadata_d"]["user-id"]
    result = await pipe_controller_run_wealth_splitter(request, req, request_json)
    if isinstance(result, tuple):  # tuple returned incase of request need to passed to goe algo
        pipe_result, handler = result
    else:
        pipe_result = result
    pipe_result = DictDefault(pipe_result)
    if pipe_result.statusCode in [200, 400]:
        json_data = json.dumps(pipe_result)
        data = JSONResponse(pipe_result, status_code=int(pipe_result.statusCode))
        # data.headers.set("Content-Type", "application/json")
        L.info(f"RESPONSE PAYLOAD POST /v3/runWealthSplitter {json_data}")
        return data
    elif pipe_result.get("statusCode") is None:  # If status is None then request need to submit to goealgo api.
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "InitialWealthSplitter",
                rest_pb2.GOERequest(request=json.dumps(pipe_result)),
                metadata=request.state.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        res, status_code = handler(goe_response)
        # res = pipe_gen[0].asend(goe_response)
        L.info(f"RESPONSE POST /v3/runWealthSplitter {res}")
        return JSONResponse(res, status_code=int(status_code))
    else:
        L.info(f"RESPONSE ERROR POST /v3/runWealthSplitter {pipe_result}")
        return JSONResponse(pipe_result, status_code=int(pipe_result.statusCode))


@router.post(
    "/api/goe-api/goalDiscovery",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc)],
    include_in_schema=False,
)
@router.post(
    "/api/goe-api/goaldiscovery",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc), Depends(JWTBearer())],
    response_model=goelib.goe_schema.goal_discovery.GoalDiscoveryOutputModel,
    responses={
        200: goelib.goe_schema.goal_discovery.goal_discovery_response_model_v4,
        404: {"model": Message},
        400: {"model": ValidationMessageOne},
        500: {"model": InternalServerMessage},
    },
    name="Goal Discovery",
    tags=["GOE"],
    include_in_schema=False,
)
async def svc_goe_goal_discovery(
    request: Request,
    json_request: goelib.goe_schema.goal_discovery.GoalDiscoveryInputModel,
    # clientemail: str = Header(None),
    # generatepayloadonly: str = Header(None),
    # debug: str = Header(None),
):
    L = request.state.vars["L"]

    request_json = json_request
    L.info(f"POST /api/goe-api/goalDiscovery {request_json}")
    L.info("User is accessing app in UI: GOE API:/api/goe-api/goalDiscovery")
    req = {}
    req["headers"] = request.headers
    req["remote_addr"] = request.client.host
    req["request_meta_data"] = request.state.vars["metadata_t"]
    req["requester_oid"] = request.state.vars["metadata_d"]["user-id"]
    req["vars"] = request.state.vars
    gd = GoalDiscovery()
    result = await gd.goal_discovery_api(req, request_json)
    if isinstance(result, tuple):  # tuple returned incase of request need to passed to goe algo
        pipe_result, _ = result
    else:
        pipe_result = result
    pipe_result = DictDefault(pipe_result)
    if pipe_result.statusCode in [200, 400]:
        json_data = json.dumps(pipe_result)
        data = JSONResponse(pipe_result, status_code=int(pipe_result.statusCode))
        L.info(f"RESPONSE PAYLOAD POST /api/goe-api/goalDiscovery {json_data}")
        return data
    elif pipe_result.get("statusCode") is None:  # If status is None then request need to submit to goealgo api.
        slice_number = 1  # request_json.get("pageIndex", 50)
        size = request_json.get("pageSize", 500)
        results = None
        if pipe_result.pipe_config.goalDiscoveryLookUp:
            db_con = DbAccess()
            db = await db_con.get_writer_access()
            tables = await get_meta_data_for_tables(["goal_discovery_lookup"])
            GoalDiscoveryLookup = tables["goal_discovery_lookup"]
            stmt = (
                select(
                    GoalDiscoveryLookup.c.initial_investment,
                    GoalDiscoveryLookup.c.target_wealth,
                    GoalDiscoveryLookup.c.goal_tenure,
                    GoalDiscoveryLookup.c.risk_profile,
                    (GoalDiscoveryLookup.c.loss_threshold).label("lossThreshold"),
                    GoalDiscoveryLookup.c.irr,
                    GoalDiscoveryLookup.c.infusions,
                    (GoalDiscoveryLookup.c.infusion_type).label("infusionType"),
                    GoalDiscoveryLookup.c.goal_probability,
                    GoalDiscoveryLookup.c.portfolio,
                    GoalDiscoveryLookup.c.goal_priority,
                    GoalDiscoveryLookup.c.goal_type,
                )
                .select_from(GoalDiscoveryLookup)
                .where(
                    and_(
                        # func.lower(GoalDiscoveryLookup.c.goal_type) == request_json["goalType"],
                        func.lower(GoalDiscoveryLookup.c.goal_priority).in_(
                            [g.lower() for g in request_json["goalPriority"]]
                        ),
                        func.lower(GoalDiscoveryLookup.c.infusion_type) == request_json["infusionType"].lower(),
                        func.lower(GoalDiscoveryLookup.c.risk_profile) == request_json["riskProfile"].lower(),
                        between(
                            GoalDiscoveryLookup.c.goal_tenure,
                            *(request_json["goalTenure"]["min"], request_json["goalTenure"]["max"]),
                        ),
                        GoalDiscoveryLookup.c.user_id == pipe_result.oid,
                    )
                )
            )
            db = await db_con.get_writer_access()
            results = await db.get_data(stmt, as_dataframe=True)
        if results is None or len(results) == 0 or results.empty:
            response_data = {
                "body": {
                    "data": [],
                },
                "requestId": uuid.uuid4().hex,
                "statusCode": 200,
            }
            return JSONResponse(response_data, status_code=200)
        pipe_result["data"] = results.to_json(orient="records")
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "GoalDiscovery",
                rest_pb2.GOERequest(request=json.dumps(pipe_result)),
                metadata=request.state.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        goe_response = json.loads(goe_response)
        goe_response["statusCode"] = int(goe_response["statusCode"])
        status_code = int(goe_response["statusCode"])

        if status_code == 200:
            cache = await GoeDataResults.Create()
            goe_response["data"] = json.loads(goe_response["data"])
            resp_data = goe_response["data"]
            req_id = await cache.save_results(resp_data, size)
            chunk_response = await cache.get_results(req_id, slice_number=slice_number)
            response_data = {
                "body": {
                    "data": chunk_response.get("data", []),
                    "page": {
                        "perPage": size,
                        "id": slice_number,
                        "totalRecords": chunk_response.get("total_records"),
                        "totalPages": chunk_response.get("total_pages", 0),
                    },
                },
                "requestId": req_id,
                "statusCode": status_code,
            }
            # L.info(f"RESPONSE POST /api/goe-api/goalDiscovery {response_data}")
            return JSONResponse(response_data, status_code=int(status_code))
        else:
            L.info(f"RESPONSE ERROR POST /api/goe-api/goalDiscovery {goe_response}")
            return JSONResponse(goe_response, status_code=status_code)
    else:
        L.info(f"RESPONSE ERROR POST /api/goe-api/goalDiscovery {pipe_result}")
        return JSONResponse(pipe_result, status_code=int(pipe_result.statusCode))


@router.get(
    "/api/goe-api/goalDiscovery",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc)],
    include_in_schema=False,
)
@router.get(
    "/api/goe-api/goaldiscovery",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc), Depends(JWTBearer())],
    response_model=goelib.goe_schema.goal_discovery.GoalDiscoveryOutputModel,
    responses={
        200: goelib.goe_schema.goal_discovery.goal_discovery_response_model_v4,
        400: {"model": ValidationMessageOne},
        500: {"model": InternalServerMessage},
    },
    name="Goal Discovery Paginated Results",
    tags=["GOE"],
    include_in_schema=False,
)
async def goe_goal_discovery(
    request: Request,
    # json_request: goelib.goe_schema.goal_discovery.GoalDiscoveryInputModel,
    requestId: str,
    pageIndex: int = 500,
):
    L = request.state.vars["L"]

    # request_json = json_request
    L.info(f"GET /api/goe-api/goalDiscovery requestId:{requestId} pageIndex:{pageIndex}")
    L.info("User is accessing app in UI: GOE API:/api/goe-api/goalDiscovery")
    slice_number = pageIndex
    cache = await GoeDataResults.Create()
    if requestId:
        status_code = 200
        chunk_response = await cache.get_results(requestId, slice_number=slice_number)
        data = chunk_response.get("data", [])
        response_data = {
            "body": {
                "data": data,
                "page": {
                    "perPage": chunk_response.get("per_page", 0),
                    "id": slice_number,
                    "totalRecords": chunk_response.get("total_records"),
                    "totalPages": chunk_response.get("total_pages", 0),
                },
            },
            "requestId": requestId,
            "statusCode": status_code,
        }
        # res = pipe_gen[0].asend(goe_response)
        L.info(f"RESPONSE POST /api/goe-api/goalDiscovery {response_data}")
        return JSONResponse(response_data, status_code=int(status_code))


@router.post(
    "/api/goe/goefordecumulation",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc), Depends(JWTBearer())],
    response_model=goelib.goe_schema.goe_decumulation.DecumulationResponseModel,
    responses={
        200: goelib.goe_schema.goe_decumulation.decumulation_response_model,
        404: {"model": Message},
        400: {"model": ValidationMessageOne},
        500: {"model": InternalServerMessage},
    },
    name="GOE For Decumulation",
    tags=["GOE"],
    include_in_schema=True,
)
async def goe_for_decumulation(
    request: Request,
    json_request: goelib.goe_schema.goe_decumulation.GoeForDecumulationInputModel,
):
    L = request.state.vars["L"]

    L.info(
        "GET Request for /api/goe/goefordecumulation",
    )
    # L.info(f"Request payload {await request.json}")
    req = {}
    req["remote_addr"] = request.client.host
    req["headers"] = request.headers
    req["request_meta_data"] = request.state.vars["metadata_t"]
    req["requester_oid"] = request.state.vars["metadata_d"]["user-id"]
    request_json = json_request
    pipePayload = await goe_decumulation_api(request, req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        goe_response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "GoeForDecumulation",
                rest_pb2.GOERequest(request=json.dumps(pipePayload)),
                metadata=request.state.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(goe_response)
        status_code = int(response_data["statusCode"])
        response_data["statusCode"] = status_code
        if status_code == 200:
            response_data.update({"body": convertToCamelCase(response_data["data"]), "message": "Success"})
        elif status_code == 400:
            response_data.update({"body": response_data["message"], "message": "ValidationError"})
        if "data" in response_data:
            del response_data["data"]
        if "errorCode" in response_data:
            response_data["errorCode"] = int(response_data["errorCode"])

    L.info(f"RESPONSE POST /api/goe/goefordecumulation {response_data}")
    return JSONResponse(response_data, status_code=int(status_code))
    # data = await make_response(response_data)
    # data.headers.set("Content-Type", "application/json")
    # return data, status_code


@router.post(
    "/api/goe-api/goalCalculator",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc)],
    include_in_schema=False,
)
@router.post(
    "/api/goe-api/goalcalculator",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(check_user_is_avc), Depends(JWTBearer())],
    response_model=goelib.goe_schema.goe_calculator.GoalCalculatorOutputModel,
    responses={
        200: goelib.goe_schema.goe_calculator.goal_calculator_response_model,
        404: {"model": Message},
        400: {"model": ValidationMessageOne},
        500: {"model": InternalServerMessage},
    },
    name="Goal Calculator",
    tags=["GOE"],
)
async def goe_goal_calculator(
    request: Request,
    json_request: goelib.goe_schema.goe_calculator.GoalCalculatorInputModel,
):
    L = request.state.vars["L"]

    L.info(
        "POST Request for /goalcalculator",
    )
    L.info(f"Request payload {json_request}")
    req = {}
    req["remote_addr"] = request.client.host
    req["headers"] = request.headers
    req["request_meta_data"] = request.state.vars["metadata_t"]
    req["requester_oid"] = request.state.vars["metadata_d"]["user-id"]

    request_json = json_request
    pipePayload, _ = await goal_calculator_api(request, req, request_json)
    response_data = pipePayload
    status_code = pipePayload.get("statusCode")
    if "statusCode" in pipePayload and pipePayload.get("statusCode") != 200:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    elif "statusCode" not in pipePayload and request.headers.get("generatepayloadonly") != "true":
        req = rest_pb2.GOERequest(request=json.dumps(pipePayload))
        response = MessageToJson(
            await svc_client.call_queue_based_service(
                "goe-service",
                "GoalCalculator",
                req,
                metadata=request.state.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response_data = json.loads(response)
        response_data = convertToCamelCase(response_data)
        status_code = int(response_data["statusCode"])
        response_data["statusCode"] = int(response_data["statusCode"])
        if status_code == 200:
            response_data["body"] = response_data["data"]
            response_data["message"] = "Success"
            del response_data["data"]
        else:
            response_data["body"] = response_data["message"]
            del response_data["message"]

    else:
        response_data = pipePayload
        status_code = pipePayload.get("statusCode")
    L.info(f"RESPONSE POST /goalcalculator {pipePayload}")
    return JSONResponse(response_data, status_code=int(status_code))
