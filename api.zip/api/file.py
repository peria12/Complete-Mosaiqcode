import io
import json
import pandas as pd
import asyncio
import uip_grpc
import uip_files

from quart.blueprints import Blueprint
from quart import request, make_response

from transcoder_libs import (
    process_post_data,
    download,
    file_access_allowed,
    process_excel_files,
)

grpc_channels = uip_grpc.GRPC(async_mode=True)
fio = uip_files.Files()

app = Blueprint(
    "file",
    __name__,
)


@app.route("/api/file/<file_id>", methods=["DELETE"])
async def svc_file_delete(file_id):
    L = request.vars["L"]

    L.info("Delete file")
    if await file_access_allowed(file_id):
        fw = uip_files.Files()
        resp = fw.DeleteFile(file_id)
        L.debug(resp)

        return json.dumps({"result": resp})
    else:
        return f"Not allowed to delete {file_id}", 403


@app.route("/api/file-name/<folder>/<file_name>", methods=["GET"])
async def file_download_name(folder, file_name=None):
    # fio = uip_files.Files()
    file_id = fio.get_file_by_name(file_name, folder)
    return await file_download(file_id)


@app.route("/api/file-id/<file_id>", methods=["GET"])
async def file_download(file_id=None):
    f = await download(file_id)
    response = await make_response(f["data"])
    response.headers.set("Content-Type", f["file_type"])
    response.headers.set("Content-Disposition", "attachment", filename=f["file_name"])
    return response


@app.route("/api/files", methods=["POST"])
async def svc_file_upload_post():
    L = request.vars["L"]

    L.info("Create new file")
    folder = request.args.get("folder", None)

    resp = await process_post_data(request, folder=folder)
    L.debug(resp)

    return json.dumps({"result": resp})


@app.route("/api/portfolio/upload_custom_fields", methods=["POST"])
async def upload_custom_fields():
    L = request.vars["L"]
    L.info("Create new file")
    folder = "portfolio_custom_fields"
    files = await process_excel_files(request)

    file = list(files.values())[0]
    buf = file["buf"]
    if buf is None:
        return {"status_code": 400, "message": "Data does not exist"}, 400
    file_name = file["file_name"]
    file_type = file["file_type"]

    fw = uip_files.Files()
    loop = asyncio.get_event_loop()
    resp = await loop.run_in_executor(None, fw.WriteFile, file_name, folder, file_type, buf)
    if "file_id" in resp:
        file_data = pd.read_excel(io.BytesIO(buf))
        L.info(file_data.head())
        L.info("file read sucessfully")
    else:
        L.info("File id does not exist")

    return json.dumps({"result": resp})
