from datetime import datetime
import rest_pb2
import rest_pb2_grpc
from uip_grpc import GRPC
from quart import Blueprint

app = Blueprint(
    "metrics",
    __name__,
)

grpc_channels = GRPC(async_mode=True)


@app.route("/apis/custom.metrics.k8s.io/v1beta1", methods=["GET"])
async def metrics_status():
    return {"status": "ok"}


@app.route("/apis/custom.metrics.k8s.io/v1beta1/namespaces/uip-app/services/<service>/<metric>", methods=["GET"])
async def metrics(service, metric):

    print(f"metrics call {service}:{metric}")
    if metric != "scale_factor":
        return f"Metric {metric} not found", 404

    stub = rest_pb2_grpc.ServiceHubStub(grpc_channels.get_channel("services-hub"))

    resp = await stub.GetScaleFactor(rest_pb2.SVCHubScaleFactor(svc_name=service))

    return {
        "kind": "MetricValueList",
        "apiVersion": "custom.metrics.k8s.io/v1beta1",
        "metadata": {
            "selfLink": f"/apis/custom.metrics.k8s.io/v1beta1/namespaces/uip-app/services/{service}/{metric}",
        },
        "items": [
            {
                "describedObject": {"kind": "Pod", "namespace": "uip-app", "name": service, "apiVersion": "/v1"},
                "metricName": metric,
                "timestamp": datetime.utcnow().isoformat(timespec="milliseconds")[:-4] + "Z",
                "value": resp.scale_factor,
            }
        ],
    }
