import traceback
import json
import rest_pb2
import rest_pb2_grpc


# import requests
import httpx
import uip_grpc
import uip_config
from quart import Blueprint, request, jsonify
from goerio import common
from google.protobuf.json_format import MessageToDict  # , ParseDict
from google.protobuf.struct_pb2 import Struct

grpc_channels = uip_grpc.GRPC(async_mode=True)

goe_rio_app = Blueprint(
    "goe_rio",
    __name__,
)

cfg = uip_config.ConfigDict()


def handle_exception(func):
    async def wrapper(*args, **kwargs):
        res = await func(*args, **kwargs)
        if res.get("exc_type") == "ValidationError":
            raise common.ValidationError(message=res.get("message"), success=res.get("success", False))
        elif res.get("exc_type") == "CommunicationFailureError":
            raise common.CommunicationFailureError(message=res.get("message"), success=res.get("success", False))
        elif res.get("exc_type") == "Exception":
            raise Exception(res.get("message", ""))
        return res

    wrapper.__name__ = func.__name__
    return wrapper


async def cms_proxy(api_key, url):
    L = request.vars["L"]
    headers = {"X-FT-API-KEY": api_key, "Content-Type": "application/json"}
    async with httpx.AsyncClient() as client:
        response = await client.get(url, headers=headers)
    res = json.loads(response.text)
    L.info(f"Response from CMS {res}")
    return res


@goe_rio_app.route("/api/rio/goe4d/translation", methods=["POST"])
@handle_exception
async def goe_rio_translation_service():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/rio/goe4d/translation {request_json}")
    headers = request.headers
    # Message entire request payload into struct's data variable
    request_json = json.dumps(request_json)
    if "clientemail" not in headers:
        L.info("clientemail is mandatory in headers.")
        raise common.ValidationError(message="clientemail is mandatory in headers.", success=False)
    json_data = {"data": request_json, "clientemail": headers["clientemail"], "version": headers["version"]}
    L.info(f"request_json: {request_json}")

    payload = {"data": Struct()}
    payload["data"].update(json_data)

    req = rest_pb2.RIOGEO4DTranslationRequest(
        payload=payload,
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).RIOGEO4DTranslation(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/rio/goe4d/translation {res}")
    return res


@goe_rio_app.route("/api/rio/cms/<content>", methods=["GET"])
@handle_exception
async def goe_rio_cms_proxy_service(content):
    """CMS proxy service(s) for Bloomreach content management service which requires a API key subcription
    all are GET call only and should be open service without Authentication and Authorization as these ere
    loaded at the Web page startup
    """
    L = request.vars["L"]
    request_json = await request.json
    # content = request.view_args['content']
    L.info(f"content {content}")

    L.info(f"POST /api/rio/cms/{content} {request_json}")
    cms_endpoint = cfg["goe_rio"]["bloomreach"]["apim"]["endpoint"]
    api_key = cfg["goe_rio"]["bloomreach"]["apim"]["subcription_key"]
    preview = cfg["goe_rio"]["bloomreach"]["apim"]["preview"]

    res = await cms_proxy(api_key, f"{cms_endpoint}/florida/content/{content}?preview={preview}")
    L.info(f"Response /api/rio/goe4d/translation {res}")
    return res


@goe_rio_app.errorhandler(common.RioException)
async def handle_advisor_portal_error(e):
    """Return json error for AdvisorPortalException errors defined .
    This will avoid having to try/catch Errors in all endpoints, returning
    correct JSON response with associated HTTP Status Code
    """
    L = request.vars["L"]
    L.info("Advisor portal api failed")
    data = {"message": e.message, "name": e.name, "statusCode": e.error_code}
    return jsonify(data), e.error_code


@goe_rio_app.errorhandler(Exception)
async def handle_error(exception):
    """Return json error for errors not handled in handle_advisor_portal_error fn.
    This will avoid having to try/catch Errors in all endpoints, returning
    correct JSON response with associated HTTP 500 Status
    """
    L = request.vars["L"]
    L.error(exception)
    L.error(traceback.format_exc())
    if "Permission Denied" in str(exception):
        msg = jsonify({"message": str(exception), "statusCode": 403, "name": "UnAuthorized"})
        return msg, 403
    msg = jsonify({"message": str(exception), "statusCode": 500, "name": "InternalError"})
    return msg, 500


@goe_rio_app.route("/api/rio/loginuserinfo", methods=["GET"])
@handle_exception
async def get_login_user_info():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/loginuserinfo {request_json}")
    req = rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).RioLoginUserInfo(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    return res


@goe_rio_app.route("/api/rio/documenthistory", methods=["GET"])
@handle_exception
async def goeap_get_document_history():
    L = request.vars["L"]
    L.info("GET /api/rio/documenthistory {request.args}")
    req = rest_pb2.AdvisiorPortalHistoryRequest(collection_name=request.args.get("collection_name"))

    res = MessageToDict(
        await rest_pb2_grpc.GoeAdvisorPortalStub(
            grpc_channels.get_channel("goe-advisor-portal")
        ).GetAdvrPortalDocumentHistory(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/documenthistory {res}")
    return res


@goe_rio_app.route("/api/rio/getcontact", methods=["POST"])
@handle_exception
async def goe_get_contact():
    L = request.vars["L"]
    request_json = await request.json
    L.info("GET /api/rio/getcontact {request_json}")
    req = rest_pb2.RIOContactRequest(
        contactId=request_json["contactId"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetContact(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/getcontact {res}")
    return res


@goe_rio_app.route("/api/rio/addcontact", methods=["POST"])
@handle_exception
async def goe_add_contact():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/addcontact {request_json}")

    wealthItems = {"data": Struct()}
    wealthItems["data"].update({"wealthItems": request_json.get("wealthItems", [])})

    req = rest_pb2.RIOContactRequest(
        contactId=request_json["contactId"],
        type=request_json.get("type", None),
        state=request_json.get("state", ""),
        email=request_json.get("email", ""),
        salutation=request_json.get("salutation", ""),
        firstName=request_json.get("firstName", ""),
        middleName=request_json.get("middleName", ""),
        lastName=request_json.get("lastName", ""),
        preferredName=request_json.get("preferredName", ""),
        gender=request_json.get("gender", ""),
        birthdate=request_json.get("birthdate", ""),
        healthStatus=request_json.get("healthStatus", ""),
        jobTitle=request_json.get("jobTitle", ""),
        organizationId=request_json.get("organizationId", ""),
        addresses=request_json.get("addresses", [""]),
        phones=request_json.get("phones", [""]),
        isRetired=request_json.get("isRetired", True),
        postcode=request_json.get("postcode", ""),
        wealthItems=wealthItems,
        hasOutstandingDebts=request_json.get("hasOutstandingDebts", False),
        action="ADD",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateContact(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/addcontact {res}")
    return res


@goe_rio_app.route("/api/rio/updatecontact", methods=["POST"])
@handle_exception
async def goe_update_contact():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/updatecontact {request_json}")

    wealthItems = {"data": Struct()}
    wealthItems["data"].update({"wealthItems": request_json.get("wealthItems", [])})

    req = rest_pb2.RIOContactRequest(
        contactId=request_json["contactId"],
        type=request_json.get("type", None),
        state=request_json.get("state", ""),
        email=request_json.get("email", ""),
        salutation=request_json.get("salutation", ""),
        firstName=request_json.get("firstName", ""),
        middleName=request_json.get("middleName", ""),
        lastName=request_json.get("lastName", ""),
        preferredName=request_json.get("preferredName", ""),
        gender=request_json.get("gender", ""),
        birthdate=request_json.get("birthdate", ""),
        healthStatus=request_json.get("healthStatus", ""),
        jobTitle=request_json.get("jobTitle", ""),
        organizationId=request_json.get("organizationId", ""),
        addresses=request_json.get("addresses", [""]),
        phones=request_json.get("phones", [""]),
        isRetired=request_json.get("isRetired", True),
        postcode=request_json.get("postcode", ""),
        wealthItems=wealthItems,
        hasOutstandingDebts=request_json.get("hasOutstandingDebts", False),
        action="UPDATE",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateContact(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/updatecontact {res}")
    return res


@goe_rio_app.route("/api/rio/deletecontact", methods=["POST"])
@handle_exception
async def goe_delete_contact():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/deletecontact {request_json}")

    req = rest_pb2.RIOContactRequest(
        contactId=request_json["contactId"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).DeleteContact(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/deletecontact {res}")
    return res


@goe_rio_app.route("/api/rio/getcontacts", methods=["GET"])
@handle_exception
async def goe_get_contacts():
    L = request.vars["L"]
    L.info("GET /api/rio/getcontacts {request.vars}")
    req = rest_pb2.RIOGetContactsRequest(
        userId=request.vars["metadata_d"]["user-id"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetContacts(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/getcontact {res}")
    return res


@goe_rio_app.route("/api/rio/client/<contactId>/getproposal", methods=["POST"])
@handle_exception
async def goe_get_client_proposal(contactId):
    L = request.vars["L"]
    request_json = await request.json
    L.info("GET /api/rio/client/{contactId}/getproposal {request_json}")
    req = rest_pb2.RIOGetProposalRequest(
        contactId=contactId,
        proposalId=request_json.get("proposalId", ""),
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetProposal(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/client/{contactId}/getproposal {res}")
    return res


@goe_rio_app.route("/api/rio/client/<contactId>/addproposal", methods=["POST"])
@handle_exception
async def goe_add_client_proposal(contactId):
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/client/{contactId}/addproposal {request_json}")

    struc_obj = Struct()
    struc_obj.update(request_json.get("customData", {}))
    customData = {}
    customData["data"] = struc_obj

    req = rest_pb2.RIOProposalRequest(
        contactId=contactId,
        proposalId=request_json.get("proposalId", ""),
        name=request_json.get("name", ""),
        state=request_json.get("state", ""),
        type=request_json.get("type", ""),
        userId=request_json.get("userId", ""),
        date=request_json.get("date", ""),
        expiryDate=request_json.get("expiryDate", ""),
        customData=customData,
        action="ADD",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateProposal(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/client/{contactId}/addproposal {res}")
    return res


@goe_rio_app.route("/api/rio/client/<contactId>/updateproposal", methods=["POST"])
@handle_exception
async def goe_update_client_proposal(contactId):
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/client/{contactId}/updateproposal {request_json}")

    struc_obj = Struct()
    struc_obj.update(request_json.get("customData", {}))
    customData = {}
    customData["data"] = struc_obj

    req = rest_pb2.RIOProposalRequest(
        contactId=contactId,
        proposalId=request_json.get("proposalId", ""),
        name=request_json.get("name", ""),
        state=request_json.get("state", ""),
        type=request_json.get("type", ""),
        userId=request_json.get("userId", ""),
        date=request_json.get("date", ""),
        expiryDate=request_json.get("expiryDate", ""),
        customData=customData,
        action="UPDATE",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateProposal(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/client/{contactId}/updateproposal {res}")
    return res


@goe_rio_app.route("/api/rio/client/<contactId>/deleteproposal", methods=["POST"])
@handle_exception
async def goe_delete_client_proposal(contactId):
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/client/{contactId}/deleteproposal {request_json}")

    req = rest_pb2.RIODeleteProposalRequest(
        contactId=contactId,
        proposalId=request_json.get("proposalId", ""),
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).DeleteProposal(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response api/rio/client/{contactId}/deleteproposal {res}")
    return res


@goe_rio_app.route("/api/rio/client/<contactId>/getclientproposals", methods=["GET"])
@handle_exception
async def goe_get_client_all_proposals(contactId):
    L = request.vars["L"]
    L.info("GET /api/rio/client/{contactId}/getclientproposals {request.vars}")
    req = rest_pb2.RIOGetAllProposalsRequest(
        contactId=contactId,
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetClientProposals(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/client/{contactId}/getclientproposals {res}")
    return res


@goe_rio_app.route("/api/rio/profile/getorganization", methods=["POST"])
@handle_exception
async def goe_get_organization():
    L = request.vars["L"]
    request_json = await request.json
    L.info("GET /api/rio/profile/getorganization {request_json}")
    req = rest_pb2.RIOGetOrganizationRequest(
        organizationId=request_json.get("organizationId", ""),
        organizationName=request_json.get("organizationName", ""),
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetOrganization(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/profile/getorganization {res}")
    return res


@goe_rio_app.route("/api/rio/profile/addorganization", methods=["POST"])
@handle_exception
async def goe_add_organization():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/profile/addorganization {request_json}")

    for key, value in request_json.items():
        if isinstance(value, dict):
            request_json[key] = {"data": Struct()}
            request_json[key]["data"].update(value)

    feeStructure = {"data": Struct()}
    feeStructure["data"].update({"feeStructure": request_json.get("feeStructure", [])})

    req = rest_pb2.RIOOrganizationRequest(
        organizationId=request_json.get("organizationId", ""),
        state=request_json.get("state", ""),
        name=request_json.get("name", ""),
        street=request_json.get("street", ""),
        postalCode=request_json.get("postalCode", ""),
        city=request_json.get("city", ""),
        stateOrProvince=request_json.get("stateOrProvince", ""),
        countryOrRegion=request_json.get("countryOrRegion", ""),
        config=request_json.get("config", {}),
        settings=request_json.get("settings", {}),
        feeStructure=feeStructure,
        equityCap=request_json.get("equityCap", {}),
        extData=request_json.get("extData", {}),
        action="ADD",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateOrganization(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/profile/addorganization {res}")
    return res


@goe_rio_app.route("/api/rio/profile/updateorganization", methods=["POST"])
@handle_exception
async def goe_update_organization():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/profile/updateorganization {request_json}")

    for key, value in request_json.items():
        if isinstance(value, dict):
            request_json[key] = {"data": Struct()}
            request_json[key]["data"].update(value)

    feeStructure = {"data": Struct()}
    feeStructure["data"].update({"feeStructure": request_json.get("feeStructure", [])})

    req = rest_pb2.RIOOrganizationRequest(
        organizationId=request_json.get("organizationId", ""),
        state=request_json.get("state", ""),
        name=request_json.get("name", ""),
        street=request_json.get("street", ""),
        postalCode=request_json.get("postalCode", ""),
        city=request_json.get("city", ""),
        stateOrProvince=request_json.get("stateOrProvince", ""),
        countryOrRegion=request_json.get("countryOrRegion", ""),
        config=request_json.get("config", {}),
        settings=request_json.get("settings", {}),
        feeStructure=feeStructure,
        equityCap=request_json.get("equityCap", {}),
        extData=request_json.get("extData", {}),
        action="UPDATE",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateOrganization(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/profile/updateorganization {res}")
    return res


@goe_rio_app.route("/api/rio/profile/deleteorganization", methods=["POST"])
@handle_exception
async def goe_delete_organization():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/profile/deleteorganization {request_json}")

    req = rest_pb2.RIODeleteOrganizationRequest(
        organizationId=request_json.get("organizationId", ""),
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).DeleteOrganization(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response api/rio/profile/deleteorganization {res}")
    return res


@goe_rio_app.route("/api/rio/profile/getorganizations", methods=["GET"])
@handle_exception
async def goe_get_organizations():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/profile/getorganizations {request_json}")

    req = rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty()

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetOrganizations(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response api/rio/profile/getorganizations {res}")
    return res


@goe_rio_app.route("/api/rio/getmarketportfolio", methods=["POST"])
@handle_exception
async def goe_get_marketportfolio():
    L = request.vars["L"]
    request_json = await request.json
    L.info("GET /api/rio/getmarketportfolio {request_json}")
    req = rest_pb2.RIOGetMarketPortfolioRequest(
        portfolioId=request_json.get("portfolioId", ""),
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetMarketPortfolio(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/getmarketportfolio {res}")
    return res


@goe_rio_app.route("/api/rio/addmarketportfolio", methods=["POST"])
@handle_exception
async def goe_add_marketportfolio():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/addmarketportfolio {request_json}")

    portfolio = {"data": Struct()}
    portfolio["data"].update(request_json.get("portfoliosData", {}))

    req = rest_pb2.RIOMarketPortfolioRequest(
        portfolioId=request_json.get("portfolioId", ""),
        goeConfigEmail=request_json["goeConfigEmail"],
        orgName="",
        country=request_json["country"],
        portfoliosData=portfolio,
        action="ADD",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateMarketPortfolio(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/addmarketportfolio {res}")
    return res


@goe_rio_app.route("/api/rio/updatemarketportfolio", methods=["POST"])
@handle_exception
async def goe_update_marketportfolio():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/updatemarketportfolio {request_json}")

    portfolio = {"data": Struct()}
    portfolio["data"].update(request_json.get("portfoliosData", {}))

    req = rest_pb2.RIOMarketPortfolioRequest(
        portfolioId=request_json.get("portfolioId", ""),
        goeConfigEmail=request_json["goeConfigEmail"],
        orgName=request_json["orgName"],
        country=request_json["country"],
        portfoliosData=portfolio,
        action="UPDATE",
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddOrUpdateMarketPortfolio(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/rio/updatemarketportfolio {res}")
    return res


@goe_rio_app.route("/api/rio/deletemarketportfolio", methods=["POST"])
@handle_exception
async def goe_delete_marketportfolio():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/profile/deletemarketportfolio {request_json}")

    req = rest_pb2.RIODeleteMarketPortfolioRequest(
        portfolioId=request_json.get("portfolioId", ""),
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).DeleteMarketPortfolio(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response api/rio/deletemarketportfolio {res}")
    return res


@goe_rio_app.route("/api/rio/getmarketportfolios", methods=["GET"])
@handle_exception
async def goe_get_marketportfolios():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/rio/getmarketportfolios {request_json}")

    req = rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty()

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetMarketPortfolios(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response api/rio/getmarketportfolios {res}")
    return res


@goe_rio_app.route("/api/rio/spireps/indicativequote", methods=["POST"])
@handle_exception
async def spire_indicative_quote_proxy_service():
    """Spire PS indicative quote proxy service involves sso ticket generation and indicatvie quote invocations"""
    L = request.vars["L"]
    request_json = await request.json
    # Massage entire request payload into struct's data variable
    json_data = {"data": request_json}
    payload = json.dumps(request_json)
    L.info(f"request_json: {payload}")

    payload = {"data": Struct()}
    payload["data"].update(json_data.get("data", {}))

    req = rest_pb2.RIOSpireIndicativeQuoteRequest(
        payload=payload,
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetSpireIndicativeQuote(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/rio/spireps/indicativequote {res}")
    return res


@goe_rio_app.route("/api/rio/spireps/personalizedquoteurl", methods=["POST"])
@handle_exception
async def spire_personalized_quote_portal_site_url_service():
    """Spire PS Personalized quote URL generation with SSO ticket generation to complete the quote at Spire Portal by FA"""
    L = request.vars["L"]
    request_json = await request.json
    # Massage entire request payload into struct's data variable
    json_data = {"data": request_json}
    payload = json.dumps(request_json)
    L.info(f"request_json: {payload}")

    payload = {"data": Struct()}
    payload["data"].update(json_data.get("data", {}))

    req = rest_pb2.RIOSpireIndicativeQuoteRequest(
        payload=payload,
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetSpirePersonalizedQuotePortalUrl(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/rio/spireps/personalizedquoteurl {res}")
    return res


@goe_rio_app.route("/api/rio/addupdatesettings", methods=["POST"])
@handle_exception
async def goeap_add_update_settings_data():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/rio/addupdatesettings {request_json}")

    value = {"data": Struct()}
    value["data"].update(request_json.get("value", {}))

    req = rest_pb2.RIOSettingsDataRequest(
        key=request_json["key"],
        value=value,
    )
    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).AddUpdateSettingsData(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Respone /api/rio/addupdatesettings {res}")
    return res


@goe_rio_app.route("/api/rio/getsettings", methods=["GET"])
@handle_exception
async def goeap_get_settings_data():
    L = request.vars["L"]
    request_json = await request.json
    L.info(f"POST /api/rio/getsettings {request_json}")
    req = rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
    res = MessageToDict(
        await rest_pb2_grpc.GoeRIOServiceStub(grpc_channels.get_channel("goe-rio")).GetSettingsData(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    return res
