from quart.blueprints import Blueprint
from quart import request
import json
from sqlalchemy import text
from transcoder_libs import check_user_access, process_excel_files
from libs.macro_models.main import run_from_api
from libs.macro_models.api_reader import SimpleAPIReader
from libs.macro_models.entrypoint import main
from google.protobuf.json_format import MessageToJson
import rest_pb2_grpc
import rest_pb2
import uip_grpc
from uip_dbs_async import Db
from datetime import datetime

app = Blueprint(
    "model_portfolio",
    __name__,
)

grpc_channels = uip_grpc.GRPC(async_mode=True)


@app.route("/api/model-portfolios/convert", methods=["POST"])
async def run_advisor_engine():

    files = await process_excel_files(request)

    if not files:
        return {"status_code": 400, "message": "Please upload a file"}, 400
    elif len(files) != 1:
        return {"status_code": 400, "message": "Please upload one file only"}, 400
    else:
        for key, values in files.items():
            if values["status"] != "":
                return {"status_code": 400, "message": values["status"]}, 400

    s3_paths = run_from_api(files)
    filtered_output = []
    for s3_path in s3_paths:
        temp = {k: v for k, v in s3_path.items() if k in ("file_id", "file_name", "file_type")}
        filtered_output.append(temp)
    return json.dumps({"result": filtered_output}), 200


@app.route("/api/model-portfolios", methods=["GET"])
async def list_portfolios():

    return MessageToJson(
        await rest_pb2_grpc.ModelPortfolioStub(grpc_channels.get_channel("model-portfolio")).GetMacroList(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/audit_records", methods=["GET"])
async def get_audit_records():

    return MessageToJson(
        await rest_pb2_grpc.ModelPortfolioStub(grpc_channels.get_channel("model-portfolio")).GetAuditRecords(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/generate_report", methods=["POST"])
async def generate_report():
    payload = await request.json
    user = request.vars["metadata_d"]["user-name"]
    print(payload)
    request_received_time = datetime.now()
    message = payload["comments"]
    output = []
    has_access = await check_user_access(request, (("model_portfolios", "file_transforms", "admin"),))
    response, status, pipeline_status = main(payload, has_access)
    request_completed_time = datetime.now()
    output.append(response)
    print(f"Complete: {output}")
    # pipeline_status = "success" if status == 200 else "error"
    time_to_process = (request_completed_time - request_received_time).seconds

    query = text(
        """INSERT INTO public.model_management_audit
    (username, request_received, request_completed, message, payload, response, status,
    time_to_process, s3_file_path, total_file_count)
    VALUES (:username,:request_received,:request_completed,:message,:payload,:response,:status,
    :time_to_process,:s3_file_path,:total_file_count);"""
    ).bindparams(
        username=user,
        request_received=request_received_time,
        request_completed=request_completed_time,
        message=message,
        payload=json.dumps(payload),
        response=json.dumps(response),
        status=pipeline_status,
        time_to_process=time_to_process,
        s3_file_path=response.get("file_id", ""),
        total_file_count=response.get("total_file_count", 0),
    )
    db = await Db.Create("uip_db_write")
    await db.execute(query)
    return json.dumps(output), status


@app.route("/api/check_rebalance", methods=["POST"])
async def check_rebalance():
    payload = await request.json
    one_tis_ids = payload["onetis_ids"]
    reader = SimpleAPIReader(one_tis_ids)
    output_ids = reader.get_ids()
    response = {"onetid_ids": output_ids}
    return response
