import uip_grpc


import rest_pb2
import rest_pb2_grpc

from quart import request, abort
from quart.blueprints import Blueprint

from google.protobuf.json_format import MessageToJson, ParseDict
from google.protobuf.struct_pb2 import Struct
from transcoder_libs import (
    process_post_data,
)

grpc_channels = uip_grpc.GRPC(async_mode=True)

app = Blueprint(
    "admin",
    __name__,
)


@app.route("/api/admin/log", methods=["POST"])
async def svc_admin_log():
    L = request.vars["L"]

    json_obj = await request.json
    if "warning" in json_obj:
        L.warning(json_obj["warning"])
    elif "error" in json_obj:
        L.error(json_obj["error"])
    elif "debug" in json_obj:
        L.debug(json_obj["debug"])
    elif "info" in json_obj:
        L.info(json_obj["info"])
    else:
        abort(400)

    return ({}, 200)


@app.route("/api/admin/system-info", methods=["GET"])
async def svc_admin_system_info():
    L = request.vars["L"]

    L.info("GET request for system-info")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetSystemInfo(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/apps", methods=["GET"])
async def svc_admin_apps():
    L = request.vars["L"]

    L.info("GET request for available apps")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetApps(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/apps/<id>", methods=["GET"])
async def svc_admin_app(id):
    L = request.vars["L"]

    L.info(f"GET request for app {id}")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetApp(
            request=rest_pb2.AppIDRequest(app_id=id),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/access", methods=["GET"])
async def svc_admin_access():
    L = request.vars["L"]

    L.info("GET request for ACL")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAccess(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/all-access", methods=["GET"])
async def svc_admin_allaccess():
    L = request.vars["L"]

    L.info("GET request for all ACLs")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAllAccess(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/users", methods=["GET"])
async def svc_admin_users_With_access():
    L = request.vars["L"]

    L.info("GET all users with given access")

    req = request.args.get("req")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUsersWithAccess(
            request=rest_pb2.JSON(str=req),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/users", methods=["POST"])
async def svc_admin_users_create():
    L = request.vars["L"]

    L.info("POST Request for /api/admin/users")
    data = await process_post_data(request)

    r = rest_pb2.CreateUserRequest(
        is_external=True,
        email=data["email"],
        password=data["password"],
        name=data["name"],
        phone_number=data["phone_number"],
    )

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).CreateUser(
            request=r,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/users/info", methods=["GET"])
async def svc_admin_users_info():
    L = request.vars["L"]

    L.info("GET all users basic information")

    req = None
    users = request.args.get("users", "").strip()
    if users != "":
        users = users.split(",")
        req = rest_pb2.UserInfoRequest(user_ids=users)
    else:
        emails = request.args.get("emails", "").strip()
        if emails != "":
            emails = emails.split(",")
            req = rest_pb2.UserInfoRequest(emails=emails)

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserInfo(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/user-settings", methods=["GET"])
async def svc_admin_app_users_settings():
    L = request.vars["L"]

    L.info("GET all app settings for the users")

    req = None
    users = request.args.get("users", "").strip()
    if users != "":
        users = users.split(",")
        req = rest_pb2.AppUserSettingsRequest(user_ids=users)
    else:
        emails = request.args.get("emails", "").strip()
        if emails != "":
            emails = emails.split(",")
            req = rest_pb2.AppUserSettingsRequest(emails=emails)

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/apps/<app_id>/zone/<zone_id>/user-settings/<user_id>", methods=["PUT"])
async def svc_admin_updateapp_settings(app_id, zone_id, user_id):
    L = request.vars["L"]

    L.info("Update App settings request")
    path = request.args.get("path", None)

    settings = Struct()
    settings.update(await request.json)

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateAppSettingsForUser(
            request=rest_pb2.UpdateAppUserSettingsRequest(
                app=app_id, user_id=user_id, zone=zone_id, settings=settings, path=path
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/apps/<app_id>/zone-settings/<zone_id>", methods=["GET"])
async def svc_admin_app_zone_settings(app_id, zone_id):
    L = request.vars["L"]

    L.info("GET all app-zone settings")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppZoneSettings(
            request=rest_pb2.AppSettingsRequest(app=app_id, zone=zone_id),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/collections", methods=["GET"])
async def svc_admin_get_collections():
    L = request.vars["L"]

    L.info("GET request to retrieve all Collections")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetCollections(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/collections_new", methods=["GET"])
async def svc_admin_get_collections_new():
    L = request.vars["L"]

    L.info("GET request to retrieve all Collections and Document names")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetCollectionNames(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/collections/<collection_name>/documents", methods=["POST"])
async def svc_admin_create_document(collection_name):
    L = request.vars["L"]

    L.info("POST request for creating a document")

    body = Struct()
    body.update(await request.json)

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateDocument(
            request=rest_pb2.UpdateDocumentRequest(
                collection_name=collection_name,
                payload=body,
                comment=request.args.get("comment"),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/collections/<collection_name>/documents/<document_id>", methods=["GET"])
async def svc_admin_get_document(collection_name, document_id):
    L = request.vars["L"]

    L.info("GET request for retrieving a document")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetDocument(
            request=rest_pb2.GetDocumentRequest(
                collection_name=collection_name,
                document_id=document_id,
                version=request.args.get("version", None),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
        sort_keys=True,
    )


@app.route("/api/admin/collections/<collection_name>/documents/<document_id>/history", methods=["GET"])
async def svc_admin_get_document_history(collection_name, document_id):
    L = request.vars["L"]

    L.info("GET request for retrieving a document history")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetDocumentHistory(
            request=rest_pb2.DocumentHistoryRequest(
                collection_name=collection_name,
                document_id=document_id,
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
        sort_keys=True,
    )


@app.route("/api/admin/collections/<collection_name>/documents/<document_id>", methods=["PUT"])
async def svc_admin_update_document(collection_name, document_id):
    L = request.vars["L"]

    L.info("PUT request for updating a document")

    body = Struct()
    body.update(await request.json)

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateDocument(
            request=rest_pb2.UpdateDocumentRequest(
                collection_name=collection_name,
                payload=body,
                comment=request.args.get("comment"),
                document_id=document_id,
                type=request.args.get("type"),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/collections/<collection_name>/documents/<document_id>", methods=["DELETE"])
async def svc_admin_delete_document(collection_name, document_id):
    L = request.vars["L"]

    L.info("DELETE request for deleting a document")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).DeleteDocument(
            request=rest_pb2.DocumentRequest(
                collection_name=collection_name,
                document_id=document_id,
                comment=request.args.get("comment"),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/collections/<name>", methods=["DELETE"])
async def svc_admin_delete_collection(name):
    L = request.vars["L"]

    L.info("DELETE request for deleting a collection")

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).DeleteCollection(
            request=ParseDict(request.args, rest_pb2.CollectionRequest(name=name)),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/update-access", methods=["POST"])
async def svc_admin_updateaccess():
    L = request.vars["L"]

    L.info("Update Access request")

    data = await process_post_data(request)
    L.debug(data)

    if "updates" not in data:
        return MessageToJson(
            rest_pb2.AccessUpdateResponse(success=False, message="No updates found!"),
            preserving_proto_field_name=True,
        )

    req = rest_pb2.AccessUpdateRequest()
    for update in data["updates"]:
        req.updates.append(
            rest_pb2.AccessUpdate(
                app=update[0],
                zone=update[1],
                type=update[2],
                user_id=update[3],
                access_type=update[4],
                action=update[5],
            )
        )

    for update in data["group_updates"]:
        req.group_updates.append(
            rest_pb2.AccessUpdate(
                app=update[0],
                zone=update[1],
                type=update[2],
                user_id=update[3],
                access_type=update[4],
                action=update[5],
            )
        )

    for user_id, info in data.get("user_info", {}).items():
        pui = req.user_info[user_id]
        pui = ParseDict(info, pui)

    for group_id, info in data.get("group_info", {}).items():
        pgi = req.group_info[group_id]
        pgi = ParseDict(info, pgi)

    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateAccess(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/departments", methods=["GET"])
async def svc_admin_depts_get():
    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetDepartments(
            request=rest_pb2.DepartmentsRequest(
                search=request.args.get("search"),
                limit=int(request.args.get("limit", 20)),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/admin/user_orgs", methods=["GET"])
async def svc_admin_user_orgs_get():
    return MessageToJson(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetUserOrgs(
            request=rest_pb2.UserOrgsRequest(
                search=request.args.get("search"),
                limit=int(request.args.get("limit", 20)),
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
