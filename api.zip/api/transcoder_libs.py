import uip_files
import json
import random
import string
import httpx
import uip_config

from uip_access import AccessControl
from quart import request, abort
import magic
import time

from uip_auth_s import Okta

fio = uip_files.Files()

okta = Okta()
cfg = uip_config.ConfigDict()


async def process_post_data(request, svc_name=None, folder=None, allow_excel=False, offset=None):
    data = {}
    json_obj = await request.json
    form = await request.form
    if json_obj:
        data.update(json_obj)
    elif form:
        data.update(form.to_dict())

    files = await request.files

    if files:
        fw = uip_files.Files()
        fs = files.to_dict(False)

        L = request.vars["L"]
        for form_name, files in fs.items():
            if form_name not in data:
                data[form_name] = []

            for f in files:
                L.info(
                    f"Writing {form_name}, {folder or ''}/{f.filename}, {f.mimetype}, {svc_name}",
                )
                if offset is not None and isinstance(offset, int):
                    f.stream.seek(offset)
                buf = f.stream.read()
                if (
                    allow_excel and f.mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                ) or verify_mime_type(buf) is None:
                    data[form_name].append(
                        fw.WriteFile(
                            file_name=f.filename,
                            folder=folder,
                            file_type=f.mimetype,
                            service_name=svc_name,
                            data=buf,
                        )
                    )
    return data


async def process_files(request, allow_excel=False, offset=None):
    resp = {}
    for form_name, files in (await request.files).to_dict(False).items():
        if form_name not in resp:
            resp[form_name] = []
        for f in files:
            if offset is not None and isinstance(offset, int):
                f.stream.seek(offset)
            buf = f.stream.read()
            # verify_mime_type(buf)
            if (
                allow_excel and f.mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ) or verify_mime_type(buf) is None:
                resp[form_name].append({"buf": buf, "file_name": f.filename, "file_type": f.mimetype})
    return resp


async def process_excel_files(request):
    resp = {}
    for key, val in (await request.files).to_dict().items():
        buf = val.stream.read()
        flag = verify_excel_mimie(buf)
        if flag is False:
            resp[key] = {"buf": None, "file_name": val.filename, "status": f'{"File Uploaded is not Excel"}'}
            continue
        if not (key in val.filename):
            request.vars["L"].info(
                f"Uploaded model_type: {key} and file: {val.filename} is not matched, returning 400",
            )
            resp[key] = {
                "buf": None,
                "file_name": val.filename,
                "status": f"File and model_type is not matched, model_type is {key}, file is {val.filename}",
            }
        else:
            resp[key] = {"buf": buf, "file_name": val.filename, "file_type": val.mimetype, "status": ""}

    return resp


def verify_excel_mimie(buf):
    mime = magic.from_buffer(buf, mime=True)

    # Allow xlxs
    if mime != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        request.vars["L"].info(f"Uploaded file is mime type {mime}, returning 400")
        return False
    return True


def verify_mime_type(buf):
    mime = magic.from_buffer(buf, mime=True)

    # Allow CSV and wheel file (ZIP)
    if (
        mime != "application/csv"
        and mime != "application/zip"
        and mime != "text/plain"
        and mime != "image/jpeg"
        and mime != "image/png"
    ):
        request.vars["L"].info(f"Uploaded file is mime type {mime}, returning 400")
        abort(400, f"File Uploaded is not CSV, mime type is {mime}")


async def check_access(request, roles):
    """Method for checking access for a given roles"""
    ac = await AccessControl.Create()
    try:
        user_id = request["requester_oid"]
        ok, _ = await ac.request_access(user_id, roles, False)
    except Exception as e:
        ok = False
    return ok


async def check_user_access(request, roles):
    """Method for checking access for a given roles"""
    ac = await AccessControl.Create()
    user_id = request.vars["metadata_d"]["user-id"]
    ok, _ = await ac.request_access(user_id, roles, False)
    return ok


# A decorator for performing authorization for REST endpoints
def authorize(roles):
    def out_wrapper(func):
        async def wrapper(*args, **kwargs):
            ac = await AccessControl.Create()
            user_id = request.vars["metadata_d"]["user-id"]
            ok, msg = await ac.request_access(user_id, roles, False)

            if ok:
                return await func(*args, **kwargs)
            else:
                abort(403, "Access denied: " + msg)

        wrapper.__name__ = func.__name__
        return wrapper

    out_wrapper.__name__ = ".".join(".".join(role) for role in roles)
    return out_wrapper


async def read_file(file_id=None):
    """Method for reading file for given file_id"""
    if not file_id:
        abort(400)
    user_id = request.vars["metadata_d"]["user-id"]
    request.vars["L"].info(f"GET Request for file {file_id}")
    allowed = user_id == "ServiceUser" or await fio.check_file_access(file_id, user_id)
    if allowed:
        f = fio.ReadFile(file_id)
        if not f:
            abort(404)
    else:
        abort(401)
    response = f
    return response


async def file_access_allowed(file_id):
    user_id = request.vars["metadata_d"]["user-id"]
    return user_id == "ServiceUser" or await fio.check_file_access(file_id, user_id)


async def download(file_id=None):
    if not file_id:
        abort(400)

    request.vars["L"].info(f"GET Request for file {file_id}")
    allowed = file_access_allowed(file_id)

    if allowed:
        f = fio.ReadFile(file_id)

        if not f:
            abort(404)
    else:
        abort(401)

    return f


async def search_okta_accounts(text, limit):
    try:
        return {"users": await okta.list_users(text=text, limit=limit)}
    except Exception as exc:
        L = request.vars["L"]
        L.info("Okta SearchUsers API Failed.")
        return json.dumps({"statusCode": 400, "message": str(exc), "data": None})


async def generate_password():
    """basic Password generator of length 8 is returned
    with atleast 2 small letter, 2 capital letters, 2 digits and 2 punctuations.

    Returns:
        str: random string is returned.
    """
    LOWER_LETTERS = random.choices(list(string.ascii_lowercase), k=3)
    UPPER_LETTERS = random.choices(list(string.ascii_uppercase), k=3)
    DIGITS = random.choices(list(string.digits), k=3)
    PUNCTUATION = random.choices(list(string.punctuation), k=3)

    random_password = LOWER_LETTERS + UPPER_LETTERS + DIGITS + PUNCTUATION
    random.shuffle(random_password)
    random_password = "".join(random_password)
    return random_password


def rebuild_score(query, fields, size):
    """In case your search is across fields in a document this will help to improve score
    based on total length all field values in a document. If total length is less high score is given.
    This is applied on query result. In other words high score is given to a document if total query coverage
    across all field value is high.
    """
    script_source = ""
    fields_sum = []
    for fld in fields:
        script_source += (
            f"int {fld}_length = doc['{fld}.keyword'].size() == 0 ? 1: doc['{fld}.keyword'].value.length();"
        )
        fields_sum.append(f" {fld}_length")
    fields_sum = " + ".join(fields_sum)
    script_source += f"return 1.0 / ({fields_sum})"
    new_query = {
        "query": {"script_score": {"query": query, "script": {"source": f"""{script_source}"""}}},
        "size": size,
    }
    return new_query


async def open_search_query(req, vars, index_name, query=None, search_string=None, scroll=False):
    """Returns query/ search string response from opensearch.

    Args:
        req (object): request object
        vars (object): vars object
        index_name (str): index name of opensearch
        query (dict, optional): Query to opensearch. Defaults to None.
        search_string (str, optional): if search_string is provided this is taken as precedence to query param to search across cross_fields/search done
            on ngram analyzed fields. Defaults to None.
        scroll (bool, optional): for pagination /scroll_id need to be returned back for next set of results. Defaults to False.

    Returns:
        dict: json response.
    """
    L = vars["L"]
    if not index_name:
        raise Exception("Index name is required.")
    request_json = await request.json
    query = request_json.get("query", {})
    scroll = request_json.get("scroll")
    req_host = f"https://{cfg['open_search']['host']}"
    auth = (cfg["open_search"]["user"], cfg["open_search"]["cred"])
    if scroll:
        op_url = f"{req_host}/{index_name}/_search?scroll={scroll}"
    else:
        op_url = f"{req_host}/{index_name}/_search"
    process_time = time.perf_counter()
    try:
        scroll_id = req.get("scroll_id") or req.get("_scroll_id", "")
        resp_data = {}
        resp = {}
        if search_string:
            async with httpx.AsyncClient() as client:
                d = await client.get(
                    f"{req_host}/{index_name}/_mapping",
                    auth=auth,
                )
                if d.status_code == 200:
                    rb_mappings = d.json()
            if "error" in d.json():
                raise Exception(rb_mappings["error"]["reason"])
            _, rb_mappings = rb_mappings.popitem()
            rb_mappings = rb_mappings["mappings"]["properties"]
            ngram_mappings = list(filter(lambda x: "fields" in x[1] and "ngram" in x[1]["fields"], rb_mappings.items()))
            ngram_fields = [f"{field[0]}.ngram" for field in ngram_mappings]
            keyword_mappings = list(
                filter(
                    lambda x: "fields" in x[1]
                    and "keyword" in x[1]["fields"]
                    and x[1]["fields"]["keyword"].get("type", "") == "keyword",
                    rb_mappings.items(),
                )
            )
            keyword_fields = [f"{field[0]}" for field in keyword_mappings]
            fields = ngram_fields
            if index_name == "entities_return_based_data":
                other_mappings = list(
                    filter(lambda x: "fields" in x[1] and "ngram" not in x[1]["fields"], rb_mappings.items())
                )
                other_fields = [f"{field[0]}" for field in other_mappings]
                fields = ngram_fields + other_fields
            query = {
                "query": {
                    "multi_match": {
                        "query": search_string,
                        "fields": fields,
                        "type": "cross_fields",
                        "operator": "and",
                    }
                }
            }
            if keyword_fields:  # script_score function works when there are keyword fields here in this case.
                query = rebuild_score(query["query"], keyword_fields, size=req.get("size", 50))
            else:
                query.update({"size": req.get("size", 50)})
        op_url = f"{index_name}/_search"
        if scroll or scroll_id:
            op_url = f"{index_name}/_search?scroll=120s"
            if "scroll_id" in req or "_scroll_id" in req:
                async with httpx.AsyncClient() as client:
                    res = await client.post(
                        f"{req_host}/_search/scroll",
                        auth=auth,
                        json={"scroll_id": scroll_id},
                    )
                    resp = res.json()
                    return resp
        async with httpx.AsyncClient() as client:
            res = await client.post(f"{req_host}/{op_url}", auth=auth, json=query)
            if res.status_code == 200:
                resp = res.json()
                return resp
    except Exception as e:
        L.error(e)
        resp = {"success": "false", "statusCode": 400, "message": str(e)}
    resp_data.update(resp)
    L.info("--- process_time %s milli seconds ---" % (round((time.perf_counter() - process_time) * 1000, 4)))
    return resp_data


async def get_fields(req_host, index_name, auth):
    async with httpx.AsyncClient() as client:
        d = await client.get(
            f"{req_host}/{index_name}/_mapping",
            auth=auth,
        )
        if "error" in d.json():
            raise Exception("Error Response from Mappings ")
            # raise Exception(rb_mappings["error"]["reason"])
        if d.status_code == 200:
            rb_mappings = d.json()
    _, rb_mappings = rb_mappings.popitem()
    rb_mappings = rb_mappings["mappings"]["properties"]
    ngram_mappings = list(filter(lambda x: "fields" in x[1] and "ngram" in x[1]["fields"], rb_mappings.items()))
    ngram_fields = [f"{field[0]}.ngram" for field in ngram_mappings]
    keyword_mappings = list(
        filter(
            lambda x: "fields" in x[1]
            and "keyword" in x[1]["fields"]
            and x[1]["fields"]["keyword"].get("type", "") == "keyword",
            rb_mappings.items(),
        )
    )
    keyword_fields = [f"{field[0]}" for field in keyword_mappings]
    fields = ngram_fields
    return fields, keyword_fields


async def es_holdings_query(request_json, vars):
    L = vars["L"]
    date = request_json["date"]
    search_string = request_json["search_string"]
    index_name = request_json.get("index_name", "entities_holdings")
    req_host = f"https://{cfg['open_search']['host']}"
    auth = (cfg["open_search"]["user"], cfg["open_search"]["cred"])
    op_url = f"{req_host}/{index_name}/_search"
    try:
        fields, keyword_fields = await get_fields(req_host, index_name, auth)
        if len(search_string.strip()) > 0:
            query = {  # return records which has ft_id value
                "query": {
                    "bool": {
                        "must": [
                            {"exists": {"field": "ft_id"}},
                            {"range": {"start_date": {"lte": date}}},
                            {"range": {"end_date": {"gte": date}}},
                            {
                                "multi_match": {
                                    "query": search_string,
                                    "fields": fields + keyword_fields,
                                    "type": "cross_fields",
                                    "operator": "and",
                                }
                            },
                        ]
                    }
                }
            }
        else:
            query = {
                "query": {
                    "bool": {
                        "must": [
                            {"exists": {"field": "ft_id"}},
                            {"range": {"start_date": {"lte": date}}},
                            {"range": {"end_date": {"gte": date}}},
                        ]
                    }
                }
            }

        if (
            keyword_fields and len(search_string.strip()) > 0
        ):  # script_score function works when there are keyword fields here in this case.
            query = rebuild_score(query["query"], keyword_fields, size=request_json.get("size", 50))
        else:
            query.update({"size": request_json.get("size", 50)})

        async with httpx.AsyncClient() as client:
            res = await client.post(op_url, auth=auth, json=query)
            if res.status_code == 200:
                resp = res.json()
                return resp
            else:
                return {
                    "success": "false",
                    "statusCode": 500,
                    "message": f"failed querying elastic search {res.status_code}",
                }
    except Exception as e:
        L.error(e)
        resp = {"success": "false", "statusCode": 500, "message": str(e)}
        return resp
