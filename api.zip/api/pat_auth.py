from quart.blueprints import Blueprint
from quart import request
from quart.wrappers import Response
from uip_dbs_async import Db
import uip_dbs
from datetime import datetime
from datetime import timedelta
from uuid import uuid4
import pandas as pd
import json
import jwt

import uip_config

app = Blueprint(
    "pat_auth",
    __name__,
)

cfg = uip_config.ConfigDict(get_impersonators=True)

async def logLoginAttempt(collection, sid, ts):
    mdb = uip_dbs.Db("uip_meta").conn["uip"]
    doc = {"user_id": sid, "attempt_timestamp": ts}
    mdb[collection].insert_one(doc)


async def loginCount(collection, from_ts, to_ts):
    mdb = uip_dbs.Db("uip_meta").conn["uip"]
    docs = mdb[collection].distinct("user_id", {"attempt_timestamp": {"$gte": from_ts, "$lte": to_ts}})
    return len(docs)


@app.route("/api/pat/auth/access", methods=["GET"])
async def access():
    session_details = request.vars.get("attributes")
    return session_details


@app.route("/api/pat/auth/login", methods=["POST"])
async def login():
    attributes = request.vars.get("attributes")
    current_timestamp = datetime.utcnow()
    await logLoginAttempt("pat_logs", attributes.get("sid"), current_timestamp)
    session_id = f"{uuid4()}"
    expiration_timestamp = current_timestamp + timedelta(minutes=30)
    session_dict = {
        "id": session_id,
        "created": current_timestamp.isoformat(),
        "valid_to": expiration_timestamp.isoformat(),
        "attributes": attributes
    }
    secret = cfg["oauth_config"]["sessionSecret"]
    token = jwt.encode(session_dict, secret, algorithm='HS256')
    response = Response(json.dumps(attributes), mimetype="application/json")
    response.headers["x-auth-token"] = token

    return response


@app.route("/api/pat/auth/login/count/<from_>/<to>", methods=["GET"])
async def login_count(from_, to):
    from_ts = pd.to_datetime(from_)
    to_ts = pd.to_datetime(to)
    counts = await loginCount("pat_logs", from_ts, to_ts)
    return {"distinctUsersCount": counts}
