import uip_grpc

import json

import rest_pb2
import rest_pb2_grpc

from quart import request, abort
from quart.blueprints import Blueprint

from google.protobuf.json_format import MessageToJson, ParseDict, MessageToDict
from google.protobuf.struct_pb2 import Struct
from transcoder_libs import (
    process_post_data,
)

grpc_channels = uip_grpc.GRPC(async_mode=True)

app = Blueprint(
    "portfolios",
    __name__,
)

##################### Portfolio - CRUD (UIP-2583 - Begin) #####################
@app.route("/api/modelportfolio", methods=["POST"])
async def create_portfolio():
    L = request.vars["L"]
    req_payload = await request.data
    L.info("Request payload: %s", req_payload)
    portfolioSvcRes = MessageToDict(
        await rest_pb2_grpc.PortfoliosStub(grpc_channels.get_channel("portfolios")).CreatePortfolio(
            request=rest_pb2.CreatePortfolioRequest(
                app = "model_portfolios", 
                zone = "portfolio_management",
                payload=rest_pb2.JSON(str=req_payload)
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(portfolioSvcRes["str"])
    if strVal["status"] == "ok":
        return strVal
    else:
        return strVal, 500

@app.route("/api/modelportfolio/id/<oid>", methods=["GET"])
async def get_portfolio(oid):
    portfolioSvcRes = MessageToDict(
        await rest_pb2_grpc.PortfoliosStub(grpc_channels.get_channel("portfolios")).ReadPortfolio(
            request=rest_pb2.ReadPortfolioRequest(id=oid),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(portfolioSvcRes["str"])
    return strVal

@app.route("/api/modelportfolio/id/<oid>", methods=["PUT"])
async def update_portfolio(oid):
    L = request.vars["L"]
    req_payload = await request.data
    L.info("Request payload: %s", req_payload)
    portfolioSvcRes = MessageToDict(
        await rest_pb2_grpc.PortfoliosStub(grpc_channels.get_channel("portfolios")).UpdatePortfolio(
            request=rest_pb2.UpdatePortfolioRequest(
                id=oid, 
                payload=rest_pb2.JSON(str=req_payload)
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(portfolioSvcRes["str"])
    if strVal["status"] == "ok":
        return strVal
    else:
        return strVal, 500

@app.route("/api/modelportfolio/id/<oid>", methods=["DELETE"])
async def delete_portfolio(oid):
    L = request.vars["L"]
    L.info("Deleting portfolio: %s", oid)
    portfolioSvcRes = MessageToDict(
        await rest_pb2_grpc.PortfoliosStub(grpc_channels.get_channel("portfolios")).DeletePortfolio(
            request=rest_pb2.DeletePortfolioRequest(id=oid),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(portfolioSvcRes["str"])
    if strVal["status"] == "ok":
        return strVal
    else:
        return strVal, 500

@app.route("/api/modelportfolio/modelportfoliolist", methods=["GET"])
async def get_portfoliolist():
    portfolioSvcRes = MessageToDict(
        await rest_pb2_grpc.PortfoliosStub(grpc_channels.get_channel("portfolios")).FetchPortfolioList(
            request=rest_pb2.FetchPortfolioListRequest(
                app = "model_portfolios", 
                zone = "portfolio_management"
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(portfolioSvcRes["str"])
    return strVal

@app.route("/api/modelportfolio/assetlist", methods=["GET"])
async def get_portfolios_assetlist():
    portfolioSvcRes = MessageToDict(
        await rest_pb2_grpc.PortfoliosStub(grpc_channels.get_channel("portfolios")).FetchPortfoliosAssetList(
            request=rest_pb2.FetchPortfoliosAssetListRequest(
                app = "model_portfolios", 
                zone = "portfolio_management"
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(portfolioSvcRes["str"])
    return strVal

@app.route("/api/modelportfolio", methods=["GET"])
async def get_all_portfolios():
    portfolioSvcRes = MessageToDict(
        await rest_pb2_grpc.PortfoliosStub(grpc_channels.get_channel("portfolios")).FetchAllPortfolios(
            request=rest_pb2.FetchAllPortfoliosRequest(
                app = "model_portfolios", 
                zone = "portfolio_management"
            ),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    strVal = json.loads(portfolioSvcRes["str"])
    return strVal
##################### Portfolio - CRUD (UIP-2583 - End) #####################
