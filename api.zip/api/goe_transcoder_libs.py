import uip_files
import uip_config

from fastapi import Request, HTTPException
fio = uip_files.Files()

cfg = uip_config.ConfigDict()

class AbortException(HTTPException):
    def __init__(self, status_code: int, detail: str):
        super().__init__(status_code=status_code, detail=detail)


async def read_file(request:Request, file_id=None):
    """Method for reading file for given file_id"""
    if not file_id:
        AbortException(status_code=400)
    user_id = request.state.vars["metadata_d"]["user-id"]
    request.state.vars["L"].info(f"GET Request for file {file_id}")
    allowed = user_id == "ServiceUser" or await fio.check_file_access(file_id, user_id)
    if allowed:
        f = fio.ReadFile(file_id)
        if not f:
            AbortException(status_code=404)
    else:
        AbortException(status_code=404)
    response = f
    return response
