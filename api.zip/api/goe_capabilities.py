import uip_grpc
from uip_dbs_async import Db  # NOQA
import json
import uip_config
import uip_dbs

# from datetime import date
import rest_pb2_grpc
from google.protobuf.struct_pb2 import Struct

# from uip_email import EmailMsg
# from uip_email import EmailMsg
from quart import Blueprint, request
from google.protobuf.json_format import MessageToJson

# from quart.json import JSONEncoder
import rest_pb2
from goelib.api.shared.common import isDateFormatValid
from google.protobuf.json_format import MessageToDict

grpc_channels = uip_grpc.GRPC(async_mode=True)

goe_capabilities_app = Blueprint(
    "goe_capabilities",
    __name__,
)

svc_client = uip_grpc.ServiceClient()
cfg = uip_config.ConfigDict()


@goe_capabilities_app.route("/api/goe_capabilities/v1/goals", methods=["GET"])
async def svc_goals():
    L = request.vars["L"]
    L.info("GET /v1/goals ")
    L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/goals")
    # Mongodb connection -------------------------
    try:
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).FetchGoals(
                request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info("User got response for : GOE CAPABILITIES:/v1/goals {}".format(response))
        return response, response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/v1/goals {}".format(str(e)))
        return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/goalinput/<goal_id>", methods=["GET"])
async def svc_goal_data(goal_id):
    L = request.vars["L"]
    L.info("GET /v1/goalInput")
    L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/goalinput")
    # Mongodb connection -------------------------
    try:
        status_code = 200
        req = rest_pb2.GoalsInputDataRequest(
            goal_id=goal_id,
        )
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).GetGoalsInputData(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info("User got response for : GOE CAPABILITIES:/v1/goalinput {}".format(response))
        return response, response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/v1/goalinput {}".format(str(e)))
        return response, status_code


def validate_goal_payload(payload):
    if isinstance(payload.get("state"), int) and payload.get("state") is not None:
        return {"success": False, "message": "Incorrect state"}
    if isinstance(payload.get("type_of_house"), int) and payload.get("type_of_house") is not None:
        return {"success": False, "message": "Incorrect type of house"}
    if isinstance(payload.get("type_of_college"), int) and payload.get("type_of_college") is not None:
        return {"success": False, "message": "Incorrect type of college"}
    if isinstance(payload.get("type_of_program"), int) and payload.get("type_of_program") is not None:
        return {"success": False, "message": "Incorrect type of program"}
    if isinstance(payload.get("veicle_category"), int) and payload.get("veicle_category") is not None:
        return {"success": False, "message": "Incorrect vehicle category"}
    if (
        not isinstance(payload.get("include_room_and_board_cost"), bool)
        and payload.get("include_room_and_board_cost") is not None
    ):
        return {"success": False, "message": "Incorrect parameter"}
    if isDateFormatValid(payload.get("year")) is False and payload.get("year") is not None:
        return {"success": False, "message": "incorrect year"}
    return {"success": True, "message": "validated successfully !!"}


@goe_capabilities_app.route("/api/goe_capabilities/v1/goalamount", methods=["POST"])
async def svc_calculate_goal_amount():
    L = request.vars["L"]
    L.info("POST /v1/goalAmount")
    L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/goalamount {}".format(await request.json))
    request_json = await request.json
    validation = validate_goal_payload(request_json)
    if validation["success"] == False:
        status_code = 500
        return {"message": validation["message"], "statusCode": status_code}, status_code
    # Mongodb connection -------------------------
    try:
        status_code = 200
        request_json = await request.json
        req = rest_pb2.CalculateGoalAmountRequest(
            goal_id=request_json.get("goal_id"),
            state=request_json.get("state"),
            type_of_house=request_json.get("type_of_house"),
            year=request_json.get("year"),
            perc_cost=request_json.get("perc_cost"),
            type_of_college=request_json.get("type_of_college"),
            type_of_program=request_json.get("type_of_program"),
            include_room_and_board_cost=request_json.get("include_room_and_board_cost"),
            vehicle_category=request_json.get("vehicle_category"),
        )
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).CalCulateGoalAmount(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info("User got response for : GOE CAPABILITIES:/v1/goalamount {}".format(response))
        return response, response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/v1/goalAmount {}".format(str(e)))
        return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/user_goals", methods=["POST", "PUT"])
async def svc_save_user_goals():
    L = request.vars["L"]
    if request.method == "POST":
        L.info("POST /v1/user_goals ")
        L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/user_goals {}".format(await request.json))
        # MongoDB connection -------------------------
        try:
            status_code = 200
            request_json = await request.json
            goal_data = Struct()
            goal_data.update(request_json["goal_data"])
            req = rest_pb2.SaveUserGoalsRequest(client_id=request_json["client_id"], goal_data=goal_data)
            response = MessageToDict(
                await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                    grpc_channels.get_channel("goe-capabilities-portal")
                ).SaveUserGoals(
                    request=req,
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            L.info("User got response for : GOE CAPABILITIES:/v1/user_goals {}".format(response))
            return response, response["statusCode"]
        except Exception as e:
            status_code = 500
            response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
            L.info("User got error for : GOE CAPABILITIES:/v1/user_goals {}".format(str(e)))
            return response, status_code
    if request.method == "PUT":
        L.info("PUT /v1/user_goals ")
        L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/user_goals")
        try:
            status_code = 200
            request_json = await request.json
            goal_data = Struct()
            goal_data.update(request_json["goal_data"])
            req = rest_pb2.UpdateUserGoalsRequest(
                goal_id=request_json["goal_id"], client_id=request_json["client_id"], goal_data=goal_data
            )
            response = MessageToDict(
                await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                    grpc_channels.get_channel("goe-capabilities-portal")
                ).UpdateUserGoals(
                    request=req,
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            L.info("User got response for : GOE CAPABILITIES:/v1/user_goals {}".format(response))
            return response, response["statusCode"]
        except Exception as e:
            status_code = 500
            response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
            L.info("User got error for : GOE CAPABILITIES:/v1/user_goals {}".format(str(e)))
            return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/user_goals/<cid>/<gid>", methods=["DELETE"])
async def svc_delete_user_goals(cid, gid):
    L = request.vars["L"]
    L.info("DELETE /v1/user_goals/{}/{}".format(cid, gid))
    L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/user_goals")
    # MongoDB connection -------------------------
    try:
        status_code = 200
        req = rest_pb2.DeleteUserGoalsRequest(cid=cid, gid=gid)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).DeleteUserGoals(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        status_code = response["statusCode"]
        L.info("User got response for : GOE CAPABILITIES:/v1/user_goals {}".format(response))
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/v1/user_goals {}".format(str(e)))
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/user_goals/<cid>", methods=["GET", "DELETE"])
async def svc_fetch_user_goals(cid):
    L = request.vars["L"]
    if request.method == "GET":
        L.info("GET /v1/user_goals ")
        L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/user_goals")
        # MongoDB connection -------------------------
        try:
            status_code = 200
            req = rest_pb2.GetUserGoalsRequest(cid=cid)
            response = MessageToDict(
                await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                    grpc_channels.get_channel("goe-capabilities-portal")
                ).FetchUserGoals(
                    request=req,
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            L.info("User got response for : GOE CAPABILITIES:/v1/user_goals {}".format(response))
            status_code = response["statusCode"]
        except Exception as e:
            status_code = 500
            response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
            L.info("User got error for : GOE CAPABILITIES:/v1/user_goals {}".format(str(e)))
        return response, status_code
    if request.method == "DELETE":
        L.info("DELETE /v1/user_goals ")
        L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/user_goals")
        # MongoDB connection -------------------------
        try:
            status_code = 200
            req = rest_pb2.DeleteUserRequest(cid=cid)
            response = MessageToDict(
                await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                    grpc_channels.get_channel("goe-capabilities-portal")
                ).DeleteAllUserGoals(
                    request=req,
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            L.info("User got response for : GOE CAPABILITIES:/v1/user_goals {}".format(response))
            status_code = response["statusCode"]
        except Exception as e:
            status_code = 500
            response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
            L.info("User got error for : GOE CAPABILITIES:/v1/user_goals {}".format(str(e)))
        return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/portfolio_composition", methods=["GET"])
async def svc_get_all_portfolio_composition():
    L = request.vars["L"]
    L.info("GET /v1/portfolio_composition")
    L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/portfolio_composition")
    try:
        status_code = 200
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).FetchAllPortfolioCompositionDetails(
                request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info("User got response for : GOE CAPABILITIES:/v1/portfolio_composition {}".format(response))
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/v1/portfolio_composition {}".format(str(e)))
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/portfolio_composition/<pid>", methods=["GET"])
async def svc_get_portfolio_composition(pid):
    L = request.vars["L"]
    L.info("GET /v1/portfolio_composition")
    L.info("User is accessing app in UI: GOE CAPABILITIES:/v1/portfolio_composition")
    try:
        status_code = 200
        req = rest_pb2.FetchPortfolioCompositionRequest(pid=pid)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).FetchPortfolioCompositionDetails(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info("User got response for : GOE CAPABILITIES:/v1/portfolio_composition {}".format(response))
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/v1/portfolio_composition {}".format(str(e)))
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/runPipe", methods=["POST"])
async def svc_goe_cap_run_pipe_v3():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/v1/runPipe")

    req = None
    request_data = await request.json
    L.info("User is accessing for : GOE CAPABILITIES:/api/goe_capabilities/v1/runPipe {}".format(request_data))
    try:
        request_headers = Struct()
        request_headers.update(request.headers)
        req = rest_pb2.GoeApiRequest(request_json=json.dumps(request_data), request_headers=request_headers)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).CallRunPipe(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response = json.loads(response["response"])
        L.info(f"RESPONSE POST /api/goe_capabilities/v1/runPipe {response}")
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/api/goe_capabilities/v1/runPipe {}".format(str(e)))
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/runWealthSplitter", methods=["POST"])
async def svc_goe_cap_initial_wealth_splitter():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/v1/runWealthSplitter")

    req = None
    request_data = await request.json
    L.info(
        "User is accessing for : GOE CAPABILITIES:/api/goe_capabilities/v1/runWealthSplitter {}".format(request_data)
    )
    try:
        request_headers = Struct()
        request_headers.update(request.headers)
        req = rest_pb2.GoeApiRequest(request_json=json.dumps(request_data), request_headers=request_headers)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(grpc_channels.get_channel("goe-capabilities-portal")).CallIWS(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response = json.loads(response["response"])
        L.info("RESPONSE POST /api/goe_capabilities/v1/runWealthSplitter {}".format(response))
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES:/api/goe_capabilities/v1/runWealthSplitter {}".format(str(e)))
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/unifiedPortfolioAdvice", methods=["POST"])
async def svc_goe_cap_unified_portfolio_advice():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/v1/unifiedPortfolioAdvice")

    req = None
    request_data = await request.json
    L.info(
        "User is accessing for : GOE CAPABILITIES:/api/goe_capabilities/v1/unifiedPortfolioAdvice {}".format(
            request_data
        )
    )
    try:
        request_headers = Struct()
        request_headers.update(request.headers)
        req = rest_pb2.GoeApiRequest(request_json=json.dumps(request_data), request_headers=request_headers)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).CallUPAv2(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response = json.loads(response["response"])
        L.info("RESPONSE POST /api/goe_capabilities/v1/unifiedPortfolioAdvice {}".format(response))
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info(
            "User got error for : GOE CAPABILITIES:/api/goe_capabilities/v1/unifiedPortfolioAdvice {}".format(str(e))
        )
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v4/unifiedPortfolioAdvice", methods=["POST"])
async def svc_goe_capabilites_unified_portfolio_advice4():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/v4/unifiedPortfolioAdvice")

    req = None
    request_data = await request.json

    L.info(
        "User is accessing for : GOE CAPABILITIES:/api/goe_capabilities/v4/unifiedPortfolioAdvice {}".format(
            request_data
        )
    )
    try:
        request_headers = Struct()
        request_headers.update(request.headers)
        req = rest_pb2.GoeApiRequest(request_json=json.dumps(request_data), request_headers=request_headers)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).CallUPAv4(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response = json.loads(response["response"])
        L.info("RESPONSE POST /api/goe_capabilities/v4/unifiedPortfolioAdvice {}".format(response))
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info(
            "User got error for : GOE CAPABILITIES:/api/goe_capabilities/v4/unifiedPortfolioAdvice {}".format(str(e))
        )
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/socialSecurityCalculator", methods=["POST"])
async def svc_goe_cap_social_security():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/v1/socialSecurityCalculator")

    req = None
    request_data = await request.json
    L.info(
        "User is accessing for : GOE CAPABILITIES:/api/goe_capabilities/v1/socialSecurityCalculator {}".format(
            request_data
        )
    )
    try:
        request_headers = Struct()
        request_headers.update(request.headers)
        req = rest_pb2.GoeApiRequest(request_json=json.dumps(request_data), request_headers=request_headers)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(grpc_channels.get_channel("goe-capabilities-portal")).CallSS(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response = json.loads(response["response"])
        L.info(f"RESPONSE POST /api/goe_capabilities/v1/socialSecurityCalculator {response}")
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info(
            "User got error for : GOE CAPABILITIES:/api/goe_capabilities/v1/socialSecurityCalculator {}".format(str(e))
        )
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/replacementincomecalculator", methods=["POST"])
async def svc_goe_cap_retirement_income():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/v1/replacementincomecalculator")

    req = None
    request_data = await request.json
    L.info(
        "User is accessing for : GOE CAPABILITIES:/api/goe_capabilities/v1/replacementincomecalculator {}".format(
            request_data
        )
    )
    try:
        request_headers = Struct()
        request_headers.update(request.headers)
        req = rest_pb2.GoeApiRequest(request_json=json.dumps(request_data), request_headers=request_headers)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(grpc_channels.get_channel("goe-capabilities-portal")).CallRI(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        response = json.loads(response["response"])
        L.info(f"RESPONSE POST /api/goe_capabilities/v1/replacementincomecalculator {response}")
        status_code = response["statusCode"]
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info(
            "User got error for : GOE CAPABILITIES:/api/goe_capabilities/v1/replacementincomecalculator {}".format(
                str(e)
            )
        )
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/user_info/<app_id>/zone/<zone_id>", methods=["PUT"])
async def svc_save_user_info(app_id, zone_id):
    L = request.vars["L"]
    L.info("PUT /api/goe_capabilities/v1/user_info/{}/zone/{}".format(app_id, zone_id))
    L.info(
        "User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/v1/user_info/{}/zone/{} {}".format(
            app_id, zone_id, await request.json
        )
    )
    try:
        status_code = 200
        request_json = await request.json
        user_details = Struct()
        user_details.update(request_json["user_details"])
        req = rest_pb2.SaveUsersBasicInformationRequest(
            path=request.args.get("path", None), app_id=app_id, zone_id=zone_id, user_details=user_details
        )
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).SaveUsersBasicInformationDetails(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info(
            "User got response for : GOE CAPABILITIES:/api/goe_capabilities/v1/user_info/{}/zone/{} {}".format(
                app_id, zone_id, str(response)
            )
        )
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info(
            "User got error for : GOE CAPABILITIES:/api/goe_capabilities/v1/user_info/{}/zone/{} {}".format(
                app_id, zone_id, str(e)
            )
        )
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/v1/user_info/<app_id>/zone/<zone_id>", methods=["GET"])
async def svc_fetch_user_info(app_id, zone_id):
    L = request.vars["L"]

    L.info("GET /api/goe_capabilities/v1/user_info/{}/zone/{}".format(app_id, zone_id))
    L.info(
        "User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/v1/user_info/{}/zone/{}".format(
            app_id, zone_id
        )
    )
    try:
        status_code = 200
        req = None
        users = request.args.get("users", "").strip()
        if users != "":
            users = users.split(",")
            req = rest_pb2.AppUserSettingsRequest(user_ids=users)
        else:
            emails = request.args.get("emails", "").strip()
            if emails != "":
                emails = emails.split(",")
                req = rest_pb2.AppUserSettingsRequest(emails=emails)

        userData = MessageToJson(
            await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).GetAppSettingsForUsers(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        user_id = request.vars["metadata_d"]["user-id"]
        userData = json.loads(userData)[user_id]["app_settings"][app_id][zone_id]
        response = {"body": userData, "message": "Success", "statusCode": status_code}
        L.info(
            "User got response for : GOE CAPABILITIES :/api/goe_capabilities/v1/user_info/{}/zone/{} {}".format(
                app_id, zone_id, str(response)
            )
        )
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info(
            "User got error for : GOE CAPABILITIES :/api/goe_capabilities/v1/user_info/{}/zone/{} {}".format(
                app_id, zone_id, str(e)
            )
        )
    return response, status_code


# @goe_capabilities_app.route("/api/goe_capabilities/v1/getUsers", methods=["POST"])
# async def svc_goe_cap_get_users():
#     L = request.vars["L"]
#     L.info("POST /api/goe_capabilities/v1/getUsers")
#     request_json = await request.json
#     L.info("User is accessing for : GOE CAPABILITIES:/api/goe_capabilities/v1/getUsers {}".format(request_json))
#     url = cfg["goe_capabilities_showcase_portal"]["get_users_url"]
#     res = await call_goe_apis(request_json, url)
#     get_signle_user = list(filter(lambda user_list: user_list["email"] == request_json["email"], res["data"]))
#     res["data"] = get_signle_user
#     L.info("RESPONSE POST /api/goe_capabilities/v1/getUsers {}".format(res))
#     return res


@goe_capabilities_app.route("/api/goe_capabilities/adduser", methods=["POST"])
async def svc_goe_cap_add_user():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/goe_capabilities/adduser {request_json}")

    req = rest_pb2.GoeCapabilitiesPortalUserRequest(
        first_name=request_json["first_name"],
        last_name=request_json.get("last_name", ""),
        email=request_json["email"],
        phone_number=request_json["phone_number"],
        client=request_json["client"],
        goe_config_email=request_json["goe_config_email"],
        api_limit=request_json["api_limit"],
        client_limit=request_json["client_limit"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeCapabilitiesPortalStub(grpc_channels.get_channel("goe-capabilities-portal")).CreateUser(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )

    L.info(f"Response /api/goe_capabilities/adduser {res}")
    return res


@goe_capabilities_app.route("/api/goe_capabilities/users", methods=["GET"])
async def svc_goe_capabilities_get_users_with_access():
    L = request.vars["L"]

    L.info("POST /api/goe_capabilities/users")

    res = MessageToDict(
        await rest_pb2_grpc.GoeCapabilitiesPortalStub(grpc_channels.get_channel("goe-capabilities-portal")).GetUsers(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/goe_capabilities/users {res}")
    return res


@goe_capabilities_app.route("/api/goe_capabilities/clients", methods=["GET"])
async def svc_goe_capabilities_get_clients_with_access():
    L = request.vars["L"]

    L.info("POST /api/goe_capabilities/clients")

    res = MessageToDict(
        await rest_pb2_grpc.GoeCapabilitiesPortalStub(grpc_channels.get_channel("goe-capabilities-portal")).GetUsers(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/goe_capabilities/users {res}")
    return res


@goe_capabilities_app.route("/api/goe_capabilities/update_access", methods=["POST"])
async def svc_goe_capabilities_update_access():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/goe_capabilities/update_access {request_json}")

    req = rest_pb2.AccessUpdateRequest()

    action = 0
    if request_json["action"] == "active":
        action = 1

    req.updates.append(
        rest_pb2.AccessUpdate(
            app="goe-capabilities",
            zone=request_json["zone"],
            type="active",
            user_id=request_json["user_id"],
            access_type=1,
            action=action,
        )
    )
    res = MessageToDict(
        await rest_pb2_grpc.AdminStub(grpc_channels.get_channel("admin")).UpdateAccess(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )
    if res.get("success"):
        status_code = 200
        response = {"success": True, "message": "user access updated", "statusCode": status_code}
    else:
        status_code = 500
        response = {"success": False, "message": "update access failed", "statusCode": status_code}
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/basic-info", methods=["POST"])
async def svc_goe_cap_basic_info():
    L = request.vars["L"]

    request_json = await request.json
    L.info(f"POST /api/goe_capabilities/basic-info {request_json}")

    logged_in_user_id = request.vars["metadata_d"]["user-id"]

    req = rest_pb2.GoeCapabilitiesPortalBasicInfoRequest(
        advisor_id=logged_in_user_id,
        full_name=request_json["full_name"],
        dob=request_json["dob"],
        gender=request_json["gender"],
        risk_profile=request_json["risk_profile"],
    )

    res = MessageToDict(
        await rest_pb2_grpc.GoeCapabilitiesPortalStub(
            grpc_channels.get_channel("goe-capabilities-portal")
        ).SaveBasicInfo(
            request=req,
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )
    L.info(f"Response /api/goe_capabilities/basic-info {res}")
    return res


@goe_capabilities_app.route("/api/goe_capabilities/search/clients/<full_name>", methods=["GET"])
async def svc_goe_cap_search_clients(full_name):
    L = request.vars["L"]
    L.info("GET /api/goe_capabilities/search/clients/{}".format(full_name))
    L.info("User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/search/clients/{}".format(full_name))
    logged_in_user_id = request.vars["metadata_d"]["user-id"]
    try:
        status_code = 200
        req = rest_pb2.GoeCapabilitiesPortalBasicInfoRequest(advisor_id=logged_in_user_id, full_name=full_name)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).SearchClient(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info(
            "User got response for : GOE CAPABILITIES :/api/goe_capabilities/search/clients/{}".format(str(response))
        )
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got response for : GOE CAPABILITIES :/api/goe_capabilities/search/clients/{}".format(str(e)))
    return response, status_code


# @goe_capabilities_app.route("/api/goe_capabilities/list/clients/<advisor_id>", methods=["GET"])
@goe_capabilities_app.route("/api/goe_capabilities/list/clients", methods=["GET"])
# async def svc_goe_cap_list_clients(advisor_id):
async def svc_goe_cap_list_clients():
    L = request.vars["L"]
    # L.info("GET /api/goe_capabilities/list/clients/{}".format(advisor_id))
    L.info("GET /api/goe_capabilities/list/clients")
    # L.info("User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/list/clients/{}".format(advisor_id))
    L.info("User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/list/clients")
    logged_in_user_id = request.vars["metadata_d"]["user-id"]
    try:
        status_code = 200
        # req = rest_pb2.GoeCapabilitiesPortalBasicInfoRequest(advisor_id=logged_in_user_id, advisor_id=advisor_id)
        req = rest_pb2.GoeCapabilitiesPortalBasicInfoRequest(advisor_id=logged_in_user_id)
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).GetListClients(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info("User got response for : GOE CAPABILITIES :/api/goe_capabilities/list/clients/{}".format(str(response)))
    except Exception as e:
        status_code = 500
        # response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        response = {
            "message": "Unexpected error: Please contact FT GOE Business team.",
            "statusCode": status_code,
            "error": str(e),
        }
        L.info("User got response for : GOE CAPABILITIES :/api/goe_capabilities/list/clients/{}".format(str(e)))
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/list/clients/filtered", methods=["GET", "POST"])
# @goe_capabilities_app.route("/api/goe_capabilities/list/clients/filtered", methods=["POST", "PUT"])
async def svc_goe_cap_list_clients_filtered():
    L = request.vars["L"]
    if request.method == "GET":
        # L.info("GET /api/goe_capabilities/list/clients/{}".format(advisor_id))
        L.info("GET /api/goe_capabilities/list/clients/filtered")
        # L.info("User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/list/clients/{}".format(advisor_id))
        L.info("User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/list/clients/filtered")
        logged_in_user_id = request.vars["metadata_d"]["user-id"]
        try:
            status_code = 200
            # req = rest_pb2.GoeCapabilitiesPortalBasicInfoRequest(advisor_id=logged_in_user_id, advisor_id=advisor_id)
            req = rest_pb2.GoeCapabilitiesPortalBasicInfoRequest(advisor_id=logged_in_user_id)
            response = MessageToDict(
                await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                    grpc_channels.get_channel("goe-capabilities-portal")
                ).GetListClients(
                    request=req,
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            # L.info("User got response for : GOE CAPABILITIES :/api/goe_capabilities/list/clients/{}".format(str(response)))
            L.info("User got response for : GOE CAPABILITIES :/api/goe_capabilities/list/clients/filtered")
        except Exception as e:
            status_code = 500
            # response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
            response = {
                "message": "Unexpected error: Please contact FT GOE Business team.",
                "statusCode": status_code,
                "error": str(e),
            }
            L.info("User got response for : GOE CAPABILITIES :/api/goe_capabilities/list/clients/filtered")
        return response, status_code
    if request.method == "POST":
        L.info("POST /api/goe_capabilities/list/clients/filtered")
        # MongoDB connection -------------------------
        try:
            status_code = 200
            request_json = await request.json
            L.info(
                "User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/list/clients/filtered {}".format(
                    request_json
                )
            )
            logged_in_user_id = request.vars["metadata_d"]["user-id"]
            req = rest_pb2.GoeCapabilitiesPortalListClientsFilteredRequest(
                advisor_id=logged_in_user_id,
                goal_key=request_json.get("goal_key", ""),
                goal_priority=request_json.get("goal_priority", ""),
                risk_profile=request_json.get("risk_profile", ""),
                goal_amt_min=request_json.get("goal_amt_min", ""),
                goal_amt_max=request_json.get("goal_amt_max", ""),
                goal_type=request_json.get("goal_type", ""),
                goal_creation_date_min=request_json.get("goal_creation_date_min", ""),
                goal_creation_date_max=request_json.get("goal_creation_date_max", ""),
                user_name_search=request_json.get("user_name_search", ""),
            )
            response = MessageToDict(
                await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                    grpc_channels.get_channel("goe-capabilities-portal")
                ).GetListClientsFiltered(
                    request=req,
                    metadata=request.vars["metadata_t"],
                ),
                preserving_proto_field_name=True,
            )
            L.info(
                "User got response for : GOE CAPABILITIES:/api/goe_capabilities/list/clients/filtered {}".format(
                    response
                )
            )
            return response, response["statusCode"]
        except Exception as e:
            status_code = 500
            response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
            L.info(
                "User got error for : GOE CAPABILITIES:/api/goe_capabilities/list/clients/filtered {}".format(str(e))
            )
            return response, status_code
    # if request.method == "PUT":
    #     L.info("PUT /api/goe_capabilities/list/clients/filtered ")
    #     L.info("User is accessing app in UI: GOE CAPABILITIES:/api/goe_capabilities/list/clients/filtered")
    #     try:
    #         status_code = 200
    #         request_json = await request.json
    #         goal_data = Struct()
    #         goal_data.update(request_json["goal_data"])
    #         req = rest_pb2.UpdateUserGoalsRequest(
    #             goal_id=request_json["goal_id"], client_id=request_json["client_id"], goal_data=goal_data
    #         )
    #         response = MessageToDict(
    #             await rest_pb2_grpc.GoeCapabilitiesPortalStub(
    #                 grpc_channels.get_channel("goe-capabilities-portal")
    #             ).UpdateUserGoals(
    #                 request=req,
    #                 metadata=request.vars["metadata_t"],
    #             ),
    #             preserving_proto_field_name=True,
    #         )
    #         L.info("User got response for : GOE CAPABILITIES:/api/goe_capabilities/list/clients/filtered {}".format(response))
    #         return response, response["statusCode"]
    #     except Exception as e:
    #         status_code = 500
    #         response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
    #         L.info("User got error for : GOE CAPABILITIES:/api/goe_capabilities/list/clients/filtered {}".format(str(e)))
    #         return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/client", methods=["PUT"])
async def svc_goe_cap_client_info():
    L = request.vars["L"]
    if request.method == "PUT":
        request_json = await request.json
        L.info(f"POST /api/goe_capabilities/client {request_json}")

        logged_in_user_id = request.vars["metadata_d"]["user-id"]

        req = rest_pb2.GoeCapabilitiesPortalClientsPut(
            advisor_id=logged_in_user_id,
            client_id=request_json.get("client_id"),
            is_favorite=request_json.get("is_favorite"),
        )

        res = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).GetClientInfo(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info(f"Response /api/goe_capabilities/client {res}")
        return res


@goe_capabilities_app.route("/api/goe_capabilities/goal", methods=["PUT"])
async def svc_goe_cap_goal_info():
    L = request.vars["L"]
    if request.method == "PUT":
        request_json = await request.json
        L.info(f"POST /api/goe_capabilities/goal {request_json}")

        logged_in_user_id = request.vars["metadata_d"]["user-id"]

        request_json_values = Struct()
        request_json_values.update(request_json.get("values", {}))
        req = rest_pb2.GoeCapabilitiesPortalGoalsPut(
            advisor_id=logged_in_user_id,
            goal_id=request_json["goal_id"],
            action=request_json["action"],
            values=request_json_values,
        )
        res = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).GetGoalInfo(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info(f"Response /api/goe_capabilities/goal {res}")
        return res


@goe_capabilities_app.route("/api/goe_capabilities/send_access_request", methods=["POST"])
async def svc_goe_capabilities_send_access_request():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/send_access_request")

    try:
        status_code = 200
        metadata = request.vars["metadata_d"]
        email = metadata["email"]
        user_full_name = metadata["user-full-name"]
        atts = []
        conn = uip_dbs.Db("uip_meta_reader").conn["uip"]["goe-capabilities-settings"]
        recipients = conn.find_one({"_id": "recipients_list"}, {"_id": 0, "users": 1})
        req = rest_pb2.GoeCapEmailRequest(
            from_addr=metadata["email"],
            to_addr=", ".join(recipients["users"]),
            subject="Access Request: GOE Capabilities Tool",
            content=f"{user_full_name} ({email}) has requested access to the GOE Capabilities Tool.",
            attachments=atts,
        )
        op = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).SendEmail(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )

        response = {"message": "Email sent", "body": op}
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES :/api/goe_capabilities/send_access_request/ {}".format(str(e)))
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/send_registration_request", methods=["POST"])
async def svc_goe_capabilities_send_registration_request():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/send_registration_request")
    request_json = await request.json
    try:
        status_code = 200
        from_email = request_json.get("sender_email")
        atts = []
        conn = uip_dbs.Db("uip_meta_reader").conn["uip"]["goe-capabilities-settings"]
        recipients = conn.find_one({"_id": "recipients_list"}, {"_id": 0, "application_email": 1})
        req = rest_pb2.GoeCapEmailRequest(
            from_addr=from_email,
            to_addr=recipients["application_email"],
            subject="New User Registration Request: GOE Capabilities Tool",
            content=f"{from_email} has requested access to the GOE Capabilities Tool.",
            attachments=atts,
        )
        op = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).SendEmail(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )

        response = {"message": "Email sent", "body": op}
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info(
            "User got error for : GOE CAPABILITIES :/api/goe_capabilities/send_registration_request/ {}".format(str(e))
        )
    return response, status_code


@goe_capabilities_app.route("/api/goe_capabilities/save_proposal", methods=["POST"])
async def svc_goe_capabilities_save_proposal():
    L = request.vars["L"]
    L.info("POST /api/goe_capabilities/save_proposal")
    request_json = await request.json
    try:
        status_code = 200
        print(list(request_json["goal_ids"]))
        proposal_request = Struct()
        proposal_request.update(request_json["request"])
        proposal_response = Struct()
        proposal_response.update(request_json["response"])
        req = rest_pb2.GoeCapabilitiesSaveProposalRequest(
            request=proposal_request,
            response=proposal_response,
            api_name=request_json["api_name"],
            client_id=request_json["client_id"],
            obj_id=request_json["obj_id"],
        )
        req.goal_ids.extend(list(request_json["goal_ids"]))
        req.SerializeToString()
        response = MessageToDict(
            await rest_pb2_grpc.GoeCapabilitiesPortalStub(
                grpc_channels.get_channel("goe-capabilities-portal")
            ).SaveProposal(
                request=req,
                metadata=request.vars["metadata_t"],
            ),
            preserving_proto_field_name=True,
        )
        L.info("User got response for : GOE CAPABILITIES :/api/goe_capabilities/save_proposal{}".format(str(response)))

        response = {"message": "Propsal Saved", "body": response}
    except Exception as e:
        status_code = 500
        response = {"message": "Unexpected error: Please contact FT GOE Business team.", "statusCode": status_code}
        L.info("User got error for : GOE CAPABILITIES :/api/goe_capabilities/send_access_request/ {}".format(str(e)))
    return response, status_code
