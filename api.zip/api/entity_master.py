import json
import uip_grpc
import time
import httpx

import rest_pb2
import rest_pb2_grpc
import uip_config

from quart.blueprints import Blueprint
from quart import request, make_response

from google.protobuf.json_format import MessageToJson, ParseDict, MessageToDict
from transcoder_libs import process_post_data, open_search_query
from google.protobuf.struct_pb2 import Struct

grpc_channels = uip_grpc.GRPC(async_mode=True)

app = Blueprint(
    "entity_master",
    __name__,
)

cfg = uip_config.ConfigDict()

rb_cache_ttl = 0
rb_mappings = []


@app.route("/api/entity-master/fields", methods=["GET"])
async def svc_em_fields():
    L = request.vars["L"]

    L.info("GET request for entity-master fields")

    return MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).GetFields(
            request=rest_pb2.google_dot_protobuf_dot_empty__pb2.Empty(),
            metadata=request.vars["metadata_t"],
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/entity-master/entities", methods=["GET"])
@app.route("/api/entity-master/entities/<entity_id>", methods=["GET"])
async def svc_em_entities(entity_id=None):
    L = request.vars["L"]

    req = rest_pb2.EntitiesRequest()

    json_obj = request.args.to_dict()
    if json_obj:
        req = ParseDict(json_obj, req)
    if request.args:
        req = ParseDict(request.args, req)

    if req.page_size == 0:
        req.page_size = 50

    if entity_id:
        L.info(f"GET request for entity: {entity_id}")

        req.entity_id = int(entity_id)
        x = await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).GetEntity(
            request=req, metadata=request.vars["metadata_t"]
        )
        json_data = MessageToDict(
            x,
            preserving_proto_field_name=True,
        )
        data = await make_response(json_data)
        data.headers.set("Content-Type", "application/json")
        return data
    else:
        L.info(
            (
                f"GET request for entities, Page: {req.page}, Page size: {req.page_size}"
                f", Filters: {req.filters}, Fields: {req.include_fields}"
                f", Exclude Fields: {req.exclude_fields}, Sort Fields: {req.sort_fields}"
            ),
        )
        json_data = MessageToJson(
            await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).GetEntities(
                request=req, metadata=request.vars["metadata_t"]
            ),
            preserving_proto_field_name=True,
        )
        data = await make_response(json_data)
        data.headers.set("Content-Type", "application/json")
        return data


@app.route("/api/entity-master/esquery", methods=["POST"])
async def svc_em_es_query():
    L = request.vars["L"]
    start_time = time.perf_counter()
    req = await request.json
    L.info(f"Requested for /api/entity-master/esquery {req}")
    json_data = MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).EsQueryResults(
            request=rest_pb2.JSON(str=json.dumps(req)), metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )
    data = await make_response(json_data)
    data.headers.set("Content-Type", "application/json")
    L.info("--- total_time %s milli seconds ---" % (round((time.perf_counter() - start_time) * 1000, 4)))
    return data


@app.route("/api/entity-master/return-based", methods=["POST"])
async def svc_em_return_based():
    global rb_cache_ttl
    global rb_mappings
    L = request.vars["L"]
    start_time = time.perf_counter()
    request_json = await request.json
    L.info(f"Requested for /api/entity-master/return-based {request_json}")
    index_name = "entities_return_based_data"
    query = request_json.get("query", {})
    scroll = request_json.get("scroll")
    search_string = request_json.get("search_string")
    req_host = f"https://{cfg['open_search']['host']}"
    auth = (cfg["open_search"]["user"], cfg["open_search"]["cred"])
    if not query and search_string != "":
        if time.time() > rb_cache_ttl:
            async with httpx.AsyncClient() as client:
                mappings = await client.get(
                    f"{req_host}/{index_name}/_mapping",
                    auth=auth,
                )
                if mappings.status_code == 200:
                    rb_mappings = mappings.json()
            if "error" in mappings.json():
                raise Exception(rb_mappings["error"]["reason"])
            _, rb_mappings = rb_mappings.popitem()
            rb_mappings = rb_mappings["mappings"]["properties"]
            rb_cache_ttl = time.time() + 60
        ngram_mappings = list(filter(lambda x: "fields" in x[1] and "ngram" in x[1]["fields"], rb_mappings.items()))
        other_mappings = list(filter(lambda x: "fields" in x[1] and "ngram" not in x[1]["fields"], rb_mappings.items()))
        ngram_fields = [f"{field[0]}.ngram" for field in ngram_mappings]
        other_fields = [f"{field[0]}" for field in other_mappings]
        fields = ngram_fields + other_fields
        query = {
            "query": {
                "multi_match": {
                    "query": search_string,
                    "fields": fields,
                    "type": "cross_fields",
                    "operator": "and",
                }
            }
        }

    res = await open_search_query(
        request_json, request.vars, index_name, query=query, search_string=search_string, scroll=scroll
    )
    try:
        entities = []
        total_records = 0
        if res.get("hits"):
            entities = [entity["_source"] for entity in res["hits"]["hits"]]
            total_records = res["hits"]["total"]["value"]
        scroll_id = res.get("_scroll_id", "") or res.get("scroll_id", "")
        resp = {
            "entities": entities,
            "total_records": total_records,
            "success": "true",
            "statusCode": 200,
        }
        if scroll_id:
            resp.update({"scroll_id": scroll_id})
    except Exception as e:
        L.error(e)
        resp = {"success": "false", "statusCode": 400, "message": str(e)}

    data = await make_response(resp)
    data.headers.set("Content-Type", "application/json")
    L.info("--- total_time %s milli seconds ---" % (round((time.perf_counter() - start_time) * 1000, 4)))
    return data


@app.route("/api/entity-master/map-entities", methods=["POST"])
async def svc_em_map_entities():
    L = request.vars["L"]

    L.info("Map entities request")

    data = await process_post_data(request)
    L.debug(data)

    req = rest_pb2.MappingRequest()
    req = ParseDict(data, req)

    # req.date = data.get("date", "")
    # req.id_date = data.get("id_date", "")
    # req.fetch_ids = data.get("fetch_ids", "")
    # for update in data["updates"]:
    #     req.updates.append(
    #         rest_pb2.AccessUpdate(
    #             app=update[0],
    #             zone=update[1],
    #             type=update[2],
    #             user_id=update[3],
    #             action=update[4],
    #         )
    #     )
    # for user_id, info in data.get("user_info", {}).items():
    #     pui = req.user_info[user_id]
    #     pui = ParseDict(info, pui)


@app.route("/api/entity-master/conflict-entities/<em_conflict_id>", methods=["GET"])
async def svc_em_conflict_entity(em_conflict_id):
    L = request.vars["L"]

    req = rest_pb2.ConflictEntitiesRequest()

    json_obj = await request.json
    if json_obj:
        req = ParseDict(json_obj, req)
    if request.args:
        req = ParseDict(request.args, req)

    L.info(f"GET request for conflict-entity: {em_conflict_id}")

    req.em_conflict_id = int(em_conflict_id)
    return MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).GetConflictEntity(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/entity-master/conflict-entities", methods=["GET"])
async def svc_em_conflict_entities():
    L = request.vars["L"]

    req = rest_pb2.ConflictEntitiesRequest()

    json_obj = await request.json
    if json_obj:
        req = ParseDict(json_obj, req)
    if request.args:
        req = ParseDict(request.args, req)

    L.info(f"GET request for conflict-entities, Fields: {req.include_fields}, Exclude Fields: {req.exclude_fields}")
    return MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).GetConflictEntities(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/entity-master/conflict-entities-resolve", methods=["POST"])
async def svc_em_resolve_conflict_entities():
    L = request.vars["L"]

    req = rest_pb2.ResolveConflictEntitiesRequest()

    json_obj = await request.json
    if json_obj:
        req = ParseDict(json_obj, req)
    if request.args:
        req = ParseDict(request.args, req)

    L.info(f"GET request for resolve-conflict-entity {1}")

    return MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).ResolveConflictEntities(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )


@app.route("/api/entity-master/entities", methods=["PUT"])
async def svc_em_add_entity():
    req = rest_pb2.Entity()

    json_obj = await request.json
    if json_obj:
        req = ParseDict(json_obj, req)
    json_data = MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).UpdateEntity(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )
    data = await make_response(json_data)
    data.headers.set("Content-Type", "application/json")
    return data


@app.route("/api/entity-master/entities/<entity_id>", methods=["DELETE"])
async def svc_em_delete_entity(entity_id):
    req = rest_pb2.DeleteEntityRequest()
    req.entity_id = int(entity_id)
    json_obj = await request.json
    if json_obj:
        req = ParseDict(json_obj, req)
    json_data = MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).DeleteEntity(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )
    data = await make_response(json_data)
    data.headers.set("Content-Type", "application/json")
    return data


# @app.route("/api/es/query", methods=["POST"])
# async def svc_es_query():
#     json_obj = await request.json
#     doc = Struct()
#     doc.update(json_obj["document"])
#     req = rest_pb2.UpdateEsRecRequest(doc_id=json_obj["doc_id"], document=doc, index_name="model_portfolio")
#     json_data = MessageToJson(
#         await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).UpdateEsRecord(
#             request=req, metadata=request.vars["metadata_t"]
#         ),
#         preserving_proto_field_name=True,
#     )
#     data = await make_response(json_data)
#     data.headers.set("Content-Type", "application/json")
#     return data


@app.route("/api/es", methods=["POST"])
async def svc_es_add_record():
    json_obj = await request.json
    doc = Struct()
    doc.update(json_obj["document"])
    req = rest_pb2.UpdateEsRecRequest(doc_id=json_obj["doc_id"], document=doc, index_name="model_portfolio")
    json_data = MessageToJson(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).UpdateEsRecord(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )
    data = await make_response(json_data)
    data.headers.set("Content-Type", "application/json")
    return data


@app.route("/api/es/<index_name>/<doc_id>", methods=["DELETE"])
async def svc_es_delete_record(index_name, doc_id):
    req = rest_pb2.DeleteEsRecRequest(doc_id=doc_id, index_name="model_portfolio")

    json_data = MessageToDict(
        await rest_pb2_grpc.EntityMasterStub(grpc_channels.get_channel("entity-master")).DeleteEsRecord(
            request=req, metadata=request.vars["metadata_t"]
        ),
        preserving_proto_field_name=True,
    )
    status_code = 200
    if "error" in json_data and "NotFoundError(404" in json_data["error"]:
        status_code = 404
    data = await make_response(json_data)
    data.headers.set("Content-Type", "application/json")
    return data, status_code
