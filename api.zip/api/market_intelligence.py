from quart.blueprints import Blueprint
from quart import request
import httpx
import uip_config

cfg = uip_config.ConfigDict()

app = Blueprint("market_intelligence", __name__)


def prep_product_query(params: dict):
    """
    query rule: universe AND source AND (remaining) fields are AND
    """
    or_query_list = list()
    and_query_list = list()
    not_query_list = list()
    if params.get("name", None):
        or_query_list.append({"term": {"name.keyword": params.get("name").lower()}})
    if params.get("partial_name", None):
        words = params.get("partial_name").split(" ")
        or_query_list.append(
            {"bool": {"must": [{"term": {"name.ngram": i.lower()}} for i in words if i.strip() != ""]}}
        )
    if params.get("ticker", None):
        or_query_list.append({"term": {"ticker.keyword": params.get("ticker").lower()}})
    if params.get("partial_ticker", None):
        or_query_list.append({"term": {"ticker.ngram": params.get("partial_ticker").lower()}})
    if params.get("id", None):
        # Split the id on the comma and then convert to lwercase as before and then pass on to multiple terms query
        multiple_ids = [id_.lower().strip() for id_ in params.get("id").split(",")]
        or_query_list.append({"terms": {"id.keyword": multiple_ids}})
        # or_query_list.append({"term": {"id.keyword": params.get("id").lower()}})
    if params.get("cusip", None):
        or_query_list.append({"term": {"cusip.keyword": params.get("cusip").lower()}})
    if params.get("universe", None):
        and_query_list.append({"match": {"universe": params.get("universe").lower()}})
    if params.get("source", None):
        and_query_list.append({"match": {"source": params.get("source").lower()}})
    if params.get("exclude_universe", None):
        not_query_list.append({"match": {"universe": params.get("exclude_universe").lower()}})
    if params.get("fund_id", None):
        or_query_list.append({"term": {"fund_id.keyword": params.get("fund_id").lower()}})
    return {
        "query": {
            "bool": {
                "must": [*and_query_list, {"bool": {"must_not": not_query_list}}, {"bool": {"should": or_query_list}}]
            }
        },
        "size": params.get("size", 100),
    }


@app.route("/api/pat/mi/search", methods=["GET"])
async def list_products():
    L = request.vars["L"]
    index_name = cfg["open_search"]["search_indexes"]["mi_product_index_name"]
    op_url = f"https://{cfg['open_search']['host']}/{index_name}/_search"
    request_args = request.args
    query = prep_product_query(request_args)
    L.info(f"search query: {query}")
    async with httpx.AsyncClient() as client:
        resp = await client.post(op_url, json=query, auth=(cfg["open_search"]["user"], cfg["open_search"]["cred"]))
        data = resp.json()
    if "error" in data:
        err = data["error"]["root_cause"][0]["reason"]
        L.error(f"\nerror resp from ES query: **** {err} ****\n{query}")
        return {"results": []}
    else:
        return {"results": [h["_source"] for h in data["hits"]["hits"]]}
