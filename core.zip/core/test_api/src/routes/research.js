import express from "express";
import { fundAnalyzer, fields } from "../mocks/research.js";

const router = express.Router();

router.get("/api/research/analyzer", (req, res) => {
  console.log("Get fund analyzer");
  res.json({ records: fundAnalyzer });
});

router.get("/api/research/analyzer/fields", (req, res) => {
  console.log("Get fund analyzer fields");
  res.json({ fields: fields });
});

export default router;
