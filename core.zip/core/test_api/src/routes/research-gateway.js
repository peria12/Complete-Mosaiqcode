import express from "express";
import { fields } from "../mocks/fields.js";
import {
  recommendations,
  next_recommendation_id,
} from "../mocks/recommendations.js";
const router = express.Router();

let recs = [...recommendations];
let next_rec_id = next_recommendation_id;

router.get("/api/research-gateway/fields", (req, res) => {
  console.log("get fields");
  res.json(fields);
});

router.get("/api/research-gateway/entries", (req, res) => {
  console.log("get rec");
  res.json({ entries: recs });
});

router.get("/api/research-gateway/entries/:id", (req, res) => {
  console.log("get rec: " + req.params.id);
  res.json(recs.find((x) => x._id == req.params.id));
});

router.delete("/api/research-gateway/entries/:id", (req, res) => {
  console.log("delete rec: " + req.params.id);
  recs = recs.filter((x) => x._id != req.params.id);
  res.json({});
});

router.put("/api/research-gateway/entries/:id", (req, res) => {
  console.log("put rec: " + req.params.id);
  recs = recs.map((x) => (x._id == req.params._id ? req.body : x));
  res.json({});
});

router.post("/api/research-gateway/entries", (req, res) => {
  console.log("post rec: ", req.body, next_rec_id);
  let new_rec = { ...req.body, _id: next_rec_id++ };
  recs.push(new_rec);
  res.json(new_rec);
});

export default router;
