export const fields = {
  stats: [
    {
      id: "return",
      title: "Return",
    },
    {
      id: "risk",
      title: "Risk",
    },
    {
      id: "alpha",
      title: "Alpha",
    },
    {
      id: "beta",
      title: "Beta",
    },
    {
      id: "sharpe",
      title: "Sharpe",
    },
    {
      id: "tracking_error",
      title: "Tracking Error",
    },
    {
      id: "information_ratio",
      title: "Information Ratio",
    },
    {
      id: "upside_capture",
      title: "Upside Capture",
    },
    {
      id: "downside_capture",
      title: "Downside Capture",
    },
    {
      id: "when_benchmark_is",
      title: "When Benchmark is",
    },
    {
      id: "benchmark_months",
      title: "Benchmark % Months",
    },
    {
      id: "outperformance_hit_rate",
      title: "Outperformance Hit Rate",
    },
    {
      id: "avg_relative_performance",
      title: "Avg Relative Performance",
    },
    {
      id: "median_relative_performance",
      title: "Median Relative Performance",
    },
  ],
  rolling: [
    {
      id: "outperformance",
      title: "Outperformance",
    },
    {
      id: "hit_rate",
      title: "Hit Rate",
    },
    {
      id: "average_outperformance",
      title: "Average Outperformance",
    },
    {
      id: "average_underperformance",
      title: "Average Underperformance",
    },
  ],
};

export const fundAnalyzer = [
  {
    id: "10_years",
    title: "Last 10 Year Stats ",
    portfolio: {
      return: "9.28%",
      risk: "16.65%",
      alpha: "1.87%",
      beta: 1.07,
      sharpe: 0.55,
      tracking_error: "5.99%",
      information_ratio: 0.4,
      upside_capture: "108%",
      downside_capture: "98%",
      when_benchmark_is: "Up",
      benchmark_months: "60%",
      outperformance_hit_rate: "56%",
      avg_relative_performance: "0.26%",
      median_relative_performance: "0.20%",
      rolling: [
        {
          id: "3month",
          title: "Rolling 3M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
        {
          id: "6month",
          title: "Rolling 6M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
        {
          id: "12month",
          title: "Rolling 12M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
      ],
    },
    benchmark: {
      return: "9.28%",
      risk: "16.65%",
      information_ratio: 0.4,
      when_benchmark_is: "Up",
      benchmark_months: "60%",
      outperformance_hit_rate: "56%",
      avg_relative_performance: "0.26%",
      median_relative_performance: "0.20%",
    },
  },
  {
    id: "5_years",
    title: "Last 5 Year Stats ",
    portfolio: {
      return: "9.28%",
      risk: "16.65%",
      alpha: "1.87%",
      beta: 1.07,
      sharpe: 0.55,
      tracking_error: "5.99%",
      information_ratio: 0.4,
      upside_capture: "108%",
      downside_capture: "98%",
      when_benchmark_is: "Up",
      benchmark_months: "60%",
      outperformance_hit_rate: "56%",
      avg_relative_performance: "0.26%",
      median_relative_performance: "0.20%",
      rolling: [
        {
          id: "3month",
          title: "Rolling 3M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
        {
          id: "6month",
          title: "Rolling 6M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
        {
          id: "12month",
          title: "Rolling 12M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
      ],
    },
    benchmark: {
      return: "9.28%",
      risk: "16.65%",
      information_ratio: 0.4,
      when_benchmark_is: "Up",
      benchmark_months: "60%",
      outperformance_hit_rate: "56%",
      avg_relative_performance: "0.26%",
      median_relative_performance: "0.20%",
    },
  },
  {
    id: "3_years",
    title: "Last 5 Year Stats ",
    portfolio: {
      return: "9.28%",
      risk: "16.65%",
      alpha: "1.87%",
      beta: 1.07,
      sharpe: 0.55,
      tracking_error: "5.99%",
      information_ratio: 0.4,
      upside_capture: "108%",
      downside_capture: "98%",
      when_benchmark_is: "Up",
      benchmark_months: "60%",
      outperformance_hit_rate: "56%",
      avg_relative_performance: "0.26%",
      median_relative_performance: "0.20%",
      rolling: [
        {
          id: "3month",
          title: "Rolling 3M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
        {
          id: "6month",
          title: "Rolling 6M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
        {
          id: "12month",
          title: "Rolling 12M",
          value: {
            outperformance: "0.66%",
            hit_rate: "70.00%",
            average_outperformance: "1.94%",
            average_underperformance: "-1.76%",
          },
        },
      ],
    },
    benchmark: {
      return: "9.28%",
      risk: "16.65%",
      information_ratio: 0.4,
      when_benchmark_is: "Up",
      benchmark_months: "60%",
      outperformance_hit_rate: "56%",
      avg_relative_performance: "0.26%",
      median_relative_performance: "0.20%",
    },
  },
];
