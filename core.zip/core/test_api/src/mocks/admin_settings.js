export let admin_settings = {
  collections: [
    {
      name: "MyCollection",
      documents: [
        {
          title_html: "Entity<BR>Master",
          show_on_portal: true,
          view_order: 1,
          title: "Entity Master",
          _id: "entity-master",
          zones: [
            {
              name: "portal",
              access: [
                {
                  title: "View",
                  name: "view",
                  granted_by: "self",
                  revoked_by: "self",
                },
                {
                  title: "Admin",
                  revoked_by: "self",
                  granted_by: "admin",
                  name: "admin",
                },
              ],
              view_order: 1,
              title: "Portal",
            },
            {
              access: [
                {
                  revoked_by: "self",
                  title: "Admin",
                  name: "admin",
                  granted_by: "admin",
                },
              ],
              name: "data-ibes",
              title: "IBes data",
              view_order: 2,
            },
          ],
        },
        {
          _id: "MyDoc2",

        },
        {
          "title_html": "Entity<BR>Master-2",
          "show_on_portal": true,
          "view_order": 1,
          "title": "Entity Master",
          "_id": "entity-master_22",
          "zones": [
            {
              "name": "portal",
              "access": [
                {
                  "title": "View",
                  "name": "view",
                  "granted_by": "self",
                  "revoked_by": "self"
                },
                {
                  "title": "Admin",
                  "revoked_by": "self",
                  "granted_by": "admin",
                  "name": "admin"
                }
              ],
              "view_order": 1,
              "title": "Portal"
            },
            {
              "access": [
                {
                  "revoked_by": "self",
                  "title": "Admin",
                  "name": "admin",
                  "granted_by": "admin"
                }
              ],
              "name": "data-ibes",
              "title": "IBes data",
              "view_order": 2
            }
          ]
        },
        {
          _id: "random_document",
        },
      ],
    },
    {
      name: "jktest3",
      documents: [
        {
          _id: "document6",
        },
      ],
    },
    {
      name: "dal_fields",
      documents: [
        {
          _id: "barra_gemltl_exp",
        },
        {
          _id: "barra_gemltl_cov",
        },
        {
          _id: "barra_gemltl_specific_risk",
        },
        {
          _id: "barra_gemltl_lsr",
        },
      ],
    },
    {
      name: "MyCollection2",
      documents: [
        {
          _id: "MyDoc2",
        },
      ],
    },
    {
      name: "users",
      documents: [
        {
          _id: "ae96293a-132c-463f-b480-09f6fd76aab4",
        },
        {
          _id: "31ba8a45-020c-4526-a170-0478b1ba1dd6",
        },
        {
          _id: "4a64d7d0-3a3b-4bab-bb95-9eeed60bd273",
        },
        {
          _id: "9e468dd9-ecd5-4672-b82e-713bd90a332a",
        },
        {
          _id: "67a2dcbd-fbe2-4b7b-961f-87a47816812d",
        },
        {
          _id: "d5072a57-21a6-4cb5-a6f1-b0eff57c0b69",
        },
        {
          _id: "c67ef290-e86b-4fe6-b189-94f70997de43",
        },
        {
          _id: "b8bafe2b-8146-4a71-a508-4ed1a8b7734f",
        },
        {
          _id: "7ce18d5a-702c-4c62-98c0-f70f7b374ac2",
        },
        {
          _id: "86268c7c-af08-4c46-9547-1df5be4bb7f6",
        },
        {
          _id: "e6ea97ce-6fe2-4a9d-a997-70a71066d1f5",
        },
        {
          _id: "e00f8756-a74d-417c-a13b-46144c4640a5",
        },
      ],
    },
    {
      name: "files",
    },
    {
      name: "jktest2",
      documents: [
        {
          _id: "document2",
        },
      ],
    },
    {
      name: "apps",
      documents: [
        {
          _id: "entity-master",
        },
        {
          _id: "research-gateway",
        },
        {
          _id: "admin",
        },
      ],
    },
  ],
};

export const setEntities = (data) => (admin_settings = data);
