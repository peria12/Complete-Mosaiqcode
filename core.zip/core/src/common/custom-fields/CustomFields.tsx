import React, { useState } from "react";
import makeStyles from "@mui/styles/makeStyles";
import Api from "utils/api";
import Typography from "@mui/material/Typography";
import { AdornedButton } from "common/FTButtons";
import TextField from "@mui/material/TextField";
import { defaultNumericOperators, defaultTextOperators } from "config/form-data";
import FTTable from "common/FTTable";
import { DeleteIconButton, FTIconButton, ClearButton } from "common/FTButtons";
import Accordion from "@mui/material/Accordion";
import Switch from "@mui/material/Switch";
import Checkbox from "@mui/material/Checkbox";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import FormControlLabel from "@mui/material/FormControlLabel";
import EditIcon from "@mui/icons-material/Edit";
import errorNotification from "utils/api-error";
import ConfirmDialog from "common/ConfirmDialog";
import RuleGridFrom from "./RuleGridForm";
import TextareaAutosize from "@mui/base/TextareaAutosize";
import Settings from "utils/settings";
import Access from "utils/access";
import { defaultFilter, defaultFieldInfo, defaultFormData } from "./config";
import PublicIcon from "@mui/icons-material/Public";
import PersonIcon from "@mui/icons-material/Person";
import Loader from "common/Loader";
import Autocomplete from "@mui/material/Autocomplete";

const useRowStyles = makeStyles({
    root: {
        width: "100%",
        padding: "15px 0",
    },
    container: {
        display: "flex",
        alignItems: "flex-start",
        flexDirection: "row",
        justifyContent: "flex-start",
        width: "100%",
        padding: "10px 0px",
    },
    formBase: {
        width: "32%",
        height: "100%",
        padding: "0 10px",
        borderRight: "2px solid grey",
    },
    btnBase: {
        marginTop: "20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: "10px",
    },
    inputform: {
        padding: "0px 10px",
        display: "flex",
        width: "100%",
        flexDirection: "row",
        flexFlow: "row wrap",
    },
    iconBtn: {
        fontSize: "1.5rem",
    },
    reportBase: {
        width: "65%",
        paddingLeft: "30px",
    },
    btn: {
        textTransform: "capitalize",
    },
    shapeCircle: {
        borderRadius: "50%",
        background: "#7ec07e",
        width: "15px",
        height: "15px",
        display: "inline-block",
        marginRight: "5px",
    },
    ruleBase: {
        width: "100%",
        display: "flex",
        alignItems: "center",
        marginTop: "20px",
    },
    accordionContent: {
        margin: "0px",
    },
    values: {
        fontSize: ".75rem",
        fontFamily: "Roboto",
    },
});

const docId = "custom_fields";

const panelStyle: any = { display: "block", maxHeight: "calc(100vh - 320px)", overflowY: "auto" };

export default function CustomFields({ app, zone, fieldsConfig, portfolioList }) {
    const classes = useRowStyles();
    const settings = Settings.getSettings();
    const [formData, setFormData] = useState<any>({ ...defaultFormData });
    const [filters, setFilters] = useState([{ ...defaultFilter }]);
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [selectedPfs, setSelectedPfs] = useState([]);
    const [fieldsInfo, setFieldsInfo] = useState<any>({
        ...defaultFieldInfo,
        fields: fieldsConfig?.fields,
        custom_fields_master: fieldsConfig?.custom_fields,
        custom_fields: fieldsConfig?.custom_fields,
    });
    // const [dragId, setDragId] = useState();
    const [expanded, setExpanded] = useState({});
    const [field, setField] = useState<any>({});
    const isAdmin = Access.hasAccessToZone(app, zone, ["admin"]);

    const global_fields =
        fieldsInfo?.custom_fields && Array.isArray(fieldsInfo.custom_fields) ? [...fieldsInfo.custom_fields] : [];
    const user_custom_fields = settings?.app_settings?.[app]?.[zone]?.[docId] || [];
    const custom_fields = [...global_fields, ...user_custom_fields];

    const handler = (type) => {
        if (!formData?.name) {
            errorNotification.next({ type: "error", text: "Please enter field name", open: true });
            return;
        }
        let rules: any = [];

        if (formData?.is_advance) {
            rules = [];
        } else {
            formData.advance_rule = "";
            rules = filters
                .filter(({ field, operator, value }) => {
                    if (!field || !operator || value == undefined || value == null) {
                        return false;
                    }
                    return true;
                })
                .map(({ field, operator, value, is_custom_field }) => ({ field, operator, value, is_custom_field }));
            formData.requires = rules.filter((r) => r.is_custom_field).map((r) => r.field);
        }

        if (selectedPfs?.length) {
            const pfs = selectedPfs.map((ele: any) => ele?.port_ft_id);
            if (pfs.length) {
                formData.portfolios = pfs;
            }
        }

        if (type == "update") {
            if (!formData.is_global) {
                const list = [...(user_custom_fields || [])];
                updateUserFields({ app, zone, id: docId, doc: getUpdatedFields(list, formData, rules) }, "updated");
            } else {
                const list = [...(fieldsInfo?.custom_fields_master || [])];
                updateDoc(getUpdatedFields(list, formData, rules), "updated");
            }
        } else {
            const new_field = {
                name: formData.name,
                is_active: formData.is_active,
                is_global: formData.is_global,
                advance_rule: formData.advance_rule ? formData.advance_rule : null,
                true_value: formData.true_value,
                false_value: formData.false_value,
                rules,
                requires: rules.filter((r) => r.is_custom_field).map((r) => r.field),
            };

            if (formData?.portfolios?.length > 0) {
                new_field["portfolios"] = [...formData.portfolios];
            }

            if (!formData.is_global) {
                updateUserFields({ app, zone, id: docId, doc: [...user_custom_fields, new_field] }, "created");
            } else {
                const fields = [...(fieldsInfo?.custom_fields_master || []), new_field];
                updateDoc(fields, "created");
            }
        }
    };

    function getUpdatedFields(list, formData, rules) {
        let index = list.findIndex((item) => item.name === formData?.id);
        if (index == -1) {
            index = list.length;
            deleteRecord({ ...formData, is_global: !formData.is_global });
        }
        const pfs = selectedPfs?.map((ele: any) => ele?.port_ft_id) || [];
        list[index] = {
            ...list[index],
            name: formData.name,
            is_active: formData.is_active,
            is_global: formData.is_global,
            advance_rule: formData.advance_rule ? formData.advance_rule : null,
            requires: formData.requires,
            true_value: formData.true_value,
            false_value: formData.false_value,
            portfolios: pfs,
            rules,
        };
        return list;
    }

    function onChange(field, value) {
        setFormData({ ...formData, [field]: value });
    }

    function transformResponse(response) {
        let fields: any = [];
        if (response?.collections) {
            const collections = JSON.parse(response.collections);
            const doc = collections.find((col) => col.name == zone);
            if (doc) {
                fields = doc?.documents.find((col) => col._id == docId)?.fields;
            }
        }
        return fields;
    }

    const columns = [
        { label: "Field", key: "field" },
        { label: "Operator", key: "operator" },
        { label: "Value", key: "value" },
    ];

    function updateUserFields(payload, message, btnLoader = true) {
        const { app, zone, id, doc } = payload;
        let fldInfo = { ...fieldsInfo, loading: true };

        if (btnLoader) {
            fldInfo = { ...fieldsInfo, isLoading: true };
        }
        setFieldsInfo(fldInfo);
        Settings.updateSettings(app, zone, id, doc)
            .then((res: any) => {
                if (res.success) {
                    if (message) {
                        errorNotification.next({ type: "success", text: `Field ${message} successfully.`, open: true });
                    }
                    handleClear();
                }
            })
            .finally(() => {
                setFieldsInfo({ ...fieldsInfo, isLoading: false, loading: false });
            });
    }

    function updateDoc(fields, message, btnLoader = true) {
        const payload = { _id: docId, fields: fields };
        let fldInfo = { ...fieldsInfo, loading: true };
        if (btnLoader) {
            fldInfo = { ...fieldsInfo, isLoading: true };
        }
        setFieldsInfo(fldInfo);
        Api.updateDocument(zone, docId, { document: JSON.stringify(payload) }, { comment: "update" })
            .then((response) => {
                if (response.success) {
                    if (message) {
                        errorNotification.next({ type: "success", text: `Field ${message} successfully.`, open: true });
                    }
                    const newFields = transformResponse(response);
                    setFieldsInfo({
                        ...fieldsInfo,
                        custom_fields_master: newFields,
                        custom_fields: newFields,
                        isLoading: false,
                        loading: false,
                    });
                    handleClear();
                } else {
                    errorNotification.next({ type: "error", text: "Failed", open: true });
                    setFieldsInfo({ ...fieldsInfo, isLoading: false, loading: false });
                }
            })
            .catch((err) => {
                console.log(err);
                setFieldsInfo({ ...fieldsInfo, isLoading: false, loading: false });
            });
    }

    function deleteRecord(info: any = null) {
        let record = { ...field };
        if (info != null) {
            record = { ...info };
        }
        if (!record.is_global) {
            const updatedFields = user_custom_fields?.filter((f) => f.name != record?.name);
            updateUserFields({ app, zone, id: docId, doc: updatedFields }, "deleted", false);
        } else {
            const updatedFields = fieldsInfo?.custom_fields_master?.filter((f) => f.name != record?.name);
            updateDoc(updatedFields, "deleted", false);
        }
    }
    function edit(e, record) {
        e.stopPropagation();
        setFormData({
            ...formData,
            id: record.name,
            name: record.name,
            is_active: record?.is_active,
            is_global: record?.is_global,
            is_advance: record?.advance_rule ? true : false,
            advance_rule: record?.advance_rule,
            true_value: record?.true_value,
            false_value: record?.false_value,
            formType: "update",
        });
        if (record?.portfolios) {
            setSelectedPfs(portfolioList?.filter((e) => record?.portfolios.includes(e?.port_ft_id)));
        } else {
            setSelectedPfs([]);
        }
        const list = JSON.parse(JSON.stringify(record.rules));
        list.forEach((filter, i) => {
            const fieldInfo = fieldsInfo?.fields.find((f) => f.id === filter.field);
            if (fieldInfo?.field_type != "string") {
                list[i]["operators"] = defaultNumericOperators;
            } else {
                list[i]["operators"] = defaultTextOperators;
            }
        });
        const _filters = list?.length > 0 ? list : [{ ...defaultFilter }];
        setFilters(_filters);
    }

    const toggle = (panelId) => (event, isExpanded) => {
        const val = isExpanded ? panelId : false;
        setExpanded({ ...expanded, panelId: val });
    };

    function handleClear() {
        setFilters([{ ...defaultFilter }]);
        setFormData({ ...formData, ...defaultFormData });
        setSelectedPfs([]);
    }
    function delField(e, rec) {
        setConfirmOpen(true);
        setField(rec);
    }

    function getColumns(formData) {
        let fields = custom_fields.filter((f) => f.is_active);
        if (formData?.formType === "update") {
            fields = fields.filter((f) => f.name != formData?.id);
        }
        let cols = [];
        if (fieldsInfo?.fields?.length) {
            cols = fieldsInfo.fields.map((f) => ({ ...f, title: `${f?.title} (${f?.id})` }));
        }
        return [
            ...cols,
            ...fields.map((ele) => ({
                ...ele,
                id: ele.name,
                title: ele.name + "*",
                filterable: true,
                field_type: "string",
                is_custom_field: true,
            })),
        ];
    }

    const showBtns = (record) => {
        if (!record?.is_global) {
            return true;
        } else if (record?.is_global && isAdmin) {
            return true;
        }
        return false;
    };

    return (
        <div className={classes.container}>
            <div className={classes.formBase} style={panelStyle}>
                <div className={classes.inputform}>
                    <div style={{ width: "100%", padding: "12px 0px" }}>
                        <MultiplePortfolioSelect
                            portfolioList={portfolioList}
                            selectedPfs={selectedPfs}
                            setSelectedPfs={setSelectedPfs}
                        />
                    </div>
                    <div style={{ width: "80%", paddingRight: "16px" }}>
                        <TextField
                            id="name"
                            label="Name"
                            onChange={(e) => onChange("name", e.target.value)}
                            autoComplete="off"
                            variant="standard"
                            value={formData?.name || ""}
                            error={false}
                            style={{ width: "100%" }}
                        />
                    </div>
                    {isAdmin && (
                        <div style={{ width: "20%" }}>
                            <FormControlLabel
                                style={{ marginLeft: "auto" }}
                                control={
                                    <Checkbox
                                        color="primary"
                                        checked={!formData?.is_global ? false : true}
                                        onChange={(e) => onChange("is_global", e.target.checked)}
                                    />
                                }
                                label="Global"
                            />
                        </div>
                    )}
                    <div className={classes.ruleBase}>
                        <Typography
                            style={{ width: "100%", color: "#616161" }}
                            align="left"
                            component="div"
                            variant="subtitle1"
                        >
                            Rules
                        </Typography>
                        <FormControlLabel
                            style={{ marginLeft: "auto" }}
                            control={
                                <Switch
                                    size="small"
                                    checked={!formData?.is_advance ? false : true}
                                    color="primary"
                                    onChange={(e) => onChange("is_advance", e.target.checked)}
                                />
                            }
                            label="Advance"
                        />
                    </div>
                    {!formData?.is_advance ? (
                        <div style={{ width: "100%" }}>
                            {filters.map((filter: any, index: number) => (
                                <RuleGridFrom
                                    key={index}
                                    filter={filter}
                                    fields={getColumns(formData)}
                                    index={index}
                                    filters={filters}
                                    setFilters={setFilters}
                                    operators={filter.operators || []}
                                />
                            ))}
                        </div>
                    ) : (
                        <div style={{ width: "100%" }}>
                            <TextareaAutosize
                                minRows={6}
                                onChange={(e) => onChange("advance_rule", e.target.value)}
                                autoComplete="off"
                                value={formData?.advance_rule || ""}
                                style={{ width: "100%" }}
                            />
                        </div>
                    )}
                    <div className="pt-5" style={{ display: "flex", width: "100%", paddingRight: "16px" }}>
                        <TextField
                            id="true_value"
                            label="True Value"
                            onChange={(e) => onChange("true_value", e.target.value)}
                            autoComplete="off"
                            variant="standard"
                            value={formData?.true_value || ""}
                            style={{ width: "50%", marginRight: "12px", background: "#e8f5e9" }}
                        />
                        <TextField
                            id="false_value"
                            label="False Value"
                            onChange={(e) => onChange("false_value", e.target.value)}
                            autoComplete="off"
                            variant="standard"
                            value={formData?.false_value || ""}
                            style={{ width: "50%", marginRight: "12px", background: "#ffebee" }}
                        />
                    </div>
                </div>
                <div className={classes.btnBase}>
                    <div>
                        <FormControlLabel
                            style={{ marginLeft: "auto" }}
                            control={
                                <Switch
                                    checked={!formData?.is_active ? false : true}
                                    color="primary"
                                    onChange={(e) => onChange("is_active", e.target.checked)}
                                />
                            }
                            label="Active"
                        />
                    </div>
                    <div style={{ width: "60%" }}>
                        <ClearButton handler={handleClear} value={true} />
                        <AdornedButton
                            style={{ marginLeft: "8px" }}
                            className={classes.btn}
                            variant="contained"
                            color="primary"
                            size={"small"}
                            onClick={() => handler(formData?.formType)}
                            loading={fieldsInfo?.isLoading}
                        >
                            {formData?.formType === "update" ? "Update" : "Save"}
                        </AdornedButton>
                    </div>
                </div>
            </div>
            <div className={classes.reportBase} style={{ ...panelStyle, padding: "0 30px" }}>
                <Typography style={{ color: "#616161" }} align="left" component="h1" variant="h5">
                    Custom Fields
                </Typography>
                {fieldsInfo?.isLoading ? (
                    <div style={{ minHeight: "100px" }}>
                        <Loader />
                    </div>
                ) : (
                    <div className="row">
                        {custom_fields?.map((record, id) => (
                            <div
                                className="col-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6"
                                style={{ padding: "5px" }}
                                key={record.name}
                                id={record.name}
                            >
                                <ConfirmDialog
                                    title={`Delete?`}
                                    open={confirmOpen}
                                    setOpen={setConfirmOpen}
                                    stopPropagation={true}
                                    onConfirm={(e) => {
                                        e?.stopPropagation();
                                        deleteRecord();
                                    }}
                                >
                                    Are you sure you want to delete this field?
                                </ConfirmDialog>

                                <Accordion key={id} expanded={expanded[id]} onChange={toggle(id)}>
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls={`${id}-content`}
                                        id={`${id}-header`}
                                        style={{ fontWeight: 500, margin: 0 }}
                                        classes={{ content: classes.accordionContent }}
                                    >
                                        <div
                                            style={{
                                                display: "flex",
                                                alignItems: "center",
                                                color: !record?.is_active ? "#a09e9e" : "rgb(76 75 75)",
                                            }}
                                        >
                                            {record?.is_global ? (
                                                <PublicIcon fontSize="small" />
                                            ) : (
                                                <PersonIcon fontSize="small" />
                                            )}
                                            <span style={{ padding: "0px 6px" }}> {record.name} </span>
                                        </div>
                                        <div style={{ marginLeft: "auto" }}>
                                            {showBtns(record) && (
                                                <>
                                                    <DeleteIconButton
                                                        handler={(e) => {
                                                            e.stopPropagation();
                                                            delField(e, record);
                                                        }}
                                                    />
                                                    <FTIconButton
                                                        handler={(e) => edit(e, record)}
                                                        title="View Report"
                                                        btnIcon={<EditIcon className={classes.iconBtn} />}
                                                        placement="top"
                                                    />
                                                </>
                                            )}
                                        </div>
                                    </AccordionSummary>
                                    <AccordionDetails style={{ paddingTop: "0px" }}>
                                        <Typography>
                                            {record?.rules?.length > 0 && (
                                                <>
                                                    <div style={{ width: "100%", marginTop: "8px" }}>
                                                        <FTTable columns={columns || []} rows={record?.rules || []} />
                                                    </div>
                                                </>
                                            )}
                                            {record?.advance_rule && (
                                                <div style={{ width: "80%" }}>
                                                    <div style={{ padding: "10px 20px%", background: "#f5f5f5" }}>
                                                        {record?.advance_rule}
                                                    </div>
                                                </div>
                                            )}
                                            <div className={"pt-2 " + classes.values}>
                                                {record?.true_value && (
                                                    <div>
                                                        True Value: <i>{record?.true_value}</i>
                                                    </div>
                                                )}
                                                {record?.false_value && (
                                                    <div>
                                                        False Value: <i>{record?.false_value}</i>
                                                    </div>
                                                )}
                                            </div>
                                        </Typography>
                                    </AccordionDetails>
                                </Accordion>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

function MultiplePortfolioSelect({ portfolioList, selectedPfs, setSelectedPfs }) {
    const options = [...portfolioList];
    const handleChange = (_, portfolioInfo) => {
        if (portfolioInfo) {
            setSelectedPfs([...portfolioInfo]);
        }
    };

    const RenderOption = function (props, option) {
        return (
            <li {...props} key={option?.id} style={{ fontSize: "12px" }}>
                <div className="col-2 text-truncate">{option?.port_ft_id}</div>
                <div className="col-10 text-truncate">{option.label}</div>
            </li>
        );
    };

    return (
        <Autocomplete
            multiple
            id="multiple-pf-selector"
            placeholder="Portfolios..."
            renderOption={RenderOption}
            limitTags={2}
            size={"small"}
            options={options}
            getOptionLabel={(option) => option.label}
            value={selectedPfs}
            filterSelectedOptions
            onChange={handleChange}
            renderInput={(params) => <TextField {...params} label="Portfolios" placeholder="Portfolios..." />}
        />
    );
}
