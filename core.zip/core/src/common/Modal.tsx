import React, { useState, useEffect } from "react";
import * as bootstrap from "bootstrap";

export default function Modal({ title, children, buttonText, onOk, onClose }) {
    const [id] = useState(Math.random().toString(36).substring(7));

    useEffect(() => {
        const element = document.getElementById(id);
        const myModal = new bootstrap.Modal(element);
        myModal.show();
        function closeListener() {
            element?.removeEventListener("hidden.bs.modal", closeListener);
            onClose();
        }
        element?.addEventListener("hidden.bs.modal", closeListener);
        return () => myModal.hide();
    });

    return (
        <div className="modal" id={id} tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title" id="exampleModalLabel">
                            {title}
                        </h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">{children}</div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                            Close
                        </button>
                        <button type="button" className="btn btn-primary" onClick={onOk}>
                            {buttonText}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
