import React from "react";
import { FormCheckbox } from "./forms/FormCheckbox";
import { FormFile } from "./forms/FormFile";
import { FormInput } from "./forms/FormInput";
import { FormSelect } from "./forms/FormSelect";

export function InputField({ field, value, onChange }) {
    if (field.type == "text") {
        return <FormInput type="text" title={field.title} value={value} onChange={onChange} />;
    } else if (field.type == "date") {
        return <FormInput type="date" title={field.title} value={value} onChange={onChange} />;
    } else if (field.type == "select") {
        return <FormSelect title={field.title} options={field.options} value={value} onChange={onChange} />;
    } else if (field.type == "checkbox") {
        return <FormCheckbox title={field.title} value={value} onChange={onChange} />;
    } else if (field.type == "files") {
        return <FormFile title={field.title} value={value} onChange={onChange} />;
    } else {
        return <div>Field Type {field.type} Not Supported</div>;
    }
}
