import React from "react";
import clsx from "clsx";
import { Theme } from "@mui/material/styles";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Button from "@mui/material/Button";
import SaveIcon from "@mui/icons-material/Save";
import ClearIcon from "@mui/icons-material/Clear";
import DeleteIcon from "@mui/icons-material/Delete";
import SendIcon from "@mui/icons-material/Send";
import AddIcon from "@mui/icons-material/Add";
import IconButton from "@mui/material/IconButton";
import SettingsBackupRestoreIcon from "@mui/icons-material/SettingsBackupRestore";
import Tooltip from "@mui/material/Tooltip";
import CircularProgress from "@mui/material/CircularProgress";

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        btn: {
            textTransform: "capitalize",
            marginLeft: 8,
        },
        iconBtn: {
            padding: theme.spacing(0.7),
            marginLeft: 3,
            backgroundColor: "#fafafa",
            "&:hover": {
                backgroundColor: "#fafafa",
            },
        },
        ftIconBtn: {
            padding: theme.spacing(0.8),
        },
        spinner: {
            color: "rgba(0, 0, 0, 0.26)",
            position: "absolute",
            top: "50%",
            left: "50%",
            marginTop: -12,
            marginLeft: -12,
        },
        hideBgColor: {
            "&:hover": {
                backgroundColor: "unset",
            },
        },
    })
);

export const UpdateButton = ({ handler, value }) => {
    const classes = useStyles();
    return (
        <Button
            onClick={handler}
            variant="contained"
            size="small"
            color="primary"
            className={classes.btn}
            startIcon={<SaveIcon />}
            disabled={!value ? true : false}
        >
            Update
        </Button>
    );
};

export const SaveButton = ({ handler, value }) => {
    const classes = useStyles();
    return (
        <Button
            onClick={handler}
            variant="contained"
            size="small"
            color="primary"
            className={classes.btn}
            startIcon={<SaveIcon />}
            disabled={!value ? true : false}
        >
            Save
        </Button>
    );
};

export const ClearButton = ({ handler, value }) => {
    const classes = useStyles();
    return (
        <Button
            onClick={handler}
            variant="contained"
            size="small"
            className={classes.btn}
            startIcon={<ClearIcon />}
            disabled={!value ? true : false}
        >
            Clear
        </Button>
    );
};

export const ResetButton = ({ handler, value }) => {
    const classes = useStyles();
    return (
        <Button
            onClick={handler}
            variant="contained"
            size="small"
            className={classes.btn}
            startIcon={<SettingsBackupRestoreIcon />}
            disabled={!value ? true : false}
        >
            Reset
        </Button>
    );
};

export const DeleteButton = ({ handler, value }) => {
    const classes = useStyles();
    return (
        <Button
            onClick={handler}
            variant="contained"
            size="small"
            color="secondary"
            className={classes.btn}
            startIcon={<DeleteIcon />}
            disabled={!value ? true : false}
        >
            Delete
        </Button>
    );
};

export const InsertButton = ({ handler, value }) => {
    const classes = useStyles();
    return (
        <Button
            onClick={handler}
            variant="contained"
            size="small"
            color="primary"
            className={classes.btn}
            endIcon={<SendIcon />}
            disabled={!value ? true : false}
        >
            Insert
        </Button>
    );
};

export const AddIconButton = ({ handler }) => {
    const classes = useStyles();
    return (
        <Tooltip title="Add Collection" aria-label="add" placement="top">
            <IconButton aria-label="delete" onClick={handler} className={classes.iconBtn} size="large">
                <AddIcon fontSize="small" />
            </IconButton>
        </Tooltip>
    );
};

export const SaveIconButton = ({ handler }) => {
    const classes = useStyles();
    return (
        <Tooltip title="Save" aria-label="Save" placement="top">
            <IconButton aria-label="Save" onClick={handler} className={classes.iconBtn} size="large">
                <SaveIcon fontSize="small" />
            </IconButton>
        </Tooltip>
    );
};

export const DeleteIconButton = ({ handler }) => {
    const classes = useStyles();
    return (
        <Tooltip title="Delete" aria-label="Save" placement="left">
            <IconButton aria-label="Save" onClick={handler} className={classes.iconBtn} size="large">
                <DeleteIcon fontSize="small" />
            </IconButton>
        </Tooltip>
    );
};

export const FTIconButton = ({
    handler,
    title,
    btnIcon,
    placement,
    hideBgColor = false,
    disabled = false,
    style = {},
}) => {
    const classes = useStyles();
    return (
        <Tooltip title={title} placement={placement}>
            <IconButton
                aria-label={title}
                onClick={handler}
                className={clsx(classes.ftIconBtn, { [classes.hideBgColor]: hideBgColor })}
                size="large"
                disabled={disabled}
                style={style}
            >
                {btnIcon}
            </IconButton>
        </Tooltip>
    );
};

export const IconBtn = ({ classes, handler, startIcon, label, color, size, disabled = false }) => {
    return (
        <Button
            onClick={handler}
            variant="contained"
            size={size}
            color={color}
            className={classes.btn}
            startIcon={startIcon}
            disabled={disabled}
        >
            {label}
        </Button>
    );
};

export const AdornedButton = (props) => {
    const { children, loading, ...rest } = props;
    const classes = useStyles();
    const isDisabled = loading ? loading : rest.disabled;
    return (
        <Button {...rest} disabled={isDisabled}>
            {children}
            {loading && <CircularProgress className={classes?.spinner} size={24} />}
        </Button>
    );
};
