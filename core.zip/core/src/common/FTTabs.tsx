import React from "react";

import { Paper, Tabs, Tab } from "@mui/material";
import { Link, useLocation } from "react-router-dom";

export default function FTTabs({ tabs, rootPath }) {
    const { pathname } = useLocation();
    const current = pathname.slice(rootPath.length + 1);
    const [value, setValue] = React.useState(current);

    const handleChange = (event: any, newValue: number) => {
        setValue(newValue);
    };

    React.useEffect(() => setValue(current), [current]);

    return (
        <Paper square>
            <Tabs value={value} onChange={handleChange} indicatorColor="primary" textColor="primary">
                {tabs.map((tab) => (
                    <Tab
                        key={tab.url}
                        value={tab.url}
                        label={tab.value}
                        component={Link}
                        to={`${rootPath}/${tab.url}`}
                        style={{
                            textTransform: "capitalize",
                            color: "#00a0dc",
                            cursor: "pointer",
                            fontWeight: 600,
                        }}
                    />
                ))}
            </Tabs>
        </Paper>
    );
}
