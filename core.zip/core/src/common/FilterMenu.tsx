import React from "react";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";

export default function FilterMenu({ mousePositions, handleClose, operators }) {
    return (
        <Menu
            keepMounted
            open={mousePositions.mouseY !== null}
            onClose={handleClose}
            anchorReference="anchorPosition"
            anchorPosition={
                mousePositions.mouseY !== null && mousePositions.mouseX !== null
                    ? { top: mousePositions.mouseY, left: mousePositions.mouseX }
                    : undefined
            }
        >
            <MenuItem dense={true} style={{ minWidth: "4rem" }}>
                Filter
            </MenuItem>
            {operators.map((op) => (
                <MenuItem
                    key={op.value}
                    dense={true}
                    style={{ minWidth: "4rem" }}
                    onClick={(e) => {
                        e.stopPropagation();
                        handleClose({ operator: op.value });
                    }}
                >
                    {op.label}
                </MenuItem>
            ))}
        </Menu>
    );
}
