import React from "react";

export function FormInput({ title, type, value, onChange }) {
    const changed = (event) => onChange(event.target.value);
    const id = Math.random().toString(36).substring(7);

    return (
        <div className="form-floating mb-3">
            <input
                type={type}
                className="form-control"
                id={id}
                placeholder="a"
                defaultValue={value}
                onChange={changed}
            />
            <label htmlFor={id}>{title}</label>
        </div>
    );
}
