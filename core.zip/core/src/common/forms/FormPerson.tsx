import React from "react";

export function FormPerson({ title, type, value, onChange }) {
    const changed = (event) => onChange(event.target.value);
    const id = Math.random().toString(36).substring(7);

    return (
        <div className="form-floating mb-3">
            <input type={type} defaultValue={value} className="form-control" id={id} onChange={changed} />
            <label htmlFor={id} className="form-label">
                {" "}
                {title}{" "}
            </label>
        </div>
    );
}
