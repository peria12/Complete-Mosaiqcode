import React from "react";

export function FormSelect({ title, options, value, onChange }) {
    const changed = (event) => onChange(event.target.value);
    const id = Math.random().toString(36).substring(7);

    return (
        <div className="form-floating mb-3">
            <select className="form-control form-select" id={id} defaultValue={value} onChange={changed}>
                {options.map((item) => (
                    <option key={item.key} value={item.key}>
                        {" "}
                        {item.value}{" "}
                    </option>
                ))}
            </select>
            <label htmlFor={id} className="form-label">
                {" "}
                {title}{" "}
            </label>
        </div>
    );
}
