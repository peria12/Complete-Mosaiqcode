import React from "react";
import {
    Button,
    TextField,
    Dialog,
    DialogActions,
    DialogContent,
    FormControl,
    Input,
    InputLabel,
    MenuItem,
    Select,
    Grid,
    Box,
    IconButton,
    Tooltip,
} from "@mui/material";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import { textOperators, numericOperators } from "../config/form-data";

const useStyles = makeStyles((theme: any) =>
    createStyles({
        container: {
            display: "flex",
            flexWrap: "wrap",
        },
        formControl: {
            width: "100%",
            marginTop: "10px",
        },
        inputBase: {
            fontSize: ".8rem",
        },
        iconBtn: {
            padding: theme.spacing(1.5),
        },
        btn: {
            textTransform: "capitalize",
        },
    })
);

const RemoveFilterFields = ({ handleRemoveFilter }) => {
    const classes = useStyles();
    return (
        <Tooltip title="Remove" placement="top">
            <IconButton aria-label="delete" onClick={handleRemoveFilter} className={classes.iconBtn} size="large">
                <DeleteIcon fontSize="small" />
            </IconButton>
        </Tooltip>
    );
};

const AddFilterFields = ({ handleAddFilter }) => {
    const classes = useStyles();
    return (
        <Tooltip title="Add" aria-label="add" placement="top">
            <IconButton aria-label="delete" onClick={handleAddFilter} className={classes.iconBtn} size="large">
                <AddIcon fontSize="small" />
            </IconButton>
        </Tooltip>
    );
};

const FilterForm = ({
    fields,
    filter,
    handleChange,
    index,
    handleRemoveFilter,
    filterCount,
    handleAddFilter,
    operators,
}) => {
    const classes = useStyles();
    return (
        <Box component="div">
            <form className={classes.container}>
                <Grid container direction="row" spacing={2}>
                    <Grid item container xs={12} sm={12} md={10} lg={10} xl={10}>
                        <Grid item container spacing={2}>
                            <Grid item xs={12} sm={12} md={4} lg={4} xl={4}>
                                <FormControl variant="standard" className={classes.formControl}>
                                    <InputLabel className={classes.inputBase} id={"filter-column-label" + index}>
                                        {" "}
                                        Columns{" "}
                                    </InputLabel>
                                    <Select
                                        labelId="filter-column-label"
                                        id={"column-filter-select" + index}
                                        name="column"
                                        value={filter.column}
                                        onChange={(event) => handleChange(event, index)}
                                        input={<Input className={classes.inputBase} />}
                                    >
                                        {fields.map((field) => {
                                            if (field.filterable) {
                                                return (
                                                    <MenuItem key={field.id} value={field.id} dense={true}>
                                                        {field.title}
                                                    </MenuItem>
                                                );
                                            }
                                        })}
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} sm={12} md={4} lg={4} xl={4}>
                                <FormControl variant="standard" className={classes.formControl}>
                                    <InputLabel className={classes.inputBase} id={"filter-operator-label" + index}>
                                        Operators
                                    </InputLabel>
                                    <Select
                                        labelId="filter-operator-label"
                                        id="operator-filter-select"
                                        name="operator"
                                        value={filter.operator}
                                        onChange={(event) => handleChange(event, index)}
                                        input={<Input className={classes.inputBase} />}
                                    >
                                        {operators?.length === 0 && (
                                            <MenuItem disabled value={""}>
                                                No Options
                                            </MenuItem>
                                        )}
                                        {operators.map((op) => (
                                            <MenuItem key={op.value} dense={true} value={op.value}>
                                                {op.label}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} sm={12} md={4} lg={4} xl={4}>
                                <FormControl className={classes.formControl}>
                                    <TextField
                                        id={"filter-value" + index}
                                        name="value"
                                        type={filter.isNumber ? "number" : "text"}
                                        InputProps={{ className: classes.inputBase }}
                                        InputLabelProps={{ className: classes.inputBase }}
                                        value={filter.value}
                                        label="Value"
                                        variant="standard"
                                        onChange={(event) => handleChange(event, index)}
                                    />
                                    <small className="text-danger" style={{ fontSize: "0.65em" }}>
                                        {filter.error}
                                    </small>
                                </FormControl>
                            </Grid>
                        </Grid>
                    </Grid>
                    <div
                        style={{
                            flexDirection: "row",
                            display: "flex",
                            justifyContent: "flex-start",
                            alignItems: "flex-end",
                        }}
                    >
                        <RemoveFilterFields handleRemoveFilter={handleRemoveFilter} />
                        {filterCount === index ? <AddFilterFields handleAddFilter={handleAddFilter} /> : null}
                    </div>
                </Grid>
            </form>
        </Box>
    );
};

export default function TableFilterForm({ fields, open, handleClose, filters, setFilters, handleFilter }) {
    const classes = useStyles();
    const filterCount = filters.length - 1;

    const handleChange = (event: any, index: number) => {
        const { name, value } = event.target;
        const list = [...filters];
        if (name === "value" && list[index]["isNumber"]) {
            list[index][name] = parseFloat(value);
        } else {
            list[index][name] = value;
        }
        if (name === "column") {
            const fieldInfo = fields.find((field) => field.id === value);
            if (!fieldInfo?.is_string) {
                list[index]["operators"] = numericOperators;
            } else {
                list[index]["operators"] = textOperators;
            }
            const field_info: any = fields.find((f: any) => f.id === list[index]["column"]);
            if (field_info) {
                if (field_info.is_string) {
                    list[index]["isNumber"] = false;
                } else {
                    list[index]["isNumber"] = true;
                    list[index]["value"] = "";
                }
            }
        }
        setFilters(list);
    };

    const handleAddFilter = () => {
        setFilters([...filters, { column: "", operator: "", value: "", query: {}, queryStr: "" }]);
    };

    const handleRemoveFilter = (index: number) => {
        if (filters.length === 1) {
            setFilters([{ column: "", operator: "", value: "", query: {}, queryStr: "" }]);
        } else {
            const list = [...filters];
            list.splice(index, 1);
            setFilters(list);
        }
    };

    return (
        <Dialog disableEscapeKeyDown open={open} onClose={handleClose} fullWidth={true}>
            <DialogContent>
                <Box component="h5"> Filter </Box>
                {filters.map((filter: any, index: number) => (
                    <FilterForm
                        key={index}
                        filter={filter}
                        fields={fields}
                        handleChange={handleChange}
                        index={index}
                        handleRemoveFilter={() => handleRemoveFilter(index)}
                        filterCount={filterCount}
                        handleAddFilter={handleAddFilter}
                        operators={filter.operators || []}
                    />
                ))}
            </DialogContent>
            <DialogActions>
                <Button onClick={handleClose} className={classes.btn} size="small" variant="contained">
                    {" "}
                    Cancel{" "}
                </Button>
                <Button
                    onClick={() => handleFilter()}
                    size="small"
                    className={classes.btn}
                    color="primary"
                    variant="contained"
                >
                    Search
                </Button>
            </DialogActions>
        </Dialog>
    );
}
