import React from "react";
import ErrorIcon from "@mui/icons-material/Error";
import Grid from "@mui/material/Grid";
import Api from "utils/api";

export default class ErrorBoundary extends React.Component<any, any> {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError(error: any) {
        console.log(error);
        return { hasError: true };
    }

    componentDidCatch(error) {
        const payload = { error: error?.stack || error?.message };
        Api.logToLoggerService(payload);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div style={{ color: "grey" }}>
                    <Grid container direction="row" justifyContent="center" alignItems="center">
                        <div style={{ textAlign: "center", marginTop: "40px" }}>
                            <ErrorIcon color="action" style={{ fontSize: "5rem" }} />
                            <h1> Oops! </h1>
                            <p> Something went wrong. </p>
                        </div>
                    </Grid>
                </div>
            );
        }
        return this.props.children;
    }
}
