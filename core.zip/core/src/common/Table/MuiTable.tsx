import React, { useState, useEffect } from "react";
import clsx from "clsx";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import TablePagination from "@mui/material/TablePagination";
import TableSortLabel from "@mui/material/TableSortLabel";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";

import Loader from "common/Loader";
import TablePaginationActions from "common/TablePaginationActions";
import TableDetailsView from "common/TableDetailsView";
import { errorHandler } from "utils/error-handler";
import { getFilterQuery, checkEquality } from "utils/helpers";
import Settings from "utils/settings";
import FilterMenu from "common/FilterMenu";
import useTableStyles from "./useTableStyles";
import TableProps from "./TableProps";
import Toolbar from "./Toolbar";
import { textOperators } from "config/form-data";

import {
    defaultQueryFilter,
    defaultFieldsInfo,
    defaultFilterInfo,
    defaultTableData,
    defaultRowsPerPage,
    defaultRowsPerPageOptions,
    initialMousePositions,
} from "./TableConfig";

const isGroupByApplied = (fieldsInfo: any) => {
    const groupBy = fieldsInfo?.groupBy;
    return groupBy[0] || groupBy[1];
};

function isGroupByColumn(fieldsInfo: any, colIndex, i) {
    const groupBy = fieldsInfo?.groupBy;
    if (!groupBy[0] && groupBy[1]) {
        if (i == 0) {
            return true;
        } else {
            return false;
        }
    }

    return groupBy[colIndex] && i == colIndex;
}

function getStripedStyle(index: number): any {
    return { background: index % 2 ? "#fafafa" : "white" };
}

function isNumeric(fieldsInfo: any, id: string) {
    return fieldsInfo?.fieldMap?.[id]?.field_type === "numeric";
}

const getValue = (fieldsInfo: any, value: any, fieldId: string) => {
    if (value === "NaN" || value === undefined || value === null) {
        return "";
    }

    if (fieldsInfo?.fieldMap?.[fieldId]?.field_type === "fractional") {
        value = (parseFloat(value) * 100).toFixed(2).replace(/\.00$/, "");
        if (value) {
            return value + "%";
        }
    }
    if (isNumeric(fieldsInfo, fieldId)) {
        return value.toLocaleString();
    }
    return value;
};

const Spacer = ({ classes }) => (
    <tr style={{ height: "25px" }}>
        <td colSpan={100} style={{ background: "white" }} className={classes.root + " " + "custom-tr-border"}></td>
    </tr>
);

function GroupByTable({ open, row, fieldsInfo, nestedTableConfig, filterInfo }) {
    const classes = useTableStyles();
    const [nestedTableInfo, setNestedTableInfo] = useState({ rows: [], isLoading: true, loaded: false });
    const { dataApi } = nestedTableConfig;
    const { groupBy, date } = filterInfo;

    useEffect(() => {
        if (!open || nestedTableInfo.loaded) {
            return;
        }
        const args = {
            search: JSON.stringify({
                [groupBy[0]]: row[groupBy[0]],
                [groupBy[1]]: row[groupBy[1]],
            }),
            asof_date: date,
        };
        setNestedTableInfo({ rows: [], isLoading: true, loaded: false });
        if (dataApi) {
            dataApi(args)
                .then((response: any) => {
                    if (response?.records) {
                        setNestedTableInfo({
                            rows: response?.records,
                            isLoading: false,
                            loaded: true,
                        });
                    } else {
                        setNestedTableInfo({ rows: [], isLoading: false, loaded: true });
                    }
                })
                .catch((e: any) => {
                    errorHandler(e);
                    setNestedTableInfo({ rows: [], isLoading: false, loaded: false });
                });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, groupBy, row, date]);

    return (
        <>
            {open &&
                (nestedTableInfo.isLoading ? (
                    <tr>
                        {" "}
                        <td colSpan={100}>
                            {" "}
                            <Loader />{" "}
                        </td>{" "}
                    </tr>
                ) : (
                    <>
                        <Spacer classes={classes} />
                        {nestedTableInfo?.rows.map((child_row: any, child_index: number) => (
                            <tr
                                key={child_index}
                                style={{ ...getStripedStyle(child_index + 1) }}
                                className={classes.root + " " + "custom-tr-border"}
                            >
                                {fieldsInfo?.sortedFields
                                    .filter((col) => fieldsInfo?.meta?.[col])
                                    .map((child_col: any) => {
                                        if (groupBy.includes(child_col)) {
                                            return <td key={child_col} style={{ background: "white", border: 0 }}></td>;
                                        }
                                        const CustomizedCell = nestedTableConfig?.customizeCell?.[child_col];
                                        return (
                                            <td
                                                key={child_col}
                                                className={clsx({
                                                    ["align-right"]: isNumeric(fieldsInfo, child_col),
                                                })}
                                                style={
                                                    isNumeric(fieldsInfo, child_col)
                                                        ? { textAlign: "right" }
                                                        : undefined
                                                }
                                            >
                                                {nestedTableConfig?.customizeCell && CustomizedCell ? (
                                                    <CustomizedCell props={{ row, filterInfo }} />
                                                ) : (
                                                    getValue(fieldsInfo, child_row[child_col], child_col)
                                                )}
                                            </td>
                                        );
                                    })}
                            </tr>
                        ))}
                        <Spacer classes={classes} />
                    </>
                ))}
        </>
    );
}

function Row({
    row,
    index,
    fieldsInfo,
    meta,
    nestedTableConfig,
    handleRightClick,
    rowConfig,
    setTableData,
    toolbarConfig,
    filterInfo,
}) {
    const [open, setOpen] = useState(false);
    const classes = useTableStyles();
    const { fields, sortedFields, fieldMap } = fieldsInfo;
    const { nested, striped } = meta;
    const isExpended = toolbarConfig?.groupByFilter ? isGroupByApplied(fieldsInfo) : nested;

    function renderChild(nestedTableConfig: any) {
        switch (nestedTableConfig?.type) {
            case "Card":
                return (
                    <tr>
                        <td style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={12}>
                            <Collapse in={open} timeout="auto" unmountOnExit>
                                <Box margin={"1px"}>
                                    <TableDetailsView
                                        fields={fields}
                                        row={row}
                                        titleProp={nestedTableConfig.titleProp}
                                    />
                                </Box>
                            </Collapse>
                        </td>
                    </tr>
                );

            case "GroupByTable":
                return (
                    <GroupByTable
                        fieldsInfo={fieldsInfo}
                        open={open}
                        row={row}
                        nestedTableConfig={nestedTableConfig}
                        filterInfo={filterInfo}
                    />
                );
        }
    }

    const handleToggle = () => setOpen(!open);

    return (
        <React.Fragment>
            <tr
                onClick={handleToggle}
                className={classes.root + " " + "custom-tr-border"}
                style={striped ? { ...getStripedStyle(index) } : undefined}
            >
                {sortedFields.map((field: any, i: number) => {
                    const CustomizedCell = rowConfig?.customizeCell[field];
                    let styles = {
                        cursor: fieldsInfo?.filterable[field] ? "context-menu" : nested ? "pointer" : undefined,
                        textAlign: fieldMap[field]?.position || "left",
                    };

                    if (rowConfig?.styleCell?.handler && rowConfig.styleCell?.handler(row)) {
                        styles = { ...styles, ...rowConfig?.styleCell.style };
                    }
                    if (isGroupByApplied(fieldsInfo) && fieldMap?.[field]?.hide_on_expended_view) {
                        return null;
                    }
                    if (fieldsInfo?.meta?.[field]) {
                        return (
                            <td
                                key={field}
                                onContextMenu={
                                    fieldsInfo?.filterable[field]
                                        ? (event) => handleRightClick(event, field, row[field])
                                        : undefined
                                }
                                style={{ ...styles }}
                                className={clsx({
                                    [classes.grpByFistCol]: isGroupByColumn(fieldsInfo, 0, i),
                                    [classes.grpBySecCol]: isGroupByColumn(fieldsInfo, 1, i),
                                })}
                            >
                                {rowConfig?.customizeCell && rowConfig?.customizeCell[field] ? (
                                    <CustomizedCell props={{ row, setTableData, filterInfo }} />
                                ) : (
                                    row[field]
                                )}
                            </td>
                        );
                    }
                    return null;
                })}
                {isExpended && (
                    <td>
                        <IconButton aria-label="expand row" size="small">
                            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                        </IconButton>
                    </td>
                )}
            </tr>
            {isExpended && renderChild(nestedTableConfig)}
        </React.Fragment>
    );
}

function createResizableColumn(col, resizer) {
    let x = 0;
    let w = 0;

    const mouseDownHandler = function (e) {
        x = e.clientX;
        const styles = window.getComputedStyle(col);
        w = parseInt(styles.width, 10);
        document.addEventListener("mousemove", mouseMoveHandler);
        document.addEventListener("mouseup", mouseUpHandler);
        resizer.classList.add("resizing");
        e.preventDefault();
    };

    const mouseMoveHandler = function (e) {
        const dx = e.clientX - x;
        col.style.width = `${w + dx}px`;

        e.preventDefault();
    };

    const mouseUpHandler = function (e) {
        document.removeEventListener("mousemove", mouseMoveHandler);
        document.removeEventListener("mouseup", mouseUpHandler);
        resizer.classList.remove("resizing");
        e.preventDefault();
    };
    resizer.addEventListener("mousedown", mouseDownHandler);
}

const transformedFields = (fields: any) => {
    const ordered_fields = fields.sort((a: any, b: any) => a.view_order - b.view_order);
    const columns = ordered_fields.filter((f) => f.show_on_table);
    const sorted_fields = columns.map((f) => f._id);
    return { ordered_fields, columns, sorted_fields };
};

const processGroupBy = (fieldsInfo, filterInfo, params, setFieldsInfo) => {
    if ("group_by" in params) {
        const cols = fieldsInfo.columns.filter((col) => !filterInfo?.groupBy.includes(col._id));
        if (filterInfo?.groupBy?.[1]) {
            cols.unshift(fieldsInfo.columns.find((col) => col._id == filterInfo?.groupBy?.[1]));
        }
        if (filterInfo?.groupBy?.[0]) {
            cols.unshift(fieldsInfo.columns.find((col) => col._id == filterInfo?.groupBy?.[0]));
        }
        setFieldsInfo({
            ...fieldsInfo,
            groupBy: filterInfo?.groupBy,
            columns: cols,
            sortedFields: cols.map((f) => f._id),
        });
    }
};
export default function MuiTable(props: TableProps) {
    const {
        meta,
        fieldsApi,
        tableDataApi,
        paginationConfig,
        nestedTableConfig,
        toolbarConfig,
        appInfo,
        rowConfig,
        defaultOrderBy,
    } = props;

    const classes = useTableStyles();
    const [fieldsInfo, setFieldsInfo] = useState<any>(defaultFieldsInfo);
    const [tableData, setTableData] = useState<any>(defaultTableData);
    const [filterInfo, setFilterInfo] = useState<any>(defaultFilterInfo);
    const [pageConfig, setPageConfig] = useState<any>({
        page: 0,
        rowsPerPage: paginationConfig?.rowsPerPage || defaultRowsPerPage,
    });
    const [orderBy, setOrderBy] = useState<any>(defaultOrderBy || {});
    const [searchText, setSearchText] = useState("");
    const [queryFilters, setQueryFilters] = useState<any>([defaultQueryFilter]);
    const [queryFilterOpen, setQueryFilterOpen] = useState(false);
    const [mousePositions, setMousePositions] = React.useState<any>(initialMousePositions);
    const [dense, setDense] = useState<any>(meta?.dense);
    const [queryParams, setQueryParams] = useState({ params: {}, filters: {} });
    const table: any = React.useRef(null);
    const [dragAndDrop, setDragAndDrop] = useState<any>({ draggedFrom: null, draggedTo: null, isDragging: false });
    const tableHeight = props?.tableHeight || "175px";

    const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => {
        setPageConfig({ ...pageConfig, page: newPage });
        // loadPage(newPage);
    };

    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setPageConfig({ page: 0, rowsPerPage: parseInt(event.target?.value, 10) });
    };

    const createSortHandler = (field: any) => () => {
        const order = orderBy[field] === "asc" ? "desc" : "asc";
        // setOrderBy({ ...orderBy, [field]: order });
        setOrderBy({ [field]: order });
    };

    const searchHandler = (text: any) => {
        setSearchText((oldText) => {
            if (text != oldText) {
                setPageConfig((pageConfig) => ({ ...pageConfig, page: 0 }));
            }
            return text;
        });
    };

    useEffect(() => {
        if (fieldsApi) {
            fieldsApi()
                .then((fields: any) => {
                    const { ordered_fields, columns, sorted_fields } = transformedFields(fields);
                    const fieldMap = {};
                    fields.forEach((field: any) => {
                        fieldMap[field._id] = field;
                    });
                    let groupByFields = [];
                    if (toolbarConfig?.groupByFilter) {
                        groupByFields = columns.filter((f) => f.group_by_field);
                    }
                    const filterable_fields = {};
                    const { appId, subAppId } = appInfo;
                    const settings = Settings.getSettings();
                    let columnsMeta = {};
                    if (appInfo.appId && settings && subAppId) {
                        columnsMeta = settings?.[appId]?.[subAppId]?.[subAppId]?.columnsMeta || {};
                    }
                    columns.filter((col) => !(col._id in columnsMeta)).forEach((col) => (columnsMeta[col._id] = true));
                    fields
                        .filter((f) => f.filterable)
                        .forEach((f) => {
                            filterable_fields[f._id] = true;
                        });
                    setFieldsInfo({
                        ...fieldsInfo,
                        fields: ordered_fields,
                        columns: columns,
                        sortedFields: sorted_fields,
                        filterable: filterable_fields,
                        groupByFields: groupByFields,
                        meta: columnsMeta,
                        fieldMap: fieldMap,
                    });
                })
                .catch((e: any) => {
                    errorHandler(e);
                    setFieldsInfo(defaultFieldsInfo);
                });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [fieldsApi, appInfo]);

    const loadPage = React.useCallback(
        (newPage: any = null) => {
            if (tableDataApi) {
                let pageIndex: any = pageConfig?.page;
                if (newPage != null) {
                    pageIndex = newPage;
                }

                setTableData({ rows: [], totalRecords: 0, isLoading: true });
                const params = { ...queryParams.params, page: pageIndex, page_size: pageConfig?.rowsPerPage };
                if (Object.keys(queryParams?.filters)?.length) {
                    let updatedFilter = {};
                    if (filterInfo.filterQuery) {
                        updatedFilter = JSON.parse(filterInfo.filterQuery);
                    }
                    params["filters"] = JSON.stringify({
                        ...updatedFilter,
                        ...queryParams.filters,
                    });
                } else if (filterInfo?.filterQuery) {
                    params["filters"] = filterInfo.filterQuery;
                }
                if (toolbarConfig?.groupByFilter) {
                    params["group_by"] = filterInfo?.groupBy.filter(Boolean).join(",");
                }

                if (toolbarConfig && toolbarConfig?.dateFilter && filterInfo?.date) {
                    params["asof_date"] = filterInfo.date;
                }
                if (toolbarConfig && toolbarConfig?.searchBar && searchText) {
                    params["search_string"] = searchText.toLowerCase();
                }
                if (Object.keys(orderBy).length) {
                    params["sort_fields"] = JSON.stringify(
                        Object.keys(orderBy).map((key) => (orderBy[key] === "desc" ? [key, -1] : [key, 1]))
                    );
                }
                tableDataApi(params)
                    .then((response: any) => {
                        if (response?.records) {
                            setTableData({
                                rows: response?.records,
                                totalRecords: Number(response.total_records),
                                isLoading: false,
                            });
                            if (toolbarConfig?.groupByFilter) {
                                processGroupBy(fieldsInfo, filterInfo, params, setFieldsInfo);
                            }
                        } else {
                            setTableData({ ...defaultTableData, isLoading: false });
                        }
                    })
                    .catch((e: any) => {
                        errorHandler(e);
                        setTableData({ ...defaultTableData, isLoading: false });
                    });
            }
        },
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [pageConfig, queryParams, filterInfo.filterQuery, filterInfo.date, filterInfo?.groupBy, searchText, orderBy]
    );

    useEffect(() => {
        loadPage();
    }, [loadPage]);

    const handleQueryFilter = (updatedFilter = null) => {
        const filterQuery = {};
        const _appliedFilters: any = [];
        let filterList: any = queryFilters;

        if (updatedFilter) {
            filterList = updatedFilter;
        }

        filterList.forEach((filter) => {
            if (filter.column && filter.operator) {
                let query = {};
                let field_title = filter.column;
                const field_info: any = fieldsInfo?.fields.find((f: any) => f._id === filter.column);
                if (field_info) {
                    field_title = field_info.title;
                }
                filter.queryStr = `${field_title} ${filter.operator} '${filter.value}'`;
                query = getFilterQuery(filter);
                if (!filterQuery[filter.column]) {
                    filterQuery[filter.column] = [];
                } else {
                    if (filterQuery[filter.column].find((prop) => checkEquality(query, prop))) {
                        return;
                    }
                }
                filterQuery[filter.column].push(query);
                filter.query = query;
                _appliedFilters.push(filter);
            }
        });

        setFilterInfo({
            ...filterInfo,
            filterQuery: JSON.stringify(filterQuery),
            appliedQueryFilters: _appliedFilters,
        });
        setQueryFilterOpen(false);
    };

    const rightClickHandler = ({ column, operator, value }) => {
        const updatedFilter: any = [...queryFilters, { column, operator, value, query: {}, queryStr: "" }];
        setQueryFilters(updatedFilter);
        setPageConfig({ ...pageConfig, page: 0 });
        handleQueryFilter(updatedFilter);
    };

    const handleRightClick = (event: any, column: string, value: any) => {
        event.preventDefault();
        setMousePositions({
            mouseX: event.clientX - 2,
            mouseY: event.clientY - 4,
            column,
            value,
        });
    };

    const handleClose = ({ operator }) => {
        let { value } = mousePositions;
        const { column } = mousePositions;
        setMousePositions(initialMousePositions);
        if (!operator || !value) {
            return;
        }
        const field_info: any = fieldsInfo?.fields.find((f: any) => f._id === column);
        if (field_info && !field_info.is_string) {
            value = parseFloat(value);
        }
        rightClickHandler({ column, operator, value });
    };

    useEffect(() => {
        if (meta.resizable) {
            const cols: any = table.current?.querySelectorAll("th");
            cols?.forEach.call(cols, (col) => {
                const resizer = document.createElement("div");
                resizer.classList.add("resizer");
                resizer.style.height = `${table?.current?.offsetHeight}px`;
                col.appendChild(resizer);
                createResizableColumn(col, resizer);
            });
        }
    });

    const onDragStart = (event) => {
        const initialPosition = Number(event.currentTarget.dataset.position);
        setDragAndDrop({
            ...dragAndDrop,
            draggedFrom: initialPosition,
            isDragging: true,
        });
        event.dataTransfer.setData("text/html", "");
    };

    const onDragOver = (event) => {
        event.preventDefault();
        const draggedTo = Number(event.currentTarget.dataset.position);
        if (draggedTo !== dragAndDrop.draggedTo) {
            setDragAndDrop({ ...dragAndDrop, draggedTo: draggedTo });
        }
    };

    const onDrop = () => {
        const { draggedFrom, draggedTo } = dragAndDrop;
        const { columns, sortedFields } = fieldsInfo;
        const newOrder = columns;
        if (draggedFrom || draggedTo === 0) {
            if (sortedFields[draggedFrom] && sortedFields[draggedTo]) {
                const fromViewOrder = newOrder.find((f) => f._id === sortedFields[draggedFrom])?.view_order;
                const toViewOrder = newOrder.find((f) => f._id === sortedFields[draggedTo])?.view_order;
                newOrder.forEach((field: any) => {
                    if (field._id === sortedFields[draggedFrom]) {
                        field.view_order = toViewOrder;
                    }
                    if (field._id === sortedFields[draggedTo]) {
                        field.view_order = fromViewOrder;
                    }
                });
                const { ordered_fields, columns, sorted_fields } = transformedFields(newOrder);
                setFieldsInfo({
                    ...fieldsInfo,
                    fields: ordered_fields,
                    columns: columns,
                    sortedFields: sorted_fields,
                });
            }
        }
        setDragAndDrop({ ...dragAndDrop, draggedFrom: null, draggedTo: null, isDragging: false });
    };

    const onDragLeave = () => {
        setDragAndDrop({ ...dragAndDrop, draggedTo: null });
    };

    return (
        <>
            <Toolbar
                classes={classes}
                // appInfo={appInfo}
                filterInfo={filterInfo}
                setFilterInfo={setFilterInfo}
                fieldsInfo={fieldsInfo}
                queryFilterOpen={queryFilterOpen}
                toolbarConfig={toolbarConfig}
                changePage={handleChangePage}
                setFieldsInfo={setFieldsInfo}
                searchHandler={searchHandler}
                setQueryFilterOpen={setQueryFilterOpen}
                setPageConfig={setPageConfig}
                queryFilters={queryFilters}
                setQueryFilters={setQueryFilters}
                handleQueryFilter={handleQueryFilter}
                queryParams={queryParams}
                setQueryParams={setQueryParams}
            />
            {tableData.isLoading ? (
                <Loader />
            ) : (
                <Paper>
                    <TableContainer
                        style={{ display: "block", height: `calc(100vh - ${tableHeight})`, overflowY: "auto" }}
                    >
                        <Table className="table" ref={table} size="small" aria-label="collapsible table" stickyHeader>
                            <TableHead>
                                <TableRow>
                                    {fieldsInfo?.columns.map((field: any, index: number) => {
                                        if (fieldsInfo?.meta?.[field._id]) {
                                            if (isGroupByApplied(fieldsInfo) && field.hide_on_expended_view) {
                                                return null;
                                            }
                                            return (
                                                <TableCell
                                                    className={clsx(classes.tableHeader, {
                                                        ["drop-area"]:
                                                            dragAndDrop && dragAndDrop.draggedTo === Number(index),
                                                        [classes.grpByFistCol]: isGroupByColumn(fieldsInfo, 0, index),
                                                        [classes.grpBySecCol]: isGroupByColumn(fieldsInfo, 1, index),
                                                    })}
                                                    style={{ cursor: "move" }}
                                                    key={field._id}
                                                    align={field.position || "left"}
                                                    sortDirection={orderBy[field._id] || false}
                                                    draggable={meta?.ordering ? true : false}
                                                    onDragStart={meta?.ordering ? onDragStart : undefined}
                                                    onDragOver={meta?.ordering ? onDragOver : undefined}
                                                    onDrop={meta?.ordering ? onDrop : undefined}
                                                    onDragLeave={meta?.ordering ? onDragLeave : undefined}
                                                    data-position={index}
                                                >
                                                    {field.sortable ? (
                                                        <TableSortLabel
                                                            active={orderBy[field._id] ? true : false}
                                                            direction={orderBy[field._id] || "asc"}
                                                            onClick={createSortHandler(field._id)}
                                                        >
                                                            {field.title}
                                                            {orderBy[field._id] ? (
                                                                <span className={classes.visuallyHidden}>
                                                                    {orderBy[field._id] === "desc"
                                                                        ? "sorted descending"
                                                                        : "sorted ascending"}
                                                                </span>
                                                            ) : null}
                                                        </TableSortLabel>
                                                    ) : (
                                                        field.title
                                                    )}
                                                </TableCell>
                                            );
                                        }
                                    })}
                                    {meta?.nested && <TableCell />}
                                </TableRow>
                            </TableHead>
                            <TableBody className={clsx("custom-tbody", { ["dense-table"]: dense })}>
                                {toolbarConfig?.queryFilter && (
                                    <FilterMenu
                                        mousePositions={mousePositions}
                                        handleClose={handleClose}
                                        operators={textOperators}
                                    />
                                )}
                                {tableData.rows.map((row: any, index: number) => (
                                    <Row
                                        key={row.id || row._id}
                                        row={row}
                                        index={index}
                                        fieldsInfo={fieldsInfo}
                                        meta={meta}
                                        nestedTableConfig={nestedTableConfig}
                                        handleRightClick={handleRightClick}
                                        rowConfig={rowConfig}
                                        setTableData={setTableData}
                                        toolbarConfig={toolbarConfig}
                                        filterInfo={filterInfo}
                                    />
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <div className={classes.tableFooter}>
                        <FormControlLabel
                            control={
                                <Switch checked={dense} color="primary" onChange={(e) => setDense(e.target.checked)} />
                            }
                            label="Dense Table"
                        />
                        <TablePagination
                            component="div"
                            count={tableData.totalRecords}
                            page={pageConfig?.page}
                            colSpan={3}
                            onPageChange={handleChangePage}
                            rowsPerPage={pageConfig?.rowsPerPage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                            rowsPerPageOptions={paginationConfig?.rowsPerPageOptions || defaultRowsPerPageOptions}
                            ActionsComponent={TablePaginationActions}
                        />
                    </div>
                </Paper>
            )}
        </>
    );
}
