import React, { useState } from "react";
import { EditorState, convertToRaw, ContentState } from "draft-js";
import { Editor } from "react-draft-wysiwyg";
import draftToHtml from "draftjs-to-html";
import htmlToDraft from "html-to-draftjs";

export default function RichTextEditor({ html, onChange }) {
    const { contentBlocks, entityMap } = htmlToDraft(html);
    const contentState = ContentState.createFromBlockArray(contentBlocks, entityMap);

    const [state, setState] = useState<any>(EditorState.createWithContent(contentState));

    const onEditorStateChange = (editorState) => {
        setState(editorState);
        onChange(draftToHtml(convertToRaw(editorState.getCurrentContent())));
    };

    return (
        <div>
            <Editor
                editorStyle={{ lineHeight: "70%" }}
                editorState={state}
                onEditorStateChange={onEditorStateChange}
                editorClassName="editor-main"
            />
        </div>
    );
}
