import React, { useState, useEffect } from "react";
import Loader from "common/Loader";
import Api from "utils/api";
import errorNotification from "utils/api-error";
import AppCover from "home/dashboad/AppCover";
import { AppContext } from "utils/context";
import PowerBI from "common/PowerBI";

// This widget can wrap aruond an IFrame or a PowerBI (which is also an Iframe)
export default function IFrame() {
    const context = React.useContext(AppContext);
    const app = context.app._id;
    const zone = context.zone.name;
    const [config, setConfig] = useState<any>({ loading: true, iframe: null, powerBiConfig: null });

    useEffect(() => {
        if (app && zone) {
            Api.getZoneSettings(app, zone)
                .then((response: any) => {
                    const conf = response?.iframe_config || null; // try iframe_cnofig first
                    if (!conf) {
                        const powerBiConfig = response?.power_bi_config || null; // if iframe_config is missing try powerbi
                        if (powerBiConfig) {
                            setConfig({ loading: false, iframe: null, powerBiConfig });
                        } else {
                            const errorInfo = {
                                type: "error",
                                text: `Unable to fetch config`,
                                open: true,
                            };
                            errorNotification.next(errorInfo);
                            setConfig({ loading: false });
                        }
                    } else {
                        setConfig({ loading: false, iframe: conf[zone], powerBiConfig: null });
                    }
                })
                .catch((err: any) => {
                    console.log(err);
                    setConfig({ loading: false });
                });
        }
    }, [zone, app]);

    if (config.loading)
        return (
            <AppCover>
                <Loader />
            </AppCover>
        );
    if (config.iframe)
        return (
            <AppCover>
                <iframe src={config.iframe.url} className="iframe" />
            </AppCover>
        );
    if (config.powerBiConfig)
        return (
            <AppCover>
                <PowerBI config={config.powerBiConfig} />
            </AppCover>
        );

    return <AppCover> Not Supported</AppCover>;
}
