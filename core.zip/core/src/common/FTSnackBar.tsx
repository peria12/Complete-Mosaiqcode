import React, { useEffect, useState } from "react";

import { Snackbar } from "@mui/material";
import MuiAlert from "@mui/material/Alert";
interface SnackBarParams {
    snack: {
        type: string;
        text: string;
        duration: number;
    };
    onClose?: any;
}

export default function FTSnackBar(params: SnackBarParams) {
    const {
        snack: { type, text, duration = 4000 },
    } = params;
    const [open, setOpen] = useState(false);

    useEffect(() => {
        if (text) setOpen(true);
    }, [type, text, duration]);

    const closeSnack = () => {
        setOpen(false);
        if (params.onClose) {
            params.onClose();
        }
    };
    if (type == "") return <></>;

    return (
        <Snackbar
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
            open={open}
            autoHideDuration={params?.snack?.duration == -1 ? undefined : duration}
            onClose={closeSnack}
            message={text}
        >
            <MuiAlert elevation={6} variant="filled" severity={type as any}>
                {text}{" "}
            </MuiAlert>
        </Snackbar>
    );
}
