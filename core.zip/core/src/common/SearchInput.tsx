import React, { useMemo } from "react";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";
import Popper from "@mui/material/Popper";

export default function SearchInput({
    field,
    onChange,
    options = [],
    placeholder = "Search..",
    value = null as any,
    disabled = false,
    disableUnderline = false,
    disableClearable = false,
    searchIcon = true,
    label = "",
    customStyle = {},
    forcePopupIcon = false,
    inputPropsStyle = {},
    popperWidth = "",
    onInputChange,
    renderOption = undefined as any,
}: any) {
    const styleParams = { width: "100%", ...customStyle };

    const CustomPopper = function (props) {
        return (
            <Popper {...props} style={{ width: options.length ? popperWidth : undefined }} placement="bottom-start" />
        );
    };

    const localRenderOption = useMemo(() => {
        if (renderOption) {
            return renderOption;
        }
        return undefined;
    }, [renderOption]);

    return (
        <Autocomplete
            freeSolo={true}
            id={"free-solo-" + field}
            size="small"
            style={styleParams}
            disableClearable={disableClearable}
            disabled={disabled}
            onChange={onChange}
            onInputChange={onInputChange}
            forcePopupIcon={forcePopupIcon}
            PopperComponent={CustomPopper}
            value={value}
            renderOption={localRenderOption}
            getOptionLabel={(option) => `${option.label}`}
            options={options}
            renderInput={(params) => (
                <TextField
                    variant={inputPropsStyle.variant || "standard"}
                    {...params}
                    placeholder={placeholder}
                    label={label ? label : null}
                    fullWidth
                    InputProps={{
                        ...params.InputProps,
                        disableUnderline: disableUnderline,
                        style: inputPropsStyle ? inputPropsStyle : { height: "33px" },
                        // endAdornment: (
                        //     <React.Fragment>
                        //         {params.InputProps.endAdornment}
                        //     </React.Fragment>
                        // ),
                        startAdornment: searchIcon ? (
                            <InputAdornment position="start">
                                {" "}
                                <SearchIcon />{" "}
                            </InputAdornment>
                        ) : (
                            <></>
                        ),
                    }}
                />
            )}
        />
    );
}
