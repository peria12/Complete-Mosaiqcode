import React from "react";
import { Theme } from "@mui/material/styles";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import TextField from "@mui/material/TextField";
import { getYesterDaysDate } from "../utils/helpers";

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        container: {
            display: "flex",
            flexWrap: "wrap",
        },
        textField: {
            marginLeft: theme.spacing(1),
            marginRight: theme.spacing(1),
            width: 135,
        },
    })
);

export default function DatePicker({
    dateStr,
    label,
    handleDateChange,
    style = null,
    inputPropsStyle = null,
    shouldDisableOldDates = false,
}: any) {
    const classes = useStyles();

    return (
        <form className={classes.container} noValidate>
            <TextField
                id="date"
                label={label}
                type="date"
                variant="standard"
                style={style ? style : { height: "40px" }}
                value={dateStr}
                onChange={handleDateChange}
                className={classes.textField}
                inputProps={{
                    style: inputPropsStyle ? inputPropsStyle : { padding: "8px" },
                    max: shouldDisableOldDates ? getYesterDaysDate() : null,
                }}
                InputLabelProps={{
                    shrink: true,
                }}
            />
        </form>
    );
}
