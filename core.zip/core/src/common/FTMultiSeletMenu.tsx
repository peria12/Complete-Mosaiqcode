import React, { useState } from "react";
import { FTIconButton } from "./FTButtons";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { Checkbox, ListItemText, Menu, MenuItem, MenuProps } from "@mui/material";

import withStyles from "@mui/styles/withStyles";

const StyledMenu = withStyles({
    paper: {
        border: "1px solid #d3d4d5",
    },
})((props: MenuProps) => {
    return (
        <Menu
            elevation={0}
            // getContentAnchorEl={null}
            anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
            }}
            transformOrigin={{
                vertical: "top",
                horizontal: "center",
            }}
            {...props}
        />
    );
});

export interface FTMultiSelectMenuParams {
    onChange;
    options;
}

export default function FTMultiSelectMenu(params: FTMultiSelectMenuParams) {
    const { onChange, options } = params;
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

    const onClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };
    const onClose = () => setAnchorEl(null);
    return (
        <>
            <FTIconButton
                handler={onClick}
                title="Columns"
                btnIcon={<MoreVertIcon style={{ fontSize: "1.75rem" }} color="primary" />}
                placement="top"
            />
            <StyledMenu id="customized-menu" anchorEl={anchorEl} keepMounted open={Boolean(anchorEl)} onClose={onClose}>
                {options.map((item) => (
                    <MenuItem key={item.key} onClick={() => onChange(item.key)} style={{ padding: "2px 10px" }}>
                        <Checkbox color="primary" checked={item.checked} />
                        <ListItemText primary={item.value} />
                    </MenuItem>
                ))}
            </StyledMenu>
        </>
    );
}
