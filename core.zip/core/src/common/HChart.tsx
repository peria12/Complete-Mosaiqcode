import React from "react";
import * as Highcharts from "highcharts";
import more from "highcharts/highcharts-more";
more(Highcharts);

import { debounceTime } from "rxjs/operators";
import { drawerResizeNotification } from "utils/events";
// import Exporting from 'highcharts/modules/exporting';
// Exporting(Highcharts);
const fontSize = "12px";

export const chartOptions = {
    plotOptions: {
        series: {
            animation: { duration: 300 },
        },
    },
    chart: {
        style: {
            fontFamily: "Roboto Condensed",
        },
    },
    yAxis: {
        labels: { style: { fontSize } },
        title: { style: { fontSize } },
    },
    xAxis: {
        labels: { style: { fontSize } },
        title: { style: { fontSize } },
    },
    credits: {
        enabled: false,
    },
};

const merge = (a, b) => {
    if (b.constructor == Object) {
        if (a.constructor == Array) {
            return a.map((x) => merge(x, b));
        } else {
            for (const key in b) {
                if (key in a) {
                    a[key] = merge(a[key], b[key]);
                } else {
                    a[key] = b[key];
                }
            }
            return a;
        }
    }
    return b;
};

export function HChart({ option, style = {}, height = 300, width = undefined as any }) {
    const id = Math.random().toString(36).substring(7);

    const newOption = merge(option, chartOptions);
    React.useEffect(() => {
        const chart = Highcharts.chart(id, newOption || {});
        const sub = drawerResizeNotification.pipe(debounceTime(5)).subscribe(() => chart.reflow());
        return () => sub.unsubscribe();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [option]);

    return <div style={{ height, width, ...style }} id={id}></div>;
}
