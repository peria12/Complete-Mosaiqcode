import React from "react";
import JSONEditor from "jsoneditor";

export default function JsonEditor({ json, onChangeText }) {
    const [mode, setMode] = React.useState("code");
    const elRef = React.useRef<HTMLDivElement | null>(null);
    const editorRef = React.useRef<JSONEditor | null>(null);

    const unmountEditor = () => {
        editorRef.current?.destroy();
    };

    const onModeChange = (newMode: string) => {
        setMode(newMode);
    };

    React.useEffect(() => {
        //const container = document.getElementById("jsoneditor");
        const container = elRef.current;
        const options = {
            mode: mode,
            onChangeText: onChangeText,
            enableTransform: false,
            onModeChange: onModeChange,
            modes: ["code", "tree", "preview"],
            // enableSort: false,
        };

        if (container) {
            const jsonEditor = new JSONEditor(container, options);
            jsonEditor.set(JSON.parse(json || "{}"));
            editorRef.current = jsonEditor;
        }

        return unmountEditor;
    }, [json, onChangeText, mode]);

    return <div id="jsoneditor" ref={elRef} style={{ height: "100%" }} />;
}
