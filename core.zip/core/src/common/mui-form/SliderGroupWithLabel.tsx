import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Controller } from "react-hook-form";
import TextField from "@mui/material/TextField";
import Input from "@mui/material/Input";
import FTSlider from "common/FTSlider";
import InputAdornment from "@mui/material/InputAdornment";

const useStyles = makeStyles((theme: any) =>
    createStyles({
        root: {
            width: "100%",
            "& .*-track-499": {
                backgroundColor: theme.palette.primary.main,
            },
            "& .MuiSlider-markLabel": {
                marginTop: "10px",
            },
        },
        base: {
            width: "100%",
            display: "flex",
            justifyContent: "flex-start",
            flexDirection: "row",
            alignItems: "center",
            padding: "2px 5px",
        },
        sliderWidth: {
            width: "17rem",
            marginLeft: "15px",
        },
        marginTextBox: {
            marginLeft: "1rem",
        },
        textBox: {
            width: "4rem",
            height: "2rem",
            fontSize: "1rem",
            paddingLeft: "1rem",
            border: "solid 1px #dddddd",
        },
        textField: {
            paddingTop: "9px",
            "& .MuiFormHelperText-root": {
                marginLeft: "1px",
            },
        },
        label: {
            color: "#9b9ba3",
            fontSize: "15px",
            fontWeight: 600,
            textAlign: "left",
        },
        header: {
            paddingLeft: "5px",
        },
    })
);

function NumberInput({ item, err, classes, disabled, getValue, handleChange }) {
    function getErrMsg(id, val) {
        if (val === "") {
            return "Required";
        } else if (err[id]) {
            return "Value must be between 0% and 100%";
        }
    }

    const inputValue = getValue(item.id, "val");
    const errMsg = getErrMsg(item.id, inputValue);
    const isErr = err[item.id] || errMsg;
    return (
        <div className={classes.marginTextBox}>
            <TextField
                variant="outlined"
                className={classes.textField}
                inputProps={{
                    style: {
                        width: "5rem",
                        padding: "9px 10px",
                    },
                }}
                type="number"
                disabled={disabled}
                sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                placeholder=""
                value={inputValue}
                onChange={(e) => handleChange(item, e.target.value, "val")}
                InputProps={{
                    endAdornment: (
                        <InputAdornment position="end" disablePointerEvents>
                            %{" "}
                        </InputAdornment>
                    ),
                }}
                error={isErr}
                helperText={errMsg}
            />
        </div>
    );
}

function SliderGroupWithLabelInput({ field, name, value, setValue }) {
    const classes = useStyles();
    const { disabled, config, min, max, marks, showTextInput, labels } = field;
    const [err, setErr] = React.useState({});
    const getValue = (id, type) => {
        const val = value[id]?.[type];
        if (type == "val" && (val != undefined || val != null)) {
            return val;
        }
        if (val) {
            if (type == "labelValue") {
                return val?.charAt(0)?.toUpperCase() + val?.slice(1);
            }
            return val;
        } else if (type === "value") {
            return 0;
        }
        return "";
    };

    const handleChange = (item, updatedValue, type) => {
        const { id } = item;
        if (showTextInput && type == "val") {
            if (updatedValue == "" || updatedValue < 0 || updatedValue > 100) {
                setErr({ ...err, [id]: true });
            } else {
                setErr({ ...err, [id]: false });
            }
        }
        const _newValue: any = { ...value?.[id], [type]: updatedValue };
        const newValues = { ...value, [id]: _newValue };
        setValue(name, newValues);
    };

    const widths = [10, showTextInput ? 4 : 15, 10];

    return (
        <div className={classes.root}>
            <div className={classes.header + " d-flex w-100"}>
                {labels?.map((label, i) => (
                    <div
                        key={label}
                        className={classes.label}
                        style={{
                            width: `${widths[i]}rem`,
                            padding: "0px 10px",
                            textAlign: "center",
                            marginLeft: i > 0 ? "1rem" : "",
                        }}
                    >
                        {label}
                    </div>
                ))}
            </div>
            {config.map(
                (item, i) =>
                    item.display && (
                        <div key={item.id} className={classes.base}>
                            <TextField
                                variant="outlined"
                                className={classes.textField}
                                inputProps={{
                                    style: {
                                        width: "10rem",
                                        padding: "9px 10px",
                                    },
                                }}
                                disabled
                                sx={{
                                    "& legend": { display: "none" },
                                    "& fieldset": { top: 0 },
                                }}
                                placeholder="Goal name"
                                value={getValue(item.id, "labelValue")}
                                onChange={(e) => handleChange(item, e.target.value, "labelValue")}
                            />
                            {!showTextInput && (
                                <div className={classes.sliderWidth}>
                                    <FTSlider
                                        value={getValue(item.id, "value")}
                                        aria-label="slider"
                                        valueLabelDisplay="auto"
                                        onChange={(event) => handleChange(item, event, "value")}
                                        aria-labelledby="input-slider"
                                        max={max}
                                        min={min}
                                        marks={marks}
                                        disabled={disabled}
                                    />
                                </div>
                            )}
                            <div className={classes.marginTextBox}>
                                <Input
                                    className={classes.textBox}
                                    value={`${getValue(item.id, "value").toFixed(0)}%`}
                                    disabled
                                    name={name}
                                    inputProps={{
                                        min: 0,
                                        max: 100,
                                        type: "text",
                                        "aria-labelledby": "input-slider",
                                    }}
                                />
                            </div>
                            {showTextInput && (
                                <NumberInput
                                    item={item}
                                    err={err}
                                    disabled={i == 0 || disabled}
                                    getValue={getValue}
                                    classes={classes}
                                    handleChange={handleChange}
                                />
                            )}
                        </div>
                    )
            )}
        </div>
    );
}

export const SliderGroupWithLabel = ({ field, control, setValue }) => {
    const name = field.id || field.key;
    return (
        <Controller
            name={name}
            control={control}
            render={({ field: { value } }) => (
                <SliderGroupWithLabelInput field={field} value={value} name={name} setValue={setValue} />
            )}
        />
    );
};
