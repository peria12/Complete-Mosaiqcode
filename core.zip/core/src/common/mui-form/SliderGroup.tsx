import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import Typography from "@mui/material/Typography";
import { Box, Input } from "@mui/material";
import FTSlider from "common/FTSlider";
import { Controller } from "react-hook-form";

const useStyles = makeStyles((theme) => ({
    root: {
        width: "100%",
        "& .*-track-499": {
            backgroundColor: theme.palette.primary.main,
        },
        "& .MuiSlider-markLabel": {
            marginTop: "10px",
        },
    },
    base: {
        width: "100%",
        display: "flex",
        justifyContent: "flex-start",
        flexDirection: "row",
        alignItems: "center",
        padding: "8px 5px",
    },
    sliderWidth: {
        width: "17rem",
        marginLeft: "15px",
    },
    marginTextBox: {
        marginLeft: "1rem",
    },
    textBox: {
        width: "4rem",
        height: "2rem",
        fontSize: "1rem",
        paddingLeft: "1rem",
        border: "solid 1px #dddddd",
    },
    textField: {
        paddingTop: "9px",
        "& .MuiFormHelperText-root": {
            marginLeft: "1px",
        },
    },
}));

const SliderGroupInput = ({ field, name, value, setValue }) => {
    const classes = useStyles();
    const { max, min, marks, disabled, notes, step } = field;

    const handleBlur = () => {
        if (value < 0) {
            setValue(name, 0);
        } else if (value > 100) {
            setValue(name, 100);
        }
    };

    const handleSliderChange = (event, newValue) => {
        setValue(name, newValue);
    };

    function valueLabelFormat(value) {
        const valueText = `$${value?.toLocaleString()}`;
        return valueText;
    }

    return (
        <div className={classes.root}>
            <Box display="flex">
                <div className={classes.sliderWidth} style={notes ? { width: "88%", marginLeft: "2%" } : undefined}>
                    <FTSlider
                        value={typeof value === "number" ? value : 0}
                        aria-label="pretto slider"
                        onChange={handleSliderChange}
                        aria-labelledby="input-slider"
                        max={max}
                        min={min}
                        marks={marks}
                        valueLabelDisplay={notes ? "on" : "auto"}
                        disabled={disabled}
                        valueLabelFormat={notes ? valueLabelFormat : undefined}
                        step={step || 1}
                        style={notes ? { marginTop: "35px" } : undefined}
                    />
                </div>
                {!notes && (
                    <div className={classes.marginTextBox}>
                        <Input
                            className={classes.textBox}
                            value={`${value?.toFixed(0)}%`}
                            disabled
                            onBlur={handleBlur}
                            name={name}
                            inputProps={{
                                min: 0,
                                max: 100,
                                type: "text",
                                "aria-labelledby": "input-slider",
                            }}
                        />
                    </div>
                )}
            </Box>
            {notes && (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <Typography style={{ paddingLeft: "2%" }} gutterBottom align="left">
                        {min}
                    </Typography>
                    <Typography gutterBottom align="right">
                        ${max?.toLocaleString()}
                    </Typography>
                </div>
            )}
        </div>
    );
};

export const SliderGroup = ({ field, control, setValue }) => {
    const name = field.id || field.key;
    return (
        <Controller
            name={name}
            control={control}
            render={({ field: { value } }) => (
                <SliderGroupInput field={field} value={value} name={name} setValue={setValue} />
            )}
        />
    );
};
