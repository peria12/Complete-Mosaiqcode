import React from "react";
import { FormControl, FormControlLabel, FormLabel, Radio, RadioGroup } from "@mui/material";
import { Controller } from "react-hook-form";

const generateRadioOptions = (options) => {
    return options?.map((singleOption) => (
        <FormControlLabel
            key={singleOption.key}
            value={singleOption.key}
            label={singleOption.label || singleOption.value}
            control={<Radio color="primary" size="small" style={{ padding: "5px" }} />}
        />
    ));
};

export const FormInputRadio = ({ field, control }) => {
    const name = field.id || field.key || field.name;
    const label = field.title;
    const options = field.options || field.states;
    const row = field?.row === false ? false : true;

    return (
        <FormControl component="fieldset" disabled={field.disabled}>
            <FormLabel component="legend">{label}</FormLabel>
            <Controller
                name={name}
                control={control}
                render={({ field: { onChange, value } }) => (
                    <RadioGroup row={row} value={value} onChange={onChange}>
                        {generateRadioOptions(options)}
                    </RadioGroup>
                )}
            />
        </FormControl>
    );
};
