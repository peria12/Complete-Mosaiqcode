import React from "react";
import { Controller } from "react-hook-form";
import { ErrorMessage } from "./ErrorMessage";
import { FormFile } from "common/forms/FormFile";

export const FormFileInput = ({ field, methods, errors }) => {
    const hasErrors = Object.keys(errors)?.length || false;
    return (
        <Controller
            name={field.name}
            control={methods.control}
            rules={{
                required: field.required,
            }}
            render={({ field: { onChange } }) => (
                <>
                    <FormFile
                        title={field.text || "Drag and Drop or Select File (Only *.csv files will be accepted)"}
                        value={[]}
                        onChange={(e) => onChange(e.filter((x) => x))}
                        multiple={field.multiple || false}
                        height={"70px"}
                        accept={field.accept}
                    />
                    {hasErrors && <ErrorMessage field={field} errors={errors} />}
                </>
            )}
        />
    );
};
