import React from "react";
import { FormControl, InputLabel } from "@mui/material";
import { Controller } from "react-hook-form";
import { ErrorMessage } from "./ErrorMessage";
import RichTextEditor from "common/RichTextEditor";

export const FormRichText = ({ control, field, errors, setValue }) => {
    const name = field.id || field.key || field.name;
    const label = field.title || "";
    const required = field.required || false;
    const isErrors = Object.keys(errors)?.length || false;
    const hideField = field.display === false ? true : false;

    return (
        <>
            {!hideField && (
                <FormControl size={"small"} style={{ width: "100%" }}>
                    <InputLabel>{label}</InputLabel>
                    <Controller
                        render={({ field: { value } }) => (
                            <RichTextEditor html={value || ""} onChange={(html) => setValue(name, html)} />
                        )}
                        rules={{
                            required: required,
                        }}
                        control={control}
                        name={name}
                    />
                    {isErrors && <ErrorMessage field={field} errors={errors} />}
                </FormControl>
            )}
        </>
    );
};
