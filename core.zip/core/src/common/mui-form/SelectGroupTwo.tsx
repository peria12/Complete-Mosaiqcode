import React, { useState, useEffect } from "react";
import { Button, MenuItem, Select } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import AddIcon from "@mui/icons-material/Add";
import CancelIcon from "@mui/icons-material/Cancel";
import { Controller } from "react-hook-form";
import clsx from "clsx";

const useStyles = makeStyles(() => ({
    container: {
        background: "#f2f2f2;",
        width: "55%",
        display: "flex",
        justifyContent: "flex-start",
        flexDirection: "column",
        alignItems: "center",
        padding: "15px 16px",
    },
    selectRow: {
        width: "100%",
        display: "flex",
        marginTop: "10px",
        alignItems: "center",
        flexDirection: "row",
        justifyContent: "flex-start",
    },
    labelContainer: {
        display: "flex",
        alignItems: "center",
        width: "100%",
    },
    label: {
        color: "#9b9ba3",
        width: "40%",
        fontSize: "15px",
        fontWeight: 700,
        textTransform: "uppercase",
        textAlign: "left",
        marginLeft: "15px",
    },
    selectRoot: {
        fontSize: ".92rem",
        width: "100%",
        padding: "10px 14px",
    },
    addContainer: {
        display: "flex",
        justifyContent: "flex-end",
        marginRight: "auto",
        width: "100%",
        marginTop: "8px",
    },

    hiddenAddContainer: {
        display: "none",
    },
    cancelIcon: {
        cursor: "pointer",
    },
}));

const getRemainingOptions = (options, fields) =>
    options.filter((item) => !fields?.find((field) => field?.key === item?.key));

const SelectGroupTwoInput = ({ field, value, name, setValue, optionsTwo }) => {
    const classes = useStyles();
    const { options, disabled, selectFieldLabels, validation } = field;
    const [remainingOptions, setRemainingOptions] = useState(getRemainingOptions(options, value));
    const [opts, setOpts] = useState([]);
    const [opts2, setOpts2] = useState([]);

    const handleAdd = () => {
        if (!disabled && options?.length > value?.length) {
            let item = {
                key: remainingOptions[0]?.key,
                value: remainingOptions[0]?.value,
            };
            if (validation?.optOrders) {
                item = { key: "", value: "" };
                createOptions(value);
            }
            setValue(name, [...value, item]);
        }
    };

    function createOptions(value) {
        resetOpts(0, value);
        resetOpts2(0, value);
    }

    useEffect(() => {
        if (validation?.optOrders) {
            createOptions(value);
        }
        // eslint-disable-next-line
    }, [validation]);

    function resetOpts(from, values) {
        const newOpts: any = [...opts];
        newOpts[0] = [...options];
        for (let i = from; i < values.length; i++) {
            const val = values[i];
            if (val.key) {
                newOpts[i + 1] = options?.filter((op) => op.key > val?.key);
            } else {
                newOpts[i + 1] = [...newOpts[i]];
            }
        }
        setOpts(newOpts);
    }

    function resetOpts2(from, values) {
        const newOpts: any = [...opts2];
        newOpts[0] = optionsTwo ? [...optionsTwo] : [];
        for (let i = from; i < values.length; i++) {
            const val = values[i];
            if (val.valueTwo) {
                newOpts[i + 1] = optionsTwo?.filter((op) => op.key < val?.valueTwo);
            } else {
                newOpts[i + 1] = [...newOpts[i]];
            }
        }
        setOpts2(newOpts);
    }

    const handleCancel = (deleteIndex) => {
        const newInputs = value.filter((item, itemIndex) => deleteIndex !== itemIndex);
        setValue(name, newInputs);
    };

    useEffect(() => {
        setRemainingOptions(getRemainingOptions(options, value));
    }, [options, value]);

    const isSelected = (key) => !!value?.find((v) => v.key == key);

    function SelectField({ value, onChange, options, disabled }) {
        return (
            <Select
                value={value}
                onChange={(x) => onChange(x.target.value)}
                variant={"outlined"}
                disabled={disabled}
                style={{ width: "40%", marginLeft: "8px" }}
                classes={{ select: classes.selectRoot }}
                displayEmpty
                sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                renderValue={(value: any) => {
                    if ([undefined, null, ""].includes(value)) {
                        return "Select...";
                    }
                    return value;
                }}
            >
                {options?.length === 0 && (
                    <MenuItem disabled value={""}>
                        {" "}
                        No Options{" "}
                    </MenuItem>
                )}
                {options?.map((item: any) => (
                    <MenuItem
                        key={item.key}
                        value={item.key}
                        className={clsx({ ["Mui-disabled"]: isSelected(item.key) })}
                    >
                        {item.value}
                    </MenuItem>
                ))}
            </Select>
        );
    }

    const handleSelect = (selectedValue, allocationIndex) => {
        const newArray = [...value];
        newArray[allocationIndex].key = selectedValue;
        newArray[allocationIndex].value = selectedValue;
        if (validation?.optOrders && newArray[allocationIndex + 1]) {
            for (let i = allocationIndex + 1; i < newArray.length; i++) {
                newArray[i].key = "";
                newArray[i].value = "";
            }
            resetOpts(allocationIndex, newArray);
        }
        setValue(name, newArray);
    };

    const handleEdit = (input, allocationIndex) => {
        const newArray = [...value];
        newArray[allocationIndex].valueTwo = input;
        if (validation?.optOrders && newArray[allocationIndex + 1] && input) {
            for (let i = allocationIndex + 1; i < newArray.length; i++) {
                newArray[i].valueTwo = "";
            }
            resetOpts2(allocationIndex, newArray);
        }
        setValue(name, newArray);
    };

    const getOptions = (id, index, info: any = {}) => {
        if (validation?.optOrders) {
            if (id == 2) {
                return opts2[index] || [];
            }
            return opts[index] || [];
        }
        if (id == 2) {
            return optionsTwo ? optionsTwo[info?.key] : [];
        }
        return options || [];
    };

    const showAddbtn = validation?.max ? validation?.max > value.length : true;

    return (
        <div className={classes.container}>
            <div className={classes.labelContainer}>
                <div className={classes.label}>{selectFieldLabels?.[0]}</div>
                <div className={classes.label}> {selectFieldLabels?.[1]}</div>
            </div>
            {value?.map((item, allocationIndex) =>
                item.key || (validation?.optOrders && "key" in item) ? (
                    <div className={classes.selectRow} key={item.key + allocationIndex}>
                        <SelectField
                            disabled={disabled}
                            value={item.key}
                            options={getOptions(1, allocationIndex) || []}
                            onChange={(selectedValue) => {
                                handleSelect(selectedValue, allocationIndex);
                                handleEdit("", allocationIndex);
                            }}
                        />
                        <SelectField
                            disabled={disabled}
                            value={value[allocationIndex].valueTwo}
                            onChange={(selectedValue) => handleEdit(selectedValue, allocationIndex)}
                            options={getOptions(2, allocationIndex, value[allocationIndex] || [])}
                        />
                        {!disabled && (
                            <div
                                style={{
                                    marginLeft: "15px",
                                }}
                            >
                                <CancelIcon
                                    className={classes.cancelIcon}
                                    onClick={() => handleCancel(allocationIndex)}
                                />
                            </div>
                        )}
                    </div>
                ) : null
            )}
            {showAddbtn && (
                <div className={options.length <= value.length ? classes.hiddenAddContainer : classes.addContainer}>
                    <Button startIcon={<AddIcon />} color="primary" onClick={handleAdd}>
                        {" "}
                        Add{" "}
                    </Button>
                </div>
            )}
        </div>
    );
};

export const SelectGroupTwo = ({ field, control, setValue, configState }) => {
    const name = field.id || field.key;
    return (
        <Controller
            name={name}
            control={control}
            render={({ field: { value } }) => (
                <SelectGroupTwoInput
                    field={field}
                    value={value || []}
                    name={name}
                    setValue={setValue}
                    optionsTwo={configState}
                />
            )}
        />
    );
};
