import React from "react";
import { FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import { Controller } from "react-hook-form";
import { ErrorMessage } from "./ErrorMessage";

export const FormInputDropdown = ({ control, field, errors, defaultValue, variant, style, configState }) => {
    const name = field.id || field.key || field.name;
    const label = field.title || "";
    const options = field.options || configState;
    const disabled = field.disabled || false;
    const isErrors = Object.keys(errors)?.length || false;
    const hideField = field.display === false ? true : false;
    const placeholderText = field.placeholder ? (
        <span style={{ color: "#9E9E9E" }}>{`Select ${field.placeholder}`} </span>
    ) : (
        ""
    );
    return (
        <>
            {!hideField && (
                <FormControl size={"small"} style={{ width: "100%" }}>
                    <InputLabel shrink={true}>{label}</InputLabel>
                    <Controller
                        render={({ field: { onChange, value }, fieldState: { error } }) => (
                            <Select
                                sx={{
                                    "& legend": { display: "none" },
                                    "& fieldset": { top: 0 },
                                }}
                                onChange={onChange}
                                value={value || ""}
                                style={style || field.style}
                                variant={disabled ? "filled" : variant}
                                error={!!error}
                                disabled={disabled}
                                displayEmpty={!disabled}
                                renderValue={(value: any) => {
                                    if ([undefined, null, ""].includes(value)) {
                                        return placeholderText;
                                    } else {
                                        const option = options?.find((o) => o?.key == value);
                                        return option ? option.value : placeholderText;
                                    }
                                    return value;
                                }}
                            >
                                {options?.length === 0 && (
                                    <MenuItem disabled value={""}>
                                        {" "}
                                        No Options{" "}
                                    </MenuItem>
                                )}
                                {options?.length > 0 &&
                                    options?.map((option: any) => (
                                        <MenuItem key={option.key} value={option.key}>
                                            {option.value}
                                        </MenuItem>
                                    ))}
                            </Select>
                        )}
                        rules={{
                            required: true,
                        }}
                        control={control}
                        name={name}
                        defaultValue={defaultValue}
                    />
                    {isErrors && <ErrorMessage field={field} errors={errors} />}
                </FormControl>
            )}
        </>
    );
};
