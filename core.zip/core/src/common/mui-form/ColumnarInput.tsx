import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Controller } from "react-hook-form";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";

const useStyles = makeStyles((theme: any) =>
    createStyles({
        root: {
            width: "100%",
            "& .*-track-499": {
                backgroundColor: theme.palette.primary.main,
            },
            "& .MuiSlider-markLabel": {
                marginTop: "10px",
            },
        },
        base: {
            width: "100%",
            display: "flex",
            justifyContent: "flex-start",
            flexDirection: "row",
            alignItems: "center",
            padding: "2px 5px",
        },
        sliderWidth: {
            width: "17rem",
            marginLeft: "15px",
        },
        marginTextBox: {
            marginLeft: "1rem",
        },
        textBox: {
            width: "4rem",
            height: "2rem",
            fontSize: "1rem",
            paddingLeft: "1rem",
            border: "solid 1px #dddddd",
        },
        textField: {
            paddingTop: "9px",
            "& .MuiFormHelperText-root": {
                marginLeft: "1px",
            },
        },
        label: {
            color: "#9b9ba3",
            fontSize: "15px",
            fontWeight: 600,
            textAlign: "left",
        },
        header: {
            paddingLeft: "5px",
        },
    })
);

function NumberInput({ item, err, classes, disabled, getValue, handleChange, name }) {
    function getErrMsg(id, value, type) {
        if (value === "") {
            return "Required";
        } else if (err[id + "-" + type] && (type == "labelValue" || type == "value")) {
            return "Value must be between 0% and 100%";
        } else if (err[id + "-" + type] && type == "val") {
            return "Value must be between 0 and 1";
        }
    }
    let inputValue = "";
    let inputType = "";
    if (name == "min_probability") {
        inputType = "labelValue";
        inputValue = getValue(item.id, inputType) || 0;
    } else if (name == "max_probability") {
        inputType = "value";
        inputValue = getValue(item.id, inputType) || 0;
    } else {
        inputType = "val";
        inputValue = getValue(item.id, inputType) || 0;
    }

    const errMsg = getErrMsg(item.id, inputValue, inputType);
    const isErr = err[item.id + "-" + inputType] || errMsg;
    return (
        <div className={classes.marginTextBox}>
            <TextField
                variant="outlined"
                className={classes.textField}
                inputProps={{
                    style: {
                        width: "5rem",
                        padding: "9px 10px",
                    },
                }}
                type="number"
                disabled={disabled}
                sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                placeholder=""
                value={inputValue}
                onChange={(e) => handleChange(item, e.target.value, inputType)}
                InputProps={{
                    endAdornment: inputType != "val" ? (
                        <InputAdornment position="end" disablePointerEvents>
                            %{" "}
                        </InputAdornment>
                    ): (<InputAdornment position="end" disablePointerEvents>
                    {" "}
                </InputAdornment>)
                }}
                error={isErr}
                helperText={errMsg}
            />
        </div>
    );
}

function ColumnarWithLabelInput({ field, name, value, setValue }) {
    const classes = useStyles();
    const { disabled, config, showTextInput, labels, display } = field;
    const [err, setErr] = React.useState({});
    const getValue = (id, type) => {
        const val = value[id]?.[type];
        console.log("value", value);
        console.log(val);
        if (type == "val" && (val != undefined || val != null)) {
            return val;
        }
        if (val) {
            if (type == "labelValue") {
                return val;
            }
            return val;
        } else if (type === "value") {
            return 0;
        }
        return "";
    };

    const handleChange = (item, updatedValue, type) => {
        const { id } = item;
        if (showTextInput && type == "value") {
            if (updatedValue == "" || updatedValue < 0 || updatedValue > 100) {
                setErr({ ...err, [id + "-" + type]: true });
            } else {
                setErr({ ...err, [id + "-" + type]: false });
            }
        } else if (showTextInput && type == "labelValue") {
            if (updatedValue == "" || updatedValue < 0 || updatedValue > 100) {
                setErr({ ...err, [id + "-" + type]: true });
            } else {
                setErr({ ...err, [id + "-" + type]: false });
            }
        } else if (showTextInput && type == "val") {
            if (updatedValue == "" || updatedValue < 0 || updatedValue > 1) {
                setErr({ ...err, [id + "-" + type]: true });
            } else {
                setErr({ ...err, [id + "-" + type]: false });
            }
        }
        const _newValue: any = { ...value?.[id], [type]: updatedValue };
        const newValues = { ...value, [id]: _newValue };
        setValue(name, newValues);
        console.log("newValues", newValues);
    };

    const widths = [10, 4, 10];

    return (
        <div className={classes.root}>
            <div className={classes.header + " d-flex w-100"}>
                {labels?.map((label, i) => (
                    <div
                        key={label}
                        className={classes.label}
                        style={{
                            width: `${widths[i]}rem`,
                            padding: "0px 10px",
                            textAlign: "center",
                            marginLeft: i > 0 ? "1rem" : "",
                        }}
                    >
                        {label}
                    </div>
                ))}
            </div>
            {config.map(
                (item) =>
                    display && (
                        <div key={item.id} className={classes.base}>
                            <div className={classes.marginTextBox}>
                                <NumberInput
                                    item={item}
                                    err={err}
                                    disabled={disabled}
                                    getValue={getValue}
                                    classes={classes}
                                    handleChange={handleChange}
                                    name={item.levels[0].name}
                                />
                            </div>
                            <div className={classes.marginTextBox}>
                                <NumberInput
                                    item={item}
                                    err={err}
                                    disabled={disabled}
                                    getValue={getValue}
                                    classes={classes}
                                    handleChange={handleChange}
                                    name={item.levels[1].name}
                                />
                            </div>
                            <NumberInput
                                item={item}
                                err={err}
                                disabled={disabled}
                                getValue={getValue}
                                classes={classes}
                                handleChange={handleChange}
                                name={item.levels[2].name}
                            />
                        </div>
                    )
            )}
        </div>
    );
}

export const ColumnarInput = ({ field, control, setValue }) => {
    const name = field.id || field.key;
    return (
        <Controller
            name={name}
            control={control}
            render={({ field: { value } }) => (
                <ColumnarWithLabelInput field={field} value={value} name={name} setValue={setValue} />
            )}
        />
    );
};
