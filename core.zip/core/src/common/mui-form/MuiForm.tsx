import React from "react";
import Typography from "@mui/material/Typography";
import { FormInputText } from "./FormInputText";
import { FormInputMultiCheckbox } from "./FormInputMultiCheckbox";
import { FormInputDropdown } from "./FormInputDropdown";
import { FormInputDate } from "./FormInputDate";
import { FormInputRadio } from "./FormInputRadio";
import RichTextEditor from "common/RichTextEditor";
import { FormAutocomplete } from "./FormAutocomplete";
import { FormSwitch } from "./FormSwitch";
import { RangeSelectGroup } from "./RangeSelectGroup";
import { RangeText } from "./RangeText";
import { FormSelectGroup } from "./FormSelectGroup";
import { DateGroup } from "./DateGroup";
import { SliderGroupWithLabel } from "./SliderGroupWithLabel";
import { ColumnarInput } from "./ColumnarInput";
import { RangeInputGroup } from "./RangeInputGroup";
import { SliderGroup } from "./SliderGroup";
import { SelectGroupTwo } from "./SelectGroupTwo";
import GoeForm from "home/goe/common/GoeForm";
import { FormFileInput } from "./FormFileInput";
import { NumberGroupField } from "./NumberGroupField";
import { FormRichText } from "./FormRichText";
import { NumberInputBtn } from "./NumberInputBtn";
import { Tooltip } from "@mui/material";
import { FileUploadDownload } from "./FileUploadDownload";

const html = "<p></p>";

interface FormProps {
    field: any;
    value?: any;
    onChange?: any;
    methods: any;
    provider?: any;
    handleAdd?: any;
    variant?: string;
    style?: any;
    configState?: any;
    customErrorHandler?: any;
    showPlaceholder?: boolean;
}

export function MuiFormLine({ field, methods }) {
    return (
        <GoeForm label={field.label}>
            <MuiForm
                field={field}
                methods={methods}
                style={{ width: field.width || "100%" }}
                variant="outlined"
                showPlaceholder={true}
            />
        </GoeForm>
    );
}

function getElement(props) {
    const {
        field,
        value,
        methods,
        provider,
        handleAdd,
        variant,
        style,
        configState,
        customErrorHandler,
        showPlaceholder = false,
    } = props;
    if (showPlaceholder && !field.placeholder) {
        field.placeholder = field.label || "";
    }
    const {
        control,
        setValue,
        formState: { errors },
    } = methods;

    switch (field.type) {
        case "text":
        case "email":
        case "percent":
        case "number":
            return (
                <FormInputText
                    control={control}
                    methods={methods}
                    field={field}
                    defaultValue={value}
                    variant={variant}
                    style={style}
                    errors={errors}
                />
            );

        case "date":
            return (
                <FormInputDate
                    name={field.id || field.key || field.name}
                    control={control}
                    label={field.title}
                    defaultValue={value}
                    format={field?.format}
                />
            );

        case "select-search":
            return (
                <FormAutocomplete
                    name={field.id || field.name}
                    control={control}
                    handleAdd={handleAdd}
                    key={value}
                    provider={provider}
                    label={field.title}
                />
            );

        case "select":
            return (
                <FormInputDropdown
                    control={control}
                    defaultValue={value}
                    variant={variant}
                    style={style}
                    field={field}
                    configState={configState}
                    errors={errors}
                />
            );

        case "select-group":
            return <FormSelectGroup control={control} field={field} options={field.options} value={value} />;

        case "checkbox":
            return (
                <FormInputMultiCheckbox
                    control={control}
                    setValue={setValue}
                    name={field.id || field.name}
                    label={field.title}
                    options={field.options}
                    displayOrder={field.displayOrder}
                />
            );

        case "radio":
            return <FormInputRadio control={control} field={field} />;

        case "files":
            return (
                <>
                    <Typography style={{ width: "100%", fontSize: "17px", paddingBottom: "10px" }} color="textPrimary">
                        {field.title}
                    </Typography>
                    <div>
                        <FormFileInput field={field} methods={methods} errors={errors} />
                    </div>
                </>
            );

        case "richText":
            return (
                <>
                    <Typography style={{ width: "100%", fontSize: "17px", paddingBottom: "10px" }} color="textPrimary">
                        {field.title}
                    </Typography>
                    <RichTextEditor html={html} onChange={(html) => props.onChange(html)} />
                </>
            );

        case "switch":
            return <FormSwitch control={control} states={field?.states} field={field} />;
        case "rich-text":
            return <FormRichText control={control} field={field} errors={errors} setValue={setValue} />;

        case "range-select-group":
            return <RangeSelectGroup field={field} methods={methods} customErrorHandler={customErrorHandler} />;

        case "range-text":
            return <RangeText methods={methods} field={field} errors={errors} />;

        case "date-group":
            return <DateGroup control={control} field={field} setValue={setValue} />;

        case "slider-group-with-label":
            return <SliderGroupWithLabel control={control} field={field} setValue={setValue} />;
        case "columnar-input":
            return <ColumnarInput control={control} field={field} setValue={setValue} />;

        case "range-input-group":
            return <RangeInputGroup control={control} field={field} setValue={setValue} />;

        case "slider-group":
            return <SliderGroup control={control} field={field} setValue={setValue} />;

        case "select-group-two":
            return <SelectGroupTwo control={control} field={field} setValue={setValue} configState={configState} />;

        case "number-group":
            return <NumberGroupField control={control} field={field} setValue={setValue} />;

        case "number-input-btn":
            return <NumberInputBtn control={control} field={field} setValue={setValue} />;

        case "file-upload-download":
            return <FileUploadDownload control={control} field={field} setValue={setValue} configState={configState} />;

        case "heading":
            return (
                <>
                    {field?.label && (
                        <div style={{ fontSize: "21px", padding: "5px 0", fontWeight: 600, marginLeft: "-10px" }}>
                            {field?.label}{" "}
                        </div>
                    )}
                </>
            );

        case "placeholder":
            return <></>;

        default:
            return <div>Field Type {field.type} Not Supported</div>;
    }
}

export function MuiForm(props: FormProps) {
    if (props.field.tooltip) {
        return (
            <Tooltip title={props.field.tooltip} placement="right" arrow>
                <div>{getElement(props)}</div>
            </Tooltip>
        );
    }
    return getElement(props);
}
