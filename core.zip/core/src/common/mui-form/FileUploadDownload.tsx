import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Controller } from "react-hook-form";
import Button from "@mui/material/Button";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import FileDownloadIcon from "@mui/icons-material/FileDownload";
import Api from "utils/api";
import { downloadFile } from "utils/helpers";
import errorNotification from "utils/api-error";

const useStyles = makeStyles(() =>
    createStyles({
        container: {
            display: "flex",
        },
        btn: {
            textTransform: "capitalize",
            color: "grey",
            borderColor: "grey",
        },
        disabled: {
            background: "rgba(0, 0, 0, 0.12)",
        },
    })
);

function FileUploadDownloadField({ name, field, value, setValue, configState }) {
    const classes = useStyles();
    const { disabled, path } = field;
    const [file, setFile] = React.useState(null);
    const templateId = configState?.[name];

    function addFile(event: any) {
        event.preventDefault();
        const file = event.target.files[0];
        setFile(file);
    }
    function showError(res) {
        errorNotification.next({ type: "error", text: res?.message || "Error uploading file", open: true });
    }

    function handler() {
        if (!file) {
            errorNotification.next({ type: "error", text: "Please select file to upload", open: true });
            return;
        }
        Api.uploadFile(path, { fieldName: name, file: [file] })
            .then((res) => {
                const response = res?.response || [];
                if (response[0]?.file_id) {
                    setValue(name, response[0]?.file_id);
                } else {
                    showError(res);
                    return;
                }
            })
            .catch((e) => {
                if(e?.response?.data?.message) {
                    showError({message: e?.response?.data?.message});


                }else {
                    console.log("Err", e);

                    showError(e);
                }
            });
    }
    return (
        <div className={classes.container}>
            {templateId && (
                <Button
                    className={classes.btn}
                    size={"small"}
                    variant="outlined"
                    component="label"
                    style={{ marginLeft: 8 }}
                    startIcon={<FileDownloadIcon />}
                    disabled={disabled}
                    onClick={() => Api.getFileRaw(templateId).then(downloadFile)}
                >
                    Template
                </Button>
            )}
            <input
                type="file"
                disabled={disabled}
                style={{ width: "250px", marginLeft: 10 }}
                accept={".xlsx, .xls, .csv"}
                onChange={addFile}
            />
            <Button
                className={classes.btn}
                size={"small"}
                variant="outlined"
                component="label"
                startIcon={<FileUploadIcon />}
                disabled={disabled}
                onClick={handler}
            >
                Upload File
            </Button>
            {value && (
                <Button
                    className={classes.btn}
                    size={"small"}
                    variant="outlined"
                    component="label"
                    style={{ marginLeft: 8 }}
                    startIcon={<FileDownloadIcon />}
                    disabled={disabled}
                    onClick={() => Api.getFileRaw(value).then(downloadFile)}
                >
                    Download File
                </Button>
            )}
        </div>
    );
}

export const FileUploadDownload = ({ field, control, setValue, configState }) => {
    const name = field.id || field.key;
    return (
        <div style={{ width: "100%" }}>
            <Controller
                name={name}
                control={control}
                render={({ field: { value } }) => (
                    <FileUploadDownloadField
                        value={value}
                        name={name}
                        field={field}
                        setValue={setValue}
                        configState={configState}
                    />
                )}
            />
        </div>
    );
};
