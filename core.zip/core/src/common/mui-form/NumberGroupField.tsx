import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import TextField from "@mui/material/TextField";
import { Controller } from "react-hook-form";

const useStyles = makeStyles(() =>
    createStyles({
        container: {
            display: "flex",
        },
        label: {
            fontSize: "15px",
            marginBottom: "9px",
            marginLeft: "5px",
        },
        emailError: {
            color: "#f44336",
        },
        inputContainer: {
            width: "130px",
            marginRight: "12px",
        },
    })
);

function NumberGroupFieldInput({ field, name, value, setValue }) {
    const { min, max, config, disabled } = field;
    const classes = useStyles();
    const [errorText, setErrorText] = React.useState({});

    const handleOnChange = (val, objectKey, index) => {
        setErrorText({ ...errorText, [index + 1]: "" });
        setValue(name, { ...value, [objectKey]: val });
        if (max !== false && parseFloat(val) > max) {
            setErrorText({ [index + 1]: `Cannot Enter a value more than ${max}` });
            return 0;
        }
        if (min !== false && parseFloat(val) < min) {
            setErrorText({ [index + 1]: `Cannot Enter a value less than ${min}` });
            return 0;
        }
        if (val !== "" && isNaN(parseFloat(val))) {
            setErrorText({ [index + 1]: `Invalid Number` });
            return 0;
        }
        setValue(name, { ...value, [objectKey]: val === "" ? val : parseFloat(val) });
        return 0;
    };

    const getErrorText = (index) => errorText?.[index + 1] || "";

    return (
        <div className={classes.container}>
            {config?.map((item, index) => (
                <div className={classes.inputContainer} key={index}>
                    <p className={classes.label}>{item.label}</p>
                    <TextField
                        variant="outlined"
                        inputProps={{
                            style: { padding: "10px", marginTop: "-4px" },
                        }}
                        size="small"
                        sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                        type="number"
                        placeholder={item.label}
                        onChange={(e) => handleOnChange(e.target.value, item.objectKey, index)}
                        disabled={disabled}
                        value={
                            value?.[item?.objectKey] || value?.[item?.objectKey] === 0 ? value?.[item?.objectKey] : ""
                        }
                    />
                    <div className={classes.emailError}>{getErrorText(index)}</div>
                </div>
            ))}
        </div>
    );
}

export const NumberGroupField = ({ field, control, setValue }) => {
    const name = field.id || field.key;
    return (
        <div style={{ width: "100%" }}>
            <Controller
                name={name}
                control={control}
                render={({ field: { value } }) => (
                    <NumberGroupFieldInput field={field} value={value} name={name} setValue={setValue} />
                )}
            />
        </div>
    );
};
