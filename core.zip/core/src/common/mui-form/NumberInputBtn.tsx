import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Controller } from "react-hook-form";
import Paper from "@mui/material/Paper";
import InputBase from "@mui/material/InputBase";
import IconButton from "@mui/material/IconButton";
import RemoveOutlinedIcon from "@mui/icons-material/RemoveOutlined";
import AddRoundedIcon from "@mui/icons-material/AddRounded";

const useStyles = makeStyles(() =>
    createStyles({
        container: {
            display: "flex",
        },
        disabled: {
            background: "rgba(0, 0, 0, 0.12)",
        },
    })
);

function NumberInputBtnField({ name, field, value, setValue, disabled }) {
    const classes = useStyles();
    const diff = field?.step || 1;
    const handleOnChange = (operation) => {
        let updatedVal = value || 0;
        if (operation == "add") {
            updatedVal = updatedVal + diff;
        } else if (updatedVal > 0) {
            updatedVal = updatedVal - diff;
            if (updatedVal < 0) {
                updatedVal = 0;
            }
        }
        setValue(name, Number(updatedVal));
    };

    function handleInputChange(event) {
        const val = event.target.value;
        if (val == "") {
            setValue(name, "");
            return;
        } else if (isNaN(Number(val)) || val < 0) {
            return;
        }
        setValue(name, Number(val));
    }

    const btnStyle = { p: "10px", borderRadius: 0 };

    return (
        <div className={classes.container}>
            <Paper
                className={disabled ? classes.disabled : undefined}
                sx={{ display: "flex", alignItems: "center", width: "100%" }}
            >
                {/* type="number" inputProps={{ className: "no-arrow" }} */}
                <InputBase
                    sx={{ ml: 1, flex: 1 }}
                    placeholder=""
                    value={value}
                    onChange={(e) => handleInputChange(e)}
                    disabled={disabled}
                    onBlur={() => {
                        if (value == "") {
                            setValue(name, 0);
                        }
                    }}
                />
                <IconButton sx={btnStyle} onClick={() => handleOnChange("sub")} disabled={disabled}>
                    <RemoveOutlinedIcon />
                </IconButton>
                <IconButton sx={btnStyle} onClick={() => handleOnChange("add")} disabled={disabled}>
                    <AddRoundedIcon />
                </IconButton>
            </Paper>
        </div>
    );
}

export const NumberInputBtn = ({ field, control, setValue }) => {
    const name = field.id || field.key;
    const disabled = field.disabled || false;
    return (
        <div style={{ width: "100%" }}>
            <Controller
                name={name}
                control={control}
                render={({ field: { value } }) => {
                    if (field?.displayTextOnly) {
                        return (
                            <div style={{ paddingLeft: "4px" }}>
                                <b>{value}</b>
                            </div>
                        );
                    }
                    return (
                        <NumberInputBtnField
                            value={value}
                            name={name}
                            field={field}
                            setValue={setValue}
                            disabled={disabled}
                        />
                    );
                }}
            />
        </div>
    );
};
