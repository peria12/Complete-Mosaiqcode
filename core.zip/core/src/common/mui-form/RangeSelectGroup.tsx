import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import TextField from "@mui/material/TextField";
import { Controller } from "react-hook-form";
import FTSelect from "common/FTSelect";

const useStyles = makeStyles(() =>
    createStyles({
        select: {
            width: "130px",
            fontSize: ".15rem",
            marginRight: "10px",
        },
        formBase: {
            width: "100%",
            padding: "12px 0px",
            display: "flex",
            justifyContent: "flex-start",
            flexDirection: "row",
            alignItems: "center",
        },
        textField: {
            width: "270px",
            marginRight: "10px",
        },
        label: {
            color: "#9b9ba3",
            width: "25%",
            fontSize: "15px",
            fontWeight: 700,
            textTransform: "uppercase",
            textAlign: "left",
        },
        inputField: {
            display: "flex",
            alignItems: "flex-start",
            flexDirection: "row",
            justifyContent: "flex-start",
            width: "75%",
            "& .MuiFormHelperText-contained": {
                margin: "0px 3px",
            },
            marginLeft: "17px",
        },
        selectRoot: {
            fontSize: ".92rem",
            padding: "10px 14px",
        },
    })
);

const findMaximumFromValues = (value, index, accessKeys, max, length) => {
    let maximumValue = max;
    for (let i = index + 1; i < length; i += 1) {
        const configObj = accessKeys[i];
        if (configObj.master) {
            continue;
        }
        const dataObj = value?.[configObj.objectKey] || {};
        const lowerLimit = null;
        const upperLimit = dataObj?.upperLimit || null;
        if (lowerLimit !== null && lowerLimit <= maximumValue) {
            maximumValue = lowerLimit - 1;
        }
        if (upperLimit !== null && upperLimit < maximumValue) {
            maximumValue = upperLimit;
        }
    }
    return maximumValue;
};

const findMinimumFromValues = (value, index, accessKeys, min) => {
    let minimumValue = min;
    for (let i = 0; i < index; i += 1) {
        const configObj = accessKeys[i];
        const dataObj = value?.[configObj.objectKey] || {};
        const lowerLimit = dataObj?.lowerLimit || null;
        const upperLimit = dataObj?.upperLimit || null;
        if (lowerLimit !== null && lowerLimit >= minimumValue) {
            minimumValue = lowerLimit + 1;
        }
        if (upperLimit !== null && upperLimit >= minimumValue) {
            minimumValue = upperLimit + 1;
        }
    }
    return minimumValue;
};

const createOptions = (min, max, type) => {
    let start;
    if (type == "lowerLimit") {
        start = 1;
    } else {
        start = min;
    }
    const options: any = [];
    for (let i = start; i <= max; i += 1) {
        options.push({ key: i, value: i.toString() });
    }
    return options;
};

const initialErrState = {
    veryConservativeRiskProfiles: false,
    conservativeRiskProfiles: false,
    conservativelyModerateRiskProfiles: false,
    moderateRiskProfiles: false,
    moderatelyAggressiveRiskProfiles: false,
    aggressiveRiskProfiles: false,
    veryAggressiveRiskProfiles: false,
};

function RangeSelectGroupInputs({ field, name, value, setValue, customErrorHandler }) {
    const { min, max, config } = field;
    const [err, setErr] = React.useState(initialErrState);
    const getOptions = (index, type, master, enableLowerLimit = false) => {
        let minimum = master ? min : findMinimumFromValues(value, index, config, min);
        let maximum = master ? max : findMaximumFromValues(value, index, config, max, config.length);
        const configObj = config[index];
        const dataObj = value?.[configObj.objectKey] || {};
        if (type === "lowerLimit" && !enableLowerLimit) {
            const upperLimit = dataObj?.upperLimit || null;
            if (upperLimit !== null && upperLimit <= maximum) {
                maximum = upperLimit - 1;
            }
        }
        if (type === "lowerLimit" && enableLowerLimit) {
            const upperLimit = dataObj?.upperLimit || null;
            if (upperLimit !== null && upperLimit <= maximum) {
                maximum = upperLimit;
            }
        }
        if (type === "upperLimit") {
            const lowerLimit = dataObj?.lowerLimit || null;
            if (lowerLimit !== null && lowerLimit >= minimum) {
                minimum = lowerLimit + 1;
            }
        }

        if (minimum !== 1) {
            minimum -= 1;
        }

        let options = createOptions(minimum, maximum, type);
        if (minimum > maximum) options = [{ key: maximum, value: maximum.toString() }];
        options = [{ key: null, value: "Empty" }, ...options];
        return options;
    };

    const handleChange = (item, updatedValue, type, isLabel = false, labelValue = "") => {
        const { objectKey } = item;
        const updatedConfig = { ...(value?.[objectKey] || {}) };
        if (isLabel) {
            updatedConfig["labelValue"] = labelValue;
            errorHandler(objectKey, labelValue);
        } else {
            updatedConfig[type] = updatedValue;
        }
        setValue(name, { ...value, [objectKey]: updatedConfig });
        // onChange({ ...value, [objectKey]: updatedConfig })
    };

    const getValue = (accessKey, type) => {
        // if (type === "lowerLimit") {
        //     return { key: 1, value: "1" };
        // }
        const val = value?.[accessKey]?.[type];
        if (val === null || val === undefined) {
            return { key: "", value: "" };
        }
        return { key: val, value: val.toString() };
    };

    const getValueForLabel = (accessKey) => {
        return accessKey === "defaultRiskProfiles" ? "Default Risk" : value?.[accessKey]?.["labelValue"] || "";
    };

    const errorHandler = (key, value) => {
        const regex = /^[a-z\d\s]+$/i; // For accepting only alphanumeric and space.
        if (value?.match(regex)) {
            setErr(initialErrState);
            customErrorHandler(false);
            return false;
        } else {
            setErr({ ...err, [key]: true });
            customErrorHandler(true);
            return true;
        }
    };

    const classes = useStyles();
    const disabled = !!field.disabled;
    return (
        <>
            {field.config?.map((field: any, index: number) => {
                return (
                    field.display && (
                        <div key={field.objectKey + index} className={classes.formBase}>
                            <div className={classes.label}> {field.label} </div>
                            <div className={classes.inputField}>
                                {field.customLabel && (
                                    <TextField
                                        size="small"
                                        sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                                        fullWidth
                                        variant={disabled ? "filled" : "outlined"}
                                        disabled={disabled || field.disabledLabel}
                                        className={classes.textField}
                                        value={getValueForLabel(field.objectKey)}
                                        placeholder="Risk name"
                                        onChange={(e) => handleChange(field, 0, "", true, e.target.value)}
                                        inputProps={{
                                            style: { padding: "10px", marginTop: "-4px" },
                                        }}
                                        error={err?.[field?.objectKey]}
                                        helperText={
                                            err[field?.objectKey] && "Only Alphanumberic and spaces are allowed."
                                        }
                                    />
                                )}
                                <div className={classes.select}>
                                    {!field.enableLowerLimit && (
                                        <TextField
                                            size="small"
                                            sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }}
                                            variant={"outlined"}
                                            inputProps={{
                                                style: { padding: "10px", marginTop: "-4px" },
                                            }}
                                            disabled={true}
                                            value={getValue(field.objectKey, "lowerLimit")?.key}
                                        />
                                    )}
                                    {field.enableLowerLimit && (
                                        <FTSelect
                                            rootClass={classes.selectRoot}
                                            disabled={disabled}
                                            variant={field?.disabled ? "filled" : "outlined"}
                                            value={getValue(field.objectKey, "lowerLimit")?.key}
                                            options={getOptions(index, "lowerLimit", field.master, true)}
                                            placeholder={"Select..."}
                                            selectDisplayProps={{ style: { marginTop: "-4px" } }}
                                            onChange={(updatedValue) => handleChange(field, updatedValue, "lowerLimit")}
                                        />
                                    )}
                                </div>
                                <div className={classes.select}>
                                    <FTSelect
                                        rootClass={classes.selectRoot}
                                        disabled={disabled}
                                        variant={field?.disabled ? "filled" : "outlined"}
                                        value={getValue(field.objectKey, "upperLimit")?.key}
                                        options={getOptions(index, "upperLimit", field.master)}
                                        placeholder={"Select..."}
                                        selectDisplayProps={{ style: { marginTop: "-4px" } }}
                                        onChange={(updatedValue) => handleChange(field, updatedValue, "upperLimit")}
                                    />
                                </div>
                            </div>
                        </div>
                    )
                );
            })}
        </>
    );
}

export const RangeSelectGroup = ({ field, methods, customErrorHandler }) => {
    const { control, setValue } = methods;
    const name = field.id || field.key;
    return (
        <div style={{ width: "100%" }}>
            <Controller
                name={name}
                control={control}
                render={({ field: { value } }) => (
                    <RangeSelectGroupInputs
                        field={field}
                        value={value}
                        name={name}
                        setValue={setValue}
                        customErrorHandler={customErrorHandler}
                    />
                )}
            />
        </div>
    );
};
