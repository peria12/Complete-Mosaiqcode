import React from "react";
import { Controller } from "react-hook-form";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import { ErrorMessage } from "./ErrorMessage";

export const FormInputText = ({ control, field, methods, defaultValue, variant, style, errors }) => {
    const label = field.title;
    const name = field.id || field.key || field.name;
    const disabled = field.disabled || false;
    const isErrors = Object.keys(errors)?.length || false;
    const hideField = field.display === false ? true : false;
    const inputType = field.type === "percent" ? "number" : "text";

    if (field.type == "number") {
        field.pattern = /^[0-9]+$/;
    }
    return (
        <>
            {!hideField && (
                <Controller
                    name={name}
                    control={control}
                    defaultValue={defaultValue}
                    rules={{
                        required: field?.required,
                        pattern: field?.pattern,
                        minLength: field?.minLength,
                        maxLength: field?.maxLength,
                        min: field?.min,
                        max: field?.max,
                    }}
                    render={({ field: { onChange, value }, fieldState: { error } }) => (
                        <>
                            <TextField
                                sx={{
                                    "& legend": { display: "none" },
                                    "& fieldset": { top: 0 },
                                }}
                                helperText={error ? error.message : null}
                                size="small"
                                type={inputType}
                                error={!!error}
                                onChange={onChange}
                                onBlur={(e: any) => methods?.setValue(name, e?.target?.value?.trim())}
                                value={value}
                                fullWidth
                                label={label}
                                variant={disabled ? "filled" : variant}
                                disabled={disabled}
                                style={style}
                                InputLabelProps={{ shrink: true }}
                                placeholder={field.placeholder}
                                inputProps={{
                                    style: { ...field?.inputPropsStyle },
                                }}
                                InputProps={{
                                    endAdornment:
                                        field.endAdornment || field.type == "percent" ? (
                                            <InputAdornment position="end" disablePointerEvents>
                                                {field.endAdornment || "%"}
                                            </InputAdornment>
                                        ) : null,
                                }}
                            />
                            {isErrors && <ErrorMessage field={field} errors={errors} />}
                        </>
                    )}
                />
            )}
        </>
    );
};
