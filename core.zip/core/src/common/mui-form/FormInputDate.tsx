import React from "react";
import TextField from "@mui/material/TextField";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";

import { Controller } from "react-hook-form";

export const FormInputDate = ({ name, control, label, defaultValue, format = "dd-MMM-yyyy" }) => {
    return (
        <div className="date-picker-alignment">
            <LocalizationProvider dateAdapter={AdapterDateFns}>
                <Controller
                    name={name}
                    control={control}
                    defaultValue={defaultValue || new Date()}
                    render={({ field: { onChange, value } }) => (
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                            <DatePicker
                                label={label}
                                value={value}
                                onChange={onChange}
                                renderInput={(params) => <TextField {...params} />}
                                inputFormat={format}
                                rifmFormatter={(val) => val.replace(/[^[a-zA-Z0-9-]*$]+/gi, "")}
                                acceptRegex={new RegExp(/[^[a-zA-Z0-9-]*$]+/gi)}
                            />
                        </LocalizationProvider>
                    )}
                />
            </LocalizationProvider>
        </div>
    );
};
