import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";

const errorStyle = {
    color: "#f44336",
    marginTop: "5px",
    marginLeft: "4px",
};
const useStyles = makeStyles(() =>
    createStyles({
        error: errorStyle,
    })
);

export const CustomErrorMessage = ({ text }) => {
    return <div style={errorStyle}>{text}</div>;
};

export const ErrorMessage = ({ field, errors }) => {
    const name = field.id || field.key || field.name;

    let error = errors;
    name.split(".").forEach((val) => {
        if (error) {
            error = error[val];
        }
    });
    const errorInfo = error || {};
    const classes = useStyles();

    switch (errorInfo.type) {
        case "required":
            return <div className={classes.error}>This field is required</div>;
        case "min":
            return <div className={classes.error}>Should be above {field.min} </div>;
        case "max":
            return <div className={classes.error}>Should be below {field.max}</div>;
        case "pattern":
            return <div className={classes.error}>This field is not valid</div>;
        case "minLength":
            return <div className={classes.error}>Must be at least {field.minLength} characters</div>;
        case "maxLength":
            return <div className={classes.error}>Only {field.maxLength} characters allowed</div>;
        default:
            return <></>;
    }
};
