import React from "react";
import Api from "utils/api";
import { downloadFile, downloadFileData } from "utils/helpers";

export function FileDownload({ file_id, children }) {
    const onClick = () => {
        Api.getFileRaw(file_id).then(downloadFile);
    };

    return (
        <div
            style={{
                display: "inline-flex",
                alignItems: "center",
                textDecoration: "auto",
                cursor: "pointer",
                paddingRight: "15px",
            }}
            onClick={onClick}
        >
            {children}
        </div>
    );
}

export function FileDownloadUrl({ url, children, filename }) {
    const onClick = () => {
        Api.getDataForDownload(url).then((resp) => downloadFileData(resp, filename));
    };

    return (
        <div
            style={{
                display: "inline-flex",
                alignItems: "center",
                textDecoration: "auto",
                cursor: "pointer",
                paddingRight: "15px",
            }}
            onClick={onClick}
        >
            {children}
        </div>
    );
}
