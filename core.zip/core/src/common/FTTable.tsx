import React, { useState } from "react";
import {
    Table,
    TableContainer,
    Paper,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    TablePagination,
    TableSortLabel,
} from "@mui/material";

import { Link } from "react-router-dom";
import InputField from "common/InputField";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import TablePaginationActions from "./TablePaginationActions";
import { stableSort, getComparator } from "utils/helpers";

const useStyles = makeStyles(() =>
    createStyles({
        visuallyHidden: {
            border: 0,
            clip: "rect(0 0 0 0)",
            height: 1,
            margin: -1,
            overflow: "hidden",
            padding: 0,
            position: "absolute",
            top: 20,
            width: 1,
        },
    })
);

function FTTableHeader({ column, style, isMultiHeaders = false, sortConfig, setSortConfig }) {
    if (isMultiHeaders) {
        style = { ...style, borderRight: "1px solid rgb(218 218 211)" };
    }
    const classes = useStyles();

    function sortHandler(orderBy) {
        const isAsc = orderBy === orderBy && sortConfig?.order === "asc";
        setSortConfig({ ...sortConfig, order: isAsc ? "desc" : "asc", orderBy: orderBy });
    }
    return (
        <TableCell
            className="fw-bold sticky-row-ddd"
            size="small"
            colSpan={column?.colSpan}
            style={
                ["numeric", "percentage"].includes(column.type)
                    ? {
                          ...style,
                          textAlign: column?.colSpan ? "center" : "right",
                          width: column.width
                      }
                    : { ...style, textAlign: column?.colSpan ? "center" : "left", width: column.width }
            }
        >
            {column.sortable ? (
                <TableSortLabel
                    active={sortConfig?.orderBy === column.id}
                    direction={sortConfig?.orderBy === column.id ? sortConfig?.order : "asc"}
                    onClick={() => sortHandler(column.id)}
                >
                    {column.label}
                    {sortConfig?.orderBy === column.id ? (
                        <span className={classes.visuallyHidden}>
                            {sortConfig?.order === "desc" ? "sorted descending" : "sorted ascending"}
                        </span>
                    ) : null}
                </TableSortLabel>
            ) : (
                (typeof column.label == 'function') ? column.label() : column.label
            )}
        </TableCell>
    );
}

export default function FTTable(params) {
    const { rows, columns, rowStyle, meta = {}, inputField = {}, paginate, headerStyle = null } = params;

    const [pageConfig, setPageConfig] = useState<any>({ page: 0, rowsPerPage: 20 });
    const [sortConfig, setSortConfig] = useState<any>({ order: "asc", orderBy: "" });
    const rowsPerPageOptions = [20, 50, 100];

    const handleChangePage = (event, page) => {
        setPageConfig({ ...pageConfig, page });
    };
    const handleChangeRowsPerPage = (event) => {
        setPageConfig({ page: 0, rowsPerPage: parseInt(event.target?.value, 10) });
    };

    const getPage = (data) => {
        if (!paginate) {
            return data;
        }
        const start = pageConfig.page * pageConfig.rowsPerPage;
        return data.slice(start, start + pageConfig.rowsPerPage);
    };

    const getValue = (value, column) => {
        if (value === "NaN" || value === undefined || value === null) {
            return "";
        }
        if (column?.type === "percentage") {
            value = (parseFloat(value) * 100)?.toFixed(2);
            if (value) {
                return value + "%";
            }
        }
        if (column?.type === "numeric") {
            return value?.toFixed(column?.toFixed || 2);
        }
        return value;
    };
    let style: any = { paddingRight: "24px" };
    if (meta?.outlinedColumns) {
        style = { ...style, outline: "1px solid rgb(218 218 211)" };
    }
    if (headerStyle) {
        style = { ...style, ...headerStyle };
    }
    let rowCols: any = columns;
    const isMultiHeaders = Array.isArray(columns?.[0]);
    if (isMultiHeaders) {
        rowCols = columns[columns?.length - 1];
    }
    return (
        <TableContainer component={Paper}>
            <Table>
                <TableHead style={{ backgroundColor: meta?.headerBgColor || "#fafafa" }}>
                    <>
                        {isMultiHeaders ? (
                            columns.map((cols, i) => (
                                <TableRow key={i}>
                                    {cols.map((col, j) => {
                                        return (
                                            <FTTableHeader
                                                key={i + j}
                                                style={style}
                                                column={col}
                                                isMultiHeaders={isMultiHeaders}
                                                sortConfig={sortConfig}
                                                setSortConfig={setSortConfig}
                                            />
                                        );
                                    })}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                {columns.map((column, i) => {
                                    return (
                                        <FTTableHeader
                                            key={i}
                                            style={style}
                                            column={column}
                                            sortConfig={sortConfig}
                                            setSortConfig={setSortConfig}
                                        />
                                    );
                                })}
                            </TableRow>
                        )}
                    </>
                </TableHead>
                <TableBody className="custom-tbody very-dense-table">
                    {getPage(stableSort(rows, getComparator(sortConfig?.order, sortConfig?.orderBy))).map((row, i) => (
                        <tr
                            key={i}
                            className="custom-tr-border"
                            style={
                                rowStyle
                                    ? rowStyle(row)
                                    : {
                                          background: meta.striped ? (i % 2 ? "white" : "#fafafa") : undefined,
                                      }
                            }
                        >
                            {rowCols.map((column, j) => {
                                let style = {};
                                const colStyleMap = row?.colStyleMap?.[column?.key] || {};
                                if (meta?.outlinedColumns) {
                                    style = { outline: "1px solid rgb(218 218 211)" };
                                }
                                if (row?.colSpan && !(column?.key in row)) {
                                    return;
                                }
                                if (Object.keys(colStyleMap).length > 0 && row?.skipOverideColumn != true) {
                                    column = { ...column, ...colStyleMap };
                                }
                                return (
                                    <td
                                        key={j}
                                        colSpan={colStyleMap?.colSpan || column.colSpan}
                                        style={{
                                            ...style,
                                            width: column.width,
                                            height: 30,
                                            textAlign: ["numeric", "percentage"].includes(column.type)
                                                ? "right"
                                                : undefined,
                                            paddingLeft: row["addPadding"] ? "25px" : undefined,
                                            ...row?.colStyle,
                                            ...colStyleMap,
                                        }}
                                    >
                                        {column.func ? (
                                            column.func(row)
                                        ) : column.link ? (
                                            <Link to={row[column.link]}>{row[column.key]}</Link>
                                        ) : inputField?.fields?.[column.key] ? (
                                            <InputField
                                                field={{
                                                    id: column.key,
                                                    ...inputField?.fields?.[column.key],
                                                }}
                                                index={i}
                                                value={row[column.key]}
                                                onChange={inputField?.onChange}
                                            />
                                        ) : (
                                            <>
                                                {row?.valueFormatting == false
                                                    ? row[column.key]
                                                    : getValue(row[column.key], column)}
                                            </>
                                        )}
                                    </td>
                                );
                            })}
                        </tr>
                    ))}
                </TableBody>
            </Table>
            {paginate ? (
                <TablePagination
                    component="div"
                    count={rows.length}
                    page={pageConfig.page}
                    colSpan={3}
                    onPageChange={handleChangePage}
                    rowsPerPage={pageConfig.rowsPerPage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    rowsPerPageOptions={rowsPerPageOptions}
                    ActionsComponent={TablePaginationActions}
                />
            ) : (
                ""
            )}
        </TableContainer>
    );
}
