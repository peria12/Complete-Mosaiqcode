import React, { useState, useEffect } from "react";
import makeStyles from "@mui/styles/makeStyles";
import { PowerBIEmbed } from "powerbi-client-react";
import { models } from "powerbi-client";
import PowerBIAuth from "utils/power-bi-auth";

const useStyles = makeStyles({
    container: {
        display: "flex",
        justifyContent: "center",
    },
});

export default function PowerBI({ config }) {
    const classes = useStyles();
    const [reportInfo, setReportInfo] = useState<any>(null);
    const [load, setLoad] = useState(true);

    useEffect(() => {
        setLoad(true);
    }, [config]);

    useEffect(() => {
        if (load && config?.workspace_id && config?.report_id) {
            const { workspace_id, report_id } = config;
            PowerBIAuth?.getReportInfo(workspace_id, report_id)
                ?.then((res) => {
                    if (res) {
                        setReportInfo(res);
                        setLoad(false);
                    }
                })
                .catch((err) => {
                    console.log("Error", err);
                });
        }
    }, [load, config]);

    if (reportInfo) {
        return (
            <div className={classes.container}>
                <PowerBIEmbed
                    embedConfig={{
                        type: "report",
                        id: reportInfo?.id,
                        embedUrl: reportInfo?.embedUrl,
                        accessToken: reportInfo?.accessToken,
                        tokenType: models.TokenType.Embed, // Aad
                        settings: {
                            panes: {
                                filters: {
                                    expanded: true,
                                    visible: true,
                                },
                            },
                            background: models.BackgroundType.Transparent,
                        },
                    }}
                    eventHandlers={
                        new Map([
                            // ['loaded', function () { console.log('Report loaded'); }],
                            // ['rendered', function () { console.log('Report rendered'); }],
                            [
                                "error",
                                function (event: any) {
                                    if (event?.detail?.message == "TokenExpired") {
                                        setLoad(true);
                                    }
                                },
                            ],
                        ])
                    }
                    cssClassName={"report-power-bi"}
                    getEmbeddedComponent={(embeddedReport: any) => {
                        (window as any).report = embeddedReport; //as Report;
                    }}
                />
            </div>
        );
    } else
        return (
            <>
                <p>Failed to load report</p>
            </>
        );
}
