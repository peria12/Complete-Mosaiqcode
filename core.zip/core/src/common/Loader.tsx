import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import createStyles from "@mui/styles/createStyles";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";

const useStyles = makeStyles(() =>
    createStyles({
        root: {
            width: "100%",
            height: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
        },
        loaderContainer: {
            height: "100%",
        },
    })
);

export default function CircularIndeterminate() {
    const classes = useStyles();
    return (
        <Box margin={"2px"}>
            <div className={classes.root}>
                <CircularProgress />
            </div>
        </Box>
    );
}
