import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Grid, ListItem, ListItemText } from "@mui/material";
import Typography from "@mui/material/Typography";

const useStyles = makeStyles(() =>
    createStyles({
        details: {
            display: "flex",
            flexDirection: "column",
        },
        primaryFont: {
            fontSize: ".90rem",
            color: "rgba(0, 0, 0, 0.54)",
        },
        secondaryFont: {
            fontSize: ".80rem",
            color: "rgba(0, 0, 0, 0.87)",
            fontWeight: 500,
        },
        header: {
            marginTop: "10px",
        },
    })
);

export default function TableDetailsView({ fields, row, titleProp }) {
    const classes = useStyles();
    return (
        <div className={classes.details}>
            <Grid direction="row" justifyContent="flex-start" container item xs={12} sm={12} md={12} lg={12} xl={12}>
                <Typography className={classes.header} align="left" component="h6" variant="subtitle1">
                    {row[titleProp]}
                </Typography>
            </Grid>
            <Grid container item xs={12} sm={12} md={12} lg={12} xl={12}>
                {fields.map((field: any) => {
                    if (field.show_on_detailed_info_view && row[field._id] && field._id !== titleProp) {
                        return (
                            <Grid key={field._id} container item xs={12} sm={12} md={12} lg={5} xl={5}>
                                <ListItem>
                                    <ListItemText
                                        primary={field.title}
                                        secondary={row[field._id]}
                                        primaryTypographyProps={{ className: classes.primaryFont }}
                                        secondaryTypographyProps={{ className: classes.secondaryFont }}
                                    />
                                </ListItem>
                            </Grid>
                        );
                    }
                })}
            </Grid>
        </div>
    );
}
