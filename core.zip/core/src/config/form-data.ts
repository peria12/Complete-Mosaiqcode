const textOperators = [
    { label: "=", value: "=" },
    { label: "!=", value: "!=" },
];

const numericOperators = [
    { label: "=", value: "=" },
    { label: "!=", value: "!=" },
    { label: "<", value: "<" },
    { label: ">", value: ">" },
    { label: "<=", value: "<=" },
    { label: ">=", value: ">=" },
];

const defaultTextOperators = [...textOperators, { label: "IN", value: "IN" }, { label: "NOT IN", value: "NOT IN" }];
const defaultNumericOperators = [
    ...numericOperators,
    { label: "IN", value: "IN" },
    { label: "NOT IN", value: "NOT IN" },
];

export { textOperators, numericOperators, defaultNumericOperators, defaultTextOperators };
