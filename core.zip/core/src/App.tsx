import React, { useEffect, useState } from "react";
import { Switch, Route, useHistory, useLocation } from "react-router-dom";

import "bootstrap";

import Api from "utils/api";
import Home from "home/Home";

import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey(
    "CompanyName=Fiduciary Trust International Ltd,LicensedGroup=FTCI,LicenseType=MultipleApplications,LicensedConcurrentDeveloperCount=10,LicensedProductionInstancesCount=5,AssetReference=AG-031336,SupportServicesEnd=7_September_2023_[v2]_MTY5NDA0MTIwMDAwMA==3041125cedab58c320bd77d546377a5b"
);

import "./App.css";
import ErrorBoundary from "common/ErrorBoundary";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { Download } from "home/download/Download";

import "ag-grid-community/styles/ag-grid.css";
// import "ag-grid-community/dist/styles/ag-theme-balham.css";
import "./ag-theme-balham.css";
import "./ag-theme-ft.css";

import GoeCapabilities from "./home/goe/goe-capabilites/GoeCapabilities";
import GoePreFetch from "./home/goe/goe-capabilites/GoePreFetch";
import moment from "moment";

export default function App() {
    const [url, setUrl] = useState("");
    const [lodingInfo, setLoadingInfo] = useState({ skipLoading: false, loading: false, loggedIn: false });
    const history = useHistory();
    const location = useLocation();
    const isGoeCapabilitiesAppUrl = Api.isGoeCapabilitiesAppUrl;

    const parseJwt = (token) => {
        const base64Url = token.split(".")[1];
        const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        const jsonPayload = decodeURIComponent(
            window
                .atob(base64)
                .split("")
                .map(function (c) {
                    return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
                })
                .join("")
        );

        return JSON.parse(jsonPayload);
    };

    const adLogin = (isInternal) => {
        Api.start(url)
            .then(({ loggedIn, url, redirectToHome, accessToken }) => {
                if (accessToken) {
                    const tokenDetails = parseJwt(accessToken);
                    localStorage.setItem("userId", tokenDetails.oid);
                }
                if (isInternal) {
                    setLoadingInfo({ ...lodingInfo, loggedIn: loggedIn });
                    if (redirectToHome) {
                        setUrl(window.location.pathname);
                        history.push("/");
                    } else if (url) {
                        setUrl("");
                        history.push(url);
                    }
                } else {
                    setLoadingInfo({ ...lodingInfo, loggedIn: loggedIn, loading: false });
                }
            })
            .catch(() => {
                if (!isInternal) {
                    setLoadingInfo({ ...lodingInfo, loading: false });
                }
            });
    };

    useEffect(() => {
        if (!isGoeCapabilitiesAppUrl) {
            adLogin(true);
        } else {
            setLoadingInfo({ ...lodingInfo, loading: true });
            // Check if user is accessing the https://goe.frk.com on a vpn
            Api.getVpnStatus()
                .then(() => {
                    adLogin(false);
                })
                .catch(() => {
                    const accessToken = sessionStorage.getItem("gcd-access-token");
                    const accessTokenExpiration = sessionStorage.getItem("gcd-access-token-expiration");
                    const now = moment().format("YYYY-MM-DD HH:mm:ss");

                    if (accessToken && moment(now).isBefore(moment(accessTokenExpiration, "YYYY-MM-DD HH:mm:ss"))) {
                        const username = localStorage.getItem("userId");
                        Api.ExternLoginSetToken(accessToken, username);
                        setLoadingInfo({ skipLoading: false, loading: false, loggedIn: true });
                    } else {
                        setLoadingInfo({ skipLoading: true, loading: false, loggedIn: false });
                    }
                });
        }
        // eslint-disable-next-line
    }, [history, url, location.pathname, isGoeCapabilitiesAppUrl]);

    if (!lodingInfo.loggedIn && !lodingInfo.skipLoading) {
        return (
            <div>
                <div>Loading...</div>
            </div>
        );
    }

    return (
        <Switch>
            <Route path="/download/:id">
                <Download />
            </Route>
            <Route path="/">
                <ErrorBoundary>
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                        {isGoeCapabilitiesAppUrl ? (
                            <GoeCapabilities
                                loading={lodingInfo.loading}
                                isAuthenticated={lodingInfo.loggedIn}
                                lodingInfo={lodingInfo}
                                setIsAuthenticated={setLoadingInfo}
                            />
                        ) : (
                            <Home />
                        )}

                        {/* Loading Images for Goe capabilities ahead so that there is no lag when app loads */}
                        <GoePreFetch />
                    </LocalizationProvider>
                </ErrorBoundary>
            </Route>
        </Switch>
    );
}
