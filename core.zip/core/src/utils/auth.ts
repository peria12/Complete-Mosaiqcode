import { BrowserAuthError, PublicClientApplication } from "@azure/msal-browser";
import { InteractionRequiredAuthError } from "@azure/msal-browser";

const BUILD_ENV = process.env?.REACT_APP_BUILD_ENV || "dev";

const environment = {
    dev: {
        clientId: "f2dbb4fe-80e5-4c9c-b11d-3325bfe61fe3",
        scopes: ["api://f2dbb4fe-80e5-4c9c-b11d-3325bfe61fe3/Read"],
    },
    test: {
        clientId: "f2dbb4fe-80e5-4c9c-b11d-3325bfe61fe3",
        scopes: ["api://f2dbb4fe-80e5-4c9c-b11d-3325bfe61fe3/Read"],
    },
    uat: {
        clientId: "f2dbb4fe-80e5-4c9c-b11d-3325bfe61fe3",
        scopes: ["api://f2dbb4fe-80e5-4c9c-b11d-3325bfe61fe3/Read"],
    },
    prod: {
        clientId: "1157a9c9-1bd6-40c0-a357-9613f01e5702",
        scopes: ["api://1157a9c9-1bd6-40c0-a357-9613f01e5702/Read"],
    },
};

const msalConfig = {
    auth: {
        clientId: environment[BUILD_ENV].clientId,
        authority: "https://login.microsoftonline.com/franklintempleton.onmicrosoft.com",
        navigateToLoginRequestUrl: false,
        // These two settings below can speed up login, but we will need to keep it up-to-date
        // As per https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/performance.md
        //cloudDiscoveryMetadata: '{"tenant_discovery_endpoint":"https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration","api-version":"1.1","metadata":[{"preferred_network":"login.microsoftonline.com","preferred_cache":"login.windows.net","aliases":["login.microsoftonline.com","login.windows.net","login.microsoft.com","sts.windows.net"]},{"preferred_network":"login.partner.microsoftonline.cn","preferred_cache":"login.partner.microsoftonline.cn","aliases":["login.partner.microsoftonline.cn","login.chinacloudapi.cn"]},{"preferred_network":"login.microsoftonline.de","preferred_cache":"login.microsoftonline.de","aliases":["login.microsoftonline.de"]},{"preferred_network":"login.microsoftonline.us","preferred_cache":"login.microsoftonline.us","aliases":["login.microsoftonline.us","login.usgovcloudapi.net"]},{"preferred_network":"login-us.microsoftonline.com","preferred_cache":"login-us.microsoftonline.com","aliases":["login-us.microsoftonline.com"]}]}',
        //authorityMetadata: '{"token_endpoint":"https://login.microsoftonline.com/b9b831a9-6c10-40bf-86f3-489ed83c81e8/oauth2/v2.0/token","token_endpoint_auth_methods_supported":["client_secret_post","private_key_jwt","client_secret_basic"],"jwks_uri":"https://login.microsoftonline.com/b9b831a9-6c10-40bf-86f3-489ed83c81e8/discovery/v2.0/keys","response_modes_supported":["query","fragment","form_post"],"subject_types_supported":["pairwise"],"id_token_signing_alg_values_supported":["RS256"],"response_types_supported":["code","id_token","code id_token","id_token token"],"scopes_supported":["openid","profile","email","offline_access"],"issuer":"https://login.microsoftonline.com/b9b831a9-6c10-40bf-86f3-489ed83c81e8/v2.0","request_uri_parameter_supported":false,"userinfo_endpoint":"https://graph.microsoft.com/oidc/userinfo","authorization_endpoint":"https://login.microsoftonline.com/b9b831a9-6c10-40bf-86f3-489ed83c81e8/oauth2/v2.0/authorize","device_authorization_endpoint":"https://login.microsoftonline.com/b9b831a9-6c10-40bf-86f3-489ed83c81e8/oauth2/v2.0/devicecode","http_logout_supported":true,"frontchannel_logout_supported":true,"end_session_endpoint":"https://login.microsoftonline.com/b9b831a9-6c10-40bf-86f3-489ed83c81e8/oauth2/v2.0/logout","claims_supported":["sub","iss","cloud_instance_name","cloud_instance_host_name","cloud_graph_host_name","msgraph_host","aud","exp","iat","auth_time","acr","nonce","preferred_username","name","tid","ver","at_hash","c_hash","email"],"tenant_region_scope":"NA","cloud_instance_name":"microsoftonline.com","cloud_graph_host_name":"graph.windows.net","msgraph_host":"graph.microsoft.com","rbac_url":"https://pas.windows.net"}',
    },
    cache: {
        cacheLocation: "sessionStorage",
        storeAuthStateInCookie: false,
    },
};

const scopes = environment[BUILD_ENV].scopes;
const graph_scopes = ["User.Read", "User.ReadBasic.All", "Group.Read.All"];
console.log(`Starting ${BUILD_ENV}`);

let pca: PublicClientApplication;

// if there are more than 1 account, we use last used account. need to test this case.
function pickAnAccount(accounts) {
    if (accounts.length === 1) {
        return accounts[0];
    } else if (accounts.length > 1) {
        const lastUsername = localStorage.getItem("lastUser");
        if (lastUsername) {
            return accounts.find((account) => account.username === lastUsername);
        }
    }
}

async function getGraphToken(account) {
    const tokenResponse = await pca.acquireTokenSilent({ scopes: graph_scopes, account });
    return tokenResponse.accessToken;
}

export async function login(url) {
    pca = new PublicClientApplication(msalConfig);
    const redirectResponse = await pca.handleRedirectPromise();
    const account = pickAnAccount(pca.getAllAccounts());

    if (redirectResponse) {
        localStorage.setItem("lastUser", redirectResponse.account?.username || "");
        return {
            token: redirectResponse.idToken,
            accessToken: redirectResponse.accessToken,
            url: redirectResponse.state,
            user: redirectResponse.account,
            expiresOn: redirectResponse.expiresOn,
            graphAccessToken: await getGraphToken(account),
        };
    }

    if (account) {
        try {
            const tokenResponse = await pca.acquireTokenSilent({ scopes, account });
            localStorage.setItem("lastUser", tokenResponse.account?.username || "");
            return {
                token: tokenResponse.idToken,
                accessToken: tokenResponse.accessToken,
                user: tokenResponse.account,
                expiresOn: tokenResponse.expiresOn,
                graphAccessToken: await getGraphToken(account),
            };
        } catch (error) {
            if (error instanceof InteractionRequiredAuthError || error instanceof BrowserAuthError) {
                pca.loginRedirect({ scopes, redirectUri: window.location.origin, state: window.location.pathname });
            } else {
                console.log("loginRedirect error", error);
            }
        }
    } else {
        if (window.location.pathname != "/") {
            return { token: undefined, redirectToHome: true };
        }
        pca.loginRedirect({ scopes, redirectUri: window.location.origin, state: url });
    }

    return { token: undefined };
}

export function logout() {
    if (pca) {
        return pca.logout();
    }
}
