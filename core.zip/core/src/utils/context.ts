import React from "react";
export const AppContext = React.createContext<any>({});
export const RBAContext = React.createContext<any>({});
export const RBAModelReturnRiskContext = React.createContext<any>({});
export const ManagerAnalysisContext = React.createContext<any>({});
