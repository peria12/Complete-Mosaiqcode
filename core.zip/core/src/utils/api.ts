import { login, logout } from "./auth";
import { getUuid } from "./helpers";
import axios from "axios";
import errorNotification from "utils/api-error";
import { graphData } from "./data";
import Settings from "./settings";

export default class Api {
    private static idToken;
    private static accessToken;
    private static graphAccessToken; // access token for microsoft graph API
    private static user;
    private static cache = {};
    private static BASE_PATH = process.env?.REACT_APP_BASE_PATH;

    private static LOCAL_HOST = "http://nycnbk148713.noam.corp.frk.com";

    public static isGoeCapabilitiesAppUrl =
        window.location.origin === "https://goe.frk.com" ||
        window.location.origin === "https://goedev.frk.com" ||
        window.location.origin === "https://goetest.frk.com" ||
        window.location.origin === "https://goeuat.frk.com";

    private static getApiUrl(url) {
        if (url.startsWith(this.LOCAL_HOST)) {
            return url;
        }
        if (this.BASE_PATH) {
            return this.BASE_PATH + url;
        }
        return url;
    }

    public static async start(redirectUrl) {
        if (this.isLoggedIn()) {
            return {
                loggedIn: true,
                url: null,
                redirectToHome: null,
                accessToken: null,
            };
        }

        return this.getToken(redirectUrl);
    }

    private static async getToken(redirectUrl) {
        const { token, accessToken, url, redirectToHome, user, expiresOn, graphAccessToken } = await login(redirectUrl);
        this.idToken = token;
        this.accessToken = accessToken;
        this.graphAccessToken = graphAccessToken;
        this.user = user;
        if (expiresOn) {
            // automatically refresh the token 1 minute before it expires
            const timeDiff = expiresOn.getTime() - new Date().getTime() - 60000;
            setTimeout(() => this.getToken("/"), timeDiff);
        }

        return {
            loggedIn: this.isLoggedIn(),
            url,
            redirectToHome,
            idToken: this.idToken,
            accessToken: accessToken,
        };
    }

    public static getAccessToken() {
        return this.accessToken;
    }

    public static async stop() {
        await logout();
        this.idToken = undefined;
    }

    public static isLoggedIn() {
        return this.idToken != undefined;
    }

    public static apiFailed(error, customErrorMsg?: string) {
        const statusCode = error?.response?.status || 500;
        const errMessage = customErrorMsg || error?.response?.data?.message;
        const errorInfo = {
            type: "error",
            text: "Something went wrong.",
            open: true,
        };
        switch (statusCode) {
            case 400:
                errorInfo.text = `${statusCode} :` + (error?.response?.data?.message || "Bad request");
                break;
            case 422:
                errorInfo.text = `${statusCode} :` + (error?.response?.data?.message || "Bad request");
                break;
            case 401:
                errorInfo.text = `${statusCode}: Unauthorized`;
                break;
            case 403:
                errorInfo.text = error?.response?.data?.message || `${statusCode}: Forbidden`;
                break;
            case 404:
                errorInfo.text = errMessage || `${statusCode}: Not found`;
                break;
            case 500:
                errorInfo.text = errMessage || `${statusCode}: Internal server error`;
                break;
            case 502:
                errorInfo.text = `${statusCode}: Bad gateway`;
                break;
            case 503:
                errorInfo.text = `${statusCode}: Service unavailable`;
                break;
        }
        localStorage.setItem("errorMsg", error);
        errorNotification.next(errorInfo);
        const message = `${error?.config?.method?.toUpperCase()}:${error?.config?.url}, Response: ${errorInfo.text}`;
        const payload = {
            error: message,
        };

        Api.logToLoggerService(payload);
        throw error;
    }

    public static getUIUser() {
        return this.user;
    }

    private static makeHeaders(headers) {
        const targetUser = Settings.getSettings()?.app_settings?.admin?.portal?.targetUser;
        const ret = {
            authorization: `Bearer ${this.accessToken}`,
            "request-id": getUuid(),
            ...headers,
        };

        if (targetUser) ret["target-email"] = targetUser;

        return ret;
    }

    private static get(url, headers: any = {}, params: any = {}, responseType: any = "json", catchError = true) {
        const call = axios
            .get(this.getApiUrl(url), {
                responseType,
                headers: this.makeHeaders(headers),
                params,
            })
            .then((resp) => resp.data);

        if (catchError) return call.catch(this.apiFailed);
        return call;
    }

    public static getModalReportData() {
        return this.get(`/api/model-portfolios`);
    }

    public static getModalPortfolioAuditData() {
        return this.get(`/api/audit_records`);
    }

    public static getGoalConsole() {
        return this.get(`/api/goe_capabilities/list/clients`);
    }

    public static filterGoalConsole(body) {
        return this.post(`/api/goe_capabilities/list/clients/filtered`, body);
    }

    public static updateAndCloneGoals(body) {
        return this.put(`/api/goe_capabilities/goal`, body);
    }

    public static getDALFields() {
        return this.get(`/api/dal/fields`);
    }

    public static deleteDALField(fieldInfo) {
        return this.put(`/api/dal/delete-factor`, fieldInfo);
    }

    public static getPortfolioAnalysisReturnRiskDataTMP() {
        return Promise.resolve(graphData.return_based_analytics);
    }

    public static getModalGenerator(body: any) {
        return this.post(`/api/generate_report`, body, {}, {}, false).catch(this.apiFailed);
    }

    private static put(url, body, headers: any = {}, params: any = {}, catchError = true) {
        const call = axios
            .put(this.getApiUrl(url), body, {
                headers: this.makeHeaders(headers),
                params,
            })
            .then((resp) => resp.data);

        if (catchError) return call.catch(this.apiFailed);
        return call;
    }

    // catchError = if TRUE, handle the error and show popup
    //               if FALSE, pass error to caller
    private static post(url, body, headers: any = {}, params: any = {}, catchError = true, extractDataFromResp = true) {
        const call = axios
            .post(this.getApiUrl(url), body, {
                headers: this.makeHeaders(headers),
                params,
            })
            .then((resp) => (extractDataFromResp ? resp.data : resp));
        if (catchError) return call.catch(this.apiFailed);
        return call;
    }

    private static delete(url, headers: any = {}, params: any = {}) {
        return axios
            .delete(this.getApiUrl(url), {
                headers: this.makeHeaders(headers),
                params,
            })
            .then((resp) => resp.data)
            .catch(this.apiFailed);
    }

    private static cachedGet(url, header = {}, params = {}, responseType = "json", catchError = true) {
        const key = `${url}:${JSON.stringify(params)}`;
        if (!this.cache[key]) {
            this.cache[key] = this.get(url, header, params, responseType, catchError);
        }
        return this.cache[key];
    }

    public static getFields() {
        return this.cachedGet("/api/research-gateway/fields").then((resp) => resp.fields);
    }

    public static getEntries(params) {
        return this.get("/api/research-gateway/entries", null, params).then((resp) => resp.entries);
    }

    public static getEntry(id) {
        return this.get(`/api/research-gateway/entries/${id}`);
    }

    private static makeEntryForm(entry) {
        const data = new FormData();
        entry.attachments?.filter((item) => item instanceof File).forEach((file) => data.append("attachments", file));
        entry.attachments = entry.attachments?.filter((item) => !(item instanceof File));
        data.append("json", JSON.stringify(entry));
        return data;
    }

    public static updateEntry(id, entry) {
        return this.put(`/api/research-gateway/entries/${id}`, this.makeEntryForm(entry));
    }

    public static requestAccess() {
        return this.post(`/api/goe_capabilities/send_access_request`, {});
    }

    public static createEntry(entry) {
        return this.post(`/api/research-gateway/entries`, this.makeEntryForm(entry));
    }

    private static makeFileForm(body, name) {
        const data = new FormData();
        [...body.file].filter((item) => item instanceof File).forEach((file) => data.append(name, file));
        data.append("json", JSON.stringify(body));
        return data;
    }

    public static createGoeActuarial(actuarial) {
        const data = this.makeFileForm(actuarial, "filePath");
        return this.post(`/api/goe/actuarial/create`, data);
    }

    public static uploadFile(path, payload) {
        const data = this.makeFileForm(payload, "filePath");
        return this.post(`${path}`, data);
    }

    public static customApiUrl(body) {
        return body.method === "POST"
            ? this.post(`${body.apiUrl}`, body.body, body.header, {}, false)
            : this.get(`${body.apiUrl}`, body.body, body.header, {}, false);
    }

    public static goeApiEndPoint() {
        return this.get(`/api/goe/api_end_point_list`, {}, {});
    }

    public static getGoalTypes() {
        return this.get(`/api/goe_capabilities/v1/goals`, {}, {});
    }

    public static saveUserDetails(userDetails) {
        return this.post("/api/goe_capabilities/basic-info", userDetails);
    }

    public static getUserDetails(app_id, zone_id) {
        return this.get(`/api/goe_capabilities/v1/user_info/${app_id}/zone/${zone_id}`);
    }

    public static saveGoals(goalDetails) {
        const clientId = localStorage.getItem("clientId");
        const goalData = {
            goal_data: goalDetails,
            client_id: clientId,
        };

        return this.post(`/api/goe_capabilities/v1/user_goals`, goalData);
    }

    public static getVpnStatus() {
        return this.get(`/api/healthcheck`, {}, {});
    }

    public static async signInWithOkta(params) {
        return await this.post("/signIn", params);
    }

    public static async signUpUser(params) {
        return await this.post("/api/goe_capabilities/send_registration_request", params);
    }

    public static ExternLoginSetToken = (token, username) => {
        localStorage.setItem("userId", username);
        this.user = { name: "", localAccountId: "", username: "" };
        this.accessToken = token;
        this.user.localAccountId = username;
    };

    public static runPipe(request, header) {
        return this.post(`/api/goe_capabilities/v1/runPipe`, request, header);
    }

    public static wealthSplitter(iwsRuquest, header) {
        return this.post(`/api/goe_capabilities/v1/runWealthSplitter`, iwsRuquest, header);
    }

    public static UPA(request, header) {
        return this.post(`/api/goe_capabilities/v4/unifiedPortfolioAdvice`, request, header);
    }

    public static getRetirementData(request, header) {
        return this.post(`/api/goe_capabilities/v1/replacementincomecalculator`, request, header);
    }

    public static getSocialSecurityData(request, header) {
        return this.post(`/api/goe_capabilities/v1/socialSecurityCalculator`, request, header);
    }

    public static getAllGoals() {
        const clientId = localStorage.getItem("clientId");
        return this.get(`/api/goe_capabilities/v1/user_goals/${clientId}`);
    }

    public static onSearch(keyword) {
        return this.get(`/api/goe_capabilities/search/clients/${keyword}`);
    }

    public static deleteGoal(goalId) {
        const clientId = localStorage.getItem("clientId");
        return this.delete(`/api/goe_capabilities/v1/user_goals/${clientId}/${goalId}`);
    }

    public static updateGoal(goalDetails, goalId) {
        const clientId = localStorage.getItem("clientId");
        const goalData = {
            goal_id: goalId,
            client_id: clientId,
            goal_data: goalDetails,
        };
        return this.put(`/api/goe_capabilities/v1/user_goals`, goalData);
    }

    public static getPortfolioComposition(id = "") {
        if (id) return this.get(`/api/goe_capabilities/v1/portfolio_composition/${id}`);
        return this.get(`/api/goe_capabilities/v1/portfolio_composition`);
    }

    public static updateGoeActuarial(id, actuarial) {
        const data = this.makeFileForm(actuarial, "filePath");
        return this.put(`/api/goe/actuarial/update/${id}`, data);
    }

    public static getGoeActuarialFileById(id) {
        return this.get(`/api/goe/actuarial/getFileById/${id}`);
    }

    public static deleteEntry(id) {
        return this.delete(`/api/research-gateway/entries/${id}`);
    }

    public static getApps() {
        return this.get(`/api/admin/apps`).then((resp) => resp?.apps);
    }

    public static getSystemInfo() {
        return this.cachedGet(`/api/admin/system-info`);
    }

    public static searchUsers(text: string) {
        const headers = {
            Authorization: `Bearer ${this.graphAccessToken}`,
            ConsistencyLevel: "eventual",
        };
        const query = text
            .split(" ")
            .filter((x) => x)
            .map((x) => `"displayName:${x}"`)
            .join(" AND ");
        return axios
            .get(
                `https://graph.microsoft.com/v1.0/users?$search=${query}&$orderby=displayName&$select=displayName,givenName,id,mail&$count=true`,
                {
                    headers,
                }
            )
            .then((resp) => resp.data)
            .catch(this.apiFailed);
    }

    public static searchGroups(text: string) {
        const headers = {
            Authorization: `Bearer ${this.graphAccessToken}`,
            ConsistencyLevel: "eventual",
        };
        const query = text
            .split(" ")
            .filter((x) => x)
            .map((x) => `"displayName:${x}"`)
            .join(" AND ");
        return axios
            .get(
                `https://graph.microsoft.com/v1.0/groups?$search=${query}&$orderby=displayName&$select=id,displayName,description,mail,mailEnabled,securityEnabled&$count=true`,
                {
                    headers,
                }
            )
            .then((resp) => resp.data)
            .catch(this.apiFailed);
    }

    public static searchUsersOkta(text) {
        return this.get("/api/okta/search_users", null, { text, limit: 20 });
    }

    public static searchDepartments(search) {
        return this.get("/api/admin/departments", null, { search, limit: 20 });
    }

    public static searchUserOrgs(search) {
        return this.get("/api/admin/user_orgs", null, { search, limit: 20 });
    }

    // This will send a link to user to change password
    public static resetPassword(username) {
        return this.post("/api/okta/reset_password", { username }, null, null, false);
    }

    public static searchAllUsers(ids: any[]) {
        const headers = {
            Authorization: `Bearer ${this.graphAccessToken}`,
            ConsistencyLevel: "eventual",
        };
        const body = { ids, types: ["user"] };
        return axios
            .post(`https://graph.microsoft.com/v1.0/directoryObjects/getByIds`, body, {
                headers: headers,
            })
            .then((resp) => resp.data)
            .catch(this.apiFailed);
    }

    public static getMyPhoto(errorHandler: any) {
        const headers = {
            Authorization: `Bearer ${this.graphAccessToken}`,
            ConsistencyLevel: "eventual",
        };

        return axios
            .get(`https://graph.microsoft.com/v1.0/users/${this.user.localAccountId}/photos/48x48/$value`, {
                headers,
                responseType: "arraybuffer",
            })
            .then((resp) => resp.data)
            .catch(errorHandler);
    }

    public static forgotPassword(params) {
        return this.post("/forgotpassword", params);
    }

    public static getEntityMasterFields() {
        return this.cachedGet("/api/entity-master/fields").then((resp) => resp.fields);
    }

    public static getEntities(params: any) {
        return this.get("/api/entity-master/entities", {}, params);
    }

    public static getEntitesForSecurityHoldings(params: any) {
        return this.post("/api/es_holdings", params);
    }

    public static entitySearch(params) {
        return this.post("/api/entity-master/esquery", params);
    }

    public static entitySearchRBA(params) {
        return this.post("/api/entity-master/return-based", params);
    }

    public static getAllUserAccess() {
        return this.get(`/api/admin/all-access`);
    }

    public static getAccess() {
        return this.get("/api/admin/access");
    }

    public static setAccess(updates, group_updates, user_info, group_info) {
        return this.post("/api/admin/update-access", {
            updates,
            group_updates,
            user_info,
            group_info,
        });
    }

    public static addOrUpdateConflictEntities(params: any) {
        return this.post("/api/entity-master/conflict-entities-resolve", params);
    }

    public static getConflictEntities() {
        return this.get("/api/entity-master/conflict-entities", {});
    }

    public static logToLoggerService(payload: any) {
        return this.post("/api/admin/log", payload, {}, {}, false).catch(console.log);
    }

    public static getCollections() {
        return this.get("/api/admin/collections_new", {});
    }

    public static deleteCollection(name: string) {
        return this.delete(`/api/admin/collections/${name}`, {});
    }

    public static getDocument(name: string, _id: string, version = "") {
        return this.get(`/api/admin/collections/${name}/documents/${_id}?version=${version}`);
    }

    public static fetchDocument(name: string, _id: string) {
        return this.get(`/api/admin/collections/${name}/documents/${_id}`);
    }

    public static insertDocument(name: string, body: any, comment) {
        return this.post(`/api/admin/collections/${name}/documents`, body, {}, { comment });
    }

    public static updateDocument(name: string, _id: string, body: any, params: any) {
        return this.put(`/api/admin/collections/${name}/documents/${_id}`, body, {}, params);
    }

    public static deleteDocument(name: string, _id: string, comment) {
        return this.delete(`/api/admin/collections/${name}/documents/${_id}`, {}, { comment });
    }

    public static getDocumentDiff(name, doc, first, second) {
        return this.get(`/api/admin/collections/${name}/documents/${doc}/diff`, {}, { first, second });
    }

    public static getDocumentHistory(name, doc) {
        return this.get(`/api/admin/collections/${name}/documents/${doc}/history`, {});
    }

    public static getFileRaw(id: string) {
        return axios
            .get(this.getApiUrl(`/api/file-id/${id}`), {
                responseType: "arraybuffer",
                headers: this.makeHeaders({}),
            })
            .catch(this.apiFailed);
    }

    /* USE THIS FUNCTION ONLY IF YOU DONT KNOW THE URL */
    public static getDataForDownload(url) {
        return this.get(url);
    }

    public static getFile(id: string) {
        return this.cachedGet(`/api/file-id/${id}`, {}, {}, "arraybuffer", true);
    }

    public static getPortfolios(params: any) {
        return this.cachedGet("/api/portfolios", {}, params);
    }

    public static getHoldings(entity_id: string, params: any) {
        return this.get(`/api/portfolios/${entity_id}/holdings`, {}, params);
    }

    public static getUserSettings() {
        return this.get(`/api/admin/user-settings`, {}, {}, {});
    }

    public static getZoneSettings(app, zone, useCached = true) {
        if (useCached) {
            return this.cachedGet(`/api/admin/apps/${app}/zone-settings/${zone}`);
        } else {
            return this.get(`/api/admin/apps/${app}/zone-settings/${zone}`);
        }
    }

    public static updateUserSettings(app, zone, path, user_id, settings) {
        return this.put(`/api/admin/apps/${app}/zone/${zone}/user-settings/${user_id}`, settings, {}, { path });
    }

    public static getAlerts(params: any) {
        return this.get("/api/alerts/events", {}, params);
    }

    public static getAlertsCount() {
        return this.get("/api/alerts/recent_events_count", {}, {}, null, false);
    }

    public static updateAlert(id: any, alert: any) {
        return this.put(`/api/alerts/defs/${id}`, alert);
    }

    public static clearAlert(event_id, alert) {
        return this.post(`/api/alerts/events/clear/${event_id}`, alert);
    }

    public static getAlertDefs() {
        return this.get(`/api/alerts/defs`).then((resp) => resp?.defs);
    }

    public static createAlertDef(alertDef) {
        return this.post(`/api/alerts/defs`, alertDef);
    }

    public static getAlertDef(alertDefId) {
        return this.get(`/api/alerts/defs/${alertDefId}`);
    }

    public static updateAlertDef(alertDefId, alertDef) {
        return this.put(`/api/alerts/defs/${alertDefId}`, alertDef);
    }

    public static deleteAlertDef(alertDefId) {
        return this.delete(`/api/alerts/defs/${alertDefId}`);
    }

    public static subscribeToAlert(alertDefId, alertMode, userId) {
        return this.post(
            `/api/alerts/defs/${alertDefId}/mode/${alertMode}/subscribe/${userId}`,
            {},
            {},
            {},
            true
            // false
        );
    }

    public static unSubscribeToAlert(alertDefId, alertMode, userId) {
        return this.post(
            `/api/alerts/defs/${alertDefId}/mode/${alertMode}/unsubscribe/${userId}`,
            {},
            {},
            {},
            true
            // false
        );
    }

    public static getAlertSubscriptions(userId) {
        return this.get(`/api/alerts/subscriptions/${userId}`).then((resp) => resp.defs);
    }

    public static getAlertSubscribers(alertDefId) {
        return this.get(`/api/alerts/users/${alertDefId}`);
    }

    public static updatePortfolioSettings(id: any, settings: any) {
        return this.post(`/api/portfolios/settings/${id}`, settings);
    }

    public static getPowerBIEmbedInfo(workspaceId: string, reportId: string) {
        return this.get(`/api/powerbi/embedinfo/workspace/${workspaceId}/report/${reportId}`).catch((error) => {
            this.apiFailed(error, "Failed to load report");
        });
    }

    public static getOptRuns(portfolio_id: string, params: any) {
        return this.get(`/api/portfolios/optimization-runs/${portfolio_id}`, {}, params);
    }

    public static getOptResults(optRunId: string) {
        return this.get(`/api/portfolios/optimization-reports/${optRunId}`);
    }

    public static getPortfoliosDal(dates) {
        const req = {
            dates: dates.sort(),
            fields: ["portfolio_list"],
            // fields: [{ portfolio_list: { list_only: true } }],
        };

        return this.dal(req, true, true, true);
    }

    public static getSecurityHoldingsDal(dates, entity_ids) {
        const req = {
            fields: ["security_holdings"],
            dates: dates,
            entities: entity_ids,
        };
        return this.dal(req, true, false, true);
    }

    public static getHoldingsDal(dates, entity_ids) {
        const req = {
            fields: ["portfolio_holdings"],
            dates: dates,
            entities: entity_ids,
        };
        return this.dal(req, true, false, true);
    }

    public static dal(req: any, to_records = true, cached = false, error = false) {
        const params = { req: JSON.stringify(req) };
        const url = "/api/dal/get-data";
        const request = cached ? this.cachedGet(url, {}, params) : this.get(url, {}, params);
        return request.then((resp) => {
            console.log("DAL OUTPUT", resp);
            if (!to_records) {
                return resp;
            }

            const pairs = Object.keys(resp.fields).map((key) => {
                const value = resp.fields[key];
                const columns = value.columns;
                const records = value.values.map((v) => Object.fromEntries(columns.map((c, i) => [c, v[i]])));
                return [key, records];
            });

            if (error) {
                const records = Object.fromEntries(pairs);
                return { ...records, error: resp?.error };
            }
            return Object.fromEntries(pairs);
        });
    }

    public static getSAAReports(body: any) {
        return this.post(`/api/saa`, this.makeEntryForm(body), {}, {}, false).catch(console.log);
    }

    public static saveLayout(layout) {
        return this.put("/api/layout", layout);
    }

    public static getModalReports(body: any) {
        return this.post(`/api/model-portfolios/convert`, body, {}, {}, true).catch(console.log);
    }

    public static getDAAReports() {
        return this.get(`/api/daa`);
    }

    public static runSAAReports(type, id, body: any) {
        return this.post(`/api/saa/${id}/${type}`, body, {}, {}, false).catch(console.log);
    }

    public static getGoeLatestDraft() {
        return this.get("/api/goe/getLatestDraft");
    }

    public static goeSaveDraft(body) {
        return this.post("/api/goe/createDraft", body);
    }

    public static getGoePortfolioEnums() {
        return this.get("/api/goe/portfolioBundle/getEnums");
    }

    public static getHistoricalActuarialFiles(id) {
        return this.get(`/api/goe/actuarial/getAllActuarialFiles/${id}`);
    }

    public static getGoeClients(body) {
        return this.post("/api/goe/getUsers", body);
    }

    public static getGoePortfolioBundles(body) {
        return this.post("/api/goe/portfolioBundle/getAll", body);
    }

    public static getBloombergHoldingInfo(payload) {
        return this.get(`http://nycnbk148713.noam.corp.frk.com:9090/bbgdata?payload=${payload}`, {}, {}, null, false);
    }

    public static createGoePortfolioBundle(body) {
        return this.post("/api/goe/portfolioBundle/create", body);
    }

    public static getGoePortfolioBundlesInfo(body) {
        return this.post("/api/goe/portfolioBundle/getOne", body).then((resp) => resp.data);
    }

    public static getGoeActuarials(body) {
        return this.post("/api/goe/actuarial/getAll", body);
    }
    public static getPortfolioLoad(body: any) {
        return this.post(`/api/goe/portfolio_upload_admin`, this.makeEntryForm(body), {}, {}, false, false);
    }

    public static getActuarialNames(body) {
        return this.post("/api/goe/actuarial/getNamesWithCustomFilter", body);
    }

    public static getGoeFilterPortfolios(body) {
        return this.post("/api/goe/portfolioBundle/getNamesWithFilter", body);
    }

    public static goeCreateClient(body) {
        return this.post("/api/goe/createUser", body);
    }

    public static goeUpdateClient(body) {
        return this.put("/api/goe/updateUser", body);
    }

    public static goeDownloadConfig(id) {
        return this.get(`/api/goe/config/${id}`);
    }

    public static getEntityInfo(id) {
        return this.get(`/api/entity-master/entities/${id}`);
    }
    public static goeDownloadConfigRaw(id) {
        return axios
            .get(this.getApiUrl(`/api/goe/config/${id}`), {
                responseType: "arraybuffer",
                headers: this.makeHeaders({}),
            })
            .catch(this.apiFailed);
    }

    public static createAnnouncements(body) {
        const data = this.makeFileForm(body, "filePath");
        return this.post(`/api/alerts/announcements`, data);
    }

    public static runAusRetCalculator(body) {
        return this.post("/api/goe/australiademo", body);
    }

    public static takeScreenshot(app, zone, html) {
        return this.post(`/api/screenshot`, html, undefined, { app, zone }, false); // need api
    }

    public static genrateAusRetIncome(body) {
        return this.post("/api/goe/australia_retirement_income", body);
    }

    public static getPortfolioViewer(params) {
        return this.get(`/api/portfolio_view/portfolio_summary`, {}, params);
    }

    public static getISRCPolicyPortfolioInfo(params) {
        return this.get(`/api/isrc-portfolio`, {}, params).then((resp) => resp.data);
    }

    public static getLatestAvailableDate(params) {
        return this.get(`/api/isrc-portfolio/latest-available-date`, {}, params, null, false).then((resp) => resp.data);
    }

    public static getRebalanceIds(body) {
        return this.post("/api/check_rebalance", body);
    }
    public static getDepartmentUsers() {
        return this.get("/api/dept/users"); //https://api.uipdev.corp.frk.com
    }
    public static getGoalData(goal_id) {
        return this.get(`/api/goe_capabilities/v1/goalinput/${goal_id}`);
    }
    public static calculateGoalAmount(body) {
        return this.post("/api/goe_capabilities/v1/goalamount", body);
    }
    public static getAccounts() {
        return this.get("/api/optimizer/accounts");
    }
    public static getStatus(date) {
        return this.get("/api/optimizer/status/" + date);
    }
    public static refreshStatus(body) {
        return this.post("/api/optimizer/run/syseq_pcon", body);
    }
    public static generateReports(request) {
        return this.post("/api/optimizer/generate_reports", request);
    }
    public static getModelList() {
        return this.get("/api/modelportfolio/modelportfoliolist");
    }
    public static getAssetList() {
        return this.get("/api/modelportfolio/assetlist");
    }
    public static getModelPortfolioById(id) {
        return this.get("/api/modelportfolio/id/" + id);
    }
    public static getSharedState(app, zone) {
        return this.get("/api/sharedobject", {}, { app, zone }); //https://api.uipdev.corp.frk.com
    }
    public static getSharedStateById(id) {
        return this.get("/api/sharedobject/id/" + id);
    }
    public static createSharedState(app, zone, request) {
        return this.post("/api/sharedobject", request, undefined, { app, zone });
    }
    public static updateSharedState(id, request, catchError = true) {
        return this.put(`/api/sharedobject/id/${id}`, request, {}, {}, catchError);
    }
    public static deleteSharedState(id) {
        return this.delete(`/api/sharedobject/id/${id}`);
    }
    public static searchForModel(query) {
        return this.post("/api/opensearch", query);
    }
    public static createModelPortfolio(request) {
        return this.post("/api/modelportfolio", request);
    }
    public static editModelPortfolio(oid, payload) {
        return this.put("/api/modelportfolio/id/" + oid, payload);
    }
    public static deleteModelPortfolio(id) {
        return this.delete("/api/modelportfolio/id/" + id);
    }

    public static getSAAClassifications() {
        return this.get("/api/saa/classifications");
    }

    public static evaluateConstraints(params) {
        return this.get("/api/saa/evaluate_constraints", {}, params);
    }
    public static saaInvokeapo(request) {
        return this.post("/api/saa/invokeapo", request);
    }

    public static calculateAnalysis(request) {
        return this.post("/api/saa/calculate_analytics", request);
    }
    public static getAuditHistory(id) {
        return this.get(`/api/sharedobject/id/${id}/audithistory`);
    }

    public static exportPDF(params) {
        return this.post(`/api/export/pdf`, params, undefined, {}, false);
    }

    public static saveProposalData(request, header) {
        return this.post(`/api/goe_capabilities/save_proposal`, request, header);
    }
    public static advisorConsoleConfig(request, header) {
        return this.post(`/api/goe_capabilities/v1/runPipe`, request, header);
    }

    public static toggleFavoriteClient(request, header) {
        return this.put(`/api/goe_capabilities/client`, request, header);
    }
}
