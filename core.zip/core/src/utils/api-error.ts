import { Subject } from "rxjs";

const errorNotification = new Subject<any>();
export default errorNotification;
