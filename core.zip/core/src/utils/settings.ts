import { Subject } from "rxjs";
import Access from "./access";
import Api from "./api";

export default class Settings {
    static settings: any = {};
    static subject = new Subject<any>();

    static init() {
        return Api.getUserSettings().catch((err) => console.error("failed to load user settings", err));
    }

    static setSettings(data, uuid) {
        this.settings = data[uuid] || {};
        console.log("SETTING settings to ", this.settings);
    }

    static getSettings() {
        return this.settings;
    }

    static getAppSettings() {
        return this.settings["app_settings"];
    }

    static async updateSettings(app_id, zone_id, path, cfg, save = true) {
        let s = this.settings;
        const paths = ["app_settings", app_id, zone_id, ...path.split(".")];

        const last = paths.pop();
        paths.forEach((x) => {
            if (x in s) {
                s = s[x];
            } else {
                s[x] = {};
                s = s[x];
            }
        });

        s[last] = cfg;

        this.subject.next({ ...this.getAppSettings() });

        if (save) {
            const response = await Api.updateUserSettings(
                app_id,
                zone_id,
                path,
                Access.userInfo.uuid,
                this.settings["app_settings"][app_id][zone_id]
            ).catch((err) => console.error("failed to update settings", err));
            return response;
        }
    }

    static subscribe(func) {
        const sub = this.subject.subscribe(func);
        return () => sub.unsubscribe();
    }
}
