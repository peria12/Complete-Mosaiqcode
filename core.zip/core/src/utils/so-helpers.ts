import Access from "./access";

export function hasAccess(info) {
    const userInfo = Access.userInfo || {};
    return info?.["author-id"] == userInfo?.["uuid"];
}

function sortByDate(a, b) {
    const key1 = new Date(a._meta?.update_date);
    const key2 = new Date(b._meta?.update_date);

    if (key1 < key2) {
        return 1;
    } else if (key1 == key2) {
        return 0;
    } else {
        return -1;
    }
}

export function sortList(options) {
    let res: any = [];
    if (!options) {
        return res;
    }
    const userOwns: any = [];
    const userNotOwns: any = [];
    options.forEach((option) => {
        if (hasAccess(option)) {
            userOwns.push(option);
        } else {
            userNotOwns.push(option);
        }
    });
    res = [...userOwns.sort(sortByDate), ...userNotOwns.sort(sortByDate)];
    return res;
}

export const searchStyles = {
    height: "30px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    padding: "2px 4px",
    fontSize: 13,
    borderColor: "rgb(217 207 207)",
};

export const squareBtnStyle = {
    border: " 1px solid rgb(217 207 207)",
    borderRadius: 3,
    padding: "3px",
    width: "30px",
    marginLeft: 3,
};

export const authorStyle: any = {
    color: "#c5c5c5",
    textTransform: "capitalize",
    fontStyle: "italic",
    marginLeft: 1,
};
