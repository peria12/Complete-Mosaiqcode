import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import * as bootstrap from "bootstrap";

import { openAutoCloseModal } from "utils/modal";
import { InputField } from "common/FormField";
import { entryNotification } from "utils/events";
import Api from "utils/api";

export default function Entry({ match }) {
    const history = useHistory();
    const [fields, setFields] = useState(null as any);
    const [entry, setEntry] = useState(null as any);
    const [modal, setModal] = useState(null as any);

    useEffect(() => {
        if (!fields) {
            Api.getFields().then(setFields);
        }
        if (!entry) {
            if (match.params.id != "new") {
                Api.getEntry(match.params.id).then(setEntry);
            } else {
                setEntry({ status: "active" });
            }
        }

        const element = document.getElementById("entryModal");
        const myModal = new bootstrap.Modal(element);
        setModal(myModal);
        return openAutoCloseModal(myModal, history);
    }, [entry, fields, history, match.params.id]);

    const onChange = (value, key) => {
        entry[key] = value;
        console.log(entry);
    };

    const saveChanges = () => {
        if (match.params.id != "new") {
            Api.updateEntry(match.params.id, entry).then(() => {
                entryNotification.next(match.params.id);
                modal?.hide();
            });
        } else {
            Api.createEntry(entry).then((resp) => {
                entryNotification.next(resp?.id);
                modal?.hide();
            });
        }
    };

    const renderFields = () =>
        fields
            .sort((a, b) => a.display_order - b.display_order)
            .map((field: any) => (
                <div className="row" key={field._id}>
                    <div className="col-sm-16">
                        <InputField
                            field={field}
                            value={entry[field._id]}
                            onChange={(value) => onChange(value, field._id)}
                        />
                    </div>
                </div>
            ));

    return (
        <div className="modal" id="entryModal" tabIndex={-1} aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title">
                            {match.params?.id == "new" ? "New Recommendation" : entry?.name}
                        </h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">{entry && fields ? renderFields() : ""}</div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                            Close
                        </button>
                        <button type="button" className="btn btn-primary" onClick={saveChanges}>
                            {match.params?.id == "new" ? "Create" : "Save"}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
