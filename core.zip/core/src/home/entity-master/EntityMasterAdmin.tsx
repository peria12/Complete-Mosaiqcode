import React, { useState, useEffect } from "react";
import { Theme } from "@mui/material/styles";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import TextField from "@mui/material/TextField";

import Api from "utils/api";
import { stableSort, getComparator, useScreenshot } from "utils/helpers";
import TablePaginationActions from "common/TablePaginationActions";
import TableToolbar from "./TableToolbar";
import EditableRow from "./EditableRow";
import { errorHandler } from "utils/error-handler";
import { globalSearch } from "utils/helpers";
import FTSnackBar from "common/FTSnackBar";
import AppCover from "home/dashboad/AppCover";

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        iconBtn: {
            padding: theme.spacing(0.6),
        },
        paper: {
            width: "100%",
            marginBottom: theme.spacing(2),
        },
        table: {
            tableLayout: "fixed",
        },
        tableHead: {
            fontWeight: "bold",
        },
        visuallyHidden: {
            border: 0,
            clip: "rect(0 0 0 0)",
            height: 1,
            margin: -1,
            overflow: "hidden",
            padding: 0,
            position: "absolute",
            top: 20,
            width: 1,
        },
        selectedRow: {
            backgroundColor: "rgb(234, 236, 247) !important",
        },
        formControl: {
            width: "100%",
        },
        inputBase: {
            fontSize: ".77rem",
            cursor: "text",
        },
    })
);

const colWidths = { entity_name: "300px", entity_type: "200px" };
const defaultWidth = "150px";
const checkboxWidth = "50px";

function EnhancedTableHead({ onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, fields }) {
    const classes = useStyles();
    const createSortHandler = (property: keyof any) => (event: React.MouseEvent<unknown>) => {
        onRequestSort(event, property);
    };
    return (
        <TableHead>
            <TableRow>
                <TableCell padding="checkbox" style={{ width: checkboxWidth }}>
                    <Checkbox
                        color="primary"
                        indeterminate={numSelected > 0 && numSelected < rowCount}
                        checked={rowCount > 0 && numSelected === rowCount}
                        onChange={onSelectAllClick}
                        inputProps={{ "aria-label": "select all entities" }}
                    />
                </TableCell>
                {fields.map((field: any) => (
                    // <TableCell
                    //     key={field._id}
                    //     align="left"
                    //     padding="default"
                    //     sortDirection={orderBy === field._id ? order : false}
                    //     className={classes.tableHead}
                    //     style={{ width: colWidths[field._id] || defaultWidth }}
                    // >
                    //     <TableSortLabel
                    //         active={orderBy === field._id}
                    //         direction={orderBy === field._id ? order : "asc"}
                    //         onClick={createSortHandler(field._id)}
                    //     >
                    //         {field.title}
                    //         {orderBy === field._id ? (
                    //             <span className={classes.visuallyHidden}>
                    //                 {order === "desc" ? "sorted descending" : "sorted ascending"}
                    //             </span>
                    //         ) : null}
                    //     </TableSortLabel>
                    // </TableCell>
                    <TableCell
                        key={field.id}
                        align="left"
                        padding="normal"
                        sortDirection={orderBy === field.id ? order : false}
                        className={classes.tableHead}
                        style={{ width: colWidths[field.id] || defaultWidth }}
                    >
                        <TableSortLabel
                            active={orderBy === field.id}
                            direction={orderBy === field.id ? order : "asc"}
                            onClick={createSortHandler(field.id)}
                        >
                            {field.title}
                            {orderBy === field.id ? (
                                <span className={classes.visuallyHidden}>
                                    {order === "desc" ? "sorted descending" : "sorted ascending"}
                                </span>
                            ) : null}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

const defaultEntityInfo = {
    fields: [],
    sortedFields: [],
    rows: [],
    originalRows: [],
};

const defaultRecords = {
    selected: [],
    mergedRows: [],
    updatedRow: {},
    isNewRowEnabled: false,
};

export default function EntityMasterAdmin() {
    const classes = useStyles();
    const [entityMasterInfo, setEntityMasterInfo] = useState({ ...defaultEntityInfo, isLoading: true });
    const [sortConfig, setSortConfig] = useState<any>({ order: "asc", orderBy: "" });
    const [recordsInfo, setRecordsInfo] = useState<any>(defaultRecords);
    const [searchText, setSearchText] = useState("");
    const [pageConfig, setPageConfig] = useState<any>({ page: 0, rowsPerPage: 25 });
    const [message, setMessage] = useState({ type: "", text: "", open: false, duration: 3000 });
    const screenshot = useScreenshot();

    useEffect(() => {
        Promise.all([Api.getEntityMasterFields(), Api.getConflictEntities()])
            .then(([fields, res]) => {
                const ordered_fields = fields.sort((a: any, b: any) => a.view_order - b.view_order);
                const entities = res?.entities || [];
                setEntityMasterInfo({
                    fields: ordered_fields,
                    sortedFields: ordered_fields.map((f) => f.id),
                    rows: entities,
                    originalRows: entities,
                    isLoading: false,
                });

                screenshot.take();
            })
            .catch((e) => {
                errorHandler(e);
                setEntityMasterInfo({ ...defaultEntityInfo, isLoading: false });
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (searchText) {
            const result = globalSearch(entityMasterInfo?.originalRows, searchText);
            setEntityMasterInfo({ ...entityMasterInfo, rows: result });
        } else {
            setEntityMasterInfo({ ...entityMasterInfo, rows: entityMasterInfo?.originalRows });
        }
        setPageConfig({ ...pageConfig, page: 0 });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchText, entityMasterInfo?.originalRows]);

    const handleRequestSort = (event: React.MouseEvent<unknown>, property: any) => {
        const isAsc = sortConfig?.order === "asc";
        setSortConfig({ order: isAsc ? "desc" : "asc", orderBy: property });
    };

    const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.checked) {
            const newSelected = entityMasterInfo?.rows.map((n: any) => n.em_conflict_id);
            setRecordsInfo({ ...recordsInfo, selected: newSelected });
            return;
        }
        setRecordsInfo({ ...recordsInfo, selected: [] });
    };

    const addOrUpdate = (payload) => {
        setMessage({ type: "info", text: "Saving...", open: true, duration: 3000 });
        Api.addOrUpdateConflictEntities(payload)
            .then((response) => {
                setMessage({ type: "success", text: "Saved.", open: true, duration: 3000 });
                if (response?.entities) {
                    setEntityMasterInfo({
                        ...entityMasterInfo,
                        rows: response?.entities,
                        originalRows: response?.entities,
                    });
                    setRecordsInfo(defaultRecords);
                } else {
                    console.log("Unexpected response");
                    setMessage({ type: "error", text: "Error during saving.", open: true, duration: 3000 });
                }
            })
            .catch((err) => {
                setMessage({ type: "error", text: "Error during saving.", open: true, duration: 3000 });
                errorHandler(err);
            });
    };

    const handleUpdate = () => {
        if (recordsInfo?.selected.length > 0) {
            const _selectedRows = entityMasterInfo?.rows.filter((r: any) =>
                recordsInfo?.selected.includes(r.em_conflict_id)
            );
            addOrUpdate({
                em_conflict_ids: recordsInfo?.selected,
                conflictEntities: _selectedRows,
            });
        }
    };

    const handleSave = () => {
        let merged = recordsInfo?.mergedRows.map((r: any) => parseFloat(r.em_conflict_id));
        if (!merged.length) {
            merged = recordsInfo?.updatedRow.em_conflict_id ? [recordsInfo?.updatedRow.em_conflict_id] : [];
        }
        addOrUpdate({
            em_conflict_ids: merged,
            conflictEntities: [recordsInfo?.updatedRow],
        });
    };

    const getDefaultValue = (_mergedRows: any) => {
        const initialValue = { ..._mergedRows[0] };
        if (_mergedRows.length > 1) {
            entityMasterInfo?.sortedFields.forEach((key: string) => {
                if (!initialValue[key]) {
                    const entry = _mergedRows.find((r: any) => r[key]);
                    if (entry) {
                        initialValue[key] = entry[key];
                    }
                }
            });
        }
        return initialValue;
    };

    const handleClick = (event: any, id: string) => {
        const selectedIndex = recordsInfo?.selected.indexOf(id);
        let newSelected: string[] = [];

        if (selectedIndex === -1) {
            newSelected = newSelected.concat(recordsInfo?.selected, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(recordsInfo?.selected.slice(1));
        } else if (selectedIndex === recordsInfo?.selected.length - 1) {
            newSelected = newSelected.concat(recordsInfo?.selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                recordsInfo?.selected.slice(0, selectedIndex),
                recordsInfo?.selected.slice(selectedIndex + 1)
            );
        }
        if (recordsInfo?.mergedRows.length) {
            const _mergedRows = entityMasterInfo?.rows.filter((r: any) => newSelected.includes(r.em_conflict_id));
            setRecordsInfo({
                ...recordsInfo,
                selected: newSelected,
                mergedRows: _mergedRows,
                updatedRow: getDefaultValue(_mergedRows),
            });
        } else {
            setRecordsInfo({ ...recordsInfo, selected: newSelected });
        }
    };

    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
        setPageConfig({ page: 0, rowsPerPage: parseInt(event.target?.value, 10) });
    };

    const isSelected = (id: string) => recordsInfo?.selected.indexOf(id) !== -1;

    const handleMerge = () => {
        const mergedRows = entityMasterInfo?.rows.filter((r: any) => recordsInfo?.selected.includes(r.em_conflict_id));
        if (mergedRows.length) {
            setRecordsInfo({
                ...recordsInfo,
                isNewRowEnabled: true,
                mergedRows: mergedRows,
                updatedRow: getDefaultValue(mergedRows),
            });
        } else {
            setRecordsInfo({ ...recordsInfo, isNewRowEnabled: true, mergedRows: mergedRows });
        }
    };

    const handleTextChange = (event: any, index: number) => {
        const { name, value } = event.target;
        const list: any = [...(entityMasterInfo?.rows || [])];
        list[index][name] = value;
        setEntityMasterInfo({
            ...entityMasterInfo,
            rows: list,
            originalRows: list,
        });
    };

    function getStripedStyle(index: number): any {
        return { background: index % 2 ? "#fafafa" : "white" };
    }

    return (
        <AppCover
            header={
                <TableToolbar
                    numSelected={recordsInfo?.selected.length}
                    handleMerge={handleMerge}
                    handleSave={handleSave}
                    mergedRows={recordsInfo?.mergedRows}
                    handleAddEntity={() => setRecordsInfo({ ...recordsInfo, isNewRowEnabled: true })}
                    isNewRowEnabled={recordsInfo?.isNewRowEnabled}
                    setSearchText={setSearchText}
                    handleClear={() => setRecordsInfo(defaultRecords)}
                    handleUpdate={handleUpdate}
                />
            }
            loading={entityMasterInfo?.isLoading}
        >
            <Paper className={classes.paper}>
                <TableContainer style={{ height: "calc(100vh - 135px)", overflowY: "auto" }}>
                    <Table
                        stickyHeader
                        className={classes.table}
                        aria-labelledby="tableTitle"
                        aria-label="enhanced table"
                    >
                        <EnhancedTableHead
                            numSelected={recordsInfo?.selected.length}
                            order={sortConfig?.order}
                            orderBy={sortConfig?.orderBy}
                            onSelectAllClick={handleSelectAllClick}
                            onRequestSort={handleRequestSort}
                            rowCount={entityMasterInfo?.rows.length}
                            fields={entityMasterInfo?.fields}
                        />
                        <TableBody className="custom-tbody dense-table">
                            {recordsInfo?.isNewRowEnabled && (
                                <EditableRow
                                    fields={entityMasterInfo?.fields}
                                    recordsInfo={recordsInfo}
                                    setRecordsInfo={setRecordsInfo}
                                />
                            )}
                            {stableSort(entityMasterInfo?.rows, getComparator(sortConfig?.order, sortConfig?.orderBy))
                                .slice(
                                    pageConfig?.page * pageConfig?.rowsPerPage,
                                    pageConfig?.page * pageConfig?.rowsPerPage + pageConfig?.rowsPerPage
                                )
                                .map((row: any, index: number) => {
                                    const isItemSelected = isSelected(row.em_conflict_id);
                                    const isRowMerged = recordsInfo?.mergedRows.find(
                                        (r: any) => r.em_conflict_id == row["em_conflict_id"]
                                    );
                                    const labelId = `em-admin-table-checkbox-${index}`;
                                    return (
                                        <tr
                                            onClick={(event) => handleClick(event, row.em_conflict_id)}
                                            role="checkbox"
                                            aria-checked={isItemSelected}
                                            tabIndex={-1}
                                            key={row.em_conflict_id}
                                            className={
                                                "custom-tr-border" + " " + (isItemSelected ? classes.selectedRow : "")
                                            }
                                            style={{ ...getStripedStyle(index) }}
                                        >
                                            <td style={{ width: checkboxWidth, padding: "0 0 0 4px" }}>
                                                <Checkbox
                                                    checked={isItemSelected}
                                                    inputProps={{ "aria-labelledby": labelId }}
                                                    color="primary"
                                                />
                                            </td>
                                            {entityMasterInfo?.sortedFields.map((field: any) => (
                                                <td
                                                    key={field}
                                                    align="left"
                                                    style={{ width: colWidths[field.id] || defaultWidth }}
                                                >
                                                    {field == "em_conflict_id" || !isItemSelected || isRowMerged ? (
                                                        row[field]
                                                    ) : (
                                                        <TextField
                                                            size="small"
                                                            id={field + index}
                                                            name={field}
                                                            InputProps={{ className: classes.inputBase }}
                                                            value={row[field] || ""}
                                                            onClick={(e) => e.stopPropagation()}
                                                            onChange={(event) => handleTextChange(event, index)}
                                                        />
                                                    )}
                                                </td>
                                            ))}
                                        </tr>
                                    );
                                })}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    component="div"
                    count={entityMasterInfo?.rows.length}
                    page={pageConfig?.page}
                    colSpan={3}
                    onPageChange={(event: any, newPage: number) => setPageConfig({ ...pageConfig, page: newPage })}
                    rowsPerPage={pageConfig?.rowsPerPage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    rowsPerPageOptions={[10, 25, 50]}
                    ActionsComponent={TablePaginationActions}
                />
            </Paper>
            <FTSnackBar snack={message} />
        </AppCover>
    );
}
