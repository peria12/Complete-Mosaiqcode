import React from "react";
import Autocomplete from "@mui/material/Autocomplete";
import TableRow from "@mui/material/TableRow";
import TextField from "@mui/material/TextField";
import TableCell from "@mui/material/TableCell";

const EditableSelectField = ({ id, name, options, recordsInfo, setRecordsInfo }) => {
    const { updatedRow } = recordsInfo;

    const setUpdatedRow = (newUpdatedRow: any) => {
        setRecordsInfo({ ...recordsInfo, updatedRow: newUpdatedRow });
    };

    const handleTextChange = (event: any) => {
        const { name, value } = event.target;
        setUpdatedRow({ ...updatedRow, [name]: value });
    };

    const handleSelectedOption = (name, value) => {
        if (value) {
            setUpdatedRow({ ...updatedRow, [name]: value });
        }
    };
    const inputValue = updatedRow?.[id] || "";

    if (!options.length) {
        return (
            <TextField
                id={id}
                key={id}
                label={name}
                name={id}
                value={inputValue + ""}
                onChange={(event) => handleTextChange(event)}
                InputLabelProps={{
                    style: {
                        fontSize: ".89rem",
                    },
                }}
            />
        );
    }

    return (
        <Autocomplete
            id={id}
            key={id}
            size="small"
            style={{ width: "100%" }}
            disableClearable
            options={options}
            onChange={(e, value) => handleSelectedOption(id, value)}
            filterOptions={(options) => options}
            inputValue={inputValue + ""}
            renderInput={(params) => (
                <TextField
                    {...params}
                    id={id}
                    key={id}
                    label={name}
                    name={id}
                    value={inputValue + ""}
                    onChange={(event) => handleTextChange(event)}
                    InputLabelProps={{
                        style: {
                            fontSize: ".89rem",
                        },
                    }}
                />
            )}
        />
    );
};

export default function EditableRow({ fields, recordsInfo, setRecordsInfo }) {
    const getOptions = (field) => {
        const options = recordsInfo?.mergedRows.filter((r) => r[field]).map((e: any) => e[field] + "");
        return Array.from(new Set(options));
    };

    return (
        <TableRow tabIndex={-1}>
            <TableCell />
            {fields.map((field: any) => (
                <TableCell key={field.id} align="left">
                    <EditableSelectField
                        id={field.id}
                        name={field.title}
                        options={getOptions(field.id)}
                        recordsInfo={recordsInfo}
                        setRecordsInfo={setRecordsInfo}
                    />
                </TableCell>
            ))}
        </TableRow>
    );
}
