import React, { useState, useEffect } from "react";
import makeStyles from "@mui/styles/makeStyles";
import Api from "utils/api";
// import clsx from "clsx";
// import Loader from "common/Loader";
// import { errorHandler } from "utils/error-handler";
import Typography from "@mui/material/Typography";
import { AdornedButton } from "common/FTButtons";
import TextField from "@mui/material/TextField";
import { defaultNumericOperators, defaultTextOperators } from "config/form-data";
import FTTable from "common/FTTable";
import { DeleteIconButton, FTIconButton, ClearButton } from "common/FTButtons";
import Accordion from "@mui/material/Accordion";
import Switch from "@mui/material/Switch";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import FormControlLabel from "@mui/material/FormControlLabel";
import EditIcon from "@mui/icons-material/Edit";
import errorNotification from "utils/api-error";
import ConfirmDialog from "common/ConfirmDialog";
import RuleGridFrom from "./RuleGridForm";
import { getUuid, useScreenshot } from "utils/helpers";
import FTSelect from "common/FTSelect";
import TextareaAutosize from "@mui/base/TextareaAutosize";
import { defaultFilter, defaultGrpInfo, tableColumns, options, defaultFormData } from "./group-config";
import AppCover from "home/dashboad/AppCover";
import Checkbox from '@mui/material/Checkbox';

const useRowStyles = makeStyles({
    root: {
        width: "100%",
        padding: "15px 0",
    },
    container: {
        display: "flex",
        alignItems: "flex-start",
        flexDirection: "row",
        justifyContent: "flex-start",
        width: "100%",
    },
    formBase: {
        width: "30%",
        height: "100%",
        padding: "0 10px",
        borderRight: "2px solid grey",
    },
    btnBase: {
        marginTop: "20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: "10px",
    },
    inputform: {
        padding: "0px 10px",
        display: "flex",
        width: "100%",
        flexDirection: "row",
        flexFlow: "row wrap",
    },
    iconBtn: {
        fontSize: "1.5rem",
    },
    reportBase: {
        width: "65%",
        paddingLeft: "30px",
    },
    btn: {
        textTransform: "capitalize",
    },
    shapeCircle: {
        borderRadius: "50%",
        background: "#7ec07e",
        width: "15px",
        height: "15px",
        display: "inline-block",
        marginRight: "5px",
    },
    ruleBase: {
        width: "100%",
        display: "flex",
        alignItems: "center",
        marginTop: "20px",
    },
});

const collectionName = "holdings";
const docId = "pf_holding_groups";

const panelStyle: any = { display: "block", height: "calc(100vh - 175px)", overflowY: "auto" };

export default function GroupManagement() {
    const classes = useRowStyles();
    const [formData, setFormData] = useState<any>({ ...defaultFormData });
    const [filters, setFilters] = useState([{ ...defaultFilter }]);
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [groupsInfo, setGroupsInfo] = useState<any>({ ...defaultGrpInfo });
    const [fields, setFields] = useState<any>([]);
    const [dragId, setDragId] = useState();
    const [expanded, setExpanded] = useState({});
    const [group, setGroup] = useState<any>({});

    const screenshot = useScreenshot();

    const handleDrag = (ev) => {
        setDragId(ev.currentTarget.id);
    };

    const handleDrop = (ev) => {
        try {
            const records = [...(groupsInfo?.groups || [])];
            const dragBox = records.find((box) => box.id === dragId);
            const dropBox = records.find((box) => box.id === ev.currentTarget.id);
            const dragBoxOrder = dragBox.order;
            const dropBoxOrder = dropBox.order;
            const newBoxState = records.map((box) => {
                if (box.id === dragId) {
                    box.order = dropBoxOrder;
                }
                if (box.id === ev.currentTarget.id) {
                    box.order = dragBoxOrder;
                }
                return box;
            });
            setGroupsInfo({ ...groupsInfo, groups: newBoxState });
            updateDoc(newBoxState, null, false);
        } catch (err) {
            console.log(err);
        }
    };

    const handler = (type) => {
        if (!formData?.title) {
            errorNotification.next({ type: "error", text: "Please enter group title", open: true });
            return;
        }
        let rules: any = [];

        if (formData?.is_advance) {
            rules = [];
        } else {
            formData.conditional_statements = "";
            rules = filters
                .filter(({ column, operator, value }) => {
                    if (!column || !operator || value == undefined || value == null) {
                        return false;
                    }
                    return true;
                })
                .map(({ column, operator, value }) => ({ column, operator, value }));

            // if (rules?.length < 1) {
            //     errorNotification.next({ type: "error", text: "Please enter valid rules", open: true });
            //     return;
            // }
        }

        if (type == "update") {
            const list = [...(groupsInfo?.masterData || [])];
            const grpIndex = list.findIndex((grp) => grp.id === formData?.id);
            list[grpIndex] = {
                ...list[grpIndex],
                title: formData.title,
                group_type: formData.group_type,
                is_active: formData.is_active,
                is_not: formData.is_not,
                conditional_statements: formData.conditional_statements,
                rules,
            };
            updateDoc(list, "updated");
        } else {
            const totalGroup = groupsInfo?.masterData?.length || 0;
            const groups = [
                ...(groupsInfo?.masterData || []),
                {
                    id: getUuid(),
                    title: formData.title,
                    group_type: formData.group_type,
                    is_active: formData.is_active,
                    is_not: formData.is_not,
                    conditional_statements: formData.conditional_statements,
                    order: totalGroup + 1,
                    rules,
                },
            ];
            updateDoc(groups, "created");
        }
    };

    function onChange(field, value) {
        setFormData({ ...formData, [field]: value });
    }

    function onTypeChage(value) {
        setFormData({ ...formData, group_type: value });
    }

    function transformResponse(response) {
        let groups: any = [];
        if (response?.collections) {
            const collections = JSON.parse(response.collections);
            const doc = collections.find((col) => col.name == collectionName);
            if (doc) {
                groups = doc?.documents.find((col) => col._id == docId)?.groups;
            }
        }
        return groups;
    }

    function updateDoc(groups, message, btnLoader = true) {
        const payload = { _id: docId, groups: groups };
        if (btnLoader) {
            setGroupsInfo({ ...groupsInfo, isLoading: true });
        }
        Api.updateDocument(collectionName, docId, { document: JSON.stringify(payload) }, { comment: "update" })
            .then((response) => {
                if (response.success) {
                    if (message) {
                        errorNotification.next({ type: "success", text: `Group ${message} successfully.`, open: true });
                    }
                    const newGroups = transformResponse(response);
                    setGroupsInfo({ ...groupsInfo, masterData: newGroups, groups: newGroups, isLoading: false });
                    handleClear();
                } else {
                    errorNotification.next({ type: "error", text: "Failed", open: true });
                    setGroupsInfo({ ...groupsInfo, isLoading: false });
                }
            })
            .catch((err) => {
                console.log(err);
                setGroupsInfo({ ...groupsInfo, isLoading: false });
            });
    }

    function deleteRecord(e) {
        e?.stopPropagation();
        const updatedGroups = groupsInfo?.masterData?.filter((grp) => grp.id != group?.id);
        updateDoc(updatedGroups, "deleted", false);
    }

    function edit(e, record) {
        e.stopPropagation();
        setFormData({
            ...formData,
            id: record?.id,
            title: record.title,
            group_type: record.group_type,
            is_active: record?.is_active,
            is_not: record?.is_not,
            is_advance: record?.conditional_statements ? true : false,
            conditional_statements: record?.conditional_statements,
            formType: "update",
        });
        const list = JSON.parse(JSON.stringify(record.rules));
        list.forEach((filter, i) => {
            const fieldInfo = fields.find((field) => field.id === filter.column);
            if (fieldInfo?.field_type != "string") {
                list[i]["operators"] = defaultNumericOperators;
            } else {
                list[i]["operators"] = defaultTextOperators;
            }
        });
        setFilters(list || []);
    }

    const toggle = (panelId) => (event, isExpanded) => {
        const val = isExpanded ? panelId : false;
        setExpanded({ ...expanded, panelId: val });
    };

    function handleClear() {
        setFilters([{ ...defaultFilter }]);
        setFormData({ ...formData, ...defaultFormData });
    }
    function delGroup(e, rec) {
        setConfirmOpen(true);
        setGroup(rec);
    }

    useEffect(() => {
        Api.getZoneSettings("portfolios", collectionName)
            .then((response: any) => {
                const groups = response?.[docId]?.["groups"];
                setFields(response?.fields?.fields || []);
                if (!groups) {
                    const errorInfo = {
                        type: "error",
                        text: `Unable to fetch settings`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                } else {
                    setGroupsInfo({ masterData: [...groups], groups: [...groups] });
                }
                screenshot.take()
            })
            .catch((err: any) => {
                console.log(err);
                setGroupsInfo(defaultGrpInfo);
            });
    }, []);

    return (
        <AppCover>
            <div className={classes.root}>
                <div className={classes.container}>
                    <div className={classes.formBase} style={panelStyle}>
                        <div className={classes.inputform}>
                            <div style={{ width: "60%", paddingRight: "16px" }}>
                                <TextField
                                    id="title"
                                    label="Title"
                                    onChange={(e) => onChange("title", e.target.value)}
                                    autoComplete="off"
                                    variant="standard"
                                    value={formData?.title || ""}
                                    // helperText="Incorrect entry."
                                    error={false}
                                    style={{ width: "100%" }}
                                />
                            </div>
                            <div style={{ width: "40%" }}>
                                <FTSelect
                                    label="Group Type"
                                    variant="standard"
                                    value={formData?.group_type || ""}
                                    options={options}
                                    onChange={onTypeChage}
                                />
                            </div>
                            <div className={classes.ruleBase}>
                                <Typography
                                    style={{ width: "100%", color: "#616161" }}
                                    align="left"
                                    component="div"
                                    variant="subtitle1"
                                >
                                    Rules
                                </Typography>
                                <FormControlLabel
                                    style={{ marginLeft: "auto" }}
                                    control={
                                        <Switch
                                            size="small"
                                            checked={!formData?.is_advance ? false : true}
                                            color="primary"
                                            onChange={(e) => onChange("is_advance", e.target.checked)}
                                        />
                                    }
                                    label="Advance"
                                />
                            </div>
                            <FormControlLabel
                                control={<Checkbox
                                    checked={formData?.is_not}
                                    size="small"
                                    onChange={(e) => onChange("is_not", e.target.checked)}
                                />}
                                label="Not"
                            />
                            {!formData?.is_advance ? (
                                <div style={{ width: "100%" }}>
                                    {filters.map((filter: any, index: number) => (
                                        <RuleGridFrom
                                            key={index}
                                            filter={filter}
                                            fields={fields}
                                            index={index}
                                            filters={filters}
                                            setFilters={setFilters}
                                            operators={filter.operators || []}
                                        />
                                    ))}
                                </div>
                            ) : (
                                <div style={{ width: "100%" }}>
                                    <TextareaAutosize
                                        minRows={6}
                                        onChange={(e) => onChange("conditional_statements", e.target.value)}
                                        autoComplete="off"
                                        value={formData?.conditional_statements || ""}
                                        style={{ width: "100%" }}
                                    />
                                </div>
                            )}
                        </div>
                        <div className={classes.btnBase}>
                            <div>
                                <FormControlLabel
                                    style={{ marginLeft: "auto" }}
                                    control={
                                        <Switch
                                            checked={!formData?.is_active ? false : true}
                                            color="primary"
                                            onChange={(e) => onChange("is_active", e.target.checked)}
                                        />
                                    }
                                    label="Active"
                                />
                            </div>
                            <div style={{ width: "60%" }}>
                                <ClearButton handler={handleClear} value={true} />
                                <AdornedButton
                                    style={{ marginLeft: "8px" }}
                                    className={classes.btn}
                                    variant="contained"
                                    color="primary"
                                    size={"small"}
                                    onClick={() => handler(formData?.formType)}
                                    loading={groupsInfo?.isLoading}
                                >
                                    {formData?.formType === "update" ? "Update" : "Save"}
                                </AdornedButton>
                            </div>
                        </div>
                    </div>
                    <div className={classes.reportBase} style={{ ...panelStyle, padding: "0 30px" }}>
                        <Typography style={{ color: "#616161" }} align="left" component="h1" variant="h5">
                            Groups
                        </Typography>

                        <div>
                            {groupsInfo?.groups
                                ?.sort((a, b) => a.order - b.order)
                                .map((record, id) => (
                                    <div
                                        style={{ padding: "5px" }}
                                        key={record.id}
                                        id={record.id}
                                        draggable={true}
                                        onDragOver={(ev) => ev.preventDefault()}
                                        onDragStart={handleDrag}
                                        onDrop={handleDrop}
                                    >
                                        <ConfirmDialog
                                            title={`Delete?`}
                                            open={confirmOpen}
                                            setOpen={setConfirmOpen}
                                            stopPropagation={true}
                                            onConfirm={(e) => deleteRecord(e)}
                                        >
                                            Are you sure you want to delete this document?
                                        </ConfirmDialog>
                                        <Accordion key={id} expanded={expanded[id]} onChange={toggle(id)}>
                                            <AccordionSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls={`${id}-content`}
                                                id={`${id}-header`}
                                                style={{ fontWeight: 500, margin: 0 }}
                                            >
                                                <div style={{ display: "flex", alignItems: "center" }}>
                                                    <span
                                                        className={classes.shapeCircle}
                                                        style={!record?.is_active ? { background: "red" } : undefined}
                                                    />
                                                    {record.title}
                                                </div>
                                                <div style={{ marginLeft: "auto" }}>
                                                    <DeleteIconButton
                                                        handler={(e) => {
                                                            e.stopPropagation();
                                                            delGroup(e, record);
                                                        }}
                                                    />
                                                    <FTIconButton
                                                        handler={(e) => edit(e, record)}
                                                        title="View Report"
                                                        btnIcon={<EditIcon className={classes.iconBtn} />}
                                                        placement="top"
                                                    />
                                                </div>
                                            </AccordionSummary>
                                            <AccordionDetails style={{ paddingTop: "0px" }}>
                                                <Typography>
                                                    {record?.group_type && (
                                                        <span style={{ marginBottom: "3px" }}>
                                                            {" "}
                                                            Group Type: {record?.group_type}{" "}
                                                        </span>
                                                    )}
                                                    {record?.rules?.length > 0 && (<>
                                                        <div style={{ marginBottom: "3px" }}>
                                                            Not: {record.is_not ? "" + record?.is_not : "false"}
                                                        </div>
                                                        <div style={{ width: "50%", marginTop: "8px" }}>
                                                            <FTTable
                                                                columns={tableColumns || []}
                                                                rows={record?.rules || []}
                                                            />
                                                        </div>
                                                    </>)}
                                                    {record?.conditional_statements && (
                                                        <div style={{ width: "80%" }}>
                                                            <div style={{ padding: "10px 20px%", background: "#f5f5f5" }}>
                                                                {record?.conditional_statements}
                                                            </div>
                                                        </div>
                                                    )}
                                                </Typography>
                                            </AccordionDetails>
                                        </Accordion>
                                    </div>
                                ))}
                        </div>
                    </div>
                </div>
            </div>
        </AppCover >
    );
}
