import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import TextField from "@mui/material/TextField";
import { defaultNumericOperators, defaultTextOperators } from "config/form-data";
import { FormControl, Input, InputLabel, MenuItem, Select, IconButton, Tooltip } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";

const useRowStyles = makeStyles({
    grid: {
        display: "flex",
        flexDirection: "row",
    },
    iconBtn: {
        fontSize: "1.5rem",
    },
    formControl: {
        marginTop: "18px",
        paddingRight: "15px",
        width: "28%",
    },
    inputBase: {
        fontSize: ".8rem",
    },
    btnBase: {
        flexDirection: "row",
        display: "flex",
        justifyContent: "flex-start",
        alignItems: "flex-end",
        width: "10%",
    },
});

const RemoveFilterFields = ({ classes, handleRemoveFilter }) => {
    return (
        <Tooltip title="Remove" placement="top">
            <IconButton aria-label="delete" onClick={handleRemoveFilter} className={classes.iconBtn} size="large">
                <DeleteIcon fontSize="small" />
            </IconButton>
        </Tooltip>
    );
};

const AddFilterFields = ({ classes, handleAddFilter }) => {
    return (
        <Tooltip title="Add" aria-label="add" placement="top">
            <IconButton aria-label="delete" onClick={handleAddFilter} className={classes.iconBtn} size="large">
                <AddIcon fontSize="small" />
            </IconButton>
        </Tooltip>
    );
};

export default function RuleGridForm({ fields, filter, index, operators, filters, setFilters }) {
    const classes = useRowStyles();

    const filterCount = filters?.length - 1;

    const handleChange = (event: any, index: number) => {
        const { name, value } = event.target;
        const list = [...filters];
        if (name === "value" && list[index]["isNumber"]) {
            list[index][name] = parseFloat(value);
        } else {
            list[index][name] = value;
        }
        if (name === "column") {
            const fieldInfo = fields.find((field) => field.id === value);
            if (fieldInfo?.field_type != "string") {
                list[index]["operators"] = defaultNumericOperators;
            } else {
                list[index]["operators"] = defaultTextOperators;
            }
            const field_info: any = fields.find((f: any) => f.id === list[index]["column"]);
            if (field_info) {
                if (field_info?.field_type == "string") {
                    list[index]["isNumber"] = false;
                } else {
                    list[index]["isNumber"] = true;
                    list[index]["value"] = "";
                }
            }
        } else if (name === "operator") {
            if (["NOT IN", "IN"].includes(value)) {
                list[index]["isNumber"] = false;
            } else {
                const field_info: any = fields.find((f: any) => f.id === list[index]["column"]);
                if (field_info?.field_type != "string") {
                    list[index]["isNumber"] = true;
                }
            }
        }
        setFilters(list);
    };

    const handleAddFilter = () => {
        setFilters([...filters, { column: "", operator: "", value: "" }]);
    };

    const handleRemoveFilter = (index: number) => {
        if (filters.length === 1) {
            setFilters([{ column: "", operator: "", value: "" }]);
        } else {
            const list = [...filters];
            list.splice(index, 1);
            setFilters(list);
        }
    };

    return (
        <div className={classes.grid}>
            <FormControl variant="standard" className={classes.formControl}>
                <InputLabel className={classes.inputBase} id={"filter-column-label" + index}>
                    {" "}
                    Columns{" "}
                </InputLabel>
                <Select
                    labelId="filter-column-label"
                    id={"column-filter-select" + index}
                    name="column"
                    value={filter.column}
                    onChange={(event) => handleChange(event, index)}
                    input={<Input className={classes.inputBase} />}
                >
                    {fields.map((field) => {
                        if (field.filterable) {
                            return (
                                <MenuItem key={field.id} value={field.id} dense={true}>
                                    {field.title}
                                </MenuItem>
                            );
                        }
                    })}
                </Select>
            </FormControl>
            <FormControl variant="standard" className={classes.formControl}>
                <InputLabel className={classes.inputBase} id={"filter-operator-label" + index}>
                    Operators
                </InputLabel>
                <Select
                    labelId="filter-operator-label"
                    id="operator-filter-select"
                    name="operator"
                    value={filter.operator}
                    onChange={(event) => handleChange(event, index)}
                    input={<Input className={classes.inputBase} />}
                >
                    {operators?.length === 0 && (
                        <MenuItem disabled value={""}>
                            No Options
                        </MenuItem>
                    )}
                    {operators.map((op) => (
                        <MenuItem key={op.value} dense={true} value={op.value}>
                            {op.label}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
            <FormControl variant="standard" className={classes.formControl}>
                <TextField
                    id={"filter-value" + index}
                    name="value"
                    type={filter.isNumber ? "number" : "text"}
                    InputProps={{ className: classes.inputBase }}
                    InputLabelProps={{ className: classes.inputBase }}
                    value={filter.value}
                    label="Value"
                    autoComplete="off"
                    variant="standard"
                    onChange={(event) => handleChange(event, index)}
                />
                <small className="text-danger" style={{ fontSize: "0.65em" }}>
                    {filter.error}
                </small>
            </FormControl>
            <div className={classes.btnBase}>
                <RemoveFilterFields classes={classes} handleRemoveFilter={() => handleRemoveFilter(index)} />
                {filterCount === index ? <AddFilterFields classes={classes} handleAddFilter={handleAddFilter} /> : null}
            </div>
        </div>
    );
}
