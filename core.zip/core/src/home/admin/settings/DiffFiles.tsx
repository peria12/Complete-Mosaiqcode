import React, { useEffect, useState } from "react";
import Api from "utils/api";

import ReactDiffViewer from "react-diff-viewer";
import * as stableStringify from "json-stable-stringify";

export default function DiffFiles({ collection, doc, first, second }) {
    const [codes, setCodes] = useState<any>(null);

    useEffect(() => {
        const call1 = Api.getDocument(collection, doc, first);
        const call2 = Api.getDocument(collection, doc, second);
        Promise.all([call1, call2]).then(([resp1, resp2]) => {
            const ts1 = resp1.__meta.timestamp;
            const ts2 = resp2.__meta.timestamp;
            const s1 = stableStringify(
                { ...resp1, __meta: undefined, _id: undefined, __doc: undefined },
                { space: "  " }
            );
            const s2 = stableStringify(
                { ...resp2, __meta: undefined, _id: undefined, __doc: undefined },
                { space: "  " }
            );

            if (Date.parse(ts2) > Date.parse(ts1)) {
                setCodes({ left: s1, right: s2 });
            } else {
                setCodes({ left: s2, right: s1 });
            }
        });
    }, [collection, doc, first, second]);

    if (!codes) {
        return <div> Loading Diff..</div>;
    }
    return <ReactDiffViewer oldValue={codes.left} newValue={codes.right} splitView={true} />;
}
