import React, { useState, useEffect } from "react";
import { Theme } from "@mui/material/styles";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Grid from "@mui/material/Grid";
import TextField from "@mui/material/TextField";
import AssignmentIcon from "@mui/icons-material/Assignment";
import Api from "utils/api";
import { errorHandler } from "utils/error-handler";
import FTSnackBar from "common/FTSnackBar";
import { ClearButton, UpdateButton, DeleteButton, SaveButton, ResetButton, IconBtn } from "common/FTButtons";
import ConfirmDialog from "common/ConfirmDialog";
import JsonEditor from "common/JsonEditor";
import HistoryPopover from "./HistoryPopover";
import DocumentationDialog from "./DocumentationDialog";
import CollectionList from "./CollectionList";
import moment from "moment";
import { Button, Chip } from "@mui/material";
import DiffFiles from "./DiffFiles";
import { useScreenshot } from "utils/helpers";
import AppCover from "home/dashboad/AppCover";
import SearchBox from "common/SearchBox";

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            width: "100%",
        },
        baseContainer: {
            backgroundColor: theme.palette.background.paper,
            height: "calc(100vh - 200px)",
            overflowY: "auto",
            width: "100%",
        },
        list: {
            width: "100%",
        },
        textAreaBase: {
            width: "100%",
            height: "calc(100vh - 300px)",
            overflowY: "auto",
        },
        textAreaContainer: {
            marginLeft: "8px",
            backgroundColor: theme.palette.background.paper,
            height: "100%",
        },
        textArea: {
            width: "100%",
            border: "2px solid rgb(158, 158, 158)",
            borderRadius: "4px",
            paddingLeft: theme.spacing(2),
            paddingRight: theme.spacing(2),
        },
        nested: {
            paddingLeft: theme.spacing(3.5),
        },
        subheader: {
            backgroundColor: "#fafafa",
            padding: "0 12px 8px 12px",
        },
        primaryFont: {
            fontSize: ".85rem",
            color: "rgba(0, 0, 0, 0.87)",
        },
        secondaryFont: {
            fontSize: ".78rem",
            color: "rgba(0, 0, 0, 0.54)",
            fontWeight: 500,
        },
        listItemIcon: {
            minWidth: "30px",
        },
        activeListItem: {
            backgroundColor: "rgba(140, 140, 140, .4)",
            color: "#fff",
            "&:hover": {
                backgroundColor: "rgba(140, 140, 140, .4)",
                color: "#ffffff",
            },
        },
        inputBase: {
            fontSize: ".77rem",
            cursor: "text",
        },
        displayFlex: {
            display: "flex",
        },
        marginLeftAuto: {
            marginLeft: "auto",
        },
        labelBase: {
            fontSize: ".85rem",
        },
        btn: {
            textTransform: "capitalize",
            marginLeft: "auto",
            marginRight: 5,
        },
        formControl: {
            paddingTop: "20px",
        },
        formLabel: {
            width: "100%",
            fontSize: "17px",
            color: "#00a0dc",
        },
        inlineFC: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
        },
    })
);

const TextareaField = ({ classes, value, setValue }) => {
    return (
        <div className={classes.textAreaContainer}>
            <JsonEditor json={value} onChangeText={setValue}></JsonEditor>
        </div>
    );
};

const jsonStringify = (value) => {
    return JSON.stringify({ ...value, __meta: undefined, __doc: undefined });
};

export default function Settings() {
    const classes = useStyles();
    const [isLoading, setLoading] = useState(true);
    const [isNewDoc, setIsNewDoc] = useState(false);
    const [adminSettings, setAdminSettings] = useState([]);
    const [settingOrg, setSettingOrg] = useState([]);
    const [value, setValue] = useState<any>("");
    const [updatedValue, setUpdatedValue] = useState("");
    const [activeItem, setActiveItem] = useState("");
    const [showSnackBar, setShowSnackBar] = useState(false);
    const [message, setMessage] = useState({ type: "", text: "", open: false, duration: 3000 });
    const [collectionName, setCollectionName] = useState("");
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [comment, setComment] = useState<any>({ value: "", error: false });
    const [version, setVersion] = useState<any>(undefined);
    const [diffVersion, setDiffVersion] = useState<string | null>(null);
    const [oldRecords, setOldRecords] = useState<any[]>([]);
    const [open, setOpen] = useState(false);
    const [metaDataProps, setMetaDataProps] = useState({ orignalDoc: {}, documentation: {} });
    const [searchText, setSearchText] = useState<string | undefined>(undefined);

    const screenshot = useScreenshot();

    useEffect(() => {
        setLoading(true);
        Api.getCollections()
            .then((response: any) => {
                updateSettingState(transformResponse(response));
            })
            .catch((e: any) => {
                errorHandler(e);
                updateSettingState({});
            })
            .finally(() => {
                setLoading(false);
                screenshot.take();
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const refreshHistory = () => {
        if (!collectionName?.length || !activeItem?.length) {
            setOldRecords([]);
        } else {
            Api.getDocumentHistory(collectionName, activeItem).then((resp) => {
                setOldRecords(
                    (resp?.history || []).sort((a, b) => (b.__meta?.timestamp || "").localeCompare(a.__meta?.timestamp))
                );
            });
        }
    };

    useEffect(() => {
        refreshHistory();
        setDiffVersion(null);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [collectionName, activeItem]);

    function transformResponse(response) {
        let collectionInfo: any = {};
        if (response?.collections) {
            collectionInfo = {
                collections: JSON.parse(response.collections),
            };
        }
        return collectionInfo;
    }

    const getHistory = () => oldRecords.map((x) => ({ ...x.__meta, rec_id: x._id }));

    const isLatest = () => {
        if (!version) {
            return true;
        }
        return !version?.archived;
    };

    const getDetails = () => {
        if (version && version.timestamp) {
            const fixTime = (ts) => moment.utc(ts).local().format("YYYY-MM-DD HH:mm:ss");
            const title = `Author: ${version.author}, Time: ${fixTime(version.timestamp)}, Comment: ${version.comment}`;
            if (isLatest()) {
                return (
                    <>
                        <Chip label="Latest" color="primary" size="small" />
                        &nbsp;&nbsp;{title}
                    </>
                );
            } else {
                return title;
            }
        }
        return <Chip label="Latest" color="primary" size="small" />;
    };

    function updateSettingState(response: any) {
        setAdminSettings(response?.collections || []);
        setSettingOrg(response?.collections || []);
    }

    const setSnackMessage = (message: any) => {
        setShowSnackBar(true);
        setMessage(message);
    };

    const handleAction = (type: string, updatedEntry = null) => {
        let callApi: any = null;
        if (!comment?.value?.length && !updatedEntry) {
            setComment({ value: "", error: true });
            return;
        }

        if (type == "update" || type == "insert") {
            let doc: any = {};
            if (!updatedEntry) {
                try {
                    doc = JSON.parse(updatedValue);
                } catch (err) {
                    setSnackMessage({ type: "error", text: "Invalid JSON doc ", open: true });
                    return;
                }
            } else {
                doc = updatedEntry;
            }
            const _id = doc?._id;

            if (type == "insert") {
                if (_id) {
                    const collectionInfo: any = settingOrg.find((s: any) => s.name === collectionName);
                    if (collectionInfo && collectionInfo.documents) {
                        if (collectionInfo.documents.find((doc) => doc._id == _id)) {
                            setSnackMessage({ type: "error", text: "_id already exists", open: true, duration: 3000 });
                            return;
                        }
                    }
                }
                setSnackMessage({ type: "info", text: "Saving...", open: true, duration: -1 });
                callApi = Api.insertDocument(collectionName, { document: JSON.stringify(doc) }, comment.value);
            }

            if (type == "update") {
                delete doc._id;
                setSnackMessage({ type: "info", text: "Updating...", open: true, duration: -1 });
                let params = {};
                if (updatedEntry) {
                    params = { type: "documentation_update" };
                } else {
                    params = { comment: comment.value };
                    doc = { ...doc, __doc: metaDataProps.documentation };
                }
                callApi = Api.updateDocument(collectionName, _id, { document: JSON.stringify(doc) }, params);
            }
        } else if (type == "delete") {
            setSnackMessage({
                type: "info",
                text: "Deleting...",
                open: true,
                duration: 3000,
            });
            callApi = Api.deleteDocument(collectionName, activeItem, comment.value);
        } else {
            return;
        }

        callApi
            .then(async (response) => {
                if (response) {
                    if (response.success) {
                        setSnackMessage({ type: "success", text: "Success", open: true, duration: 6000 });
                        response = transformResponse(response);
                        updateSettingState(response);
                        const collection = response?.collections?.find((c) => c.name == collectionName);
                        let doc = collection?.documents?.find((d) => d._id == activeItem);
                        if (doc) {
                            if (type == "update") {
                                doc = await Api.fetchDocument(collectionName, doc._id);
                            }
                            setValue(jsonStringify(doc));
                            setMetaDataProps({ orignalDoc: doc, documentation: doc?.__doc || {} });
                            setVersion({ ...doc.__meta, rec_id: doc._id });
                        }
                    } else {
                        const err = `Failed to ${type}: ${response.message}`;
                        setSnackMessage({ type: "error", text: err, open: true, duration: 3000 });
                        errorHandler(err);
                    }
                    // setValue("");
                    // setActiveItem("");
                    // setComment({ value: "", error: false });
                    refreshHistory();
                }
            })
            .catch((err) => {
                setSnackMessage({ type: "error", text: "Something went wrong.", open: true, duration: 3000 });
                errorHandler(err);
            });
    };

    const deleteCollection = () => {
        setSnackMessage({ type: "info", text: "Deleting...", open: true, duration: 3000 });
        Api.deleteCollection(collectionName)
            .then((response) => {
                if (response) {
                    if (response.success) {
                        setSnackMessage({ type: "success", text: "Success", open: true, duration: 3000 });
                        updateSettingState(transformResponse(response));
                    } else {
                        const err = `Failed to delete collection: ${response.message}`;
                        setSnackMessage({ type: "error", text: err, open: true, duration: 3000 });
                        errorHandler(err);
                    }
                    // setActiveItem("");
                }
            })
            .catch((err) => {
                setSnackMessage({ type: "error", text: "Something went wrong.", open: true, duration: 3000 });
                errorHandler(err);
            });
    };

    const onClose = () => {
        setMessage({ type: "", text: "", open: false, duration: 3000 });
        setShowSnackBar(false);
    };

    const handleClear = () => {
        setValue("");
        setUpdatedValue("");
    };

    const selectVersion = (version) => {
        setVersion(version);
        Api.getDocument(collectionName, activeItem, version.rec_id).then((response) => {
            setValue(JSON.stringify(response));
        });
    };

    const onDiff = (diff_version) => {
        setDiffVersion(diff_version);
    };

    const addOrUpdateDocumentation = (document: any) => {
        const newValue: any = { ...metaDataProps?.orignalDoc, __doc: { ...document } };
        handleAction("update", newValue);
    };

    const openDeletePopup = () => {
        if (!comment?.value?.length) {
            setComment({ value: "", error: true });
            return;
        }

        setConfirmOpen(true);
    };

    return (
        <AppCover
            loading={isLoading}
            header={
                <div className="ms-2" style={{ width: "100%" }}>
                    <SearchBox setSearchText={setSearchText} />
                </div>
            }
        >
            <div className={classes.root}>
                {showSnackBar && <FTSnackBar snack={message} onClose={onClose} />}
                <Grid container direction="row" justifyContent="center" alignItems="flex-start">
                    <Grid item container xs={12} sm={12} md={3} lg={3} xl={3}>
                        <CollectionList
                            classes={classes}
                            adminSettings={adminSettings}
                            setActiveItem={setActiveItem}
                            activeItem={activeItem}
                            setAdminSettings={setAdminSettings}
                            setIsNewDoc={setIsNewDoc}
                            settingOrg={settingOrg}
                            setValue={setValue}
                            deleteCollection={deleteCollection}
                            collectionName={collectionName}
                            setCollectionName={setCollectionName}
                            setUpdatedValue={setUpdatedValue}
                            setVersion={setVersion}
                            setMetaDataProps={setMetaDataProps}
                            searchText={searchText}
                        />
                    </Grid>
                    <Grid item container xs={12} sm={12} md={9} lg={9} xl={9}>
                        {diffVersion ? (
                            <div className="d-flex flex-column ms-3" style={{ width: "100%" }}>
                                <div className="my-2">
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        size="small"
                                        onClick={() => setDiffVersion(null)}
                                    >
                                        Back
                                    </Button>
                                </div>
                                <div>
                                    <DiffFiles
                                        collection={collectionName}
                                        doc={activeItem}
                                        first={version?.rec_id || activeItem}
                                        second={diffVersion}
                                    ></DiffFiles>
                                </div>
                            </div>
                        ) : (
                            <div className="d-flex flex-column" style={{ width: "100%" }}>
                                <div className="d-flex justify-content-between mb-2 ms-2">
                                    <div>{getDetails()}</div>
                                    {open && (
                                        <DocumentationDialog
                                            classes={classes}
                                            open={open}
                                            setOpen={setOpen}
                                            onAdd={addOrUpdateDocumentation}
                                            metaDataProps={metaDataProps}
                                        />
                                    )}
                                    {collectionName == "dal_fields" && !isNewDoc && (
                                        <IconBtn
                                            classes={classes}
                                            handler={() => setOpen(true)}
                                            startIcon={<AssignmentIcon />}
                                            label={"Documentation"}
                                            color="primary"
                                            size="small"
                                        />
                                    )}
                                    <HistoryPopover
                                        history={getHistory()}
                                        onSelect={selectVersion}
                                        activeVersion={version}
                                        onDiff={onDiff}
                                    />
                                </div>
                                <div className={classes.textAreaBase}>
                                    <TextareaField classes={classes} value={value} setValue={setUpdatedValue} />
                                </div>
                                <div className="mx-2 my-3 comments">
                                    <TextField
                                        required
                                        variant="standard"
                                        onChange={(e) => {
                                            comment.value = e.target.value;
                                            comment.error = false;
                                        }}
                                        label="Comment"
                                        style={{ width: "100%" }}
                                        error={comment.error}
                                    />
                                </div>
                                <div>
                                    <ClearButton handler={handleClear} value={isLatest() && updatedValue} />
                                    {!isNewDoc && (
                                        <ResetButton
                                            handler={() => setValue(new String(value))}
                                            value={isLatest() && updatedValue}
                                        />
                                    )}
                                    {!isNewDoc && (
                                        <UpdateButton
                                            handler={() => handleAction("update")}
                                            value={isLatest() && updatedValue}
                                        />
                                    )}
                                    {!isNewDoc && (
                                        <>
                                            <DeleteButton
                                                handler={openDeletePopup}
                                                value={isLatest() && updatedValue}
                                            />
                                            <ConfirmDialog
                                                title={`Delete document?`}
                                                open={confirmOpen}
                                                setOpen={setConfirmOpen}
                                                onConfirm={() => handleAction("delete")}
                                            >
                                                Are you sure you want to delete this document?
                                            </ConfirmDialog>
                                        </>
                                    )}
                                    {isNewDoc && (
                                        <SaveButton
                                            handler={() => handleAction("insert")}
                                            value={isLatest() && updatedValue}
                                        />
                                    )}
                                </div>
                            </div>
                        )}
                    </Grid>
                </Grid>
            </div>
        </AppCover>
    );
}
