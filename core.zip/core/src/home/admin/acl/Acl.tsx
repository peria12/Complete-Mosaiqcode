import React, { useState, useEffect, useRef } from "react";
import makeStyles from "@mui/styles/makeStyles";
import IconButton from "@mui/material/IconButton";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import Typography from "@mui/material/Typography";
import { Button } from "@mui/material";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";

import Api from "utils/api";
import SearchBox from "common/SearchBox";
import { errorHandler } from "utils/error-handler";
import { searchByProp, useScreenshot } from "utils/helpers";
import UserPermissions from "./UserPermissions";
import ActionPopover from "./ActionPopover";
import FTSnackBar from "common/FTSnackBar";
import Access from "utils/access";
import AppCover from "home/dashboad/AppCover";
import { mapUser, Selectors } from "./Selectors";
import errorNotification from "utils/api-error";

const useRowStyles = makeStyles({
    root: {
        "& > *": {
            borderBottom: "unset",
        },
    },
    tableHeader: {
        fontWeight: "bold",
    },
    parentRow: {
        paddingBottom: "3px",
        paddingTop: "3px",
    },
    childRow: {
        color: "grey",
        paddingBottom: "0px",
        paddingTop: "0px",
    },
    checkbox: {
        padding: "6px 1px",
    },
    qusIconBtn: {
        padding: "2px",
    },
    qusIcon: {
        fontSize: ".85rem",
    },
    spacer: {
        height: "1.2rem",
    },
});

function MyCheckbox({ checked, onChecked, indeterminate, disabled, defaultClass = "", checkedClass = "" }) {
    const ref: any = useRef();
    useEffect(() => {
        ref.current.indeterminate = indeterminate;
    }, [indeterminate]);

    const classVal = `form-check-input pointer ${checked || indeterminate ? checkedClass : ""} ${defaultClass}`;

    return (
        <div className="form-check pointer">
            <input
                className={classVal}
                ref={ref}
                type="checkbox"
                value=""
                checked={checked}
                disabled={disabled}
                onChange={(event) => onChecked(event.target.checked)}
            />
        </div>
    );
}

function Row({ app, permissions, handleCheckbox, checkBoxStatusMap, handleUserPermissions, tab }) {
    const [open, setOpen] = React.useState({});
    const classes = useRowStyles();
    const hasChildren = app.zones && Object.keys(app.zones).length > 0;

    const showZone = (zone) => Object.values(checkBoxStatusMap[zone.name]).some((acc: any) => acc.display != "hide");
    const showApp = (app) => app.zones.some(showZone);

    const handleCollapse = (id: string) => setOpen({ ...open, [id]: !open[id] });

    const getMixStatus = (type) => {
        const statuses = Object.values(checkBoxStatusMap)
            .map((zone: any) => zone[type])
            .filter((status) => status)
            .filter((status: any) => status.display != "hide");

        const values = Array.from(new Set(statuses.map((status: any) => status.value)));
        const values_out = Array.from(new Set(statuses.map((status: any) => status.value_out)));
        const value = values.length == 1 ? values[0] : -1;
        const value_out = values_out.length == 1 ? values_out[0] : -1;
        const allHide = statuses.every((status: any) => status.display == "hide");
        const allDisable = statuses.every((status: any) => status.display == "disable");
        const display = allHide ? "hide" : allDisable ? "disable" : "show";
        return { display, value, value_out };
    };

    const getSingleStatus = (zone, type) => {
        const status = checkBoxStatusMap[zone];
        return status ? status[type] : undefined;
    };

    const CheckBoxField = ({ type, zone, handleUserPermissions }) => {
        const classes = useRowStyles();
        const status = zone ? getSingleStatus(zone, type) : getMixStatus(type);
        if (!status) return <React.Fragment />;
        if (status.display == "hide") return <React.Fragment />;
        return (
            <div className="d-flex" style={{ minWidth: "100px" }}>
                {tab == "user" ? (
                    <MyCheckbox
                        checkedClass="bg-success"
                        defaultClass="border-success"
                        checked={status.value == 1}
                        disabled={status.display == "disable"}
                        onChecked={(val) => handleCheckbox(app, zone, type, val, "user", false)}
                        indeterminate={status.value == -1}
                    />
                ) : (
                    <>
                        <MyCheckbox
                            checkedClass="bg-success"
                            defaultClass="border-success"
                            checked={status.value == 1}
                            disabled={status.display == "disable"}
                            onChecked={(val) => handleCheckbox(app, zone, type, val, "group", false)}
                            indeterminate={status.value == -1}
                        />
                        <MyCheckbox
                            checkedClass="bg-danger"
                            defaultClass="border-danger"
                            checked={status.value_out == 1}
                            disabled={status.display == "disable"}
                            onChecked={(val) => handleCheckbox(app, zone, type, val, "group", true)}
                            indeterminate={status.value_out == -1}
                        />
                    </>
                )}
                {zone && (
                    <IconButton
                        color="default"
                        aria-label="View access"
                        onClick={() => {
                            handleUserPermissions(app, zone, type);
                        }}
                        className={classes.qusIconBtn}
                        size="large"
                    >
                        <HelpOutlineOutlinedIcon className={classes.qusIcon} />
                    </IconButton>
                )}
            </div>
        );
    };

    const PermissionRow = ({ permissions, zoneId = null, className }) => {
        return (
            <React.Fragment>
                {permissions.map((permission: any) => {
                    return (
                        <TableCell key={permission.id} className={className}>
                            <CheckBoxField
                                type={permission.id}
                                zone={zoneId}
                                handleUserPermissions={handleUserPermissions}
                            />
                        </TableCell>
                    );
                })}
            </React.Fragment>
        );
    };

    if (!showApp(app)) return <React.Fragment />;

    function getStripedStyle(index: number): any {
        return { background: index % 2 ? "#f5f5f5" : "white" };
    }

    return (
        <React.Fragment>
            <TableRow className={classes.root} style={{ background: "#eeeeee" }}>
                <TableCell component="th" scope="row" className={classes.parentRow}>
                    {app.title}
                    {hasChildren ? (
                        <IconButton
                            edge="end"
                            aria-label="expand row"
                            size="small"
                            onClick={() => handleCollapse(app._id)}
                        >
                            {!open[app._id] ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                        </IconButton>
                    ) : null}
                </TableCell>
                <PermissionRow permissions={permissions} className={classes.parentRow} />
            </TableRow>
            {hasChildren &&
                !open[app._id] &&
                app.zones.filter(showZone).map((zone: any, i: number) => (
                    <TableRow key={zone.name} className={classes.root} style={{ ...getStripedStyle(i) }}>
                        <TableCell component="th" scope="row" className={classes.childRow}>
                            <span style={{ paddingLeft: "12px" }}>{zone.title}</span>
                        </TableCell>
                        <PermissionRow permissions={permissions} zoneId={zone.name} className={classes.childRow} />
                    </TableRow>
                ))}
            <TableRow className={classes.spacer} />
        </React.Fragment>
    );
}

const getPermissions = (apps: any) => {
    const permissions: any = [];
    apps.forEach((app: any) => {
        app.zones
            .sort((a, b) => a.view_order - b.view_order)
            .forEach((zone: any) => {
                if (zone && zone.access) {
                    zone.access
                        .filter((acc) => acc.granted_by != "auto")
                        .forEach((access: any) => {
                            const perm = permissions.find((ele: any) => ele.id === access.name);
                            if (!perm) {
                                permissions.push({ id: access.name, title: access.title, apps: [app._id] });
                            } else {
                                if (!perm.apps.includes(app._id)) {
                                    perm.apps.push(app._id);
                                }
                            }
                        });
                }
            });
    });
    return permissions;
};
const noDataMessage = (
    <Typography align="center" component="h6" variant="subtitle1">
        No records found
    </Typography>
);

export default function Acl({ apps = [] }) {
    const [isLoading, setLoading] = useState(true);
    const [searchText, setSearchText] = useState("");
    const [applications, setApplications] = useState(apps);
    const [permissions, setPermissions] = useState([] as any);
    const [allUserAccess, setAllUserAccess] = useState([] as any);
    const [origUserAccess, setOrigUserAccess] = useState([] as any);
    const classes = useRowStyles();
    const [message, setMessage] = useState({ type: "", text: "", open: false, duration: 3000 });
    const [peopleMap, setPeopleMap] = useState({});
    const [openDialog, setOpenDialog] = useState(false);
    const [userAccessView, setUserAccessView] = useState({ app: "", zone: "", type: "" });
    const [tab, setTab] = useState<string>("user");
    const screenshot = useScreenshot();

    const myId = Access.userInfo.uuid;
    const me = origUserAccess[myId] || origUserAccess["new_user"];
    const iAmSuper = me?.access?.find((acc) => acc.app == "admin" && acc.zone == "acl" && acc.type == "admin");
    const iHaveAccess = (appId, zone, type) => {
        return me?.access?.some((x) => x.app == appId && x.zone == zone.name && x.type == type);
    };
    const getDefaultAccess = (type) => (type == "user" ? origUserAccess["new_user"] : {});

    const userHasAccess = (userId, appId, zoneId, type, userType, revoke) => {
        const user = allUserAccess[userId] || getDefaultAccess(userType);
        const access = revoke ? user?.exclude_access : user?.access;
        return access?.some((perm) => perm.app == appId && perm.zone == zoneId && perm.type == type) || false;
    };

    const userHasAccessOrig = (userId, appId, zoneId, type, userType, revoke) => {
        const user = origUserAccess[userId] || getDefaultAccess(userType);
        const access = revoke ? user?.exclude_access : user?.access;
        return access?.some((perm) => perm.app == appId && perm.zone == zoneId && perm.type == type) || false;
    };

    const filterFn = tab == "user" ? (u) => u.type == "user" : (u) => u.type != "user";
    const users = Object.values(peopleMap).filter(filterFn);

    const statusMap = {};
    apps.map((app: any) => {
        const zoneMap = {};
        app.zones.map((zone) => {
            const accessMap = {};
            zone.access.map((acc) => {
                let display = "show";
                let value = 0;
                let value_out = 0;

                if (acc.granted_by == "auto") {
                    display = "hide";
                } else {
                    if (!iAmSuper && !iHaveAccess(app._id, zone, "admin")) {
                        if (users.some((p: any) => p.id != myId) || !users.length) display = "hide";
                        else if (iHaveAccess(app._id, zone, acc.type)) {
                            if (acc.revoked_by == "admin") display = "disable";
                        } else {
                            if (acc.granted_by == "admin") display = "disable";
                        }
                    } else {
                        if (
                            tab == "user" &&
                            users.some(
                                (p: any) =>
                                    p.id != myId &&
                                    acc.granted_by != "admin" &&
                                    userHasAccessOrig(p.id, app._id, zone.name, acc.name, p.type, false)
                            )
                        ) {
                            display = "disable";
                        }
                    }
                    if (display != "hide") {
                        {
                            const vals = users.map((p: any) =>
                                userHasAccess(p.id, app._id, zone.name, acc.name, p.type, false)
                            );
                            const hasTrue = vals.includes(true);
                            const hasFalse = vals.includes(false);
                            value = hasTrue ? (hasFalse ? -1 : 1) : 0;
                        }

                        {
                            const vals = users.map((p: any) =>
                                userHasAccess(p.id, app._id, zone.name, acc.name, p.type, true)
                            );
                            const hasTrue = vals.includes(true);
                            const hasFalse = vals.includes(false);
                            value_out = hasTrue ? (hasFalse ? -1 : 1) : 0;
                        }
                    }
                }
                accessMap[acc.name] = { display, value, value_out };
            });
            zoneMap[zone.name] = accessMap;
        });
        statusMap[app._id] = zoneMap;
    });

    const showZone = (app, zone, type) => {
        const status = statusMap[app._id][zone.name];
        return status && status[type]?.display == "show";
    };

    const getDescription = React.useCallback((info) => {
        if (info.type == "adgroup") {
            return `${info.id} (group)`;
        }
        if (info.type == "supervisor") {
            return `${info.name} (Org)`;
        }
        if (info.type == "department") {
            return `${info.name} (Dept)`;
        }
    }, []);

    useEffect(() => {
        setPermissions(getPermissions(applications));
    }, [applications]);

    useEffect(() => {
        if (searchText) {
            setApplications(searchByProp(apps, searchText, "title"));
        } else {
            setApplications(apps);
        }
    }, [searchText, apps]);

    useEffect(() => {
        setLoading(true);
        Api.getAllUserAccess()
            .then((response: any) => {
                if (response) {
                    const details = { ...response.user_details, ...response.group_details };
                    setAllUserAccess(details);
                    setOrigUserAccess(details);
                }
                screenshot.take();
            })
            .catch((e: any) => {
                errorHandler(e);
            })
            .finally(() => {
                setLoading(false);
            });

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        Api.searchAllUsers([myId])
            .then((resp) => {
                const newPeople = resp.value.map(mapUser)?.[0];
                if (newPeople) {
                    setPeopleMap({ [newPeople.id]: newPeople });
                }
            })
            .catch((e) => console.log(e));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [myId]);

    const updateUserAccess = (user, appId, zone, type, checked, revoke) => {
        const findFn = (item) => item.app == appId && item.zone == zone && item.type == type;
        if (revoke) {
            if (!checked) {
                user.exclude_access = user.exclude_access?.filter((x) => !findFn(x)) || [];
            } else {
                if (!user.exclude_access?.find(findFn)) {
                    user.exclude_access = [...(user.exclude_access || []), { app: appId, zone, type }];
                }
                user.access = user.access.filter((x) => !findFn(x));
            }
        } else {
            if (!checked) {
                user.access = user.access.filter((x) => !findFn(x));
            } else {
                if (!user.access.find(findFn)) {
                    user.access = [...user.access, { app: appId, zone, type }];
                }
                user.exclude_access = user.exclude_access?.filter((x) => !findFn(x)) || [];
            }
        }
    };

    const userRemovedEvent = (appId, zone, type, userId, checked, revoke) => {
        const newAllUserAccess: any = { ...allUserAccess };
        const user = { access: [], ...(allUserAccess[userId] || allUserAccess["new_user"]) };

        updateUserAccess(user, appId, zone, type, checked, revoke);
        newAllUserAccess[userId] = user;
        const userInfo = allUserAccess[userId].info;

        setPeopleMap({
            ...peopleMap,
            [userId]: {
                id: userId,
                givenName: userInfo.first_name,
                label: userInfo.name,
                mail: userInfo.email,
                type: userInfo.type || "user", // default to user
                emp_id: userInfo.emp_id,
                description: getDescription(userInfo),
            },
        });
        setAllUserAccess(newAllUserAccess);
    };

    const handleCheckbox = (app, zoneId, type, checked, userType, revoke) => {
        const zones = app.zones
            .filter((zone) => !zoneId || zone.name == zoneId)
            .filter((zone) => showZone(app, zone, type))
            .map((zone) => zone.name);

        const newAllUserAccess: any = { ...allUserAccess };

        users.map((p: any) => {
            const user = { access: [], ...(allUserAccess[p.id] || getDefaultAccess(userType)) };
            newAllUserAccess[p.id] = user;

            zones.map((zone) => updateUserAccess(user, app._id, zone, type, checked, revoke));
        });

        setAllUserAccess(newAllUserAccess);
    };

    const onReset = () => {
        setAllUserAccess(origUserAccess);
    };

    const getChanges = () => {
        const old: any[] = [];
        const now: any[] = [];

        Object.values(peopleMap)
            .filter((p: any) => allUserAccess[p.id])
            .map((p: any) => {
                const origUser = origUserAccess[p.id] || getDefaultAccess(p.type);
                const newUser = allUserAccess[p.id] || getDefaultAccess(p.type);

                origUser?.access?.forEach((a: any) => old.push([a.app, a.zone, a.type, p.id, 1]));
                newUser?.access?.forEach((a: any) => now.push([a.app, a.zone, a.type, p.id, 1]));

                origUser?.exclude_access?.forEach((a: any) => old.push([a.app, a.zone, a.type, p.id, 0]));
                newUser?.exclude_access?.forEach((a: any) => now.push([a.app, a.zone, a.type, p.id, 0]));
            });

        const isEqual = (a, b) => [0, 1, 2, 3, 4].every((i) => a[i] == b[i]);

        const added = now.filter((item) => !old.some((x) => isEqual(x, item))).map((x) => [...x, 1]);
        const removed = old.filter((item) => !now.some((x) => isEqual(x, item))).map((x) => [...x, 0]);

        return [...added, ...removed];
    };

    const getUserInfo = (changes) => {
        const ret_users = {};
        const ret_groups = {};
        Array.from(new Set(changes.map((change) => change[3]))).forEach((pid: any) => {
            const obj = peopleMap[pid];
            if (obj.type == "user") {
                ret_users[pid] = {
                    first_name: obj.givenName,
                    name: obj.name,
                    email: obj.mail,
                    description: obj.description,
                };
            } else {
                ret_groups[pid] = {
                    id: obj.group_id,
                    type: obj.type,
                    emp_id: obj.emp_id,
                    dept_code: obj.dept_code,
                    name: obj.name,
                };
            }
        });
        return [ret_users, ret_groups];
    };

    const onSave = () => {
        const changes = getChanges();
        const [user_info, group_info] = getUserInfo(changes);

        const user_changes: any[] = [];
        const group_changes: any[] = [];
        changes.forEach((change) => {
            if (change[3] in user_info) {
                user_changes.push(change);
            } else {
                group_changes.push(change);
            }
        });

        setMessage({ type: "info", text: "Saving...", open: true, duration: 3000 });
        errorNotification.next({ type: "info", text: "Saving...", open: true });
        Api.setAccess(user_changes, group_changes, user_info, group_info)
            .then((response) => {
                if (response?.state?.user_details) {
                    const details = { ...response.state.user_details, ...response.state.group_details };
                    setAllUserAccess(details);
                    setOrigUserAccess(details);

                    setMessage({ type: "success", text: "Saved.", open: true, duration: 3000 });
                    errorNotification.next({ type: "success", text: "Saved.", open: true });
                } else {
                    setMessage({ type: "error", text: `Save failed: ${response.message}`, open: true, duration: 3000 });
                    errorNotification.next({ type: "error", text: `Save failed: ${response.message}`, open: true });
                }
            })
            .catch((err) => {
                console.log("error while saving", err);
                setMessage({ type: "failed", text: "Error during save.", open: true, duration: 3000 });
                errorNotification.next({ type: "failed", text: "Error during save.", open: true });
            });
    };

    const handleUserPermissions = (app, zone, type) => {
        setOpenDialog(true);
        setUserAccessView({ app, zone, type });
    };
    const changes = getChanges();
    const changeTab = (e, val) => {
        setTab(val);
    };

    return (
        <AppCover
            loading={isLoading}
            header={
                <div className="d-flex flex-row-reverse bd-highlight">
                    <div className="px-2">
                        <ActionPopover changes={changes} onSave={onSave} peopleMap={peopleMap} />
                    </div>

                    <div className="px-2">
                        <Button onClick={onReset} variant="contained" disabled={!changes.length}>
                            Reset
                        </Button>
                    </div>
                </div>
            }
        >
            <div className="d-flex flex-column">
                <div className="d-flex mb-2">
                    {openDialog && (
                        <UserPermissions
                            app={userAccessView.app}
                            zoneId={userAccessView.zone}
                            typeId={userAccessView.type}
                            allUserAccess={allUserAccess}
                            openDialog={openDialog}
                            setOpenDialog={setOpenDialog}
                            userRemovedEvent={userRemovedEvent}
                            tab={tab}
                        />
                    )}
                </div>
                <div className="mb-2">
                    <nav className="nav nav-tabs">
                        <a
                            className={"nav-link pointer text-dark fw-bold " + (tab == "user" ? "active" : "")}
                            onClick={() => changeTab(null, "user")}
                        >
                            Users
                        </a>
                        <a
                            className={"nav-link pointer text-dark fw-bold " + (tab == "group" ? "active" : "")}
                            onClick={() => changeTab(null, "group")}
                        >
                            Groups
                        </a>
                    </nav>
                </div>
                <div className="d-flex">
                    <div className="d-flex flex-column mb-2" style={{ width: "30em" }}>
                        <Selectors tab={tab} peopleMap={peopleMap} setPeopleMap={setPeopleMap} />
                    </div>
                    <TableContainer style={{ maxHeight: "calc(100vh - 240px)" }}>
                        <Table aria-label="application permission table" stickyHeader>
                            <TableHead>
                                <TableRow className={classes.tableHeader}>
                                    <TableCell align="left">
                                        <SearchBox
                                            setSearchText={setSearchText}
                                            placeholder={"Search Apps..."}
                                            width={180}
                                        />
                                    </TableCell>
                                    {permissions.map((per: any) => (
                                        <TableCell className={classes.tableHeader} key={per.id} align="left">
                                            {per.title}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody style={{ maxHeight: "calc(100vh - 400px)" }}>
                                {applications && applications.length ? (
                                    applications.map((app: any) => (
                                        <Row
                                            key={app._id}
                                            tab={tab}
                                            app={app}
                                            permissions={permissions}
                                            handleCheckbox={handleCheckbox}
                                            checkBoxStatusMap={statusMap[app._id]}
                                            handleUserPermissions={handleUserPermissions}
                                        />
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell>{noDataMessage}</TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
            </div>
            <FTSnackBar snack={message} />
        </AppCover>
    );
}
