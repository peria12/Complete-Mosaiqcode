import React, { useState, useEffect } from "react";
import {
    IconButton,
    Button,
    Chip,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControl,
    Popover,
    TextField,
    Tooltip,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import { Autocomplete } from "@mui/material";

import FTSelect from "common/FTSelect";
import FTTable from "common/FTTable";
import Api from "utils/api";
import FTText from "common/FTText";
import errorNotification from "utils/api-error";

function Actions({ row, deleteAlert, editAlert }) {
    return (
        <div className="row">
            <div className="col-6 px-0">
                <Tooltip title="Edit" placement="top">
                    <IconButton aria-label="delete" onClick={() => editAlert(row)} size="large">
                        <EditIcon fontSize="small" color="primary" />
                    </IconButton>
                </Tooltip>
            </div>
            <div className="col-6 px-0">
                <Tooltip title="Remove" placement="top">
                    <IconButton aria-label="delete" onClick={() => deleteAlert(row)} size="large">
                        <DeleteIcon fontSize="small" color="secondary" />
                    </IconButton>
                </Tooltip>
            </div>
        </div>
    );
}

function FTAuto({ options, label, onChange, inputValue }) {
    return (
        <FormControl style={{ width: "100%" }}>
            <Autocomplete
                freeSolo
                inputValue={inputValue}
                onInputChange={(e: any) => e && onChange(e.target.value || e.target.textContent)}
                options={options}
                renderInput={(params) => <TextField {...params} label={label} />}
            />
        </FormControl>
    );
}

function AlertEditor({ columns, alert, setAlert, cond, types }) {
    const fieldOptions = columns.map((x) => ({ key: x.id, value: x.name }));
    const operatorOptions = ["=", "!=", "<", ">", "<=", ">="].map((x) => ({ key: x, value: x }));
    const typeOptions = Object.keys(types).map((k) => ({ key: k, value: types[k] }));

    const onChange = (row, field, val) => {
        row[field] = val;
        setAlert({ ...alert, conditions: [...alert.conditions] });
    };

    const options = [];
    if (!alert) {
        return <div className="row"> </div>;
    }

    return (
        <div className="m-4 px-2" style={{ width: "400px" }}>
            {cond && (
                <>
                    <div className="row my-3">
                        <FTSelect
                            label="Field"
                            value={cond.field}
                            options={fieldOptions}
                            onChange={(x) => onChange(cond, "field", x)}
                        />
                    </div>
                    <div className="row my-3">
                        <FTSelect
                            label="Type"
                            value={cond.type}
                            options={typeOptions}
                            onChange={(x) => onChange(cond, "type", x)}
                        />
                    </div>
                    <div className="row my-3">
                        <FTSelect
                            label="Operator"
                            value={cond.op}
                            options={operatorOptions}
                            onChange={(x) => onChange(cond, "op", x)}
                        />
                    </div>
                    <div className="row my-3">
                        <FTAuto
                            options={options}
                            label="Value"
                            inputValue={cond.value}
                            onChange={(x) => onChange(cond, "value", x)}
                        />
                    </div>
                </>
            )}
        </div>
    );
}

export function AlertDialog({ columns, handleClose, open }) {
    const [alerts, setAlerts] = useState<any>([]);
    const [origAlerts, setOrigAlerts] = useState<any>([]);
    const [alert, setAlert] = useState<any>(null);
    const [cond, setCondition] = useState<any>();
    const [ref, setRef] = useState<any>(null);

    const types = {
        value: "Value",
        change: "Change",
        change_percent: "Change %",
    };

    function alertChange(al) {
        if (alerts.find((x) => x._id == al._id)) {
            setAlerts(alerts.map((x) => (x._id == al._id ? al : x)));
        } else {
            setAlerts([...alerts, al]);
        }
        setAlert(al);
    }

    function editAlert(row) {
        setAlert(row == alert ? null : row);
        setCondition(null);
    }
    function deleteAlert(row) {
        if (row == alert) {
            setAlert(null);
            setCondition(null);
        }
        setAlerts(alerts.filter((al) => al != row));
    }

    const getActionCell = (row) => <Actions row={row} editAlert={editAlert} deleteAlert={deleteAlert} />;
    function getConditionStr(x) {
        const field = columns.find((c) => c.id == x.field)?.name || "";
        if (x.type == "value") {
            return `${field} ${x.op} ${x.value}`;
        }
        return `${types[x.type]}(${field}) ${x.op} ${x.value}`;
    }

    function selectCondition(event, cond) {
        setCondition(cond);
        handleClickPopover(event);
    }
    function handleRemove(row) {
        const newA = { ...alert, conditions: alert.conditions.filter((x) => x != row) };
        setAlert(newA);
        setAlerts([...alerts.map((x) => (x._id == alert._id ? newA : x))]);
        setCondition(null);
    }
    function handleAdd() {
        const ref = React.createRef<HTMLSpanElement>();
        const cond = { field: "", type: "value", op: "=", value: "" };
        const newA = { ...alert, conditions: [...alert.conditions, cond] };
        setRef(ref);
        setCondition(cond);
        setAlert(newA);
        setAlerts([...alerts.map((x) => (x._id == alert._id ? newA : x))]);
    }

    function getTriggerChips(al) {
        if (al == alert) {
            return (
                <>
                    {" "}
                    {al.conditions.map((c, i) => (
                        <span key={i} ref={ref}>
                            <Chip
                                label={getConditionStr(c)}
                                size="small"
                                color={c == cond ? "secondary" : "primary"}
                                className="m-1"
                                onClick={(e) => selectCondition(e, c)}
                                onDelete={() => handleRemove(c)}
                            />
                        </span>
                    ))}
                    <IconButton aria-label="add" onClick={handleAdd} size="large">
                        <AddIcon color="action" fontSize="small" />
                    </IconButton>
                </>
            );
        }

        return al.conditions.map((c, i) => <Chip label={getConditionStr(c)} key={i} size="small" className="m-1" />);
    }

    const severityOptions = ["High", "Medium", "Low"].map((x) => ({ key: x, value: x }));
    function changeName(name) {
        const newA = { ...alert, name };
        setAlert(newA);
        setAlerts([...alerts.map((x) => (x._id == alert._id ? newA : x))]);
    }

    function changeSeverity(severity) {
        const newA = { ...alert, severity };
        setAlert(newA);
        setAlerts([...alerts.map((x) => (x._id == alert._id ? newA : x))]);
    }
    const getNameCell = (row) => (alert == row ? <FTText value={alert.name} onChange={changeName} /> : row["name"]);

    function getSeverityCell(row) {
        if (alert == row) {
            return <FTSelect label="" value={alert.severity} options={severityOptions} onChange={changeSeverity} />;
        } else {
            return row["severity"];
        }
    }
    const alertColumns = [
        { label: "Name", func: getNameCell, width: "20%" },
        { label: "Trigger Conditions", func: getTriggerChips, width: "55%" },
        { label: "Severity", func: getSeverityCell, width: "15%" },
        { label: "", func: getActionCell, width: "10%" },
    ];

    function load() {
        Api.getAlertDefs().then((resp) => {
            setAlerts(JSON.parse(JSON.stringify(resp)));
            setOrigAlerts(resp);
        });
    }

    useEffect(load, []);

    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(() => {
        if (ref) {
            setAnchorEl(ref.current.children[0]);
            setRef(null);
        }
    });

    function newAlert() {
        alertChange({
            name: "",
            _id: `TEMPORARY_ID-${Math.random().toString(36).substring(10)}`,
            conditions: [],
        });
    }
    const styleFunc = (row) => (row._id == alert?._id ? { backgroundColor: "#efefef" } : {});

    const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null);
    const openPopover = Boolean(anchorEl);
    const handleClickPopover = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClosePopover = () => {
        setAnchorEl(null);
        setCondition(null);
    };

    function handleReset() {
        const alertsNew = JSON.parse(JSON.stringify(origAlerts));
        setAlerts(alertsNew);
        setAlert(alert ? alertsNew.find((al) => alert._id == al._id) : null);
        setCondition(null);
    }

    function getChanges() {
        const origMap = new Map(origAlerts.map((x) => [x._id, x]));
        const newMap = new Map(alerts.map((x) => [x._id, x]));

        const changedDefs: any[] = [];
        const newDefs: any = [];
        const deletedDefs: any = [];

        alerts.forEach((x) => {
            if (x._id.startsWith("TEMPORARY_ID-")) {
                newDefs.push(x);
            } else {
                const orig = origMap.get(x._id);
                if (JSON.stringify(x) != JSON.stringify(orig)) {
                    changedDefs.push(x);
                }
            }
        });
        origAlerts.forEach((x) => {
            if (!newMap.has(x._id)) {
                deletedDefs.push(x);
            }
        });

        return [changedDefs, newDefs, deletedDefs];
    }

    function handleSave() {
        const [changedDefs, newDefs, deletedDefs] = getChanges();

        const updates = changedDefs.map((x) => Api.updateAlertDef(x._id, x));
        const creates = newDefs.map((x) => Api.createAlertDef({ ...x, _id: undefined }));
        const deletes = deletedDefs.map((x) => Api.deleteAlertDef(x._id));

        Promise.all([...updates, ...creates, ...deletes])
            .then(() => {
                errorNotification.next({ type: "success", text: "Success. Alerts updated.", open: true });
                load();
            })
            .catch((err) => {
                console.log("Calls failed", err);
                errorNotification.next({ type: "error", text: "Error. Failed to update alerts.", open: true });
            });
    }

    function hasChanges() {
        const [changedDefs, newDefs, deletedDefs] = getChanges();
        return changedDefs.length || newDefs.length || deletedDefs.length;
    }

    return (
        <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={open} maxWidth="xl">
            <DialogTitle id="customized-dialog-title">Alert Definitions</DialogTitle>
            <DialogContent dividers style={{ width: "1300px" }}>
                <div className="d-flex flex-row-reverse mb-2">
                    <Button variant="contained" onClick={newAlert} color="primary">
                        New Alert Definition
                    </Button>
                </div>
                <FTTable columns={alertColumns} rows={alerts} rowStyle={styleFunc}></FTTable>
                <Popover
                    open={openPopover}
                    anchorEl={anchorEl}
                    onClose={handleClosePopover}
                    anchorOrigin={{
                        vertical: "bottom",
                        horizontal: "left",
                    }}
                    transformOrigin={{
                        vertical: "top",
                        horizontal: "left",
                    }}
                >
                    <AlertEditor columns={columns} cond={cond} alert={alert} setAlert={alertChange} types={types} />
                </Popover>
            </DialogContent>
            <DialogActions>
                <Button variant="contained" onClick={handleClose} color="secondary">
                    Cancel
                </Button>
                <Button variant="contained" onClick={handleReset} color="secondary" disabled={!hasChanges()}>
                    Reset
                </Button>
                <Button variant="contained" autoFocus onClick={handleSave} color="primary" disabled={!hasChanges()}>
                    Save changes
                </Button>
            </DialogActions>
        </Dialog>
    );
}
