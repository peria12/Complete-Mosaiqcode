import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Checkbox, FormControlLabel } from "@mui/material";
import { Controller } from "react-hook-form";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";

const useStyles = makeStyles((theme: any) =>
    createStyles({
        btn: {
            textTransform: "capitalize",
            marginLeft: 8,
            margin: 2,
        },
        checkBox: {
            marginRight: "auto",
        },
        row: {
            display: "flex",
            width: "100%",
            borderBottom: "1px solid rgba(224, 224, 224, 1)",
        },
        root: {
            width: "100%",
        },
        paper: {
            width: "100%",
            marginBottom: theme.spacing(2),
        },
        table: {
            minWidth: 750,
        },
    })
);

function EnhancedTable({ rows, field, setValue }) {
    const classes = useStyles();
    const [selected, setSelected] = React.useState<any>({});
    const { name, levels } = field;

    const columns = [{ key: "app", value: "All" }, ...levels];

    React.useEffect(() => {
        const _selected = {};
        columns.forEach((ele) => {
            _selected[ele?.key] = [];
        });
        setSelected(_selected);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    React.useEffect(() => {
        const id = "app";
        const newValues: any = [];
        if (selected?.[id]) {
            selected[id]?.forEach((ele) => {
                const entry = { [id]: ele };
                levels.forEach((lvl) => {
                    entry[lvl?.key] = selected?.[lvl?.key].includes(ele);
                });
                newValues.push(entry);
            });
            setValue(name, newValues);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selected]);

    const handleSelectAllClick = (event: any, key) => {
        if (event.target.checked) {
            const newSelected = rows.map((n) => n.key);
            setSelected({ ...selected, [key]: newSelected });
            return;
        }
        setSelected({ ...selected, [key]: [] });
    };

    const handleClick = (column: string, value: any) => {
        const selectedItems = selected?.[column];
        const selectedIndex = selectedItems.indexOf(value);
        let newSelected: string[] = [];
        if (selectedIndex === -1) {
            newSelected = [...selectedItems, value];
        } else if (selectedIndex === 0) {
            newSelected = [selectedItems.slice(1)];
        } else if (selectedIndex === selectedItems.length - 1) {
            newSelected = [...selectedItems.slice(0, -1)];
        } else if (selectedIndex > 0) {
            newSelected = [...selectedItems.slice(0, selectedIndex), ...selectedItems.slice(selectedIndex + 1)];
        }
        setSelected({ ...selected, [column]: newSelected });
    };

    function getStripedStyle(index: number): any {
        return { background: index % 2 ? "#fafafa" : "white" };
    }

    const isSelected = (col: string, key: string) => selected[col]?.indexOf(key) !== -1;

    return (
        <TableContainer>
            <Table className={classes.table}>
                <EnhancedTableHead
                    classes={classes}
                    selected={selected}
                    onSelectAllClick={(e, key) => handleSelectAllClick(e, key)}
                    rowCount={rows.length}
                    columns={columns}
                />
                <TableBody>
                    {rows?.map((row, index) => {
                        const labelId = `enhanced-table-checkbox-${index}`;
                        return (
                            <TableRow
                                hover
                                role="checkbox"
                                tabIndex={-1}
                                key={row.key}
                                style={{ ...getStripedStyle(index + 1) }}
                            >
                                {columns.map((col: any) => {
                                    const isItemSelected = isSelected(col.key, row.key);
                                    return (
                                        <TableCell
                                            key={col.key}
                                            padding="checkbox"
                                            component="th"
                                            id={labelId}
                                            scope="row"
                                            style={{ padding: "0 16px" }}
                                        >
                                            <FormControlLabel
                                                style={{ minWidth: "40px" }}
                                                label={row[col.key] || ""}
                                                value={false}
                                                control={
                                                    <Checkbox
                                                        color="primary"
                                                        onClick={() => handleClick(col?.key, row?.key)}
                                                        checked={isItemSelected}
                                                    />
                                                }
                                            />
                                        </TableCell>
                                    );
                                })}
                            </TableRow>
                        );
                    })}
                </TableBody>
            </Table>
        </TableContainer>
    );
}

function EnhancedTableHead(props: any) {
    const { columns, onSelectAllClick, selected, rowCount } = props;
    return (
        <TableHead>
            <TableRow>
                {columns?.map((col) => {
                    const numSelected = selected[col.key]?.length;
                    return (
                        <TableCell
                            padding="checkbox"
                            key={col.id}
                            align={col.numeric ? "right" : "left"}
                            style={{ padding: "0 16px" }}
                        >
                            <FormControlLabel
                                value={col.key}
                                label={col.value}
                                control={
                                    <Checkbox
                                        color="primary"
                                        indeterminate={numSelected > 0 && numSelected < rowCount}
                                        checked={rowCount > 0 && numSelected === rowCount}
                                        onChange={(e) => onSelectAllClick(e, col.key)}
                                    />
                                }
                            />
                        </TableCell>
                    );
                })}
            </TableRow>
        </TableHead>
    );
}

export default function CheckboxGrid({ field, methods, options }) {
    const { control, setValue } = methods;
    const { name, levels } = field;
    const levelProps = {};
    levels.forEach((ele) => {
        levelProps[ele?.key] = false;
    });
    const rows = options.map((opt: any) => ({ app: opt.value, key: opt.key, ...levelProps }));

    return (
        <Controller
            name={name}
            control={control}
            render={() => <EnhancedTable rows={rows} setValue={setValue} field={field} />}
        />
    );
}
