import { HChart } from "common/HChart";
import React from "react";
import { RBAContext } from "utils/context";
import { unique } from "utils/helpers";
import { Cover } from "./Cover";
import { toRecords } from "./utils";

export default function FactorResponse() {
    const { pairs, pairIndex, getEntityName } = React.useContext(RBAContext);

    if (!pairs?.length) return <></>;

    const sortFn = (a, b) => a.quintile - b.quintile;
    const recs = toRecords(pairs[pairIndex]?.factor_response_rel_quintiles).sort(sortFn);

    const getKey = (r) => `${r.id_type}:${r.id_value}:${r.bench_id_type}:${r.bench_id_value}`;
    const ids = unique(recs.map(getKey));

    const format = (x) => x * 100;

    const getName = (id) => {
        const rec = recs.find(x => getKey(x) == id)
        if (!rec) return 'N/A'

        const factorName = getEntityName(rec.id_type, rec.id_value)
        const factorBenchName = getEntityName(rec.bench_id_type, rec.bench_id_value)
        return `${factorName} - ${factorBenchName}`
    }

    const getChart = (id, name) => {
        const records = recs.filter((x) => getKey(x) == id);
        return {
            title: {
                text: "",
                align: "center",
            },
            xAxis: {
                crosshair: true,
                categories: ["Worst 20%", "2nd", "3rd", "4th", "Best 20%"],
            },
            yAxis: [
                {
                    title: {
                        text: "",
                    },
                    labels: {
                        format: "{text} %",
                    },
                },
            ],
            plotOptions: {
                line: {
                    dataLabels: {
                        enabled: true,
                    },
                },
            },
            tooltip: {
                valueDecimals: 2,
                valueSuffix: "%",
                shared: true,
            },
            series: [
                {
                    name,
                    type: "column",
                    data: records.map((r) => format(r.rel_factor_perf)),
                    color: "#FA9375",
                    marker: { enabled: false },
                },
                {
                    name: "Fund - Benchmark",
                    type: "line",
                    dataLabels: { format: "{point.y:.2f}" },
                    data: records.map((r) => format(r.rel_fund_perf)),
                    marker: { enabled: false },
                },
            ],
        };
    };

    return (
        <div className="d-flex flex-column rounded">
            <div className="row me-2">
                {ids.map((id: any, i) => {
                    const name = getName(id)
                    return <div key={i} className="col-12 col-md-6 col-lg-6 col-xl-4 col-xxl-3">
                        <Cover title={name}>
                            <HChart option={getChart(id, name)} />
                        </Cover>
                    </div>
                })}
            </div>
        </div>
    );
}
