import React from "react";
import { HChart } from "common/HChart";
import { RBAContext } from "utils/context";
import { Cover } from "./Cover";

export function ExcessReturnDistributions() {
    const { pairs, getFundBenchNames } = React.useContext(RBAContext);

    if (!pairs.length) return <></>;

    const getTitle = (pair) => {
        const [fundName, benchName] = getFundBenchNames(pair);
        return `${fundName} vs ${benchName}`;
    };

    const getChart = (pair, title) => {
        const dist = pair?.distribution;

        return {
            title: {
                text: "Excess Return Distribution",
                align: "center",
            },
            subtitle: {
                text: `Kurtosis: ${dist?.kurtosis?.toFixed(2)}, Skew: ${dist?.skew?.toFixed(2)}`,
            },
            xAxis: {
                crosshair: true,
                labels: {
                    format: "{text} %",
                },
            },
            yAxis: [
                {
                    // Primary yAxis
                    title: {
                        text: "",
                    },
                    tickAmount: 8,
                },
                {
                    title: { text: "" },
                    opposite: true,
                    tickAmount: 8,
                },
            ],
            tooltip: {
                valueDecimals: 2,
                headerFormat: "{point.key:.2f} % <br>",
                shared: true,
            },
            series: [
                {
                    name: title,
                    type: "column",
                    yAxis: 0,
                    pointWidth: 15,
                    data: dist?.bins.map(([x, y]) => [x * 100, y]) || [],
                    color: "#FA9375",
                    tooltip: {
                        valueSuffix: "%",
                    },
                },
                {
                    name: "Normalized Distribution",
                    type: "line",
                    yAxis: 1,
                    dashStyle: "dash",
                    color: "#57DFD4",
                    marker: {
                        enabled: false,
                    },
                    data: dist?.bell_curve.map(([x, y]) => [x * 100, y]) || [],
                },
            ],
        };
    };

    return (
        <>
            <div className="row me-2">
                {pairs
                    .filter((x) => x)
                    .map((p, i) => {
                        const title = getTitle(p);
                        return (
                            <div key={i} className="col-12 col-md-6 col-lg-6 col-xl-4 col-xxl-3">
                                <Cover title={title}>
                                    <HChart option={getChart(p, title)} />
                                </Cover>
                            </div>
                        );
                    })}
            </div>
        </>
    );
}
