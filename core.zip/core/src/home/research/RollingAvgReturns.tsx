import React from "react";
import { toRecords } from "./utils";
import { FTGrid } from "./components/FTGrid";
import { RBAContext } from "utils/context";

export default function RollingAvgReturn() {
    const { pairs, getFundBenchNames } = React.useContext(RBAContext);

    if (!pairs.length) return <></>;

    const headerClass = "ft-grid-th-div-span";
    const headerClassC = "ft-grid-th-div-span text-center";
    const headerClassB = "ft-grid-th-div-span ft-border-right";
    const cellClass = (val) => (val < 0 ? "ft-grid-td red-value" : "ft-grid-td");
    const cellClassB = (val) => (val < 0 ? "ft-grid-td ft-border-right red-value" : "ft-grid-td ft-border-right");
    const cellClass2B = () => "ft-grid-td-div-span ft-border-right";
    const width = 65;
    const pct = true;

    const fund_bm_cols = [
        [
            { headerName: "", field: "", colSpan: 2, headerClass, cellClass },
            { headerName: "Rolling 3 Month", field: "", colSpan: 4, headerClass: headerClassC, cellClass },
            { headerName: "Rolling 6 Month", field: "", colSpan: 4, headerClass: headerClassC, cellClass },
            { headerName: "Rolling 12 Month", field: "", colSpan: 4, headerClass: headerClassC, cellClass },
        ],
        [
            { headerName: "Fund", field: "fund", maxWidth: 350, headerClass: headerClassB, cellClass: cellClass2B },
            {
                headerName: "Benchmark",
                field: "benchmark",
                maxWidth: 350,
                headerClass: headerClassB,
                cellClass: cellClass2B,
            },
            { headerName: "Avg Perf", field: "avg_perf_3m", width, headerClass, cellClass, pct },
            { headerName: "Hit Rate", field: "hit_rate_3m", width, headerClass, cellClass, pct },
            { headerName: "Avg Out", field: "avg_out_perf_3m", width, headerClass, cellClass, pct },
            {
                headerName: "Avg Und",
                field: "avg_under_perf_3m",
                width,
                headerClass: headerClassB,
                cellClass: cellClassB,
                pct,
            },
            { headerName: "Avg Perf", field: "avg_perf_6m", width, headerClass, cellClass, pct },
            { headerName: "Hit Rate", field: "hit_rate_6m", width, headerClass, cellClass, pct },
            { headerName: "Avg Out", field: "avg_out_perf_6m", width, headerClass, cellClass, pct },
            {
                headerName: "Avg Und",
                field: "avg_under_perf_6m",
                width,
                headerClass: headerClassB,
                cellClass: cellClassB,
                pct,
            },
            { headerName: "Avg Perf", field: "avg_perf_12m", width, headerClass, cellClass, pct },
            { headerName: "Hit Rate", field: "hit_rate_12m", width, headerClass, cellClass, pct },
            { headerName: "Avg Out", field: "avg_out_perf_12m", width, headerClass, cellClass, pct },
            { headerName: "Avg Und", field: "avg_under_perf_12m", width, headerClass, cellClass, pct },
        ],
    ];

    const getRowsForFundBench = (months) => {
        return pairs
            .filter((x) => x)
            .map((p) => {
                const [fundName, benchName] = getFundBenchNames(p);
                const recs = toRecords(p?.rolling_stats)?.filter((x) => x.months == months) || [];
                const rec_3m = recs.find((x) => x.window == 3);
                const rec_6m = recs.find((x) => x.window == 6);
                const rec_12m = recs.find((x) => x.window == 12);
                return {
                    fund: fundName,
                    benchmark: benchName,
                    avg_perf_3m: rec_3m?.avg_perf,
                    hit_rate_3m: rec_3m?.hit_rate,
                    avg_out_perf_3m: rec_3m?.avg_out_perf,
                    avg_under_perf_3m: rec_3m?.avg_under_perf,
                    avg_perf_6m: rec_6m?.avg_perf,
                    hit_rate_6m: rec_6m?.hit_rate,
                    avg_out_perf_6m: rec_6m?.avg_out_perf,
                    avg_under_perf_6m: rec_6m?.avg_under_perf,
                    avg_perf_12m: rec_12m?.avg_perf,
                    hit_rate_12m: rec_12m?.hit_rate,
                    avg_out_perf_12m: rec_12m?.avg_out_perf,
                    avg_under_perf_12m: rec_12m?.avg_under_perf,
                };
            });
    };

    return (
        <div className="d-flex">
            <div className="rounded border p-1">
                <div className="ft-card-header">Rolling Average Returns (Performance - Relative)</div>
                <div className="d-flex flex-column">
                    <div className="d-flex mb-3 flex-column">
                        <div className="text-center fw-bold">3Y</div>
                        <FTGrid columnDefs={fund_bm_cols} rowData={getRowsForFundBench(36)}></FTGrid>
                    </div>
                    <div className="d-flex mb-3 flex-column">
                        <div className="text-center fw-bold">5Y</div>
                        <FTGrid columnDefs={fund_bm_cols} rowData={getRowsForFundBench(60)}></FTGrid>
                    </div>

                    <div className="d-flex flex-column">
                        <div className="text-center fw-bold">7Y</div>
                        <FTGrid columnDefs={fund_bm_cols} rowData={getRowsForFundBench(84)}></FTGrid>
                    </div>
                </div>
            </div>
        </div>
    );
}
