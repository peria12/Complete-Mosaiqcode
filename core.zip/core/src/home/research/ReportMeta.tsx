import React from "react";
import { toRecords } from "./utils";
import FTTable from "common/FTTable";
import { RBAContext } from "utils/context";
import { unique } from "utils/helpers";
import { Cover } from "./Cover";
import { HChart } from "common/HChart";

const columns = [
    { key: "id_type", label: "Id Type" },
    { key: "id_value", label: "Id Value" },
    { key: "date", label: "Date" },
    { key: "data_available", label: "Data Available", type: "numeric" },
    { key: "message", label: "Message" },
];

function transformData(rows: any) {
    return rows?.map((r) => {
        const value = r?.data_available || "";
        if (value) {
            r["data_available"] = value == "NaN" ? "" : parseFloat(value) * 100;
        }
        return r;
    });
}

export default function ReportMeta() {
    const { data, getEntityName } = React.useContext(RBAContext);

    if (!data) return <></>;
    const rows = transformData(toRecords(data?.data_checks) || []);
    const returns = toRecords(data?.returns)?.map((x) => ({ ...x, date: new Date(x.date).getTime() }));
    const getKey = (r) => `${r.id_type}:${r.id_value}`;
    const ids = unique(returns.map(getKey));
    const getChart = (id) => {
        const factorName = getEntityName(...id.split(":"));
        const records = returns.filter((x) => getKey(x) == id);
        return {
            title: { text: "", align: "center" },
            xAxis: { type: "datetime" },
            yAxis: [
                {
                    title: { text: "" },
                    labels: { format: "{text:.2f} %" },
                },
                {
                    title: { text: "" },
                    opposite: true,
                },
            ],
            plotOptions: {
                series: {
                    pointIntervalUnit: "month",
                },
            },
            tooltip: {
                pointFormat: "Return: {point.y:.2f} %",
            },
            series: [
                {
                    name: factorName,
                    dataLabels: { format: "{point.y:.2f}%" },
                    yAxis: 0,
                    data: records?.map((ele) => [ele.date, ele?.cum_return * 100]),
                },
                {
                    name: "Data Available",
                    data: records?.map((ele) => {
                        const config: any = {
                            x: ele.date,
                            y: ele.cum_return * 100,
                            marker: { enabled: false },
                        };
                        if (!ele?.data_available) {
                            config["marker"] = {
                                fillColor: "red",
                                states: {
                                    hover: { fillColor: "red", lineColor: "red" },
                                },
                            };
                        }
                        return config;
                    }),
                    lineWidth: 0,
                    marker: {
                        enabled: true,
                        radius: 2,
                        symbol: "circle",
                    },
                    tooltip: {
                        valueDecimals: 2,
                    },
                    states: {
                        hover: { lineWidthPlus: 0 },
                    },
                },
            ],
        };
    };

    return (
        <>
            <div className="d-flex flex-column pb-1">
                {/* <div className="text-center fw-bold">Data Checks</div> */}
                {/* <div className="d-flex flex-row mb-3">
                <div className="me-1 flex-fill">
                    <FTTable columns={columns} rows={rows}></FTTable>
                </div>
            </div> */}
                <div className="row" style={{ width: "100%" }}>
                    <div className="text-center fw-bold">Returns</div>
                    {ids.map((id, i) => (
                        <div key={i} className="col-12 col-md-6 col-lg-6 col-xl-4 col-xxl-3">
                            <Cover>
                                <HChart option={getChart(id)} />
                            </Cover>
                        </div>
                    ))}
                    {rows?.length > 0 && (
                        <div className="col-12 col-md-6 col-lg-6 col-xl-4 col-xxl-6">
                            <FTTable columns={columns} rows={[...rows]}></FTTable>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}
