export const toRecords = (data) => {
    return (
        data?.records.map((r) => {
            const x = {};
            data.columns.forEach((c, i) => {
                x[c] = r[i];
            });
            return x;
        }) || []
    );
};

export const format = (x, pct = false) => {
    return x == null || x == undefined
        ? ""
        : pct
        ? `${(x * 100).toFixed(2)}%`
        : typeof x == "number"
        ? `${x.toFixed(2)} `
        : x;
};

export const rowsForAbsPerf = (pair, getFundBenchNames) => {
    const [fundName] = getFundBenchNames(pair);
    const recs = toRecords(pair?.point_in_time_perf);
    const yearRecs = toRecords(pair?.yearly_perf);

    const getRet = (months) => {
        return recs?.find((x) => x.months == months)?.return;
    };

    const data = {
        fundName,
        "1M": getRet(1),
        "3M": getRet(3),
        "6M": getRet(6),
        "1Y": getRet(12),
        "3Y": getRet(36),
        "5Y": getRet(60),
        "7Y": getRet(84),
        "10Y": getRet(120), //TODO
    };
    yearRecs?.forEach((y) => (data[y.year] = y.return));

    return data;
};

export const rowsForRelPerf = (pair, getFundBenchNames) => {
    const [fundName, benchName] = getFundBenchNames(pair);
    const recs = toRecords(pair?.point_in_time_perf);
    const yearRecs = toRecords(pair?.yearly_perf);

    const getRet = (months) => {
        return recs?.find((x) => x.months == months)?.rel_return;
    };

    const data = {
        fundName,
        benchName,
        "1M": getRet(1),
        "3M": getRet(3),
        "6M": getRet(6),
        "1Y": getRet(12),
        "3Y": getRet(36),
        "5Y": getRet(60),
        "7Y": getRet(84),
        "10Y": getRet(120), //TODO
    };
    yearRecs?.forEach((y) => (data[y.year] = y.rel_return));

    return data;
};

export const getMaxAbsPerf = (pair) => {
    const recs = toRecords(pair?.point_in_time_perf);
    const maxMonth = Math.max(...recs.map((r) => r.months));
    return recs.find((x) => x.months == maxMonth) || {};
};

export const getYears = (pairs) => {
    const map = {};
    pairs
        .flatMap((p) => toRecords(p?.yearly_perf).filter((x) => x))
        .forEach((y) => {
            map[y.year] = y;
        });
    return Object.values(map).sort((a: any, b: any) => b?.year - a?.year);
};

export const color = (val) => (val < 0 ? "red-value" : "");
