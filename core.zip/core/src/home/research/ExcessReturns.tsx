import React from "react";
import { toRecords } from "./utils";
import { HChart } from "common/HChart";
import { RBAContext } from "utils/context";
import { Cover } from "./Cover";

export function ExcessReturns() {
    const { pairs, getFundBenchNames } = React.useContext(RBAContext);

    if (!pairs.length) return <></>;

    const getTitle = (pair) => {
        const [fundName, benchName] = getFundBenchNames(pair);
        return `${fundName} vs ${benchName}`;
    };

    const getChart = (pair, title) => {
        const data = {
            title: {
                text: "Rolling 12M Excess Returns vs BM",
                align: "center",
            },
            subtitle: {
                align: "center",
            },
            xAxis: {
                type: "datetime",
            },
            yAxis: [
                {
                    title: {
                        text: "Return",
                    },
                    labels: {
                        format: "{text} %",
                    },
                    tickAmount: 8,
                },
            ],
            tooltip: {
                valueDecimals: 2,
                valueSuffix: "%",
                shared: true,
            },
            series: [
                {
                    name: title,
                    type: "line",
                    color: "#57DFD4",
                    data:
                        toRecords(pair?.rel_returns_rolling)?.filter(x => x.rel_returns_12m != null).map((x) => [
                            new Date(x.date).getTime(),
                            x.rel_returns_12m * 100,
                        ]) || [],
                },
            ],
        };
        return data;
    };

    return (
        <>
            <div className="row me-2">
                {pairs
                    .filter((x) => x)
                    .map((p, i) => {
                        const title = getTitle(p);
                        return (
                            <div key={i} className="col-12 col-md-6 col-lg-6 col-xl-4 col-xxl-3">
                                <Cover title={title}>
                                    <HChart option={getChart(p, title)} />
                                </Cover>
                            </div>
                        );
                    })}
            </div>
        </>
    );
}
