import React from "react";

export function Cover({ children, title = "", width = "", cls = "" }) {
    return (
        <div className={`rounded bg-white border mb-2 me-2 p-1 ${cls}`} style={{ width: width }}>
            {title && title.length ? <div className="mb-2 ft-card-header">{title}</div> : <></>}
            {children}
        </div>
    );
}
