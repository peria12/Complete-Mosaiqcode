import React, { useState, useEffect, useRef } from "react";
import Button from "@mui/material/Button";
import CircularProgress from "@mui/material/CircularProgress";
import AppCover from "home/dashboad/AppCover";
import PortfolioAnalysisDashBoard from "./dashboard/PortfolioAnalysisDashBoard";
import RollingAvgReturn from "./RollingAvgReturns";
import { Link, useLocation, Route, Redirect } from "react-router-dom";

import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { AdornedButton } from "common/FTButtons";

import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import ModelReturnRisk from "./ModelReturnRisk";
import Settings from "utils/settings";
import Api from "utils/api";
import { FundRiskReturn } from "./FundRiskReturn";
import { ExcessReturns } from "./ExcessReturns";
import { AB } from "./AB";
import { ExcessReturnDistributions } from "./ExcessReturnDistributions";
import FactorResponse from "./FactorResponse";
import FactorResponseRel from "./FactorResponseRel";
import ReportMeta from "./ReportMeta";
import moment from "moment";
import errorNotification from "utils/api-error";
import { RBAContext } from "utils/context";
import { toRecords } from "./utils";
import { FundAnalyzer } from "./FundAnalyzer";
import { useScreenshot } from "utils/helpers";
import { PairSelector } from "./components/PairSelector";

const BootstrapDialogTitle = (props: any) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: "absolute",
                        right: 6,
                        top: 6,
                        color: (theme) => theme?.palette?.grey?.[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const transformEnteries = (obj, models) => {
    const model = models.find((m) => m.id == obj.model_id);

    return model?.entries
        ?.filter((ele: any) => ele?.entry)
        .map((e: any) => {
            if (e?.entry) {
                const obj = { weight: Number(e.value) }; //
                if (e?.entry?.type) {
                    obj["_meta"] = { return_type: e?.entry?.type };
                }
                if (e?.entry?.mstar_id) {
                    obj["mstar_id"] = e?.entry?.mstar_id;
                } else if (e?.entry?.fs_bm_id) {
                    obj["fs_bm_id"] = e?.entry?.fs_bm_id;
                }
                return obj;
            }
        });
};

const getEntities = (ele: any, key: string, models) => {
    const obj = ele?.[key];
    const label = obj?.label;
    const model_id = obj?.model_id;
    const entityInfo = {};
    if (obj?.type) {
        entityInfo["_meta"] = { return_type: obj?.type };
    }
    if (model_id != null && model_id != undefined) {
        return {
            _custom_: {
                [label]: transformEnteries(obj, models),
            },
        };
    } else if (obj?.mstar_id) {
        return { ...entityInfo, mstar_id: obj?.mstar_id };
    } else if (obj?.fs_bm_id) {
        return { ...entityInfo, fs_bm_id: obj?.fs_bm_id };
    }
};

const getPayload = (group, formData, dates, models) => ({
    dates: [dates.fromDate, moment(dates.toDate).format("YYYY-MM-DD")], // use last day of month
    date_info: { type: "series", freq: { unit: "monthly" } },
    fields: [
        {
            return_based_analytics: {
                currency: formData.currency,
                benchmark_entities: group?.funds?.map((ele: any) => getEntities(ele, "benchmark", models)),
                factor_entities: group?.factors?.map((ele: any) => getEntities(ele, "factFund", models)) || [],
                benchmark_factor_entities:
                    group?.factors?.map((ele: any) => getEntities(ele, "factBenchmark", models)).filter((e) => e) || [],
                beta_profile_entities: formData?.betaProfile?.map((ele) => {
                    const obj = { fs_bm_id: ele.id };
                    if (ele?.type) {
                        obj["_meta"] = { return_type: ele?.type };
                    }
                    return obj;
                }),
                return_window: { unit: "monthly" },
            },
        },
    ],
    entities: group?.funds?.map((ele: any) => getEntities(ele, "fund", models)),
});

const defaultFundProps = { id: "", label: "", entries: [] };
const defaultGroupProps = { funds: [], factors: null };
const defaultForm = {
    currency: "USD",
    fund: { ...defaultFundProps },
    benchmark: { ...defaultFundProps },
    factFund: { ...defaultFundProps },
    factBenchmark: { ...defaultFundProps },
    betaProfile: null,
};

function DashboardDialog({ openDialog, setOpenDialog, setData, dates, setDates }) {
    const app = "research-tool";
    const zone = "portfolio_analysis";
    const settings = Settings.getSettings();
    const prevAnalysis = settings?.app_settings?.["research-tool"]?.portfolio_analysis?.dashboard || {};
    const [isInitialLoading, setIsInitialLoading] = useState(true);
    const [dashboardMeta, setDashboardMeta] = useState<any>({});
    const [group, setGroup] = useState<any>(defaultGroupProps);
    const [formData, setFormData] = useState<any>({ ...defaultForm, ...dates });
    const [currencyList, setCurrencyList] = useState<string[]>(["USD"]);

    const lastEntry = { entry: null, value: 0, edit: true, last: true };
    const lastModel = { key: "Model 1", last: true, edit: true, entries: [lastEntry] };
    const [models, setModels] = useState<any[]>([{ ...lastModel, id: 0 }]);

    const [isLoading, setLoading] = useState(false);
    const [dashboardConfig, setDashboardConfig] = useState<any>({});

    const [analysis, setAnalysis] = useState<any>([]);
    const [selectedAnalysis, setSelectedAnalysis] = useState<any>({});
    const dataChanged = useRef<boolean>(false);

    useEffect(() => {
        dataChanged.current = true;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [group, formData, models]);

    useEffect(() => {
        (async () => {
            const [zone_settings, analysis] = await Promise.all([
                Api.getZoneSettings("research-tool", "portfolio_analysis"),
                Api.getSharedState(app, zone),
            ]);
            const dashboard_config = zone_settings?.dashboard_config;
            if (!dashboard_config) {
                const errorInfo = {
                    type: "error",
                    text: `Unable to fetch Portfolio Analysis settings`,
                    open: true,
                };
                errorNotification.next(errorInfo);
                return;
            }
            setDashboardConfig(dashboard_config);

            setAnalysis(analysis);
            const defaultAnalysis =
                (prevAnalysis?.id && analysis?.find((analysis) => prevAnalysis?.id === analysis._id?.$oid)) || {};
            setSelectedAnalysis(defaultAnalysis);
            const dashboardMeta: any = defaultAnalysis?.payload || {};
            setDashboardMeta(dashboardMeta);
            setModels(dashboardMeta?.models || [{ ...lastModel, id: 0 }]);
            if (!dashboardMeta?.formData?.betaProfile?.length) {
                setFormData({ ...dashboardMeta?.formData, betaProfile: dashboard_config?.betaProfile });
            } else {
                setFormData({ ...dashboardMeta?.formData });
            }
            if (dashboard_config.currencyList) {
                setCurrencyList(dashboard_config.currencyList);
            }
            if (!dashboardMeta?.group?.factors?.length && dashboard_config?.factors) {
                setGroup({ ...dashboardMeta?.group, factors: dashboard_config?.factors });
            } else {
                setGroup(dashboardMeta?.group);
            }
            setIsInitialLoading(false);
        })();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const dashboardMeta: any = selectedAnalysis?.payload || {};
        setDashboardMeta(dashboardMeta);
        if (!dashboardMeta?.formData?.betaProfile?.length) {
            setFormData({ ...dashboardMeta?.formData, betaProfile: dashboardConfig?.betaProfile });
        } else {
            setFormData({ ...dashboardMeta?.formData });
        }
        if (!dashboardMeta?.group?.factors?.length && dashboardConfig?.factors) {
            setGroup({ ...dashboardMeta?.group, factors: dashboardConfig?.factors });
        } else {
            setGroup(dashboardMeta?.group);
        }
        setModels(dashboardMeta?.models || [{ ...lastModel, id: 0 }]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedAnalysis, dashboardConfig?.betaProfile, dashboardConfig?.factors]);

    const resetFactors = () => {
        if (dashboardConfig?.factors) {
            setGroup({ ...group, factors: dashboardConfig?.factors });
        }
    };

    const resetBetaProfiles = () => {
        if (dashboardConfig.betaProfile) {
            setFormData({ ...formData, betaProfile: dashboardConfig?.betaProfile });
        }
    };

    const clearPage = () => {
        if (dashboardConfig?.factors) {
            setGroup({ ...group, factors: dashboardConfig?.factors, funds: [] });
        }
        if (dashboardConfig.betaProfile) {
            setFormData({ ...formData, betaProfile: dashboardConfig?.betaProfile });
        }

        setSelectedAnalysis({ _id: { $oid: "_default_" } });
        Settings.updateSettings("research-tool", "portfolio_analysis", "dashboard", { id: "" });
    };

    function runAnalytics(group, formData, dates) {
        const diff = moment(dates.toDate)?.diff(moment(dates.fromDate), "years");
        if (diff < 2) {
            const errorInfo = {
                type: "error",
                text: `Minimum difference between start date and end date should be 2 years.`,
                open: true,
            };
            errorNotification.next(errorInfo);
            return;
        }
        const payload = getPayload(group, formData, dates, models);
        setLoading(true);
        Api.dal(payload, false)
            .then((response) => {
                if (response?.error) {
                    const errorInfo = {
                        type: "error",
                        text: `${response?.error}`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                }
                const data = response?.fields?.return_based_analytics;
                if (data) {
                    setData(data);
                    setOpenDialog(false);
                }
                setLoading(false);
            })
            .catch((err) => {
                const errorInfo = {
                    type: "error",
                    text: `Unable to perform analysis. Error: ${err}`,
                    open: true,
                };
                errorNotification.next(errorInfo);

                setLoading(false);
            });
    }

    const analyzeDisabled = () => {
        return !group?.funds?.length;
    };

    function updateAnalysis(key, newAnalysis: any = {}) {
        const allAnalysis = analysis;
        const updatedAnalysis = {
            ...newAnalysis,
            payload: {
                group,
                formData,
                models,
            },
        };
        let analysisList: any = [];
        if (key == "update") {
            const index = allAnalysis.findIndex((v) => v._id.$oid == selectedAnalysis._id.$oid);
            if (index == -1) {
                return;
            }
            Api.updateSharedState(selectedAnalysis._id.$oid, updatedAnalysis).then((res) => {
                if (res.message) {
                    errorNotification.next({ type: "success", text: res.message, open: true });
                }
                updatedAnalysis._id = {
                    $oid: selectedAnalysis._id.$oid,
                };
                allAnalysis[index] = updatedAnalysis;
                analysisList = [...allAnalysis];
                setSelectedAnalysis(updatedAnalysis);
                setAnalysis(analysisList);
            });
        } else if (key == "create") {
            Api.createSharedState(app, zone, {
                ...updatedAnalysis,
            }).then((res) => {
                if (res.message) {
                    errorNotification.next({ type: "success", text: res.message, open: true });
                }
                updatedAnalysis._id = {
                    $oid: res._id,
                };
                analysisList = [...allAnalysis, updatedAnalysis];
                setSelectedAnalysis(updatedAnalysis);
                setAnalysis(analysisList);
            });
        } else if (key == "delete") {
            Api.deleteSharedState(selectedAnalysis._id.$oid).then((res) => {
                if (res.message) {
                    errorNotification.next({ type: "success", text: res.message, open: true });
                }
                const newList = allAnalysis.filter((v) => v._id.$oid != selectedAnalysis._id.$oid);
                analysisList = [...newList];
                setSelectedAnalysis(analysisList[0]);
                setAnalysis(analysisList);
            });
        }
    }

    function selectAnalysis(analysisId) {
        setSelectedAnalysis(analysis.find((elem) => elem._id.$oid === analysisId));
        Settings.updateSettings("research-tool", "portfolio_analysis", "dashboard", {
            id: analysisId,
        });
    }

    return (
        <Dialog open={openDialog} onClose={() => setOpenDialog(false)} fullWidth maxWidth="xl">
            <BootstrapDialogTitle id="customized-dialog-title" onClose={() => setOpenDialog(false)}>
                Dashboard
            </BootstrapDialogTitle>

            <DialogContent dividers>
                {isInitialLoading ? (
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <CircularProgress />
                    </div>
                ) : (
                    <PortfolioAnalysisDashBoard
                        group={group}
                        setGroup={setGroup}
                        formData={formData}
                        setFormData={setFormData}
                        dashboardMeta={dashboardMeta}
                        dates={dates}
                        setDates={setDates}
                        models={models}
                        setModels={setModels}
                        lastModel={lastModel}
                        currencyList={currencyList}
                        resetFactors={resetFactors}
                        resetBetaProfiles={resetBetaProfiles}
                        analysis={analysis}
                        updateAnalysis={updateAnalysis}
                        selectedAnalysis={selectedAnalysis}
                        clearPage={clearPage}
                        selectAnalysis={selectAnalysis}
                    />
                )}
            </DialogContent>
            <DialogActions>
                <AdornedButton
                    style={{ textTransform: "capitalize" }}
                    variant="contained"
                    onClick={() => setOpenDialog(false)}
                    color="secondary"
                >
                    {" "}
                    Close{" "}
                </AdornedButton>
                <AdornedButton
                    style={{ textTransform: "capitalize" }}
                    variant="contained"
                    loading={isLoading}
                    disabled={analyzeDisabled()}
                    onClick={() => {
                        runAnalytics(group, formData, dates);
                    }}
                    color="primary"
                >
                    Analyze
                </AdornedButton>
            </DialogActions>
        </Dialog>
    );
}

const maxDate = moment().startOf("month").add(-1, "days");

const HeaderComponent = ({ setData, showPairSelector, setPairIndex }) => {
    const [openDialog, setOpenDialog] = useState(true);
    const [dates, setDates] = useState({
        fromDate: maxDate.clone().subtract(10, "years").add(1, "months").format("YYYY-MM-DD"),
        toDate: maxDate.format("YYYY-MM-DD"),
    });

    return (
        <div className="me-1 h-100">
            <div className="d-flex h-100">
                <div className="d-flex justify-content-center flex-column">
                    <Button
                        variant="outlined"
                        style={{
                            textTransform: "capitalize",
                            color: "#E38561",
                            borderColor: "#E38561",
                            backgroundColor: "#FFFEFE",
                        }}
                        size="small"
                        onClick={() => {
                            setOpenDialog(true);
                        }}
                    >
                        Dashboard
                    </Button>
                </div>
                <div className="d-flex justify-content-end flex-column">
                    <div className="ms-2">{showPairSelector && <PairSelector onChange={setPairIndex} />}</div>
                </div>
            </div>
            <DashboardDialog
                openDialog={openDialog}
                setOpenDialog={setOpenDialog}
                setData={setData}
                dates={dates}
                setDates={setDates}
            />
        </div>
    );
};

function Tabs({ data, tab, tabs }) {
    if (!data) return <></>;

    const isActive = (tab) => {
        if (!data?.pairs || !data.pairs?.length) return true;

        const dataCheck = tabs.find((x) => x.key == tab)?.dataCheck;
        if (!dataCheck) return true;

        return data?.pairs?.some((x) => x && dataCheck.some((k) => x[k])) || false;
    };

    const getTabClass = (key) => (isActive(key) ? "rt-effect " + (key == tab ? "rt-active" : "") : "rt-inactive");

    return (
        <div className="rt-container">
            <nav>
                <ul>
                    {tabs?.map((tab) => (
                        <li key={tab.key}>
                            <Link className={getTabClass(tab.key)} to={`/research-tool/portfolio_analysis/${tab.key}`}>
                                {tab.label}
                            </Link>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    );
}

const tabs = [
    {
        key: "model_return_risk",
        label: "Return Risk",
        pairSelector: true,
    },
    {
        key: "factor_response",
        label: "Factor Response",
        pairSelector: true,
        dataCheck: ["factor_response_quintiles"],
    },
    {
        key: "rel_factor_response",
        label: "Relative Factor Response",
        pairSelector: true,
        dataCheck: ["factor_response_rel_quintiles"],
    },
    {
        key: "fund_analyzer",
        label: "Fund Analyzer",
        pairSelector: true,
    },
    {
        key: "rolling_avg_return",
        label: "Rolling Average Returns",
    },
    {
        key: "fund_risk_return",
        label: "Fund Risk Return",
    },
    {
        key: "excess_returns",
        label: "Excess Returns",
    },
    {
        key: "a_b",
        label: "A - B",
    },
    {
        key: "excess_ret_dist",
        label: "Excess Ret Dist",
    },
    {
        key: "meta",
        label: "Meta",
    },
];

export default function PortfolioAnalysisHome() {
    const { pathname } = useLocation();
    const paths = pathname.split("/");
    const tab = paths[3];

    const [data, setDataLocal] = useState<any>(null);
    const [pairIndex, setPairIndex] = useState<any>(0);

    const setData = (dataIn) => {
        setDataLocal(dataIn);
        setPairIndex(0);
    };
    useScreenshot();

    const entities = toRecords(data?.entity_info);
    const getKey = (id_type, id_value) => `${id_type}:${id_value}`;
    const entityMap = entities?.reduce((d, x) => {
        d[getKey(x.id_type, x.id_value)] = x;
        return d;
    }, {});

    const getEntityName = (id_type, id_value) =>
        id_type == "_model_" ? id_value : entityMap[getKey(id_type, id_value)]?.entity_name || "N/A";

    const getFundBenchNames = (pair) => {
        const { fund, bench } = pair?.ids || {};
        const fundName = getEntityName(fund?.id_type, fund?.id_value);
        const benchName = getEntityName(bench?.id_type, bench?.id_value);
        return [fundName, benchName];
    };

    const pairs = data?.pairs?.filter((x) => x) || [];

    const showPairSelector = !!tabs.find((x) => x.key == tab)?.pairSelector;

    return (
        <RBAContext.Provider value={{ data, pairs, getEntityName, getFundBenchNames, pairIndex }}>
            <AppCover
                header={
                    <HeaderComponent
                        setData={setData}
                        showPairSelector={showPairSelector}
                        setPairIndex={setPairIndex}
                    />
                }
            >
                <div className="d-flex flex-column">
                    <div className="d-flex justify-content-between">
                        <div>
                            <Tabs data={data} tabs={tabs} tab={tab} />
                        </div>
                    </div>
                    <div className="mt-4" style={{ height: "calc(100vh - 210px)", overflow: "auto" }}>
                        <Route exact path="/research-tool/portfolio_analysis">
                            <Redirect to="/research-tool/portfolio_analysis/model_return_risk" />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/model_return_risk">
                            <ModelReturnRisk />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/rolling_avg_return">
                            <RollingAvgReturn />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/fund_risk_return">
                            <FundRiskReturn />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/excess_returns">
                            <ExcessReturns />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/a_b">
                            <AB />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/excess_ret_dist">
                            <ExcessReturnDistributions />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/factor_response">
                            <FactorResponse />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/rel_factor_response">
                            <FactorResponseRel />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/fund_analyzer">
                            <FundAnalyzer />
                        </Route>
                        <Route path="/research-tool/portfolio_analysis/meta">
                            <ReportMeta />
                        </Route>
                    </div>
                </div>
            </AppCover>
        </RBAContext.Provider>
    );
}
