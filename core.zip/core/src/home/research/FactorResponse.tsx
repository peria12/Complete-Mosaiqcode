import React from "react";
import { HChart } from "common/HChart";
import { RBAContext } from "utils/context";
import { unique } from "utils/helpers";
import { Cover } from "./Cover";
import { toRecords } from "./utils";

export default function FactorResponse() {
    const { pairs, pairIndex, getEntityName } = React.useContext(RBAContext);

    if (!pairs?.length) return <></>;

    const sortFn = (a, b) => a.quintile - b.quintile;
    const recs = toRecords(pairs[pairIndex]?.factor_response_quintiles).sort(sortFn);
    const getKey = (r) => `${r.id_type}:${r.id_value}`;
    const ids = unique(recs.map(getKey));

    const toPercent = (x) => x * 100;

    const getChart = (id) => {
        const records = recs.filter((x) => getKey(x) == id);
        const factorName = getEntityName(...id.split(":")); // find a better way

        return {
            title: {
                text: "",
                align: "center",
            },
            xAxis: {
                categories: ["Worst 20%", "2nd", "3rd", "4th", "Best 20%"],
            },
            yAxis: [
                {
                    title: {
                        text: "",
                    },
                    labels: {
                        format: "{text} %",
                    },
                },
            ],
            plotOptions: {
                line: {
                    dataLabels: {
                        enabled: true,
                    },
                },
            },
            tooltip: {
                valueDecimals: 2,
                valueSuffix: "%",
                shared: true,
            },
            series: [
                {
                    name: factorName,
                    type: "column",
                    data: records.map((r) => toPercent(r.factor_perf)),
                    color: "#FA9375",
                    marker: { enabled: false },
                    dataLabels: { enabled: false },
                },
                {
                    name: "Fund",
                    type: "line",
                    data: records.map((r) => toPercent(r.fund_perf)),
                    marker: { enabled: false },
                    dataLabels: { enabled: false },
                },
                {
                    name: "Benchmark",
                    type: "line",
                    data: records.map((r) => toPercent(r.bench_perf)),
                    marker: { enabled: false },
                    dataLabels: { enabled: false },
                },
                {
                    name: "Active",
                    type: "line",
                    dataLabels: { enabed: true, format: "{point.y:.2f}" },
                    data: records.map((r) => toPercent(r.active_perf)),
                    marker: { enabled: false },
                },
            ],
        };
    };

    return (
        <div className="d-flex flex-column rounded">
            <div className="row me-2">
                {ids.map((id: any, i) => (
                    <div
                        key={i}
                        className="col-12 col-md-6 col-lg-6 col-xl-4 col-xxl-3"
                        style={{ padding: "0px !important" }}
                    >
                        <Cover title={getEntityName(...id.split(":"))}>
                            <HChart option={getChart(id)} />
                        </Cover>
                    </div>
                ))}
            </div>
        </div>
    );
}
