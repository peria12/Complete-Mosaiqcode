import React from "react";
import { AbsPerformanceAllTable } from "./components/AbsPerformanceAllTable";
import { RelPerformanceAllTable } from "./components/RelPerformanceAllTable";
import { CorrelationAllTable } from "./components/CorrelationAllTable";
import { RiskAllTable } from "./components/RIskAllTable";
import { ReturnAllTable } from "./components/ReturnAllTable";
import { RBAContext } from "utils/context";

export function FundRiskReturn() {
    const { pairs } = React.useContext(RBAContext);
    if (!pairs?.length) return <></>;

    return (
        <>
            <div className="d-flex flex-column pe-2" style={{minWidth: "1540px", width: "1540px"}}>
                <div className="d-flex flex-wrap">
                    <AbsPerformanceAllTable />
                    <RelPerformanceAllTable />
                </div>
                <div className="d-flex flex-wrap">
                    <RiskAllTable />
                    <ReturnAllTable />
                </div>
                <div className="d-flex">
                    <CorrelationAllTable />
                </div>
            </div>
        </>
    );
}
