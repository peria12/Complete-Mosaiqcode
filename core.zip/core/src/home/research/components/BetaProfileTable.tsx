import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toFixed } from "utils/helpers";
import { toRecords } from "../utils";
import { FTGrid } from "./FTGrid";

export function BetaProfileTable() {
    const { pair, getEntityName } = React.useContext(RBAModelReturnRiskContext);

    const headerClass = "ft-grid-th-div-span";
    const cellClass = (val) => (val < 0 ? "ft-grid-td red-value" : "ft-grid-td");
    const cellClass2 = () => "ft-grid-td-div-span";
    const format = (val) => toFixed(val, 2, "0.00")

    const cols = [
        { headerName: "", field: "entity_name", cellClass: cellClass2, headerClass, width: 520 },
        { headerName: "Fund", field: "fund_beta", format, cellClass, headerClass, width: 60 },
        { headerName: "Bench", field: "bench_beta", format, cellClass, headerClass, width: 60 },
        { headerName: "+/-", field: "rel_beta", format, cellClass, headerClass, width: 60 },
    ];

    const getRows = () => {
        const recs = toRecords(pair?.beta_profile);
        recs.forEach((x) => (x.entity_name = getEntityName(x.id_type, x.id_value)));
        return recs;
    };

    return (
        <div className="rounded bg-white border mb-2 me-2 p-1 w-75">
            <div className="ft-card-header">Beta Profile</div>
            <FTGrid columnDefs={cols} rowData={getRows()}></FTGrid>
        </div>
    );
}
