import React from "react";
import { RBAContext } from "utils/context";

export function PairSelector({ onChange }) {
    const { pairs, pairIndex, getFundBenchNames } = React.useContext(RBAContext);
    if (!pairs || !pairs.length) return <></>;

    const p = pairs[pairIndex];
    const [pFund, pBench] = getFundBenchNames(p);

    if (!p) return <></>;

    return (
        <nav>
            <div className="fund-analyzer-dropdown">
                <button>
                    <div className="fa-left-drop">
                        <code className="fa-small-text"> {pFund} </code> {p.ids?.fund?.id_value || ""}
                    </div>
                    <div className="fa-middle-drop">
                        <code className="fa-color1"> I </code> <code className="fa-vs-text"> VS </code>
                        <code className="fa-color2"> I </code>{" "}
                    </div>
                    <div className="fa-right-drop">
                        {p.ids?.bench?.id_value || ""}
                        <code className="fa-small-text"> {pBench} </code>
                    </div>
                </button>
                <ul>
                    {pairs.map((x, i) => {
                        if (i == pairIndex) return <></>;
                        const [fund, bench] = getFundBenchNames(x);
                        return (
                            <li key={i}>
                                <a onClick={() => onChange(i)}>
                                    <div className="fa-left-drop">
                                        <code className="fa-small-text"> {fund} </code> {x.ids?.fund?.id_value || ""}
                                    </div>
                                    <div className="fa-middle-drop">
                                        <code className="fa-color3"> I </code> <code className="fa-vs-text"> VS </code>
                                        <code className="fa-color4"> I </code>{" "}
                                    </div>
                                    <div className="fa-right-drop">
                                        {x.ids?.bench?.id_value || ""}
                                        <code className="fa-small-text"> {bench} </code>
                                    </div>
                                </a>
                            </li>
                        );
                    })}
                </ul>
            </div>
        </nav>
    );
}
