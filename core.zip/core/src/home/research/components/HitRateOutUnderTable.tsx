import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toFixed } from "utils/helpers";
import { toRecords } from "../utils";
import { FTGrid } from "./FTGrid";

export function HitRateOutUnderTable() {
    const {pair} = React.useContext(RBAModelReturnRiskContext)
    
    const headerClass = "ft-grid-th-div-span"
    const cellClass = val => val >= 0 ? "ft-grid-td " : "ft-grid-td red-value"
    const format = toFixed

    const monthMap = { 12: "1Y", 36: "3Y", 60: "5Y", 84: "7Y", 120: "10Y" };
    const cols = [
        { headerName: "Period", field: "period", cellClass: () => headerClass, headerClass },
        { headerName: "Hit Rate", field: "hit_rate", cellClass, headerClass, format },
        { headerName: "Avg Out-Perf.", field: "avg_out_perf", cellClass, headerClass, format },
        { headerName: "Avg Under-Perf.", field: "avg_under_perf", cellClass, headerClass, format },
    ];

    const getRows = () => {
        const recs = toRecords(pair?.stats);
        return recs ? recs.map((r) => ({ ...r, period: monthMap[r.months] })) : [];
    };

    return (
        <div className="rounded bg-white border my-2 me-2 p-1" style={{ width: 350 }}>
            <FTGrid columnDefs={cols} rowData={getRows()}></FTGrid>
        </div>
    );
}
