import React from "react";
import { toRecords } from "../utils";
import { RBAContext } from "utils/context";
import { FTGrid } from "./FTGrid";
import { Cover } from "../Cover";
import { toFixed } from "utils/helpers";

export function ReturnAllTable() {
    const { pairs, getFundBenchNames } = React.useContext(RBAContext);

    const headerClass = "ft-grid-th-div-span";
    const headerClassB = "ft-grid-th-div-span ft-border-right";
    const cellClass = (val) => (val < 0 ? "ft-grid-td red-value" : "ft-grid-td");
    const cellClassB = (val) => `${cellClass(val)} ft-border-right`
    const cellClass2 = () => "ft-grid-td-div-span ft-border-right";
    const formatP = (x) => (x ? `${toFixed(x * 100)}%` : "");
    const width = 93;

    const cols = [
        [
            { headerName: "" },
            { headerName: "3Y", colSpan: 3, headerClass: headerClass + " text-center" },
            { headerName: "5Y", colSpan: 3, headerClass: headerClass + " text-center" },
        ],
        [
            { headerName: "Fund", field: "fundName", minWidth: 100, maxWidth: 350, cellClass: cellClass2, headerClass },
            { headerName: "Hit Rate", field: "hit_rate", format: formatP, width, cellClass, headerClass },
            { headerName: "Avg Out-Perf.", field: "avg_out_perf", format: formatP, width, cellClass, headerClass },
            {
                headerName: "Avg Under-Perf.",
                field: "avg_under_perf",
                format: formatP,
                width,
                cellClass: cellClassB,
                headerClass: headerClassB,
            },
            { headerName: "Hit Rate", field: "hit_rate_5y", format: formatP, width, cellClass, headerClass },
            { headerName: "Avg Out-Perf.", field: "avg_out_perf_5y", format: formatP, width, cellClass, headerClass },
            {
                headerName: "Avg Under-Perf.",
                field: "avg_under_perf_5y",
                format: formatP,
                width,
                cellClass,
                headerClass,
            },
        ],
    ];

    const getRows = () => {
        return (
            pairs
                .filter((x) => x)
                .map((p) => {
                    const recs = toRecords(p?.stats) || [];
                    const y3 = recs.find((r) => r.months == 36);
                    const y5 = recs.find((r) => r.months == 60);

                    const [fundName] = getFundBenchNames(p);
                    return {
                        fundName,
                        hit_rate: y3?.hit_rate,
                        avg_out_perf: y3?.avg_out_perf,
                        avg_under_perf: y3?.avg_under_perf,
                        hit_rate_5y: y5?.hit_rate,
                        avg_out_perf_5y: y5?.avg_out_perf,
                        avg_under_perf_5y: y5?.avg_under_perf,
                    };
                }) || []
        );
    };

    return (
        <Cover title={"Return Profile"}>
            <FTGrid columnDefs={cols} rowData={getRows()}></FTGrid>
        </Cover>
    );
}
