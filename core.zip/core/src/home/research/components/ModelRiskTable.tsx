import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toRecords } from "../utils";
import { FTGrid } from "./FTGrid";

export function ModelRiskTable() {
    const { pair, getEntityName } = React.useContext(RBAModelReturnRiskContext);
    if (!pair?.component_info) return <></>;

    const headerClass = "ft-grid-th-div-span";
    const cellClass = (val) => (val < 0 ? "ft-grid-td red-value" : "ft-grid-td");
    const cellClass2 = () => "ft-grid-td-div-span";

    const cols = [
        { headerName: "", field: "entity_name", cellClass: cellClass2, headerClass, width: 400 },
        { headerName: "Abs Risk", field: "risk", cellClass, headerClass, width: 70, pct: true },
        { headerName: "% of TE", field: "te_risk", cellClass, headerClass, width: 70, pct: true },
        { headerName: "Active(ρ)", field: "active_risk", cellClass, headerClass, width: 70 },
    ];

    const getRows = () => {
        const recs = toRecords(pair?.component_info) || [];
        recs.forEach((x) => (x.entity_name = getEntityName(x.id_type, x.id_value)));
        return recs;
    };

    return (
        <div className="rounded bg-white border mb-2 me-2 p-1 w-100">
            <div className="ft-card-header">Model Risk</div>
            <FTGrid columnDefs={cols} rowData={getRows()}></FTGrid>
        </div>
    );
}
