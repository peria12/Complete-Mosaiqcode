import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { color, rowsForRelPerf, toRecords } from "../utils";
import { FTGrid } from "./FTGrid";

export function RelPerformanceTable() {
    const { pair, getFundBenchNames } = React.useContext(RBAModelReturnRiskContext);

    const getYears = () => {
        const recs = toRecords(pair?.yearly_perf);
        return recs?.reverse() || [];
    };

    const headerClass = "ft-grid-th-div-span ft-border-right";
    const cellClass2 = () => "ft-grid-td-div-span ft-border-right";
    const cellClass = (val) => `ft-border-right ft-grid-td ${color(val)}`;
    const cellClassLast = (val) => `ft-grid-td ${color(val)}`;

    const width = 57;
    const pct = true;
    const cols = [
        { headerName: "vs Benchmark", field: "benchName", width: 350, cellClass: cellClass2, headerClass },
        { headerName: "1M", field: "1M", type: "rightAligned", width, cellClass, headerClass, pct },
        { headerName: "3M", field: "3M", type: "rightAligned", width, cellClass, headerClass, pct },
        { headerName: "6M", field: "6M", type: "rightAligned", width, cellClass, headerClass, pct },
        { headerName: "1Y", field: "1Y", type: "rightAligned", width, cellClass, headerClass, pct },
        { headerName: "3Y", field: "3Y", type: "rightAligned", width, cellClass, headerClass, pct },
        { headerName: "5Y", field: "5Y", type: "rightAligned", width, cellClass, headerClass, pct },
        { headerName: "7Y", field: "7Y", type: "rightAligned", width, cellClass, headerClass, pct },
        { headerName: "10Y", field: "10Y", type: "rightAligned", width, cellClass, headerClass, pct },
        ...getYears().map((y) => ({
            headerName: y.year_display,
            field: y.year,
            type: "rightAligned",
            width,
            cellClass,
            headerClass,
            pct,
        })),
    ];

    cols[cols.length - 1].headerClass = "ft-grid-th-div-span";
    cols[cols.length - 1].cellClass = cellClassLast;

    const getRows = () => {
        return [rowsForRelPerf(pair, getFundBenchNames)];
    };

    return (
        <div className="rounded bg-white border mb-2 p-1 w-100">
            <div className="ft-card-header">Performance - Relative</div>
            <FTGrid columnDefs={cols} rowData={getRows()} />
        </div>
    );
}
