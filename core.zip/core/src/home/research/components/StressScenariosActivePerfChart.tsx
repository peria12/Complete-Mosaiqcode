import { HChart } from "common/HChart";
import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toRecords } from "../utils";

export function StressScenariosActivePerfChart() {
    const { pair, getEntityName } = React.useContext(RBAModelReturnRiskContext);

    const getOptions = () => {
        const recs = toRecords(pair?.beta_profile) || [];

        return {
            title: {
                text: "",
                align: "center",
            },
            xAxis: {
                categories: recs.map((x) => getEntityName(x.id_type, x.id_value)),
            },
            yAxis: [
                {
                    title: {
                        text: "",
                    },
                    labels: {
                        format: "{text} %",
                    },
                },
            ],
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true,
                    },
                },
            },
            tooltip: {
                shared: true,
                valueDecimals: 2,
            },
            series: [
                {
                    name: "Fund vs Benchmark",
                    type: "bar",
                    data: recs.map((x) => x.active_perf * 100),
                    dataLabels: { format: "{point.y:.2f}%" },
                    color: "#FA9375",
                },
            ],
        };
    };

    return (
        <div className="rounded bg-white border mb-2 p-1" style={{ width: 650 }}>
            <div className="ft-card-header mb-3">Stress Scenarios - 2σ Corrections (Active Performance)</div>
            <HChart option={getOptions()}></HChart>
        </div>
    );
}
