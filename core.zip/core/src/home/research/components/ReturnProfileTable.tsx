import React from "react";
import { RBAModelReturnRiskContext } from "utils/context";
import { toFixed } from "utils/helpers";
import { getMaxAbsPerf, toRecords } from "../utils";
import { FTGrid } from "./FTGrid";

export function ReturnProfileTable() {
    const { pair } = React.useContext(RBAModelReturnRiskContext);

    const headerClass = "ft-grid-th-div-span";
    const headerClassH = "ft-grid-th-div-span mr-11";
    const cellClass = (val, row) => {
        const v = row.color != null ? row.color : val;
        if (row.label == "StDev" || row.label == "TE") return "ft-grid-td";
        if (row.label == "UpCap" || row.label == "DownCap") {
            return v >= 0 ? "ft-grid-td green-value" : "ft-grid-td red-value";
        }
        return v < 0 ? "ft-grid-td red-value" : "ft-grid-td";
    };
    const cols = [
        {
            headerName: "Annualized",
            field: "label",
            headerClass: "fst-italic font-14",
            cellClass: () => headerClass,
            width: 100,
        },
        { headerName: "Fund", field: "fund", headerClass: headerClassH, cellClass, width: 70, formatFn: 'format' },
        { headerName: "Bench", field: "bm", headerClass: headerClassH, cellClass, width: 70, formatFn: 'format' },
    ];
    const format = x => x == null ? "" : `${toFixed(x*100)}%`

    const fields = [
        { label: "StDev", fund: "fund_std", bm: "bench_std", format },
        { label: "Sharpe", fund: "sharpe_ratio", bm: "bench_sharpe_ratio" },
        { label: "Beta", fund: "beta" },
        { label: "Correl", fund: "correlation" },
        { label: "TE", fund: "te", format },
        { label: "VaR(95%)", fund: "var_95", bm: "bench_var_95", format },
        { label: "Cvar(95%)", fund: "cvar_95", format },
        { label: "Alpha", fund: "alpha", format },
        { label: "IR", fund: "ir" },
        { label: "UpCap", fund: "up_cap", color: "up_cap_color", format },
        { label: "DownCap", fund: "down_cap", color: "down_cap_color", format },
        { label: "MaxDraw", fund: "max_drawdown", bm: "max_bench_drawdown", format },
    ];

    const getRows = () => {
        const statRecs = toRecords(pair?.stats);
        if (statRecs) {
            const maxPerf = getMaxAbsPerf(pair);
            const maxMonth = Math.max(...statRecs.map((r) => r.months));
            const rec = statRecs.find((x) => x.months == maxMonth) || {};
            const out = fields.map((f) => ({
                label: f.label,
                fund: rec[f.fund],
                bm: f.bm ? rec[f.bm] : null,
                color: f.color ? rec[f.color] : null,
                format: f.format,
            }));
            const returnRec = {
                label: "Return",
                fund: maxPerf.return,
                bm: maxPerf.bench_return,
                format,
            };
            return [returnRec, ...out];
        }
        return [];
    };

    return <FTGrid columnDefs={cols} rowData={getRows()}></FTGrid>;
}
