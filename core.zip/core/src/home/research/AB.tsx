import React from "react";
import { toRecords } from "./utils";
import { HChart } from "common/HChart";
import { RBAContext } from "utils/context";
import { Cover } from "./Cover";

export function AB() {
    const { pairs, getFundBenchNames } = React.useContext(RBAContext);

    if (!pairs.length) return <></>;

    const getTitle = (pair) => {
        const [fundName, benchName] = getFundBenchNames(pair);
        return `${fundName} vs ${benchName}`;
    };

    const getChart = (pair) => {
        const recs = toRecords(pair?.rolling_18m_a_b)?.map((x) => ({ ...x, date: new Date(x.date).getTime() }));
        return {
            title: { text: "Rolling 18M Alpha/Beta vs Benchmark" },
            xAxis: {
                type: "datetime",
            },
            yAxis: [
                {
                    title: {
                        text: "Beta",
                    },
                    tickAmount: 8,
                },
                {
                    title: {
                        text: "Alpha",
                    },
                    labels: { format: "{text} %" },
                    opposite: true,
                    tickAmount: 8,
                },
            ],
            tooltip: {
                shared: true,
                valueDecimals: 2,
            },

            series: [
                {
                    name: "Beta (LHS)",
                    type: "line",
                    color: "#57DFD4",
                    pointWidth: 25,
                    data: recs?.map((x) => [x.date, x.beta]) || [],
                },
                {
                    name: "Alpha (RHS)",
                    type: "line",
                    color: "#FA9375",
                    yAxis: 1,
                    pointWidth: 25,
                    data: recs?.map((x) => [x.date, 100.0 * x.alpha]) || [],
                    tooltip: {
                        valueSuffix: "%",
                    },
                },
            ],
        };
    };

    return (
        <>
            <div className="row me-2">
                {pairs
                    .filter((x) => x)
                    .map((p, i) => {
                        const title = getTitle(p);
                        return (
                            <div key={i} className="col-12 col-md-6 col-lg-6 col-xl-4 col-xxl-3">
                                <Cover title={title}>
                                    <HChart option={getChart(p)} />
                                </Cover>
                            </div>
                        );
                    })}
            </div>
        </>
    );
}
