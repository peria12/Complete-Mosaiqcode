import React from "react";
import StackBarChartWithCheckbox from "./StackBarChartWithCheckbox";

const keys = [
    "Alpha",
    "Currency DM vs Base Currency",
    "EM Asia EX China(EQ)",
    "EM China(EQ)",
    "EM Eur Mid East and Africa(EQ)",
    "EM Latin America(EQ)",
    "Europe(EQ)",
    "Global Market(EQ)",
    "Japan EQ",
    "Pacific Ex Japan EQ",
    "UK EQ",
    "US Consumer Discretionary",
    "US Consumer Staples",
    "US Dividend(Style)",
    "US Energy",
    "US EQ",
    "US Financials",
    "US Healthcare",
];

const data: any = {};
keys.forEach((key) => {
    data[key] = [];
});
for (let y = 2020; y < 2024; y++) {
    for (let m = 1; m <= 12; m++) {
        keys.forEach((key) => {
            data[key].push([Date.UTC(y, m - 1), Math.random()]);
        });
    }
}

const seriesData: any = [];
Object.entries(data).forEach(([key, values]) => {
    seriesData.push({
        name: key,
        data: values,
        visible: true,
        selected: true,
    });
});

export default function PercentContributionByFactor() {
    return (
        <StackBarChartWithCheckbox
            title="% Contribution to Risk by Factor"
            yAxisTitle="PCTR (ln %)"
            seriesData={seriesData}
            resetButtonPosition={[-77, 5]}
            legendWidth={200}
        />
    );
}
