import React from "react";
import CurrentFactorExposures from "./CurrentFactorExposures";
import PersistentExposures from "./PersistentExposures";
import AggregateRiskDecomposition from "./AggregateRiskDecomposition";
import ExposuresOverTime from "./ExposuresOverTime";
import PercentAggregateRiskDecomp from "./PercentAggregateRiskDecomp";
import ContributionToRiskByCategory from "./ContributionToRiskByCategory";
import PercentContributionByFactor from "./PercentContributionByFactor";
import PerformanceAttributionByFactor from "./PerformanceAttributionByFactor";
import PerformanceAttributionByCategory from "./PerformanceAttributionByCategory";

export default function Outputs() {
    return (
        <div className="output-container">
            <div>
                <CurrentFactorExposures />
                <PersistentExposures />
            </div>
            <div>
                <ExposuresOverTime />
                <AggregateRiskDecomposition />
            </div>
            <div>
                <PercentAggregateRiskDecomp />
                <ContributionToRiskByCategory />
                <PercentContributionByFactor />
            </div>
            <div>
                <PerformanceAttributionByFactor />
                <PerformanceAttributionByCategory />
            </div>
        </div>
    );
}
