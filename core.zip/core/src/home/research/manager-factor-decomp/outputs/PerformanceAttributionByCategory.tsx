import React from "react";
import Highcharts from "highcharts/highstock";
import StockModule from "highcharts/modules/stock";
import StackBarChartWithCheckbox from "./StackBarChartWithCheckbox";

StockModule(Highcharts);

const keys = ["Credit", "Equity", "FX", "Region", "Sector", "Style", "Term"];
const data: any = {};
keys.forEach((key) => {
    data[key] = [];
});
for (let y = 2020; y < 2024; y++) {
    for (let m = 1; m <= 12; m++) {
        keys.forEach((key) => {
            data[key].push([Date.UTC(y, m - 1), Math.random() * (1 - -1) + -1]);
        });
    }
}

const lineData: any = [];
for (let y = 2020; y < 2024; y++) {
    for (let m = 1; m <= 12; m++) {
        lineData.push([Date.UTC(y, m - 1), Math.random() * (1 - -1) + -1]);
    }
}

const seriesData: any = [];
Object.entries(data).forEach(([key, values]) => {
    seriesData.push({
        name: key,
        data: values,
        type: "column",
        visible: true,
        selected: true,
    });
});
seriesData.push({
    name: "",
    data: lineData,
    type: "spline",
    visible: true,
    selected: true,
});

export default function PerformanceAttributionByCategory() {
    return (
        <StackBarChartWithCheckbox
            title="Performance Attribution by Category"
            yAxisTitle="Returns (ln %)"
            seriesData={seriesData}
            resetButtonPosition={[-37, -70]}
            legendWidth={120}
        />
    );
}
