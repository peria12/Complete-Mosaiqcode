import React from "react";
import StackBarChartWithCheckbox from "./StackBarChartWithCheckbox";

const keys = [
    "Currency EM vs Base Currency",
    "EUxUK Qual(Style)",
    "EUxUK Size(Style)",
    "EM Sov Spd",
    "EM Energy & Materials",
    "EM Financials",
    "Global IG Credit",
    "Global High Yield",
    "Currency DM vs Base Currency",
    "Global Short Rates",
    "Intl IT + Consumer Discretionary",
    "Intl Cons Staples + Healthcare + Retail",
    "Intl Utilities + Telo + Real Estate",
    "UK Value(Style)",
    "UK Low Vol(Style)",
    "EU PanEUR Term + Credit",
    "xUS Tips",
    "xUS Term",
    "Pan EUR currencies vs Base Currency",
    "EU Govt Related",
];

const data: any = {};
keys.forEach((key) => {
    data[key] = [];
});
for (let y = 2020; y < 2024; y++) {
    for (let m = 1; m <= 12; m++) {
        keys.forEach((key) => {
            data[key].push([Date.UTC(y, m - 1), Math.random() * (1 - -1) + -1]);
        });
    }
}

const lineData: any = [];
for (let y = 2020; y < 2024; y++) {
    for (let m = 1; m <= 12; m++) {
        lineData.push([Date.UTC(y, m - 1), Math.random() * (1 - -1) + -1]);
    }
}

const seriesData: any = [];
Object.entries(data).forEach(([key, values]) => {
    seriesData.push({
        name: key,
        data: values,
        type: "column",
        visible: true,
        selected: true,
    });
});
seriesData.push({
    name: "",
    data: lineData,
    type: "spline",
    visible: true,
    selected: true,
});

export default function PerformanceAttributionByFactor() {
    return (
        <StackBarChartWithCheckbox
            title="Performance Attribution by Factor"
            yAxisTitle="Returns (ln %)"
            seriesData={seriesData}
            resetButtonPosition={[-77, 5]}
            legendWidth={200}
        />
    );
}
