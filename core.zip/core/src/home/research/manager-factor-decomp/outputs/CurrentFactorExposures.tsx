import React, { useRef, useEffect } from "react";
import * as d3 from "d3";
import Button from "@mui/material/Button";

const color = {
    prv: "#de48a6",
    curr: "#268adc",
};

const master = [
    {
        factor: "Alpha",
        currentMonth: -0.7,
        prevMonth: -0.6,
    },
    {
        factor: "Currency DM Vs Base Currency",
        currentMonth: -0.68,
        prevMonth: -0.66,
    },
    {
        factor: "EM China (EQ)",
        currentMonth: -0.6,
        prevMonth: -0.5,
    },
    {
        factor: "Global Market (EQ)",
        currentMonth: 0.2,
        prevMonth: 0.3,
    },
    {
        factor: "Japan (EQ)",
        currentMonth: 0.7,
        prevMonth: 0.6,
    },
];
const seriesData = [
    ...master,
    ...master.map((e, i) => ({ ...e, factor: e.factor + i })),
    ...master.map((e, i) => ({ ...e, factor: e.factor + i * 2 })),
];

const Height = 500;
const Width = 800;

export default function CurrentFactorExposures() {
    const chartRef = useRef(null);
    const [chartData, setChartData] = React.useState({
        series: seriesData,
    });

    useEffect(() => {
        renderGraph();
        //eslint-disable-next-line
    }, [chartData]);

    function onReset() {
        setChartData((cd) => ({
            ...cd,
            series: seriesData,
        }));
    }

    function onUncheck(val) {
        const list = chartData?.series || [];
        const index = list.findIndex((item) => item?.factor == val);
        if (index !== -1) {
            setChartData((cd) => ({
                ...cd,
                series: chartData?.series?.filter((_, i) => i != index),
            }));
        }
    }

    const colStrMaxWidth = 25;
    const offset = 40;

    function trimText(text = "") {
        if (text?.length <= colStrMaxWidth) return text;
        return text.substring(0, colStrMaxWidth).concat("...");
    }

    function renderGraph() {
        const data = chartData?.series || [];
        const margin = { top: 10, right: 10, bottom: 10, left: 10 };
        const width = Width - margin.left - margin.right;
        const height = Height - margin.top - margin.bottom;

        const svg = d3.select(chartRef.current);

        svg.selectAll("g").remove();

        svg.attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        const factors = data.map((d) => d?.factor);

        const barHeight = height * 0.4;

        const xScale = d3
            .scaleBand()
            .domain(factors)
            .range([offset * 0.9, width])
            .padding(0.6);

        const yScale = d3
            .scaleLinear()
            .domain([
                Math.min(
                    0,
                    d3.min(
                        data,
                        (d) => d.currentMonth,
                        (d) => d.prevMonth
                    )
                ),
                d3.max(
                    data,
                    (d) => d.currentMonth,
                    (d) => d.prevMonth
                ),
            ])
            .nice()
            .range([barHeight, 5]);

        const xAxis = d3.axisBottom(xScale).tickSizeOuter(0);

        const yAxis = d3.axisLeft(yScale).ticks(3).tickSizeOuter(0);

        //create grid
        const xAxisGrid = xAxis
            .tickSize(-(height + 60))
            .tickFormat("")
            .ticks(0)
            .tickSizeOuter(0);
        svg.append("g")
            .attr("class", "x axis-grid")
            .attr("transform", "translate(20," + (height + 60) + ")")
            .call(xAxisGrid);

        const labelGrp = svg
            .append("g")
            .attr("transform", `translate(0, ${yScale(0)})`)
            .call(xAxis)
            .call((g) => g.selectAll("line").remove())
            .call((g) =>
                g
                    .selectAll(".tick")
                    .append("foreignObject")
                    .attr("class", "checkbox-base")
                    .attr("transform", `translate(-20, 360)`)
                    .append("xhtml:input")
                    .attr("class", "checkbox")
                    .attr("type", "checkbox")
                    .attr("checked", true)
                    .on("click", (_, i) => onUncheck(i))
            );

        labelGrp
            .selectAll("text")
            .attr("class", "label")
            .attr("transform", `rotate(-90)`)
            .attr("y", 0)
            .attr("x", 0)
            .attr("dy", 0)
            .attr("dx", -(barHeight + 60))
            .text((text) => trimText(text));

        // y-axis label
        svg.append("g")
            .call(yAxis)
            .call((g) => g.selectAll("line").remove())
            .call((g) => g.selectAll("text").attr("x", -5))
            .attr("transform", `translate(${offset},0)`);

        // Create grouped bars for current month and previous month
        const group = svg
            .selectAll(".group")
            .data(data)
            .enter()
            .append("g")
            .attr("transform", (d) => `translate(${xScale(d.factor) + 2}, 0)`);

        group
            .append("rect")
            .attr("fill", color.curr)
            .attr("width", xScale.bandwidth() / 2)
            .attr("x", 0)
            .attr("y", (d) => yScale(Math.max(0, d.currentMonth)))
            .attr("height", (d) => Math.abs(yScale(0) - yScale(d.currentMonth)))
            .attr("style", (d) => (d.currentMonth < 0 ? "fill-opacity: 0.5;" : ""));

        group
            .append("rect")
            .attr("fill", color.prv)
            .attr("width", xScale.bandwidth() / 2)
            .attr("x", xScale.bandwidth() / 2)
            .attr("y", (d) => yScale(Math.max(0, d.prevMonth)))
            .attr("height", (d) => Math.abs(yScale(0) - yScale(d.prevMonth)))
            .attr("style", (d) => (d.prevMonth < 0 ? "fill-opacity: 0.5;" : ""));

        // append xAxis and yAxis label
        const axisLabelGrp = svg.append("g");

        axisLabelGrp
            .append("text")
            .attr("class", "axis-label")
            .attr("text-anchor", "end")
            .attr("x", Width / 2)
            .attr("y", Height)
            .text("Factors");

        axisLabelGrp
            .append("text")
            .attr("class", "axis-label")
            .attr("text-anchor", "end")
            .attr("y", 0)
            .attr("dy", 12)
            .attr("dx", -(barHeight / 2))
            .attr("transform", "rotate(-90)")
            .text("Beta");
    }

    return (
        <>
            <div
                style={{
                    padding: 9,
                    border: "2px solid grey",
                    height: Height + 50,
                    display: "flex",
                    flexDirection: "column",
                }}
            >
                <svg id="current-factor-chart" ref={chartRef} />
                <div style={{ marginLeft: "auto", marginTop: -2 }}>
                    <Button size="small" variant="outlined" className="reset-btn" onClick={onReset}>
                        Reset
                    </Button>
                </div>
            </div>
        </>
    );
}
