import React from "react";
import StackBarChartWithCheckbox from "./StackBarChartWithCheckbox";

const keys = ["Credit", "Equity", "FX", "Region", "Sector", "Style", "Term"];
const data: any = {};
keys.forEach((key) => {
    data[key] = [];
});
for (let y = 2020; y < 2024; y++) {
    for (let m = 1; m <= 12; m++) {
        keys.forEach((key) => {
            data[key].push([Date.UTC(y, m - 1), Math.random()]);
        });
    }
}

const seriesData: any = [];
Object.entries(data).forEach(([key, values]) => {
    seriesData.push({
        name: key,
        data: values,
        visible: true,
        selected: true,
    });
});

export default function ContributionToRiskByCategory() {
    return (
        <StackBarChartWithCheckbox
            title="% Contribution to Risk by Category"
            yAxisTitle="PCTR (ln %)"
            seriesData={seriesData}
            resetButtonPosition={[-37, -70]}
            legendWidth={120}
        />
    );
}
