import React, { useCallback } from "react";
import Highcharts from "highcharts/highstock";
import HighchartsReact from "highcharts-react-official";
import StockModule from "highcharts/modules/stock";
import { seriesCheckboxHandler } from "../ma-helper";

StockModule(Highcharts);

export default function StackBarChartWithCheckbox({ title, yAxisTitle, seriesData, resetButtonPosition, legendWidth }) {
    const [chartData] = React.useState({ series: seriesData });
    const [chartOptions, setChartOptions] = React.useState<any>(getOptions());
    const chartRef = React.useRef<any>(null);

    React.useEffect(() => {
        setChartOptions({ ...getOptions(), series: chartData.series });
        //eslint-disable-next-line
    }, [chartData]);

    React.useEffect(() => {
        if (chartRef?.current) {
            chartRef.current.chart.update({ series: chartOptions.series }, true);
        }
        //eslint-disable-next-line
    }, [chartOptions]);

    function onReset() {
        setChartOptions({
            ...chartOptions,
            series: seriesData,
        });
    }

    const onUncheck = useCallback(
        (index) => {
            setChartOptions((prvOptions) => seriesCheckboxHandler(prvOptions, index));
        },
        //eslint-disable-next-line
        [chartOptions]
    );

    function getBtnPositions(chart) {
        return {
            x: chart.plotLeft + chart.plotWidth + legendWidth / 2 + resetButtonPosition[0],
            y: chart.spacingBox.height - chart.spacing[0] + resetButtonPosition[1],
        };
    }

    function positionButton(chart) {
        chart.resetButton?.animate?.(getBtnPositions(chart));
    }

    function updateBtnAxis(chart) {
        const textRef = chart.resetButton?.element.childNodes[1];
        textRef?.setAttribute("x", 12);
        textRef?.setAttribute("y", 16);
    }

    function onLoad(chart) {
        if (!chart.resetButton) {
            const { x, y } = getBtnPositions(chart);
            chart.resetButton = chart.renderer
                .button("Reset", x, y, onReset.bind(chart))
                .on("mouseleave", () => updateBtnAxis(chart))
                .add();
            const nodes = chart.resetButton?.element.childNodes;
            const textRef = nodes[1];
            const rectRef = nodes[0];
            rectRef.setAttribute("class", "hc-reset-btn");
            rectRef.setAttribute("rx", "3");
            rectRef.setAttribute("ry", "3");
            textRef.setAttribute("class", "hc-rst-btn-text");
            updateBtnAxis(chart);
            positionButton(chart);
        }
    }

    function getOptions() {
        const options = {
            chart: {
                type: "column",
                width: 1000,
                style: {
                    fontFamily: "Roboto Condensed",
                },
            },
            title: {
                text: title,
                align: "left",
                style: { fontWeight: "bold" },
            },
            legend: {
                enabled: true,
                width: legendWidth,
                maxHeight: 284,
                align: "right",
                verticalAlign: "middle",
                layout: "vertical",
                y: 10,
                useHTML: true,
                legendItemStyle: {
                    cursor: "unset",
                },
                itemStyle: {
                    textOverflow: "ellipsis",
                    overflow: "hidden",
                    fontSize: "13px",
                    fontWeight: 500,
                },
                itemCheckboxStyle: {
                    cursor: "pointer",
                    position: "absolute",
                    right: "10px",
                    marginLeft: "auto",
                },
            },
            xAxis: {
                type: "datetime",
            },
            yAxis: {
                title: { text: yAxisTitle },
                opposite: false,
            },
            plotOptions: {
                column: {
                    stacking: "normal",
                    dataLabels: {
                        enabled: false,
                    },
                },
                series: {
                    selected: true,
                    showCheckbox: true,
                    events: {
                        legendItemClick: function () {
                            return false;
                        },
                        checkboxClick: function () {
                            const series = this as any;
                            if (series.visible) {
                                series.hide();
                            } else {
                                series.show();
                            }
                            return false;
                        },
                    },
                },
            },
            series: seriesData,
        };
        return options;
    }

    return (
        <>
            <div style={{ margin: "4px 4px", border: "2px solid grey" }}>
                <HighchartsReact
                    ref={chartRef}
                    highcharts={Highcharts}
                    constructorType="stockChart"
                    options={chartOptions}
                    callback={(chart) => {
                        chart.update({
                            chart: {
                                events: {
                                    load: () => onLoad(chart),
                                    redraw: () => positionButton(chart),
                                },
                            },
                            plotOptions: {
                                series: {
                                    events: {
                                        legendItemClick: () => false,
                                        checkboxClick: function () {
                                            const curRef = this as any;
                                            onUncheck(curRef.index);
                                        },
                                    },
                                },
                            },
                        });
                    }}
                />
            </div>
        </>
    );
}
