import React, { useCallback } from "react";
import Highcharts from "highcharts/highstock";
import HighchartsReact from "highcharts-react-official";
import StockModule from "highcharts/modules/stock";
StockModule(Highcharts);

import { factors } from "../ma-cfg";
import { seriesCheckboxHandler } from "../ma-helper";

const colors: any = Highcharts?.getOptions()?.colors;

const years = [2020, 2021, 2022, 2023];

function addTimeSeries(arr) {
    const mockData: any = [];
    years?.forEach((y) => {
        arr.map((val, m) => {
            mockData.push([Date.UTC(y, m, 1), Number(val?.toFixed(2))]);
        });
    });
    return mockData;
}

const seriesData = factors?.map((f, i) => {
    const val = i > 0 ? i * 0.1 : -1 * 0.1;
    return {
        name: f,
        visible: true,
        selected: true,
        showCheckbox: true,
        data: addTimeSeries(new Array(10).fill(val)),
        color: colors[i % colors.length],
    };
});

const legendWidth = 200;

const options = {
    chart: {
        type: "line",
        height: 500,
        width: 800,
        style: {
            fontFamily: "Roboto Condensed",
        },
    },
    credits: { enabled: false },
    title: {
        text: "Exposures Over Time",
        align: "left",
        style: { fontWeight: "bold" },
    },
    legend: {
        enabled: true,
        width: legendWidth,
        align: "right",
        verticalAlign: "middle",
        layout: "vertical",
        useHTML: true,
        // labelFormatter: function () {
        //     return "<span>" + (this as any).name + "</span>";
        // },
        legendItemStyle: {
            cursor: "unset",
        },
        itemStyle: {
            textOverflow: "ellipsis",
            overflow: "hidden",
            fontSize: "13px",
            fontWeight: 500,
        },
        itemCheckboxStyle: {
            cursor: "pointer",
            position: "absolute",
            right: "10px",
            marginLeft: "auto",
        },
    },
    yAxis: {
        title: { text: "T-Stat/Beta" },
        opposite: false,
    },
    xAxis: {
        type: "datetime",
        // endOnTick: true,
        tickPositioner: function () {
            const ticks: any = [];
            const start = new Date((this as any).dataMin);
            const end = new Date((this as any).dataMax);
            // Loop through the years and add ticks
            for (let year = start.getFullYear(); year <= end.getFullYear(); year++) {
                const tick = new Date(year + 1, 0, 0).getTime();
                ticks.push(tick);
            }
            return ticks;
        },

        labels: {
            format: "{value:%Y}", // Display only the year on the X-axis labels
        },
        gridLineWidth: 1, // Set the width of the x-axis grid lines
        gridLineDashStyle: "dash", // Set the dash style of the x-axis grid lines
    },
    plotOptions: {
        series: {
            marker: {
                enabled: false,
                states: {
                    hover: {
                        enabled: false,
                    },
                },
            },
            // label: { enabled: false },
        },
    },
    series: seriesData,
};

export default function ExposuresOverTime() {
    const [chartData] = React.useState({ series: seriesData });
    const [chartOptions, setChartOptions] = React.useState<any>(options);
    const chartRef = React.useRef<any>(null);

    React.useEffect(() => {
        setChartOptions({ ...options, series: chartData.series });
        //eslint-disable-next-line
    }, [chartData]);


    React.useEffect(() => {
        if (chartRef?.current) {
            chartRef.current.chart.update({ series: chartOptions.series }, true)
        }
        //eslint-disable-next-line
    }, [chartOptions]);

    function onReset() {
        setChartOptions({
            ...chartOptions,
            series: seriesData
        })
    }

    const onUncheck = useCallback((index) => {
        setChartOptions((prvOptions) => seriesCheckboxHandler(prvOptions, index))
        //eslint-disable-next-line
    }, [chartOptions])

    function getBtnPositions(chart) {
        // const { width } = chart.resetButton.getBBox();
        return {
            x: chart.plotLeft + chart.plotWidth + legendWidth / 2 - 60, //- width,
            y: chart.spacingBox.height - chart.spacing[0], //chart.legend.legendHeight
        };
    }

    function positionButton(chart) {
        chart.resetButton?.animate?.(getBtnPositions(chart));
    }

    function updateBtnAxis(chart) {
        const textRef = chart.resetButton?.element.childNodes[1];
        textRef?.setAttribute("x", 12);
        textRef?.setAttribute("y", 16);
    }

    function onLoad(chart) {
        if (!chart.resetButton) {
            const { x, y } = getBtnPositions(chart);
            chart.resetButton = chart.renderer
                .button("Reset", x, y, onReset.bind(chart))
                .on("mouseleave", () => updateBtnAxis(chart))
                .add();
            const nodes = chart.resetButton?.element.childNodes;
            const textRef = nodes[1];
            const rectRef = nodes[0];
            rectRef.setAttribute("class", "hc-reset-btn");
            rectRef.setAttribute("rx", "3");
            rectRef.setAttribute("ry", "3");
            textRef.setAttribute("class", "hc-rst-btn-text");
            updateBtnAxis(chart);
            positionButton(chart);
        }
    }

    return (
        <>
            <div style={{ margin: "0px 4px", border: "2px solid grey" }}>
                <HighchartsReact
                    // allowChartUpdate={true}
                    ref={chartRef}
                    highcharts={Highcharts}
                    constructorType="stockChart"
                    options={chartOptions}
                    callback={(chart) => {
                        chart.update({
                            chart: {
                                events: {
                                    load: () => onLoad(chart),
                                    redraw: () => positionButton(chart),
                                },
                            },
                            plotOptions: {
                                series: {
                                    events: {
                                        legendItemClick: () => false,
                                        checkboxClick: function () {
                                            const curRef = this as any;
                                            onUncheck(curRef.index);
                                        },
                                    },
                                },
                            },
                        });
                    }}
                />
            </div>
        </>
    );
}
