import React from "react";
import Highcharts from "highcharts/highstock";
import HighchartsReact from "highcharts-react-official";
import StockModule from "highcharts/modules/stock";
StockModule(Highcharts);

const years = [2020, 2021, 2022, 2023];

let base = 22;
function getData() {
    const mockData: any = [];
    years?.forEach((y) => {
        new Array(12).fill(0).map((_, m) => {
            const offset = (m + 1) * 0.2;
            let val: any = base + offset;
            if (m % 2 == 0) {
                val = base - offset;
            }
            mockData.push([Date.UTC(y, m, 1), val]);
        });
        base += 2.5;
    });
    return mockData;
}
const defaultSeriesCfg = { visible: true, selected: true }

const seriesData = [
    {
        ...defaultSeriesCfg,
        name: "Total Risk",
        color: "#ee4a4a",
        data: getData(),
    },
    {
        ...defaultSeriesCfg,
        name: "Factor Risk",
        color: "#a55aaa",
        data: getData(),
    },
    {
        ...defaultSeriesCfg,
        name: "Factor Risk",
        color: "#287fc5",
        data: getData(),
    },
];

const options = {
    chart: {
        type: "line",
        style: {
            fontFamily: "Roboto Condensed",
        },
    },
    credits: { enabled: false },
    title: {
        text: "Aggregate Risk Decomposition",
        align: "left",
        style: { fontWeight: "bold" },
    },
    xAxis: {
        type: "datetime",
        // endOnTick: true,
        tickPositioner: function () {
            const ticks: any = [];
            const start = new Date((this as any).dataMin);
            const end = new Date((this as any).dataMax);
            // Loop through the years and add ticks
            for (let year = start.getFullYear(); year <= end.getFullYear(); year++) {
                const tick = new Date(year + 1, 0, 0).getTime();
                ticks.push(tick);
            }
            return ticks;
        },

        labels: {
            format: "{value:%Y}", // Display only the year on the X-axis labels
            // tickInterval: 30 * 24 * 3600 * 1000
        },
        gridLineWidth: 1, // Set the width of the x-axis grid lines
        gridLineDashStyle: "dash", // Set the dash style of the x-axis grid lines
    },
    yAxis: {
        title: {
            text: "Risk (in %)",
        },
        min: 0,
        max: 100,
        gridLineWidth: 1,
        tickPositions: [0, 50, 100],
    },
    legend: {
        enabled: true,
        layout: "horizontal", // Display the legend horizontally
        verticalAlign: "top", // Align the legend to the top
        y: 40, // Adjust the vertical position of the legend
    },
    plotOptions: {
        series: {
            marker: {
                enabled: false, // Disable the marker for all points
                states: {
                    hover: {
                        enabled: false, // Disable the marker on hover
                    },
                },
            },
        },
    },
    series: seriesData,
    // navigator: {
    //     series: seriesData
    // },
};

export default function AggregateRiskDecomposition() {
    const [chartData] = React.useState({ series: seriesData });
    const [chartOptions, setChartOptions] = React.useState<any>(options);
    const chartRef = React.useRef<any>(null);

    React.useEffect(() => {
        setChartOptions({ ...options, series: chartData.series });
        //eslint-disable-next-line
    }, [chartData]);

    return (
        <div style={{ margin: "4px 4px", border: "2px solid grey" }}>
            <HighchartsReact
                ref={chartRef}
                highcharts={Highcharts}
                constructorType="stockChart"
                options={chartOptions}
            />
        </div>
    );
}
