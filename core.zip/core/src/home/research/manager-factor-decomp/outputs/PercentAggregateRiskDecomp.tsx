import React from "react";
import Highcharts from "highcharts/highstock";
import HighchartsReact from "highcharts-react-official";
import StockModule from "highcharts/modules/stock";

StockModule(Highcharts);

const keys = ["Factor Risk", "Specific Risk"];

const data: any = {};
keys.forEach((key) => {
    data[key] = [];
});
for (let y = 2020; y < 2024; y++) {
    for (let m = 1; m <= 12; m++) {
        keys.forEach((key) => {
            data[key].push([Date.UTC(y, m - 1), Math.random()]);
        });
    }
}

const seriesData: any = [];
Object.entries(data).forEach(([key, values]) => {
    seriesData.push({
        name: key,
        data: values,
    });
});

export default function PercentAggregateRiskDecomp() {
    const [chartData] = React.useState({ series: seriesData });
    const [chartOptions, setChartOptions] = React.useState<any>(getOptions());
    const chartRef = React.useRef<any>(null);

    React.useEffect(() => {
        setChartOptions({ ...getOptions(), series: chartData.series });
        //eslint-disable-next-line
    }, [chartData]);

    React.useEffect(() => {
        if (chartRef?.current) {
            chartRef.current.chart.update({ series: chartOptions.series }, true);
        }
        //eslint-disable-next-line
    }, [chartOptions]);

    function getOptions() {
        const options = {
            chart: {
                type: "column",
                width: 1000,
                style: {
                    fontFamily: "Roboto Condensed",
                },
            },
            title: {
                text: "% Aggregate Risk Decomposition",
                align: "left",
                style: { fontWeight: "bold" },
            },
            legend: {
                enabled: true,
                layout: "horizontal",
                verticalAlign: "top",
            },
            rangeSelector: {
                enabled: false,
            },
            xAxis: {
                type: "datetime",
            },
            yAxis: {
                title: { text: "PCTR (ln %)" },
                opposite: false,
            },
            plotOptions: {
                column: {
                    stacking: "normal",
                    dataLabels: {
                        enabled: false,
                    },
                },
            },
            series: seriesData,
        };
        return options;
    }

    return (
        <>
            <div style={{ margin: "0px 4px", border: "2px solid grey" }}>
                <HighchartsReact
                    ref={chartRef}
                    highcharts={Highcharts}
                    constructorType="stockChart"
                    options={chartOptions}
                />
            </div>
        </>
    );
}
