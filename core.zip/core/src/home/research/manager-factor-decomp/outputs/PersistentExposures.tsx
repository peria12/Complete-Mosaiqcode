import React, { useRef, useEffect } from "react";
import * as d3 from "d3";
import { factors } from "../ma-cfg";

const colors = {
    left: "#d9b3cb",
    right: "#c74697",
};

const seriesData = Array.from(
    { length: 16 },
    () => Array.from({ length: 10 }, () => Math.floor(Math.random() * 40)) //.sort((a, b) => a - b)
);
const boxTitlesList = [...factors];

const Width = 550;
const boxHeight = 23;
const boxPadding = 15;
const medianLineOffset = 6;
const legendWidth = 260;

export default function PersistentExposures() {
    const chartRef = useRef(null);
    const [chartData, setChartData] = React.useState({
        boxTitles: boxTitlesList,
        series: seriesData,
        currExposure: [],
    });

    useEffect(() => {
        renderGraph();
        //eslint-disable-next-line
    }, [chartData]);

    function getHeight(data: any = []) {
        const totalItems = data?.length + 1;
        return (boxHeight + boxPadding) * totalItems + 60;
    }

    function onReset() {
        setChartData((cd) => ({
            ...cd,
            boxTitles: boxTitlesList,
            series: seriesData,
        }));
    }

    function onUncheck(factor) {
        const list = chartData?.boxTitles || [];
        const index = list.indexOf(factor);
        if (index !== -1) {
            setChartData((cd) => ({
                ...cd,
                boxTitles: chartData?.boxTitles?.filter((item) => factor != item),
                series: chartData?.series?.filter((_, i) => i != index),
            }));
        }
    }

    function renderGraph() {
        const data = chartData?.series || [];
        const boxTitles = chartData?.boxTitles || [];
        const Height = getHeight(data);
        const margin = { top: 0, right: 20, bottom: 30, left: 20 };
        const width = Width - margin.left - margin.right;
        const height = Height - margin.top - margin.bottom;
        const svg = d3.select(chartRef.current);
        svg.selectAll("g").remove();

        svg.attr("width", width + margin.left + margin.right + legendWidth)
            .attr("height", height + margin.top + margin.bottom)
            .attr("top", margin.top)
            .attr("bottom", margin.bottom)
            .attr("left", margin.bottom)
            .attr("right", margin.bottom)
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        // Draw x-axis
        const xScale = d3
            .scaleLinear()
            .domain([d3.min(data, (d) => d3.min(d)), d3.max(data, (d) => d3.max(d))])
            .range([10, width]);

        const xAxis = d3.axisBottom(xScale);
        const xAxisGrid = xAxis.tickSize(-height).ticks().tickSizeOuter(0);

        svg.append("g")
            .attr("class", "axis-grid-dash")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxisGrid);

        // Draw boxes for each set of data
        let medianLineY1 = boxHeight + boxPadding - medianLineOffset;

        for (let index = 0; index < data.length; index++) {
            const boxPlot = svg.append("g").attr("class", "box-plot");
            const boxData = data[index];
            const i = index + 1;
            // Calculate quartiles, median, min, and max
            const minVal = d3.min(boxData);
            const maxVal = d3.max(boxData);
            const q1 = d3.quantile(boxData, 0.25);
            const median = d3.quantile(boxData, 0.5);
            const q3 = d3.quantile(boxData, 0.75);
            // const boxCenter = xScale((q1 + q3) / 2);

            // Draw lines from the center of the box to the min and max values
            boxPlot
                .append("line")
                .attr("style", "stroke:black")
                .attr("x1", xScale(minVal))
                .attr("x2", xScale(maxVal))
                .attr("y1", i * (boxHeight + boxPadding) + boxHeight / 2)
                .attr("y2", i * (boxHeight + boxPadding) + boxHeight / 2);

            // Draw the lower part of the box
            boxPlot
                .append("rect")
                .attr("style", "fill:" + colors?.left)
                .attr("x", xScale(q1))
                .attr("y", i * (boxHeight + boxPadding))
                .attr("width", xScale(median) - xScale(q1))
                .attr("height", boxHeight);

            // Draw the upper part of the box
            boxPlot
                .append("rect")
                .attr("style", "fill:" + colors?.right)
                .attr("x", xScale(median))
                .attr("y", i * (boxHeight + boxPadding))
                .attr("width", xScale(q3) - xScale(median))
                .attr("height", boxHeight);

            const medianLineY2 = medianLineY1 + boxHeight + medianLineOffset * 2;

            // Draw the median line
            boxPlot
                .append("line")
                .attr("class", "line")
                .attr("style", "stroke-dasharray: 3,2;")
                .attr("x1", xScale(median))
                .attr("x2", xScale(median))
                .attr("y1", medianLineY1)
                .attr("y2", medianLineY2);

            medianLineY1 = medianLineY2 + boxPadding - medianLineOffset * 2;

            // Draw the whiskers
            boxPlot
                .selectAll(".whisker" + i)
                .data([minVal, maxVal])
                .enter()
                .append("line")
                .attr("class", "line")
                .attr("x1", (d) => xScale(d))
                .attr("x2", (d) => xScale(d))
                .attr("y1", i * (boxHeight + boxPadding))
                .attr("y2", i * (boxHeight + boxPadding) + boxHeight);

            // draw Current exposure
            boxPlot
                .append("circle")
                .style("cursor", "pointer")
                .attr("cx", xScale(q1) + 250)
                .attr("cy", i * (boxHeight + boxPadding) + 12)
                .attr("r", 4)
                .attr("fill", "white")
                .attr("stroke", "black")
                .attr("stroke-width", 0.5)
                .append("title")
                .text("Current Exposure");

            // draw label and checkbox
            const legendYAxis = i * (boxHeight + boxPadding);
            const legendXAxis = width + 40;
            boxPlot
                .append("foreignObject")
                .attr("class", "checkbox-base")
                .attr("transform", `translate(${legendXAxis + legendWidth * 0.8}, ${legendYAxis})`)
                .append("xhtml:input")
                .attr("class", "checkbox")
                .attr("type", "checkbox")
                .attr("checked", true)
                .on("click", () => onUncheck(boxTitles[index]));

            boxPlot
                .append("text")
                .attr("x", legendXAxis)
                .attr("y", legendYAxis + 15)
                .text(boxTitles[index]);
        }

        // add x-axis label
        const axisLabelGrp = svg.append("g");
        axisLabelGrp
            .append("text")
            .attr("class", "axis-label")
            .attr("text-anchor", "end")
            .attr("x", Width / 2)
            .attr("y", Height - 4)
            .text("T-Stat/Beta");

        //reset button
        const resetBtn = svg
            .append("g")
            .attr("transform", `translate(${width + legendWidth * 0.8},${Height - 50})`)
            .attr("cursor", "pointer")
            .on("click", onReset);

        resetBtn.append("rect").attr("class", "chart-reset-btn");

        resetBtn
            .append("text")
            .attr("class", "btn-text")
            .attr("dx", "30")
            .attr("dy", "18")
            .attr("text-anchor", "middle")
            .text("Reset");
    }

    return (
        <>
            <div
                style={{
                    margin: "6px 0px",
                    padding: 4,
                    border: "2px solid grey",
                    height: 750,
                    minHeight: 300,
                    overflowY: "scroll",
                    overflowX: "hidden",
                }}
            >
                <svg id="persistent-exposures-chart" ref={chartRef} />
            </div>
        </>
    );
}
