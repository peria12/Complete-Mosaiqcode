import React, { useState } from "react";
import AppCover from "home/dashboad/AppCover";
import SearchInput from "common/SearchInput";
import { FTIconButton } from "common/FTButtons";
import ShareWith from "common/ShareWith";
import ShareIcon from "@mui/icons-material/Share";
import CopyAllIcon from "@mui/icons-material/CopyAll";
import DriveFileRenameOutlineIcon from "@mui/icons-material/DriveFileRenameOutline";
import Card from "@mui/material/Card";
import CloseIcon from "@mui/icons-material/Close";
import DeleteIcon from "@mui/icons-material/Delete";
import { ManagerAnalysisContext } from "utils/context";
import Access from "utils/access";
import "./ma.scss";
import { defaultFormData } from "./ma-helper";
import SelectInput from "./SelectInput";
import { AdornedButton } from "common/FTButtons";
import { sortList, hasAccess, squareBtnStyle, authorStyle, searchStyles } from "utils/so-helpers";
import Outputs from "./outputs/Outputs";

// import errorNotification from "utils/api-error";
// import Api from "utils/api";

const RenderOption = function (props, option, deleteOption) {
    return (
        <li {...props} key={option.id} style={{ fontSize: "14px" }}>
            <div style={{ display: "flex", width: "90%", justifyContent: "space-between" }}>
                <div className="col-12">
                    {option.label}
                    {option.author && <span style={authorStyle}>({option.author})</span>}
                </div>
                {typeof deleteOption === "function" && !option.author && (
                    <DeleteIcon
                        className="delete-icon"
                        style={{ color: "red", marginRight: "10px" }}
                        onClick={(e) => {
                            e.stopPropagation();
                            deleteOption(option);
                        }}
                    />
                )}
            </div>
        </li>
    );
};

function MenuBar() {
    const style = { marginLeft: 5 };
    return (
        <div className="menu-bar-base">
            <SelectInput field="workflow" placeholder="Select Workflow" />
            <SelectInput field="funds" type="popover" placeholder="Select Fund" styles={style} />
            <SelectInput field="benchmarks" type="popover" placeholder="Choose Benchmark(s)" styles={style} />
        </div>
    );
}

function FundVsBenchmarks({ fund, bench, setFormData }) {
    function RemoveBtn({ id }) {
        const style = { fontSize: "1.1rem", color: "grey" };
        return (
            <FTIconButton
                handler={() => setFormData((fd) => ({ ...fd, [id]: [] }))}
                title="Remove"
                style={{ padding: 0, cursor: "pointer" }}
                btnIcon={<CloseIcon style={style} color="primary" />}
                placement="top"
            />
        );
    }

    return (
        <div className="ma-fund-vs-bench-list">
            <RemoveBtn id="funds" />
            <span className="text">{fund} </span>
            <span style={{ color: "#C5C5C5", fontSize: 14, padding: "0px 4px" }}> vs </span>
            <span className="text"> {bench} </span>
            <RemoveBtn id="benchmarks" />
            <AdornedButton
                className="green-btn"
                variant="outlined"
                size="small"
                // onClick={undefined}
                // loading={loaders?.run}
                // disabled={false}
            >
                Run
            </AdornedButton>
        </div>
    );
}

export default function ManagerAnalysisContainer({ app, type }) {
    const [formData, setFormData] = useState<any>({ ...defaultFormData });
    const [filters, setFilters] = useState<any>({});
    const [deletePopup, setDeletePopup] = useState<any>({ open: false, deleteObj: null, deleted: false });
    const [shareInfo, setShareInfo] = useState<any>({ open: false, shareBtnRef: null, data: null });

    function updateFormData(key, value) {
        setFormData((fd) => ({ ...fd, [key]: value }));
    }

    function handleAction(action) {
        console.log("OP", app, type, action);
    }

    const deleteOption = (deleteObj) => {
        setDeletePopup({ ...deletePopup, open: true, deleteObj });
    };

    function isDisabled(isCopy = false) {
        const value = formData?.template?.id;
        if (!value) {
            return true;
        }
        const template = formData?.templateList?.find((t) => t.id == value);
        if (value != template?._id?.$oid) {
            return true;
        }
        if (isCopy) {
            return false;
        }
        if (template?.["author-id"] && hasAccess(template)) {
            return false;
        }
        return true;
    }

    const getIconStyle = (isCopy = false) => {
        return isDisabled(isCopy) ? { ...squareBtnStyle, opacity: 0.4 } : squareBtnStyle;
    };

    function onShare(e, valueObj) {
        if (hasAccess(valueObj?._meta)) {
            setShareInfo({ open: true, shareBtnRef: e.currentTarget, data: valueObj });
        }
    }

    function refreshData() {
        //
    }

    const templateAuthor = formData?.template?.author;
    const userInfo = Access.userInfo || {};
    const funds = formData["funds"] || [];
    const benchmarks = formData["benchmarks"] || [];
    return (
        <ManagerAnalysisContext.Provider value={{ formData, setFormData, filters, setFilters }}>
            <AppCover
                className="manager-analysis"
                header={
                    <div className="saa template-input-grp">
                        <div className="input-field w-100">
                            <SearchInput
                                onChange={(_, v) => updateFormData("template", v)}
                                onInputChange={(e, v) => {
                                    if (e?.type === "change") {
                                        updateFormData("template", { id: null, name: v });
                                    }
                                }}
                                options={sortList(formData?.templateList)}
                                value={formData?.templateList?.find((t) => t.id == formData?.template?.id)}
                                placeholder="Template Name.."
                                inputPropsStyle={{ ...searchStyles, minWidth: "215px" }}
                                disableUnderline={true}
                                forcePopupIcon={true}
                                popperWidth="300px"
                                searchIcon={false}
                                renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                            />
                            <FTIconButton
                                handler={handleAction("copy")}
                                title={"Copy"}
                                btnIcon={<CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                                placement="top"
                                disabled={isDisabled(true)}
                                style={getIconStyle(true)}
                            />
                            <FTIconButton
                                handler={handleAction("rename")}
                                title={"Rename"}
                                btnIcon={
                                    <DriveFileRenameOutlineIcon
                                        style={{ fontSize: "1.1rem", color: "grey" }}
                                        color="primary"
                                    />
                                }
                                placement="top"
                                disabled={isDisabled()}
                                style={getIconStyle()}
                            />
                            <FTIconButton
                                handler={(e) => onShare(e, formData?.template?.id)}
                                title={shareInfo.open ? "" : "Share"}
                                btnIcon={<ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                                placement="top"
                                disabled={isDisabled()}
                                style={getIconStyle()}
                            />
                            <ShareWith
                                shareInfo={shareInfo}
                                setShareInfo={setShareInfo}
                                refreshData={refreshData}
                                setBenchmarkModelData={() => {
                                    return null;
                                }}
                            />
                            <div className="temp-input-grp2 saa-template-selector">
                                <div className="input-label w-100" style={{ textAlign: "left" }}>
                                    Created by
                                </div>
                                <div className="label-value capitalize" style={{ width: "100%" }}>
                                    {templateAuthor ? templateAuthor : userInfo?.name}
                                </div>
                            </div>
                        </div>
                    </div>
                }
            >
                <div className="manager-analysis">
                    {formData?.workflow && (
                        <Card raised className="ma-select-card">
                            <div style={{ padding: "10px 6px" }}>
                                {" "}
                                <MenuBar />{" "}
                            </div>
                            {(funds[0] || benchmarks[0]) && (
                                <FundVsBenchmarks fund={funds[0]} bench={benchmarks[0]} setFormData={setFormData} />
                            )}
                        </Card>
                    )}
                    {!formData?.workflow && <MenuBar />}
                    <Outputs />
                </div>
            </AppCover>
        </ManagerAnalysisContext.Provider>
    );
}
