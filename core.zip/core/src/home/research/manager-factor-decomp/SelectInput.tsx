import React, { useState, useEffect, useMemo } from "react";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Popover from "@mui/material/Popover";
import Button from "@mui/material/Button";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { ReactComponent as FilterIcon } from "assets/ft-icons/filter.svg";
import { AdornedButton } from "common/FTButtons";
import SearchBox from "common/SearchBox";
import { globalSearch } from "utils/helpers";
import { workflows } from "./ma-helper";
import CloseIcon from "@mui/icons-material/Close";
import { FTIconButton } from "common/FTButtons";
import Checkbox from "@mui/material/Checkbox";
import { filterOptions } from "./ma-helper";
import { ManagerAnalysisContext } from "utils/context";

const listClass = "manager-analysis-menu-item";

function FilterList({ values, name, header, list, separator = false, updateFilter }) {
    return (
        <div className="filter-list" style={separator ? { borderLeft: "1px solid #E5E5E5" } : {}}>
            <div className="filter-list-name">{header}</div>
            <div style={{ maxWidth: 360 }}>
                {list?.map((value) => {
                    const labelId = `checkbox-list-label-${value}`;
                    return (
                        <div key={labelId} className="list-item" onClick={() => updateFilter(name, value)}>
                            <Checkbox
                                className="item-checkbox"
                                size="small"
                                edge="start"
                                checked={values?.includes(value)}
                                disableRipple
                                inputProps={{ "aria-labelledby": labelId }}
                            />
                            {value}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

function FilterOptions({ filterInfo }) {
    const { filters, setFilters } = React.useContext(ManagerAnalysisContext);
    const { field, section } = filterInfo;
    const filter = filters?.[field]?.[section] || {};

    function updateFilter(name, value) {
        let updatedList: any = [];
        const values = filter?.[name] || [];
        if (values?.includes(value)) {
            updatedList = values?.filter((v) => value != v);
        } else {
            updatedList = [...values, value];
        }
        setFilters((f) => ({
            ...f,
            [field]: {
                ...f?.[field],
                [section]: {
                    ...f?.[field]?.[section],
                    [name]: updatedList,
                },
            },
        }));
    }

    function clearFilter() {
        setFilters((f) => ({
            ...f,
            [field]: {
                ...f?.[field],
                [section]: {},
            },
        }));
    }

    return (
        <div className="manager-analysis-popover ma-filter-popover-base">
            <div className="ma-filter-popover">
                {filterOptions?.map(({ field, name, list }, i) => {
                    return (
                        <FilterList
                            key={field}
                            name={field}
                            header={name}
                            list={list}
                            values={filter?.[field] || []}
                            updateFilter={updateFilter}
                            separator={i != 0 ? true : false}
                        />
                    );
                })}
            </div>
            <div className="d-flex justify-content-end">
                <AdornedButton className="clear-btn m-1" variant="outlined" size="small" onClick={clearFilter}>
                    Clear
                </AdornedButton>
            </div>
        </div>
    );
}
function FilterSection({ field, label, section, setFilterInfo }) {
    const { formData, setFormData, filters } = React.useContext(ManagerAnalysisContext);
    const [searchText, setSearchText] = useState("");
    const [searchResults, setSearchResults] = useState<any>([]);
    const [btnStyle, setBtnStyle] = useState<any>({ index: null });

    const options = useMemo(() => formData?.groups?.[field]?.[section] || [], [formData, field, section]);
    const filter = useMemo(() => filters?.[field]?.[section], [filters, field, section]);
    const values = useMemo(() => formData?.[field], [formData, field]);

    useEffect(() => {
        let results: any = [];
        let items: any = JSON.parse(JSON.stringify(options));

        if (filter && items?.length) {
            Object.keys(filter)?.map((key) => {
                const values = filter[key] || [];
                if (values?.length) {
                    items = items?.filter((item) => values.includes(item[key]));
                }
            });
        }
        if (searchText) {
            results = globalSearch(items, searchText, 0, ["value"]);
        } else {
            results = items;
        }
        setSearchResults(results);
    }, [filter, searchText, options]);

    // eslint-disable-next-line react-hooks/exhaustive-deps

    function isFavorite(item) {
        const favorites = formData?.groups?.[field]?.favorites || [];
        return favorites?.find((e) => e.key == item.key);
    }

    function updateFavorites(item, action) {
        let favorites = [...(formData?.groups?.[field]?.favorites || [])];
        if (action == "add") {
            if (!favorites?.find((e) => e.key == item.key)) {
                favorites.push(item);
            }
        } else {
            const items = [...favorites];
            favorites = items?.filter((e) => e.key != item.key);
        }
        setFormData((fd) => ({
            ...fd,
            groups: {
                ...fd.groups,
                [field]: {
                    ...fd.groups[field],
                    favorites: favorites,
                },
            },
        }));
    }

    function onSelect(value) {
        // single fund
        let selected: any = [];
        if (values?.includes(value)) {
            selected = [];
        } else {
            selected = [value];
        }
        setFormData((fd) => ({ ...fd, [field]: selected }));
    }

    return (
        <div className="section">
            <div className="section-header">{label}</div>
            <div className="section-body">
                <div className="d-flex align-items-center">
                    <SearchBox
                        setSearchText={setSearchText}
                        placeholder=" "
                        style={{ width: "100%", borderBottom: "1px solid #E5E5E5", padding: 0 }}
                        searchIconPosition="end"
                    />
                    <div
                        className="filter-icon"
                        onClick={(e) => {
                            e.stopPropagation();
                            setFilterInfo({ open: true, btnRef: e?.currentTarget, field, section });
                        }}
                    >
                        <FilterIcon />
                    </div>
                </div>
                <div className="list-panel" style={section == "favorites" ? { height: 80 } : undefined}>
                    {searchResults?.map((ele, i) => {
                        let itemStyle = {};
                        if (values.includes(ele.key)) {
                            itemStyle = { background: "rgba(53, 93, 209, 0.20)" };
                        }
                        if (section == "favorites") {
                            return (
                                <div
                                    key={ele.key}
                                    className="d-flex ma-list-item"
                                    onMouseEnter={() => setBtnStyle({ index: i })}
                                    onMouseLeave={() => setBtnStyle({ index: null })}
                                    onClick={() => onSelect(ele.key)}
                                    style={itemStyle}
                                >
                                    <div style={{ width: `calc(100% - 18px)` }}>{ele.value}</div>
                                    <div className="d-flex align-items-center" style={{ width: 18 }}>
                                        <FTIconButton
                                            handler={(e) => {
                                                e.stopPropagation();
                                                updateFavorites(ele, "remove");
                                            }}
                                            title="Remove"
                                            style={{
                                                padding: "0px",
                                                cursor: "pointer",
                                                display: i == btnStyle.index ? "block" : "none",
                                            }}
                                            btnIcon={
                                                <CloseIcon
                                                    style={{ fontSize: "1.2rem", color: "grey" }}
                                                    color="primary"
                                                />
                                            }
                                            placement="top"
                                        />
                                    </div>
                                </div>
                            );
                        }
                        return (
                            <div
                                key={ele.key}
                                className="d-flex ma-list-item"
                                onMouseEnter={() => setBtnStyle({ index: i })}
                                onMouseLeave={() => setBtnStyle({ index: null })}
                                onClick={() => onSelect(ele.key)}
                                style={itemStyle}
                            >
                                <div style={{ width: `calc(100% - 40px)` }}>
                                    {isFavorite(ele) ? <b>*</b> : ""}
                                    {ele.value}
                                </div>
                                <div className="d-flex align-items-center" style={{ width: 40 }}>
                                    <button
                                        className="add-fav-btn"
                                        style={{
                                            cursor: "pointer",
                                            display: i == btnStyle.index ? "block" : "none",
                                        }}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            updateFavorites(ele, "add");
                                        }}
                                    >
                                        *Add
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

export default function SelectInput({ field, placeholder, styles = {}, type = "" }: any) {
    const [popoverInfo, setPopoverInfo] = useState<any>({ open: false, btnRef: null });
    const [filterInfo, setFilterInfo] = useState<any>({ open: false, btnRef: null });
    const { formData, setFormData } = React.useContext(ManagerAnalysisContext);
    const values = useMemo(() => formData?.[field] || [], [formData, field]);

    if (type == "popover") {
        return (
            <>
                {formData?.workflow && (
                    <div style={styles}>
                        <Button
                            className="select-base popover-btn"
                            size="small"
                            variant="outlined"
                            onClick={(e) => setPopoverInfo({ open: true, btnRef: e?.currentTarget })}
                            endIcon={<ArrowDropDownIcon style={{ fontSize: "20px", color: "rgba(0, 0, 0, 0.54)" }} />}
                        >
                            <span className="value-text">{values[0] || placeholder}</span>
                        </Button>
                        <Popover
                            id={placeholder?.split(" ")?.join("_")}
                            open={popoverInfo?.open}
                            onClose={() => setPopoverInfo({ open: false, btnRef: null })}
                            anchorEl={popoverInfo?.btnRef}
                            anchorOrigin={{ vertical: "top", horizontal: "left" }}
                            transformOrigin={{ vertical: "top", horizontal: "left" }}
                            disableRestoreFocus
                        >
                            <div className="manager-analysis-popover">
                                <div className="section-title">{placeholder}</div>
                                <FilterSection
                                    field={field}
                                    section="favorites"
                                    label="Favorites"
                                    setFilterInfo={setFilterInfo}
                                />

                                {field == "benchmarks" && (
                                    <FilterSection
                                        field={field}
                                        section="benchmark_list"
                                        label="Benchmarks"
                                        setFilterInfo={setFilterInfo}
                                    />
                                )}
                                <FilterSection
                                    field={field}
                                    section="coverage_list"
                                    label="Funds - Coverage List"
                                    setFilterInfo={setFilterInfo}
                                />
                                <FilterSection
                                    field={field}
                                    section="outside_coverage_list"
                                    label="Other Funds - Outside Coverage"
                                    setFilterInfo={setFilterInfo}
                                />
                            </div>
                        </Popover>
                        <Popover
                            id={"ma-filter-popover"}
                            open={filterInfo?.open}
                            onClose={() => setFilterInfo({ open: false, btnRef: null })}
                            anchorEl={filterInfo?.btnRef}
                            anchorOrigin={{ vertical: "top", horizontal: "right" }}
                            transformOrigin={{ vertical: "top", horizontal: "left" }}
                            disableRestoreFocus
                            style={{ marginLeft: 10 }}
                        >
                            {filterInfo?.open && <FilterOptions filterInfo={filterInfo} />}
                        </Popover>
                    </div>
                )}
            </>
        );
    }

    return (
        <Select
            displayEmpty
            value={formData?.[field]}
            onChange={(e) => setFormData((fd) => ({ ...fd, [field]: e.target.value }))}
            SelectDisplayProps={{ className: "select-base" }}
            style={styles}
        >
            <MenuItem disabled value="" className={listClass} style={{ opacity: 1, color: "#355dd1" }}>
                {placeholder}
            </MenuItem>
            {workflows?.map((o) => (
                <MenuItem
                    key={o.key}
                    value={o.value}
                    className={listClass}
                    style={
                        formData?.[field] == o.key
                            ? { color: "#2A2A2A", background: "rgba(53, 93, 209, 0.20)" }
                            : { background: "#fff" }
                    }
                >
                    {o.value}
                </MenuItem>
            ))}
        </Select>
    );
}
