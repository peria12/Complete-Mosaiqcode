import React, { useState } from "react";
import { getUuid } from "utils/helpers";
import TextField from "@mui/material/TextField";
import moment from "moment";
import { AdornedButton, FTIconButton } from "common/FTButtons";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import Divider from "@mui/material/Divider";
import CancelIcon from "@mui/icons-material/Cancel";
import { useStyles } from "./dashboard-style";
import FundInfo from "./FundInfo";
import ModalDialog from "./ModelDialog";
import AutoCompleteSelect from "./AutoCompleteSelect";
import DynamicFeedIcon from "@mui/icons-material/DynamicFeed";
import { DesktopDatePicker } from "@mui/x-date-pickers/DesktopDatePicker";
import FTSelect from "common/FTSelect";
import { Tooltip } from "@mui/material";
import AnalysisMenu from "./AnalysisMenu";
export default function PortfolioAnalysisDashBoard({
    group,
    setGroup,
    formData,
    setFormData,
    dashboardMeta = {},
    dates,
    setDates,
    models,
    setModels,
    lastModel,
    currencyList,
    resetFactors,
    resetBetaProfiles,
    analysis,
    updateAnalysis,
    clearPage,
    selectedAnalysis,
    selectAnalysis,
}: any) {
    const classes = useStyles();
    const [open, setOpen] = useState(false);
    const [inputInfo, setInputInfo] = useState(dashboardMeta?.inputInfo || { id: "", list: [] });
    const [betaProfile, setBetaProfile] = useState(dashboardMeta?.betaProfile || { id: "", label: "" });

    function formDataOnchange(id, value) {
        let newFormData = { ...formData };
        if (id == "fromDate" || id == "toDate") {
            setDates({ ...dates, [id]: moment(value).endOf("month").format("YYYY-MM-DD") });
        } else {
            newFormData = { ...formData, [id]: value };
            setFormData(newFormData);
        }
    }

    function createNewModal(id) {
        setInputInfo({ ...inputInfo, id: id });
        setOpen(true);
    }

    const isAddBtnDisabled = (groupId, fundId, benchId) => {
        if (groupId == "factors") {
            const firstFactGrp = group?.["factors"]?.[0];
            if (!firstFactGrp || isDisabledFactBenchmark()) {
                return ![undefined, null, ""].includes(formData?.[fundId]?.id);
            }
        }
        return (
            ![undefined, null, ""].includes(formData?.[fundId]?.id) &&
            ![undefined, null, ""].includes(formData?.[benchId]?.id)
        );
    };

    function isDisabledFactBenchmark() {
        const firstFactGrp = group?.["factors"]?.[0];
        if (firstFactGrp && ["", undefined, null].includes(firstFactGrp?.factBenchmark?.id)) {
            return true;
        }
        return false;
    }

    function addGroup(groupId, fundId, benchId) {
        if (isAddBtnDisabled(groupId, fundId, benchId)) {
            const list = [
                ...(group[groupId] || []),
                {
                    id: getUuid(),
                    [fundId]: formData?.[fundId] || {},
                    [benchId]: formData?.[benchId] || {},
                },
            ];
            const newGroups = { ...group, [groupId]: list };
            const newFormData = {
                ...formData,
                [fundId]: { id: "", label: "", entries: [] },
                [benchId]: {
                    id: "",
                    label: "",
                    entries: [],
                },
            };
            setGroup(newGroups);
            setFormData(newFormData);
        }
    }

    function removeBetaProfile(id) {
        const list = [...formData.betaProfile] || [];
        const index = list.findIndex((e) => e.id == id);
        list.splice(index, 1);
        const newFormData = { ...formData, betaProfile: list };
        setFormData(newFormData);
    }

    function addBetaProfile() {
        if (betaProfile?.id) {
            let updatedList: any = [];
            const list = formData?.betaProfile || [];
            const defaultBetaProfile = { id: "", label: "" };
            if (!list.find((e) => e.id == betaProfile?.id)) {
                updatedList = [...list, betaProfile];
                const newFormData = { ...formData, betaProfile: updatedList };
                setFormData(newFormData);
            }
            setBetaProfile({ ...defaultBetaProfile });
        }
    }

    function onBetaProfileChange(info) {
        const betaProfileInfo = {
            id: info?.mstar_id || info?.fs_bm_id,
            label: info ? info.label : "",
            mstar_id: info?.mstar_id,
            fs_bm_id: info?.fs_bm_id,
            type: info?.type,
        };
        setBetaProfile(betaProfileInfo);
    }

    function onDelete(grpId, info) {
        const list = [...group[grpId]];
        const index = group[grpId]?.findIndex((e) => e.id == info.id);
        list.splice(index, 1);
        const newGroup = { ...group, [grpId]: list };
        setGroup(newGroup);
    }

    function onAutoCompleteChange(id, info) {
        const formInfo = {
            [id]: {
                ...formData[id],
                id: info ? info.id : "",
                label: info ? info.label : "",
                bb_ticker: info?.bb_ticker || "",
                model_id: info?.model ? info?.id : null,
                entries: info?.entries || [],
                mstar_id: info?.mstar_id,
                fs_bm_id: info?.fs_bm_id,
                entity_name: info?.entity_name,
                symbol: info?.symbol,
                type: info?.type,
            },
        };
        const newFormData = { ...formData, ...formInfo };
        setFormData(newFormData);
    }
    // const valueLabelFormat = (value) => `${value}%`;
    const onCopy = (item) => {
        setFormData({ ...formData, ...item });
    };
    const maxDate = moment().startOf("month").add(-1, "days").toDate();
    const currencyOptions = currencyList.map((x) => ({ key: x, value: x }));

    return (
        <div className={classes.base}>
            <div className={classes.leftPanel}>
                <ModalDialog
                    open={open}
                    setOpen={setOpen}
                    fieldId={inputInfo?.id}
                    onModelChange={setModels}
                    onModelSelect={onAutoCompleteChange}
                    models={models}
                    setModels={setModels}
                    lastModel={lastModel}
                    group={group}
                />
                <div className="d-flex mb-3">
                    <div style={{ width: "12em" }} className="pe-4">
                        <DesktopDatePicker
                            views={["year", "month"]}
                            label="Start Date"
                            openTo="month"
                            maxDate={maxDate}
                            value={dates.fromDate}
                            renderInput={(props) => <TextField size="small" variant="standard" {...props} />}
                            onChange={(value) => formDataOnchange("fromDate", value)}
                        />
                    </div>
                    <div style={{ width: "12em" }} className="pe-4">
                        <DesktopDatePicker
                            views={["year", "month"]}
                            openTo="month"
                            label="End Date"
                            maxDate={maxDate}
                            value={dates.toDate}
                            renderInput={(props) => <TextField size="small" variant="standard" {...props} />}
                            onChange={(value) => formDataOnchange("toDate", value)}
                        />
                    </div>
                    <div style={{ width: "10em" }} className="pe-4">
                        <FTSelect
                            label="Currency"
                            value={formData.currency}
                            onChange={(val) => formDataOnchange("currency", val)}
                            options={currencyOptions}
                        />
                    </div>
                    <div style={{ display: "flex", alignItems: "center", paddingTop: "7px" }}>
                        <AnalysisMenu
                            analysis={analysis}
                            updateAnalysis={updateAnalysis}
                            selectedAnalysis={selectedAnalysis}
                            selectAnalysis={selectAnalysis}
                            clearPage={clearPage}
                        />
                    </div>
                </div>

                <Paper elevation={3} style={{ padding: "8px 0" }}>
                    <Typography style={{ paddingLeft: "12px" }} align="left" component="h3" variant="subtitle1">
                        Funds
                    </Typography>
                    <div className={classes.container}>
                        <div className={classes.item + " " + classes.separator} style={{ width: "25%" }}>
                            <div className={classes.formControl}>
                                <AutoCompleteSelect
                                    fieldId="fund"
                                    value={formData?.fund}
                                    placeholder="Fund"
                                    handleChange={onAutoCompleteChange}
                                />
                                <FTIconButton
                                    handler={() => createNewModal("fund")}
                                    title="Add Model"
                                    btnIcon={<DynamicFeedIcon />}
                                    placement="top"
                                />
                            </div>
                            <div className={classes.formControl}>
                                <AutoCompleteSelect
                                    fieldId="benchmark"
                                    value={formData?.benchmark}
                                    placeholder="Benchmark"
                                    handleChange={onAutoCompleteChange}
                                />
                                <FTIconButton
                                    handler={() => createNewModal("benchmark")}
                                    title="Add Model"
                                    btnIcon={<DynamicFeedIcon />}
                                    placement="top"
                                />
                            </div>
                            <div className={classes.formControl} style={{ justifyContent: "end" }}>
                                <AdornedButton
                                    style={{ marginLeft: "8px" }}
                                    className={classes.btn}
                                    variant="contained"
                                    color="primary"
                                    size={"small"}
                                    onClick={() => addGroup("funds", "fund", "benchmark")}
                                    disabled={!isAddBtnDisabled("funds", "fund", "benchmark")}
                                >
                                    Add Fund
                                </AdornedButton>
                            </div>
                        </div>
                        <div className={classes.item} style={{ width: "75%" }}>
                            <div className="d-flex flex-wrap">
                                {group?.funds?.map((ele, i) => (
                                    <FundInfo
                                        key={i}
                                        groupId="funds"
                                        item={ele}
                                        index={i}
                                        onDelete={(info) => onDelete("funds", info)}
                                        onCopy={onCopy}
                                        models={models}
                                    />
                                ))}
                            </div>
                        </div>
                    </div>
                </Paper>

                <Paper elevation={3} style={{ padding: "8px 0", marginTop: "12px" }}>
                    <Typography style={{ paddingLeft: "12px" }} align="left" component="h3" variant="subtitle1">
                        Factors &nbsp; &nbsp;
                        <Tooltip title="Restore defaults">
                            <button className="btn btn-secondary btn-sm" onClick={resetFactors}>
                                <i className="fas fa-undo"></i>
                            </button>
                        </Tooltip>
                    </Typography>
                    <div className={classes.container}>
                        <div className={classes.item + " " + classes.separator} style={{ width: "25%" }}>
                            <div className={classes.formControl}>
                                <AutoCompleteSelect
                                    fieldId="factFund"
                                    value={formData?.factFund}
                                    placeholder="Fund"
                                    handleChange={onAutoCompleteChange}
                                />
                                <FTIconButton
                                    handler={() => createNewModal("factFund")}
                                    title="Add Model"
                                    btnIcon={<DynamicFeedIcon />}
                                    placement="top"
                                />
                            </div>
                            <div className={classes.formControl}>
                                <AutoCompleteSelect
                                    fieldId="factBenchmark"
                                    value={formData?.factBenchmark}
                                    placeholder="Benchmark"
                                    handleChange={onAutoCompleteChange}
                                    disabled={isDisabledFactBenchmark()}
                                />
                                <FTIconButton
                                    handler={() => createNewModal("factBenchmark")}
                                    title="Add Model"
                                    btnIcon={<DynamicFeedIcon />}
                                    placement="top"
                                />
                            </div>
                            <div className={classes.formControl} style={{ justifyContent: "end" }}>
                                <AdornedButton
                                    style={{ marginLeft: "8px" }}
                                    className={classes.btn}
                                    variant="contained"
                                    color="primary"
                                    size={"small"}
                                    onClick={() => addGroup("factors", "factFund", "factBenchmark")}
                                    disabled={!isAddBtnDisabled("factors", "factFund", "factBenchmark")}
                                >
                                    Add Factor
                                </AdornedButton>
                            </div>
                        </div>
                        <div className={classes.item} style={{ width: "75%" }}>
                            <div className={classes.cardGrid}>
                                {group?.factors?.map((ele, i) => (
                                    <FundInfo
                                        key={i}
                                        groupId="factors"
                                        item={ele}
                                        index={i}
                                        onDelete={(info) => onDelete("factors", info)}
                                        onCopy={onCopy}
                                        models={models}
                                    />
                                ))}
                            </div>
                        </div>
                    </div>
                </Paper>
            </div>
            <div className={classes.rightPanel}>
                <Paper elevation={3} style={{ padding: "8px 0", marginLeft: "12px", height: "100%" }}>
                    <Typography style={{ paddingLeft: "12px" }} align="left" component="h3" variant="subtitle1">
                        Beta Profile &nbsp; &nbsp;
                        <Tooltip title="Restore defaults">
                            <button className="btn btn-secondary btn-sm" onClick={resetBetaProfiles}>
                                <i className="fas fa-undo"></i>
                            </button>
                        </Tooltip>
                    </Typography>
                    <div style={{ display: "flex", padding: "6px 12px" }}>
                        <AutoCompleteSelect
                            fieldId="betaProfile"
                            value={betaProfile}
                            placeholder="Beta Profile"
                            handleChange={(id, info) => onBetaProfileChange(info)}
                        />
                        <AdornedButton
                            style={{ marginLeft: "8px" }}
                            className={classes.btn}
                            variant="contained"
                            color="primary"
                            disabled={!betaProfile?.id}
                            size={"small"}
                            onClick={addBetaProfile}
                        >
                            Add
                        </AdornedButton>
                    </div>

                    <div style={{ maxHeight: "600px", overflow: "auto" }}>
                        <List dense={true}>
                            {formData?.betaProfile?.map((bp, i) => (
                                <span key={i}>
                                    <ListItem
                                        key={bp.id}
                                        secondaryAction={
                                            <CancelIcon
                                                style={{ fontSize: "1.3rem" }}
                                                className="pointer text-danger"
                                                onClick={() => removeBetaProfile(bp.id)}
                                            />
                                        }
                                    >
                                        <ListItemText
                                            style={{ margin: "3px 0px" }}
                                            primaryTypographyProps={{ style: { fontSize: "0.78rem" } }}
                                            secondaryTypographyProps={{ style: { fontSize: "0.78rem" } }}
                                            primary={bp.label}
                                            secondary={bp.id}
                                        />
                                    </ListItem>
                                    {formData?.betaProfile[i + 1] && <Divider />}
                                </span>
                            ))}
                        </List>
                    </div>
                </Paper>
            </div>
        </div>
    );
}
