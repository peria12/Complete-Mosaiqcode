export const data = [
    {
        fund: "Fund 1",
        benchmark: "Benchmark 1",
    },
    {
        fund: "Fund 2",
        benchmark: "Benchmark 2",
    },
    {
        fund: "Fund 3",
        benchmark: "Benchmark 3",
    },
    {
        fund: "Fund 4",
        benchmark: "Benchmark 4",
    },
    {
        fund: "Fund 5",
        benchmark: "Benchmark 5",
    },
    {
        fund: "Fund 6",
        benchmark: "Benchmark 6",
    },
];

export const fundList = [
    { id: 1, label: "Fund 1" },
    { id: 2, label: "Fund 2" },
    { id: 3, label: "Fund 3" },
];
export const benchmarkList = [
    { id: 1, label: "Benchmark 1" },
    { id: 2, label: "Benchmark 2" },
    { id: 3, label: "Benchmark 3" },
];

export const getQueryParams = (query) => ({
    query: {
        bool: {
            must: [
                {
                    bool: {
                        should: [
                            {
                                bool: {
                                    must: [{ match: { entity_type: "INDEX" } }, { exists: { field: "fs_bm_id" } }],
                                },
                            },
                            {
                                bool: {
                                    must: [{ exists: { field: "mstar_id" } }],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    search_string: query.toLowerCase(),
    size: 25,
});
