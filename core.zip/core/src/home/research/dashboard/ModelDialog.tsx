import React from "react";
import CancelIcon from "@mui/icons-material/Cancel";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import { AdornedButton } from "common/FTButtons";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import { ClickAwayListener, Input } from "@mui/material";
import AutoCompleteSelect from "./AutoCompleteSelect";
import FTTable from "common/FTTable";

const getUsedModelIds = (group) => {
    const m1 = (group?.funds || []).map((f) => f.fund?.model_id).filter((x) => x != null);
    const m2 = (group?.funds || []).map((f) => f.benchmark?.model_id).filter((x) => x != null);
    const m3 = group?.factors?.map((f) => f.factFund?.model_id).filter((x) => x != null) || [];
    const m4 = group?.factors?.map((f) => f.factBenchmark?.model_id).filter((x) => x != null) || [];
    return new Set([].concat(m1, m2, m3, m4));
};

export default function ModelDialog({
    open,
    setOpen,
    fieldId,
    onModelChange,
    onModelSelect,
    models,
    setModels,
    lastModel,
    group,
}) {
    const modelsInUse: any = getUsedModelIds(group);

    const lastEntry = { entry: null, value: 0, edit: true, last: true };

    const getE = () => models?.find((m) => m.edit)?.entries || [];
    const setE = (entries) => setModels(models.map((m) => (m.edit ? { ...m, entries } : m)));

    const handleDeleteModel = (row) => {
        const newModels = models.filter((m) => m != row);
        if (!newModels.find((x) => x.edit) && newModels.length) {
            newModels[0].edit = true;
        }
        setModels(newModels);
    };

    const handleDelete = (row) => {
        setE(getE().filter((x) => x != row));
    };

    const handleValueUpdate = (row, e) => {
        setE(getE().map((x) => (x == row ? { ...x, value: e.target.value } : x)));
    };

    const flip = (row, edit) => {
        setE(getE().map((x) => (x == row && !x.last ? { ...x, edit } : x)));
    };

    const flipM = (row) => {
        setModels(models.map((x) => (x == row ? { ...x, edit: true } : { ...x, edit: false })));
    };

    const handleEntryUpdate = (row, val) => {
        const newEntries = getE().map((x) => (val && x == row ? { ...row, entry: val, edit: false, last: false } : x));
        if (row.last) {
            newEntries.push({ ...lastEntry });
        }
        setE(newEntries);
    };

    const getSum = () => {
        return getE()
            .filter((x) => !x.last)
            .reduce((sum, x) => sum + parseFloat(x.value), 0.0);
    };

    const handleModelNameUpdate = (row, e) => {
        setModels(models.map((m) => (m == row ? { ...row, key: e.target.value } : m)));
    };

    const iconFn = (row) =>
        row.last ? <></> : <CancelIcon className="pointer text-danger" onClick={() => handleDelete(row)} />;

    const iconFnM = (row) => {
        if (modelsInUse.has(row.id)) {
            return <></>;
        }

        return <CancelIcon className="pointer text-danger" onClick={() => handleDeleteModel(row)} />;
    };

    const columns = [
        {
            label: "Entity Name",
            width: "55%",
            func: (row) =>
                row.edit ? (
                    <ClickAwayListener onClickAway={() => flip(row, false)}>
                        <div>
                            <AutoCompleteSelect
                                fieldId={fieldId}
                                value={row.entry}
                                handleChange={(_, info) => handleEntryUpdate(row, info)}
                            />
                        </div>
                    </ClickAwayListener>
                ) : (
                    <span className="pointer align-middle" onClick={() => flip(row, true)}>
                        {row.entry?.entity_name}
                    </span>
                ),
        },
        { label: "Ticker", func: (row) => row.entry?.bb_ticker, width: "15%" },
        { label: "Type", func: (row) => row.entry?.entity_type, width: "10%" },
        {
            label: () => `(Total: ${getSum()}%)`,
            func: (row) =>
                row.last ? (
                    <></>
                ) : (
                    <Input
                        type="number"
                        inputProps={{ style: { textAlign: "right" } }}
                        value={row.value}
                        onChange={(e) => handleValueUpdate(row, e)}
                    />
                ),
            width: "%",
        },
        { label: "", func: iconFn, width: "5%" },
    ];

    const modelColumns = [
        {
            label: "Model Name",
            width: "85%",
            func: (row) =>
                row.edit ? (
                    <ClickAwayListener onClickAway={() => flipM(row)}>
                        <div>
                            <Input value={row.key} onChange={(e) => handleModelNameUpdate(row, e)} />
                        </div>
                    </ClickAwayListener>
                ) : (
                    <span className="pointer align-middle" onClick={() => flipM(row)}>
                        {row.key}
                    </span>
                ),
        },
        { label: "", func: iconFnM, width: "15%" },
    ];
    const selectedModel = models?.find((m) => m.edit);

    const handleSelect = () => {
        onModelChange(models);
        onModelSelect(fieldId, { ...selectedModel, model: true, label: selectedModel.key });
        setOpen(false);
    };

    const addModel = () => {
        const id = Math.max(Math.max(...models.map((m) => m.id)) + 1, 1);
        const newModel = { ...lastModel, key: `Model ${id}`, entries: [{ ...lastEntry }], id };
        setModels([...models.map((m) => ({ ...m, edit: false })), newModel]);
    };

    const rowStyle = (row) => (row.edit ? { backgroundColor: "#DDDDDD" } : {});

    return (
        <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="xl">
            {/* <DialogTitle style={{ textTransform: "capitalize" }}>{fieldId} Model</DialogTitle> */}
            <DialogContent style={{ height: "900px" }}>
                <DialogContentText></DialogContentText>
                <div className="mt-4">
                    <div className="row">
                        <div className="col-3">
                            <FTTable columns={modelColumns} rows={models} rowStyle={rowStyle}></FTTable>
                            <div className="mt-2 justify-content-end d-flex">
                                <AddCircleIcon className="pointer text-success" onClick={addModel} />
                            </div>
                        </div>
                        <div className="col-9">
                            <FTTable columns={columns} rows={getE()}></FTTable>
                        </div>
                    </div>
                </div>
            </DialogContent>
            <DialogActions>
                <AdornedButton
                    style={{ textTransform: "capitalize" }}
                    variant="contained"
                    onClick={() => {
                        onModelChange(models);
                        setOpen(false);
                    }}
                    color="secondary"
                >
                    Close
                </AdornedButton>
                {selectedModel && (
                    <AdornedButton
                        style={{ textTransform: "capitalize" }}
                        variant="contained"
                        onClick={handleSelect}
                        color="primary"
                    >
                        Select {selectedModel.key}
                    </AdornedButton>
                )}
            </DialogActions>
        </Dialog>
    );
}
