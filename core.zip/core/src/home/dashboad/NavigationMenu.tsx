import React, { useState } from "react";
import Access from "utils/access";
import Settings from "utils/settings";
import { stableSort, getComparator } from "utils/helpers";
import DOMPurify from "dompurify";
import { Link, useLocation, useHistory } from "react-router-dom";
import { getDefaultScreenshot } from "./images";
import "./dashboard.css";

export default function NavigationMenu({ apps }) {
    const history = useHistory();
    const settings = Settings.getSettings();
    const lastViewed = settings?.app_settings?.admin?.portal?.lastViewed;
    const screenshots = settings?.app_settings?.admin?.portal?.screenshots || {};
    const { pathname } = useLocation();
    const paths = pathname.split("/");
    const [hovered, setHovered] = useState(null);

    return (
        <div className="title-nav-container">
            <ul>
                {stableSort(apps, getComparator("asc", "view_order")).map((app: any) => {
                    if (app.show_on_portal && app.view_order > 0) {
                        const lastViewedZoneForApp = lastViewed?.lastViewedZoneForEachApp?.[app._id];
                        const shownZones = app?.zones?.filter(
                            (zone) => zone.show_on_portal && Access.hasAccessToZone(app._id, zone.name, ["view"])
                        );
                        return (
                            <li
                                key={app._id}
                                onMouseOver={() => setHovered(app._id)}
                                onMouseOut={() => setHovered(null)}
                                onClick={() => {
                                    history.push(
                                        lastViewedZoneForApp
                                            ? `/${app._id}/${lastViewedZoneForApp}`
                                            : `/${app._id}/${shownZones?.[0]?.name}`
                                    );
                                }}
                            >
                                <div className="title-nav-link-wrapper">
                                    <Link
                                        className="title-nav-top-link"
                                        dangerouslySetInnerHTML={{
                                            __html: DOMPurify.sanitize(app.title_html),
                                        }}
                                    ></Link>
                                    <div
                                        className={
                                            (hovered && hovered === app._id) || paths[1] === app._id
                                                ? "title-nav-top-link-bottom-finished"
                                                : "title-nav-top-link-bottom"
                                        }
                                        style={{ background: app.color1 }}
                                    ></div>
                                </div>
                                <div className="title-sub-nav">
                                    <ul>
                                        {stableSort(shownZones, getComparator("asc", "view_order")).map((zone: any) => {
                                            return (
                                                <li key={zone.name}>
                                                    <Link
                                                        to={`/${app._id}/${zone.name}`}
                                                        onClick={(e) => e.stopPropagation()}
                                                    >
                                                        <img
                                                            className="title-sub-nav-img"
                                                            style={{ border: `2px solid ${app.color1}` }}
                                                            src={
                                                                screenshots[app._id]?.[zone.name]?.url ||
                                                                getDefaultScreenshot(app._id, zone.name)?.i ||
                                                                "https://anima-uploads.s3.amazonaws.com/projects/623b2c507af52e429bf57823/releases/62559c308c8ec1e7431395a5/img/prtfl-opt-config-1@2x.png"
                                                            }
                                                        />
                                                        <span
                                                            dangerouslySetInnerHTML={{
                                                                __html: DOMPurify.sanitize(
                                                                    zone.title_html || zone.title
                                                                ),
                                                            }}
                                                        ></span>
                                                    </Link>
                                                </li>
                                            );
                                        })}
                                    </ul>
                                </div>
                            </li>
                        );
                    }
                })}
            </ul>
        </div>
    );
}
