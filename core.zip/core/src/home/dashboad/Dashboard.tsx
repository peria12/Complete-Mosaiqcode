import React, { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import RGL, { WidthProvider } from "react-grid-layout";
import Settings from "utils/settings";
import moment from "moment";
import { debounceTime } from "rxjs/operators";
import { BehaviorSubject } from "rxjs";
import { screenshotNotification, homePageResetNotification } from "utils/events";
import { getDefaultScreenshot } from "./images";
import { Paper } from "@mui/material";
import Access from "utils/access";

const ReactGridLayout = WidthProvider(RGL);

function getLink(app_name, zone) {
    return `/${app_name}/${zone}`;
}

function generateLayout(apps) {
    const settings = Settings.getSettings();
    const layout = settings?.app_settings?.admin?.portal?.layout || [];

    const newLayout = layout
        .map((l) => {
            const app = apps.find((app) => app._id == l.i);
            if (!app || !app.show_on_portal) {
                return null;
            }
            const child_layout = l.child_layout
                .map((lc) => {
                    const zone = app.zones.find((z) => z.name == lc.i);
                    if (!zone || !zone.show_on_portal || !Access.hasAccessToZone(app._id, zone.name, ["view"])) {
                        return null;
                    }
                    return { ...lc, title: zone.title, link: getLink(app._id, zone.name), h: 7 };
                })
                .filter((x) => x);

            const zones = new Set(child_layout.map((c) => c.i));
            const max_y = Math.max(...child_layout.map((z) => z.y));
            app.zones
                .filter(
                    (z) => z.show_on_portal && !zones.has(z.name) && Access.hasAccessToZone(app._id, z.name, ["view"])
                )
                .forEach((z, i) => {
                    child_layout.push({
                        x: 0,
                        y: max_y + 1 + i, // increase y by 1 for each new zone
                        w: l.w,
                        h: 7,
                        i: z.name,
                        title: z.title,
                        link: getLink(app._id, z.name),
                    });
                });

            return {
                ...l,
                title: app.title,
                color: app.color1 || "#A5A5A5",
                color2: app.color2 || "#ADADAD",
                child_layout,
            };
        })
        .filter((x) => x);

    let currX = Math.max(0, ...newLayout.map((l) => l.x + l.w));

    const currentApps = new Set(newLayout.map((l) => l.i));
    apps.sort((a, b) => a.view_order - b.view_order).forEach((app) => {
        if (!currentApps.has(app._id)) {
            const child_layout = app.zones
                .filter((z) => z.show_on_portal && Access.hasAccessToZone(app._id, z.name, ["view"]))
                .map((z, i) => ({ x: 0, y: i, w: 2, h: 7, i: z.name, title: z.title, link: getLink(app._id, z.name) }));
            let xPos;
            let yPos;
            if (app.view_order > 0) {
                xPos = currX;
                yPos = app.view_order;
                currX = (currX + 2) % 10;
            } else {
                xPos = 11;
                yPos = -app.view_order;
            }
            const parent = {
                i: app._id,
                title: app.title,
                w: 2,
                x: xPos,
                y: yPos,
                h: 20,
                color: app.color1 || "#A5A5A5",
                color2: app.color2 || "#ADADAD",
                child_layout,
            };
            newLayout.push(parent);
        }
    });

    return newLayout;
}

function Title({ name, compact }) {
    return (
        <div
            className="drag-handle"
            style={{ paddingLeft: "7px", height: compact ? "20px" : "24px", lineHeight: compact ? "30px" : "40px" }}
        >
            <div className={compact ? "robotocondensed-bold-white-xl" : "robotocondensed-bold-white-30px"}>{name}</div>
        </div>
    );
}

const calcW = (x, args, compact) => {
    const [X, Y] = compact ? [2.2, 2.8] : [1.83, 3.1];
    const minH = Math.max(...args.map((x) => x.h + x.y)) / X + Y;
    const minW = Math.max(...args.map((x) => x.w + x.x));
    const child_layout = x.child_layout.map((c) => ({ ...c, ...args.find((a) => a.i == c.i) }));
    return { ...x, h: minH, minH, minW, child_layout };
};

function ChildElement({ item, refs, i, screenshot, setHeight, compact, counter, app }) {
    const ref = useRef<HTMLDivElement>(null);
    let default_img: any = undefined;
    if (!screenshot?.url || !screenshot?.height) {
        default_img = getDefaultScreenshot(app, item.i);
    }

    useEffect(() => {
        if (ref.current) {
            const width = ref.current.offsetWidth;
            const getH = (w, h) => Math.max((h * width) / w / 5.9 + 5.9, 10);
            if (screenshot && screenshot.height) {
                setHeight(i, getH(screenshot.width, screenshot.height));
            } else {
                setHeight(i, getH(default_img?.w || 2, default_img?.h || 1));
            }
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ref.current, counter]);

    const getDate = () => (screenshot?.time ? moment.utc(screenshot.time * 1000).format("DD MMM YYYY") : "");

    const getBorderRadius = () => (compact ? "3px 3px 3px 3px" : "3px 3px 0px 0px");

    return (
        <div className="d-flex flex-column" style={{ height: "100%" }}>
            {compact ? (
                <Link to={item.link || ""}>
                    <div
                        className="flex-grow-1 d-flex drag-handle2"
                        style={{
                            lineHeight: "35px",
                            backgroundColor: "white",
                            opacity: 0.9,
                            borderRadius: getBorderRadius(),
                            maxHeight: "32px",
                        }}
                    >
                        <div style={{ paddingLeft: "3px" }}>
                            <Paper>
                                <img
                                    style={{
                                        backgroundColor: "white",
                                        borderRadius: "0px 0px 3px 3px",
                                        height: "20px",
                                        width: "30px",
                                        cursor: "pointer",
                                    }}
                                    src={screenshot?.url || default_img?.i}
                                />
                            </Paper>
                        </div>
                        <p className="ps-1 client-management-02-feb-2022 robotocondensed-normal-white-15px">
                            <span className="robotocondensed-normal-shark-15px">{item.title}</span>
                        </p>
                    </div>
                </Link>
            ) : (
                <div
                    className="px-1 py-2 flex-grow-1 d-flex justify-content-center drag-handle2"
                    ref={ref}
                    style={{
                        backgroundColor: "white",
                        opacity: 0.9,
                        borderRadius: getBorderRadius(),
                        maxHeight: "35px",
                    }}
                >
                    <p className="text-center client-management-02-feb-2022 robotocondensed-normal-white-15px">
                        <span className="robotocondensed-normal-shark-15px">{item.title}</span>
                        <span className="robotocondensed-normal-shark-12px">&nbsp;</span>
                        <span className="robotocondensed-normal-true-v-12px-2">{getDate()}</span>
                    </p>
                </div>
            )}
            {!compact && (
                <Link to={item.link || ""}>
                    <div className="flex-shrink-1">
                        <img
                            ref={(el) => (refs.current[i] = el)}
                            style={{
                                backgroundColor: "white",
                                borderRadius: "0px 0px 3px 3px",
                                height: "100%",
                                width: "100%",
                                cursor: "pointer",
                            }}
                            className="prtfl-opt-config-1"
                            src={
                                screenshot?.url ||
                                default_img?.i ||
                                "https://anima-uploads.s3.amazonaws.com/projects/623b2c507af52e429bf57823/releases/62559c308c8ec1e7431395a5/img/prtfl-opt-config-1@2x.png"
                            }
                        />
                    </div>
                </Link>
            )}
        </div>
    );
}

function DashboardChild({ x, enableUserChange, screenshots, compact, onChildLayoutChange, counter }) {
    const [mylayout, setMylayout] = useState(x.child_layout);
    const refs: any = useRef([]);

    const handleResize = useCallback((l, oldLayoutItem, layoutItem, placeholder) => {
        const changeCoef = oldLayoutItem.w / oldLayoutItem.h;
        layoutItem.h = layoutItem.w / changeCoef;
        placeholder.h = layoutItem.w / changeCoef;
    }, []);

    const setHeight = (i, h) => {
        mylayout[i].h = h;
        setMylayout(mylayout.map((x) => ({ ...x })));
    };

    const generateDOMChild = () => {
        return mylayout.map((item, i) => (
            <div key={item.i} style={{ borderRadius: "3px", overflow: "hidden" }}>
                <ChildElement
                    item={item}
                    refs={refs}
                    app={x.i}
                    i={i}
                    screenshot={screenshots[item.i]}
                    setHeight={setHeight}
                    compact={compact}
                    counter={counter}
                />
            </div>
        ));
    };

    return (
        <ReactGridLayout
            draggableHandle=".drag-handle2"
            cols={x.w}
            layout={mylayout}
            isResizable={!compact}
            isDraggable={!compact}
            className="layout"
            onResize={handleResize}
            containerPadding={[5, 0]}
            margin={compact ? [4, 4] : [5, 5]}
            rowHeight={1}
            onLayoutChange={(args) => onChildLayoutChange(args, x.i)}
            onDragStop={enableUserChange}
            onResizeStop={enableUserChange}
        >
            {generateDOMChild()}
        </ReactGridLayout>
    );
}

export function Dashboard({ apps, compact }) {
    // eslint-disable-next-line
    let [layout, setLayout] = useState(generateLayout(apps));
    let [userChange] = useState(false);
    const ref = useRef<any>(null);
    const settings = Settings.getSettings();
    const screenshots = settings?.app_settings?.admin?.portal?.screenshots || {};
    const subject = React.useMemo(() => new BehaviorSubject<any>(null), []);
    // eslint-disable-next-line
    let [counter, setCounter] = useState({ started: false });
    let [width] = useState(0);
    const [show, setShow] = useState(true);

    useEffect(() => {
        const sub = subject.pipe(debounceTime(200)).subscribe((val) => {
            if (val) {
                setCounter({ started: true });
                window.dispatchEvent(new Event("resize"));
            }
        });

        if (ref.current) {
            const resize_ob = new ResizeObserver((arg) => {
                if (arg?.length > 0) {
                    const w = arg[0]?.contentRect?.width;
                    if (w && w != width) {
                        if (width != 0) {
                            subject.next("a");
                            window.dispatchEvent(new Event("resize"));
                        }
                        // eslint-disable-next-line react-hooks/exhaustive-deps
                        width = w;
                    }
                }
            });

            resize_ob.observe(ref.current);
        }
        return () => sub.unsubscribe();
    }, []);

    useEffect(() => {
        if (!compact) {
            const sub = screenshotNotification.subscribe(() => {
                setCounter({ started: true });
            });

            const sub2 = homePageResetNotification.subscribe(() => {
                setShow(false);
                setLayout(generateLayout(apps));
                setTimeout(() => setShow(true), 100); // for a clean re-draw
            });

            return () => {
                sub.unsubscribe();
                sub2.unsubscribe();
            };
        }
    }, [compact, apps]);

    const enableUserChange = () => {
        userChange = true;
    };

    const onChildLayoutChange = (args, i) => {
        setParentLayout(layout.map((x) => (x.i == i ? calcW(x, args, compact) : { ...x })));
    };

    const setParentLayout = (newLayout) => {
        if (JSON.stringify(newLayout) != JSON.stringify(layout)) {
            setLayout(newLayout);
            layout = newLayout;
            const getCoOrds = (l) => ({ i: l.i, x: l.x, y: l.y, w: l.w, h: l.h });
            const data = newLayout.map((l) => ({ ...getCoOrds(l), child_layout: l.child_layout.map(getCoOrds) }));
            if (userChange) {
                Settings.updateSettings("admin", "portal", "layout", data);
                userChange = false;
            }
        }
    };

    const onLayoutChange = (args) => {
        if (!compact) {
            setParentLayout(layout.map((x) => ({ ...x, ...args.find((y) => y.i == x.i) })));
            window.dispatchEvent(new Event("resize"));
        }
    };

    const generateDOM = () =>
        layout.map((x) => (
            <div
                key={x.i}
                style={{ backgroundImage: `linear-gradient(to right, ${x.color}, ${x.color2})`, borderRadius: "3px" }}
            >
                <Title name={x.title} compact={compact}></Title>
                <DashboardChild
                    x={x}
                    enableUserChange={enableUserChange}
                    screenshots={screenshots[x.i] || {}}
                    compact={compact}
                    onChildLayoutChange={onChildLayoutChange}
                    counter={counter}
                />
            </div>
        ));

    return show ? (
        <div ref={ref} id="rgl_dashboard_remove_from_screenshot">
            <ReactGridLayout
                draggableHandle=".drag-handle"
                cols={12}
                layout={layout}
                className="layout"
                rowHeight={1}
                isResizable={!compact}
                isDraggable={!compact}
                isBounded={true}
                onLayoutChange={onLayoutChange}
                onDragStop={enableUserChange}
                onResizeStop={enableUserChange}
            >
                {generateDOM()}
            </ReactGridLayout>
        </div>
    ) : (
        <></>
    );
}
