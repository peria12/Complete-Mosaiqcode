import React, { useEffect, useMemo, useRef, useState } from "react";
import { Paper, Button } from "@mui/material";
import errorNotification from "utils/api-error";
import ShareIcon from "@mui/icons-material/Share";
import CloseIcon from "@mui/icons-material/Close";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import DriveFileRenameOutlineIcon from "@mui/icons-material/DriveFileRenameOutline";
import { FTIconButton } from "common/FTButtons";
import SearchInput from "common/SearchInput";
import "ag-grid-enterprise";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { AgGridReact } from "ag-grid-react";
import Api from "utils/api";
import Access from "utils/access";
import SearchForAsset from "../shared/SearchForAsset";
import { operatorOptions, squareBtnStyle, numericFieldCfg } from "../utils/aa-cfg";
import ShareWith from "../../../../common/ShareWith";
import EditModal from "../shared/EditNameDialog";
import CopyAllIcon from "@mui/icons-material/CopyAll";
import { RenderOption, styles } from "./SAAInput";
import { hasAccess } from "../utils/aa-helper";

function formatConstraints(constraints) {
    return constraints.map((constraint, idx) => ({
        constraint_id: idx + 1,
        asset_type: constraint.asset[0],
        asset_category: constraint.asset[1],
        asset_sub_category: constraint.asset[2],
        asset_description: constraint.asset[3],
        bench_type: constraint.bench?.[0] || "",
        bench_category: constraint.bench?.[1] || "",
        bench_sub_category: constraint.bench?.[2] || "",
        bench_description: constraint.bench?.[3] || "",
        operator: constraint.operator,
        min:
            constraint.operator === ">=" ? constraint.value : constraint.operator === "Btwn" ? constraint.value[0] : "",
        max:
            constraint.operator === "<=" ? constraint.value : constraint.operator === "Btwn" ? constraint.value[1] : "",
    }));
}

export default function ConstraintsSet({
    assetGroups,
    app,
    zone,
    onConstraintsSave,
    constraintList,
    refreshData,
    deleteOption,
    deleteObj,
    setDeleteObj,
}) {
    const [rowsForTable, setRowsForTable] = useState<any[]>([]);
    const [editNamePopup, setEditNamePopup] = useState<any>({
        value: "",
        label: "",
        open: false,
        selectedConstraint: {},
    });
    const [shareInfo, setShareInfo] = React.useState<any>({ open: false, shareBtnRef: null, data: null });
    const gridRef = useRef<AgGridReact>(null);
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const defaultColDef = useMemo(() => {
        return {
            enableValue: true,
            width: 100,
            resizable: true,
            flex: 1,
            minWidth: 100,
            suppressMenu: true,
            singleClickEdit: true,
        };
    }, []);
    const userInfo = Access.userInfo || {};

    useEffect(() => {
        if (deleteObj?.deleted) {
            if (deleteObj.deleteObj?._meta?.type === "constraints") {
                setEditNamePopup((editName) => ({
                    ...editName,
                    value: "",
                    label: "",
                    selectedConstraint: null,
                }));
                setRowsForTable([]);
                setDeleteObj((deleteObj) => ({ ...deleteObj, deleteObj: null, deleted: false }));
            }
        }
    }, [deleteObj, setDeleteObj]);

    function onShare(e, value, list) {
        const data = list?.find((ele) => ele?.id == value) || {};
        const authorId = data?._meta?.["author-id"];
        if (authorId == userInfo["uuid"]) {
            setShareInfo({
                open: true,
                shareBtnRef: e.currentTarget,
                data: data,
            });
        }
    }

    function checkDisableSave() {
        let disable = !editNamePopup.label;
        if (rowsForTable.length === 0) {
            disable = true;
        }
        rowsForTable.forEach((row) => {
            if (!row.operator || !row.asset_type) {
                disable = true;
            } else if (row.operator === "Btwn") {
                disable ||= !row.min || !row.max;
            } else if (row.operator === ">=") {
                disable ||= !row.min;
            } else {
                disable ||= !row.max;
            }
        });
        return disable;
    }

    function assetClassLeft(params) {
        if (!params.node.data.asset_asset_id && !params.node.data.asset_type) {
            const constraint_id = params.node.data.constraint_id;
            return (
                <SearchForAsset
                    list={assetGroups?.master}
                    ids={[]}
                    handleChange={(e, doc) => handleSearchChangeAsset(e, doc, constraint_id, params.data)}
                    styles={{ height: "23px", width: "98%" }}
                />
            );
        } else {
            return params.node.data.asset_type || null;
        }
    }

    function assetClassRight(params) {
        if (!params.node.data.bench_asset_id && !params.node.data.bench_type) {
            const constraint_id = params.node.data.constraint_id;
            return (
                <SearchForAsset
                    list={assetGroups?.master}
                    ids={[]}
                    handleChange={(e, doc) => handleSearchChangeBench(e, doc, constraint_id, params.data)}
                    styles={{ height: "23px" }}
                />
            );
        } else {
            return params.node.data.bench_type || null;
        }
    }

    function deleteIcon(params) {
        if (!params.node.data.constraint_id) return "";
        return (
            <FTIconButton
                handler={() => onDelete(params)}
                title="Remove"
                btnIcon={<CloseIcon style={{ fontSize: "1rem", color: "grey" }} />}
                placement="top"
            />
        );
    }

    function onDelete(params) {
        const { node } = params;
        setRowsForTable((rows) => {
            return rows?.filter((e) => e.constraint_id != node.data?.constraint_id);
        });
    }

    function deleteIconHeader() {
        return (
            <FTIconButton
                handler={onDeleteAll}
                title="Remove All"
                btnIcon={<CancelOutlinedIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                placement="top"
            />
        );
    }

    function onDeleteAll() {
        setRowsForTable([]);
    }

    function handleSave(name) {
        if (checkDisableSave()) {
            errorNotification.next({ type: "error", text: "lack of value for constraint", open: true });
            return;
        }
        const getValue = (row) => {
            if (row.operator === "Btwn") {
                return [Number(row.min), Number(row.max)];
            } else if (row.operator === ">=") {
                return Number(row.min);
            } else if (row.operator === "<=") {
                return Number(row.max);
            }
        };
        const formatted = {
            Name: name,
            name: name + "-constraints",
            type: "constraints",
            constraints: rowsForTable.map((row) => {
                const bench = [
                    row.bench_type || "",
                    row.bench_category || "",
                    row.bench_sub_category || "",
                    row.bench_description || "",
                ];
                const constraint = {
                    value: getValue(row),
                    operator: row.operator || "",
                    asset: [
                        row.asset_type || "",
                        row.asset_category || "",
                        row.asset_sub_category || "",
                        row.asset_description || "",
                    ],
                };
                const benchValues = bench.filter((ele) => ele);
                constraint["bench"] = benchValues.length > 0 ? bench : null;
                return constraint;
            }),
        };
        if (editNamePopup?.action !== "copy" && editNamePopup.value) {
            Api.updateSharedState(editNamePopup.value, formatted).then((res: any) => {
                if (res.message) {
                    errorNotification.next({ type: "success", text: res.message, open: true });
                    onConstraintsSave(res["shared-object"]);
                    setEditNamePopup((info) => ({
                        ...info,
                        selectedConstraint: {
                            id: res["shared-object"]?._id?.$oid,
                            label: res["shared-object"].Name,
                            constraints: res["shared-object"].constraints,
                            _meta: res["shared-object"],
                        },
                    }));
                }
            });
        } else {
            Api.createSharedState(app, zone, formatted).then((res: any) => {
                if (res.message) {
                    errorNotification.next({ type: "success", text: res.message, open: true });
                    onConstraintsSave(res["shared-object"]);
                    setEditNamePopup((info) => ({
                        ...info,
                        value: res["shared-object"]?._id?.$oid,
                        selectedConstraint: {
                            id: res["shared-object"]?._id?.$oid,
                            label: res["shared-object"].Name,
                            constraints: res["shared-object"].constraints,
                            _meta: res["shared-object"],
                        },
                    }));
                }
            });
        }
    }

    const columns = [
        {
            cellStyle: { textAlign: "center", color: "#355dd1" },
            children: [
                {
                    cellRenderer: deleteIcon,
                    headerComponent: deleteIconHeader,
                    cellRendererParams: { onDelete: onDelete },
                    headerComponentParams: { onDelete: onDeleteAll },
                    maxWidth: 30,
                },
                {
                    headerName: "Class",
                    field: "asset_type",
                    colSpan: (params) => {
                        if (!params.node.data.asset_asset_id && !params.node.data.asset_type) {
                            return 4;
                        } else {
                            return 1;
                        }
                    },
                    cellRenderer: assetClassLeft,
                    cellStyle: { color: "#355DD1" },
                },
                {
                    headerName: "Asset Category",
                    field: "asset_category",
                    cellStyle: { color: "#355DD1" },
                },
                {
                    headerName: "Sub Category",
                    field: "asset_sub_category",
                    cellStyle: { color: "#355DD1" },
                },
                {
                    headerName: "Asset Description",
                    field: "asset_description",
                    cellStyle: { color: "#355DD1" },
                },
                {
                    headerName: "Operator",
                    field: "operator",
                    editable: true,
                    cellEditor: "agRichSelectCellEditor",
                    cellEditorPopup: true,
                    cellEditorParams: {
                        values: operatorOptions.map((option) => option.value),
                        cellRenderer: function (params) {
                            return <span style={{ color: "#355DD1" }}>{params.value || ""}</span>;
                        },
                    },
                    cellStyle: {
                        border: "solid 1px #c5c5c5",
                        borderRadius: "3px",
                        textAlign: "center",
                        width: "65px",
                        color: "#355DD1",
                    },
                    maxWidth: 70,
                },
                {
                    headerName: "Min %",
                    field: "min",
                    cellClassRules: {
                        "cell-input": (params) => params.data.operator !== "<=",
                    },
                    valueGetter: (params) => (params.node.data.operator !== "<=" ? params.node.data.min : 0),
                    editable: (params) => params.node.data.operator !== "<=",
                    valueParser: (params) => Math.max(0, Number(params.newValue || 0)),
                    maxWidth: 45,
                    cellStyle: { borderRadius: "3px", width: "42px", color: "#355DD1" },
                    ...numericFieldCfg,
                },
                {
                    headerName: "",
                    cellRenderer: () => "--",
                    resizable: false,
                    maxWidth: 15,
                    cellStyle: { textAlign: "center" },
                },
                {
                    headerName: "Max %",
                    field: "max",
                    maxWidth: 45,
                    cellClassRules: {
                        "cell-input": (params) => params.data.operator !== ">=",
                    },
                    valueGetter: (params) => (params.node.data.operator !== ">=" ? params.node.data.max : ""),
                    editable: (params) => params.node.data.operator !== ">=",
                    valueParser: (params) => Math.min(100, Number(params.newValue || 0)),
                    cellStyle: { borderRadius: "3px", width: "42px", color: "#355DD1" },
                    ...numericFieldCfg,
                },
            ],
        },
        {
            headerName: "",
            cellRenderer: () => "of",
            resizable: false,
            maxWidth: 35,
            cellStyle: { color: "grey", textAlign: "center" },
        },
        {
            headerName: "Relative to...",
            cellStyle: { textAlign: "center" },
            children: [
                {
                    headerName: "Class",
                    field: "bench_type",
                    colSpan: (params) => {
                        if (!params.node.data.bench_asset_id && !params.node.data.bench_type) {
                            return 4;
                        } else {
                            return 1;
                        }
                    },
                    cellRenderer: assetClassRight,
                    cellStyle: { color: "#355DD1" },
                },
                {
                    headerName: "Asset Category",
                    field: "bench_category",
                    cellStyle: { color: "#355DD1" },
                },
                {
                    headerName: "Sub Category",
                    field: "bench_sub_category",
                    cellStyle: { color: "#355DD1" },
                },
                {
                    headerName: "Asset Description",
                    field: "bench_description",
                    cellStyle: { color: "#355DD1" },
                },
            ],
        },
    ];

    const handleSearchChangeAsset = (_, doc, constraint_id, rowData) => {
        if (doc) {
            setRowsForTable((rows) => {
                const _rows = [...rows] || [];
                let updatedRow;
                if (!constraint_id) {
                    updatedRow = {
                        ...rowData,
                        constraint_id: _rows.length ? _rows[_rows.length - 1].constraint_id + 1 : 1,
                        asset_asset_id: doc.asset_id,
                        asset_type: doc.asset_type,
                        asset_category: doc.category,
                        asset_sub_category: doc.sub_category,
                        asset_description: doc.asset,
                    };
                    _rows.push(updatedRow);
                } else {
                    const selectedRowIdx = _rows.findIndex((row) => row.constraint_id === constraint_id);
                    _rows[selectedRowIdx].asset_asset_id = doc.asset_id;
                    _rows[selectedRowIdx].asset_type = doc.asset_type;
                    _rows[selectedRowIdx].asset_category = doc.category;
                    _rows[selectedRowIdx].asset_sub_category = doc.sub_category;
                    _rows[selectedRowIdx].asset_description = doc.asset;
                }
                return _rows;
            });
        }
    };

    const handleSearchChangeBench = (_, doc, constraint_id, rowData) => {
        if (doc) {
            setRowsForTable((rows) => {
                const _rows = [...rows] || [];
                let updatedRow;
                if (!constraint_id) {
                    updatedRow = {
                        ...rowData,
                        constraint_id: _rows.length ? _rows[_rows.length - 1].constraint_id + 1 : 1,
                        bench_asset_id: doc.asset_id,
                        bench_type: doc.asset_type,
                        bench_category: doc.category,
                        bench_sub_category: doc.sub_category,
                        bench_description: doc.asset,
                    };
                    _rows.push(updatedRow);
                } else {
                    const selectedRowIdx = _rows.findIndex((row) => row.constraint_id === constraint_id);
                    _rows[selectedRowIdx].bench_asset_id = doc.asset_id;
                    _rows[selectedRowIdx].bench_category = doc.category;
                    _rows[selectedRowIdx].bench_type = doc.asset_type;
                    _rows[selectedRowIdx].bench_sub_category = doc.sub_category;
                    _rows[selectedRowIdx].bench_description = doc.asset;
                }
                return _rows;
            });
        }
    };

    return (
        <div id="constraints" style={{ width: "100%", height: "100%" }}>
            <Paper square elevation={5} style={{ width: "100%", height: "100%", padding: "10px" }}>
                <label className="top_selection_label">
                    <div>Constraint Name</div>
                    <div className="top_selection_input">
                        <SearchInput
                            onChange={(_, v) => {
                                if (v) {
                                    setRowsForTable(formatConstraints(v.constraints));
                                    setEditNamePopup((editName) => ({
                                        ...editName,
                                        value: v.id,
                                        label: v.label,
                                        selectedConstraint: v,
                                    }));
                                }
                            }}
                            onInputChange={(e) => {
                                if (e?.type === "change") {
                                    setEditNamePopup((editName) => ({
                                        ...editName,
                                        label: e.target.value,
                                        value: "",
                                        selectedConstraint: {},
                                    }));
                                }
                            }}
                            options={constraintList}
                            value={constraintList?.find((con) => con.id === editNamePopup.value)}
                            disableUnderline={true}
                            forcePopupIcon={true}
                            inputPropsStyle={styles}
                            popperWidth="300px"
                            searchIcon={false}
                            renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                        />
                        <FTIconButton
                            handler={() =>
                                setEditNamePopup((editName) => ({ ...editName, open: true, action: "copy" }))
                            }
                            title={"Copy"}
                            btnIcon={<CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={!editNamePopup.label || !editNamePopup.value}
                            style={
                                !editNamePopup.label || !editNamePopup.value
                                    ? { ...squareBtnStyle, opacity: 0.4 }
                                    : squareBtnStyle
                            }
                        />
                        <FTIconButton
                            handler={() => {
                                setEditNamePopup((editName) => ({ ...editName, open: true, action: "edit" }));
                            }}
                            title="Edit"
                            btnIcon={
                                <DriveFileRenameOutlineIcon
                                    style={{ fontSize: "1.1rem", color: "grey" }}
                                    color="primary"
                                />
                            }
                            placement="top"
                            disabled={
                                !editNamePopup.label ||
                                !editNamePopup.value ||
                                !hasAccess(editNamePopup.selectedConstraint?._meta)
                            }
                            style={
                                !editNamePopup.label ||
                                !editNamePopup.value ||
                                !hasAccess(editNamePopup.selectedConstraint?._meta)
                                    ? { ...squareBtnStyle, opacity: 0.4 }
                                    : squareBtnStyle
                            }
                        />
                        <FTIconButton
                            handler={(e) => onShare(e, editNamePopup.value, constraintList)}
                            title={shareInfo.open ? "" : "Share"}
                            btnIcon={<ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} />}
                            placement="top"
                            style={squareBtnStyle}
                            disabled={!editNamePopup.value}
                        />
                        <ShareWith
                            shareInfo={shareInfo}
                            setShareInfo={setShareInfo}
                            refreshData={refreshData}
                            setBenchmarkModelData={() => {
                                return null;
                            }}
                        />
                    </div>
                </label>
                <div style={{ height: "calc(100% - 100px)", width: "100%", fontFamily: "Roboto Condensed" }}>
                    <div style={gridStyle}>
                        <AgGridReact
                            rowData={[...rowsForTable, {}]}
                            ref={gridRef}
                            columnDefs={columns}
                            defaultColDef={defaultColDef}
                            stopEditingWhenCellsLoseFocus={true}
                        />
                    </div>
                </div>
                <div className={"btn-group"} style={{ width: "100%" }}>
                    <Button
                        className="save-btn"
                        variant="outlined"
                        size="small"
                        onClick={() => handleSave(editNamePopup.label)}
                        disabled={!editNamePopup.label}
                    >
                        {" "}
                        Save{" "}
                    </Button>
                </div>
            </Paper>
            <EditModal
                editInfo={{
                    field: "constraint",
                    open: editNamePopup.open,
                    value: editNamePopup.label,
                    action: editNamePopup.action,
                }}
                setEditInfo={setEditNamePopup}
                editOnSave={(_, name) => {
                    setEditNamePopup((editName) => ({ ...editName, label: name, open: false }));
                    handleSave(name);
                }}
            />
        </div>
    );
}
