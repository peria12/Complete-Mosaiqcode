import React, { useState, useEffect } from "react";
import AppCover from "home/dashboad/AppCover";
import errorNotification from "utils/api-error";
import Api from "utils/api";
import SAAInput from "./SAAInput";
import ConstraintsSet from "./ConstraintsSet";
import Output from "./outputs/Output";
import OptimalPortfolio from "./outputs/OptimalPortfolio";
import ConfirmDialog from "common/ConfirmDialog";
import SearchInput from "common/SearchInput";
import { FTIconButton } from "common/FTButtons";
import ShareIcon from "@mui/icons-material/Share";
import ShareWith from "../../../../common/ShareWith";
import { defaultLayoutCfg, windowsCfgKeys } from "../utils/aa-cfg";
import { useScreenshot } from "utils/helpers";
import {
    updateRowValues,
    getSharedObjOptions,
    getAssetId,
    updateConstraintList,
    sortList,
    hasAccess,
} from "../utils/aa-helper";
import { styles, RenderOption } from "./SAAInput";
import { defaultFormData, squareBtnStyle } from "../utils/aa-cfg";
import Settings from "utils/settings";
import _ from "lodash";
import "../asset-allocation.scss";
import "winbox/dist/css/winbox.min.css";
import "winbox/dist/css/themes/white.min.css";
import WinBox from "react-winbox";
import "../aa-winbox.scss";
import CopyAllIcon from "@mui/icons-material/CopyAll";
import DriveFileRenameOutlineIcon from "@mui/icons-material/DriveFileRenameOutline";
import Access from "utils/access";

export default function SAAContainer({ app, type }) {
    const [assetGroups, setAssetGroups] = useState<any>({ master: [], records: [], selected: null });
    const [formData, setFormData] = useState<any>({ ...defaultFormData });
    const [initialOutputData, setInitialOutputData] = useState<any>({ data: {}, benchmark: null, modelAssets: [] });
    const [outputData, setOutputData] = useState<any>({ data: {}, benchmark: null, modelAssets: [] });
    const [loaded, setLoaded] = useState(false);
    const [windowCfg, setWindowCfg] = useState<any>({ ...defaultLayoutCfg });
    const [validationError, setValidationError] = useState<any>({});
    const [deletePopup, setDeletePopup] = useState<any>({ open: false, deleteObj: null, deleted: false });
    const [selectedTemplate, setSelectedTemplate] = useState<any>();
    const [shareInfo, setShareInfo] = useState<any>({ open: false, shareBtnRef: null, data: null });
    const screenshot = useScreenshot();
    const settings = Settings.getSettings();

    useEffect(() => {
        const windows = settings?.app_settings?.aa?.saa2?.windows || {};
        setWindowCfg((cfg) => {
            const newCfg = { ...cfg };
            Object.keys(windows)?.map((k) => {
                newCfg[k] = windows[k];
            });
            return newCfg;
        });
        setLoaded(true);
    }, [settings]);

    function getSharedObjects() {
        return new Promise((resolve, reject) => {
            Api.getSharedState(app, type)
                .then((response: any) => {
                    if (response.length > 0) {
                        const constraintList = getSharedObjOptions(response, "constraints");
                        const modelList = getSharedObjOptions(response, "modelportfolio");
                        const templateList = getSharedObjOptions(response, "template");
                        const benchmarkList = getSharedObjOptions(response, "benchmark");
                        setFormData((fd) => ({ ...fd, constraintList, modelList, templateList, benchmarkList }));
                        return resolve({ templateList, modelList, constraintList, benchmarkList });
                    }
                    return resolve({});
                })
                .catch((err: any) => {
                    console.log(err);
                    reject();
                });
        });
    }

    function refreshData() {
        getSharedObjects();
    }

    function transformCME(resp: any = {}, key) {
        const list = resp[key] || [];
        return list?.map((ele) => {
            const value = Number(ele[key]);
            const ret = isNaN(value) ? ele[key] : value * 100;
            return {
                return: ret,
                entity_id: ele.req_entity_id,
                actual_date: ele.actual_date,
                model_type: ele.model_type || null,
            };
        });
    }

    function get_cme_risk(resp: any = {}, id, key) {
        const riskData = resp[key] || [];
        const entry = riskData?.find((ele) => ele?.req_entity_id == id);
        let risk = entry?.[key] || null;
        if (risk) {
            risk = risk * 100;
        }
        return {
            risk: risk,
            actual_date: entry?.actual_date,
        };
    }

    function get_bm_cme(resp: any = [], id) {
        const data = resp || [];
        const entry = data?.find((ele) => ele?.req_entity_id == id);
        let bm_return = entry?.return || null;
        let bm_risk = entry?.volatility || null;
        if (bm_return) {
            bm_return = bm_return * 100;
        }
        if (bm_risk) {
            bm_risk = bm_risk * 100;
        }
        return {
            bm_risk,
            bm_return,
        };
    }
    function getCMEData(cmeDate, currency, ids = null, data = null) {
        const fields = ["cme", "cme.vol"];
        const payload = {
            base_currency: currency || "USD",
            fields,
            dates: [cmeDate],
            entities: ids ? ids : formData.entityIds,
            date_info: { fill_missing_lookback: 365 },
        };
        const payloadForBM = {
            fields: ["mosaiq.benchmark_assets_return_risk"],
            dates: [cmeDate],
            entities: ids ? ids : formData.entityIds,
            id_type: "entity_id",
        };
        setFormData((fd) => ({ ...fd, cmeList: [] }));
        const list = data ? data : assetGroups.master;
        setAssetGroups((ag) => ({
            ...ag,
            master: list.map((e) => ({ ...e, return: "", risk: "", ret_actual_date: "", bm_return: "", bm_risk: "" })),
        }));
        Promise.all([Api.dal(payload), Api.dal(payloadForBM)])
            .then((resp) => {
                if (resp.length) {
                    const cmeList = transformCME(resp[0], fields[0]) || [];
                    if (cmeList.length && list?.length) {
                        const updatedAstGrups = list.map((ele) => {
                            let cmeInfo: any = {};
                            if (ele?.asset_type == "Equity") {
                                const matched_cme = cmeList.filter((c) => c.entity_id == ele.entity_id) || {};
                                cmeInfo = matched_cme?.find((e) => ele.cme_approach == e.model_type);
                                if (!cmeInfo) {
                                    cmeInfo = matched_cme?.find((e) => e.model_type != null);
                                }
                                if (!cmeInfo) {
                                    cmeInfo = matched_cme?.[0] || {};
                                }
                            } else {
                                cmeInfo = cmeList.find((c) => c.entity_id == ele.entity_id) || {};
                            }
                            const riskInfo = get_cme_risk(resp[0], ele.entity_id, fields[1]);
                            const bmInfo = get_bm_cme(resp[1]?.["mosaiq.benchmark_assets_return_risk"], ele.entity_id);
                            return {
                                ...ele,
                                return: cmeInfo?.return,
                                ret_actual_date: cmeInfo?.actual_date,
                                risk: riskInfo?.risk,
                                // rsk_actual_date: riskInfo?.actual_date,
                                bm_return: bmInfo.bm_return,
                                bm_risk: bmInfo.bm_risk,
                            };
                        });
                        setAssetGroups((ag) => ({ ...ag, master: [...updatedAstGrups] }));
                    }
                    setFormData((fd) => ({ ...fd, cmeList }));
                }
            })
            .catch((e) => {
                console.log(e);
            });
    }

    useEffect(() => {
        getSharedObjects();
        Api.getZoneSettings(app, type)
            .then((response: any) => {
                const objective_function = response?.objective_function?.functions;
                if (!objective_function) {
                    const errorInfo = {
                        type: "error",
                        text: `Unable to fetch ${type?.toUpperCase()} settings`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                } else {
                    const objFuncList: any = [];
                    Object.keys(objective_function).map((key) => {
                        objFuncList.push({ id: key, label: objective_function[key].display });
                    });
                    setFormData((fd) => ({ ...fd, objFuncList }));
                }
            })
            .catch((err: any) => {
                console.log(err);
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [type, app]);

    useEffect(() => {
        Api.getSAAClassifications()
            .then((res) => {
                if (res?.data < 0) {
                    const errorInfo = {
                        type: "error",
                        text: `Unable to fetch classifications`,
                        open: true,
                    };
                    errorNotification.next(errorInfo);
                } else {
                    const cols = res.columns;
                    const data = res?.data?.map((row) => {
                        const info: any = { label: "", min: 0, max: 100 };
                        cols.forEach((col, index) => {
                            info[col] = row[index];
                        });
                        const asset_id = getAssetId(info);
                        info["id"] = asset_id;
                        info["asset_id"] = asset_id;
                        return info;
                    });
                    const entityIds: any = Array.from(
                        new Set(data?.filter((r) => r.entity_id).map((e) => e.entity_id))
                    );

                    setFormData((fd) => ({ ...fd, assetGroups: data, entityIds }));
                    setAssetGroups({ master: [...data], records: [...data] });
                    getCMEData(formData?.inputs?.cmeDate, null, entityIds, data);
                }
            })
            .catch((err) => {
                console.log(err);
            })
            .finally(() => {
                screenshot.take();
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function onConstraintsSave(info, resetFormData = true) {
        const params = { constraints: info?.constraints };
        setValidationError((e) => ({ ...e, constraint: false }));
        Api.evaluateConstraints({ req: params })
            .then((res) => {
                const cols = res.columns;
                const entries = res?.data?.map((row) => {
                    const info = {};
                    cols.forEach((col, index) => {
                        info[col] = row[index];
                    });
                    return info;
                });
                if (entries?.length > 0) {
                    const entry = entries?.find((e) => e?.min > e?.max);
                    if (entry) {
                        setValidationError((e) => ({ ...e, constraint: true }));
                    }
                }
                const updatedList = updateRowValues(assetGroups?.master, entries);
                setAssetGroups({ ...assetGroups, master: updatedList });
                if (resetFormData) {
                    setFormData((fd) => {
                        const list = fd.constraintList || [];
                        const constraintList = updateConstraintList(info, list);
                        return {
                            ...fd,
                            constraintList,
                            inputs: { ...fd.inputs, constraint: info?._id?.$oid },
                        };
                    });
                }
            })
            .catch((err) => {
                console.log("evaluateConstraints", err);
            });
    }

    async function submitAndRunOutput(request, benchmarkAssets, modelAssets) {
        const res = await Api.saaInvokeapo(request);
        if (res.message === "RebalancingStatus.NoSolutionFound") {
            const errorInfo = {
                type: "error",
                text: `No Solution Found`,
                open: true,
            };
            errorNotification.next(errorInfo);
        } else {
            setInitialOutputData({ data: res, benchmark: benchmarkAssets, modelAssets });
            setOutputData({ data: res, benchmark: benchmarkAssets, modelAssets });
            refreshData();
        }
    }

    async function editSolutionWithoutSave(editedSolution) {
        const templateInfo = formData?.inputs?._meta;
        const updatedSolution = await Api.calculateAnalysis({
            ...editedSolution,
            benchmark: templateInfo?.benchmark,
            cme_date: templateInfo?.cmeDate,
            cme_currency_code: templateInfo?.cme_currency_code,
        });

        const prev_cur_solution = outputData.data.final_objective;
        setOutputData({
            ...outputData,
            data: {
                ...outputData.data,
                final_objective: { ...editedSolution, ...updatedSolution },
                prev_final_objective: prev_cur_solution,
            },
        });
    }

    async function editOrSelectSolution(selectedFrontier) {
        const templateInfo = formData?.inputs?._meta;
        const updatedSolution = await Api.calculateAnalysis({
            ...selectedFrontier,
            benchmark: templateInfo?.benchmark,
            cme_date: templateInfo?.cmeDate,
            cme_currency_code: templateInfo?.cme_currency_code,
        });

        const templateInputs = {
            ...templateInfo,
            prev_final_objective: { ...selectedFrontier, ...updatedSolution },
        };
        const res = await Api.updateSharedState(templateInfo?._id?.$oid, templateInputs);
        if (res.message) {
            const errorInfo = {
                type: "success",
                text: res.message,
                open: true,
            };
            errorNotification.next(errorInfo);
        }
        if (res["shared-object"]) {
            const prev_cur_solution = outputData.data.final_objective;
            setOutputData({
                ...outputData,
                data: {
                    ...outputData.data,
                    final_objective: res["shared-object"].prev_final_objective,
                    prev_final_objective: prev_cur_solution,
                },
            });
            refreshData();
        }
    }

    function resetOutputData() {
        setOutputData(initialOutputData);
        editOrSelectSolution(initialOutputData.data?.final_objective);
    }

    const cfgKeyMap = {
        minheight: "minHeight",
        maxheight: "maxHeight",
        minwidth: "minWidth",
        maxwidth: "maxWidth",
    };

    function updateWindowSettings(cfg: any) {
        if (!loaded) {
            return;
        }
        const newCfg: any = windowsCfgKeys?.reduce((result, key) => {
            if (cfgKeyMap[key]) {
                result[cfgKeyMap[key]] = cfg[key];
            } else {
                result[key] = cfg[key];
            }
            return result;
        }, {});
        const id = newCfg?.id;
        if (id) {
            const settings = Settings.getSettings();
            const windows = settings?.app_settings?.aa?.saa2?.windows || {};
            const allCfg = { ...windows, [id]: newCfg };
            Settings.updateSettings("aa", "saa2", "windows", allCfg);
        }
    }

    const throttle = _.throttle(function (currRef) {
        updateWindowSettings(currRef);
    }, 500);

    const defaultBoxCfg = {
        top: 110,
        bottom: 16,
        left: 16,
        right: 16,
        noFull: true,
        noClose: true,
        className: "aa-win-box white",
        onMinimize: function () {
            const currRef = this as any;
            currRef?.setBackground("rgb(153, 221, 180)");
            updateWindowSettings(currRef);
        },
        onMaximize: function () {
            const currRef = this as any;
            currRef?.setBackground("#fff");
            updateWindowSettings(currRef);
        },
        onRestore: function () {
            const currRef = this as any;
            currRef?.setBackground("#fff");
            updateWindowSettings(currRef);
        },
        onResize: function () {
            const currRef = this as any;
            if (!currRef?.min) {
                throttle(currRef);
            }
        },
        onBlur: function () {
            const currRef = this as any;
            updateWindowSettings(currRef);
        },
    };

    function getWindowCfg(id) {
        const windowConfig: any = windowCfg?.[id];
        if (windowConfig) {
            delete windowConfig.index;
        }
        if (windowCfg?.[id].min) {
            return {
                header: windowConfig?.header,
                height: windowConfig?.height,
                index: windowConfig?.index,
                maxHeight: windowConfig?.maxHeight,
                maxWidth: windowConfig?.maxWidth,
                minHeight: windowConfig?.minHeight,
                minWidth: windowConfig?.minWidth,
                width: windowConfig?.width,
                x: windowConfig?.x,
                y: windowConfig?.y,
                //top: windowConfig?.top,
                min: true,
                // focused: window?.focused,
                // hidden: window.hidden,
                // full: window.full,
            };
        }
        return windowCfg?.[id];
    }

    async function handleDelete() {
        const res = await Api.deleteSharedState(deletePopup.deleteObj?._meta?._id?.$oid);
        errorNotification.next({ type: "success", text: res.message, open: true });
        refreshData();
        setDeletePopup((deletePopup) => ({ ...deletePopup, open: false, deleted: true }));
        if (deletePopup.deleteObj?._meta?.type === "template") {
            setSelectedTemplate(null);
        }
    }

    const deleteOption = (deleteObj) => {
        setDeletePopup({ ...deletePopup, open: true, deleteObj });
    };

    function isDisabled(isCopy = false) {
        const value = selectedTemplate?.id;
        if (!value) {
            return true;
        }
        const template = formData?.templateList?.find((t) => t.id == selectedTemplate?.id);
        if (value != template?._id?.$oid) {
            return true;
        }
        if (isCopy) {
            return false;
        }
        if (template?.["author-id"] && hasAccess(template)) {
            return false;
        }
        return true;
    }
    const getIconStyle = (isCopy = false) =>
        isDisabled(isCopy) ? { ...squareBtnStyle, opacity: 0.4 } : squareBtnStyle;

    function onShare(e, value, list) {
        const data = list?.find((ele) => ele?.id == value) || {};
        if (hasAccess(data?._meta)) {
            setShareInfo({ open: true, shareBtnRef: e.currentTarget, data });
        }
    }

    const userInfo = Access.userInfo || {};
    const templateAuthor = formData?.inputs?.author;

    function onTemplateChange(id, reload = true) {
        setSelectedTemplate({ id: id, reload });
        const templateInfo = formData?.templateList?.find((temp) => temp?._id?.$oid === id);
        const model = templateInfo?.model?.id ?? templateInfo?.model;
        const selectedOutputData = {
            data: {
                final_objective: templateInfo?.prev_final_objective || {},
            },
            benchmark:
                formData?.benchmarkList?.find((item) => item?.id === templateInfo?.benchmark)?._meta?.assets || [],
            modelAssets: formData?.modelList?.find((item) => item?.id === model)?._meta?.assetGroups || [],
        };
        setOutputData(selectedOutputData);
        setInitialOutputData(selectedOutputData);
    }

    return (
        <AppCover
            className="saa"
            header={
                <div className="template-input-grp">
                    {/* <div className="input-label" style={{ width: "30%" }}>
                        Template Name
                    </div> */}
                    <div className="input-field w-100">
                        <SearchInput
                            onChange={(_, v) => onTemplateChange(v?.id)}
                            onInputChange={(e, v) => {
                                if (e?.type === "change") {
                                    setSelectedTemplate({ id: null, name: v });
                                    setOutputData({ data: {}, benchmark: null, modelAssets: [] });
                                    setInitialOutputData({ data: {}, benchmark: null, modelAssets: [] });
                                }
                            }}
                            options={sortList(formData?.templateList)}
                            value={formData?.templateList?.find((t) => t.id == selectedTemplate?.id)}
                            placeholder="Template Name.."
                            inputPropsStyle={{ ...styles, minWidth: "215px" }}
                            disableUnderline={true}
                            forcePopupIcon={true}
                            popperWidth="300px"
                            searchIcon={false}
                            renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                        />
                        <FTIconButton
                            handler={() => setSelectedTemplate({ ...selectedTemplate, copy: true, editedName: false })}
                            title={"Copy"}
                            btnIcon={<CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={isDisabled(true)}
                            style={getIconStyle(true)}
                        />
                        <FTIconButton
                            handler={() => setSelectedTemplate({ ...selectedTemplate, editedName: true, copy: false })}
                            title={"Rename"}
                            btnIcon={
                                <DriveFileRenameOutlineIcon
                                    style={{ fontSize: "1.1rem", color: "grey" }}
                                    color="primary"
                                />
                            }
                            placement="top"
                            disabled={isDisabled()}
                            style={getIconStyle()}
                        />
                        <FTIconButton
                            handler={(e) => onShare(e, formData?.inputs?.id, formData?.templateList)}
                            title={shareInfo.open ? "" : "Share"}
                            btnIcon={<ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />}
                            placement="top"
                            disabled={isDisabled()}
                            style={getIconStyle()}
                        />
                        <ShareWith
                            shareInfo={shareInfo}
                            setShareInfo={setShareInfo}
                            refreshData={refreshData}
                            setBenchmarkModelData={() => {
                                return null;
                            }}
                        />
                        <div className="temp-input-grp2 saa-template-selector">
                            <div className="input-label w-100" style={{ textAlign: "left" }}>
                                Created by
                            </div>
                            <div className="label-value capitalize" style={{ width: "100%" }}>
                                {templateAuthor ? templateAuthor : userInfo?.name}
                            </div>
                        </div>
                    </div>
                </div>
            }
        >
            {loaded && (
                <>
                    <WinBox id="input" title="SAA Inputs" {...defaultBoxCfg} {...getWindowCfg("input")}>
                        <div className="saa" id="saa-input" key="input">
                            <SAAInput
                                app={app}
                                zone={type}
                                assetGroups={assetGroups}
                                formData={formData}
                                setFormData={setFormData}
                                outputData={outputData}
                                onConstraintsSave={onConstraintsSave}
                                refreshData={getSharedObjects}
                                getCMEData={getCMEData}
                                submitAndRunOutput={submitAndRunOutput}
                                validationError={validationError}
                                deleteOption={deleteOption}
                                deleteObj={deletePopup}
                                setDeleteObj={setDeletePopup}
                                selectedTemplate={selectedTemplate}
                                onTemplateChange={onTemplateChange}
                            />
                        </div>
                    </WinBox>
                    <WinBox
                        id="constraintsSet"
                        title="Constraints Set"
                        {...defaultBoxCfg}
                        {...getWindowCfg("constraintsSet")}
                    >
                        <div className="saa" style={{ height: "100%" }}>
                            <ConstraintsSet
                                assetGroups={assetGroups}
                                app={app}
                                zone={type}
                                onConstraintsSave={onConstraintsSave}
                                constraintList={formData?.constraintList}
                                refreshData={refreshData}
                                deleteOption={deleteOption}
                                deleteObj={deletePopup}
                                setDeleteObj={setDeletePopup}
                            />
                        </div>
                    </WinBox>
                    <WinBox id="output" title="SAA Outputs" {...defaultBoxCfg} {...getWindowCfg("output")}>
                        <div className="saa">
                            <Output
                                data={outputData}
                                editOrSelectSolution={editOrSelectSolution}
                                editSolutionWithoutSave={editSolutionWithoutSave}
                                resetOutputData={resetOutputData}
                            />
                        </div>
                    </WinBox>
                    <WinBox
                        id="optimalPortfolio"
                        title="Optimal Portfolio"
                        {...defaultBoxCfg}
                        {...getWindowCfg("optimalPortfolio")}
                    >
                        <div className="saa">
                            <OptimalPortfolio
                                data={outputData}
                                editOrSelectSolution={editOrSelectSolution}
                                resetOutputData={resetOutputData}
                            />
                        </div>
                    </WinBox>
                    <ConfirmDialog
                        title=""
                        open={deletePopup.open}
                        setOpen={(open) => setDeletePopup({ ...deletePopup, open })}
                        stopPropagation={true}
                        onConfirm={(e) => {
                            e?.stopPropagation();
                            handleDelete();
                        }}
                    >
                        Are you sure you want to delete?
                    </ConfirmDialog>
                </>
            )}
        </AppCover>
    );
}
