import React, { useMemo, useRef, useCallback } from "react";
import { Paper } from "@mui/material";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
// import moment from "moment";
// import FTDatePicker from "common/FTDatePicker";
import { AgGridReact } from "ag-grid-react";

function formatRecords(records) {
    return records.map((record) => ({
        id: record._id.$oid,
        date: record._meta.create_timestamp?.substring(0, 10),
        time: record._meta.create_timestamp?.substring(11, 19),
        createdBy: record._meta?.author,
    }));
}

export default function AuditTrail({ records, onSelectPastRecord }) {
    const gridRef = useRef<AgGridReact>(null);
    const defaultColDef = useMemo(() => {
        return {
            enableValue: true,
            width: 100,
            resizable: true,
            flex: 1,
            minWidth: 100,
            suppressMenu: true,
        };
    }, []);
    const columns = [
        {
            headerName: "Date",
            field: "date",
        },
        {
            headerName: "Time",
            field: "time",
        },
        {
            headerName: "Created By",
            field: "createdBy",
        },
        // {
        //     headerName: "Template Name",
        //     field: "template",
        // },
        // {
        //     headerName: "Model",
        //     field: "model",
        // },
        // {
        //     headerName: "Risk Model",
        //     field: "risk",
        // },
        // {
        //     headerName: "Objectives fn",
        //     field: "objectivesFn",
        // },
        // {
        //     headerName: "Hurdles",
        //     cellStyle: { textAlign: "center" },
        //     children: [
        //         {
        //             headerName: "<= % Risk",
        //             field: "hurdlesRisk",
        //         },
        //         {
        //             headerName: ">= % Ret",
        //             field: "hurdlesRet",
        //         },
        //     ],
        // },
        // {
        //     headerName: "CME",
        //     cellStyle: { textAlign: "center" },
        //     children: [
        //         {
        //             headerName: "Date",
        //             field: "CMEDate",
        //         },
        //         {
        //             headerName: "Currency",
        //             field: "currency",
        //         },
        //     ],
        // },
        // {
        //     headerName: "Constraints",
        //     field: "constraints",
        // },
        // {
        //     headerName: "Benchmark",
        //     field: "benchmark",
        // },
        // {
        //     headerName: "Trckng Err",
        //     field: "trackingErr",
        // },
    ];

    const onSelectionChanged = useCallback(
        (e) => {
            const selectedRows = e.api.getSelectedRows();
            onSelectPastRecord(selectedRows[0]?.id);
        },
        [onSelectPastRecord]
    );

    return (
        <div id="audit-trail" style={{ width: "100%", height: "100%" }}>
            <Paper square elevation={5} style={{ width: "100%", height: "100%", padding: "15px" }}>
                {/* <div className="time-wrapper">
                    <label className="time-picker">
                        <div>Show From</div>
                        <div className="date-picker-alignment">
                            <FTDatePicker
                                label=""
                                format="dd/MM/yyyy"
                                style={styles}
                                dateStr={moment(new Date()).format("YYYY-MM-DD")}
                                handleDateChange={() => true}
                                disableUnderline
                                inputPropsStyle={innerStyles}
                            />
                        </div>
                    </label>
                    <label className="time-picker">
                        <div>To</div>
                        <div className="date-picker-alignment">
                            <FTDatePicker
                                label=""
                                format="dd/MM/yyyy"
                                style={styles}
                                dateStr={moment(new Date()).format("YYYY-MM-DD")}
                                handleDateChange={() => true}
                                disableUnderline
                                inputPropsStyle={innerStyles}
                            />
                        </div>
                    </label>
                </div> */}
                <div style={{ height: "450px", width: "100%" }}>
                    <AgGridReact
                        rowData={formatRecords(records)}
                        ref={gridRef}
                        columnDefs={columns}
                        defaultColDef={defaultColDef}
                        rowSelection={"single"}
                        onSelectionChanged={onSelectionChanged}
                    />
                </div>
            </Paper>
        </div>
    );
}
