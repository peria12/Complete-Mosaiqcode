import React from "react";
import clsx from "clsx";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import CloseIcon from "@mui/icons-material/Close";
import { FTIconButton } from "common/FTButtons";
import { styled } from "@mui/material/styles";
import Tooltip, { tooltipClasses } from "@mui/material/Tooltip";
import moment from "moment";

import { assetCols } from "../utils/aa-cfg";
import { numberVal } from "../utils/aa-helper";

function getValue(col, row) {
    if (col.percentage) {
        const val = numberVal(row[col.id]);
        if (val != undefined && val != null) {
            return val + "%";
        }
        return "";
    }
    return row[col.id];
}

const iconStyle = { fontSize: "1.2rem", color: "grey" };

function DeleteIcon({ row, onDelete }) {
    const isGroupedRow = row?.isGroupedRow || false;
    if (isGroupedRow) {
        return <></>;
    }
    return (
        <FTIconButton
            handler={() => onDelete(row)}
            title="Remove"
            style={{ padding: "0px" }}
            btnIcon={<CloseIcon style={iconStyle} color="primary" />}
            placement="top"
        />
    );
}

function DeleteIconHeader({ onDeleteAll }) {
    return (
        <FTIconButton
            handler={onDeleteAll}
            title="Remove All"
            style={{ padding: "1px" }}
            btnIcon={<CancelOutlinedIcon style={iconStyle} color="primary" />}
            placement="top"
        />
    );
}

const HtmlTooltip = styled(({ className, isValid, ...props }: any) => (
    <Tooltip {...props} disableHoverListener={isValid} classes={{ popper: className }} />
))(() => ({
    [`& .${tooltipClasses.tooltip}`]: {
        backgroundColor: "#f5f5f9",
        fontFamily: "Roboto",
        fontSize: ".9rem",
        maxWidth: 220,
        border: "1px solid #dadde9",
        color: "#DC4545",
    },
}));

const isEmpty = (v) => v === null || v === undefined || v === "";

const _isValid = (r) => r?.min > r?.max || isEmpty(r?.risk) || isEmpty(r?.return);

function Status({ row }) {
    const isGroupedRow = row?.isGroupedRow || false;
    if (isGroupedRow) {
        return <></>;
    }
    const isValid = _isValid(row);
    return (
        <div style={{ display: "flex", justifyContent: "center" }}>
            <HtmlTooltip
                isValid={!isValid}
                title={
                    <>
                        {isEmpty(row?.risk) && <div>Risk value is not available</div>}
                        {isEmpty(row?.return) && <div>Return value is not available</div>}
                        {row?.min > row?.max && <div>Invalid constraint {row?.return}</div>}
                    </>
                }
            >
                <div className="traffic-light">
                    <div className={clsx("top circle", { active: isValid })} />
                    <div className={clsx("center circle", { active: row?.min == row?.max })} />
                    <div className={clsx("bottom circle", { active: !isValid })} />
                </div>
            </HtmlTooltip>
        </div>
    );
}

const getRowCellStyle = (col) => ({
    height: "30px",
    minHeight: "30px",
    width: col.width || "50px",
    minWidth: col.minWidth || "50px",
});

const getHeaderCellStyle = (col) => ({
    width: col.width || "50px",
    minWidth: col.minWidth || "50px",
});

const getDateStyle = (row, analysisDate) => {
    let style: any = { fontSize: "11px", paddingLeft: 1 };
    const cmeDate = row["ret_actual_date"];
    const diff = moment(analysisDate).diff(moment(cmeDate), "days");
    if (cmeDate && analysisDate && diff > 30) {
        style = {
            ...style,
            color: "#FE9467",
        };
    }
    return style;
};

const sliceIndex = 5;
const cols: any = assetCols.slice(0, sliceIndex);
const cols2: any = assetCols.slice(sliceIndex);

export default function AssetTable({ rows, onDelete, onDeleteAll, isEditable, analysisDate }) {
    function Table({ cols, rows }) {
        return (
            <table>
                <thead>
                    <tr>
                        {cols?.map((col) => {
                            if (!isEditable && col.id == "delBtn") {
                                return null;
                            }
                            return (
                                <th key={col.id} style={getHeaderCellStyle(col)}>
                                    <div>
                                        <span
                                            className={clsx({
                                                "saa-border": col.id == "return" || col.id == "ret_actual_date",
                                            })}
                                            style={{ textAlign: col.id == "status" ? "center" : undefined }}
                                        >
                                            {col.id == "delBtn" ? (
                                                <DeleteIconHeader onDeleteAll={onDeleteAll} />
                                            ) : (
                                                col.name
                                            )}
                                        </span>
                                    </div>
                                </th>
                            );
                        })}
                    </tr>
                </thead>
                <tbody>
                    {rows?.map((row, i) => (
                        <tr key={i} className={row.isGroupedRow ? "saa-texthead" : ""}>
                            {cols?.map((col) => {
                                if (!isEditable && col.id == "delBtn") {
                                    return null;
                                }
                                return (
                                    <td
                                        key={col.id}
                                        style={getRowCellStyle(col)}
                                        className={clsx({
                                            "border-left": col.id == "return" || col.id == "ret_actual_date",
                                        })}
                                        onClick={col.id == "delBtn" ? onDelete : undefined}
                                    >
                                        {(() => {
                                            switch (col.id) {
                                                case "delBtn":
                                                    return <DeleteIcon row={row} onDelete={onDelete} />;
                                                case "status":
                                                    return <Status row={row} />;
                                                case "ret_actual_date":
                                                    return (
                                                        <span style={getDateStyle(row, analysisDate)}>
                                                            {getValue(col, row)}
                                                        </span>
                                                    );
                                                default:
                                                    return getValue(col, row);
                                            }
                                        })()}
                                    </td>
                                );
                            })}
                        </tr>
                    ))}
                </tbody>
            </table>
        );
    }

    return (
        <section className="ft-saa_tb" id="blur">
            <div className="ft-card ft-saa_tbcontent">
                <div className="ft-card-header-saa">
                    <Table cols={cols} rows={rows} />
                </div>
                <div className="ft-card-header-Y3">
                    <div className="saa-2">
                        <div className="saa-constraints">
                            <div className="saa-h4">Constraints</div>
                            <div className="saa-bottom-bar1"></div>
                        </div>
                        <div className="saa-cme">
                            <div className="saa-h4">CME</div>
                            <div className="saa-bottom-bar1"></div>
                        </div>
                    </div>
                    <Table cols={cols2} rows={rows} />
                </div>
            </div>
        </section>
    );
}
