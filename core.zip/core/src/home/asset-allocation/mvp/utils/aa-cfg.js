
import moment from "moment";

export const defaultLayoutCfg = {
    input: {
        x: 15,
        y: 100,
        height: 440,
        minHeight: 300,
        width: 700,
        minWidth: 600,
        top: window.innerWidth < 1650 ? 180 : 110
    },
    output: {
        x: 720,
        y: 100,
        minWidth: 400,
        width: 970,
        height: 440,
        minHeight: 300,
    },
    constraintsSet: {
        x: 15,
        y: 550,
        height: 250,
        minHeight: 200,
        width: 900,
        minWidth: 300,
    },

    optimalPortfolio: {
        x: 920,
        y: 550,
        height: 250,
        minHeight: 200,
        width: 770,
        minWidth: 300,
    }
}


// export const daaDefaultLayoutCfg = {
//     benchmarks: {
//         x: 15,
//         y: 100,
//         height: 440,
//         minHeight: 300,
//         width: 700,
//         minWidth: 600,
//     },
//     parentChildMapping: {
//         x: 920,
//         y: 550,
//         height: 250,
//         minHeight: 200,
//         width: 770,
//         minWidth: 300,
//     },
//     isrcMapping: {
//         x: 720,
//         y: 100,
//         minWidth: 800,
//         width: 970,
//         height: 440,
//         minHeight: 300,
//     },
//     daaGraphs: {
//         x: 15,
//         y: 550,
//         height: 250,
//         minHeight: 200,
//         width: 900,
//         minWidth: 300,
//     },
// }

export const daaGraphCols1 = [
    {
        header: "BM",
        col: "Prospectus",
        name: "bmProspectus"
    }, {
        header: "BM % of",
        col: "Asset Class",
        name: "bmPercent"
    }, {
        header: "SAA",
        col: "Output",
        name: "saaSolution"
    }, {
        header: "DAA",
        col: "Current",
        name: "daaCurrent"
    }, {
        header: "DAA",
        col: "Target",
        name: "daaTarget"
    }, {
        header: "DAA % of",
        col: "Asset Class",
        name: "daaPercent"
    }, {
        header: "Absolute",
        col: "Difference",
        name: "absoluteDiff"
    }, {
        header: "% of",
        col: "Difference",
        name: "diffPercent"
    }
]

export const daaGraphCols2 = [
    {
        header: "ISRC",
        cols: [
            { col: "BM", name: "isrcBenchmark" },
            { col: "Current", name: "isrc" }
        ],
        showForSecTable: true
    },
    {
        header: "Tilt",
        cols: [
            { col: "Policy", name: "policy" },
            { col: "Custom", name: 'custom' }
        ],
        showForSecTable: false,
    }, {
        header: "Limit",
        cols: [
            { col: "Min", name: "min" },
            { col: "Max", name: 'max' }
        ],
        showForSecTable: false
    }
]

export const parentChildMappingCols1 = [
    { label: "", name: "key", style: { width: '10px', fontSize: '0.8rem' } },
    { label: "", name: "del", style: { width: '10px', padding: 0 } },
    { label: "Parent", name: 'parent', style: { display: 'flex', alignItems: 'center', justifyContent: 'center', width: '50px' } },
    { label: 'Portfolios', name: 'portfolios', style: { width: '160px' } },
    { label: 'Description', name: 'description', style: { width: '120px' } },
    { label: 'Benchmark', name: 'benchmark', style: { width: '160px', "textAlign": "left" } },
    { label: 'SAA', name: 'saa', style: { width: '160px' } },
    { label: 'Currency', name: 'currency', style: { width: '120px' } },
    { label: 'TE', name: 'trackingError', style: { width: '50px' } }]

export const parentChildMappingCols2 = [
    { label: 'Equity', name: 'Equity', headerStyle: { color: "rgba(37, 116, 189, 0.897)" } },
    { label: 'Fixed Income', name: 'Fixed Income', headerStyle: { color: "rgba(240, 72, 94, 0.815)" } },
    { label: 'Alternatives', name: 'Alternatives', headerStyle: { color: "rgba(83, 72, 240, 0.89)" } },
    { label: 'Cash', name: 'Cash', headerStyle: { color: "rgba(93, 209, 112, 0.87)" } }
]
export const windowsCfgKeys = ["focused", "full", "hidden", "header", "id", "index", "top", "bottom", "left", "right", "x", "y", "max", "min", "height", "minheight", "maxheight", "width", "minwidth", "maxwidth"];

export const operatorOptions = [
    {
        label: '<=',
        value: '<=',
        disable: ["min"]
    },
    {
        label: '>=',
        value: '>=',
        disable: ["max"]
    },
    {
        label: 'Btwn',
        value: 'Btwn',
        disable: []
    }
]
export const defaultFormData = {
    inputs: {
        cme_currency_code: "USD",
        riskModel: "FTIS Return-Based",
        cmeDate: moment(new Date()).format("YYYY-MM-DD"),
        trackingError: "",
        trackingErrorMin: 0,
        trackingErrorMax: 10
    },
    currencyList: [
        { id: "USD", label: "USD" },
        { id: "EUR", label: "EUR" },
        { id: "JPY", label: "JPY" },
        { id: "GBP", label: "GBP" },
        { id: "AUD", label: "AUD" },
        { id: "CAD", label: "CAD" },
    ],
    riskModelList: [
        { id: "FTIS Return-Based", label: "FTIS Return-Based" }
    ]
}

export const p_columns = [
    { label: "P*", value: "p", class: "ft-saa-p" },
    { label: "BM", value: "bm", class: "ft-saa-bm" },
    { label: "P1", value: "p1", class: "ft-saa-p1", hoverEffect: true },
    { label: "P2", value: "p2", class: "ft-saa-p1", hoverEffect: true },
    { label: "P3", value: "p3", class: "ft-saa-p1", hoverEffect: true },
    { label: "P4", value: "p4", class: "ft-saa-p1", hoverEffect: true },
    { label: "P5", value: "p5", class: "ft-saa-p1", hoverEffect: true },
    { label: "P6", value: "p6", class: "ft-saa-p1", hoverEffect: true },
    { label: "P7", value: "p7", class: "ft-saa-p1", hoverEffect: true },
    { label: "P8", value: "p8", class: "ft-saa-p1", hoverEffect: true },
    { label: "P9", value: "p9", class: "ft-saa-p1", hoverEffect: true },
    { label: "P10", value: "p10", class: "ft-saa-p1", hoverEffect: true },
];

export const tb2_rows = [
    { label: "Equity", value: "equity" },
    { label: "Contribution to Risk", value: "contributionToRisk" },
];

export const tb3_rows = [
    { label: "Return", value: "expected_return" },
    { label: "Volatility", value: "total_risk" },
    { label: "5%VaR", value: "5_pcnt_VaR" },
    { label: "5%CVaR", value: "5_pcnt_CVaR" },
    { label: "Sharpe Ratio", value: "sharpe_ratio" },
    { label: "Tracking Error", value: "tracking_error" },
    { label: "Beta", value: "portfolio_predicted_beta" },
    { label: "Up Capture", value: "up_capture" },
    { label: "Down Capture", value: "down_capture" },
];

export const tb2_rows_for_daa = [
    { label: "Expected Risk", value: "expectedRisk" },
    { label: "Expected Return", value: "expectedReturn" },
];

export const squareBtnStyle = {
    border: " 1px solid rgb(217 207 207)",
    borderRadius: 3,
    padding: "3px",
    width: "30px",
    marginLeft: 3,
};

export const numericFieldCfg = {
    headerClass: "numeric-header-cell",
    cellClass: "numeric-cell",
    valueFormatter: (params) => {
        const value = params.value;
        if (value !== "" && value !== undefined && value !== null) {
            return value + "%";
        }
        return "";
    },
    minWidth: 50,
    width: 50,
};

export const assetCols = [
    {
        id: "delBtn",
        name: "",
    },
    {
        id: "asset_class",
        name: "Class",
    },
    {
        id: "category",
        name: "Category",
        minWidth: 150
    },
    {
        id: "sub_category",
        name: "Sub Category",
        minWidth: 150
    },
    {
        id: "asset",
        name: "Asset Description",
        minWidth: 150
    },
    {
        id: "current",
        name: "Current",
        align: "right",
        percentage: true
    },
    {
        id: "min",
        name: "Min",
        align: "right",
        percentage: true
    },
    {
        id: "max",
        name: "Max",
        align: "right",
        percentage: true
    },
    {
        id: "status",
        name: "Status",
    },
    {
        id: "risk",
        name: "Rsk",
        align: "right",
        percentage: true
    },
    {
        id: "return",
        name: "Rtn",
        align: "right",
        percentage: true
    },
    {
        id: "ret_actual_date",
        name: "CME Date",
        align: "left",
        minWidth: 67,
        width: 67,
    },
]

const mappingOffset = 650
export const isrcMappingCfg = {
    id: "isrc",
    title: "ISRC Mapping",
    type: "isrcMapping",
    offset: mappingOffset,
    headers: [
        { id: "name", name: "Name", x: 0, position: "left" },
        { id: "region", name: "Region", x: 200, position: "left" },
        // list 2
        { id: "category", name: "Category", x: 150 + mappingOffset, position: "right" },
        { id: "sub_category", name: "Sub Category", x: 380 + mappingOffset, position: "right" },
        { id: "asset", name: "Asset Description", x: 590 + mappingOffset, position: "right" },
    ],
}

export const isrcBmMappingCfg = {
    id: "isrcBenchmark",
    title: "ISRC Benchmark Mapping",
    type: "isrcBenchmarkMapping",
    offset: mappingOffset,
    headers: [
        { id: "name", name: "Name", x: 0, position: "left" },
        { id: "region", name: "Region", x: 200, position: "left" },
        // list 2
        { id: "category", name: "Category", x: 150 + mappingOffset, position: "right" },
        { id: "sub_category", name: "Sub Category", x: 380 + mappingOffset, position: "right" },
        { id: "asset", name: "Asset Description", x: 590 + mappingOffset, position: "right" },
    ]
}
export const benchmarkMappingCfg = {
    id: "benchmarkMapping",
    title: "Benchmark Mapping",
    type: "benchmarkMapping",
    offset: mappingOffset,
    headers: [
        { id: "benchmark", name: "Benchmark", x: 0, position: "left" },
        // list 2
        { id: "category", name: "Category", x: 150 + mappingOffset, position: "right" },
        { id: "sub_category", name: "Sub Category", x: 380 + mappingOffset, position: "right" },
        { id: "asset", name: "Asset Description", x: 590 + mappingOffset, position: "right" },
    ]
}
