import React from "react";
import Paper from "@mui/material/Paper";
import { HChart } from "common/HChart";
import { numberVal } from "../utils/aa-helper";

const colors = {
    0: ["#052D79", "#0f43a5", "#03389D", "#044FDD", "#3270FC", "#5195FC", "#91BAFD", "#DDEBFE"],
    1: ["#9F0535", "#C10640", "#DA0547", "#FD0F53", "#FD4B7C", "#FD87A8", "#FFABC3", "#FFD1DE"],
    2: ["#471DB4", "#8F69F0", "#7147c3", "#835bca", "#946fd1", "#a583d8", "#b497df", "#c4abe5"],
    3: ["#129F95", "#55b0a7", "#6bb9b1", "#7fc2ba", "#92cbc4", "#a5d3cd", "#b7dcd7", "#c9e5e1"],
};

const legendColStyle = `"font-size:12px; min-width:38px; font-family:'Roboto condensed'; font-style: italic; font-weight:500; text-align: right;"`;
const legendColStyle2 = `"font-size:12px; font-weight:500;font-style: italic;padding-left: 5px;"`;
const orderMap = {
    Equity: 1,
    "Fixed Income": 2,
    Alternatives: 3,
    Cash: 4,
};

const mapSeries = (data, colors, pfs) => {
    return data.map((ele, i) => {
        const weights = pfs.map((id) => numberVal(ele[id] || 0));
        return {
            name: `${ele?.asset_class} - ${ele?.sub_category}  ${ele?.asset_name}`,
            color: colors[i],
            data: weights,
        };
    });
};

function getSeriesData(assets, pfs) {
    const types = Array.from(new Set(assets?.map((e) => e?.asset_class)));
    types.sort((a: any, b: any) => {
        const val1 = orderMap[a] || 100;
        const val2 = orderMap[b] || 100;
        return val1 - val2;
    });

    let seriesData: any = [];
    types.map((type, i) => {
        const list = mapSeries(
            assets?.filter((ele) => ele.asset_class == type),
            colors[i % 4],
            pfs
        );
        const lastIdx = list.length - 1;
        if (i < types.length - 1) {
            list[lastIdx].separator = true;
        }
        seriesData = [...seriesData, ...list];
    });
    return seriesData;
}

function getWeight(val) {
    if (val != null) {
        return val + "%";
    }
    return "";
}

export default function AssetAllocationWeights({ portfolios = [], data }) {
    function highlighSelectedArea(e, type = "") {
        const series = e.series || e;
        const chart = series?.chart;

        if (chart.customRect) {
            chart.customRect.destroy();
        }

        function drawRect(info) {
            const { x, top, width, height, index } = info;
            chart.selectedPortfolio = index;
            chart.customRect = chart?.renderer
                .rect(x, top, width, height)
                .attr({ fill: "transparent", id: "area-square-selector" })
                .add();
            chart?.series?.forEach((series) => {
                series?.show();
            });
        }

        if (type == "mouseOut" && chart.lastClickedInfo) {
            return drawRect(chart.lastClickedInfo);
        }

        const cpRange = series.closestPointRangePx * 0.6;

        const yAxis = series.yAxis;
        const top = yAxis.toPixels(yAxis.max) - 10;
        const bottom = yAxis.toPixels(yAxis.min);
        const height = bottom - top + 30;
        const width = cpRange * 1.2;
        const x = e.clientX / 1.2;
        const drawInfo = { x, top, width, height, index: e?.index };
        drawRect(drawInfo);
        if (type == "click") {
            chart.lastClickedInfo = drawInfo;
        }
    }
    const portfolioIds = portfolios?.map((e: any) => e?.portfolios);
    let categories = portfolioIds;

    function getOptions(data) {
        if (!data?.portfolios?.length && !categories?.length) {
            return { title: { text: "" } };
        }

        portfolioIds?.map((id) => {
            const weights = data?.map((ele) => numberVal(ele[id] || 0));
            const sum = weights?.reduce((p, c) => p + c, 0);
            let total = 0;
            if (weights?.length) {
                total = Number(sum?.toFixed(0));
                if (total != 100) {
                    categories = categories?.filter((item) => item != id);
                }
            }
        });

        return {
            chart: {
                type: "area",
                spacingLeft: 0,
            },
            title: { text: null },
            // accessibility: {
            //     point: {
            //         valueDescriptionFormat:
            //             "{index}. {point.category}, {point.y:,.1f} billions, {point.percentage:.1f}%.",
            //     },
            // },
            xAxis: {
                minPadding: 0,
                categories: categories,
                labels: {
                    align: "center",
                    overflow: "justify",
                },
                startOnTick: false,
                endOnTick: false,
            },
            yAxis: {
                min: 0,
                max: 100,
                labels: {
                    format: "{value}%",
                },
                title: {
                    enabled: false,
                },
            },
            tooltip: {
                enabled: true,
                pointFormat:
                    '<span style="color:{series.color}">{series.name}</span>: <b>{point.percentage:.2f}%</b><br/>',
                // split: true
            },
            plotOptions: {
                series: {
                    // pointStart: 0
                    pointPlacement: "on",
                    lineWidth: 0.2,
                    states: {
                        inactive: {
                            // opacity: 1
                        },
                    },
                },
                area: {
                    pointPlacement: "on",
                    stacking: "percent",
                    marker: {
                        enabled: false,
                        states: {
                            hover: {
                                enabled: false,
                            },
                        },
                    },
                    point: {
                        events: {
                            click: function () {
                                const curr = this as any;
                                highlighSelectedArea(curr, "click");
                            },
                            mouseOver: function () {
                                const curr = this as any;
                                highlighSelectedArea(curr);
                            },
                        },
                    },
                    events: {
                        mouseOut: function () {
                            // const curr = this as any;
                            // highlighSelectedArea(curr, "mouseOut")
                        },
                    },
                    showInLegend: true,
                },
            },
            legend: {
                align: "right",
                layout: "vertical",
                width: "40%",
                verticalAlign: "middle",
                backgroundColor: "white",
                borderColor: "#CCC",
                borderWidth: 0,
                shadow: true,
                marginLeft: 0,
                itemMarginTop: 4,
                title: {
                    text: `
                <span style="width: 100%; display:flex;">
                    <span style="min-width:20px;"></span>
                    <span style=${legendColStyle}>Wgts</span>
                </span>`,
                    style: {
                        fontStyle: "italic",
                    },
                },
                symbolRadius: 2,
                useHTML: true,
                labelFormatter: function () {
                    const curr = (this as any)?.userOptions;
                    const pfIndex = (this as any)?.chart?.selectedPortfolio || 0;
                    const weight = numberVal(curr?.data[pfIndex]);
                    let separatorStyle = "";
                    if (curr?.separator) {
                        separatorStyle = `border-bottom: 2px solid #ccc;width:250px;padding-bottom:6px;margin-bottom:6px`;
                    }
                    return `
                    <span style="width: 100%; display:flex;${separatorStyle}"> 
                        <span style=${legendColStyle}>${getWeight(weight)}</span>
                        <span style=${legendColStyle2}>${curr.name}</span>
                    </span>
                `;
                },
            },
            series: getSeriesData(data, categories),
        };
    }
    const options: any = React.useMemo(
        () => getOptions(data),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [data]
    );

    return (
        <Paper className="saa-outputs" square elevation={5} style={{ width: "100%", padding: "0px 8px" }}>
            <div className="saa-drag card-header w-100" style={{ textAlign: "left", marginBottom: 7 }}>
                {" "}
                Asset Allocation Weights{" "}
            </div>
            <HChart option={options} style={{ height: "100%", width: "100%", display: "flex", alignItems: "center" }} />
        </Paper>
    );
}
