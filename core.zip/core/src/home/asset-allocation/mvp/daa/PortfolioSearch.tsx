import React from "react";
import AutocompleteField from "common/AutocompleteField";
import { globalSearch } from "utils/helpers";

const styles = {
    height: "30px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    padding: "2px 18px 2px 4px",
    fontSize: 13,
    borderColor: "rgb(217 207 207)",
};

export default function PortfolioSearch({ portfolioList, value, handleChange, ...props }) {
    const provider = (options: object[] = [], query) => {
        if (!query) {
            return Promise.resolve([options, options.length]);
        }
        const results = globalSearch(options, query, 0);
        return Promise.resolve([results, results.length]);
    };

    const RenderOption = function (props, option) {
        return (
            <li {...props} style={{ fontSize: "14px" }}>
                <div className="col-2 text-truncate">{option?.id}</div>
                <div className="col-10 text-truncate">{option.label}</div>
            </li>
        );
    };

    return (
        <div style={{ width: "100%" }}>
            <AutocompleteField
                onChange={(_, v) => handleChange("portfolio", v?.id)}
                provider={(q) => provider(portfolioList, q)}
                value={value ? portfolioList?.find((f) => f.id == value) : { id: "", label: "" }}
                placeholder="Select Portfolio"
                inputPropsStyle={props.inputStyles ?? styles}
                disableUnderline={true}
                renderOption={RenderOption}
                forcePopupIcon={true}
                searchIcon={false}
                popperWidth="400px"
            />
        </div>
    );
}
