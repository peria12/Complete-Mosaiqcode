import * as d3 from "d3";
import errorNotification from "utils/api-error";

const listStyle = { itemHeight: 31, margin: 30, x: 0, y: 60 };
const leftCircleX = 410;
const rightCircleX = 120;
const minLinkStrokeWidth = 0.75;
const maxLinkStrokeWidth = 4;
const idPrefixLeft = "left_";
const idPrefixRight = "right_";
const defaultSvgHeight = 300;

const instances = {};

export function mappingManager(id) {
    let offset = 650;
    let colStrMaxWidth = 25;
    let list1: any = [];
    let list2: any = [];
    let links: any = [];
    let headers: any = [];
    let headerMap: any = {};
    let mappings: any = {};
    let selectedItemLeft: any = null;
    let selectedItemRight: any = null;
    let isValidTotalWeight = false;
    let svgHeight = defaultSvgHeight;

    function setHeaders(_headers, _offset, _colStrMaxWidth = 25) {
        headers = _headers;
        offset = _offset;

        headerMap = headers.reduce((result, item) => {
            result[item.id] = item;
            return result;
        }, {});
        colStrMaxWidth = _colStrMaxWidth;
    }

    const getLinkWeight = (weight) => Number(weight)?.toFixed(1);

    function header(svg) {
        headers.forEach((header) => {
            svg.append("text").attr("class", "header").attr("x", header.x).attr("y", 25).text(header.name);
        });

        svg.append("line")
            .attr("x1", 0)
            .attr("y1", 35)
            .attr("x2", 1500)
            .attr("y2", 35)
            .attr("stroke", "#E5E5E5")
            .attr("stroke-width", "2.5");
    }

    const styleListItem = (d) => {
        if (d.isGroupedRow) {
            const color = d.color || "#3270FC";
            return `fill:${color};font-style:italic;font-size: 15.5px;`;
        }
        return "";
    };

    function trimText(text = "") {
        if (text?.length <= colStrMaxWidth) return text;
        return text.substring(0, colStrMaxWidth).concat("...");
    }

    function drawColumn(listItem, field, isLeftList) {
        const x = headerMap[field].x;

        listItem
            .append("text")
            .attr("class", "list-item")
            .attr("x", isLeftList ? x : x - offset)
            .attr("y", (_, i) => i * listStyle.itemHeight)
            .text((item) => trimText(item[field]))
            .attr("style", styleListItem);
    }

    const isEmpty = (obj: any = {}) => !(Object.keys(obj)?.length > 0);

    function onResetWeight(d) {
        const l_id = `${idPrefixLeft}${d?.id}`;
        const r_id = `${idPrefixRight}${d?.mapId}`;
        if (d?.position == "right") {
            mappings[l_id][r_id][1] = false;
            updateWeight(l_id, d?.position);
        } else {
            mappings[r_id][l_id][1] = false;
            updateWeight(r_id, d?.position);
        }
        loadMapping();
    }

    function removeEmptyMap() {
        Object.keys(mappings).map((k) => {
            const map = mappings[k] || {};
            if (isEmpty(map)) {
                delete mappings?.[k];
            }
        });
    }

    function removeMapping(d) {
        let id = "";
        if (d?.position == "left") {
            id = `${idPrefixLeft}${d?.id}`;
        } else {
            id = `${idPrefixRight}${d?.mapId}`;
        }
        const map = mappings[id] || {};
        const refId = Object.keys(map)?.[0];
        delete mappings[id];
        Object.keys(mappings[refId])?.some((k) => {
            if (k == id) {
                delete mappings?.[refId]?.[k];
                removeEmptyMap();
                return true;
            }
        });
        const refKeys = Object.keys(mappings[refId] || {});
        if (refKeys.length > 0) {
            const itemId = refKeys[0];
            updateWeight(refId, mappings?.[refId]?.[itemId]?.[2]);
        }
        loadMapping();
    }

    function createMapping(tgtPos, weight = 100, modified = false) {
        const l_id = `${idPrefixLeft}${selectedItemLeft}`;
        const r_id = `${idPrefixRight}${selectedItemRight}`;
        if (!mappings[l_id]) {
            mappings[l_id] = {};
        }
        if (!mappings[r_id]) {
            mappings[r_id] = {};
        }
        const leftLinks = Object.keys(mappings[l_id]);
        const rightLinks = Object.keys(mappings[r_id]);
        const leftMap = mappings[l_id] || {};
        const rightMap = mappings[r_id] || {};
        let isValid = true;
        if (leftLinks?.length > 0) {
            if (!isEmpty(rightMap)) {
                isValid = false;
            } else {
                const linked = Object.keys(leftMap).filter((k) => Object.keys(mappings[k])?.length > 1);
                if (linked.length > 0) {
                    isValid = false;
                }
            }
        }
        if (rightLinks?.length > 0) {
            if (!isEmpty(leftMap)) {
                isValid = false;
            } else {
                const linked = Object.keys(rightMap).filter((k) => Object.keys(mappings[k])?.length > 1);
                if (linked.length > 0) {
                    isValid = false;
                }
            }
        }

        if (!isValid) {
            errorNotification.next({
                type: "error",
                text: "Many-to-many links are not supported",
                open: true,
            });
        } else {
            mappings[l_id][r_id] = [weight, modified, tgtPos];
            mappings[r_id][l_id] = [weight, modified, tgtPos];
            if (Object.keys(mappings[l_id])?.length > 1) {
                mappings[r_id][l_id] = "right";
                updateWeight(l_id, "right");
            }
            if (Object.keys(mappings[r_id])?.length > 1) {
                mappings[l_id][r_id] = "left";
                updateWeight(r_id, "left");
            }
        }
        selectedItemLeft = null;
        selectedItemRight = null;
        loadMapping();
    }

    const linkHandler = (item, isLeftList) => {
        if (isLeftList) {
            selectedItemLeft = item.id;
            if (selectedItemRight) {
                createMapping("left");
            }
        } else {
            selectedItemRight = item.id;
            if (selectedItemLeft) {
                createMapping("right");
            }
        }
    };

    function drawCircle(list, listData, isLeftList) {
        const X = isLeftList ? leftCircleX - 9 : rightCircleX - 10;
        const getY = (_, i) => i * listStyle.itemHeight - 17;
        const getStyle = (d) => {
            let style = "cursor:pointer;";
            if (d.isGroupedRow) {
                style += `display:none;`;
            }
            return style;
        };

        const isItemLinked = (d) => {
            let prefix = idPrefixLeft;
            let pos = "right";
            if (!isLeftList) {
                prefix = idPrefixRight;
                pos = "left";
            }
            const map = mappings[`${prefix}${d.id}`] || {};
            if (isEmpty(map)) {
                return false;
            }
            const keys = Object.keys(map);
            const key = keys?.[0];
            if (keys?.length == 1) {
                const refMap = mappings[key] || {};
                if (Object.keys(refMap)?.length == 1) {
                    return false;
                }
            }
            if (map?.[key]?.[2] == pos) {
                return false;
            }
            return true;
        };

        const getClassName = (d) => {
            if (isItemLinked(d)) {
                return "fa-solid fa-circle filled-circle";
            }
            return "fa-regular fa-circle";
        };

        list.selectAll(".circle-icon")
            .data(listData)
            .enter()
            .append("foreignObject")
            .attr("class", "circle-icon")
            .attr("x", X)
            .attr("y", getY)
            .append("xhtml:i")
            .attr("class", getClassName)
            .attr("style", getStyle)
            .on("click", (e, d) => {
                linkHandler(d, isLeftList);
            });
    }

    function drawList(svg, listData, isLeftList = false) {
        const X = isLeftList ? listStyle.x : listStyle.x + offset;
        const Y = listStyle.y;

        const list = svg.append("g").attr("transform", `translate(${X}, ${Y})`);
        const listItem = list.selectAll(".list-item").data(listData).enter();

        drawCircle(list, listData, isLeftList);

        headers.forEach((header) => {
            if (isLeftList && header?.position == "left") {
                drawColumn(listItem, header?.id, isLeftList);
            } else if (!isLeftList && header?.position == "right") {
                drawColumn(listItem, header?.id, isLeftList);
            }
        });
    }

    const customLink = (d) => {
        const i = list2.findIndex((e) => e.id == d.mapId);
        const leftX = leftCircleX;
        const leftY = d.index * listStyle.itemHeight + 55;
        const rightX = rightCircleX + offset;
        const rightY = i * listStyle.itemHeight + 55;
        const isUpside = d.index > i;
        const midX = (leftX + rightX) / 2;

        const controlPoint1X = midX * 1.2;
        const controlPoint1Y = isUpside ? leftY * 1.1 : leftY * 0.8;

        const controlPoint2X = midX * 0.8;
        const controlPoint2Y = isUpside ? rightY * 0.9 : rightY * 1.1;

        return `M${leftX},${leftY}C${controlPoint1X},${controlPoint1Y} ${controlPoint2X},${controlPoint2Y} ${rightX},${rightY}`;
    };

    const getInputStyle = (d) => {
        const l_id = `${idPrefixLeft}${d?.id}`;
        const r_id = `${idPrefixRight}${d?.mapId}`;
        const lKeys = Object.keys(mappings[l_id] || {});
        const rKeys = Object.keys(mappings[r_id] || {});
        if (lKeys?.length == 1 && rKeys?.length == 1) {
            return "pointer-events: none;";
        }
        return "";
    };

    function drawLinks(svg, links) {
        const gradient = svg
            .append("defs")
            .selectAll("linearGradient")
            .data(links)
            .enter()
            .append("linearGradient")
            .attr("id", "linkGradient")
            .attr("gradientUnits", "userSpaceOnUse")
            .attr("x1", () => 330)
            .attr("y1", (d) => d.index * listStyle.itemHeight + 45)
            .attr("x2", () => 548)
            .attr("y2", (d) => {
                const i = list2.findIndex((e) => e.id == d.mapId);
                return i * listStyle.itemHeight + 46;
            });

        gradient.append("stop").attr("offset", "0%").attr("stop-color", "#FD0F53");

        gradient.append("stop").attr("offset", "60%").attr("stop-color", "#FD0F53");

        gradient.append("stop").attr("offset", "100%").attr("stop-color", "#355DD1");

        // plot links
        svg.selectAll("path")
            .data(links)
            .join("path")
            .attr("d", customLink)
            .classed("link", true)
            .attr("fill", "none")
            .attr("stroke", "url(#linkGradient)")
            .attr("stroke-width", (d) => {
                const w = getLinkWeight(d["weight"]) || 100;
                const strokeWidth = (Number(w) * 3) / 100;
                if (strokeWidth < minLinkStrokeWidth) {
                    return minLinkStrokeWidth;
                } else if (strokeWidth > maxLinkStrokeWidth) {
                    return maxLinkStrokeWidth;
                }
                return strokeWidth;
            });

        // plot input
        const selector = svg
            .selectAll(".input-panel")
            .data(links)
            .enter()
            .append("foreignObject")
            .attr("class", (d) => {
                let clsName = "input-panel";
                if (d?.wgt_modified) {
                    clsName += " modified-wgt";
                }
                return clsName;
            })
            .attr("x", (d) => {
                if (d.position == "left") {
                    return leftCircleX + 20;
                }
                return offset + rightCircleX * 0.32;
            })
            .attr("y", (d) => {
                if (d.position == "left") {
                    return d.index * listStyle.itemHeight + 42;
                }
                const i = list2.findIndex((e) => e.id == d.mapId);
                return (i + 1) * listStyle.itemHeight + 10;
            });

        selector
            .append("xhtml:input")
            .attr("type", "text")
            .attr("class", "link-input")
            .attr("value", (d) => getLinkWeight(d["weight"]))
            .on("change", (e, d) => onWeightChange(e, d))
            .attr("style", getInputStyle);

        const span = selector.append("xhtml:span").attr("class", "input-sfx");
        span.text("%");

        const getClassName = (d) => {
            let clsName = "fa-solid fa-circle-xmark input-icon";
            if (d?.wgt_modified) {
                clsName += " reset-remove-icon";
                return clsName;
            }
            clsName += " remove-icon";
            return clsName;
        };

        const onClick = (d) => (d?.wgt_modified ? onResetWeight(d) : removeMapping(d));
        span.append("xhtml:i")
            .attr("class", getClassName)
            .on("click", (_, d) => onClick(d));
        // .attr("class", "fa-solid fa-arrow-rotate-left")
    }

    function updateWeight(id, pos) {
        let weight: any = 0;
        const map = mappings[id];
        const unchangedLinks = Object.keys(map)?.filter((k) => !map?.[k][1]);
        const modifiedLinks = Object.keys(map)?.filter((k) => map?.[k][1]);
        const usedWeight = modifiedLinks.reduce((t, c) => {
            const val = map[c][0] || 0;
            return t + Number(val);
        }, 0);

        const remainingWgt = 100 - usedWeight;
        if (remainingWgt <= 0) {
            weight = 0;
        } else {
            const remaining = unchangedLinks.length;
            weight = (remainingWgt / remaining).toFixed(1);
        }

        // update weight
        unchangedLinks?.map((k) => {
            mappings[id][k][0] = weight;
            mappings[id][k][2] = pos;
            mappings[k][id] = mappings[id][k]; // update weight in link ref
        });
    }

    function loadMapping() {
        links = [];
        Object.keys(mappings).forEach((key) => {
            if (key.startsWith(idPrefixLeft)) {
                const id = key.slice(idPrefixLeft.length);
                const linkGrp = mappings[key];
                Object.keys(linkGrp).map((k) => {
                    const mapId = k.slice(idPrefixRight.length);
                    const index = list1.findIndex((item) => item.id == id);
                    links.push({
                        id,
                        mapId,
                        index,
                        weight: linkGrp[k][0],
                        wgt_modified: linkGrp[k][1],
                        position: linkGrp[k][2],
                    });
                });
            }
        });
        isValidTotalWeight = true;
        const mappingKeys = Object.keys(mappings || {});
        if (mappingKeys?.length > 0) {
            isValidTotalWeight = mappingKeys?.every((key) => {
                const map = mappings[key] || {};
                const links = Object.keys(map);
                if (links?.length > 1) {
                    const sum = links.reduce((t, c) => {
                        const val = map[c][0] || 0;
                        return t + Number(val);
                    }, 0);
                    const totalWeight = Number(sum?.toFixed(0));
                    if (totalWeight != 100) {
                        return false;
                    }
                } else if (links?.length == 1) {
                    const refLink = mappings?.[links?.[0]] || {};
                    const refLinkKeys = Object.keys(refLink);
                    if (refLinkKeys?.length == 1) {
                        //1-2-1 mapping
                        const totalWeight = Number(refLink?.[key]?.[0])?.toFixed(0);
                        if (Number(totalWeight) != 100) {
                            return false;
                        }
                    }
                }
                return true;
            });
        }
        refreshSvg();
    }

    const onWeightChange = (event, d) => {
        let val = event.target.value;
        if (isNaN(parseFloat(val))) {
            val = 0; // handle invalid input
        }
        const weight: any = Number(val);
        const l_id = `${idPrefixLeft}${d?.id}`;
        const r_id = `${idPrefixRight}${d?.mapId}`;

        mappings[l_id][r_id][0] = weight;
        mappings[l_id][r_id][1] = true;

        mappings[r_id][l_id][0] = weight;
        mappings[r_id][l_id][1] = true;

        if (d?.position == "right") {
            updateWeight(l_id, d?.position);
        } else {
            updateWeight(r_id, d?.position);
        }
        loadMapping();
    };

    function refreshSvg() {
        const svg = d3.select("#mapping-container");
        svg.html("");
        header(svg);
        drawList(svg, list1, true);
        drawList(svg, list2);
        drawLinks(svg, links);
    }

    function onClearMapping() {
        setMappings({});
        selectedItemLeft = null;
        selectedItemRight = null;
        loadMapping();
    }

    function getCurrentState() {
        return { links, list1, mappings };
    }

    function calculateSvgHeight() {
        const totalItems = Math.max(list1?.length || 0, list2?.length || 0);
        if (totalItems > 0) {
            svgHeight = totalItems * listStyle?.itemHeight + 40;
        }
        if (totalItems == 0 || svgHeight < defaultSvgHeight) {
            svgHeight = defaultSvgHeight;
        }
    }

    function getSvgHeight() {
        return svgHeight;
    }

    function setList1(arr: any = []) {
        list1 = JSON.parse(JSON.stringify(arr));
        setMappings({});
        calculateSvgHeight();
    }

    function setList2(arr = [], updateList = true) {
        list2 = JSON.parse(JSON.stringify(arr));
        if (updateList) {
            setMappings({});
        }
        calculateSvgHeight();
    }

    function setMappings(map: any = []) {
        const newMappings = JSON.parse(JSON.stringify(map));
        mappings = newMappings;
    }

    function getIsValidTotalWeight() {
        return isValidTotalWeight;
    }

    if (!instances[id]) {
        instances[id] = {
            setHeaders,
            loadMapping,
            onClearMapping,
            getCurrentState,
            setList1,
            setList2,
            setMappings,
            getIsValidTotalWeight,
            getSvgHeight,
        };
    }

    return instances[id];
}
