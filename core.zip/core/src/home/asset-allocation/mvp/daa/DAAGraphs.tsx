/* eslint-disable */
import React, { useState, useEffect } from "react";
import Decimal from "decimal.js";
import { groupBy, roundNumber } from "utils/helpers";
import AutocompleteField from "common/AutocompleteField";
import SearchInput from "common/SearchInput";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-enterprise";
import Access from "utils/access";
import { sortList } from "../utils/aa-helper";
import { AdornedButton, FTIconButton } from "common/FTButtons";
import CopyAllIcon from "@mui/icons-material/CopyAll";
import ModeEditIcon from "@mui/icons-material/ModeEdit";
import LockIcon from "@mui/icons-material/Lock";
import LockOpenIcon from "@mui/icons-material/LockOpen";
import ShareIcon from "@mui/icons-material/Share";
import DriveFileRenameOutlineIcon from "@mui/icons-material/DriveFileRenameOutline";
import { Dialog, Typography } from "@mui/material";
import Api from "utils/api";
import errorNotification from "utils/api-error";
import ParentChildMapping from "./ParentChildMapping";
import { daaGraphCols1, daaGraphCols2, tb3_rows, isrcMappingCfg, isrcBmMappingCfg } from "../utils/aa-cfg";
import { RenderOption } from "../saa/SAAInput";
import ConfirmDialog from "common/ConfirmDialog";
import { squareBtnStyle } from "./daa-helper";
import Mapping from "./Mapping";
import EfficientFrontier from "./EfficientFrontier";
import AssetAllocationWeights from "./AssetAllocationWeights";
import EditModal from "../shared/EditNameDialog";
import ShareWith from "../../../../common/ShareWith";
import { globalSearch } from "utils/helpers";
import { hasAccess, removeKeys, percentPostfix } from "../utils/aa-helper";

export const styles = {
    height: "30px",
    border: " 1px solid rgb(217 207 207)",
    borderRadius: "5px",
    padding: "2px 4px",
    marginBottom: "5px",
    fontSize: 13,
};

const isDisabled = (value, isCopyBtn) => {
    if (!value) {
        return true;
    }
    if (isCopyBtn) {
        return false;
    }
    if (value?.["author-id"] && hasAccess(value)) {
        return false;
    }
    return true;
};

const getIconStyle = (valueObj, isCopyBtn) => {
    const disabledBtnStyle = { ...squareBtnStyle, opacity: 0.4 };
    return isDisabled(valueObj, isCopyBtn) ? disabledBtnStyle : squareBtnStyle;
};
const toAssetStr = (assetObj) =>
    [assetObj?.class || "", assetObj?.category || "", assetObj?.sub_category || "", assetObj?.asset || ""].toString();

function getAllAssets(selectedParentChildMapping, appSettings, saaSolution, benchmarkInfo) {
    const assetHash = {};
    selectedParentChildMapping?.portfolios?.map((portfolio) => {
        if (portfolio.isParent) {
            appSettings.portfolioMap[portfolio?.portfolios]?.assets?.forEach((asset) => {
                const assetStr = toAssetStr(asset);
                if (!Object.hasOwn(assetHash, assetStr)) {
                    assetHash[assetStr] = {
                        assetClass: asset?.class,
                        daaCurrent: asset?.percentage * 100,
                        daaTarget: asset?.percentage * 100,
                    };
                }
            });
        }
    });
    selectedParentChildMapping?.portfolios?.map((portfolio) => {
        if (!portfolio.isParent) {
            appSettings.portfolioMap[portfolio?.portfolios]?.assets?.forEach((asset) => {
                const assetStr = toAssetStr(asset);
                if (!Object.hasOwn(assetHash, assetStr)) {
                    assetHash[assetStr] = {
                        assetClass: asset?.class,
                        daaCurrent: 0,
                        daaTarget: 0,
                    };
                }
            });
        }
    });
    saaSolution.forEach((asset) => {
        const assetStr = asset.asset.toString();
        if (!Object.hasOwn(assetHash, assetStr)) {
            assetHash[assetStr] = {
                assetClass: asset.asset[0],
                daaCurrent: 0,
                daaTarget: 0,
            };
        }
    });
    Object.values(benchmarkInfo).forEach((p_bm: any) => {
        p_bm?.assets?.forEach((asset) => {
            const assetStr = [asset?.asset_type, asset?.category, asset?.sub_category, asset?.asset].toString();
            if (!Object.hasOwn(assetHash, assetStr)) {
                assetHash[assetStr] = {
                    assetClass: asset?.asset_type,
                    daaCurrent: 0,
                    daaTarget: 0,
                };
            }
        });
    });
    return assetHash;
}

function getTypeSum(data, colName) {
    return data.reduce((da, dc) => da + (Number(dc[colName]) || 0), 0);
}

function getTiltByPortfolio(assetHash, daaTargetClassSum, portfolio) {
    const rawTilt = {};
    const benchmarkTilt = {};
    const custom = {};
    const bmClassSum = {};
    const rawTiltSum = {};
    Object.values(assetHash).map((value: any) => {
        if (!Object.hasOwn(bmClassSum, value.assetClass)) {
            bmClassSum[value.assetClass] = 0;
        }
        if (!Object.hasOwn(rawTiltSum, value.assetClass)) {
            rawTiltSum[value.assetClass] = 0;
        }
        bmClassSum[value.assetClass] += Number(value?.saaBenchmark?.[portfolio] || 0);
        rawTiltSum[value.assetClass] +=
            (Number(value?.[portfolio]) || 0) - (Number(value?.saaBenchmark?.[portfolio]) || 0) || 0;
    });

    Object.keys(assetHash)?.map((assetStr, idx) => {
        const assetArr = assetStr.split(",");
        const bmProspectus = Number(assetHash[assetStr]?.saaBenchmark?.[portfolio]) || 0;
        const portfolioVal = assetHash[assetStr]?.[portfolio] || 0;
        rawTilt[idx] = portfolioVal - bmProspectus;
        benchmarkTilt[idx] = bmClassSum[assetArr[0]]
            ? new Decimal(bmProspectus).dividedBy(new Decimal(bmClassSum[assetArr[0]])).times(100).toNumber()
            : 0;
        const portfolioPercentage = daaTargetClassSum[assetArr[0]]
            ? new Decimal(portfolioVal).dividedBy(new Decimal(daaTargetClassSum[assetArr[0]])).times(100)
            : 0;
        custom[idx] = new Decimal(portfolioPercentage).minus(new Decimal(benchmarkTilt[idx])).toNumber();
    });
    return { rawTilt, benchmarkTilt, custom, bmClassSum, daaTargetClassSum, rawTiltSum };
}

function getInitialTableData(assetHash, selectedParentChildMapping, isrc, isrcBenchmark) {
    const formattedData: any = [];
    const policyRawTilt = {};
    const policyBenchmarkTilt = {};
    const policyTilt = {};
    const daaTargetClassSum = {};
    const bmClassSum = {};
    const isrcBmClassSum = {};
    const policyRawTiltSum = {};
    const isrcClassSum = {};
    const parentPortfolio = selectedParentChildMapping.portfolios.find((portfolio) => portfolio.isParent)?.portfolios;
    Object.entries(assetHash).map(([key, value]: any) => {
        if (!Object.hasOwn(daaTargetClassSum, value.assetClass)) {
            daaTargetClassSum[value.assetClass] = 0;
        }
        if (!Object.hasOwn(bmClassSum, value.assetClass)) {
            bmClassSum[value.assetClass] = 0;
        }
        if (!Object.hasOwn(isrcClassSum, value.assetClass)) {
            isrcClassSum[value.assetClass] = 0;
        }
        daaTargetClassSum[value.assetClass] += typeof value.daaTarget === "number" ? value.daaTarget : 0;
        bmClassSum[value.assetClass] += Number(value?.saaBenchmark?.[parentPortfolio]) || 0;
        isrcClassSum[value.assetClass] += Number(isrc[key.toLowerCase()]) || 0;
        if (!Object.hasOwn(isrcBmClassSum, value.assetClass)) {
            isrcBmClassSum[value.assetClass] = 0;
        }
        if (!Object.hasOwn(policyRawTiltSum, value.assetClass)) {
            policyRawTiltSum[value.assetClass] = 0;
        }
        isrcBmClassSum[value.assetClass] += Number(isrcBenchmark[key.toLowerCase()]) || 0;
        policyRawTiltSum[value.assetClass] +=
            (Number(isrc[key.toLowerCase()]) || 0) - (Number(isrcBenchmark[key.toLowerCase()]) || 0) || 0;
    });

    Object.keys(assetHash)?.map((assetStr, idx) => {
        const assetArr = assetStr.split(",");
        const bmProspectus = Number(assetHash[assetStr]?.saaBenchmark?.[parentPortfolio]) || 0;
        const bmPercent = (bmProspectus / bmClassSum[assetArr[0]]) * 100;
        const saaSolution = assetHash[assetStr]?.saaSolution || 0;
        const daaCurrent = assetHash[assetStr]?.daaCurrent || 0;
        const daaTarget = assetHash[assetStr]?.daaTarget || 0;
        const absoluteDiff = assetHash[assetStr]?.daaTarget - bmProspectus;
        const isrcVal = isrc[assetStr.toLowerCase()];
        const isrcBenchmarkVal = isrcBenchmark[assetStr.toLowerCase()];
        policyRawTilt[idx] = (isrcVal || 0) - (isrcBenchmarkVal || 0);
        policyBenchmarkTilt[idx] = new Decimal(isrcBenchmarkVal || 0)
            .dividedBy(isrcBmClassSum[assetArr[0]])
            .times(100)
            .toNumber();
        policyTilt[idx] = new Decimal(isrcVal || 0)
            .dividedBy(new Decimal(isrcClassSum[assetArr[0]]))
            .times(100)
            .minus(new Decimal(policyBenchmarkTilt[idx]))
            .toNumber();

        const clsLevelSumOfDiff = daaTargetClassSum[assetArr[0]] - bmClassSum[assetArr[0]];
        const row = {
            id: idx,
            asset_class: assetArr[0] || "",
            category: assetArr[1] || "",
            sub_category: assetArr[2] || "",
            asset_name: assetArr[3] || "",
            bmProspectus,
            bmPercent,
            isrc: isrcVal,
            isrcBenchmark: isrcBenchmarkVal,
            saaSolution,
            daaCurrent,
            daaTarget,
            daaPercent: (daaTarget / daaTargetClassSum[assetArr[0]]) * 100,
            absoluteDiff,
            diffPercent:
                Math.round(clsLevelSumOfDiff * 100) / 100 === 0 ? "" : (absoluteDiff / clsLevelSumOfDiff) * 100,
        };
        selectedParentChildMapping?.portfolios?.map((portfolio) => {
            if (portfolio.isParent) {
                row[portfolio?.portfolios] = daaTarget;
            }
            row[portfolio?.portfolios] = assetHash?.[assetStr][portfolio?.portfolios] || "";
        });
        formattedData.push(row);
    });
    const customTilts = getTiltByPortfolio(assetHash, daaTargetClassSum, parentPortfolio);
    return {
        formattedData,
        ...customTilts,
        policyRawTilt,
        policyBenchmarkTilt,
        policyRawTiltSum,
        isrcBmClassSum,
        policyTilt,
    };
}

function groupRows(rows, groupedRows, selectedParentChildMapping, grpBy = "asset_class") {
    if (!rows?.length) {
        return [];
    }
    const groupData = groupBy(rows, grpBy);
    let results: any = [];
    const totalValues = {
        isrc: 0,
        isrcBenchmark: 0,
        saaSolution: 0,
        daaCurrent: 0,
        daaTarget: 0,
        bmProspectus: 0,
    };
    const parentPortfolio = selectedParentChildMapping.portfolios.find((portfolio) => portfolio.isParent);

    Object.keys(groupData).forEach((type) => {
        if (groupData[type]) {
            const bmProspectus = getTypeSum(groupData[type], "bmProspectus");
            const isrc = getTypeSum(groupData[type], "isrc");
            const isrcBenchmark = getTypeSum(groupData[type], "isrcBenchmark");
            const saaSolution = getTypeSum(groupData[type], "saaSolution");
            const daaCurrent = getTypeSum(groupData[type], "daaCurrent");
            const daaTarget = getTypeSum(groupData[type], "daaTarget");
            const targetPortfoios = {};
            selectedParentChildMapping?.portfolios.map((portfolio) => {
                targetPortfoios[portfolio.portfolios] = getTypeSum(groupData[type], portfolio.portfolios);
            });
            totalValues.bmProspectus += bmProspectus;
            totalValues.isrc += isrc;
            totalValues.isrcBenchmark += isrcBenchmark;
            totalValues.saaSolution += saaSolution;
            totalValues.daaCurrent += daaCurrent;
            totalValues.daaTarget += daaTarget;
            selectedParentChildMapping?.portfolios.map((portfolio) => {
                if (!Object.hasOwn(totalValues, portfolio.portfolios)) {
                    totalValues[portfolio.portfolios] = 0;
                }
                totalValues[portfolio.portfolios] += targetPortfoios[portfolio.portfolios];
            });
        }
    });
    Object.keys(groupData).forEach((type) => {
        if (groupData[type]) {
            const value = groupData[type].map((row) => {
                const prevRow = groupedRows.find((r) => r.id === row.id);
                if (prevRow && prevRow?.lockedAssets) {
                    return { ...row, lockedAssets: prevRow?.lockedAssets };
                }
                return { ...row, isOnlyAssetInClass: groupData[type].length === 1 ? true : false };
            });
            const bmProspectus = getTypeSum(groupData[type], "bmProspectus");
            const isrc = getTypeSum(groupData[type], "isrc");
            const isrcBenchmark = getTypeSum(groupData[type], "isrcBenchmark");
            const saaSolution = getTypeSum(groupData[type], "saaSolution");
            const daaCurrent = getTypeSum(groupData[type], "daaCurrent");
            const daaTarget = getTypeSum(groupData[type], "daaTarget");
            const absoluteDiff = daaTarget - bmProspectus;
            const targetPortfoios = {};
            selectedParentChildMapping?.portfolios.map((portfolio) => {
                targetPortfoios[portfolio.portfolios] = getTypeSum(groupData[type], portfolio.portfolios);
            });
            const aggFields: any = {
                bmProspectus,
                bmPercent: (bmProspectus / totalValues.bmProspectus) * 100,
                isrc,
                isrcBenchmark,
                saaSolution,
                daaCurrent,
                daaTarget,
                daaPercent: (daaTarget / totalValues.daaTarget) * 100,
                absoluteDiff,
                limitMin: Number(parentPortfolio[type]?.min) || 0,
                limitMax: Number(parentPortfolio[type]?.max) || 100,
                ...targetPortfoios,
            };
            let className = "";
            if (type === "Equity") {
                className = "saa-texthead-blue";
            }
            if (type === "Fixed Income") {
                className = "saa-texthead-red";
            }
            if (type === "Alternatives") {
                className = "saa-texthead-purple";
            }
            if (type === "Cash") {
                className = "saa-texthead-green";
            }
            results = [
                ...results,
                {
                    asset_name: type,
                    ...Object.fromEntries(
                        Object.entries(aggFields).map(([key, val]) => [
                            key,
                            typeof val === "number" ? roundNumber(val) : val,
                        ])
                    ),
                    className: "table-text-grey" + " " + className,
                    isGroupedRow: true,
                },
                {
                    asset_name: "Contribution to TE",
                    className: "table-text-grey",
                    isGroupedRow: true,
                    contribution_type: type,
                },
                ...value.map((asset) =>
                    Object.fromEntries(
                        Object.entries(asset).map(([key, val]) => [
                            key,
                            typeof val === "number" ? roundNumber(val) : val,
                        ])
                    )
                ),
            ];
        }
    });
    results.push({
        ...Object.fromEntries(
            Object.entries(totalValues).map(([key, val]) => [key, typeof val === "number" ? roundNumber(val) : val])
        ),
        className: "table-text-grey",
        isGroupedRow: true,
    });
    results.forEach((row, idx) => (row.key = idx));
    return results;
}

function updateTheRestByRatio(obj, changingKey, newVal) {
    const changedVal = Number(newVal);
    const diff = new Decimal(changedVal).minus(new Decimal(obj[changingKey] || 0));
    const updatedObj = { ...obj };
    if (diff.equals(0)) {
        return updatedObj;
    }
    let sumOfRest = new Decimal(0);
    for (let key in obj) {
        if (key === changingKey.toString()) {
            continue;
        }
        sumOfRest = new Decimal(sumOfRest).plus(new Decimal(Math.abs(obj[key]) || 0));
    }

    for (let key in obj) {
        if (key === changingKey.toString()) {
            updatedObj[key] = newVal;
        } else {
            const origVal = new Decimal(obj[key] || 0);
            const signal = Number(obj[key]) >= 0 ? 1 : -1;
            updatedObj[key] = sumOfRest.toNumber()
                ? origVal.minus(diff.times(origVal).dividedBy(sumOfRest.times(signal))).toNumber()
                : origVal
                      .minus(diff)
                      .dividedBy(Object.keys(obj).length - 1)
                      .toNumber();
        }
    }
    return updatedObj;
}

export default function DAAGraphs({
    app,
    type,
    appSettings,
    saaSharedObjList,
    portfolioList,
    setUploadPopup,
    daaPfs,
    refreshDaaData,
    daaSharedObjList,
    assetGroups,
}) {
    const userInfo = Access.userInfo || {};
    const [selectedTemplate, setSelectedTemplate] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [groupedRows, setGroupedRows] = useState<any>([]);
    const [initialDataPart2, setInitialDataPart2] = useState({});
    const [dataPart2, setDataPart2] = useState({});
    const [openExpDialog, setOpenExpDialog] = useState(false);
    const [parentChildMapping, setParentChildMapping] = useState<any>({ openEditDialog: false });
    const [isrcMapping, setIsrcMapping] = useState<any>({ open: false, calculatedInitial: false });
    const [isrcBmMapping, setIsrcBmMapping] = useState<any>({ open: false });
    const [editInfo, setEditInfo] = useState<any>({ open: false, field: "", value: "" });
    const [deletePopup, setDeletePopup] = useState<any>({ open: false, deleteObj: null, deleted: false });
    const [shareInfo, setShareInfo] = useState<any>({ open: false, shareBtnRef: null, data: null });
    const [tilt, setTilt] = useState<any>({ selection: "custom", policy: {}, custom: {} });
    const [assetHash, setAssetHash] = useState({});
    const sortedPortfolios: any = [];
    if (parentChildMapping?.selectedMapping?._meta) {
        const parentPortfolio = parentChildMapping?.selectedMapping?._meta?.portfolios.find((portfolio) =>
            Boolean(portfolio.isParent)
        );
        sortedPortfolios.push(parentPortfolio);
        sortedPortfolios.push(
            ...parentChildMapping?.selectedMapping?._meta?.portfolios.filter((portfolio) => !portfolio.isParent)
        );
    }

    useEffect(() => {
        let formattedData;
        formatDataForTable(
            appSettings,
            parentChildMapping?.selectedMapping?._meta,
            isrcMapping?.selectedMapping?._meta,
            isrcBmMapping?.selectedMapping?._meta
        ).then((res) => {
            formattedData = res;
            setTableData(() => formattedData);
            const grouped = groupRows(formattedData, groupedRows, parentChildMapping?.selectedMapping?._meta);
            setGroupedRows(() => grouped);
            let needCalCols = [
                "bmProspectus",
                "saaSolution",
                "daaCurrent",
                "daaTarget",
                "isrcBenchmark",
                "isrc",
            ].concat(parentChildMapping?.selectedMapping?._meta?.portfolios.map((p) => p.portfolios));
            getDataPart2(formattedData, needCalCols, grouped);
        });
    }, [
        appSettings,
        parentChildMapping?.selectedMapping,
        isrcMapping?.selectedMapping,
        isrcBmMapping?.selectedMapping,
        selectedTemplate,
    ]);

    function getISRCMappedValues(origISRC, mapping, assetHash) {
        if (!mapping) {
            return [{}, assetHash];
        }
        const mappedValues = {};
        const newAssetHash = { ...assetHash };
        const parsedMapping = typeof mapping?.mappings === "string" ? JSON.parse(mapping.mappings) : mapping.mappings;
        for (const key in parsedMapping) {
            if (!key.startsWith("left_")) {
                continue;
            }
            const isrcAsset = origISRC.assets.find((asset) => "left_" + asset.id === key);
            const rightAssets = parsedMapping[key];
            for (const rightAssetStr in rightAssets) {
                if (!rightAssetStr.startsWith("right_")) {
                    continue;
                }
                const rightAssetArr = rightAssetStr.substring(6).split("||");
                if (!Object.hasOwn(assetHash, rightAssetArr.toString())) {
                    assetHash[rightAssetArr.toString()] = {
                        assetClass: isrcAsset?.class || "",
                        daaCurrent: 0,
                        daaTarget: 0,
                    };
                }
                if (!Object.hasOwn(mappedValues, rightAssetArr.toString())) {
                    mappedValues[rightAssetArr.toString()] = 0;
                }
                const mappedPercentage =
                    rightAssets[rightAssetStr][2] === "left"
                        ? new Decimal(100)
                        : new Decimal(rightAssets[rightAssetStr][0]);
                mappedValues[rightAssetArr.toString()] += Number(mappedPercentage.mul(isrcAsset?.percentage)) || 0;
            }
        }

        const totalNumber = Object.values(mappedValues).reduce((da: number, dc: any) => da + (dc || 0), 0);
        for (const val in mappedValues) {
            mappedValues[val] = Number(new Decimal(mappedValues[val]).mul(100).dividedBy(totalNumber));
        }
        return [mappedValues, newAssetHash];
    }

    async function handleSaveTemplate() {
        const targetPortfoios = {};
        const portfoliosArr = parentChildMapping.selectedMapping?._meta?.portfolios;
        portfoliosArr?.map((p) => {
            targetPortfoios[p.portfolios] = [];
        });
        tableData.forEach((row) => {
            portfoliosArr?.forEach((p) => {
                if (row[p.portfolios]) {
                    targetPortfoios[p.portfolios].push([
                        row.asset_class,
                        row.category,
                        row.sub_category,
                        row.asset_name,
                        Number(row[p.portfolios]) / 100,
                    ]);
                }
            });
        });
        portfoliosArr?.map(async (p) => {
            const formattedObj = {
                _id: "daa_" + p?.portfolios?.toLowerCase(),
                asset_header: ["class", "category", "sub_category", "asset", "percentage"],
                assets: targetPortfoios[p?.portfolios],
                date: new Date().toISOString().substr(0, 7),
            };
            await Api.updateDocument(
                "daa2",
                "daa_" + p?.portfolios?.toLowerCase(),
                { document: JSON.stringify(formattedObj) },
                { comment: "update" }
            );
        });
        const payload = {
            name: selectedTemplate?.label + "_daa_template",
            Name: selectedTemplate?.label,
            type: "daa_template",
            parentChildMapping: parentChildMapping.selectedMapping.id,
            isrcMapping: isrcMapping.selectedMapping.id,
            isrcBmMapping: isrcBmMapping.selectedMapping.id,
        };
        let response;
        if (!selectedTemplate?.id) {
            response = await Api.createSharedState(app, type, payload);
        } else {
            response = await Api.updateSharedState(selectedTemplate.id, payload);
        }
        if (response.status === "ok") {
            if (response?.message) {
                errorNotification.next({ type: "success", text: response.message, open: true });
                refreshDaaData();
            }
        }
    }

    async function formatDataForTable(
        appSettings,
        selectedParentChildMapping,
        selectedISRCMapping,
        selectedISRCbmMapping
    ) {
        if (!appSettings || !selectedParentChildMapping) {
            setTilt({ selection: "custom", custom: {} });
            setDataPart2({});
            return [];
        }
        let assetHash = {};
        let benchmarkInfo = {};
        const parentPortfolio = selectedParentChildMapping?.portfolios.find((portfolio) => Boolean(portfolio.isParent));
        const parentSAAId = parentPortfolio?.saa;
        const parentPortfolioSAA = saaSharedObjList?.templateList?.find(
            (template) => template?._id?.$oid === parentSAAId
        )?._meta;
        if (!parentPortfolioSAA?.prev_final_objective?.solution) {
            errorNotification.next({ type: "error", text: "No SAA Ouput for Parent Portfolio", open: true });
        }
        selectedParentChildMapping?.portfolios?.map((p) => {
            benchmarkInfo[p.portfolios] = saaSharedObjList?.benchmarkList
                .concat(daaSharedObjList?.benchmarkMapping)
                ?.find((benchmark) => benchmark?.id === p?.benchmark)?._meta;
        });
        assetHash = getAllAssets(
            selectedParentChildMapping,
            appSettings,
            parentPortfolioSAA?.prev_final_objective?.solution,
            benchmarkInfo
        );
        parentPortfolioSAA?.prev_final_objective?.solution?.map((asset) => {
            const assetStr = asset?.asset?.toString();
            assetHash[assetStr].saaSolution = asset?.holding;
        });
        Object.keys(assetHash).forEach((assetStr) => {
            assetHash[assetStr].saaBenchmark = {};
            selectedParentChildMapping?.portfolios.forEach((p) => {
                assetHash[assetStr].saaBenchmark[p.portfolios] =
                    benchmarkInfo[p.portfolios]?.assets?.find(
                        (a) => [a.asset_type, a.category, a.sub_category, a.asset].toString() === assetStr
                    )?.weight || 0;
            });
        });
        Object.values(selectedParentChildMapping.portfolios).map((portfolio: any) => {
            appSettings.portfolioMap[portfolio?.portfolios]?.assets?.forEach((asset) => {
                const assetStr = toAssetStr(asset);
                if (Object.hasOwn(assetHash, assetStr)) {
                    assetHash[assetStr][portfolio?.portfolios] = asset?.percentage ? asset?.percentage * 100 : "";
                }
            });
        });
        const [isrc, newAssetHash] = getISRCMappedValues(appSettings.isrc, selectedISRCMapping, assetHash);
        const [isrcBenchmark, updatedAssetHash] = getISRCMappedValues(
            appSettings.isrcBenchmark,
            selectedISRCbmMapping,
            newAssetHash
        );
        assetHash = updatedAssetHash;
        const sortedAssetHash = {};
        Object.keys(assetHash)
            .sort()
            .forEach(function (v, i) {
                sortedAssetHash[v] = assetHash[v];
            });
        setAssetHash(sortedAssetHash);
        const {
            formattedData,
            rawTilt,
            rawTiltSum,
            bmClassSum,
            benchmarkTilt,
            daaTargetClassSum,
            custom,
            policyRawTilt,
            policyBenchmarkTilt,
            policyRawTiltSum,
            isrcBmClassSum,
            policyTilt,
        } = getInitialTableData(sortedAssetHash, selectedParentChildMapping, isrc, isrcBenchmark);
        setTilt((tilt) => ({
            ...tilt,
            rawTilt,
            rawTiltSum,
            bmClassSum,
            benchmarkTilt,
            daaTargetClassSum,
            custom,
            policyRawTilt,
            policyBenchmarkTilt,
            policyRawTiltSum,
            isrcBmClassSum,
            policy: policyTilt,
        }));
        return formattedData;
    }

    function updateContributionToTE(dataPart2, grouped) {
        let updatedGroupedRows = [...grouped];
        Object.entries(dataPart2).forEach(([colName, colObj]: any) => {
            const contributionToTE = colObj?.contribution_to_te;
            updatedGroupedRows = updatedGroupedRows.map((row) => {
                if (row.asset_name === "Contribution to TE") {
                    row[colName] = roundNumber(contributionToTE?.[row.contribution_type]);
                }
                return row;
            });
        });
        setGroupedRows(updatedGroupedRows);
    }

    async function getDataPart2(formattedData, needCalCols, grouped) {
        const payloads = {};
        const benchmark: any = {};
        const parentPortfolio = parentChildMapping?.selectedMapping?._meta?.portfolios?.find((p) => p.isParent);
        const parentPortfolioBenchmark = parentPortfolio?.benchmark;
        for (let colName of needCalCols) {
            if (colName === "saaSolution") {
                benchmark[colName] = parentPortfolio?.benchmark;
            } else if (colName === "isrc") {
                const benchmarkSolution: any = [];
                for (let row of formattedData) {
                    if (!row.isrcBenchmark) {
                        continue;
                    }
                    benchmarkSolution.push({
                        asset: [
                            row?.asset_class || "",
                            row?.category || "",
                            row?.sub_category || "",
                            row?.asset_name || "",
                        ],
                        holding: row?.isrcBenchmark || 0,
                    });
                }
                benchmark[colName] = benchmarkSolution;
            } else if (colName === "daaCurrent" || colName === "daaTarget") {
                benchmark[colName] = parentPortfolioBenchmark;
            } else if (colName === "bmProspectus" || colName === "isrcBenchmark") {
                benchmark[colName] = "";
            } else {
                benchmark[colName] = parentChildMapping?.selectedMapping?._meta?.portfolios?.find(
                    (p) => p.portfolios === colName
                )?.benchmark;
            }
        }
        formattedData.forEach((row) => {
            const asset = [row?.asset_class, row?.category, row?.sub_category, row?.asset_name];
            for (let colName of needCalCols) {
                if (!row[colName]) {
                    continue;
                }
                if (!Object.hasOwn(payloads, colName)) {
                    if (!benchmark[colName]) {
                        payloads[colName] = {
                            solution: [
                                {
                                    asset,
                                    holding: Number(row[colName]) || 0,
                                },
                            ],
                        };
                    } else if (typeof benchmark[colName] === "object") {
                        payloads[colName] = {
                            solution: [
                                {
                                    asset,
                                    holding: Number(row[colName]) || 0,
                                },
                            ],
                            benchmark_solution: benchmark[colName],
                        };
                    } else {
                        payloads[colName] = {
                            solution: [
                                {
                                    asset,
                                    holding: Number(row[colName]) || 0,
                                },
                            ],
                            benchmark: benchmark[colName],
                        };
                    }
                } else {
                    payloads[colName].solution.push({ asset, holding: Number(row[colName]) });
                }
            }
        });
        const calculated = {};
        Promise.all(
            needCalCols.map(async (colName) => {
                if (payloads[colName] && payloads[colName]?.solution?.length) {
                    return Api.calculateAnalysis(payloads[colName]);
                }
            })
        ).then((resArr) => {
            needCalCols.forEach((colName, idx) => (calculated[colName] = resArr[idx]));
            updateContributionToTE({ ...dataPart2, ...calculated }, grouped);
            setDataPart2((data) => ({ ...data, ...calculated }));
            const newInitialDataPart2 = { ...initialDataPart2 };
            for (let key in calculated) {
                if (calculated[key] && !Object.hasOwn(newInitialDataPart2, key)) {
                    newInitialDataPart2[key] = calculated[key];
                }
            }
            setInitialDataPart2(newInitialDataPart2);
        });
    }

    function updateTilt(tilt) {
        let updatedData = [...tableData];
        const assetCntInSameClass = updatedData.reduce((cnt, cur) => {
            cnt[cur.asset_class] = (cnt[cur.asset_class] || 0) + 1;
            return cnt;
        }, {});
        // update portfolios
        if (tilt.selection === "custom") {
            const childTilt = {};
            const childClassSum = {};
            for (let portfolio of parentChildMapping?.selectedMapping?._meta?.portfolios) {
                if (!portfolio.isParent) {
                    const classSum = {};
                    Object.entries(assetHash).map(([key, value]: any) => {
                        if (!Object.hasOwn(classSum, value.assetClass)) {
                            classSum[value.assetClass] = 0;
                        }
                        classSum[value.assetClass] +=
                            typeof value?.[portfolio.portfolios] === "number" ? value[portfolio.portfolios] : 0;
                    });
                    childTilt[portfolio.portfolios] = getTiltByPortfolio(assetHash, classSum, portfolio.portfolios);
                    childClassSum[portfolio.portfolios] = classSum;
                }
                updatedData.forEach((row, idx) => {
                    const rowInGroup = groupedRows.find((r) => r.id === idx);
                    let updatedVal = Number(rowInGroup[portfolio?.portfolios]);
                    if (
                        row.id === rowInGroup.id ||
                        (row.id !== rowInGroup.id && !rowInGroup?.lockedAssets?.[portfolio?.portfolios])
                    ) {
                        if (!portfolio.isParent) {
                            updatedVal =
                                (childClassSum[portfolio.portfolios][row?.asset_class] *
                                    (Number(tilt.custom[idx]) + childTilt[portfolio.portfolios].benchmarkTilt[idx])) /
                                100;
                        } else {
                            updatedVal =
                                (tilt.daaTargetClassSum[row?.asset_class] *
                                    (Number(tilt.custom[idx]) + tilt.benchmarkTilt[idx])) /
                                100;
                        }
                    }
                    updatedData[idx][portfolio?.portfolios] = updatedVal;
                    if (portfolio.isParent) {
                        updatedData[idx].daaTarget = updatedVal;
                    }
                });
            }
        } else {
            for (let portfolio of parentChildMapping?.selectedMapping?._meta?.portfolios) {
                updatedData.forEach((row, idx) => {
                    const rowInGroup = groupedRows.find((r) => r.id === idx);
                    let updatedVal = Number(rowInGroup[portfolio?.portfolios]);
                    if (
                        row.id === rowInGroup.id ||
                        (row.id !== rowInGroup.id && !rowInGroup?.lockedAssets?.[portfolio?.portfolios])
                    ) {
                        updatedVal = Number(tilt.policyRawTiltSum[row.asset_class])
                            ? (Number(row.isrcBenchmark) || 0) +
                              (Number(tilt.policy?.[idx]) || 0) +
                              ((Number(row.isrcBenchmark) || 0) / Number(tilt.isrcBmClassSum[row.asset_class])) *
                                  Number(tilt.policyRawTiltSum[row.asset_class])
                            : (Number(row.isrcBenchmark) || 0) +
                              (Number(tilt.policy?.[idx]) || 0) +
                              (1 / assetCntInSameClass[row.asset_class]) *
                                  Number(tilt.policyRawTiltSum[row.asset_class]);
                    }
                    updatedData[idx][portfolio?.portfolios] = updatedVal;
                    if (portfolio.isParent) {
                        updatedData[idx].daaTarget = updatedVal;
                    }
                });
            }
        }

        updatedData = updatedData.map((row) => {
            const absoluteDiff = row.daaTarget - row.bmProspectus;
            const clsLevelSumOfDiff = tilt.daaTargetClassSum[row.asset_class] - tilt.bmClassSum[row.asset_class];
            return {
                ...row,
                daaPercent: (row.daaTarget / tilt.daaTargetClassSum[row.asset_class]) * 100,
                absoluteDiff,
                diffPercent:
                    Math.round(clsLevelSumOfDiff * 100) / 100 === 0
                        ? ""
                        : ((row.daaTarget - row.bmProspectus) / clsLevelSumOfDiff) * 100,
            };
        });

        setTableData(() => updatedData);
        const grouped = groupRows(updatedData, groupedRows, parentChildMapping?.selectedMapping?._meta);
        setGroupedRows(() => grouped);
        getDataPart2(
            updatedData,
            ["daaTarget"].concat(parentChildMapping?.selectedMapping?._meta?.portfolios.map((p) => p.portfolios)),
            grouped
        );
    }

    function updateTargetPortfolio(portfolio, updatedPortfolioData) {
        let updatedData = tableData.map((r) => ({
            ...r,
            [portfolio.portfolios]: updatedPortfolioData[r.id],
        }));
        if (portfolio.isParent) {
            const daaTargetClassSum = {};
            updatedData = updatedData.map((r) => ({
                ...r,
                daaTarget: updatedPortfolioData[r.id],
            }));

            const newAssetHash = { ...assetHash };
            Object.keys(assetHash).map((key: any, idx) => {
                if (!Object.hasOwn(daaTargetClassSum, assetHash[key].assetClass)) {
                    daaTargetClassSum[assetHash[key].assetClass] = 0;
                }
                daaTargetClassSum[assetHash[key].assetClass] += Number(updatedPortfolioData[idx] || 0);
                newAssetHash[key].daaTarget = updatedPortfolioData[idx];
                newAssetHash[key][portfolio.portfolios] = updatedPortfolioData[idx];
            });
            setAssetHash(newAssetHash);
            const newTilt = { ...tilt, ...getTiltByPortfolio(newAssetHash, daaTargetClassSum, portfolio.portfolios) };
            setTilt(() => newTilt);
            updateTilt(newTilt);
        } else {
            setTableData(() => updatedData);
            const grouped = groupRows(updatedData, groupedRows, parentChildMapping?.selectedMapping?._meta);
            setGroupedRows(() => grouped);
            getDataPart2(updatedData, [portfolio.portfolios], grouped);
        }
    }

    function markLocked(portfolio, row) {
        setGroupedRows((rows) => {
            const newRows = [...rows];
            if (!newRows[row.key].lockedAssets) {
                newRows[row.key].lockedAssets = {};
            }
            newRows[row.key].lockedAssets[portfolio] = true;
            return newRows;
        });
    }

    function checkDisabledSave() {
        const totalValues = groupedRows[groupedRows.length - 1];
        if (
            !parentChildMapping?.selectedMapping ||
            !selectedTemplate?.label
            // ||!isrcMapping?.selectedMapping?._meta ||
            // !isrcBmMapping?.selectedMapping?._meta
        ) {
            return true;
        }
        for (let portfolio of parentChildMapping?.selectedMapping?._meta?.portfolios) {
            if (!totalValues || !totalValues[portfolio.portfolios] || totalValues[portfolio.portfolios] !== 100) {
                return true;
            }
        }
        return false;
    }

    function refreshData(field, id) {
        refreshDaaData().then((sharedObj) => {
            const { daaTemplates = [], parentChildMapping = [], isrcMapping = [], isrcBmMapping = [] }: any = sharedObj;
            if (field === "daa_template") {
                const template = daaTemplates.find((t) => t.id === id);
                setSelectedTemplate(template);
                selectMapping(setParentChildMapping, "parentChildMapping", template._meta?.parentChildMapping);
                selectMapping(setIsrcMapping, "isrcMapping", template._meta?.isrcMapping);
                selectMapping(setIsrcBmMapping, "isrcBmMapping", template._meta?.isrcBmMapping);
            } else if (field === "daa_portfolios_mapping") {
                const pcMapping = parentChildMapping?.find((m: any) => m?.id === id);
                setParentChildMapping((mapping) => ({
                    ...mapping,
                    selectedMapping: pcMapping || { id: "", label: "" },
                }));
            } else if (field === "isrcMapping") {
                const selectedMapping = isrcMapping?.find((m: any) => m?.id === id);
                setIsrcMapping((mapping) => ({
                    ...mapping,
                    selectedMapping: selectedMapping || { id: "", label: "" },
                }));
            } else if (field === "isrcBenchmarkMapping") {
                const selectedMapping = isrcBmMapping?.find((m: any) => m?.id === id);
                setIsrcBmMapping((mapping) => ({
                    ...mapping,
                    selectedMapping: selectedMapping || { id: "", label: "" },
                }));
            }
        });
    }

    const provider = (options: object[] = [], query) => {
        if (!query) {
            return Promise.resolve([options, options.length]);
        }
        const results = globalSearch(options, query, 0);
        return Promise.resolve([results, results.length]);
    };

    const deleteOption = (deleteObj) => {
        setDeletePopup({ ...deletePopup, open: true, deleteObj });
    };

    async function handleDelete() {
        const res = await Api.deleteSharedState(deletePopup.deleteObj?._meta?._id?.$oid);
        errorNotification.next({ type: "success", text: res.message, open: true });
        refreshData(deletePopup.deleteObj?._meta?.type, deletePopup.deleteObj?._meta?._id?.$oid);
        setDeletePopup((deletePopup) => ({ ...deletePopup, open: false, deleted: true }));
    }

    async function editOnSave(info, value) {
        setEditInfo({ open: false });
        let fieldInfo: any = {};
        let updateStateFunc: any = null;
        if (editInfo?.field == "isrcMapping") {
            fieldInfo = { ...isrcMapping?.selectedMapping?._meta };
            updateStateFunc = setIsrcMapping;
        } else if (editInfo?.field == "parentChildMapping") {
            fieldInfo = { ...parentChildMapping?.selectedMapping?._meta };
            updateStateFunc = setParentChildMapping;
        } else if (editInfo?.field == "isrcBmMapping") {
            fieldInfo = { ...isrcBmMapping?.selectedMapping?._meta };
            updateStateFunc = setIsrcBmMapping;
        } else if (editInfo?.field === "selectedTemplate") {
            fieldInfo = { ...selectedTemplate?._meta };
            updateStateFunc = setSelectedTemplate;
        }
        const request = {
            ...fieldInfo,
            name: value + "-" + fieldInfo?.type,
            Name: value,
        };
        let response: any = {};
        if (info?.action == "copy") {
            const keys: any = ["author", "author-id", "is_editable", "create_date", "update_date", "_id", "name_orig"];
            const payload = removeKeys(request, keys);
            payload["access"] = { system: false, dept: false, users: [] };
            response = await Api.createSharedState(app, type, payload);
        } else if (info?.action === "edit") {
            response = await Api.updateSharedState(request._id?.$oid, request);
        }
        if (response?.message) {
            const mappingObj = response?.["shared-object"];
            let author = "";
            if (mappingObj["author"] && mappingObj["author-id"] != userInfo["uuid"]) {
                author = mappingObj["author"];
            }
            const selectedMapping = {
                key: mappingObj._id?.$oid,
                id: mappingObj._id?.$oid,
                label: mappingObj.Name,
                author,
                _meta: { ...mappingObj },
            };
            if (updateStateFunc) {
                updateStateFunc((mapping) => ({ ...mapping, selectedMapping }));
            }
            if (editInfo?.field === "selectedTemplate") {
                setSelectedTemplate(() => ({ ...selectedMapping }));
            }
            errorNotification.next({ type: "success", text: response.message, open: true });
            refreshData(fieldInfo?.type, mappingObj._id?.$oid);
        }
    }

    function onShare(e, valueObj) {
        if (hasAccess(valueObj?._meta)) {
            setShareInfo({ open: true, shareBtnRef: e.currentTarget, data: valueObj });
        }
    }

    function selectMapping(setFunc, name, mappingId) {
        setFunc((mapping) => ({
            ...mapping,
            selectedMapping: mappingId ? daaSharedObjList?.[name]?.find((m: any) => m?.id === mappingId) : {},
        }));
    }

    const portfolios = parentChildMapping?.selectedMapping?._meta?.portfolios || [];

    return (
        <div className="daa-graph opt-container">
            <Typography variant="h6">DAA</Typography>
            <EditModal editInfo={editInfo} setEditInfo={setEditInfo} editOnSave={editOnSave} />
            <div className="w-content">
                <div className="left-panel">
                    <div className="w-100 d-flex">
                        <div className="temp-input-grp">
                            <div className="input-label">Template Name</div>
                            <div className="input-field">
                                <SearchInput
                                    onChange={(_, v) => {
                                        setSelectedTemplate(v);
                                        selectMapping(
                                            setParentChildMapping,
                                            "parentChildMapping",
                                            v._meta?.parentChildMapping
                                        );
                                        selectMapping(setIsrcMapping, "isrcMapping", v._meta?.isrcMapping);
                                        selectMapping(setIsrcBmMapping, "isrcBmMapping", v._meta?.isrcBmMapping);
                                    }}
                                    onInputChange={(e, v) => {
                                        if (e?.type === "change") {
                                            setSelectedTemplate((template) => ({ ...template, label: v }));
                                        }
                                    }}
                                    options={sortList(daaSharedObjList?.daaTemplates)}
                                    value={{
                                        id: selectedTemplate?.id || "",
                                        label: selectedTemplate?.label || "",
                                    }}
                                    placeholder="Template Name.."
                                    inputPropsStyle={styles}
                                    disableUnderline={true}
                                    forcePopupIcon={true}
                                    popperWidth="300px"
                                    searchIcon={false}
                                    renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                                />
                                <FTIconButton
                                    handler={() =>
                                        setEditInfo({
                                            open: true,
                                            field: "selectedTemplate",
                                            value: selectedTemplate?.label,
                                            action: "copy",
                                        })
                                    }
                                    title={"Copy"}
                                    btnIcon={
                                        <CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(selectedTemplate?._meta, true)}
                                    style={getIconStyle(selectedTemplate?._meta, true)}
                                />
                                <FTIconButton
                                    handler={() =>
                                        setEditInfo({
                                            open: true,
                                            field: "selectedTemplate",
                                            value: selectedTemplate?.label,
                                            action: "edit",
                                        })
                                    }
                                    title={editInfo?.open ? "" : "Rename"}
                                    btnIcon={
                                        <DriveFileRenameOutlineIcon
                                            style={{ fontSize: "1.1rem", color: "grey" }}
                                            color="primary"
                                        />
                                    }
                                    placement="top"
                                    disabled={isDisabled(selectedTemplate?._meta, false)}
                                    style={getIconStyle(selectedTemplate?._meta, true)}
                                />
                                <FTIconButton
                                    handler={(e) => onShare(e, selectedTemplate)}
                                    title="Share"
                                    btnIcon={
                                        <ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(selectedTemplate?._meta, false)}
                                    style={getIconStyle(selectedTemplate?._meta, false)}
                                />
                            </div>
                        </div>
                        <div className="temp-input-grp2">
                            <div className="input-label">Created by</div>
                            <div className="label-value capitalize">
                                {selectedTemplate?._meta?.author ? selectedTemplate?._meta?.author : userInfo?.name}
                            </div>
                        </div>
                    </div>
                    <div className="w-100 d-flex">
                        <div className="temp-input-grp" style={{ width: "30%" }}>
                            <div className="input-label" style={{ width: "35%" }}>
                                Parent/Child Mapping
                            </div>
                            <div className="input-field" style={{ width: "65%" }}>
                                <AutocompleteField
                                    onChange={(_, v) =>
                                        setParentChildMapping((parentChildMapping) => ({
                                            ...parentChildMapping,
                                            selectedMapping: v,
                                        }))
                                    }
                                    provider={(q) => provider(daaSharedObjList.parentChildMapping || [], q)}
                                    value={{
                                        id: parentChildMapping?.selectedMapping?.id || "",
                                        label: parentChildMapping?.selectedMapping?.label || "",
                                    }}
                                    placeholder=""
                                    inputPropsStyle={styles}
                                    disableUnderline={true}
                                    forcePopupIcon={true}
                                    searchIcon={false}
                                    popperWidth="300px"
                                    renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                                />
                                <FTIconButton
                                    handler={() =>
                                        setEditInfo({
                                            open: true,
                                            field: "parentChildMapping",
                                            value: parentChildMapping?.selectedMapping?.label,
                                            action: "copy",
                                        })
                                    }
                                    title={"Copy"}
                                    btnIcon={
                                        <CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(parentChildMapping?.selectedMapping?._meta, true)}
                                    style={getIconStyle(parentChildMapping?.selectedMapping?._meta, true)}
                                />
                                <FTIconButton
                                    handler={() => {
                                        setParentChildMapping((mapping) => ({ ...mapping, openEditDialog: true }));
                                    }}
                                    title={parentChildMapping?.selectedMapping ? "Edit" : "Create"}
                                    btnIcon={
                                        <ModeEditIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    style={squareBtnStyle}
                                />
                                <FTIconButton
                                    handler={(e) => onShare(e, parentChildMapping?.selectedMapping)}
                                    title="Share"
                                    btnIcon={
                                        <ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(parentChildMapping?.selectedMapping?._meta, false)}
                                    style={getIconStyle(parentChildMapping?.selectedMapping?._meta, false)}
                                />
                                <ShareWith
                                    shareInfo={shareInfo}
                                    setShareInfo={setShareInfo}
                                    refreshData={() => refreshData(shareInfo.data?._meta?.type, shareInfo.data?.id)}
                                    setBenchmarkModelData={null}
                                />
                            </div>
                            {parentChildMapping?.openEditDialog && (
                                <Dialog
                                    id="parent-child-mapping"
                                    open={parentChildMapping?.openEditDialog}
                                    onClose={() =>
                                        setParentChildMapping((parentChildMapping) => ({
                                            ...parentChildMapping,
                                            openEditDialog: false,
                                        }))
                                    }
                                    maxWidth="xl"
                                    fullWidth
                                >
                                    <ParentChildMapping
                                        app={app}
                                        zone={type}
                                        selectedMapping={parentChildMapping}
                                        userInfo={userInfo}
                                        portfolioList={portfolioList}
                                        saaSharedObjList={saaSharedObjList}
                                        refreshDaaData={refreshDaaData}
                                        changeParentChildMapping={(mapping) => {
                                            setParentChildMapping((parentChildMapping) => ({
                                                ...parentChildMapping,
                                                selectedMapping: mapping,
                                            }));
                                        }}
                                        appSettings={appSettings}
                                        benchmarkMappingList={daaSharedObjList?.benchmarkMapping || []}
                                        deleteOption={deleteOption}
                                        daaPfs={daaPfs}
                                    />
                                </Dialog>
                            )}
                        </div>
                        <div className="temp-input-grp2">
                            <div className="input-label" style={{ width: "30%" }}>
                                ISRC Mapping
                            </div>
                            <div className="input-field" style={{ width: "70%" }}>
                                <AutocompleteField
                                    onChange={(_, v) =>
                                        setIsrcMapping((mappings) => ({
                                            ...mappings,
                                            selectedMapping: v,
                                        }))
                                    }
                                    provider={(q) => provider(daaSharedObjList.isrcMapping || [], q)}
                                    value={{
                                        id: isrcMapping?.selectedMapping?.id || "",
                                        label: isrcMapping?.selectedMapping?.label || "",
                                    }}
                                    placeholder="ISRC Mapping..."
                                    inputPropsStyle={styles}
                                    disableUnderline={true}
                                    forcePopupIcon={true}
                                    searchIcon={false}
                                    renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                                    popperWidth="300px"
                                />
                                <FTIconButton
                                    handler={() =>
                                        setEditInfo({
                                            open: true,
                                            field: "isrcMapping",
                                            value: isrcMapping?.selectedMapping?.label,
                                            action: "copy",
                                        })
                                    }
                                    title={"Copy"}
                                    btnIcon={
                                        <CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(isrcMapping?.selectedMapping?._meta, true)}
                                    style={getIconStyle(isrcMapping?.selectedMapping?._meta, true)}
                                />
                                <FTIconButton
                                    handler={() => setIsrcMapping((m) => ({ ...m, open: true }))}
                                    title="Edit"
                                    btnIcon={
                                        <ModeEditIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    style={squareBtnStyle}
                                />

                                <FTIconButton
                                    handler={(e) => onShare(e, isrcMapping?.selectedMapping)}
                                    title="Share"
                                    btnIcon={
                                        <ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(isrcMapping?.selectedMapping?._meta, false)}
                                    style={getIconStyle(isrcMapping?.selectedMapping?._meta, false)}
                                />
                                <AdornedButton
                                    variant="outlined"
                                    size="small"
                                    onClick={() => setUploadPopup("isrc")}
                                    loading={false}
                                    style={{ padding: 0, marginLeft: "5px" }}
                                >
                                    Upload
                                </AdornedButton>
                                <Mapping
                                    app={app}
                                    zone={type}
                                    appSettings={appSettings}
                                    mappingInfo={isrcMapping}
                                    setMappingInfo={setIsrcMapping}
                                    daaSharedObjList={daaSharedObjList?.isrcMapping || []}
                                    refreshDaaData={refreshDaaData}
                                    deleteOption={deleteOption}
                                    daaPfs={daaPfs}
                                    mappingConfig={isrcMappingCfg}
                                />
                            </div>
                        </div>
                        <div className="temp-input-grp2">
                            <div className="input-label" style={{ width: "40%" }}>
                                ISRC Benchmark Mapping
                            </div>
                            <div className="input-field" style={{ width: "60%" }}>
                                <AutocompleteField
                                    onChange={(_, v) =>
                                        setIsrcBmMapping((mappings) => ({
                                            ...mappings,
                                            selectedMapping: v,
                                        }))
                                    }
                                    provider={(q) => provider(daaSharedObjList.isrcBmMapping || [], q)}
                                    value={{
                                        id: isrcBmMapping?.selectedMapping?.id || "",
                                        label: isrcBmMapping?.selectedMapping?.label || "",
                                    }}
                                    placeholder="ISRC Benchmark Mapping..."
                                    disableUnderline={true}
                                    forcePopupIcon={true}
                                    searchIcon={false}
                                    inputPropsStyle={{ ...styles, minWidth: "215px" }}
                                    renderOption={(props, option) => RenderOption(props, option, deleteOption)}
                                    popperWidth="300px"
                                />
                                <FTIconButton
                                    handler={() =>
                                        setEditInfo({
                                            open: true,
                                            field: "isrcBmMapping",
                                            value: isrcBmMapping?.selectedMapping?.label,
                                            action: "copy",
                                        })
                                    }
                                    title={"Copy"}
                                    btnIcon={
                                        <CopyAllIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(isrcBmMapping?.selectedMapping?._meta, true)}
                                    style={getIconStyle(isrcBmMapping?.selectedMapping?._meta, true)}
                                />
                                <FTIconButton
                                    handler={() => setIsrcBmMapping((m) => ({ ...m, open: true }))}
                                    title="Edit"
                                    btnIcon={
                                        <ModeEditIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    style={squareBtnStyle}
                                />
                                <FTIconButton
                                    handler={(e) => onShare(e, isrcBmMapping?.selectedMapping)}
                                    title="Share"
                                    btnIcon={
                                        <ShareIcon style={{ fontSize: "1.1rem", color: "grey" }} color="primary" />
                                    }
                                    placement="top"
                                    disabled={isDisabled(isrcBmMapping?.selectedMapping?._meta, false)}
                                    style={getIconStyle(isrcBmMapping?.selectedMapping?._meta, false)}
                                />
                                <Mapping
                                    app={app}
                                    zone={type}
                                    appSettings={appSettings}
                                    mappingInfo={isrcBmMapping}
                                    setMappingInfo={setIsrcBmMapping}
                                    daaSharedObjList={daaSharedObjList?.isrcBmMapping || []}
                                    refreshDaaData={refreshDaaData}
                                    deleteOption={deleteOption}
                                    daaPfs={daaPfs}
                                    mappingConfig={isrcBmMappingCfg}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="table-container" style={{ flexDirection: "column" }}>
                        <div className="saa-tb1" style={{ display: "flex" }}>
                            <div className="first-group-table">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>
                                                <div>
                                                    <span>Class</span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span>Category</span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span>Sub Category</span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span>Asset Name</span>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {groupedRows.map((row) => (
                                            <tr key={row.key} className={row.className}>
                                                <td>{row.asset_class}&nbsp;</td>
                                                <td>{row.category}&nbsp;</td>
                                                <td>{row.sub_category}&nbsp;</td>
                                                <td>{row.asset_name}&nbsp;</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            {daaGraphCols1.map((column, idx) => (
                                <div
                                    key={idx}
                                    className="ft-saa-pwt"
                                    style={{ minWidth: "75px", backgroundColor: "white" }}
                                >
                                    <div className="saa-2">
                                        <div className="saa-pwt">
                                            <div className="daa-h4">{column.header}</div>
                                        </div>
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>
                                                    <div>
                                                        <span style={{ right: "5px", textAlign: "right" }}>
                                                            {column.col}
                                                        </span>
                                                    </div>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {groupedRows.map((row) => {
                                                return (
                                                    <tr
                                                        key={row.key}
                                                        className={row.isGroupedRow ? "table-text-sum-num" : ""}
                                                    >
                                                        <td>{percentPostfix(row[column.name])}&nbsp;</td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            ))}
                            <div className="ft-saa-cwt">
                                <div className="saa-2">
                                    <div className="saa-cwt">
                                        <div className="saa-h4" style={{ color: "black" }}>
                                            {`ISRC (${appSettings?.isrc?.date})`}
                                        </div>
                                    </div>
                                </div>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>
                                                <div>
                                                    <span style={{ width: "85%", textAlign: "right", color: "black" }}>
                                                        BM
                                                    </span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span style={{ width: "85%", textAlign: "right", color: "black" }}>
                                                        Current
                                                    </span>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {groupedRows.map((row) => {
                                            return (
                                                <tr
                                                    key={row.key}
                                                    className={row.isGroupedRow ? "table-text-sum-num" : ""}
                                                >
                                                    <td>{percentPostfix(row?.isrcBenchmark)}&nbsp;</td>
                                                    <td>{percentPostfix(row?.isrc)}&nbsp;</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            <div className="ft-saa-cwt">
                                <div className="saa-2">
                                    <div className="saa-cwt">
                                        <div className="saa-h4" style={{ color: "black" }}>
                                            Tilt
                                        </div>
                                    </div>
                                </div>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>
                                                <div>
                                                    <span style={{ width: "80%", textAlign: "right" }}>
                                                        <input
                                                            type="radio"
                                                            checked={tilt.selection === "policy"}
                                                            onChange={() => {
                                                                setTilt((tilt) => ({ ...tilt, selection: "policy" }));
                                                                updateTilt({ ...tilt, selection: "policy" });
                                                            }}
                                                        />
                                                        <label>Policy</label>
                                                    </span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span style={{ width: "80%", textAlign: "right" }}>
                                                        <input
                                                            type="radio"
                                                            checked={tilt.selection === "custom"}
                                                            onChange={() => {
                                                                setTilt((tilt) => ({ ...tilt, selection: "custom" }));
                                                                updateTilt({ ...tilt, selection: "custom" });
                                                            }}
                                                        />
                                                        <label>Custom</label>
                                                    </span>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {groupedRows.map((row) => {
                                            const parentPortofioId =
                                                parentChildMapping?.selectedMapping?._meta?.portfolios?.find(
                                                    (p) => p.isParent
                                                )?.portfolios;
                                            return (
                                                <tr
                                                    key={row.key}
                                                    className={row.isGroupedRow ? "table-text-sum-num" : ""}
                                                >
                                                    {!row.isGroupedRow && !row.isOnlyAssetInClass && (
                                                        <>
                                                            <td>
                                                                {percentPostfix(
                                                                    roundNumber(tilt.policy?.[row?.id] || 0)
                                                                )}
                                                                &nbsp;
                                                            </td>
                                                            <td className="saa-input" style={{ width: "74px" }}>
                                                                <input
                                                                    type="number"
                                                                    value={
                                                                        Number(tilt.custom?.[row?.id])
                                                                            ? roundNumber(tilt.custom?.[row?.id])
                                                                            : tilt.custom?.[row?.id]
                                                                    }
                                                                    onChange={(e) => {
                                                                        const customTiltInSameClass = {};
                                                                        Object.keys(tilt.custom).forEach((key) => {
                                                                            const rowInGroup = groupedRows.find(
                                                                                (r) => r?.id?.toString() === key
                                                                            );
                                                                            if (
                                                                                key === row.id.toString() ||
                                                                                (key !== row.id.toString() &&
                                                                                    tableData[key]?.asset_class ===
                                                                                        row.asset_class &&
                                                                                    !rowInGroup?.lockedAssets?.[
                                                                                        parentPortofioId
                                                                                    ])
                                                                            ) {
                                                                                customTiltInSameClass[key] =
                                                                                    tilt.custom[key];
                                                                            }
                                                                        });
                                                                        const updatedTilt = {
                                                                            ...tilt,
                                                                            custom: {
                                                                                ...tilt.custom,
                                                                                ...updateTheRestByRatio(
                                                                                    customTiltInSameClass,
                                                                                    row.id,
                                                                                    e.target.value
                                                                                ),
                                                                            },
                                                                        };
                                                                        setTilt(() => updatedTilt);
                                                                        updateTilt(updatedTilt);
                                                                    }}
                                                                />
                                                                %
                                                                {Boolean(row.lockedAssets?.[parentPortofioId]) ? (
                                                                    <LockIcon
                                                                        style={{
                                                                            width: "12px",
                                                                            height: "12px",
                                                                            cursor: "pointer",
                                                                            color: "#800000",
                                                                        }}
                                                                        onClick={() => {
                                                                            setGroupedRows((rows) => {
                                                                                const newRows = [...rows];
                                                                                newRows[row.key].lockedAssets[
                                                                                    parentPortofioId
                                                                                ] = false;
                                                                                return newRows;
                                                                            });
                                                                        }}
                                                                    />
                                                                ) : (
                                                                    <LockOpenIcon
                                                                        style={{
                                                                            width: "12px",
                                                                            height: "12px",
                                                                            cursor: "pointer",
                                                                        }}
                                                                        onClick={() => {
                                                                            markLocked(parentPortofioId, row);
                                                                        }}
                                                                    />
                                                                )}
                                                            </td>
                                                        </>
                                                    )}
                                                    {row.isGroupedRow &&
                                                        row.asset_name !== "Contribution to TE" &&
                                                        row.key !== groupedRows.length - 1 && (
                                                            <>
                                                                <td>
                                                                    {percentPostfix(
                                                                        roundNumber(
                                                                            tilt.policyRawTiltSum?.[row?.asset_name] ||
                                                                                0
                                                                        )
                                                                    )}
                                                                    &nbsp;
                                                                </td>
                                                                <td className="saa-input" style={{ width: "74px" }}>
                                                                    <input
                                                                        type="number"
                                                                        value={
                                                                            Number(tilt?.rawTiltSum?.[row?.asset_name])
                                                                                ? roundNumber(
                                                                                      tilt?.rawTiltSum?.[
                                                                                          row?.asset_name
                                                                                      ]
                                                                                  )
                                                                                : tilt?.rawTiltSum?.[row?.asset_name]
                                                                        }
                                                                        onChange={(e) => {
                                                                            const value = e.target.value;
                                                                            const updatedRawTiltSum = {};
                                                                            Object.keys(tilt.rawTiltSum).forEach(
                                                                                (key) => {
                                                                                    if (
                                                                                        key === row.asset_name ||
                                                                                        (key !== row.asset_name &&
                                                                                            !tilt.lockedRawTiltSum?.[
                                                                                                key
                                                                                            ])
                                                                                    ) {
                                                                                        updatedRawTiltSum[key] =
                                                                                            tilt.rawTiltSum[key];
                                                                                    }
                                                                                }
                                                                            );
                                                                            const rawTiltSum = {
                                                                                ...tilt.rawTiltSum,
                                                                                ...updateTheRestByRatio(
                                                                                    updatedRawTiltSum,
                                                                                    row.asset_name,
                                                                                    value
                                                                                ),
                                                                            };
                                                                            const daaTargetClassSum = {
                                                                                ...tilt.daaTargetClassSum,
                                                                            };
                                                                            Object.entries(rawTiltSum).forEach(
                                                                                ([key, value]: any) => {
                                                                                    daaTargetClassSum[key] = Number(
                                                                                        value
                                                                                    )
                                                                                        ? new Decimal(value).plus(
                                                                                              new Decimal(
                                                                                                  tilt.bmClassSum[key]
                                                                                              )
                                                                                          )
                                                                                        : 0;
                                                                                }
                                                                            );
                                                                            const updatedTilt = {
                                                                                ...tilt,
                                                                                rawTiltSum,
                                                                                daaTargetClassSum,
                                                                            };
                                                                            setTilt(() => updatedTilt);
                                                                            updateTilt(updatedTilt);
                                                                        }}
                                                                    />
                                                                    %
                                                                    {Boolean(
                                                                        tilt.lockedRawTiltSum?.[row.asset_name]
                                                                    ) ? (
                                                                        <LockIcon
                                                                            style={{
                                                                                width: "12px",
                                                                                height: "12px",
                                                                                cursor: "pointer",
                                                                                color: "#800000",
                                                                            }}
                                                                            onClick={() => {
                                                                                setTilt((tilt) => ({
                                                                                    ...tilt,
                                                                                    lockedRawTiltSum: {
                                                                                        ...tilt.lockedRawTiltSum,
                                                                                        [row.asset_name]: false,
                                                                                    },
                                                                                }));
                                                                            }}
                                                                        />
                                                                    ) : (
                                                                        <LockOpenIcon
                                                                            style={{
                                                                                width: "12px",
                                                                                height: "12px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                            onClick={() => {
                                                                                setTilt((tilt) => ({
                                                                                    ...tilt,
                                                                                    lockedRawTiltSum: {
                                                                                        ...tilt.lockedRawTiltSum,
                                                                                        [row.asset_name]: true,
                                                                                    },
                                                                                }));
                                                                            }}
                                                                        />
                                                                    )}
                                                                </td>
                                                            </>
                                                        )}
                                                    {(row.isOnlyAssetInClass || row.key === groupedRows.length - 1) && (
                                                        <>
                                                            <td style={{ paddingRight: "12px" }}>
                                                                {percentPostfix(
                                                                    roundNumber(tilt.policy?.[row?.id]) || 0
                                                                )}
                                                                &nbsp;
                                                            </td>
                                                            <td style={{ paddingRight: "12px" }}>
                                                                {percentPostfix(
                                                                    roundNumber(tilt.custom?.[row?.id]) || 0
                                                                )}
                                                                &nbsp;
                                                            </td>
                                                        </>
                                                    )}
                                                    {row.asset_name === "Contribution to TE" && (
                                                        <>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                        </>
                                                    )}
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            <div className="ft-saa-cwt">
                                <div className="saa-2">
                                    <div className="saa-cwt">
                                        <div className="saa-h4">Limit</div>
                                    </div>
                                </div>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>
                                                <div>
                                                    <span style={{ width: "85%", textAlign: "right" }}>Min</span>
                                                </div>
                                            </th>
                                            <th>
                                                <div>
                                                    <span style={{ width: "85%", textAlign: "right" }}>Max</span>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {groupedRows.map((row) => {
                                            return (
                                                <tr
                                                    key={row.key}
                                                    className={row.isGroupedRow ? "table-text-sum-num" : ""}
                                                >
                                                    <td>{percentPostfix(row.limitMin)}&nbsp;</td>
                                                    <td>{percentPostfix(row.limitMax)}&nbsp;</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            <div className="ft-saa-cwt">
                                <div className="saa-2">
                                    <div className="saa-cwt">
                                        <div className="saa-h4">DAA Target Portfolio</div>
                                    </div>
                                </div>
                                <table>
                                    <thead>
                                        <tr>
                                            {sortedPortfolios?.map((portfolio) => (
                                                <th style={{ minWidth: "75px" }}>
                                                    <div>
                                                        <span
                                                            style={{
                                                                width: "85%",
                                                                textAlign: "right",
                                                                color: "#cc701b",
                                                            }}
                                                        >
                                                            {portfolio?.isParent
                                                                ? "*" + portfolio?.portfolios
                                                                : portfolio?.portfolios}
                                                        </span>
                                                    </div>
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {groupedRows.map((row) => {
                                            return (
                                                <tr
                                                    key={row.key}
                                                    className={row.isGroupedRow ? "table-text-sum-num" : ""}
                                                    style={{ minWidth: "60px" }}
                                                >
                                                    {sortedPortfolios?.map((portfolio) => {
                                                        const limitMax = Number(portfolio[row.asset_class]?.max) || 100;
                                                        if (row.isGroupedRow || tilt.selection === "policy") {
                                                            const groupLimitMax =
                                                                Number(portfolio[row.asset_name]?.max) || 100;
                                                            const groupLimitMin =
                                                                Number(portfolio[row.asset_name]?.min) || 0;
                                                            const color =
                                                                row?.[portfolio.portfolios] < groupLimitMin ||
                                                                row?.[portfolio.portfolios] > groupLimitMax ||
                                                                (row.key === groupedRows.length - 1 &&
                                                                    row?.[portfolio?.portfolios] !== 100)
                                                                    ? "red"
                                                                    : "";
                                                            return (
                                                                <td style={{ color }}>
                                                                    {percentPostfix(row?.[portfolio?.portfolios])}
                                                                    &nbsp;
                                                                </td>
                                                            );
                                                        } else {
                                                            let color =
                                                                row?.[portfolio.portfolios] < 0 ||
                                                                row?.[portfolio.portfolios] > limitMax
                                                                    ? "red"
                                                                    : "";
                                                            return (
                                                                <td className="saa-input">
                                                                    <input
                                                                        type="number"
                                                                        min="0"
                                                                        style={{
                                                                            color,
                                                                        }}
                                                                        value={
                                                                            Number(row?.[portfolio?.portfolios])
                                                                                ? roundNumber(
                                                                                      row?.[portfolio?.portfolios]
                                                                                  )
                                                                                : row?.[portfolio?.portfolios]
                                                                        }
                                                                        onChange={(e) => {
                                                                            color =
                                                                                Number(e.target.value) > limitMax
                                                                                    ? "red"
                                                                                    : "";
                                                                            const currentObj = {};
                                                                            const allRowsInPortfolio = {};
                                                                            tableData.forEach((r, i) => {
                                                                                const rowInGroup = groupedRows.find(
                                                                                    (row) => row?.id === i
                                                                                );
                                                                                if (
                                                                                    row.id === rowInGroup.id ||
                                                                                    (row.id !== rowInGroup.id &&
                                                                                        r.asset_class ===
                                                                                            row.asset_class &&
                                                                                        !rowInGroup?.lockedAssets?.[
                                                                                            portfolio?.portfolios
                                                                                        ])
                                                                                ) {
                                                                                    currentObj[r.id] =
                                                                                        r?.[portfolio?.portfolios];
                                                                                }
                                                                                allRowsInPortfolio[r.id] =
                                                                                    r?.[portfolio?.portfolios];
                                                                            });
                                                                            const updatedPortfolioData =
                                                                                updateTheRestByRatio(
                                                                                    currentObj,
                                                                                    row.id,
                                                                                    e.target.value
                                                                                );
                                                                            updateTargetPortfolio(portfolio, {
                                                                                ...allRowsInPortfolio,
                                                                                ...updatedPortfolioData,
                                                                            });
                                                                        }}
                                                                    />
                                                                    %
                                                                    {Boolean(
                                                                        row.lockedAssets?.[portfolio?.portfolios]
                                                                    ) ? (
                                                                        <LockIcon
                                                                            style={{
                                                                                width: "12px",
                                                                                height: "12px",
                                                                                cursor: "pointer",
                                                                                color: "#800000",
                                                                            }}
                                                                            onClick={() => {
                                                                                setGroupedRows((rows) => {
                                                                                    const newRows = [...rows];
                                                                                    newRows[row.key].lockedAssets[
                                                                                        portfolio?.portfolios
                                                                                    ] = false;
                                                                                    return newRows;
                                                                                });
                                                                            }}
                                                                        />
                                                                    ) : (
                                                                        <LockOpenIcon
                                                                            style={{
                                                                                width: "12px",
                                                                                height: "12px",
                                                                                cursor: "pointer",
                                                                            }}
                                                                            onClick={() => {
                                                                                markLocked(portfolio.portfolios, row);
                                                                            }}
                                                                        />
                                                                    )}
                                                                </td>
                                                            );
                                                        }
                                                    })}
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="saa-tb3">
                            <div style={{ display: "flex" }}>
                                <div className="first-group-table" style={{ marginTop: 0 }}>
                                    <table>
                                        <tbody>
                                            {tb3_rows.map((row) => (
                                                <tr key={row.value}>
                                                    <td></td>
                                                    <td></td>
                                                    <td>{row.label}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                {daaGraphCols1.map((column, idx) => (
                                    <div
                                        key={idx}
                                        className="ft-saa-pwt"
                                        style={{ minWidth: "75px", backgroundColor: "white" }}
                                    >
                                        <table>
                                            <tbody>
                                                {tb3_rows.map((row) => (
                                                    <tr key={row.value}>
                                                        <td>
                                                            {percentPostfix(
                                                                roundNumber(dataPart2[column.name]?.[row.value])
                                                            )}
                                                            &nbsp;
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                ))}
                                {daaGraphCols2.map((group, idx) => {
                                    return (
                                        <div
                                            key={idx}
                                            className="ft-saa-pwt"
                                            style={{
                                                minWidth: "150px",
                                                backgroundColor: "white",
                                                visibility: group.showForSecTable ? "visible" : "hidden",
                                            }}
                                        >
                                            <table>
                                                <tbody>
                                                    {tb3_rows.map((row) => (
                                                        <tr key={row.value}>
                                                            <td>
                                                                {percentPostfix(
                                                                    roundNumber(
                                                                        dataPart2[group.cols[0].name]?.[row.value]
                                                                    )
                                                                )}
                                                                &nbsp;
                                                            </td>
                                                            <td>
                                                                {percentPostfix(
                                                                    roundNumber(
                                                                        dataPart2[group.cols[1].name]?.[row.value]
                                                                    )
                                                                )}
                                                                &nbsp;
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    );
                                })}

                                <div
                                    className="ft-saa-pwt"
                                    style={{
                                        minWidth: `${Math.max(
                                            parentChildMapping?.selectedMapping?._meta?.portfolios?.length * 75,
                                            150
                                        )}px`,
                                        backgroundColor: "white",
                                    }}
                                >
                                    <table>
                                        <tbody>
                                            {tb3_rows.map((row) => (
                                                <tr key={row.key}>
                                                    {parentChildMapping?.selectedMapping?._meta?.portfolios?.map(
                                                        (portfolio) => (
                                                            <td>
                                                                {percentPostfix(
                                                                    roundNumber(
                                                                        dataPart2[portfolio.portfolios]?.[row.value]
                                                                    )
                                                                )}
                                                                &nbsp;
                                                            </td>
                                                        )
                                                    )}
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="saa-output-btn" className="d-flex w-100">
                        <div className="btn-group" style={{ width: "100%" }}>
                            <AdornedButton
                                className="save-btn"
                                variant="outlined"
                                size="small"
                                onClick={() => setOpenExpDialog(true)}
                            >
                                Export Report
                            </AdornedButton>
                            <AdornedButton className="sbt-btn m-1" variant="outlined" size="small">
                                Refresh
                            </AdornedButton>
                            <AdornedButton
                                className="save-btn"
                                variant="outlined"
                                size="small"
                                disabled={checkDisabledSave()}
                                onClick={() => handleSaveTemplate()}
                            >
                                Save
                            </AdornedButton>
                        </div>
                    </div>
                    <ConfirmDialog
                        title=""
                        open={deletePopup.open}
                        setOpen={(open) => setDeletePopup({ ...deletePopup, open })}
                        stopPropagation={true}
                        onConfirm={(e) => {
                            e?.stopPropagation();
                            handleDelete();
                        }}
                    >
                        Are you sure you want to delete?
                    </ConfirmDialog>
                </div>
            </div>
            <div style={{ width: "100%", display: "flex" }}>
                <div style={{ width: "50%" }}>
                    <EfficientFrontier data={dataPart2} initialData={initialDataPart2} portfolios={portfolios} />
                </div>
                <div style={{ width: "50%", marginLeft: 8 }}>
                    <AssetAllocationWeights portfolios={portfolios} data={tableData} />
                </div>
            </div>
        </div>
    );
}
