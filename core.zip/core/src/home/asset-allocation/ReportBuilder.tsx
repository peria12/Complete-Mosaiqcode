import React, { useState, useEffect } from "react";
import FTTable from "common/FTTable";
import { getCamelCase, get } from "utils/helpers";
import Typography from "@mui/material/Typography";
import { HChart } from "common/HChart";
import * as Highcharts from "highcharts";
import { AdornedButton } from "common/FTButtons";
import InputField from "common/InputField";
import FTSlider from "common/FTSlider";
import { FileDownload, FileDownloadUrl } from "common/FileDownload";

const hColors: any = Highcharts?.getOptions()?.colors;
const colors: any = [null, hColors?.[8], hColors?.[2]];

const generateChartData = (reportInfo: any, records: any) => {
    if (!records) return {};
    return {
        title: { text: reportInfo?.title || "" },
        xAxis: {
            categories: records?.map((rec) => rec[reportInfo?.xAxisFieldId]),
        },
        series: reportInfo?.columns?.map((col: any, i: number) => {
            return {
                type: "column",
                name: col.name,
                color: colors[i],
                data: records.map((rec) => rec[col?.id]),
            };
        }),
    };
};

const transformColumns = (columns: any, reportType: any) => {
    const isISRC = reportType == "ftis_risk_dashboard";
    return columns?.map((col) => {
        let type = col.type;
        if (col.percent) {
            type = "percentage";
        }
        return {
            ...col,
            toFixed: type == "numeric" ? 3 : 2,
            key: col.id,
            label: isISRC && col.id == "index" ? "" : getCamelCase(col.id),
            type: type,
        };
    });
};

const InputElement = ({ id, field, value, onChange, errors }) => (
    <div style={{ paddingRight: "12px", width: "100%" }}>
        <InputField key={id} field={field} value={value} onChange={onChange} shrink={true} />
        {errors[field.id] && (
            <small className="text-danger" style={{ fontSize: "0.85em" }}>
                {" "}
                {errors[field.id]}{" "}
            </small>
        )}
    </div>
);

const DataTable = ({ config, reportData, inputFields = {}, onChangeFilters, subTitle, reportType }) => {
    let columns = config?.columns || reportData?.columns || [];
    if (config?.columnWidth) {
        columns = columns.map((col) => ({ ...col, width: config?.columnWidth }));
    }
    let cols: any = [];
    if (Array.isArray(columns?.[0])) {
        cols = columns?.map((col) => transformColumns(col, reportType));
    } else {
        cols = transformColumns(columns, reportType);
    }
    const meta = { ...config?.meta, headerBgColor: "white", striped: true };
    return (
        <>
            {subTitle}
            <FTTable
                columns={cols || []}
                rows={reportData?.data || []}
                meta={{ ...meta }}
                headerStyle={config?.headerStyle}
                inputField={{
                    ...inputFields,
                    onChange: (fieldId, index) => onChangeFilters(fieldId, index, config?.id),
                }}
            />
        </>
    );
};

function transformReportData(reportInfo: any = [], config: any = {}) {
    let groupColumns: any = [];
    let grpRows: any = [];
    const indentationColumn = "index";
    const defaultRowStyle = { padding: "6px 16px", borderRight: "1px solid rgb(218 218 211)" };
    config?.groups?.forEach((ele, index) => {
        if (config?.groups?.[index]?.groupTitle) {
            const grpInfo = config?.groups?.[index];
            const grpRow = {
                index: grpInfo?.groupTitle,
                valueFormatting: false,
                colStyle: { ...defaultRowStyle, ...grpInfo?.headerStyle, fontWeight: 600 },
            };
            groupColumns?.forEach((col) => {
                if (col?.id !== "index") {
                    grpRow[col?.id] = col?.id;
                }
            });
            grpRows = [...grpRows, grpRow];
        }
        if (ele.type == "section") {
            const section = {
                ...ele,
                [indentationColumn]: ele.title,
                colStyle: { ...defaultRowStyle, ...ele?.style, textAlign: "center" },
            };
            grpRows = [...grpRows, section];
        } else if (ele?.id && reportInfo?.reports?.[ele?.id]) {
            const repInfo = reportInfo?.reports[ele?.id];
            if (index == 0) {
                groupColumns = repInfo?.columns?.map((col, i) => {
                    if (i == 0) {
                        col.colSpan = 2;
                    }
                    return col;
                });
            }
            const data = repInfo?.data || [];
            const styledRows = data.map((row, i) => {
                row.colStyle = { ...defaultRowStyle };
                row.colSpan = ele.colSpan;
                if (ele?.rowsWithDefaultColumns?.length > 0 && ele?.rowsWithDefaultColumns?.includes(i)) {
                    row.skipOverideColumn = true;
                }
                if (ele?.columnMap) {
                    Object.keys(ele?.columnMap).map((key) => {
                        row[key] = row[ele?.columnMap[key]];
                    });
                }
                if (i == 0 && !ele?.groupTitle) {
                    row.colStyle = { ...row?.colStyle, ...ele?.headerStyle };
                } else {
                    let padding: any = 5;
                    if (row[indentationColumn]) {
                        const values = row[indentationColumn].split("|");
                        if (values?.length > 1) {
                            row[indentationColumn] = values[values?.length - 1];
                            if (ele.indentation != false) {
                                padding = padding + values?.length * 12;
                                row.colStyleMap = {
                                    [indentationColumn]: { padding: `6px ${padding}px` },
                                };
                            }
                        }
                    }
                }
                if (ele?.colStyleMap) {
                    Object.keys(ele?.colStyleMap).map((key) => {
                        if (!row?.colStyleMap) {
                            row.colStyleMap = {};
                        }
                        if (row?.colStyleMap?.[key]) {
                            const style = row?.colStyleMap?.[key];
                            row.colStyleMap[key] = { ...style, ...ele?.colStyleMap[key] };
                        } else {
                            row.colStyleMap[key] = { ...ele?.colStyleMap[key] };
                        }
                    });
                }
                if (ele?.columns?.length > 0) {
                    ele?.columns?.map((col) => {
                        const key = col?.id;
                        if (!row?.colStyleMap) {
                            row.colStyleMap = {};
                        }
                        if (row?.colStyleMap?.[key]) {
                            const style = row?.colStyleMap?.[key];
                            row.colStyleMap[key] = { ...style, type: col?.type };
                        } else {
                            row.colStyleMap[key] = { type: col?.type };
                        }
                    });
                }
                return row;
            });
            grpRows = [...grpRows, ...styledRows];
        }
    });
    return { columns: groupColumns, data: grpRows };
}

export default function ReportBuilder({
    classes,
    currTabInfo,
    config,
    reportInfo,
    filterValues,
    setFilterValues,
    handler,
    errors = {},
    // setErrors,
    InputTypes,
    reportType,
}) {
    const { type, id, title, accessKey, rows, label } = config;
    const { id: tabId } = currTabInfo;
    const curTabFilterValues = filterValues?.[tabId];
    let reportData = reportInfo?.reports?.[id] || {};
    const isLoading = reportInfo?.isLoading;

    if (InputTypes.includes(type)) {
        reportData = get(curTabFilterValues, id);
    } else if (accessKey) {
        reportData = get(reportInfo?.reports, accessKey);
    }
    if (config?.groups?.length > 0 && reportType == "ftis_risk_dashboard") {
        reportData = transformReportData(reportInfo, config);
    }

    const inputFields = { fields: {} };
    const [chartData, setChartData] = useState({});

    const isDisabled = () => Object.keys(errors).find((key) => errors[key]);

    useEffect(() => {
        if (type === "chart") {
            setChartData({});
            let chartConfig = {};
            const _reportData: any = get(reportInfo?.reports, accessKey);
            if (reportInfo && _reportData?.length) {
                chartConfig = generateChartData(config, _reportData);
            }
            const updatedConfig = { ...chartData, [id]: chartConfig };
            setChartData(updatedConfig);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [reportInfo]); //reportInfo, config

    const onChangeFilters = (prop, index, elementId) => (event: any) => {
        const value = event.target.value;
        const eleInfo = currTabInfo?.elements.find((ele: any) => ele.id == elementId) || {};
        let updatedValue = { ...filterValues[tabId] };
        if (["text", "number"].includes(eleInfo.type)) {
            updatedValue = { ...updatedValue, [elementId]: value };
        } else if (eleInfo.type === "input-table") {
            const list = [...updatedValue[elementId]];
            list[index][prop] = value;
            updatedValue = { ...updatedValue, [elementId]: list };
        } else if (eleInfo.type === "field-group") {
            updatedValue = { ...updatedValue, [elementId]: { ...updatedValue[elementId], [prop]: value } };
        }
        setFilterValues({ ...filterValues, [tabId]: updatedValue });
        // setErrors({ ...errors, [elementId]: "" });
        // if (value === "" || value === null || value === undefined) {
        //     // setErrors({ ...errors, [fieldInfo?.id]: "Required" });
        // } else if (["number"].includes(eleInfo.type)) {
        //     if (isNaN(value)) {
        //         setErrors({ ...errors, [elementId]: "Invalid input" });
        //     }
        // }
    };

    const subTitle = (
        <>
            {title && (
                <Typography style={{ paddingBottom: "7px" }} align="left" component="h6" variant="h6">
                    {title}
                </Typography>
            )}
        </>
    );

    const buttonElement = (
        <AdornedButton
            style={{ marginLeft: "auto" }}
            onClick={() => handler(tabId)}
            className={classes.btn}
            color="primary"
            variant="contained"
            loading={reportInfo?.btnLoading}
            disabled={isDisabled()}
        >
            {label}
        </AdornedButton>
    );

    switch (type) {
        case "table":
            return (
                <>
                    {!isLoading && (
                        <DataTable
                            config={config}
                            reportData={reportData}
                            onChangeFilters={onChangeFilters}
                            subTitle={subTitle}
                            reportType={reportType}
                        />
                    )}
                </>
            );

        case "input-table": {
            rows.forEach((ele) => {
                if (["text", "number", "percent"].includes(ele.type)) {
                    inputFields["fields"][ele.id] = { ...ele };
                }
            });
            return (
                <DataTable
                    config={config}
                    reportData={{ columns: config?.columns, data: reportData }}
                    inputFields={inputFields}
                    onChangeFilters={onChangeFilters}
                    subTitle={subTitle}
                    reportType={reportType}
                />
            );
        }
        case "chart":
            return <>{!reportInfo?.btnLoading && chartData?.[id] && <HChart key={id} option={chartData?.[id]} />}</>;

        case "text":
        case "number":
            return (
                <InputElement
                    id={id}
                    field={config}
                    errors={errors}
                    value={curTabFilterValues?.[id]}
                    onChange={(fieldId, index) => onChangeFilters(fieldId, index, id)}
                />
            );

        case "slider":
            return (
                <>
                    {subTitle}
                    <FTSlider
                        value={reportData || 0}
                        aria-label="pretto slider"
                        onChange={() => console.log("change")}
                        aria-labelledby="input-slider"
                        max={config.max}
                        min={config.min}
                        marks={config.marks}
                        valueLabelDisplay="auto"
                    />
                </>
            );
        case "field-group":
            return (
                <>
                    {subTitle}
                    <div className={classes.filter}>
                        {config?.fields?.map((field: any) => (
                            <InputElement
                                key={field.id}
                                id={field.id}
                                field={field}
                                errors={errors}
                                value={get(curTabFilterValues, `${id}.${field?.id}`, null)}
                                onChange={(fieldId, index) => onChangeFilters(fieldId, index, id)}
                            />
                        ))}
                    </div>
                </>
            );
        case "button-groups":
            return (
                <>
                    {config?.buttons?.map((btn: any, index) => {
                        if (btn.type === "download-button") {
                            const file_id = get(reportInfo?.reports, btn.accessKey, {})?.file_id;
                            return (
                                <FileDownload key={index} file_id={file_id}>
                                    <AdornedButton
                                        className={classes.btn}
                                        variant="contained"
                                        color="primary"
                                        disabled={!file_id}
                                    >
                                        {btn.label}
                                    </AdornedButton>
                                </FileDownload>
                            );
                        } else if (btn.type == "download-button-url") {
                            return (
                                <FileDownloadUrl key={index} url={btn.url} filename={btn.filename}>
                                    <AdornedButton className={classes.btn} variant="contained" color="primary">
                                        {btn.label}
                                    </AdornedButton>
                                </FileDownloadUrl>
                            );
                        }
                        return { buttonElement };
                    })}
                </>
            );

        case "button":
            return (
                <AdornedButton
                    style={{ marginLeft: "auto" }}
                    onClick={() => handler(tabId)}
                    className={classes.btn}
                    color="primary"
                    variant="contained"
                    loading={reportInfo?.btnLoading}
                    disabled={isDisabled()}
                >
                    {label}
                </AdornedButton>
            );

        default:
            return <></>;
    }
}
