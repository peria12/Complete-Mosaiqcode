import React from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import makeStyles from "@mui/styles/makeStyles";

const useRowStyles = makeStyles((theme) => ({
    root: {
        display: "flex",
        justifyContent: "center",
        flexWrap: "wrap",
        "& > *": {
            margin: theme.spacing(0.5),
        },
    },
    dialog: {
        minWidth: 120,
    },
    header: {
        color: "grey",
        fontSize: "1.12rem",
    },
    btn: {
        textTransform: "capitalize",
    },
    delBtn: {
        color: "#ffffff",
    },
    closeBtn: {
        position: "absolute",
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: theme.palette.grey[500],
    },
}));

function ErrorModal({ setOpenDialog, openDialog, popupError, setPopupErr }) {
    const classes = useRowStyles();
    function handleClose() {
        setOpenDialog(false);
        setPopupErr([]);
    }

    if (!openDialog) return null;
    return (
        <React.Fragment>
            <Dialog
                open={openDialog}
                onClose={handleClose}
                scroll={"paper"}
                aria-labelledby="dialog-title"
                aria-describedby="dialog-description"
                maxWidth={"sm"}
                fullWidth={true}
            >
                <DialogTitle id="dialog-title" className={classes.header}>
                    Error
                    <IconButton aria-label="close" className={classes.closeBtn} onClick={handleClose} size="large">
                        <CloseIcon fontSize="small" />
                    </IconButton>
                </DialogTitle>
                <DialogContent dividers={true}>
                    <ul>
                        {popupError.length > 0 ? (
                            popupError.map((message, idx) => <li key={idx}>{message.error[0]}</li>)
                        ) : (
                            <li>Error 1</li>
                        )}
                    </ul>
                </DialogContent>
            </Dialog>
        </React.Fragment>
    );
}

export default ErrorModal;
