import React, { useState, useEffect } from "react";
import { Theme } from "@mui/material/styles";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import DeleteIcon from "@mui/icons-material/Delete";
import clsx from "clsx";

import Access from "utils/access";
import Api from "utils/api";
import errorNotification from "utils/api-error";
import SearchBox from "common/SearchBox";
import { errorHandler } from "utils/error-handler";
import DOMPurify from "dompurify";
import { useScreenshot } from "utils/helpers";
import AppCover from "home/dashboad/AppCover";
import Loader from "common/Loader";
import ConfirmDialog from "common/ConfirmDialog";

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        container: {
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            alignItems: "center",
        },
        fieldsAccordianBar: {
            width: "80%",
            paddingTop: "20px",
        },
        headingWrapper: {
            display: "flex",
            width: "100%",
            justifyContent: "space-between",
        },
        heading: {
            fontSize: theme.typography.pxToRem(15),
            flexBasis: "33.33%",
            flexShrink: 0,
        },
        secondaryHeading: {
            fontSize: theme.typography.pxToRem(15),
            color: theme.palette.text.secondary,
        },
        docTitle: {
            fontWeight: 600,
            fontSize: "1.1rem",
        },
    })
);

export default function DALFields() {
    const classes = useStyles();
    const [searchText, setSearchText] = useState("");
    const [expanded, setExpanded] = React.useState({});
    const [dalFieldsInfo, setDalFieldsInfo] = useState({ orignalFields: [], fields: [] });
    const [deletePopup, setDeletePopup] = useState<any>({ open: false, deleteField: null });
    const [loading, setLoading] = useState(false);
    useScreenshot();

    useEffect(() => {
        setLoading(true);
        Api.getDALFields()
            .then((data) => {
                const dalFields: any = { orignalFields: Object.values(data.dal), fields: [] };
                setDalFieldsInfo(dalFields);
            })
            .catch((e: any) => {
                errorHandler(e);
                setDalFieldsInfo({ orignalFields: [], fields: [] });
            })
            .finally(() => setLoading(false));

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        let _fields = [];
        if (searchText) {
            _fields = searchByProp(dalFieldsInfo?.orignalFields, searchText);
        } else {
            _fields = dalFieldsInfo?.orignalFields;
        }
        _fields.sort((a: any, b: any) => {
            const id_arr_a = a._id.split(".");
            const id_arr_b = b._id.split(".");
            if (id_arr_a.length < id_arr_b.length) {
                return -1;
            }
            if (id_arr_a.length > id_arr_b.length) {
                return 1;
            }
            if (id_arr_a < id_arr_b) {
                return -1;
            }
            if (id_arr_a > id_arr_b) {
                return 1;
            }
            return 0;
        });
        setDalFieldsInfo({ ...dalFieldsInfo, fields: _fields });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchText, dalFieldsInfo?.orignalFields]);

    function searchByProp(array: any, searchText: string) {
        if (!searchText) {
            return [];
        }
        searchText = searchText.toLowerCase();
        return array?.filter((item: any) => {
            let texts = (item && item?.__doc?.search_texts) || [];
            if (texts?.length == 0 && item?._id && typeof item._id === "string") {
                texts = item._id.split("_")?.filter((e) => !!e);
            }
            const mached = texts.find((text) => text?.toLowerCase().indexOf(searchText) > -1);
            return mached ? true : false;
        });
    }

    const handleChange = (panelId) => (event, isExpanded) => {
        const val = isExpanded ? true : false;
        setExpanded({ ...expanded, [panelId]: val });
    };

    const renderTitle = (_idStr) => {
        if (_idStr && typeof _idStr === "string") {
            const words = _idStr.split("_");
            return words
                .map((word) => {
                    return word[0].toUpperCase() + word.substring(1);
                })
                .join(" ");
        }
        return _idStr;
    };

    function hasAdminAccess(_idStr) {
        if (_idStr && typeof _idStr === "string") {
            const words = _idStr.split(".");
            return Access.hasAccessToZone("dal", words[0], ["admin"]);
        }
        return false;
    }

    return (
        <AppCover header={<SearchBox setSearchText={setSearchText} placeholder={"Search DAL fields..."} />}>
            <div className={classes.container}>
                {loading ? (
                    <Loader />
                ) : (
                    <div className={classes.fieldsAccordianBar}>
                        {dalFieldsInfo?.fields?.length == 0 && (
                            <Accordion disabled style={{ background: "#fff" }}>
                                <AccordionSummary>
                                    {" "}
                                    <Typography className={classes.heading}>No match found</Typography>{" "}
                                </AccordionSummary>
                            </Accordion>
                        )}
                        {dalFieldsInfo?.fields?.map((field: any, i) => {
                            const id = "panel-" + i;
                            return (
                                <Accordion key={id} expanded={expanded[id]} onChange={handleChange(id)}>
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls={`${id}-content`}
                                        id={`${id}-header`}
                                    >
                                        <div className={classes.headingWrapper}>
                                            <Typography
                                                className={clsx(classes.heading, { [classes.docTitle]: expanded[id] })}
                                            >
                                                {renderTitle(field?._id)}
                                            </Typography>
                                            {field?._ff?.ns && hasAdminAccess(field?._id) && (
                                                <DeleteIcon
                                                    className="delete-icon"
                                                    style={{ color: "red" }}
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        setDeletePopup({
                                                            ...deletePopup,
                                                            open: true,
                                                            deleteField: field?._id,
                                                        });
                                                    }}
                                                />
                                            )}
                                        </div>
                                        {/* <Typography className={classes.secondaryHeading}>I am an accordion</Typography> */}
                                    </AccordionSummary>
                                    <AccordionDetails>
                                        <Typography>
                                            <div
                                                dangerouslySetInnerHTML={{
                                                    __html: DOMPurify.sanitize(
                                                        field?.__doc?.description || "No documentation available"
                                                    ),
                                                }}
                                            />
                                        </Typography>
                                    </AccordionDetails>
                                </Accordion>
                            );
                        })}
                        <ConfirmDialog
                            title=""
                            open={deletePopup.open}
                            setOpen={(open) => setDeletePopup({ ...deletePopup, open })}
                            stopPropagation={true}
                            onConfirm={(e) => {
                                e?.stopPropagation();
                                setLoading(true);
                                const splited = deletePopup?.deleteField.split(".");
                                const payload = {
                                    _ff: {
                                        ns: splited[0],
                                    },
                                    _id: splited.length === 2 ? splited[1] : "",
                                };
                                Api.deleteDALField(payload).then((res) => {
                                    if (res) {
                                        errorNotification.next({ type: "success", text: res.message, open: true });
                                        Api.getDALFields()
                                            .then((data) => {
                                                const dalFields: any = {
                                                    orignalFields: Object.values(data.dal),
                                                    fields: [],
                                                };
                                                setDalFieldsInfo(dalFields);
                                            })
                                            .catch((e: any) => {
                                                errorHandler(e);
                                                setDalFieldsInfo({ orignalFields: [], fields: [] });
                                            })
                                            .finally(() => setLoading(false));
                                    }
                                });
                            }}
                        >
                            Are you sure you want to delete?
                        </ConfirmDialog>
                    </div>
                )}
            </div>
        </AppCover>
    );
}
