import React, { useState, useContext } from "react";
import {
    Box,
    Button,
    Card,
    CardContent,
    Step,
    StepLabel,
    Stepper,
    Typography,
    Backdrop,
    CircularProgress,
    Snackbar,
    Alert,
} from "@mui/material";
import { useHistory } from "react-router-dom";
import _ from "lodash";
import EntitiesContainer from "../tabs/EntitiesTabs/EntitiesContainer";
import FieldsContainer from "../tabs/FieldsTabs/FieldsContainer";
import DatesContainer from "../tabs/DatesTab/DatesContainer";
import { BuildJsonContext } from "../contexts/BuildJsonContext";
import { mergeFieldJson, handleExcelFetch } from "../utils/common";
import SaveDialog from "./SaveDialog";
import Api from "../../../../utils/api";

const steps = ["Fields", "Entities", "Dates"];

export default function DALPlugin() {
    const history = useHistory();
    const [activeStep, setActiveStep] = useState<number>(0);
    const [loading, setLoading] = useState<boolean>(false);
    const [snackBaropen, setSnackBaropen] = useState<boolean>(false);
    const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
    const [messageInfo, setMessageInfo] = useState<any>();
    const {
        manageEntityScreenJson,
        savedEntityData,
        manageFieldsScreenJson,
        savedFieldsData,
        manageDatesScreenJson,
        savedDatesData,
        buildJsonValue,
        isFromDalPlugin,
        combinedFieldsData,
        combinedFieldsData: {
            fields: { splitedfieldsArr, splitedSubFieldsArr, splitedFiltersArr, splitedOthersArr },
        },
        combinedEntitiesData,
        combinedEntitiesData: {
            entities: selectedEntityData,
            id_date: selectedIDDateData,
            id_type: selectedIDTypeData,
        },
        combinedDatesData,
        combinedDatesData: { dates: selectedDatesData, date_info: selectedDateInfo },
    } = useContext(BuildJsonContext);
    const handleClose = (event: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === "clickaway") {
            return;
        }
        setSnackBaropen(false);
    };
    const saveEntitiesData = () => {
        manageEntityScreenJson?.({ type: "saveEntityData", payload: combinedEntitiesData });
        if (selectedEntityData.length !== 0)
            manageEntityScreenJson?.({ type: "updateEntitiesJson", payload: selectedEntityData });
        if (selectedIDDateData !== "")
            manageEntityScreenJson?.({ type: "updateIDDateJson", payload: selectedIDDateData });
        if (selectedIDTypeData !== "")
            manageEntityScreenJson?.({ type: "updateIDTypeJson", payload: selectedIDTypeData });
    };
    const resetEntitiesData = () => {
        manageEntityScreenJson?.({ type: "resetEntityData" });
        manageEntityScreenJson?.({ type: "updateSearchEntity", payload: savedEntityData });
    };
    const saveFieldsData = () => {
        manageFieldsScreenJson?.({ type: "saveFieldsData", payload: combinedFieldsData });

        if (splitedfieldsArr.length !== 0) {
            const req = mergeFieldJson(splitedfieldsArr, splitedSubFieldsArr, splitedFiltersArr, splitedOthersArr);
            manageFieldsScreenJson?.({ type: "updateFieldsJson", payload: req });
        }
    };
    const resetFieldsData = () => {
        manageFieldsScreenJson?.({ type: "resetFieldsData" });
        manageFieldsScreenJson?.({ type: "updateFieldsData", payload: savedFieldsData });
    };

    const handleNext = (isNext) => {
        if (isNext) setActiveStep((prevActiveStep) => prevActiveStep + 1);

        if (steps[activeStep] === "Entities") {
            saveEntitiesData();
        }
        if (steps[activeStep] === "Fields") {
            saveFieldsData();
        }
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };
    const saveDatesData = () => {
        manageDatesScreenJson?.({ type: "saveDatesData", payload: combinedDatesData });
        if (selectedDatesData.length !== 0) {
            manageDatesScreenJson?.({ type: "updateDatesJson", payload: selectedDatesData });
            localStorage.setItem("savedDalRequest", JSON.stringify({ ...buildJsonValue, dates: selectedDatesData }));
        }
        if (selectedDateInfo?.type !== null && selectedDateInfo?.type != undefined) {
            manageDatesScreenJson?.({ type: "updateDatesInfoJson", payload: selectedDateInfo });
            localStorage.setItem("savedDalRequest", JSON.stringify({ ...buildJsonValue, date_info: selectedDateInfo }));
        }
    };
    const resetDatesData = () => {
        manageDatesScreenJson?.({ type: "resetDatesData" });
        manageDatesScreenJson?.({ type: "updateDatesData", payload: savedDatesData });
    };
    const handleCancel = () => {
        if (
            _.isEqual(combinedFieldsData, savedFieldsData) &&
            _.isEqual(combinedEntitiesData, savedEntityData) &&
            _.isEqual(combinedDatesData, savedDatesData)
        ) {
            history.push("/dal/webui");
        } else {
            setConfirmOpen(true);
        }
    };
    const resetData = () => {
        if (steps[activeStep] === "Fields") {
            resetFieldsData();
        }
        if (steps[activeStep] === "Entities") {
            resetEntitiesData();
        }
        if (steps[activeStep] === "Dates") {
            resetDatesData();
        }
    };

    const handleFetchData = () => {
        saveDatesData();
        setLoading(true);
        const payload = Object.assign(JSON.parse(JSON.stringify(buildJsonValue)), { result_format: "excel" });
        Api.dal(payload, false)
            .then((res) => {
                if (res.error !== "") {
                    setSnackBaropen(true);
                    setMessageInfo({ message: `Error From API: ${res.error}`, severity: "error" });
                } else {
                    if (res.fields?.excel_file_info?.url) {
                        if (isFromDalPlugin) {
                            handleExcelFetch(res.fields.excel_file_info.url);
                        } else {
                            location.href = res.fields.excel_file_info.url;
                            setSnackBaropen(true);
                            setMessageInfo({ message: "File Downloaded Successfully", severity: "success" });
                        }
                    } else {
                        setSnackBaropen(true);
                        setMessageInfo({ message: "No Records Found", severity: "error" });
                    }
                }
                setLoading(false);
            })
            .catch((err) => {
                console.log(err);
                setLoading(false);
            });
    };

    return (
        <Box sx={{ width: "90%", margin: "80px auto 80px auto" }}>
            <Stepper activeStep={activeStep} alternativeLabel>
                {steps.map((label) => {
                    const stepProps = {};
                    const labelProps = {};

                    return (
                        <Step key={label} {...stepProps}>
                            <StepLabel {...labelProps}>{label}</StepLabel>
                        </Step>
                    );
                })}
            </Stepper>
            {activeStep === steps.length ? (
                <>
                    <Card sx={{ minWidth: 275, minHeight: 300, margin: 2 }}>
                        <CardContent>
                            <Typography variant="body2">Fetching data...</Typography>
                            <Box sx={{ display: "flex", flexDirection: "row", pt: 2 }}>
                                <Box sx={{ flex: "1 1 auto" }} />
                                {/* <Button onClick={handleReset}>Reset</Button> */}
                            </Box>
                        </CardContent>
                    </Card>
                </>
            ) : (
                <>
                    <Typography component="div" sx={{ my: 2 }}>
                        <Card sx={{ width: "100%", minHeight: 420 }}>
                            {activeStep === 0 && <FieldsContainer />}
                            {activeStep === 1 && <EntitiesContainer />}
                            {activeStep === 2 && <DatesContainer />}
                        </Card>
                    </Typography>
                    <Box sx={{ display: "flex", flexDirection: "row", pt: 2 }}>
                        <Button
                            color="primary"
                            variant="outlined"
                            onClick={() => {
                                handleCancel();
                            }}
                        >
                            Cancel
                        </Button>
                        <Box sx={{ flex: "1 1 auto" }} />
                        {activeStep !== 0 && (
                            <Button color="secondary" variant="outlined" onClick={handleBack} sx={{ mr: 1 }}>
                                Previous
                            </Button>
                        )}
                        {activeStep === steps.length - 1 ? (
                            <Button variant="contained" color="primary" onClick={handleFetchData}>
                                Fetch Data
                            </Button>
                        ) : (
                            <Button variant="contained" color="primary" onClick={() => handleNext(true)}>
                                Next
                            </Button>
                        )}
                    </Box>
                </>
            )}
            <Snackbar open={snackBaropen} autoHideDuration={5000} onClose={handleClose}>
                <Alert variant="filled" onClose={handleClose} severity={messageInfo?.severity} sx={{ width: "100%" }}>
                    {messageInfo?.message}
                </Alert>
            </Snackbar>
            <Backdrop sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading}>
                <p>Please wait while we are fetching data</p>
                <CircularProgress />
            </Backdrop>
            <SaveDialog
                title={`You have unsaved changes`}
                open={confirmOpen}
                setOpen={setConfirmOpen}
                stopPropagation={true}
                onConfirm={(e) => {
                    e?.stopPropagation();
                    handleNext(false);
                    history.push("/dal/webui");
                }}
                onDiscard={(e) => {
                    e?.stopPropagation();
                    resetData();
                    history.push("/dal/webui");
                }}
            >
                There are unsaved changes. You can save your changes, cancel to continue editing, or leave and discard
                changes
            </SaveDialog>
        </Box>
    );
}
