import React, { useState, useContext } from "react";
import { Autocomplete, TextField, Typography, CardContent, Snackbar, Alert } from "@mui/material";
import { orderBy } from "lodash";
import { BuildJsonContext } from "../contexts/BuildJsonContext";

const AddFieldComponent = ({ setSearchFieldValue, searchFieldValue, tableComponent, nestedField }) => {
    const [snackbarOpen, setSnackbarOpen] = useState<any>({ message: "", severity: "", open: false });
    const {
        manageFieldsScreenJson,
        combinedFieldsData: {
            fields: { splitedfieldsArr },
        },
        dalApiFieldsList,
    } = useContext(BuildJsonContext);

    const handleCloseSnackBar = (event: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === "clickaway") {
            return;
        }
        setSnackbarOpen({ message: "", severity: "", open: false });
    };
    const handleAddField = (addField) => {
        const isPresent = splitedfieldsArr.some((item) => item.id === addField.id && item.isNested === nestedField);
        if (!isPresent) {
            manageFieldsScreenJson?.({ type: "addFields", payload: { ...addField, isNested: nestedField } });
            setSearchFieldValue({ id: "", label: "" });
        } else {
            setSnackbarOpen({ message: `Field Already Added`, severity: "error", open: true });
            setSearchFieldValue({ id: "", label: "" });
        }
    };
    return (
        <CardContent>
            <div style={{ display: "flex", justifyContent: "flex-start", gap: "20px" }}>
                <Typography sx={{ color: "#000", fontSize: "15px", display: "flex", alignItems: "center" }}>
                    Fields
                </Typography>
                <Autocomplete
                    id="autocomplete"
                    sx={{
                        "& .MuiInputLabel-root": {
                            top: "-7px",
                        },
                        "& .MuiInputBase-root.MuiOutlinedInput-root": {
                            padding: "0px",
                        },
                    }}
                    className="dalSearchInput"
                    autoHighlight={true}
                    options={orderBy([...dalApiFieldsList.dal.obj, ...dalApiFieldsList.em.emObj], ["id"], ["asc"])}
                    onChange={(_, v) => {
                        setSearchFieldValue(v);
                        handleAddField(v);
                    }}
                    value={searchFieldValue}
                    disableClearable
                    renderInput={(params) => (
                        <TextField sx={{ "& fieldset": { border: "none" } }} {...params} label="Add Field" />
                    )}
                />
                <Snackbar open={snackbarOpen.open} autoHideDuration={100000} onClose={handleCloseSnackBar}>
                    <Alert
                        variant="filled"
                        onClose={handleCloseSnackBar}
                        severity={snackbarOpen.severity}
                        sx={{ width: "100%" }}
                    >
                        {snackbarOpen.message}
                    </Alert>
                </Snackbar>
            </div>
            {tableComponent}
        </CardContent>
    );
};

export default AddFieldComponent;
