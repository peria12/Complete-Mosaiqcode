import React, { useEffect, useState, useContext } from "react";
import { useHistory, Switch, Route, useRouteMatch } from "react-router-dom";
import { useScreenshot } from "utils/helpers";
import { Container, Button, Backdrop, Box, CircularProgress, Snackbar, Alert } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import Wizard from "./Wizard";
import Api from "utils/api";
import { isJsonString, handleExcelFetch, getFieldItem } from "../utils/common";

import { BuildJsonContext } from "../contexts/BuildJsonContext";

declare global {
    interface Window {
        chrome: {
            webview: {
                postMessage: (message: any) => void;
                addEventListener: (message: any, event: any) => any;
            };
        };
    }
}
export default function DALFields() {
    const {
        push,
        location: { pathname },
    } = useHistory();
    const screenshot = useScreenshot();

    const isFromExcel = window.navigator.userAgent.toLowerCase().includes("dalplugin");

    const { path } = useRouteMatch();

    const [loading, setLoading] = useState<boolean>(false);
    const [inputText, setInputText] = useState<any>("");
    const [snackBaropen, setSnackBaropen] = useState<boolean>(false);
    const [messageInfo, setMessageInfo] = useState<any>();
    const {
        buildJsonValue,
        setBuildJsonValue,
        isFromDalPlugin,
        setIsFromDalPlugin,
        setDalApiFieldsList,
        manageFieldsScreenJson,
        manageEntityScreenJson,
        manageDatesScreenJson,
    } = useContext(BuildJsonContext);
    const textArea = {
        "& textarea": {
            boxSizing: "border-box",
            width: "100%",
            margin: "20px 0px",
            padding: "10px",
            fontSize: "16px",
            background: "#FFFFFF 0% 0% no-repeat padding-box",
            boxShadow: "0.45px 2px 10px #7777771A",
            border: "1px solid #000",
            borderRadius: "6px",
            outline: "none",
            resize: "none",
        },
    };
    useEffect(() => {
        const savedDalRequest = localStorage.getItem("savedDalRequest");
        if (savedDalRequest) {
            setInputText(JSON.parse(savedDalRequest));
            setBuildJsonValue?.(JSON.parse(savedDalRequest));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    useEffect(() => {
        Api.getDALFields()
            .then((data) => {
                const arr = Object.keys(data.dal).sort();
                const emArr = Object.keys(data.em).sort();
                const obj = arr.map((item) => {
                    return { id: item, label: item };
                });
                const emObj = emArr.map((item) => {
                    return { id: item, label: item };
                });
                setDalApiFieldsList?.({ dal: { arr, obj }, em: { emArr, emObj } });
            })
            .catch((e) => {
                console.log(e);
            })
            .finally(() => {
                screenshot.take();
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    useEffect(() => {
        if (isFromExcel) {
            setIsFromDalPlugin?.(true);
            const Header = document.querySelector("#title-bar")?.classList as DOMTokenList;
            Header.add("hideHeader");
            const AppNav = document.querySelector(".app-top-nav")?.classList as DOMTokenList;
            AppNav.add("hideAppNav");
        }
    }, [isFromExcel, setIsFromDalPlugin]);

    useEffect(() => {
        setInputText(JSON.stringify(buildJsonValue, null, 4));
    }, [buildJsonValue]);

    const handleOnChange = (e) => {
        setInputText(e.target.value);
    };
    const handleClose = (event: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === "clickaway") {
            return;
        }
        setSnackBaropen(false);
    };

    const handleClearInput = () => {
        setInputText("{}");
        manageFieldsScreenJson?.({ type: "resetFieldsData" });
        manageEntityScreenJson?.({ type: "resetEntityData" });
        manageDatesScreenJson?.({ type: "resetDatesData" });
        localStorage.removeItem("savedDalRequest");
    };

    const handleWizardClick = () => {
        if (isJsonString(inputText)) {
            const parsedVal = JSON.parse(inputText);
            setBuildJsonValue?.(parsedVal);
            const res = getFieldItem(parsedVal?.fields || []);
            manageFieldsScreenJson?.({ type: "updateSplitedFieldJson", payload: { fields: res } });
            manageEntityScreenJson?.({
                type: "updateCombinedEntitiesJson",
                payload: {
                    entities: parsedVal?.entities || [],
                    id_type: parsedVal?.id_type || "",
                    id_date: parsedVal?.id_date || "",
                },
            });
            manageDatesScreenJson?.({
                type: "updateCombinedDatesJson",
                payload: { dates: parsedVal?.dates || [], date_info: parsedVal?.date_info || {} },
            });
            setSnackBaropen(false);
            push(`${path}/wizard`);
        } else {
            setSnackBaropen(true);
            setMessageInfo({ message: "Json is invalid please provide valid Json", severity: "error" });
        }
    };

    const fetchData = () => {
        if (isJsonString(inputText)) {
            setLoading(true);
            localStorage.setItem("savedDalRequest", inputText);
            const payload = Object.assign(JSON.parse(inputText), { result_format: "excel" });
            Api.dal(payload, false)
                .then((res) => {
                    if (res.error !== "") {
                        setSnackBaropen(true);
                        setMessageInfo({ message: `Error From API: ${res.error}`, severity: "error" });
                    } else {
                        if (res.fields?.excel_file_info?.url) {
                            if (isFromDalPlugin) {
                                handleExcelFetch(res.fields.excel_file_info.url);
                            } else {
                                location.href = res.fields.excel_file_info.url;
                                setSnackBaropen(true);
                                setMessageInfo({ message: "File Downloaded Successfully", severity: "success" });
                            }
                        } else {
                            setSnackBaropen(true);
                            setMessageInfo({ message: "No Records Found", severity: "error" });
                        }
                    }
                    setLoading(false);
                })
                .catch((err) => {
                    console.log(err);
                    setLoading(false);
                });
        } else {
            setSnackBaropen(true);
            setMessageInfo({ message: "Json is invalid please provide valid Json", severity: "error" });
        }
    };

    return (
        <>
            {pathname === "/dal/webui" && (
                <Container maxWidth="lg" style={{ marginTop: 60 }}>
                    <div className="d-flex justify-content-end">
                        <Button color="error" variant="outlined" startIcon={<DeleteIcon />} onClick={handleClearInput}>
                            Clear
                        </Button>
                    </div>
                    <Box sx={textArea}>
                        <textarea rows={14} value={inputText} onChange={handleOnChange} />
                    </Box>
                    <Snackbar open={snackBaropen} autoHideDuration={5000} onClose={handleClose}>
                        <Alert
                            variant="filled"
                            onClose={handleClose}
                            severity={messageInfo?.severity}
                            sx={{ width: "100%" }}
                        >
                            {messageInfo?.message}
                        </Alert>
                    </Snackbar>
                    <div className="d-flex justify-content-between">
                        <div>
                            {isFromDalPlugin && (
                                <Button
                                    color="secondary"
                                    variant="outlined"
                                    className="closebtn"
                                    onClick={() => {
                                        window.chrome.webview.postMessage("CancelButtonClicked");
                                    }}
                                >
                                    Close
                                </Button>
                            )}
                        </div>
                        <div className={"d-flex flex-row"}>
                            <Button
                                color="primary"
                                variant="contained"
                                style={{ marginRight: 15 }}
                                onClick={handleWizardClick}
                            >
                                Wizard
                            </Button>
                            <div>
                                <Button color="secondary" variant="outlined" onClick={fetchData}>
                                    Fetch Data
                                </Button>
                                <Backdrop
                                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                                    open={loading}
                                >
                                    <p>Please wait while we are fetching data</p>
                                    <CircularProgress />
                                </Backdrop>
                            </div>
                        </div>
                    </div>
                </Container>
            )}
            <Switch>
                <Route path={`${path}/Wizard`} component={Wizard} />
            </Switch>
        </>
    );
}
