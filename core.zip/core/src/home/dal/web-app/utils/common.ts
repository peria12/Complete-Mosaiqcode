export function isJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

export function isValid_Date(str) {
    const regex =
        /^([0-9]{4})-((01|02|03|04|05|06|07|08|09|10|11|12|(?:J(anuary|u(ne|ly))|February|Ma(rch|y)|A(pril|ugust)|(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)|(JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)|(September|October|November|December)|(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)|(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)))|(january|february|march|april|may|june|july|august|september|october|november|december))-([0-3][0-9])$/;
    if (str == null) {
        return false;
    }
    if (regex.test(str) === true) {
        return true;
    }
    return false;
}
export function handleExcelFetch(respURL) {
    window.chrome.webview.postMessage(
        JSON.stringify({
            message: "ExcelFileLoaded",
            data: respURL,
            calledfrom: "fetchdata",
        })
    );
}

export function getFieldItem(fieldsArrObj) {
    const splitedfieldsArr: any = [];
    const splitedSubFieldsArr: any = [];
    const splitedFiltersArr: any = [];
    const splitedOthersArr: any = [];
    fieldsArrObj.forEach((item) => {
        if (typeof item === "string") {
            splitedfieldsArr.push({
                id: item,
                label: item,
                isNested: null,
                fieldsValue: "",
            });
        } else {
            const fieldkey = Object.entries(item);
            splitedfieldsArr.push({
                id: fieldkey[0][0],
                label: fieldkey[0][0],
                isNested: null,
                fieldsValue: JSON.stringify(fieldkey[0][1]),
            });
            splitFieldItems(
                item,
                fieldkey[0][0],
                null,
                splitedfieldsArr,
                splitedSubFieldsArr,
                splitedFiltersArr,
                splitedOthersArr
            );
        }
    });
    return { splitedfieldsArr, splitedSubFieldsArr, splitedFiltersArr, splitedOthersArr };
}

function splitFieldItems(
    fieldObj,
    fieldName,
    nestedKey,
    splitedfieldsArr,
    splitedSubFieldsArr,
    splitedFiltersArr,
    splitedOthersArr
) {
    for (const fieldObjKey in fieldObj) {
        for (const fieldObjVal in fieldObj[fieldObjKey]) {
            if (fieldObjVal === "sub_fields") {
                const subFieldVal = fieldObj[fieldObjKey][fieldObjVal];
                subFieldVal.forEach((item) => {
                    if (typeof item === "string") {
                        splitedSubFieldsArr.push({
                            fieldName,
                            subFieldName: "sub_fields",
                            nestedKey,
                            subFieldValue: item,
                        });
                    } else {
                        const nestedKey = Object.entries(item);
                        splitedfieldsArr.push({
                            id: nestedKey[0][0],
                            label: nestedKey[0][0],
                            isNested: fieldName,
                            fieldsValue: JSON.stringify(nestedKey[0][1]),
                        });
                        splitedSubFieldsArr.push({
                            fieldName,
                            subFieldName: "sub_fields",
                            nestedKey: null,
                            subFieldValue: nestedKey[0][0],
                            isNested: true,
                            nestedValue: JSON.stringify(nestedKey[0][1]),
                        });
                        splitFieldItems(
                            item,
                            fieldName,
                            nestedKey[0][0],
                            splitedfieldsArr,
                            splitedSubFieldsArr,
                            splitedFiltersArr,
                            splitedOthersArr
                        );
                    }
                });
            }
            if (fieldObjVal === "filters") {
                const filterVal = fieldObj[fieldObjKey][fieldObjVal];
                splitedFiltersArr.push({
                    fieldName,
                    subFieldName: "filters",
                    nestedKey,
                    subFieldValue: filterVal,
                });
            }
            if (fieldObjVal !== "sub_fields" && fieldObjVal !== "filters") {
                const othersVal = fieldObj[fieldObjKey][fieldObjVal];
                splitedOthersArr.push({
                    fieldName,
                    subFieldName: fieldObjVal,
                    nestedKey,
                    subFieldValue: othersVal,
                });
            }
        }
    }
}

export function mergeFieldJson(splitedfieldsArr, splitedSubFieldsArr, splitedFiltersArr, splitedOthersArr) {
    const newObj: any = [];
    let index = -1;
    for (const [idx, fieldObj] of splitedfieldsArr.entries()) {
        const fieldName = fieldObj.label;
        if (!fieldObj.isNested) {
            newObj.push({ [fieldName]: {} });
            index++;
        }
        if (newObj[index]) {
            for (const item of [...splitedSubFieldsArr, ...splitedFiltersArr, ...splitedOthersArr]) {
                const subFieldName = item.subFieldName;
                if (fieldName == item.fieldName) {
                    if (!item.nestedKey && !item.isNested) {
                        if (subFieldName === "sub_fields") {
                            if (!newObj[index][fieldName][subFieldName]) {
                                newObj[index][fieldName] = { [item.subFieldName]: [] };
                            }
                            newObj[index][fieldName][subFieldName].push(item.subFieldValue);
                        }
                        if (subFieldName === "filters") {
                            Object.assign(newObj[index][fieldName], {
                                filters: item.subFieldValue,
                            });
                        }
                        if (subFieldName !== "sub_fields" && subFieldName !== "filters") {
                            Object.assign(newObj[index][fieldName], {
                                [item.subFieldName]: item.subFieldValue,
                            });
                        }
                    }
                    if (item.nestedKey) {
                        if (subFieldName !== "sub_fields" && subFieldName !== "filters") {
                            const findnest = newObj[index][fieldName]["sub_fields"].find((itm) => {
                                return itm[item.nestedKey];
                            });
                            Object.assign(findnest[item.nestedKey], {
                                [item.subFieldName]: item.subFieldValue,
                            });
                        }
                        if (subFieldName === "sub_fields") {
                            const isNestedAdded = newObj[index][fieldName][subFieldName].find((is) => {
                                return is[item.nestedKey];
                            });
                            if (!isNestedAdded) {
                                newObj[index][fieldName][subFieldName].push({
                                    [item.nestedKey]: { sub_fields: [] },
                                });
                                const findnest = newObj[index][fieldName][subFieldName].find((itm) => {
                                    return itm[item.nestedKey];
                                });
                                findnest[item.nestedKey][subFieldName].push(item.subFieldValue);
                            }
                            if (isNestedAdded) {
                                isNestedAdded[item.nestedKey][subFieldName].push(item.subFieldValue);
                            }
                        }
                        if (subFieldName === "filters") {
                            const findnest = newObj[index][fieldName]["sub_fields"].find((itm) => {
                                return itm[item.nestedKey];
                            });
                            Object.assign(findnest[item.nestedKey], {
                                filters: item.subFieldValue,
                            });
                        }
                    }
                }
            }
        }
        if (JSON.stringify(newObj[index][fieldName]) == "{}") {
            newObj[index] = fieldName;
        }
        if (!fieldObj.isNested) {
            splitedfieldsArr[idx].fieldsValue = JSON.stringify(newObj[index][fieldName]);
        } else {
            const findnest = newObj[index][fieldObj.isNested]["sub_fields"].find((itm) => {
                return itm[fieldObj.id];
            });
            splitedfieldsArr[idx].fieldsValue = JSON.stringify(findnest[fieldObj.id]);
        }
    }
    return newObj;
}
