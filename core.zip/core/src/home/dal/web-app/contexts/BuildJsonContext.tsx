import React, { createContext, useState, useMemo } from "react";
import _ from "lodash";

export interface BuildJsonComponentContext {
    buildJsonValue?: any;
    setBuildJsonValue?: (buildJsonValue: any) => void;

    isFromDalPlugin?: boolean;
    setIsFromDalPlugin?: (name: boolean) => void;

    dalApiFieldsList?: any;
    setDalApiFieldsList?: (dalApiFieldsList: any) => void;

    manageFieldsScreenJson?: ((action: any) => void | undefined) | undefined;

    combinedFieldsData?: any;
    setCombinedFieldsData?: (combinedFieldsData: any) => void;

    savedFieldsData?: any;
    setSavedFieldsData?: (savedFieldsData: any) => void;

    manageEntityScreenJson?: ((action: any) => void | undefined) | undefined;

    combinedEntitiesData?: any;
    setCombinedEntitiesData?: (combinedEntitiesData: any) => void;

    savedEntityData?: any;
    setSavedEntityData?: (savedEntityData: any) => void;

    manageDatesScreenJson?: ((action: any) => void | undefined) | undefined;

    combinedDatesData?: any;
    setCombinedDatesData?: (combinedDatesData: any) => void;

    savedDatesData?: any;
    setSavedDatesData?: (savedDatesData: any) => void;
}
const initialContext = {
    buildJsonValue: {},
    isFromDalPlugin: false,
    combinedFieldsData: {
        fields: { splitedfieldsArr: [], splitedSubFieldsArr: [], splitedFiltersArr: [], splitedOthersArr: [] },
    },
    savedFieldsData: {
        fields: { splitedfieldsArr: [], splitedSubFieldsArr: [], splitedFiltersArr: [], splitedOthersArr: [] },
    },
    combinedEntitiesData: { entities: [], id_type: "", id_date: "" },
    savedEntityData: [],
    combinedDatesData: { dates: [], date_info: {} },
    savedDatesData: [],
    dalApiFieldsList: { dal: { arr: [], obj: [] }, em: { emArr: [], emObj: [] } },
};
export const BuildJsonContext = createContext<BuildJsonComponentContext>(initialContext);

export const BuildJsonContextProvider = (props: any) => {
    const [buildJsonValue, setBuildJsonValue] = useState<any>(props.buildJsonValue || initialContext.buildJsonValue);

    const [isFromDalPlugin, setIsFromDalPlugin] = useState<boolean>(
        props.isFromDalPlugin || initialContext.isFromDalPlugin
    );

    const [combinedFieldsData, setCombinedFieldsData] = useState<any>(
        props.combinedFieldsData || initialContext.combinedFieldsData
    );

    const [savedFieldsData, setSavedFieldsData] = useState<any>(
        props.savedFieldsData || initialContext.savedFieldsData
    );

    const [savedEntityData, setSavedEntityData] = useState<any>(
        props.savedEntityData || initialContext.savedEntityData
    );

    const [dalApiFieldsList, setDalApiFieldsList] = useState<any>(
        props.dalApiFieldsList || initialContext.dalApiFieldsList
    );

    const [combinedEntitiesData, setCombinedEntitiesData] = useState<any>(
        props.combinedEntitiesData || initialContext.combinedEntitiesData
    );

    const [combinedDatesData, setCombinedDatesData] = useState<any>(
        props.combinedDatesData || initialContext.combinedDatesData
    );

    const [savedDatesData, setSavedDatesData] = useState<any>(props.savedDatesData || initialContext.savedDatesData);

    const manageEntityScreenJson = (action) => {
        if (action.type === "addSearchEntity") {
            if (Array.isArray(action.payload)) {
                setCombinedEntitiesData((prev) => ({
                    ...prev,
                    entities: [...prev.entities, ...action.payload],
                }));
            } else {
                setCombinedEntitiesData((prev) => ({
                    ...prev,
                    entities: [...prev.entities, action.payload],
                }));
            }
        }
        if (action.type === "saveEntityData") {
            setSavedEntityData(action.payload);
        }
        if (action.type === "resetEntityData") {
            setCombinedEntitiesData({ entities: [], id_type: "", id_date: "" });
        }
        if (action.type === "updateSearchEntity") {
            setCombinedEntitiesData(action.payload);
        }
        if (action.type === "removeSearchEntity") {
            setCombinedEntitiesData((prev) => ({
                ...prev,
                entities: prev.entities.filter((entity) => {
                    return entity !== action.payload;
                }),
            }));
        }
        if (action.type === "removeKeyValuePairs") {
            setCombinedEntitiesData((prev) => ({
                ...prev,
                entities: prev.entities.filter((item) => {
                    let keep = true;
                    if (typeof item === "object") {
                        const val = Object.entries(item);
                        keep = val[0][0] != action.payload.key || val[0][1] != JSON.parse(action.payload.value);
                    }
                    return keep;
                }),
            }));
        }
        if (action.type === "addSelectedIDDate") {
            setCombinedEntitiesData((prev) => {
                return { ...prev, id_date: action.payload };
            });
        }
        if (action.type === "updateCombinedEntitiesJson") {
            setCombinedEntitiesData(action.payload);
            setSavedEntityData(action.payload);
        }
        if (action.type === "updateEntitiesJson") {
            setBuildJsonValue((current) => {
                return { ...current, entities: action.payload };
            });
        }
        if (action.type === "updateIDDateJson") {
            setBuildJsonValue((current) => {
                return { ...current, id_date: action.payload };
            });
        }
        if (action.type === "updateIDTypeJson") {
            setBuildJsonValue((current) => {
                return { ...current, id_type: action.payload };
            });
        }
    };
    const manageFieldsScreenJson = (action) => {
        if (action.type === "addFields") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedfieldsArr: [...prev.fields.splitedfieldsArr, action.payload],
                },
            }));
        }
        if (action.type === "updateSplitedFieldJson") {
            setCombinedFieldsData((current) => {
                return { ...current, ...action.payload };
            });
            setSavedFieldsData((current) => {
                return { ...current, ...action.payload };
            });
        }
        if (action.type === "removeField") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedfieldsArr: _.reject(prev.fields.splitedfieldsArr, {
                        id: action.payload.id,
                        isNested: action.payload.isNested,
                    }),
                },
            }));
        }
        if (action.type === "saveFieldsData") {
            setSavedFieldsData(action.payload);
        }
        if (action.type === "updateFieldsData") {
            setCombinedFieldsData(action.payload);
        }
        if (action.type === "resetFieldsData") {
            setCombinedFieldsData({
                fields: { splitedfieldsArr: [], splitedSubFieldsArr: [], splitedFiltersArr: [], splitedOthersArr: [] },
            });
        }
        if (action.type === "resetSubFieldsData") {
            setCombinedFieldsData(action.payload);
        }
        if (action.type === "addSubField") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedSubFieldsArr: [...prev.fields.splitedSubFieldsArr, action.payload],
                },
            }));
        }
        if (action.type === "updateNestedSubField") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedSubFieldsArr: action.payload,
                },
            }));
        }
        if (action.type === "removeSubField") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedSubFieldsArr: _.reject(prev.fields.splitedSubFieldsArr, {
                        subFieldValue: action.payload.subFieldValue,
                        nestedKey: action.payload.nestedKey,
                    }),
                },
            }));
        }
        if (action.type === "addFilters") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedFiltersArr: [...prev.fields.splitedFiltersArr, action.payload],
                },
            }));
        }
        if (action.type === "addorRemoveFiltersIds") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedFiltersArr: action.payload,
                },
            }));
        }
        if (action.type === "addOthers") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedOthersArr: [...prev.fields.splitedOthersArr, action.payload],
                },
            }));
        }
        if (action.type === "removeOthers") {
            setCombinedFieldsData((prev) => ({
                ...prev,
                fields: {
                    ...prev.fields,
                    splitedOthersArr: _.reject(prev.fields.splitedOthersArr, {
                        subFieldName: action.payload.id,
                        nestedKey: action.payload.nestedKey,
                        fieldName: action.payload.selectedField,
                    }),
                },
            }));
        }
        if (action.type === "updateFieldsJson") {
            setBuildJsonValue((current) => {
                return { ...current, fields: action.payload };
            });
        }
    };
    const manageDatesScreenJson = (action) => {
        if (action.type === "addSelectedDate") {
            if (Array.isArray(action.payload)) {
                setCombinedDatesData((prev) => ({
                    ...prev,
                    dates: [...prev.dates, ...action.payload],
                }));
            } else {
                setCombinedDatesData((prev) => ({
                    ...prev,
                    dates: [...prev.dates, action.payload],
                }));
            }
        }
        if (action.type === "removeSelectedDate") {
            setCombinedDatesData((prev) => ({
                ...prev,
                dates: prev.dates.filter((date) => {
                    return date !== action.payload;
                }),
            }));
        }
        if (action.type === "saveDatesData") {
            setSavedDatesData(action.payload);
        }
        if (action.type === "updateDatesData") {
            setCombinedDatesData(action.payload);
        }
        if (action.type === "resetDatesData") {
            setCombinedDatesData({ dates: [], date_info: {} });
        }
        if (action.type === "addSelectedDatesTypes") {
            setCombinedDatesData?.((prev) => {
                return { ...prev, date_info: { ...prev.date_info, type: action.payload } };
            });
        }
        if (action.type === "updateDatesJson") {
            setBuildJsonValue((current) => {
                return { ...current, dates: action.payload };
            });
        }
        if (action.type === "updateDatesInfoJson") {
            setBuildJsonValue((current) => {
                return { ...current, date_info: action.payload };
            });
        }
        if (action.type === "updateCombinedDatesJson") {
            setCombinedDatesData(action.payload);
            setSavedDatesData(action.payload);
        }
    };
    const providerValue = useMemo(
        () => ({
            buildJsonValue,
            setBuildJsonValue,
            isFromDalPlugin,
            setIsFromDalPlugin,
            setDalApiFieldsList,
            combinedFieldsData,
            setCombinedFieldsData,
            savedEntityData,
            dalApiFieldsList,
            combinedEntitiesData,
            manageEntityScreenJson,
            savedFieldsData,
            manageFieldsScreenJson,
            combinedDatesData,
            savedDatesData,
            manageDatesScreenJson,
            setCombinedEntitiesData,
            setCombinedDatesData,
        }),
        [
            buildJsonValue,
            isFromDalPlugin,
            dalApiFieldsList,
            combinedFieldsData,
            savedEntityData,
            combinedEntitiesData,
            savedFieldsData,
            combinedDatesData,
            savedDatesData,
        ]
    );

    return <BuildJsonContext.Provider value={providerValue}>{props.children}</BuildJsonContext.Provider>;
};
