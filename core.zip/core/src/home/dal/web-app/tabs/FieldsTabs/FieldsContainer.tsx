import React, { useState, useContext, useRef } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { IconButton, Dialog, DialogContent, DialogTitle, Snackbar, Alert } from "@mui/material";
import AddFieldComponent from "../../components/AddFieldComponent";
import TableComponent from "../../components/TableComponent";
import ParametersContainer from "../ParameterTabs/ParametersContainer";
import ConfirmDialog from "../../../../../common/ConfirmDialog";
import { BuildJsonContext } from "../../contexts/BuildJsonContext";

const FieldsContainer = () => {
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
    const [snackBaropen, setSnackBaropen] = useState<boolean>(false);
    const [searchFieldValue, setSearchFieldValue] = useState<any>({ id: "", label: "" });
    const [messageInfo, setMessageInfo] = useState<any>();
    const [selectedField, setSelectedField] = useState<string>("");
    const [deleteField, setDeleteField] = useState<any>({});
    const gridRef = useRef<any>(null);
    const {
        manageFieldsScreenJson,
        combinedFieldsData: {
            fields: { splitedfieldsArr },
        },
        dalApiFieldsList,
    } = useContext(BuildJsonContext);

    const handleSubFieldModal = () => {
        setIsOpen(false);
    };
    const handleClose = (event: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === "clickaway") {
            return;
        }
        setSnackBaropen(false);
    };
    function deleteRecord() {
        manageFieldsScreenJson?.({ type: "removeField", payload: deleteField });
        setSnackBaropen(true);
        setMessageInfo({ message: `Field Deleted`, severity: "error" });
    }
    function handleActions(params) {
        const isPresent = dalApiFieldsList.em.emArr.includes(params.data.id);
        return (
            <>
                <IconButton sx={{ padding: "0" }} disabled={isPresent}>
                    <EditIcon
                        sx={{ margin: "0 10px", color: isPresent ? "#ccc" : "#000" }}
                        onClick={() => {
                            setSelectedField(params.data.id);
                            setIsOpen(true);
                            setSnackBaropen(false);
                        }}
                    />
                </IconButton>
                <IconButton sx={{ padding: "0" }}>
                    <DeleteIcon
                        sx={{ color: "#000" }}
                        onClick={() => {
                            setDeleteField(params.data);
                            setConfirmOpen(true);
                        }}
                    />
                </IconButton>
            </>
        );
    }

    const columns = [
        { field: "id", headerName: "Fields", maxWidth: 300 },
        {
            field: "fieldsValue",
            headerName: "Parameters",
            tooltipField: "fieldsValue",
        },
        {
            field: "actions",
            headerName: "Actions",
            maxWidth: 150,
            cellRenderer: handleActions,
        },
    ];
    return (
        <>
            <AddFieldComponent
                setSearchFieldValue={setSearchFieldValue}
                searchFieldValue={searchFieldValue}
                nestedField={null}
                tableComponent={
                    <TableComponent
                        gridRef={gridRef}
                        rowData={splitedfieldsArr.filter((item) => item.isNested == null)}
                        columnData={columns}
                        onCellClicked={null}
                    />
                }
            />
            <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="dal-web fields-pop-up">
                <DialogTitle>Parameter for {selectedField}</DialogTitle>
                <DialogContent>
                    <ParametersContainer
                        selectedField={selectedField}
                        handleSubFieldModal={handleSubFieldModal}
                        selectedNestedField={null}
                    />
                </DialogContent>
            </Dialog>
            <Snackbar open={snackBaropen} autoHideDuration={100000} onClose={handleClose}>
                <Alert variant="filled" onClose={handleClose} severity={messageInfo?.severity} sx={{ width: "100%" }}>
                    {messageInfo?.message}
                </Alert>
            </Snackbar>
            <ConfirmDialog
                title={`Delete?`}
                open={confirmOpen}
                setOpen={setConfirmOpen}
                stopPropagation={true}
                onConfirm={(e) => {
                    e?.stopPropagation();
                    deleteRecord();
                }}
            >
                Are you sure you want to delete this <b>{deleteField.id}</b>?
            </ConfirmDialog>
        </>
    );
};

export default FieldsContainer;
