import React, { useState, useContext, useEffect } from "react";
import { Typography, TextField } from "@mui/material";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { BuildJsonContext } from "../../contexts/BuildJsonContext";

const IDDateComponent = () => {
    const { manageEntityScreenJson } = useContext(BuildJsonContext);
    const [selectedDate, setSelectedDate] = useState<any>(null);
    useEffect(() => {
        const dateHandler = () => {
            if (JSON.stringify(selectedDate) != "null") {
                const formatDate = new Date(selectedDate.getTime() - selectedDate.getTimezoneOffset() * 60000)
                    .toISOString()
                    .slice(0, 10);
                console.log(formatDate, "formatDate");
                manageEntityScreenJson?.({ type: "addSelectedIDDate", payload: formatDate });
            }
        };
        dateHandler();
    }, [selectedDate]);
    return (
        <>
            <Typography>ID Date</Typography>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                    disableFuture
                    inputFormat="yyyy-MM-dd"
                    value={selectedDate}
                    onChange={(newDateValue) => {
                        setSelectedDate(newDateValue);
                    }}
                    InputProps={{
                        sx: {
                            "&.MuiInputBase-root": {
                                "& .MuiOutlinedInput-input": {
                                    padding: "9px",
                                },
                                "& .MuiOutlinedInput-notchedOutline": {
                                    borderColor: "#767676",
                                },
                            },
                        },
                    }}
                    renderInput={(params) => (
                        <TextField sx={{ "& legend": { display: "none" }, "& fieldset": { top: 0 } }} {...params} />
                    )}
                />
            </LocalizationProvider>
        </>
    );
};
export default IDDateComponent;
