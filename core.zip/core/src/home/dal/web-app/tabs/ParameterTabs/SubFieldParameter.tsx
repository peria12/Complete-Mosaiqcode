import React, { useState, useRef, useContext } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import {
    Dialog,
    DialogContent,
    DialogTitle,
    IconButton,
    Autocomplete,
    TextField,
    Typography,
    Snackbar,
    Alert,
} from "@mui/material";

import { BuildJsonContext } from "../../contexts/BuildJsonContext";
import TableComponent from "../../components/TableComponent";
import ConfirmDialog from "../../../../../common/ConfirmDialog";
import ParametersContainer from "../ParameterTabs/ParametersContainer";

const inlineFormStyles = {
    display: "flex",
    gap: "8px",
};

const SubFieldParameter = ({ selectedField, selectedNestedField }) => {
    const [subField, setSubField] = useState<any>("");
    const [inputValue, setInputValue] = useState<any>("");
    const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [nestedField, setNestedField] = useState<any>(null);
    const [snackbarOpen, setSnackbarOpen] = React.useState<any>({ message: "", severity: "", open: false });
    const [deleteSubField, setDeleteSubField] = useState<any>({});
    const gridRef = useRef<any>(null);
    const {
        manageFieldsScreenJson,
        combinedFieldsData: {
            fields: { splitedSubFieldsArr },
        },
        dalApiFieldsList,
    } = useContext(BuildJsonContext);
    const nestedKey = selectedNestedField || null;
    function handleActions(params) {
        const isPresent = dalApiFieldsList.em.emArr.includes(params.data.subFieldValue);
        return (
            <>
                {!selectedNestedField && (
                    <IconButton sx={{ padding: "0" }} disabled={isPresent}>
                        <EditIcon
                            sx={{ margin: "0 10px", color: isPresent ? "#ccc" : "#000" }}
                            onClick={() => {
                                setNestedField(params.data.subFieldValue);
                                setIsOpen(true);
                            }}
                        />
                    </IconButton>
                )}
                <IconButton sx={{ padding: "0" }}>
                    <DeleteIcon
                        sx={{ color: "#000" }}
                        onClick={() => {
                            setSubField(params.data.id);
                            setConfirmOpen(true);
                            setDeleteSubField(params.data);
                        }}
                    />
                </IconButton>
            </>
        );
    }

    const columns = [
        { field: "subFieldValue", headerName: "Subfield", maxWidth: 300 },
        {
            field: "nestedValue",
            headerName: "Parameters",
            tooltipField: "nestedValue",
        },
        {
            field: "actions",
            headerName: "Actions",
            maxWidth: 150,
            cellRenderer: handleActions,
        },
    ];
    const handleSubfield = (subFieldVal) => {
        if (subFieldVal != null && subFieldVal != "") {
            const isPresent = splitedSubFieldsArr.some((item) => item.subFieldValue === subFieldVal);
            if (!isPresent) {
                manageFieldsScreenJson?.({
                    type: "addSubField",
                    payload: {
                        fieldName: selectedField,
                        subFieldName: "sub_fields",
                        nestedKey,
                        subFieldValue: subFieldVal,
                    },
                });
            } else {
                setSnackbarOpen({ message: `Sub Field Already Exists`, severity: "error", open: true });
            }
        }
        setSubField("");
        setInputValue("");
    };
    const handleClose = (event: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === "clickaway") {
            return;
        }
        setSnackbarOpen({ message: "", severity: "", open: false });
    };
    function deleteRecord() {
        manageFieldsScreenJson?.({ type: "removeSubField", payload: deleteSubField });
        setSnackbarOpen({ message: `Sub Field Deleted`, severity: "error", open: true });
    }
    const handleSubFieldModal = () => {
        setIsOpen(false);
    };
    return (
        <>
            <div style={inlineFormStyles}>
                <Typography sx={{ color: "#000", fontSize: "15px", display: "flex", alignItems: "center" }}>
                    Sub Fields
                </Typography>
                <Autocomplete
                    id="autocomplete"
                    freeSolo
                    sx={{
                        "& .MuiInputLabel-root": {
                            top: "-7px",
                        },
                        "& .MuiInputBase-root.MuiOutlinedInput-root": {
                            padding: "0px",
                        },
                    }}
                    className="dalSearchInput"
                    options={[...dalApiFieldsList.dal.arr, ...dalApiFieldsList.em.emArr].sort()}
                    onChange={(_, v) => {
                        setSubField(v);
                        handleSubfield(v);
                    }}
                    value={subField}
                    inputValue={inputValue}
                    onInputChange={(event, newInputValue) => {
                        setInputValue(newInputValue);
                    }}
                    renderInput={(params) => (
                        <TextField sx={{ "& fieldset": { border: "none" } }} {...params} label="Add Sub Field" />
                    )}
                />
            </div>
            <Snackbar open={snackbarOpen.open} autoHideDuration={100000} onClose={handleClose}>
                <Alert variant="filled" onClose={handleClose} severity={snackbarOpen.severity} sx={{ width: "100%" }}>
                    {snackbarOpen.message}
                </Alert>
            </Snackbar>
            <ConfirmDialog
                title={`Delete?`}
                open={confirmOpen}
                setOpen={setConfirmOpen}
                stopPropagation={true}
                onConfirm={(e) => {
                    e?.stopPropagation();
                    deleteRecord();
                }}
            >
                Are you sure you want to delete the <b>{subField}</b> Sub Field?
            </ConfirmDialog>
            <TableComponent
                gridRef={gridRef}
                rowData={splitedSubFieldsArr.filter(
                    (item) => item.fieldName === selectedField && item.nestedKey === nestedKey
                )}
                columnData={columns}
                onCellClicked={null}
            />
            <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="dal-web fields-pop-up">
                <DialogTitle>Nested Parameters {nestedField} </DialogTitle>
                <DialogContent>
                    <ParametersContainer
                        selectedField={selectedField}
                        handleSubFieldModal={handleSubFieldModal}
                        selectedNestedField={nestedField}
                    />
                </DialogContent>
            </Dialog>
        </>
    );
};

export default SubFieldParameter;
