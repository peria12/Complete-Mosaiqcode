import React, { useState, useRef, useContext } from "react";
import _ from "lodash";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { IconButton, Button, Dialog, DialogContent, DialogTitle, Snackbar, Alert } from "@mui/material";
import AddFieldComponent from "../../components/AddFieldComponent";
import TableComponent from "../../components/TableComponent";
import ParametersContainer from "../ParameterTabs/ParametersContainer";
import ConfirmDialog from "../../../../../common/ConfirmDialog";
import SaveDialog from "../../components/SaveDialog";

import { BuildJsonContext } from "../../contexts/BuildJsonContext";

const NestedSubFieldContainer = ({ handleNestedSubFieldModal, selectedField }) => {
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
    const [saveOpen, setSaveOpen] = useState<boolean>(false);
    const [snackBaropen, setSnackBaropen] = useState<boolean>(false);
    const [searchFieldValue, setSearchFieldValue] = useState<any>({ id: "", label: "" });
    const [messageInfo, setMessageInfo] = useState<any>();
    const [selectedNestedField, setSelectedNestedField] = useState<string>("");
    const [deleteField, setDeleteField] = useState<any>({});
    const gridRef = useRef<any>(null);
    const {
        manageFieldsScreenJson,
        combinedFieldsData,
        savedFieldsData,
        combinedFieldsData: {
            fields: { splitedfieldsArr },
        },
        dalApiFieldsList,
    } = useContext(BuildJsonContext);

    const handleSubFieldModal = () => {
        setIsOpen(false);
    };

    const handleClose = (event: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === "clickaway") {
            return;
        }
        setSnackBaropen(false);
    };
    function deleteRecord() {
        manageFieldsScreenJson?.({ type: "removeField", payload: deleteField });
        setSnackBaropen(true);
        setMessageInfo({ message: `Field ${selectedNestedField} Deleted`, severity: "error" });
    }
    function handleActions(params) {
        const isPresent = dalApiFieldsList.em.emArr.includes(params.data.id);
        return (
            <>
                <IconButton sx={{ padding: "0" }} disabled={isPresent}>
                    <EditIcon
                        sx={{ margin: "0 10px", color: isPresent ? "#ccc" : "#000" }}
                        onClick={() => {
                            setSelectedNestedField(params.data.id);
                            setIsOpen(true);
                            setSnackBaropen(false);
                        }}
                    />
                </IconButton>
                <IconButton sx={{ padding: "0" }}>
                    <DeleteIcon
                        sx={{ color: "#000" }}
                        onClick={() => {
                            setDeleteField(params.data);
                            setConfirmOpen(true);
                        }}
                    />
                </IconButton>
            </>
        );
    }
    const columns = [
        { field: "id", headerName: "Fields", maxWidth: 300 },
        {
            field: "fieldsValue",
            headerName: "Parameters",
            tooltipField: "fieldsValue",
        },
        {
            field: "actions",
            headerName: "Actions",
            maxWidth: 150,
            cellRenderer: handleActions,
        },
    ];
    const saveNestedFieldsData = () => {
        manageFieldsScreenJson?.({ type: "saveFieldsData", payload: combinedFieldsData });
        handleNestedSubFieldModal(false);
    };

    const handleCancel = () => {
        if (_.isEqual(combinedFieldsData, savedFieldsData)) {
            handleNestedSubFieldModal(false);
        } else {
            setSaveOpen(true);
        }
    };
    const resetNestedFieldsData = () => {
        manageFieldsScreenJson?.({ type: "resetFieldsData" });
        manageFieldsScreenJson?.({ type: "updateFieldsData", payload: savedFieldsData });
        handleNestedSubFieldModal(false);
    };
    return (
        <>
            <AddFieldComponent
                setSearchFieldValue={setSearchFieldValue}
                searchFieldValue={searchFieldValue}
                nestedField={selectedField}
                tableComponent={
                    <TableComponent
                        gridRef={gridRef}
                        rowData={splitedfieldsArr.filter((item) => item.isNested == selectedField)}
                        columnData={columns}
                        onCellClicked={null}
                    />
                }
            />
            <div className="flex-container">
                <Button color="primary" variant="outlined" onClick={handleCancel}>
                    Cancel
                </Button>
                <Button variant="contained" color="primary" onClick={saveNestedFieldsData}>
                    Next
                </Button>
            </div>
            <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="dal-web fields-pop-up">
                <DialogTitle>Parameter for {selectedField}</DialogTitle>
                <DialogContent>
                    <ParametersContainer
                        selectedField={selectedField}
                        handleSubFieldModal={handleSubFieldModal}
                        selectedNestedField={selectedNestedField}
                    />
                </DialogContent>
            </Dialog>
            <Snackbar open={snackBaropen} autoHideDuration={100000} onClose={handleClose}>
                <Alert variant="filled" onClose={handleClose} severity={messageInfo?.severity} sx={{ width: "100%" }}>
                    {messageInfo?.message}
                </Alert>
            </Snackbar>
            <ConfirmDialog
                title={`Delete?`}
                open={confirmOpen}
                setOpen={setConfirmOpen}
                stopPropagation={true}
                onConfirm={(e) => {
                    e?.stopPropagation();
                    deleteRecord();
                }}
            >
                Are you sure you want to delete the <b>{deleteField.id}</b> Field?
            </ConfirmDialog>
            <SaveDialog
                title={`You have unsaved changes`}
                open={saveOpen}
                setOpen={setSaveOpen}
                stopPropagation={true}
                onConfirm={(e) => {
                    e?.stopPropagation();
                    saveNestedFieldsData();
                }}
                onDiscard={(e) => {
                    e?.stopPropagation();
                    resetNestedFieldsData();
                }}
            >
                There are unsaved changes. You can save your changes, cancel to continue editing, or leave and discard
                changes
            </SaveDialog>
        </>
    );
};

export default NestedSubFieldContainer;
