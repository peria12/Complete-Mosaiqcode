import React, { useState, useContext } from "react";
import PropTypes from "prop-types";
import _ from "lodash";
import { Button, CardContent, Tabs, Tab, Box, Dialog, DialogContent, DialogTitle } from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import SubFieldParameter from "./SubFieldParameter";
import FiltersParameter from "./FiltersParameter";
import OthersParameters from "./OthersParameters";
import NestedSubFieldContainer from "./NestedSubFieldContainer";
import SaveDialog from "../../components/SaveDialog";
import { mergeFieldJson } from "../../utils/common";
import { BuildJsonContext } from "../../contexts/BuildJsonContext";

function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ padding: "24px 0" }}>
                    <Box>{children}</Box>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        "aria-controls": `simple-tabpanel-${index}`,
    };
}
const steps = ["Sub Field", "Filters", "Others"];
export default function ParametersContainer({
    selectedField,
    handleSubFieldModal,
    selectedNestedField,
}: {
    selectedField: any;
    handleSubFieldModal: any;
    selectedNestedField: any;
}) {
    const [value, setValue] = useState<number>(0);
    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [saveOpen, setSaveOpen] = useState<boolean>(false);

    const {
        manageFieldsScreenJson,
        combinedFieldsData: {
            fields: { splitedfieldsArr, splitedSubFieldsArr, splitedFiltersArr, splitedOthersArr },
        },
        combinedFieldsData,
        savedFieldsData,
    } = useContext(BuildJsonContext);
    const handleChange = (event: any, newValue: number) => {
        setValue(newValue);
    };
    const handleNestedSubFieldModal = () => {
        setIsOpen(false);
    };
    const addNestedSubFieldVal = (req) => {
        let nestedVal: any = "";
        req.find(function (item) {
            if (typeof item != "string") {
                const fields: any = Object.entries(item);
                if (fields[0][0] == selectedField) {
                    fields[0][1].sub_fields.find((item) => {
                        const subfields = Object.entries(item);
                        if (subfields[0][0] == selectedNestedField) {
                            nestedVal = subfields[0][1];
                        }
                    });
                }
            }
        });
        return JSON.stringify(nestedVal);
    };
    const saveParametersTabData = () => {
        manageFieldsScreenJson?.({ type: "saveFieldsData", payload: combinedFieldsData });
        if (splitedfieldsArr.length !== 0) {
            const req = mergeFieldJson(splitedfieldsArr, splitedSubFieldsArr, splitedFiltersArr, splitedOthersArr);
            manageFieldsScreenJson?.({ type: "updateFieldsJson", payload: req });
            if (selectedNestedField != null) {
                const newState = splitedSubFieldsArr.map((item) => {
                    if (
                        item.fieldName === selectedField &&
                        item.nestedKey === null &&
                        item.subFieldValue === selectedNestedField
                    ) {
                        return {
                            ...item,
                            isNested: true,
                            nestedValue: addNestedSubFieldVal(req),
                        };
                    }
                    return item;
                });

                manageFieldsScreenJson?.({ type: "updateNestedSubField", payload: newState });
            }
        }
    };
    const resetParametersTabData = () => {
        manageFieldsScreenJson?.({
            type: "resetSubFieldsData",
            payload: {
                fields: {
                    splitedfieldsArr: splitedfieldsArr,
                    splitedSubFieldsArr: [],
                    splitedFiltersArr: [],
                    splitedOthersArr: [],
                },
            },
        });
        manageFieldsScreenJson?.({
            type: "updateFieldsData",
            payload: Object.assign({
                fields: {
                    ...savedFieldsData.fields,
                    splitedfieldsArr: splitedfieldsArr,
                },
            }),
        });

        handleSubFieldModal(false);
    };
    const handleSaveParameters = () => {
        saveParametersTabData();
        handleSubFieldModal(false);
    };
    const handleCancel = () => {
        if (_.isEqual(combinedFieldsData, savedFieldsData)) {
            handleSubFieldModal(false);
        } else {
            setSaveOpen(true);
        }
    };
    return (
        <CardContent className="DalWebTab">
            <p className="breadCrumbs">
                <HomeIcon />
                {selectedField} <ArrowForwardIosIcon /> {selectedNestedField ? <>Sub Field</> : steps[value]}{" "}
                {selectedNestedField && (
                    <>
                        {" "}
                        <ArrowForwardIosIcon /> {selectedNestedField} <ArrowForwardIosIcon /> {steps[value]}
                    </>
                )}{" "}
            </p>
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                <Tabs
                    TabIndicatorProps={{ style: { background: "none" } }}
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                >
                    <Tab label="Subfield" {...a11yProps(0)} />
                    <Tab label="Filters" {...a11yProps(1)} />
                    <Tab label="Others" {...a11yProps(2)} />
                </Tabs>
            </Box>
            <TabPanel value={value} index={0}>
                <SubFieldParameter selectedField={selectedField} selectedNestedField={selectedNestedField} />
            </TabPanel>
            <TabPanel value={value} index={1}>
                <FiltersParameter selectedField={selectedField} selectedNestedField={selectedNestedField} />
            </TabPanel>
            <TabPanel value={value} index={2}>
                <OthersParameters selectedField={selectedField} selectedNestedField={selectedNestedField} />
            </TabPanel>
            <div className="flex-container">
                <Button color="error" variant="outlined" onClick={handleCancel}>
                    Cancel
                </Button>
                <Button variant="contained" color="primary" onClick={() => handleSaveParameters()}>
                    Save Parameters
                </Button>
            </div>

            <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="dal-web fields-pop-up">
                <DialogTitle>Parameter {selectedField}</DialogTitle>
                <DialogContent>
                    <NestedSubFieldContainer
                        handleNestedSubFieldModal={handleNestedSubFieldModal}
                        selectedField={selectedField}
                    />
                </DialogContent>
            </Dialog>
            <SaveDialog
                title={`You have unsaved changes`}
                open={saveOpen}
                setOpen={setSaveOpen}
                stopPropagation={true}
                onConfirm={(e) => {
                    e?.stopPropagation();
                    handleSaveParameters();
                }}
                onDiscard={(e) => {
                    e?.stopPropagation();
                    resetParametersTabData();
                }}
            >
                There are unsaved changes. You can save your changes, cancel to continue editing, or leave and discard
                changes
            </SaveDialog>
        </CardContent>
    );
}
