import React, { useState, useEffect } from "react";
import makeStyles from "@mui/styles/makeStyles";
import { useParams } from "react-router-dom";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import { Link } from "react-scroll";

import Api from "utils/api";
import { errorHandler } from "utils/error-handler";
import FTTable from "common/FTTable";
import { columnsInfo, reports, initRiskDecomposition, initAssetDetAcc, initVsFinalSummary } from "./OptimizationMock";
import AppCover from "home/dashboad/AppCover";

const useStyles = makeStyles({
    root: {
        "& > *": {
            border: "unset",
        },
    },
    container: {
        display: "flex",
        justifyContent: "center",
        flexDirection: "row",
        alignItems: "top",
    },

    reportGrid: {
        width: "80%",
        height: "calc(100vh - 50px)",
        overflowY: "auto",
        overflowX: "auto",
    },
    listItem: {
        cursor: "pointer",
        color: "#00a0dc",
        "&:hover": {
            color: "#00a0dc",
            // borderLeft: "1px solid grey"
        },
    },
    listItemText: {
        color: "#00a0dc",
        fontFamily: "Helvetica Neue,Helvetica,Arial,sans-serif",
        fontSize: "16px",
        lineHeight: 1.44,
        fontWeight: 500,
    },
    reportList: {
        width: "20%",
    },
    report: {
        width: "100%",
        height: "auto",
    },
    activeLink: {
        color: "#00a0dc",
        borderBottom: "1px solid #00a0dc",
        textDecoration: "none",
        "&:hover": {
            textDecoration: "none",
        },
        "&.active": {
            color: "#00a0dc",
            borderLeftColor: "transparent",
            fontFamily: "Helvetica Neue,Helvetica,Arial,sans-serif",
            fontSize: "14px",
            lineHeight: 1.44,
            fontWeight: 600,
        },
    },
    panel: {
        background: " #005598",
        fontSize: "18px",
        color: "#fff",
        padding: "10px 15px",
        borderBottom: "1px solid transparent",
        borderTopLeftRadius: "3px",
        borderTopRightRadius: "3px",
        marginTop: "18px",
    },
});

const ReportList = ({ classes }) => (
    <List dense={true}>
        {reports.map((r, i) => (
            <ListItem key={i} className={classes.listItem}>
                <Link
                    containerId="reportContainer"
                    duration={500}
                    activeClass={classes.activeLink}
                    to={r.id}
                    spy={true}
                    smooth={true}
                >
                    <ListItemText primaryTypographyProps={{ className: classes.listItemText }}>
                        {" "}
                        {r.title}{" "}
                    </ListItemText>
                </Link>
            </ListItem>
        ))}
    </List>
);

const transformData = (arr: any) => {
    const transformedArr: any = [];
    [...arr].forEach((ele) => {
        if (ele.selectionData) {
            ele.selectionData.forEach((item) => {
                item.addPadding = true;
                transformedArr.push(item);
            });
        } else {
            transformedArr.push(ele);
        }
    });
    return transformedArr;
};

export default function Optimization() {
    const classes = useStyles();
    const { optRunId } = useParams();
    const [optResultInfo, setOptResultInfo] = useState<any>({ resultInfo: {}, isLoading: true });

    useEffect(() => {
        Api.getOptResults(optRunId)
            .then((response: any) => {
                const results = {
                    initVsFinalSummary: initVsFinalSummary,
                    initRiskDecomposition: initRiskDecomposition,
                    initAssetDetAcc: initAssetDetAcc,
                    objectiveValues: [],
                    constraintValues: [],
                };
                const resultInfo = response?.opt_results?.[0]?.solution || {};
                const constraintValues = transformData(resultInfo?.constraintValues);
                if (constraintValues) {
                    results.constraintValues = constraintValues;
                }
                if (resultInfo?.objectiveValues) {
                    results.objectiveValues = resultInfo?.objectiveValues;
                }
                setOptResultInfo((optResultInfo: any) => {
                    return { ...optResultInfo, optResultInfo: results || {}, isLoading: false };
                });
            })
            .catch((e: any) => {
                errorHandler(e);
                setOptResultInfo({ optResultInfo: {}, isLoading: false });
            });
    }, [optRunId]);

    return (
        <AppCover>
            <div className={classes.container}>
                <div id="reportContainer" className={classes.reportGrid}>
                    {reports.map((r, i) => (
                        <div key={i} id={r.id} className={classes.report}>
                            <div className={classes.panel}>{r.title}</div>
                            {columnsInfo[r.id] ? (
                                <FTTable
                                    columns={columnsInfo[r.id] || []}
                                    rows={optResultInfo?.optResultInfo?.[r.id] || []}
                                />
                            ) : (
                                <div
                                    style={{
                                        height: "100px",
                                        display: "flex",
                                        alignItems: "center",
                                        flexDirection: "row",
                                        justifyContent: "center",
                                        fontSize: "20px",
                                        fontWeight: 500,
                                        color: "grey",
                                    }}
                                >
                                    {r.title}
                                </div>
                            )}
                        </div>
                    ))}
                    <div style={{ height: "30px" }} />
                </div>
                <div className={classes.reportList}>
                    <ReportList classes={classes} />
                </div>
            </div>
        </AppCover>
    );
}
