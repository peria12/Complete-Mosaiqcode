import React, { useState } from "react";
import makeStyles from "@mui/styles/makeStyles";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import ButtonGroup from "@mui/material/ButtonGroup";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { HChart } from "common/HChart";
import * as Highcharts from "highcharts";
import ShowChartIcon from "@mui/icons-material/ShowChart";

import EventNoteIcon from "@mui/icons-material/EventNote";
import { FTIconButton } from "common/FTButtons";

// import Api from "utils/api";
// import { errorHandler } from "utils/error-handler";
import FTTable from "common/FTTable";
import AppCover from "home/dashboad/AppCover";

const useStyles = makeStyles({
    root: {
        "& > *": {
            border: "unset",
        },
    },
    base: {
        width: "100%",
        background: "white",
    },
    container: {
        display: "flex",
        justifyContent: "center",
        flexDirection: "row",
        alignItems: "top",
    },
    title: {
        fontSize: "17px",
        fontWeight: 600,
    },
    btnGrp: {
        paddingLeft: "10px",
        "& button": {
            fontSize: "0.65rem",
            textTransform: "capitalize",
            "&:first-child": {
                borderTopLeftRadius: "20px",
                borderBottomLeftRadius: "20px",
            },
            "&:last-child": {
                borderTopRightRadius: "20px",
                borderBottomRightRadius: "20px",
            },
        },
    },
});

const meta = {
    widgets: [
        {
            id: "asset_allocation",
            title: "Asset Allocation",
            type: "table",
        },
        {
            id: "stock_style",
            title: "Stock Style",
            type: "table",
            filters: {
                buttons: [{ label: "Map" }, { label: "Weight" }, { label: "Historical" }],
            },
        },
        {
            id: "factor_profile",
            title: "Factor Profile",
            type: "chart",
            filters: {
                buttons: [{ label: "1-Yr" }, { label: "3-Yr" }, { label: "5-Yr" }],
                options: [
                    {
                        key: "category",
                        value: "vs. Category %",
                    },
                    {
                        key: "index",
                        value: "vs. Index %",
                    },
                ],
            },
        },
        {
            id: "style_measures",
            title: "Style Measures",
            type: "table",
            filters: {
                buttons: [{ label: "MeasuresMarket" }, { label: "Cap" }],
            },
        },
        {
            id: "exposure",
            title: "Exposure",
            type: "table",
            filters: {
                buttons: [{ label: "Sector" }, { label: "Region" }, { label: "Country" }],
                options: [
                    {
                        key: "category",
                        value: "vs. Category %",
                    },
                    {
                        key: "index",
                        value: "vs. Index %",
                    },
                ],
            },
        },
    ],
};

const fields = {
    asset_allocation: [
        { key: "asset_class", label: "Asset Class" },
        { key: "fund", label: "Fund", type: "numeric" },
        { key: "category", label: "Category", type: "numeric" },
        { key: "index", label: "Index", type: "numeric" },
    ],
    stock_style: [
        { key: "year", label: "Year" },
        { key: "category", label: "Category" },
        { key: "style", label: "Style" },
        { key: "equity", label: "Equity %", type: "numeric" },
    ],

    factor_profile: [
        { key: "factors", label: "Factors" },
        { key: "fund_value", label: "Fund Value", type: "numeric" },
        { key: "5_yr_min_value", label: "5 Yr Min Value", type: "numeric" },
        { key: "5_yr_max_value", label: "5 Yr Max Value", type: "numeric" },
        { key: "category_average", label: "Category Average", type: "numeric" },
    ],
    style_measures: [
        { key: "value_growth_measures", label: "Value & Growth Measures" },
        { key: "fund", label: "Fund", type: "numeric" },
        { key: "cat_avg", label: "Cat. Average", type: "numeric" },
        { key: "index", label: "Index", type: "numeric" },
    ],
    exposure: [
        { key: "sectors", label: "Sectors" },
        { key: "fund", label: "Fund %", type: "numeric" },
        { key: "cat", label: "Cat %", type: "numeric" },
    ],
};

const reportMock = {
    asset_allocation: [
        {
            asset_class: "U.S. Equity",
            fund: 97.7,
            category: 92.22,
            index: 99.8,
        },
        {
            asset_class: "Non-U.S. Equity",
            fund: 2.3,
            category: 5.89,
            index: 0.2,
        },
        {
            asset_class: "Fixed Income",
            fund: 0,
            category: 0.17,
            index: 0,
        },
        {
            asset_class: "Other",
            fund: 0,
            category: 0.63,
            index: 0,
        },
        {
            asset_class: "Cash",
            fund: 0,
            category: 1.4,
            index: 0,
        },
        {
            asset_class: "Not Classified",
            fund: 0,
            category: 0.04,
            index: 0,
        },
    ],
    stock_style: [
        {
            year: 2021,
            category: "US Fund Large Growth",
            style: "Large Growth",
            equity: 100,
        },
        {
            year: 2020,
            category: "US Fund Large Growth",
            style: "Large Growth",
            equity: 98.92,
        },
        {
            year: 2019,
            category: "US Fund Large Growth",
            style: "Large Growth",
            equity: 98.6,
        },
        {
            year: 2018,
            category: "US Fund Large Growth",
            style: "Large Growth",
            equity: 98.7,
        },
        {
            year: 2017,
            category: "US Fund Large Growth",
            style: "Large Growth",
            equity: 97.26,
        },
    ],
    factor_profile: [
        {
            factors: "Style",
            fund_value: 4.31,
            "5_yr_min_value": 2.51,
            "5_yr_max_value": 19.86,
            category_average: 12.51,
        },
        {
            factors: "Yield",
            fund_value: 92.35,
            "5_yr_min_value": 62.73,
            "5_yr_max_value": 93.71,
            category_average: 80.67,
        },
        {
            factors: "Momentum",
            fund_value: 41.81,
            "5_yr_min_value": 6.44,
            "5_yr_max_value": 75.72,
            category_average: 65.95,
        },
        {
            factors: "Quality",
            fund_value: 10.07,
            "5_yr_min_value": 8.35,
            "5_yr_max_value": 43.46,
            category_average: 19.68,
        },
        {
            factors: "Volatility",
            fund_value: 27.58,
            "5_yr_min_value": 25.64,
            "5_yr_max_value": 81.65,
            category_average: 42.92,
        },
        {
            factors: "Liquidity",
            fund_value: 32.08,
            "5_yr_min_value": 17.72,
            "5_yr_max_value": 68.82,
            category_average: 59.26,
        },
        {
            factors: "Size",
            fund_value: 77.12,
            "5_yr_min_value": 63.21,
            "5_yr_max_value": 88.14,
            category_average: 92.09,
        },
    ],
    style_measures: [
        {
            value_growth_measures: "Price/Earnings",
            fund: 37.74,
            cat_avg: 30.73,
            index: 30.76,
        },
        {
            value_growth_measures: "Price/Book",
            fund: 8.12,
            cat_avg: 7.9,
            index: 10.98,
        },
        {
            value_growth_measures: "Price/Sales",
            fund: 6.98,
            cat_avg: 4.64,
            index: 4.62,
        },
        {
            value_growth_measures: "Price/Cash Flow",
            fund: 24.98,
            cat_avg: 18.89,
            index: 19.24,
        },
        {
            value_growth_measures: "Dividend Yield %",
            fund: 0.26,
            cat_avg: 0.61,
            index: 0.71,
        },
        {
            value_growth_measures: "Long-Term Earnings %",
            fund: 17.81,
            cat_avg: 14.29,
            index: 13.57,
        },
        {
            value_growth_measures: "Historical Earnings %",
            fund: 15.42,
            cat_avg: 15.47,
            index: 10.91,
        },
        {
            value_growth_measures: "Sales Growth %",
            fund: 11.18,
            cat_avg: 7.75,
            index: 7.81,
        },
        {
            value_growth_measures: "Cash-Flow Growth %",
            fund: 11.5,
            cat_avg: 14.9,
            index: 15.17,
        },
        {
            value_growth_measures: "Book-Value Growth %",
            fund: 17.04,
            cat_avg: 9.08,
            index: 6.88,
        },
    ],
    exposure: [
        {
            sectors: "Basic Materials",
            fund: 0.49,
            cat: 1.41,
        },
        {
            sectors: "Consumer Cyclical",
            fund: 16.85,
            cat: 15.68,
        },
        {
            sectors: "Financial Services",
            fund: 9.36,
            cat: 10.57,
        },
        {
            sectors: "Real Estate",
            fund: 1.84,
            cat: 1.31,
        },
        {
            sectors: "Communication Services",
            fund: 18.3,
            cat: 15.97,
        },
        {
            sectors: "Energy",
            fund: 0,
            cat: 0.55,
        },
        {
            sectors: "Industrials",
            fund: 4.6,
            cat: 6.49,
        },
        {
            sectors: "Technology",
            fund: 34.82,
            cat: 32.52,
        },
        {
            sectors: "Consumer Defensive",
            fund: 2.36,
            cat: 3.15,
        },
        {
            sectors: "Healthcare",
            fund: 11.37,
            cat: 12.03,
        },
        {
            sectors: "Utilities",
            fund: 0,
            cat: 0.33,
        },
    ],
};

function SelectBox(params: any) {
    const { value, onChange, options } = params;

    return (
        <FormControl variant="outlined" size="small">
            <Select
                value={value}
                onChange={(x) => onChange(x.target.value)}
                displayEmpty
                style={{
                    borderRadius: "22px",
                    fontSize: "0.8rem",
                    height: "27px",
                }}
            >
                {options.map((item: any) => (
                    <MenuItem key={item.key} value={item.key}>
                        {item.value}
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    );
}

function ToolBar({ classes, widget, setReportMeta }) {
    const [filterValue, setFilterValue] = useState<any>({ factor_profile: "category", exposure: "category" });
    const [reportType, setReportType] = useState<any>({
        factor_profile: 3,
        stock_style: 3,
        style_measures: 1,
        exposure: 1,
    });

    const filterInfo = widget?.filters || {};
    function handleChange(e) {
        setFilterValue({ ...filterValue, [widget?.id]: e });
    }

    function handler(index) {
        setReportType({ ...reportType, [widget?.id]: index + 1 });
    }

    function handleOpenFilter() {
        setReportMeta((meta) => {
            const _widgets = [...meta.widgets];
            _widgets.forEach((wgt) => {
                if (wgt.id == widget?.id) {
                    wgt.type = widget.type === "chart" ? "table" : "chart";
                }
            });
            return { ...meta, _widgets: _widgets };
        });
    }

    return (
        <>
            {filterInfo.buttons && (
                <ButtonGroup variant="outlined" className={classes.btnGrp}>
                    {filterInfo?.buttons.map((btn, index) => (
                        <Button
                            key={index}
                            onClick={() => handler(index)}
                            variant={reportType?.[widget?.id] == index + 1 ? "contained" : undefined}
                            color={reportType?.[widget?.id] == index + 1 ? "primary" : undefined}
                        >
                            {btn.label}
                        </Button>
                    ))}
                </ButtonGroup>
            )}

            {filterInfo?.options && (
                <div style={{ paddingLeft: "8px", paddingTop: "4px" }}>
                    <SelectBox
                        value={filterValue?.[widget?.id] || ""}
                        onChange={(e) => handleChange(e)}
                        options={filterInfo?.options}
                    />
                </div>
            )}

            {widget?.id == "factor_profile" && (
                <div style={{ marginLeft: "auto" }}>
                    <FTIconButton
                        handler={handleOpenFilter}
                        title={widget?.type}
                        btnIcon={
                            widget?.type == "table" ? (
                                <ShowChartIcon style={{ fontSize: "1.25rem" }} color="action" />
                            ) : (
                                <EventNoteIcon style={{ fontSize: "1.25rem" }} color="action" />
                            )
                        }
                        placement="left"
                    />
                </div>
            )}
        </>
    );
}

const options = {
    title: { text: "" },
    xAxis: {
        categories: ["Style", "Yield", "Momentum", "Quality", "Volatility", "Liquidity", "Size"],
    },
    series: [
        {
            type: "column",
            name: "Fund Value",
            data: [4.31, 92.35, 41.81, 10.07, 27.58, 32.08, 77.12],
        },
        {
            type: "column",
            name: "5-Yr Min Value",
            color: Highcharts?.getOptions()?.colors?.[2],
            data: [2.51, 62.73, 6.44, 8.35, 25.64, 17.72, 63.21],
        },
        {
            type: "column",
            name: "5-Yr Max Value",
            color: Highcharts?.getOptions()?.colors?.[8],
            data: [19.86, 93.71, 75.72, 43.46, 81.65, 68.82, 88.14],
        },
        {
            type: "spline",
            name: "Index Average",
            data: [10.88, 72.3, 43.88, 24.47, 40.76, 48.81, 87.88],
            marker: {
                lineWidth: 2,
                lineColor: Highcharts?.getOptions()?.colors?.[3],
                fillColor: "white",
            },
        },
    ],
};

export default function Reports() {
    const classes = useStyles();
    const [reportMeta, setReportMeta] = useState<any>(meta);
    // useEffect(() => {
    //     Api.getOptResults(optRunId)
    //         .then((response: any) => {
    //             const results = {
    //                 initVsFinalSummary: initVsFinalSummary,
    //                 initRiskDecomposition: initRiskDecomposition,
    //                 initAssetDetAcc: initAssetDetAcc,
    //                 objectiveValues: [],
    //                 constraintValues: [],
    //             };
    //             setOptResultInfo((optResultInfo: any) => {
    //                 return {...optResultInfo, optResultInfo: results || { }, isLoading: false };
    //             });
    //         })
    //         .catch((e: any) => {
    //             errorHandler(e);
    //             setOptResultInfo({optResultInfo: { }, isLoading: false });
    //         });
    // }, [optRunId]);
    const colWidth = 6;
    return (
        <AppCover>
            <div className={classes.base}>
                <div className={classes.container + " " + "px-4"}>
                    <Grid
                        className="pt-3"
                        container
                        direction="row"
                        justifyContent="flex-start"
                        alignItems="flex-start"
                        spacing={2}
                    >
                        {reportMeta.widgets?.map((widget: any, index: number) => {
                            return (
                                <Grid
                                    key={widget.id + "_" + index}
                                    container
                                    item
                                    xs={colWidth}
                                    sm={colWidth}
                                    md={colWidth}
                                    lg={colWidth}
                                    xl={colWidth}
                                >
                                    <hr style={{ width: "100%" }} />
                                    <div
                                        style={{
                                            display: "flex",
                                            flexDirection: "row",
                                            alignItems: "center",
                                            width: "100%",
                                            paddingBottom: "8px",
                                        }}
                                    >
                                        <div className={classes.title}>{widget.title}</div>
                                        <ToolBar classes={classes} widget={widget} setReportMeta={setReportMeta} />
                                    </div>
                                    {fields?.[widget.id] && widget.type == "table" && (
                                        <FTTable
                                            columns={fields[widget.id] || []}
                                            rows={reportMock?.[widget.id] || []}
                                        />
                                    )}
                                    {widget?.type == "chart" && <HChart option={options} />}
                                </Grid>
                            );
                        })}
                    </Grid>
                </div>
            </div>
        </AppCover>
    );
}
