export const defaultHoldingsInfo = {
    allHoldings: [],
    holdings: [],
    grouped: [],
    isLoading: false,
};

export const defaultColumnsInfo = {
    meta: {},
    fields: [],
    sorted_fields: [],
    numeric_fields: [],
    agg_fields: [],
    fieldMap: {},
};

export const deafultHiddenCols = {
    entity_id: false,
    sedol: false,
    cusip: false,
    isin: false,
    ft_id: false,
    fsym_security_id: false,
    country: false,
    is_cash_yn: false,
    long_short: false,
    currency: false,
    is_cash: false,
};

// const pieChartTemplate = {
//     chart: { type: "pie", backgroundColor: null, },
//     credits: { enabled: false },
//     // exporting: { enabled: true },
//     title: {
//         text: "",
//         align: "center",
//         style: {
//             // fontWeight: "bold",
//         },
//     },
//     subtitle: { text: null },
//     // tooltip: { pointFormat: "{series.name}: <b>{point.percentage:.0f}%</b>", },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: "pointer",
//             borderColor: "#0000FF",
//             borderWidth: 0,
//             dataLabels: {
//                 enabled: false, // show level on pie chart
//                 distance: -45,
//                 format: "{y} %",
//             },
//             center: ["30%", "30%"],
//             // showInLegend: true, // to show colors-code map for values
//         },
//     },
//     series: [{
//         name: 'Actual',
//         colorByPoint: true,
//         data: []
//     }]
// };

export const collectionName = "holdings";

const aggregateSumFields = [{ id: "book_value" }, { id: "mkt_value" }, { id: "weight" }];

export function getColumInfo(fields, colMap) {
    let loadDefaultSetting = false;
    if (Object.keys(colMap).length == 0) {
        loadDefaultSetting = true;
    }

    const ordered_fields = fields
        ?.filter((f) => f.show_on_table)
        ?.sort((a: any, b: any) => a.view_order - b.view_order);
    const sorted_fields = ordered_fields.map((f) => f.id);
    ordered_fields.filter((col) => !(col.id in colMap)).forEach((col) => (colMap[col.id] = true));
    const fieldMap = {};
    ordered_fields.forEach((field: any) => {
        fieldMap[field.id] = field;
    });
    return {
        meta: loadDefaultSetting ? { ...colMap, ...deafultHiddenCols } : colMap,
        fields: ordered_fields,
        fieldMap: fieldMap,
        sorted_fields: sorted_fields,
        numeric_fields: ordered_fields?.filter((f) => ["percentage", "number"].includes(f.field_type)),
        agg_fields: ordered_fields?.filter((f) => f.is_aggregateField),
    };
}

function getCondition(colValue, rule) {
    const { operator, value } = rule;
    switch (operator) {
        case "=":
            return colValue == value;
        case "!=":
            return colValue != value;
        case "<":
            return colValue < value;
        case ">":
            return colValue > value;
        case "<=":
            return colValue <= value;
        case ">=":
            return colValue >= value;
        case "IN": {
            const values = value?.split(",")?.map((element) => element.trim());
            return values.some((val) => val == colValue);
        }
        case "NOT IN": {
            const values = value?.split(",")?.map((element) => element.trim());
            return !values.some((val) => val != colValue);
        }
        case "LIKE": {
            return colValue?.includes(value);
        }
        case "NOT LIKE": {
            return !colValue?.includes(value);
        }
        default:
            return false;
    }
}

function filterByCondtions(records, conditions) {
    let results: any = [];
    try {
        results = records.filter((em: any) => {
            const func_str = `x = ${JSON.stringify(em)}; return ${conditions}`;
            console.log("func_str: ", func_str);
            const result = new Function(func_str)();
            console.log("result", result);
            return result;
        });
    } catch (err) {
        console.log(err);
    }
    return results;
}

function getRecords(group, entities) {
    const rules = group?.rules;
    let filterEntities = [...entities];
    if (group?.conditional_statements) {
        filterEntities = filterByCondtions(filterEntities, group?.conditional_statements);
    } else {
        rules.forEach((rule) => {
            filterEntities = filterEntities.filter((entity) => getCondition(entity[rule?.column], rule));
        });
        if (group?.is_not) {
            const ids = filterEntities.map((em) => em.entity_id);
            filterEntities = entities.filter((em) => !ids.includes(em.entity_id));
        }
    }
    return filterEntities;
}

export const getAggregateSum = (securities, column) => securities.reduce((a, b) => a + (Number(b[column]) || 0), 0);

function getAggregateFields(securities, fields) {
    const aggregateFields = {};
    fields?.forEach((field) => {
        const val = securities.reduce((a, b) => a + (Number(b[field.id]) || 0), 0);
        aggregateFields[field.id] = val; // val?.toFixed(2);
    });
    return aggregateFields;
}

const getMax = (arr = [], prop) => arr?.reduce((acc, c) => Math.max(c[prop], acc), -Infinity);

const getMin = (arr = [], prop) => arr?.reduce((acc, c) => Math.min(c[prop], acc), Infinity);

const getRange = (arr, prop) => {
    const min = Math.abs(getMin(arr, prop));
    return min + Math.abs(getMax(arr, prop));
};

function getEntitites(entities, aggregateFields) {
    const result = {};
    const marketValRange = getRange(entities, "mkt_value");
    const feesRange = getRange(entities, "fees");

    const holdingsWithWeight = entities.map((sec) => {
        return {
            ...sec,
            // weight: (sec?.mkt_value * 100) / aggregateFields?.mkt_value,
            mkt_value_percent: (sec?.mkt_value * 100) / marketValRange,
            actual_group: (sec?.actual_percent * 100) / aggregateFields?.actual_percent,
            fees_percent: (sec?.fees * 100) / feesRange,
        };
    });

    result["entities"] = holdingsWithWeight;
    // const chartTeplate: any = JSON.parse(JSON.stringify(pieChartTemplate));
    // const data = holdingsWithWeight?.map(e => {
    //     let val = e.actual_group;
    //     if (val) {
    //         val = parseFloat(val?.toFixed(2))
    //     }
    //     return ({ name: e.entity_name, y: val })
    // });
    // if (data?.length > 0) {
    //     chartTeplate["series"][0]["data"] = data;
    //     if (data?.length < 3) {
    //         chartTeplate["plotOptions"].pie.center = ["0", "0"];
    //     }
    //     result["chartTeplate"] = chartTeplate
    // }
    return result;
}

// const aggregateColSpan = 3;
export function transformData(groups, entities) {
    const results: any = [];
    const totalValue = getAggregateSum(entities, "mkt_value");
    const totalBookVal = getAggregateSum(entities, "book_value");
    groups.every((group, i) => {
        const { group_type, title } = group;
        const securities = getRecords(group, entities);
        let aggregateFields: any = {};
        let updatedRecords = { entity_name: group?.title, group_type };
        if (group_type == "Series") {
            if (title == "Others") {
                let seriesEntities: any = [];
                results
                    .filter((res) => res.group_type == "Series")
                    .forEach((r) => {
                        seriesEntities = [...seriesEntities, ...(r?.entities || [])];
                    });
                if (seriesEntities?.length != entities?.length) {
                    const ids = seriesEntities.map((e) => e.entity_id);
                    const otherEntities = entities.filter((e) => !ids.includes(e.entity_id));
                    aggregateFields = getAggregateFields(otherEntities, aggregateSumFields);
                    const props = getEntitites(otherEntities, aggregateFields);
                    updatedRecords = { ...updatedRecords, ...props };
                }
            } else {
                aggregateFields = getAggregateFields(securities, aggregateSumFields);
                const props = getEntitites(securities, aggregateFields);
                updatedRecords = { ...updatedRecords, ...props };
            }
            if (securities?.length > 0) {
                // aggregateFields["weight"] = (aggregateFields?.mkt_value * 100) / totalValue;
                results.push({ ...aggregateFields, ...updatedRecords });
            }
        } else if (title == "Others") {
            if (securities?.length > 0) {
                // aggregateFields["weight"] = (aggregateFields?.mkt_value * 100) / totalValue;
                results.push({ ...aggregateFields, ...updatedRecords });
            }
        } else if (group_type == "Aggregate") {
            aggregateFields = getAggregateFields(securities, [{ id: "weight" }]);
            // const grpMarketValue = getAggregateSum(securities, "mkt_value");
            // aggregateFields["weight"] = (grpMarketValue * 100) / totalValue;
            // updatedRecords["colSpan"] = aggregateColSpan;
            results.push({ ...aggregateFields, ...updatedRecords });
            // if (group_type != groups[i + 1]?.group_type) {
            //     // sum of aggregate section
            //     const aggRows = results.filter((res) => res.group_type == group_type);
            //     const aggGrpTotals = getAggregateFields(aggRows, fieldsInfo?.agg_fields);
            //     results.push({
            //         ...aggGrpTotals,
            //         group_type,
            //         // colSpan: aggregateColSpan,
            //         overLine: true,
            //     });
            // }
        } else if (group_type == "Monthly Rebalance Monitor") {
            aggregateFields = getAggregateFields(securities, [{ id: "weight" }]);
            // updatedRecords["colSpan"] = aggregateColSpan + 1;
            if (group_type != groups[i - 1]?.group_type) {
                results.push({
                    entity_name: "Monthly Rebalance Monitor",
                    group_type,
                    // colSpan: aggregateColSpan + 1,
                    style: { background: "#9e9e9e" },
                });
            }
            results.push({ ...aggregateFields, ...updatedRecords });
        }
        return true;
    });
    const sumGrpLevelWeight = getAggregateSum(
        results.filter((res) => res.group_type === "Series"),
        "weight"
    );
    return {
        holdings: results,
        mkt_value: totalValue,
        book_value: totalBookVal,
        weight: sumGrpLevelWeight,
    };
}

export function getAlignment(field_type, grp, i) {
    if (grp?.group_type == "Aggregate" && i == 0) {
        return "right";
    }
    if (grp?.group_type == "Monthly Rebalance Monitor" && i == 0) {
        return "center";
    }
    return field_type == "string" ? (i == 0 ? "left" : "center") : "right";
}
