export const ui_template = {
    _id: "ui_template",
    title: "Portfolio: ISRC Policy Portfolio",
    reportInfo: [
        { key: "portfolio", title: "Portfolio" },
        { key: "benchmark", title: "ISRC Policy Benchmark" },
        { key: "date", title: "Date" },
    ],
    elements: [
        {
            id: "Summary",
            type: "table",
            width: "30%",
        },
        {
            id: "Equity",
            type: "table",
            width: "30%",
        },
        {
            id: "Cash",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "Cash",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "Fixed Income",
            type: "table",
            gridType: "row",
            width: "30%",
        },

        {
            id: "Commodity",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "FX",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "Equity Risk",
            type: "table",
            gridType: "row",
            width: "30%",
        },

        {
            id: "Equity Sector",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "Equity Style - Portfolio",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "Equity Style - US Equity",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "Fixed Income Stats",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "Key Rate Duration",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "OAD Region Contribution",
            type: "table",
            gridType: "row",
            width: "30%",
        },
        {
            id: "OAD Sector Contribution",
            type: "table",
            gridType: "row",
            width: "30%",
        },
    ],
};
