import React from "react";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import { Link } from "react-router-dom";
import VisibilityIcon from "@mui/icons-material/Visibility";
import DescriptionIcon from "@mui/icons-material/Description";
import moment from "moment";

import MuiTable from "common/Table/MuiTable";
import Api from "utils/api";
import { FTIconButton } from "common/FTButtons";

const useStyles = makeStyles(() =>
    createStyles({
        fileBtn: {
            color: "#00a0dc",
            cursor: "pointer",
        },
        fileNameText: {
            borderBottom: "1px solid #00a0dc",
        },
        iconBtn: {
            fontSize: "1.5rem",
            color: "#00a0dc",
        },
    })
);

const columns = [
    {
        _id: "wsp_date",
        title: "Run Date",
        is_string: true,
        view_order: 1,
        show_on_table: true,
        sortable: true,
        filterable: 0,
    },
    {
        _id: "created_on",
        title: "Run Time",
        is_string: true,
        view_order: 2,
        show_on_table: true,
        sortable: false,
        filterable: 0,
    },
    {
        _id: "wsp_file_id",
        title: "Workspace",
        is_string: true,
        view_order: 3,
        show_on_table: true,
        sortable: false,
        filterable: 0,
    },
    {
        _id: "view_report",
        title: "View Report",
        is_string: true,
        view_order: 4,
        show_on_table: true,
        sortable: false,
        filterable: 0,
    },
];

function ViewReport({ props }) {
    const { row } = props;
    const classes = useStyles();
    return (
        <Link to={`/portfolios/optimization/${row._id}`}>
            <FTIconButton
                handler={undefined}
                title="View Report"
                btnIcon={<VisibilityIcon className={classes.iconBtn} color="primary" />}
                placement="top"
            />
        </Link>
    );
}

function ExtractTime({ props }) {
    const { row } = props;
    return <>{moment.utc(row.created_on).local().format("HH:mm:ss")}</>;
}

function FileLink({ props }) {
    const { row } = props;
    const classes = useStyles();
    return (
        <a
            href={`/api/file-id/${row.wsp_file_id}?access_token=${Api.getAccessToken()}`}
            download
            className={classes.fileBtn}
            style={{ display: "inline-flex", alignItems: "center", cursor: "pointer" }}
        >
            <FTIconButton
                handler={undefined}
                title="View Report"
                btnIcon={<DescriptionIcon className={classes.iconBtn} color="primary" />}
                placement="top"
            />
            {row.wsp_file_id ? "Workspace.xml" : ""}
        </a>
    );
}

export default function OptimizationRuns({ id }) {
    const getOptRunsData = (params: any) => {
        return Api.getOptRuns(id, params).then((resp: any) => {
            return {
                records: resp?.opt_runs,
                total_records: resp?.total_records,
            };
        });
    };

    const getFields = () => Promise.resolve(columns);

    return (
        <MuiTable
            appInfo={{
                appId: "portfolios",
                subAppId: "optimization",
            }}
            meta={{
                nested: false,
                striped: true,
                dense: true,
            }}
            fieldsApi={getFields}
            tableDataApi={getOptRunsData}
            rowConfig={{
                customizeCell: {
                    wsp_file_id: FileLink,
                    view_report: ViewReport,
                    created_on: ExtractTime,
                },
            }}
            toolbarConfig={{
                queryFilter: false,
                searchBar: false,
                columnHideShow: false,
            }}
            tableHeight="240px"
        />
    );
}
