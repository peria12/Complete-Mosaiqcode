import React from "react";
import { Button, TextField, Dialog, DialogActions, DialogContent, FormControl, Box } from "@mui/material";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import InputAdornment from "@mui/material/InputAdornment";

const useStyles = makeStyles(() =>
    createStyles({
        container: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
        },
        action: {
            paddingBottom: "16px",
            paddingTop: 0,
        },
        formControl: {
            width: "100%",
            padding: "10px 0 15px 10px",
        },
        inputBase: {
            fontSize: ".8rem",
        },
        btn: {
            textTransform: "capitalize",
        },
    })
);

const SettingsForm = ({ settingsDialogInfo, setSettingsDialogInfo }) => {
    const classes = useStyles();

    const handleChange = (e: any, key: string) => {
        setSettingsDialogInfo({ ...settingsDialogInfo, [key]: { ...settingsDialogInfo[key], value: e.target.value } });
    };

    return (
        <Box component="div">
            <form className={classes.container}>
                <FormControl className={classes.formControl}>
                    <TextField
                        id={"cash_target"}
                        name="cash_target"
                        type="number"
                        InputLabelProps={{ className: classes.inputBase }}
                        value={settingsDialogInfo.cash_target?.value}
                        label="% Cash Target"
                        onChange={(event) => handleChange(event, "cash_target")}
                        InputProps={{
                            className: classes.inputBase,
                            endAdornment: <InputAdornment position="start">%</InputAdornment>,
                        }}
                    />
                    <small className="text-danger" style={{ fontSize: "0.65em" }}>
                        {settingsDialogInfo.cash_target.error}
                    </small>
                </FormControl>
                <FormControl className={classes.formControl}>
                    <TextField
                        id={"cash_target_threshold"}
                        name="cash_target_threshold"
                        type="number"
                        InputProps={{
                            className: classes.inputBase,
                            endAdornment: <InputAdornment position="start">%</InputAdornment>,
                        }}
                        InputLabelProps={{ className: classes.inputBase }}
                        value={settingsDialogInfo.cash_target_threshold?.value}
                        label="% Cash Target Threshold"
                        onChange={(event) => handleChange(event, "cash_target_threshold")}
                    />
                    <small className="text-danger" style={{ fontSize: "0.65em" }}>
                        {settingsDialogInfo.cash_target_threshold.error}
                    </small>
                </FormControl>
            </form>
        </Box>
    );
};

export default function SettingsDialog({ settingsDialogInfo, setSettingsDialogInfo }) {
    const classes = useStyles();
    const handleClose = () => setSettingsDialogInfo({ ...settingsDialogInfo, open: false });

    const update = (pf_id: string) => {
        const { cash_target, cash_target_threshold } = settingsDialogInfo;
        settingsDialogInfo?.updatePortfolioSettings(pf_id, {
            cash_target: cash_target.value,
            cash_target_threshold: cash_target_threshold.value,
        });
        handleClose();
    };

    return (
        <Dialog open={settingsDialogInfo.open} onClose={handleClose} fullWidth={false}>
            <DialogContent>
                <Box component="h5">Settings </Box>
                <SettingsForm settingsDialogInfo={settingsDialogInfo} setSettingsDialogInfo={setSettingsDialogInfo} />
            </DialogContent>
            <DialogActions className={classes.action}>
                <Button onClick={handleClose} className={classes.btn} size="small" variant="contained">
                    Cancel
                </Button>
                <Button
                    onClick={() => update(settingsDialogInfo.pf_id)}
                    size="small"
                    className={classes.btn}
                    color="primary"
                    variant="contained"
                >
                    {" "}
                    Update{" "}
                </Button>
            </DialogActions>
        </Dialog>
    );
}
