import React from "react";
import { Form } from "react-bootstrap";
import Access from "utils/access";
import { UserSelector } from "common/UserSelector";

export default function ShareAccess({ access, updateAccess }) {
    const isAdmin = Access.hasAccessToZone("admin", "acl", ["admin"]);

    const setUsers = (users) => {
        updateAccess("users", users);
    };

    return (
        <div className="portfolio-management-share-access-wrapper">
            <span className="mr-11">Share With:</span>
            <Form.Check
                inline
                label="System"
                name="system"
                type={"checkbox"}
                id={`inline-checkbox-1`}
                onChange={(event) => {
                    updateAccess("system", event.target.checked);
                }}
                checked={access?.system || false}
                disabled={!isAdmin ? true : access?.users?.length || access?.dept ? true : false}
            />
            <Form.Check
                inline
                label="Dept"
                name="dept"
                type={"checkbox"}
                id={`inline-checkbox-2`}
                onChange={(event) => {
                    updateAccess("dept", event.target.checked);
                }}
                checked={access?.dept || false}
                disabled={access?.users?.length || access?.system ? true : false}
            />
            <UserSelector users={access?.users || []} setUsers={setUsers} disabled={access?.dept || access?.system} />
        </div>
    );
}
