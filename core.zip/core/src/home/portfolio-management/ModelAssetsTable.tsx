import React from "react";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import CloseIcon from "@mui/icons-material/Close";
import { FTIconButton } from "common/FTButtons";
import { roundNumber } from "utils/helpers";

const numberVal = (val) => {
    if (val != undefined && val != null && val !== "") {
        val = Number(val).toFixed(2);
        return isNaN(val) ? "" : Number(val);
    }
    return "";
};

function getValue(col, row) {
    const val = numberVal(row[col.id]);
    if (val != undefined && val != null && val !== "") {
        return val + "%";
    }
    return "";
}

const iconStyle = { fontSize: "1.2rem", color: "grey" };

function DeleteIcon({ row, onDelete }) {
    const isGroupedRow = row?.isGroupedRow || false;
    if (isGroupedRow) {
        return <></>;
    }
    return (
        <FTIconButton
            handler={() => onDelete(row)}
            title="Remove"
            style={{ padding: "0" }}
            btnIcon={<CloseIcon style={iconStyle} color="primary" />}
            placement="top"
        />
    );
}

function DeleteIconHeader({ onDeleteAll }) {
    return (
        <FTIconButton
            handler={onDeleteAll}
            title="Remove All"
            style={{ padding: "1px" }}
            btnIcon={<CancelOutlinedIcon style={iconStyle} color="primary" />}
            placement="top"
        />
    );
}

const getRowCellStyle = (col) => {
    const style: any = {
        height: "20px",
        minHeight: "20px",
        width: col.width || "50px",
        minWidth: col.minWidth || "50px",
        fontSize: "14px",
        borderBottom: "1px solid #E5E5E5",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
    };
    if (col?.type == "numeric") {
        style.textAlign = "right";
    }
    return style;
};

const getHeaderCellStyle = (col) => {
    const style: any = {
        width: col.width || "50px",
        minWidth: col.minWidth || "50px",
        color: "#C5C5C5",
        fontStyle: "italic",
        fontWeight: "400",
        fontSize: "14px",
        borderBottom: "1px solid #E5E5E5",
    };
    if (col?.type == "numeric") {
        style.textAlign = "right";
    }
    return style;
};

function Table({ rows, cols, isEditable, setModelData }) {
    function onDelete(id) {
        const newAssets = rows.slice();
        const filteredAssets = newAssets.filter((asset) => asset.entity_id !== id);
        setModelData((modelData) => ({ ...modelData, assets: filteredAssets }));
    }
    function onDeleteAll() {
        setModelData((modelData) => ({ ...modelData, assets: [] }));
    }
    return (
        <table style={{ width: "100%" }}>
            <thead>
                <tr>
                    {cols?.map((col) => {
                        if (!isEditable && col.id == "delBtn") {
                            return null;
                        }
                        return (
                            <th key={col.id} style={getHeaderCellStyle(col)}>
                                <div>
                                    <span>
                                        {col.id == "delBtn" ? <DeleteIconHeader onDeleteAll={onDeleteAll} /> : col.name}
                                    </span>
                                </div>
                            </th>
                        );
                    })}
                </tr>
            </thead>
            <tbody>
                {rows?.map((row, i) => (
                    <tr key={i} style={{ color: isEditable ? "black" : "#2A2A2A" }}>
                        {cols?.map((col) => {
                            if (!isEditable && col.id == "delBtn") {
                                return null;
                            }
                            if (isEditable && col.id == "weight") {
                                return (
                                    <td key={col.id} style={getRowCellStyle(col)}>
                                        <input
                                            key={col.id}
                                            className="portfolio-management-edit-input weights-text"
                                            type="number"
                                            min={0}
                                            value={row.weight}
                                            onChange={(e) => {
                                                const newAssets: any = rows.slice();
                                                newAssets.find((asset) => asset.entity_id === row.entity_id).weight =
                                                    e.target.value;
                                                setModelData((modelData) => ({ ...modelData, assets: newAssets }));
                                            }}
                                        />
                                        %
                                    </td>
                                );
                            }
                            return (
                                <td
                                    key={col.id}
                                    style={getRowCellStyle(col)}
                                    onClick={col.id == "delBtn" ? () => onDelete(row.entity_id) : undefined}
                                >
                                    {(() => {
                                        switch (col.id) {
                                            case "delBtn":
                                                return <DeleteIcon row={row} onDelete={onDelete} />;
                                            case "weight":
                                            case "bm_risk":
                                            case "bm_return":
                                                return getValue(col, row);
                                            default:
                                                return row[col.id];
                                        }
                                    })()}
                                </td>
                            );
                        })}
                    </tr>
                ))}
            </tbody>
        </table>
    );
}

function sum(arr) {
    let val = 0;
    arr.forEach((num) => (val += Number(num) || 0));
    return roundNumber(val);
}

function sumByWeight(rows, key) {
    let sumRes = 0;
    rows.forEach((r) => (sumRes += ((r[key] || 0) * r.weight) / 100));
    return roundNumber(sumRes);
}

export default function ModelAssetsTable({ rows, cols, isEditable, setModelData }) {
    return (
        <>
            <div style={{ display: "flex" }}>
                <div className="portfolio-management-left-table-wrapper">
                    <Table
                        rows={rows}
                        cols={cols.slice(0, 5)}
                        isEditable={isEditable}
                        setModelData={setModelData}
                    ></Table>
                </div>
                <div style={{ width: "30%", marginTop: "9px" }}>
                    <div className="portfolio-management-col-group-line-for-table"></div>
                    <Table rows={rows} cols={cols.slice(5)} isEditable={isEditable} setModelData={setModelData}></Table>
                </div>
            </div>
            <div>
                <div className="portfolio-management-total-risk">{sumByWeight(rows, "bm_risk")}%</div>
                <div className="portfolio-management-total-return">{sumByWeight(rows, "bm_return")}%</div>
                <div className="portfolio-management-total-weight">{sum(rows.map((r) => r.weight))}%</div>
            </div>
        </>
    );
}
