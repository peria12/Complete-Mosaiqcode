import React, { useState, useEffect } from "react";
import RGL, { WidthProvider } from "react-grid-layout";
import AppCover from "home/dashboad/AppCover";
import "./model-portfolio.css";
import ModelDetail from "./ModelDetail";
import ListView from "./ListView";
import Api from "utils/api";
import { useScreenshot } from "utils/helpers";

const ReactGridLayout = WidthProvider(RGL);

export default function ModelPortfolio() {
    const [rowDataForModel, setRowDataForModel] = useState<any[]>();
    const [showList, setShowList] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [modelData, setModelData] = useState<any>({});
    const [modelListMap, setModelListMap] = useState(new Map());
    const [modelSuites, setModelSuites] = useState<any[]>([]);
    useScreenshot();

    function refreshModelList() {
        Api.getModelList().then((res) => {
            if (res) {
                setRowDataForModel(res);
                const allModelMap = new Map();
                res.forEach((record) => allModelMap.set(record.Name, record._id));
                setModelListMap(allModelMap);
                const modelSuites = new Set();
                res.forEach((model) => {
                    modelSuites.add(model["Model Suite"]);
                });
                setModelSuites(Array.from(modelSuites));
            }
        });
    }

    useEffect(() => {
        refreshModelList();
    }, []);

    function addAsset(assets) {
        const newAssets = [...(modelData?.assets || [])];
        assets.forEach((addedAsset) => {
            newAssets.push({ entity_id: addedAsset.entity_id, entity_name: addedAsset.entity_name, weight: 0 });
        });
        setModelData({ ...modelData, assets: newAssets });
    }

    return (
        <AppCover className="portfolio-management">
            <ReactGridLayout draggableHandle=".portfolio-management-drag-handle">
                <div key="1" data-grid={{ x: 0, y: 0, w: 6, h: 3 }}>
                    <ModelDetail
                        handleViewButton={() => setShowList(!showList)}
                        showList={showList}
                        isEditMode={isEditMode}
                        setIsEditMode={setIsEditMode}
                        modelData={modelData}
                        setModelData={setModelData}
                        modelListMap={modelListMap}
                        modelSuites={modelSuites}
                        refreshModelList={refreshModelList}
                    />
                </div>
                <div key="2" data-grid={{ x: 6, y: 0, w: 6, h: 3 }}>
                    {showList && (
                        <ListView
                            isEditMode={isEditMode}
                            addAsset={addAsset}
                            assets={modelData.assets || []}
                            rowDataForModel={rowDataForModel}
                        />
                    )}
                </div>
            </ReactGridLayout>
        </AppCover>
    );
}
