import React, { useState, useEffect } from "react";
import { CircularProgress, Typography } from "@mui/material";
import { KeyboardDoubleArrowLeft, KeyboardDoubleArrowRight } from "@mui/icons-material";
import plusIcon from "assets/Plus.svg";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "./model-portfolio.css";
import Api from "utils/api";
import { groupBy } from "utils/helpers";
import AutocompleteField from "common/AutocompleteField";
import errorNotification from "utils/api-error";
import ConfirmDialog from "common/ConfirmDialog";

import ShareAccess from "./ShareAccess";
import { getQueryParams } from "../research/dashboard/dashboard-config";
import ModelAssetsTable from "./ModelAssetsTable";
import { Users } from "common/UserSelector";

function formatModelData(data) {
    const shareObj = data;
    const assetData = shareObj?.assets?.data;
    const formattedAssets = assetData.map((assetArr) => {
        const formattedAsset = {};
        shareObj?.assets?.columns?.forEach((col, i) => {
            formattedAsset[col] = assetArr[i];
        });
        return formattedAsset;
    });
    return {
        ...shareObj,
        _id: { ...shareObj?._id },
        access: { ...shareObj?.access },
        assets: formattedAssets,
        created: shareObj?.create_date,
        updated: shareObj?.update_date,
    };
}

export default function ModelPortfolio({
    modelData,
    setModelData,
    modelListMap,
    modelSuites,
    refreshModelList,
    ...props
}) {
    const [initialModelData, setInitialModelData] = useState<any>({});
    const [saveType, setSaveType] = useState(props.saveType || "");
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [showSearchEntity, setShowSearchEntity] = useState(false);
    const [loading, setLoading] = useState(false);
    const [loadingSave, setLoadingSave] = useState(false);
    let scroll_id = null;
    const initialCols = props.customOptionCols
        ? props.customOptionCols.map((col) => ({
              name: col.label,
              id: col.key,
              width: col.width,
              type: col.type,
          }))
        : [
              {
                  name: "Entity ID",
                  id: "entity_id",
              },
              {
                  name: "Entity Name",
                  id: "entity_name",
              },
          ];
    const cols = [
        ...initialCols,
        {
            name: "Weight",
            id: "weight",
            type: "numeric",
            width: "10%",
            minWidth: "75px",
        },
    ];
    const searchEntityFields = props?.customOptionCols?.filter((e) => e.showInSearch) || [];
    const [columns, setColumns] = useState(cols);

    const { handleViewButton, showList } = props;

    useEffect(() => {
        if (modelListMap && modelListMap.size) {
            Api.getModelPortfolioById(modelListMap?.entries()?.next()?.value?.[1]).then((model) => {
                updateColumnsForAssets(model?.assets);
                setModelData(formatModelData(model));
                setInitialModelData(formatModelData(model));
            });
        }
        //eslint-disable-next-line
    }, [modelListMap]);

    useEffect(() => {
        const newColumns = [...columns];
        if (props.isEditMode) {
            newColumns.unshift({
                name: "",
                id: "delBtn",
                width: "5%",
            });
        } else {
            newColumns.shift();
        }
        setColumns(newColumns);
        //eslint-disable-next-line
    }, [props.isEditMode]);

    function searchModels(input) {
        if (!input || input.length < 3) return Promise.resolve([[], 0]);
        const query = {
            index_name: "model_portfolio",
            query: {
                size: 10000,
                query: {
                    bool: {
                        must: input.split(" ").map((str) => ({
                            match: {
                                "name.ngram": str,
                            },
                        })),
                    },
                },
            },
        };
        return Api.searchForModel(query).then((data) => {
            const allData = data?.hits?.hits.map((record) => record?._source?.name);
            const filtered: any[] = [];
            allData.forEach((modelName) => {
                const id = modelListMap.get(modelName);
                if (id) {
                    filtered.push({
                        label: modelName,
                        id,
                    });
                }
            });
            return [filtered, filtered.length || 0];
        });
    }

    function searchEntity(query, more) {
        if (props.customSearchEntity) {
            if (!query) {
                query = " ";
            }
            return props.customSearchEntity(query);
        } else {
            if (!query) return Promise.resolve([[], 0]);
            // const controller = new AbortController();
            if (!query && !(more && scroll_id)) {
                return Promise.resolve([[], 0]);
            }
            const queryParams = more ? { scroll_id } : getQueryParams(query);
            scroll_id = null;
            return Api.entitySearchRBA(queryParams).then((data) => {
                scroll_id = data.entities.length ? data.scroll_id : null;
                const entities: any = [];
                data.entities.forEach((entity) => {
                    entities.push(entity);
                });
                return [entities.map((x) => ({ ...x, id: x.entity_id, label: "" })), data.total_records];
            });
        }
    }

    const searchUser = async (query) => {
        if (!query) return Promise.resolve([[], 0]);

        const query1 = Api.searchUsersOkta(query).then((data) => data.users?.map(mapUserOkta) || []);

        const query2 = Api.searchUsers(query)
            .then((results: any) => results.value.map(mapUser))
            .catch((e) => console.log(e));

        const [a, b] = await Promise.all([query1, query2]);
        return [
            [...a, ...b].map((el) => ({
                id: el.mail,
                label: el.mail,
            })),
            a.length + b.length,
        ];
    };

    function updateColumnsForAssets(assetsAndMapping) {
        const mapping = assetsAndMapping?.display_name_mapping;
        const newColumns = assetsAndMapping?.columns?.map((col) => ({
            name: mapping[col],
            id: col,
            width: "10%",
        }));
        newColumns[newColumns.length - 1] = {
            name: "Weight",
            id: "weight",
            width: "10%",
        };
        setColumns(newColumns);
    }

    const mapUserOkta = (obj) => ({
        id: obj.id,
        label: `${obj.profile.firstName} ${obj.profile.lastName} ${obj.profile.login} (External)`,
        mail: obj.profile.email,
        givenName: obj.profile.lastName,
        name: `${obj.profile.firstName} ${obj.profile.lastName}`,
        local: true,
        type: "user",
        category: "External Users (Okta)",
    });

    const mapUser = (obj) => ({
        id: obj.id,
        label: obj.displayName,
        mail: obj.mail,
        givenName: obj.givenName,
        name: obj.displayName,
        category: "Users",
        type: "user",
    });

    function updateAfterSave(res) {
        errorNotification.next({ type: "success", text: res.message, open: true });
        refreshModelList();
        if (props.setIsEditMode) {
            props.setIsEditMode(false);
        }
        const formattedData = props.formatModelData
            ? props.formatModelData({ _meta: res?.["shared-object"] })
            : formatModelData(res?.["shared-object"]);
        setModelData(formattedData);
        setInitialModelData(formattedData);
    }

    async function handleSave() {
        let count = 0;
        const assets = modelData?.assets?.map((item) => {
            count += Number(item.weight);
            return {
                entity_id: item.entity_id,
                weight: item.weight,
            };
        });
        if (Math.round(count * 100) / 100 !== 100) {
            return errorNotification.next({ type: "error", text: "Sum of weight should be 100% only", open: true });
        }
        setLoadingSave(true);
        if (props.headerName && props.headerName === "Benchmark") {
            const payload = {
                ...modelData,
                name: modelData.Name + "-benchmark",
                type: "benchmark",
            };
            if (saveType === "create") {
                await Api.createSharedState("aa", "saa2", payload)
                    .then((res) => {
                        updateAfterSave(res);
                    })
                    .catch((e) => console.log(e));
            }
            if (saveType === "edit") {
                await Api.updateSharedState(modelData?._id?.$oid, payload)
                    .then((res) => {
                        updateAfterSave(res);
                    })
                    .catch((e) => console.log(e));
            }
        } else {
            const payload = { ...modelData, assets };
            if (saveType === "create") {
                delete payload._id;
                await Api.createModelPortfolio(payload)
                    .then((res) => {
                        updateAfterSave(res);
                    })
                    .catch((e) => console.log(e));
            }
            if (saveType === "edit") {
                await Api.editModelPortfolio(payload?._id?.$oid, payload)
                    .then((res) => {
                        updateAfterSave(res);
                    })
                    .catch((e) => console.log(e));
            }
        }
        setLoadingSave(false);
    }

    const handleCreate = () => {
        props.setIsEditMode(true);
        setSaveType("create");
        setModelData({});
    };

    const handleDelete = () => {
        Api.deleteModelPortfolio(modelData?._id?.$oid).then((res) => {
            errorNotification.next({ type: "success", text: res.message, open: true });
            setModelData({});
            refreshModelList();
        });
    };

    const handleCancel = () => {
        if (props.handleCancel) {
            props.handleCancel();
        } else {
            props.setIsEditMode(false);
            setModelData(initialModelData);
        }
    };

    function onChangeValue(key, value) {
        const newModelData = { ...modelData };
        newModelData[key] = value;
        setModelData(newModelData);
    }

    function updateAccess(key, value) {
        const newAccess = { ...modelData?.access };
        newAccess[key] = value;
        onChangeValue("access", newAccess);
    }

    function groupRows(rows) {
        const groupData = groupBy(rows, "asset_type");
        const groupedRows: any = [];
        Object.keys(groupData).forEach((type) => {
            if (groupData[type]) {
                groupedRows.push(...groupData[type]);
            }
        });
        return groupedRows;
    }

    const RenderOption = function (props, option) {
        const first = props["data-option-index"] == 0;
        return (
            <>
                {first ? (
                    <li {...props} style={{ position: "sticky", top: "0px", background: "white" }}>
                        <div className="col-2 text-truncate ft-grid-header">Entity Id</div>
                        <div className="col-5 text-truncate ft-grid-header">Entity Name</div>
                        <div className="col-2 text-truncate ft-grid-header">Entity Type</div>
                        <div className="col-2 text-truncate ft-grid-header">Ticker</div>
                    </li>
                ) : (
                    <></>
                )}
                <li {...props} style={{ fontSize: "14px" }} key={option.entity_id}>
                    <div className="col-2 text-truncate">{option.entity_id}</div>
                    <div className="col-5 text-truncate">{option.entity_name}</div>
                    <div className="col-2 text-truncate">{option.entity_type}</div>
                    <div className="col-2 text-truncate">{option.bb_ticker || option.symbol}</div>
                </li>
            </>
        );
    };

    const setUsers = (users) => {
        updateAccess("users", users);
    };

    return (
        <div className="portfolio-management-wrapper" style={{ display: "flex", flexDirection: "column" }}>
            <Typography variant="h5" className="portfolio-management-drag-handle">
                {props.headerName ? props.headerName : "Model Portfolio"}
            </Typography>
            {loading ? (
                <div
                    style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                    }}
                >
                    <CircularProgress />
                </div>
            ) : (
                <>
                    <div className="porfolio-management-info-wrapper">
                        <div className="porfolio-management-row-wrapper" style={{ justifyContent: "end" }}>
                            {!props.isEditMode && (
                                <div className="porfolio-management-search-bar">
                                    <label
                                        htmlFor="search-box"
                                        className="porfolio-management-label porfolio-management-search-label"
                                        id="search-label"
                                    >
                                        Search
                                    </label>
                                    <div style={{ width: "50%" }}>
                                        <AutocompleteField
                                            provider={searchModels}
                                            onChange={(_, modelName) => {
                                                setLoading(true);
                                                Api.getModelPortfolioById(modelName.id).then((res) => {
                                                    updateColumnsForAssets(res?.assets);
                                                    setModelData(formatModelData(res));
                                                    setInitialModelData(formatModelData(res));
                                                    setLoading(false);
                                                });
                                            }}
                                            placeholder="Search"
                                            inputPropsStyle={{
                                                variant: "outlined",
                                                height: "30px",
                                                border: "solid 1px #C4C4C4",
                                                padding: 0,
                                            }}
                                            popperWidth="350px"
                                        />
                                    </div>
                                </div>
                            )}
                            {handleViewButton && (
                                <div className="porfolio-management-button" onClick={handleViewButton}>
                                    {showList && <KeyboardDoubleArrowLeft color="action" />}
                                    {showList ? "Close" : "View All"}
                                    {!showList && <KeyboardDoubleArrowRight color="action" />}
                                </div>
                            )}
                        </div>

                        <div className="porfolio-management-row-wrapper">
                            <div
                                className={`porfolio-management-field-wrapper ${
                                    props.isEditMode
                                        ? "porfolio-management-first-column-edit"
                                        : "porfolio-management-first-column"
                                }`}
                            >
                                <span className="porfolio-management-label">Name</span>
                                {props.isEditMode ? (
                                    <input
                                        className="portfolio-management-edit-input"
                                        value={modelData.Name}
                                        onChange={(e) => onChangeValue("Name", e.target.value)}
                                        style={{
                                            width: "70%",
                                            height: "24px",
                                        }}
                                    />
                                ) : (
                                    <div className="porfolio-management-value">{modelData.Name}</div>
                                )}
                            </div>
                            <div
                                className={`porfolio-management-field-wrapper ${
                                    props.isEditMode
                                        ? "porfolio-management-desc-field-edit"
                                        : "porfolio-management-desc-field"
                                }`}
                            >
                                <span className="porfolio-management-label">Description</span>
                                {props.isEditMode ? (
                                    <textarea
                                        className="portfolio-management-edit-input"
                                        value={modelData.Description}
                                        onChange={(e) => onChangeValue("Description", e.target.value)}
                                        style={{
                                            width: "100%",
                                        }}
                                    />
                                ) : (
                                    <div className="porfolio-management-value">{modelData.Description}</div>
                                )}
                            </div>
                        </div>
                        <div className="porfolio-management-row-wrapper">
                            <div
                                className={`porfolio-management-field-wrapper ${
                                    props.isEditMode
                                        ? "porfolio-management-first-column-edit"
                                        : "porfolio-management-first-column"
                                }`}
                            >
                                <span className="porfolio-management-label">Category</span>
                                {props.isEditMode ? (
                                    <input
                                        className="portfolio-management-edit-input"
                                        value={modelData.Category}
                                        onChange={(e) => onChangeValue("Category", e.target.value)}
                                        style={{
                                            width: "70%",
                                            height: "24px",
                                        }}
                                    />
                                ) : (
                                    <div className="porfolio-management-value">{modelData.Category}</div>
                                )}
                            </div>
                            <div
                                className={`porfolio-management-field-wrapper ${
                                    props.isEditMode
                                        ? "porfolio-management-desc-field-edit"
                                        : "porfolio-management-other-column"
                                }`}
                            >
                                <span className="porfolio-management-label">User</span>
                                {props.isEditMode ? (
                                    <AutocompleteField
                                        provider={searchUser}
                                        onChange={(e, newValue) => {
                                            const val: any = newValue;
                                            onChangeValue("User", val.id);
                                        }}
                                        value={{ id: modelData.User || "", label: modelData.User || "" }}
                                        customStyle={{ width: "50%" }}
                                        inputPropsStyle={{ color: "#355dd1" }}
                                    />
                                ) : (
                                    <div className="porfolio-management-value">{modelData.User}</div>
                                )}
                            </div>
                            {!props.isEditMode && (
                                <div className="porfolio-management-field-wrapper porfolio-management-other-column">
                                    <span className="porfolio-management-label">Updated</span>

                                    <div className="porfolio-management-value">{modelData.updated}</div>
                                </div>
                            )}
                        </div>
                        <div className="porfolio-management-row-wrapper">
                            <div
                                className={`porfolio-management-field-wrapper ${
                                    props.isEditMode
                                        ? "porfolio-management-first-column-edit"
                                        : "porfolio-management-first-column"
                                }`}
                            >
                                <span className="porfolio-management-label">Sub-Category</span>
                                {props.isEditMode ? (
                                    <input
                                        className="portfolio-management-edit-input"
                                        value={modelData["Sub-Category"]}
                                        onChange={(e) => onChangeValue("Sub-Category", e.target.value)}
                                        style={{
                                            width: "70%",
                                            height: "24px",
                                        }}
                                    />
                                ) : (
                                    <div className="porfolio-management-value">{modelData["Sub-Category"]}</div>
                                )}
                            </div>
                            <div
                                className={`porfolio-management-field-wrapper ${
                                    props.isEditMode
                                        ? "porfolio-management-desc-field-edit"
                                        : "porfolio-management-other-column"
                                }`}
                            >
                                {props.headerName === "Benchmark" ? (
                                    <></>
                                ) : (
                                    <>
                                        <span className="porfolio-management-label">Model Suite</span>
                                        {props.isEditMode ? (
                                            <>
                                                <input
                                                    list="model-suites"
                                                    className="portfolio-management-edit-input"
                                                    value={modelData["Model Suite"]}
                                                    onChange={(e) => onChangeValue("Model Suite", e.target.value)}
                                                    disabled={props.disableModelSuites}
                                                    style={{
                                                        width: "25%",
                                                        height: "24px",
                                                    }}
                                                />
                                                <datalist id="model-suites">
                                                    {modelSuites.map((item: any) => {
                                                        return (
                                                            <option value={item} key={item}>
                                                                {item}
                                                            </option>
                                                        );
                                                    })}
                                                </datalist>
                                            </>
                                        ) : (
                                            <div className="porfolio-management-value">{modelData["Model Suite"]}</div>
                                        )}
                                    </>
                                )}
                            </div>
                            {!props.isEditMode && (
                                <div className="porfolio-management-field-wrapper porfolio-management-other-column">
                                    <span className="porfolio-management-label">Created</span>
                                    <div className="porfolio-management-value">{modelData.created}</div>
                                </div>
                            )}
                        </div>
                    </div>
                    <div style={{ boxSizing: "border-box" }}>
                        <div className="portfolio-management-ag">
                            <ModelAssetsTable
                                rows={groupRows(modelData.assets || [])}
                                setModelData={setModelData}
                                cols={columns}
                                isEditable={props.isEditMode}
                            />
                        </div>
                        {props.isEditMode && (
                            <div
                                className="porfolio-management-row-wrapper"
                                style={{ justifyContent: "space-between", marginTop: "30px" }}
                            >
                                <div className="portfolio-management-add-icon">
                                    <div
                                        style={{ cursor: "pointer" }}
                                        onClick={() => {
                                            setShowSearchEntity(true);
                                        }}
                                    >
                                        <img src={plusIcon} />
                                    </div>
                                    {showSearchEntity && (
                                        <AutocompleteField
                                            provider={searchEntity}
                                            onChange={(_, entity) => {
                                                const newAssets = [...(modelData?.assets || [])];
                                                newAssets.push({
                                                    ...entity,
                                                    weight: 0,
                                                });
                                                setModelData((modelData) => ({ ...modelData, assets: newAssets }));
                                            }}
                                            placeholder="Search Entity"
                                            inputPropsStyle={{
                                                variant: "outlined",
                                                height: "30px",
                                                width: "100%",
                                                border: "solid 1px #C4C4C4",
                                                padding: 0,
                                            }}
                                            popperWidth="50%"
                                            renderOption={!searchEntityFields?.length && RenderOption}
                                            fields={searchEntityFields}
                                        />
                                    )}
                                </div>
                                <ShareAccess access={modelData?.access} updateAccess={updateAccess} />
                            </div>
                        )}
                        <Users users={modelData?.access?.users || []} setUsers={setUsers} />
                    </div>

                    <div className="porfolio-management-bottom-inner">
                        {!props.isEditMode ? (
                            <div className="porfolio-management-bottom-content">
                                {Object.keys(modelData).length !== 0 && (
                                    <button
                                        className="porfolio-management-button"
                                        style={{ color: "#FA0E0E", borderColor: "#FA0E0E" }}
                                        onClick={() => setConfirmOpen(true)}
                                    >
                                        Delete
                                    </button>
                                )}
                                {Object.keys(modelData).length !== 0 && (
                                    <button
                                        className="porfolio-management-button"
                                        onClick={() => {
                                            props.setIsEditMode(!props.isEditMode);
                                            setSaveType("edit");
                                        }}
                                    >
                                        Edit
                                    </button>
                                )}
                                {Object.keys(modelData).length !== 0 && (
                                    <button
                                        className="porfolio-management-button"
                                        onClick={() => {
                                            onChangeValue("Name", modelData.Name + " - copy");
                                            props.setIsEditMode(true);
                                            setSaveType("create");
                                        }}
                                    >
                                        Copy
                                    </button>
                                )}
                                <button
                                    className="porfolio-management-button"
                                    style={{ color: "#61C98E", borderColor: "#61C98E" }}
                                    onClick={() => handleCreate()}
                                >
                                    Create
                                </button>
                            </div>
                        ) : (
                            <div className="porfolio-management-bottom-content">
                                <button
                                    className="porfolio-management-button"
                                    onClick={() => handleCancel()}
                                    style={{ color: "#FA0E0E", borderColor: "#FA0E0E" }}
                                >
                                    {props.cancelButtonText || "Cancel"}
                                </button>
                                {loadingSave && (
                                    <div>
                                        <CircularProgress style={{ height: "25px", width: "25px" }} />
                                    </div>
                                )}
                                {!loadingSave && (
                                    <button
                                        className="porfolio-management-button"
                                        onClick={() => handleSave()}
                                        disabled={!modelData.Name}
                                    >
                                        Save
                                    </button>
                                )}
                            </div>
                        )}
                        <ConfirmDialog
                            title={`Delete?`}
                            open={confirmOpen}
                            setOpen={setConfirmOpen}
                            stopPropagation={true}
                            onConfirm={(e) => {
                                e?.stopPropagation();
                                handleDelete();
                            }}
                        >
                            Are you sure you want to delete <b>{modelData?.Name}</b>?
                        </ConfirmDialog>
                    </div>
                </>
            )}
        </div>
    );
}
