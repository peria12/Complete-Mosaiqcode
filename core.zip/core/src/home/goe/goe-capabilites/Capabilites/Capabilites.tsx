import React from "react";
import GoeCapabiliates from "../assets/images/svg/Goe_capabilites.svg";
import "./Capabilites.scss";
export default function Capabilites() {
    return (
        <div className="landing-components">
            <div className="capabilites-heading">
                <span className="components-heading-content components-heading-content-blue"> GOE</span>
                <span className="components-heading-content">&nbsp;Capabilities</span>
            </div>
            <div className="capabilites-img-div">
                <img className="capabilites-img" src={GoeCapabiliates} alt="GOE Capabilites" />
            </div>
        </div>
    );
}
