import React, { useEffect, useState, useContext, useMemo } from "react";
import Api from "utils/api";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";
import Loader from "./Loader";
import PlanForRetirementImage from "../../assets/images/svg/plan-of-retirement.svg"
import OwnAHourse from "../../assets/images/svg/own-a-house.svg";
import SaveCollege from "../../assets/images/svg/save-college.svg";
import BuyCar from "../../assets/images/svg/buy-car.svg";
import TakeVacation from "../../assets/images/svg/take-vacation.svg";
import DrawIncome from "../../assets/images/svg/draw-income.svg";
import CustomGoal from "../../assets/images/svg/custom-goal.svg";
const GoalSelection = (props: any) => {
    const goalsTypesList: any = useMemo(() => [
        {
            "goal_key": "plan_retirement",
            "goal_name": "Plan for Retirement",
            "id": "1",
            "scenario_type": "retirement",
            background_image: PlanForRetirementImage
        },
        {
            "goal_key": "own_house",
            "goal_name": "Own a House",
            "id": "2",
            "scenario_type": "regular",
            background_image: OwnAHourse
        },
        {
            "goal_key": "save_collage",
            "goal_name": "Save for College",
            "id": "3",
            "scenario_type": "regular",
            background_image: SaveCollege
        },
        {
            "goal_key": "buy_car",
            "goal_name": "Buy a Car",
            "id": "4",
            "scenario_type": "regular",
            background_image: BuyCar
        },
        {
            "goal_key": "take_vacation",
            "goal_name": "Take a Vacation",
            "id": "5",
            "scenario_type": "regular",
            background_image: TakeVacation
        },
        {
            "goal_key": "draw_income",
            "goal_name": "Draw Income",
            "id": "6",
            "scenario_type": "retirement",
            background_image: DrawIncome
        },
        {
            "goal_key": "custom_goal",
            "goal_name": "Custom Goal",
            "id": "7",
            "scenario_type": "regular",
            background_image: CustomGoal
        }
    ], [])

    const [goalList, setGoalList] = useState(goalsTypesList);
    const [loadingGoals, setLoadingGoals] = useState(false);
    const { setJourneyPath } = useContext(GoeCapabilitiesContext);


    useEffect(() => {
        setLoadingGoals(true);
        Api.getGoalTypes()
            .then((response: any) => {
                if (response.body.length) {
                    setGoalList(response.body.map(x => ({
                        ...(goalsTypesList.find(y => y.id === x.id) || {}),
                        ...x,
                    })));
                }
                setLoadingGoals(false);
            })
            .catch(() => {
                setLoadingGoals(false);
            });
    }, []);
    return (
        <div>
            <div
                className="back-button"
                onClick={() => {
                    setJourneyPath!("basic-information");
                }}
            >
                <span className="arrow"></span>
                <div>Back</div>
            </div>
            <div className="goal-selection">
                {loadingGoals && <Loader />}
                <div className="header">
                    <span>Select Goal Type</span>
                    <div className="border"></div>
                </div>
                <div className="goal-type-list">
                    {goalList.map((goal) => {
                        const goalKey = goal["goal_key"] || "";
                        const goalName = goal["goal_name"] || "";
                        const goalImage = goal["background_image"] || "";
                        return (
                            <div
                                key={goalKey}
                                className={`${goalKey}  goal-box`}
                                onClick={() => {
                                    props.setGoalEditType("NEW");
                                    props.showGoalQuestioonaire(goalKey);
                                }}
                                style={loadingGoals ? {
                                    display: 'none'
                                } : {}}
                            >
                                <div className="goal">
                                    <div className="goal-label">{goalName}</div>
                                    <div className="goal-image" style={{
                                        backgroundImage: `url(${goalImage})`
                                    }}></div>
                                </div>
                                <div className="add">
                                    <span className="plus">+</span>
                                    <div>Add</div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default GoalSelection;
