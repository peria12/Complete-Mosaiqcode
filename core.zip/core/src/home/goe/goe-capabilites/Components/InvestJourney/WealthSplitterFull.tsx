import React, { useState, useContext } from "react";
import Button from "react-bootstrap/Button";
import WealthSplitterDonut from "./WealthSplitterDonut";
import Loader from "./Loader";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";

const WealthSplitterFull = (props: any) => {
    const [donutSize, setDonutSize] = useState("start");
    const rowData = props.wealthRecommendation;
    const { setJourneyPath } = useContext(GoeCapabilitiesContext);
    const formatDollar = (dollarValue, is_dollar) => {
        // const USDollar = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
        if (is_dollar && dollarValue && typeof dollarValue !== "number") {
            // return Number(dollarValue.replace(/[$,]/g, ""));
            return "$" + digitFromator(dollarValue.replace(/[$,]/g, "")).replace(".0", "");
        }
        return "$" + digitFromator(dollarValue).replace(".0", "");
    };

    const digitFromator = (labelValue) => {
        // Nine Zeroes for Billions
        return Math.abs(Number(labelValue)) >= 1.0e9
            ? (Math.abs(Number(labelValue)) / 1.0e9).toFixed(1) + "B"
            : // Six Zeroes for Millions
            Math.abs(Number(labelValue)) >= 1.0e6
            ? (Math.abs(Number(labelValue)) / 1.0e6).toFixed(1) + "M"
            : // Three Zeroes for Thousands
            Math.abs(Number(labelValue)) >= 1.0e3
            ? (Math.abs(Number(labelValue)) / 1.0e3).toFixed(1) + "K"
            : Math.abs(Number(labelValue)).toFixed(1);
    };

    return (
        <div>
            <div
                className="back-button-wealth-splitter-full"
                onClick={() => {
                    setJourneyPath!("goal-type");
                    props.setWlthSplitter("wealth-splitter");
                }}
            >
                <span className="arrow"></span>
                <div>Back</div>
            </div>
            <div className="wealth-splitter-full">
                {props.loading ? <Loader /> : <></>}
                <div className="header">
                    <span>Wealth Splitter</span>
                    <div className="border"></div>
                </div>
                <div className={`wealth-splitter-chart ${donutSize}`}>
                    {
                        <WealthSplitterDonut
                            wealthRecommendation={props.wealthRecommendation}
                            donutSize={donutSize}
                            setDonutSize={setDonutSize}
                        />
                    }
                    {donutSize === "small" && (
                        <div className="wealthsplitter-table">
                            <div className="wealth-split-toggle">
                                <span
                                    className="toggle"
                                    onClick={() => {
                                        setDonutSize("large");
                                    }}
                                ></span>
                            </div>
                            {/* <div style={containerStyle}>
                            <div style={gridStyle} className="ag-theme-alpine">
                                <AgGridReact rowData={rowData} columnDefs={columnDefs}></AgGridReact>
                            </div>
                        </div> */}
                            <div className="div-wealth-table">
                                <div className="div-wealth-inner-table">
                                    <div className="div-wealth-inner-table-left">
                                        <div className="div-wealth-inner1-table">
                                            <span className="span-head-wealth-table">Name</span>
                                        </div>
                                        {rowData.map((item, index) => {
                                            return (
                                                <div
                                                    key={index}
                                                    className={
                                                        index % 2 === 0
                                                            ? "div-wealth-inner1-right-table div-wealth-inner-odd-left-table"
                                                            : "div-wealth-inner1-right-table div-wealth-inner-even-left-table"
                                                    }
                                                    style={{ width: "100%" }}
                                                >
                                                    <div>
                                                        <span
                                                            className={`dot-wealth-table`}
                                                            style={{ background: item.color }}
                                                        ></span>
                                                    </div>
                                                    <div>
                                                        <span className="span-subhead-right-wealth-table">
                                                            {item.name}
                                                        </span>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                    <div className="div-wealth-inner-table-right">
                                        <div className="div-wealth-inner1-right-table">
                                            <div className="div-wealth-inner2-right-table">
                                                <span className="span-head-right-wealth-table">Initial Input</span>
                                            </div>
                                            <div className="div-wealth-inner2-right-table">
                                                <span className="span-head-right-wealth-table">Suggested</span>
                                            </div>
                                            <div className="div-wealth-inner2-right-table">
                                                <span className="span-head-right-wealth-table">Recommendation</span>
                                            </div>
                                            <div className="div-wealth-inner2-right-table">
                                                <span className="span-head-right-wealth-table">Priority</span>
                                            </div>
                                            <div className="div-wealth-inner2-right-table">
                                                <span className="span-head-right-wealth-table">Tenure</span>
                                            </div>
                                            <div className="div-wealth-inner2-right-table">
                                                <span className="span-head-right-wealth-table">Fund Status</span>
                                            </div>
                                        </div>
                                        {rowData.map((item, index) => {
                                            console.log("item", item.recommendation);
                                            return (
                                                <div
                                                    key={index}
                                                    className={
                                                        index % 2 === 0
                                                            ? "div-wealth-inner1-right-table div-wealth-inner-odd-left-table"
                                                            : "div-wealth-inner1-right-table div-wealth-inner-even-left-table"
                                                    }
                                                >
                                                    <div className="div-wealth-inner2-right-table">
                                                        <span className="span-subhead-right-wealth-table">
                                                            {formatDollar(item.initialInput, true)}
                                                        </span>
                                                    </div>
                                                    <div className="div-wealth-inner2-right-table">
                                                        <span className="span-subhead-right-wealth-table">
                                                            {formatDollar(item.suggested, true)}
                                                        </span>
                                                    </div>
                                                    <div className="div-wealth-inner2-right-table">
                                                        <span
                                                            className={`span-subhead-right-wealth-table ${
                                                                item.recommendation < 0
                                                                    ? "span-subhead-dec-right-wealth-table"
                                                                    : "span-subhead-ace-right-wealth-table"
                                                            }`}
                                                        >
                                                            {formatDollar(item.recommendation, false)}
                                                        </span>
                                                    </div>
                                                    <div className="div-wealth-inner2-right-table">
                                                        <span className="span-subhead-right-wealth-table">
                                                            {item.priority}
                                                        </span>
                                                    </div>
                                                    <div className="div-wealth-inner2-right-table">
                                                        <span className="span-subhead-right-wealth-table">
                                                            {item.tenure}
                                                        </span>
                                                    </div>
                                                    <div className="div-wealth-inner2-right-table">
                                                        <span className="span-subhead-right-wealth-table">
                                                            {item.fundStatus}
                                                        </span>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>
                            <div className="wealth-actions">
                                <div>Would you like to continue with the optimized initial wealth?</div>
                                <div>
                                    <Button
                                        onClick={() => {
                                            setJourneyPath!("goal-type");
                                            props.setWlthSplitter("wealth-splitter");
                                        }}
                                    >
                                        Restore Initial Input
                                    </Button>
                                    <Button
                                        onClick={() => {
                                            props.generateOutPut(props.wealthRecommendation);
                                        }}
                                    >
                                        Yes, Generate Output
                                    </Button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
export default WealthSplitterFull;
