import React, { useEffect, useState, useContext, useCallback } from "react";
import "./invest-journey.scss";
import moment from "moment";
import GlobeIcon from "../../assets/images/svg/globe-icon.svg";
import BuildingInvestment from "../../assets/images/svg/Building_investment.svg";
import Invest from "../../Pages/Invest/Invest";
import GoalOverView from "../../Components/Invest/GoalOverview/GoalOverview";
import Disclosure from "../../Components/Disclosure/Disclosure";
import Api from "utils/api";
import RetirementCalculator from "../../Pages/FinancialPlanningTools/RetirementCalculator/RetirementCalculator";
import SSCalculator from "../../Pages/FinancialPlanningTools/SSCalculator/SSCalculator";
import TimeLine from "./TimeLine";
import GoalList from "./GoalList";
import GoalSelection from "./GoalSelection";
import BasicInfo from "./BasicInfo";
import WealthSplitter from "./WealthSplitter";
import WealthSplitterFull from "./WealthSplitterFull";
import GoalUtilizeModal from "./GoalUtilizeModal";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";
import Settings from "utils/settings";
import { IGoalData, ISaveProposalData } from "home/goe/common/interfaces";
import BackgroundImage1 from "../../assets/images/svg/background1.svg";
import BackgroundImage2 from "../../assets/images/svg/background2.svg";
import BackgroundImage3 from "../../assets/images/svg/background3.svg";
import OverviewBackground from "../../assets/images/svg/Overview_background.svg";
import { runPipeController, wealthSplitterController } from "../../GoeController";
const welathRecommendationColors = ["#00847D", "#6CA2FF", "#FF8A1F", "#FAB518", "#A68CFF"];

const InvestorJourney = (props: any) => {
    const [isRetshow, setIsRetshow] = useState(false);
    const [isSSCshow, setIsSSCshow] = useState(false);
    const [addedGoalList, setAddedGoalList] = useState<IGoalData[]>([]);
    const [goalQuestionnaire, setGoalQuestionnaire] = useState("");
    const [journeyPath, setJourneyPath] = useState("basic-information");
    const { startJourney, setStartJourney } = useContext(GoeCapabilitiesContext);
    const [goalJson, setGoalJson] = useState<any>({});
    const [loading, setLoading] = useState(false);
    const [inputData, setInputData] = useState({});
    const [overview, setOverview] = useState("");

    const startInvestJourney = () => {
        setStartJourney?.(true);
        props.setRoutingPath("invest");
    };

    const investJourneyBackgroundClass = startJourney
        ? overview
            ? "investor-goal-overview"
            : "investor-journey-started"
        : "";
    const investJournetBackgroundImage = startJourney
        ? overview
            ? `url(${OverviewBackground})`
            : `url(${BackgroundImage3})`
        : `url(${BackgroundImage1}), url(${BackgroundImage2})`;
    return (
        <div
            className={"investor-journey " + investJourneyBackgroundClass}
            style={{
                backgroundImage: investJournetBackgroundImage,
            }}
        >
            {!isRetshow && !isSSCshow && !startJourney && (
                <InvestLandingPage startInvestJourney={startInvestJourney} setRoutingPath={props.setRoutingPath} />
            )}
            {isRetshow && !isSSCshow && (
                <RetirementCalculator
                    setIsRetshow={setIsRetshow}
                    setIsSSCshow={setIsSSCshow}
                    setStartJourney={setStartJourney}
                    setGoalJson={setGoalJson}
                    goalJson={goalJson}
                    setLoading={setLoading}
                    loading={loading}
                    setInputData={setInputData}
                    inputData={inputData}
                />
            )}
            {isSSCshow && (
                <SSCalculator setIsRetshow={setIsRetshow} setIsSSCshow={setIsSSCshow} setInputData={setInputData} />
            )}
            {!isRetshow && !isSSCshow && startJourney && (
                <InvestGoalJourney
                    app_id={props.app_id}
                    zone_id={props.zone_id}
                    setIsRetshow={setIsRetshow}
                    setStartJourney={setStartJourney}
                    setAddedGoalList={setAddedGoalList}
                    addedGoalList={addedGoalList}
                    setGoalQuestionnaire={setGoalQuestionnaire}
                    goalQuestionnaire={goalQuestionnaire}
                    journeyPath={journeyPath}
                    setJourneyPath={setJourneyPath}
                    setGoalJson={setGoalJson}
                    goalJson={goalJson}
                    setLoading={setLoading}
                    loading={loading}
                    setOverview={setOverview}
                    overview={overview}
                    setRoutingPath={props.setRoutingPath}
                />
            )}
            <Disclosure />
        </div>
    );
};

const InvestGoalJourney = (props: any) => {
    const {
        addedGoalList,
        setAddedGoalList,
        goalQuestionnaire,
        setGoalQuestionnaire,
        goalJson,
        setGoalJson,
        loading,
        setLoading,
        setOverview,
        overview,
    } = props;
    const settings = Settings.getSettings();
    const objId = sessionStorage.getItem("save_proposal_objId");
    const { goalEditType, setGoalEditType, activeGoal, setActiveGoal, wlthSplitter, setWlthSplitter } =
        useContext(GoeCapabilitiesContext);
    const [showGoalUtilize, setShowGoalUtilize] = useState(false);
    const [wealthRecommendation, setWealthRecommendations] = useState([]);
    const [optimizedGoalList, setOptimizedGoalList] = useState<any>([]);
    const [goalSelection, setGoalSelection] = useState("");
    const [goalWealthReport, setGoalWealthReport] = useState({});
    const [goalWealthReportsGeneratepayloadonly, setGoalWealthReportGeneratepayloadonly] = useState({});
    const [goalUpaReport, setGoalUpaReport] = useState({});
    const [goalUpaReportConfig, setGoalUpaReportConfig] = useState({});
    const [isUpa, setIsUpa] = useState(false);
    const [goalOptimized, setGoalOptimized] = useState(false);
    const [goalWealthReportData, setGoalWealthReportData] = useState({});
    const [goalWealthReportDataConfig, setGoalWealthReportDataConfig] = useState({});
    const [saveProposalData, setSaveProposalData] = useState<ISaveProposalData>({
        goal_ids: [],
        request: {},
        response: {},
        api_name: "",
        client_id: settings?._id,
        obj_id: objId || "",
    });

    const { name, riskProfile, journeyPath, setJourneyPath, setGoalList } = useContext(GoeCapabilitiesContext);

    const saveGoals = async () => {
        setIsUpa(false);
        saveProposalData.api_name = "Save_Praposal_Runpipe";
        if (addedGoalList.length > 1) {
            console.log("addedGoalList", addedGoalList);
            setShowGoalUtilize(true);
        } else {
            const runPipeCalls: any = [];
            const runPipeCallsGeneratepayloadonly: any = [];
            const runPipeGoalsKeys: any = [];
            let goalKey = "";
            setLoading(true);
            for (let i = 0; i < addedGoalList.length; i++) {
                goalKey = addedGoalList[i]["goal-key"];
                runPipeGoalsKeys.push(goalKey);
                const goalDetails = addedGoalList[i];
                const recommendation: any = wealthRecommendation.filter((rc: any) => {
                    return rc.goalId == goalKey;
                });
                if (recommendation && recommendation.length) {
                    // goalDetails initialWealth= recommendation.suggested
                    goalDetails["initial_investment"] = recommendation[0].suggested;
                }

                //Set save proposal data
                saveProposalData.goal_ids.push(goalKey);
                saveProposalData.request[goalKey] = {
                    normal: addedGoalList[i],
                    payload: addedGoalList[i],
                };
                saveProposalData.response[goalKey] = { normal: null, payload: null };
                const basicInfo = { name: name, risk_profile_type: riskProfile };
                const [runPipePromise, runPipePromiseGeneratepayloadonly] = await Promise.all([
                    runPipeController(goalDetails, basicInfo, false, false, 0),
                    runPipeController(addedGoalList[i], basicInfo, true, false, 0),
                ]);
                runPipeCalls.push(runPipePromise);
                runPipeCallsGeneratepayloadonly.push(runPipePromiseGeneratepayloadonly);
            }
            const goalWealthReports = {};
            const goalWealthReportsGeneratepayloadonly = {};

            const res = await Promise.all(runPipeCalls);
            const resGeneratepayloadonly = await Promise.all(runPipeCallsGeneratepayloadonly);
            await Promise.all(
                res.map((r, i) => {
                    goalWealthReports[runPipeGoalsKeys[i]] = r.body;
                    saveProposalData.response[goalKey].normal = r.body;
                    return r.body;
                })
            );

            await Promise.all(
                resGeneratepayloadonly.map((r, i) => {
                    goalWealthReportsGeneratepayloadonly[runPipeGoalsKeys[i]] = r.body;
                    saveProposalData.response[goalKey].payload = r.body;
                    return r.body;
                })
            );
            setLoading(false);
            setGoalWealthReport(goalWealthReports);
            setGoalWealthReportGeneratepayloadonly(goalWealthReportsGeneratepayloadonly);
            setOverview("overview");
            setSaveProposalData(saveProposalData);
        }
    };

    const getAllGoals = useCallback(() => {
        Api.getAllGoals().then((response) => {
            console.log("getAllGoals");
            const goalData = response.body.goal_data;
            const goalList: any[] = [];
            for (const goalKey in goalData) {
                const goalInfo = goalData[goalKey];
                goalInfo["goal-key"] = goalKey;

                goalList.push(goalInfo);
            }
            setGoalList!(goalList);
            setAddedGoalList(goalList);
            setLoading(false);
        });
    }, [setAddedGoalList, setGoalList, setLoading]);

    useEffect(() => {
        getAllGoals();
    }, [getAllGoals]);

    useEffect(() => {
        if (goalEditType === "EDIT" && goalQuestionnaire !== activeGoal["goal_key"]) {
            setGoalQuestionnaire(activeGoal["goal_key"]);
        }
    }, [goalEditType, activeGoal, setGoalQuestionnaire, goalQuestionnaire]);

    const saveGoal = (goalDetails: any) => {
        let isGoalExist = false;
        const timeFrameType = goalDetails["contribution_time"] == "month" ? "months" : "years";
        if (goalDetails["goal_key"] == "plan_retirement") {
            const retirementTimeFrameType = goalDetails["my_withdrawal_frequency"] == "Month" ? "months" : "years";
            goalDetails.tenure = `${Math.abs(
                Math.ceil(moment().diff(goalDetails["end_on_date"], retirementTimeFrameType, true))
            )} ${retirementTimeFrameType}`;
        } else if (goalDetails["goal_key"] == "draw_income") {
            goalDetails.tenure = `${Math.abs(
                Math.ceil(moment().diff(goalDetails["last_withdrawal"], timeFrameType, true))
            )} ${timeFrameType}`;
            goalDetails["goal_amount"] = goalDetails["draw_income"];
        } else {
            goalDetails.tenure = `${Math.abs(
                Math.ceil(moment().diff(goalDetails["achieve_this_goal"], timeFrameType, true))
            )} ${timeFrameType}`;
        }

        for (let i = 0; i < addedGoalList.length; i++) {
            if (addedGoalList[i]["goal-key"] == goalDetails["goal-key"]) {
                addedGoalList[i] = goalDetails;
                isGoalExist = true;
            }
        }
        setLoading(true);
        if (isGoalExist) {
            Api.updateGoal(goalDetails, goalDetails["goal-key"]).then(() => {
                getAllGoals();
            });
        } else {
            Api.saveGoals(goalDetails).then(() => {
                getAllGoals();
            });
        }

        setGoalQuestionnaire("");
        setActiveGoal?.({});
        setGoalEditType?.("NEW");
    };

    const editGoal = (goalKey: string) => {
        setGoalEditType?.("EDIT");
        const currentGoal = addedGoalList.filter((goal) => {
            return goal["goal-key"] === goalKey;
        });
        if (currentGoal && currentGoal.length > 0) {
            setActiveGoal?.(currentGoal[0]);
        }
        setWlthSplitter?.("");
        setGoalQuestionnaire(currentGoal[0]["goal_key"]);
    };

    const deleteGoal = (goalKey: string) => {
        setLoading(true);
        Api.deleteGoal(goalKey).then(() => {
            getAllGoals();
            setGoalQuestionnaire("");
            setGoalEditType?.("NEW");
            setActiveGoal?.({});
        });
    };

    const addMoreGoals = () => {
        setJourneyPath!("goal-type");
        setGoalQuestionnaire("");
        setActiveGoal?.({});
        setWlthSplitter?.("");
    };

    const showGoalUtilization = async () => {
        const basicInfo = {
            name: name,
            risk_profile_type: riskProfile,
        };

        setGoalOptimized(false);
        if (goalSelection === "one-portfolio") {
            const runPipeCalls: any = [];
            const runPipeCallsGeneratepayloadonly: any = [];
            const runPipeGoalsKeys: any = [];
            setLoading(true);

            for (let i = 0; i < addedGoalList.length; i++) {
                const goalKey: string = addedGoalList[i]["goal-key"];
                runPipeGoalsKeys.push(goalKey);
                const [runPipePromise, runPipePromiseGeneratepayloadonly] = await Promise.all([
                    runPipeController(addedGoalList[i], basicInfo, false, false, 0),
                    runPipeController(addedGoalList[i], basicInfo, true, false, 0),
                ]);
                runPipeCalls.push(runPipePromise);
                runPipeCallsGeneratepayloadonly.push(runPipePromiseGeneratepayloadonly);

                //Set save proposal data
                saveProposalData.goal_ids.push(goalKey);
                saveProposalData.request[goalKey] = {
                    normal: addedGoalList[i],
                    payload: addedGoalList[i],
                };
                saveProposalData.response[goalKey] = { normal: null, payload: null };
            }
            const goalWealthReports = {};
            const goalWealthReportsGeneratepayloadonly = {};

            const res = await Promise.all(runPipeCalls);
            const resGeneratepayloadonly = await Promise.all(runPipeCallsGeneratepayloadonly);
            await Promise.all(
                res.map((r, i) => {
                    const goalKey = runPipeGoalsKeys[i];

                    goalWealthReports[goalKey] = r.body;
                    saveProposalData.response[goalKey].normal = r.body;

                    return r.body;
                })
            );

            await Promise.all(
                resGeneratepayloadonly.map((r, i) => {
                    const goalKey = runPipeGoalsKeys[i];

                    goalWealthReportsGeneratepayloadonly[goalKey] = r.body;
                    saveProposalData.response[goalKey].payload = r.body;

                    return r.body;
                })
            );

            setGoalWealthReport(goalWealthReports);
            setGoalWealthReportGeneratepayloadonly(goalWealthReportsGeneratepayloadonly);
            setOverview("overview");
            setLoading(false);
            setSaveProposalData(saveProposalData);
        } else {
            wealthSplitterController(addedGoalList, basicInfo).then((response) => {
                console.log(response, "upa response");
            });
        }
    };

    const showWealthSplitterFull = () => {
        setLoading(true);
        const basicInfo = {
            name: name,
            risk_profile_type: riskProfile,
        };
        wealthSplitterController(addedGoalList, basicInfo).then((response) => {
            const wealthSplitDonutResponse = response.body.goalResponseList.map((gs, index) => {
                const goalData = addedGoalList.filter((g) => g["goal-key"] == gs.goalId)[0];
                return {
                    name: gs.goal,
                    initialInput: gs.origCurrWealth,
                    suggested: gs.wealthSplit,
                    recommendation: gs.wealthSplit - gs.origCurrWealth,
                    priority: goalData["goal_priority"],
                    tenure: goalData["tenure"],
                    fundStatus: gs.fundedStatus,
                    goalId: gs.goalId,
                    color: welathRecommendationColors[index % 5],
                };
            });

            setLoading(false);
            setWealthRecommendations(wealthSplitDonutResponse);
            setWlthSplitter?.("wealth-splitter-full");
            setJourneyPath!("proposal");
        });
    };

    return (
        <div className="goals-journey">
            {overview != "overview" && <TimeLine investJourneyPath={journeyPath} />}
            {journeyPath === "basic-information" && <BasicInfo />}
            {journeyPath == "goal-type" && overview != "overview" && (
                <div className="goal-type">
                    <div className="goal-selection-list">
                        {goalQuestionnaire && wlthSplitter == "" && (
                            <Invest
                                goalId={goalQuestionnaire}
                                setGoalQuestionnaire={setGoalQuestionnaire}
                                saveGoal={saveGoal}
                                goalEditType={goalEditType}
                                goalData={activeGoal}
                                addedGoalList={addedGoalList}
                                setIsRetshow={props.setIsRetshow}
                                setIsSSCshow={props.setIsSSCshow}
                                setStartJourney={() => props.setStartJourney}
                                setGoalJson={setGoalJson}
                                goalJson={goalJson}
                                backClick={() => {
                                    setGoalQuestionnaire("");
                                    setActiveGoal?.({});
                                    setGoalJson({});
                                }}
                            />
                        )}
                        {!goalQuestionnaire && wlthSplitter == "" && (
                            <GoalSelection
                                showGoalQuestioonaire={setGoalQuestionnaire}
                                setGoalEditType={(editType) => {
                                    setGoalEditType?.(editType);
                                }}
                            />
                        )}

                        {wlthSplitter === "wealth-splitter" && (
                            <WealthSplitter
                                goalList={addedGoalList}
                                loading={loading}
                                backClick={() => {
                                    getAllGoals();
                                    setWlthSplitter?.("");
                                    setJourneyPath!("goal-type");
                                    setActiveGoal?.({});
                                }}
                                showGoalUtilization={showGoalUtilization}
                                showWealthSplitterFull={showWealthSplitterFull}
                                setWlthSplitter={setWlthSplitter}
                            />
                        )}

                        <GoalList
                            addedGoalList={addedGoalList}
                            deleteGoal={deleteGoal}
                            editGoal={editGoal}
                            saveGoals={saveGoals}
                            wlthSplitter={wlthSplitter}
                            activeGoal={activeGoal}
                            loading={loading}
                            addMoreGoals={addMoreGoals}
                            getAllGoals={getAllGoals}
                        />
                    </div>
                </div>
            )}

            {journeyPath == "proposal" && overview != "overview" && (
                <>
                    <WealthSplitterFull
                        setWlthSplitter={setWlthSplitter}
                        setOverview={setOverview}
                        loading={loading}
                        generateOutPut={async (wealthRecommendation) => {
                            const basicInfo = { name: name, risk_profile_type: riskProfile };
                            if (goalSelection === "one-portfolio") {
                                const runPipeCalls: any = [];
                                const runPipeCallsGeneratepayloadonly: any = [];
                                const runPipeGoalsKeys: any = [];

                                const optGlList: any = [];

                                for (let i = 0; i < addedGoalList.length; i++) {
                                    const goalDetails = JSON.parse(JSON.stringify(addedGoalList[i]));
                                    const recommendation = wealthRecommendation.filter((rc) => {
                                        return rc.goalId == goalDetails["goal-key"];
                                    });
                                    if (recommendation && recommendation.length) {
                                        // goalDetails initialWealth= recommendation.suggested
                                        goalDetails["initial_investment"] = recommendation[0].suggested;
                                    }
                                    optGlList[i] = goalDetails;
                                }
                                setOptimizedGoalList(optGlList);
                                setLoading(true);
                                setGoalOptimized(true);
                                for (let i = 0; i < optGlList.length; i++) {
                                    runPipeGoalsKeys.push(optGlList[i]["goal-key"]);
                                    const [runPipePromise, runPipePromiseGeneratepayloadonly] = await Promise.all([
                                        runPipeController(optGlList[i], basicInfo, false, false, 0),
                                        runPipeController(optGlList[i], basicInfo, true, false, 0),
                                    ]);

                                    runPipeCalls.push(runPipePromise);
                                    runPipeCallsGeneratepayloadonly.push(runPipePromiseGeneratepayloadonly);
                                }
                                const goalWealthReports = {};
                                const goalWealthReportsGeneratepayloadonly = {};

                                const res = await Promise.all(runPipeCalls);
                                const resGeneratepayloadonly = await Promise.all(runPipeCallsGeneratepayloadonly);
                                await Promise.all(
                                    res.map((r, i) => {
                                        goalWealthReports[runPipeGoalsKeys[i]] = r.body;
                                        return r.body;
                                    })
                                );

                                await Promise.all(
                                    resGeneratepayloadonly.map((r, i) => {
                                        goalWealthReportsGeneratepayloadonly[runPipeGoalsKeys[i]] = r.body;
                                        return r.body;
                                    })
                                );

                                setLoading(false);
                                setGoalWealthReport(goalWealthReports);
                                setGoalWealthReportGeneratepayloadonly(goalWealthReportsGeneratepayloadonly);
                                setOverview("overview");
                            }
                        }}
                        wealthRecommendation={wealthRecommendation}
                    />
                </>
            )}

            {overview === "overview" && (
                <GoalOverView
                    setOverview={setOverview}
                    goalWealthReport={goalWealthReport}
                    goalWealthReportsGeneratepayloadonly={goalWealthReportsGeneratepayloadonly}
                    addedGoalList={
                        goalOptimized ? (optimizedGoalList.length ? optimizedGoalList : addedGoalList) : addedGoalList
                    }
                    setGoalWealthReport={setGoalWealthReport}
                    loading={loading}
                    setWlthSplitter={setWlthSplitter}
                    setActiveGoalOverView={(goalKey) => {
                        const actGoal = addedGoalList.filter((goal) => {
                            return goal["goal_key"] == goalKey;
                        });

                        setActiveGoal?.(actGoal[0] || {});
                    }}
                    setGoalQuestionnaire={setGoalQuestionnaire}
                    setGoalEditType={setGoalEditType}
                    goalUpaReport={goalUpaReport}
                    goalUpaReportConfig={goalUpaReportConfig}
                    goalWealthReportData={goalWealthReportData}
                    goalWealthReportDataConfig={goalWealthReportDataConfig}
                    setGoalWealthReportData={setGoalWealthReportData}
                    setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                    isUpa={isUpa}
                    setLoading={setLoading}
                    setJourneyPath={setJourneyPath}
                    getAllGoals={getAllGoals}
                    saveProposalData={saveProposalData}
                    setRoutingPath={props.setRoutingPath}
                    onGoBackClick={(isUpa) => {
                        setActiveGoal?.({});

                        if (isUpa) {
                            setIsUpa(false);
                            setGoalSelection("all-portfolios");
                            setShowGoalUtilize(true);
                        } else {
                            setGoalSelection("one-portfolio");
                            setShowGoalUtilize(false);

                            setWlthSplitter?.("wealth-splitter");
                        }
                    }}
                />
            )}
            {!isUpa && (
                <GoalUtilizeModal
                    setOverview={setOverview}
                    goalSelection={goalSelection}
                    show={showGoalUtilize}
                    goalList={addedGoalList}
                    setGoalUpaReport={setGoalUpaReport}
                    goalUpaReportConfig={goalUpaReportConfig}
                    setGoalUpaReportConfig={setGoalUpaReportConfig}
                    setIsUpa={setIsUpa}
                    onHide={() => setShowGoalUtilize(false)}
                    setGoalWealthReportData={setGoalWealthReportData}
                    setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                    setLoading={setLoading}
                    loading={loading}
                    saveProposalData={saveProposalData}
                    setSaveProposalData={setSaveProposalData}
                    showWealthSplitter={(goalSelection) => {
                        setGoalSelection(goalSelection);
                        setShowGoalUtilize(false);
                        setWlthSplitter?.("wealth-splitter");
                        setActiveGoal?.({});
                    }}
                />
            )}
        </div>
    );
};

const InvestLandingPage = (props: any) => {
    return (
        <div className="landing">
            <div className="top-half">
                <div>
                    <div className="begin-invest-journey">
                        <div>Begin your Investment Journey with Us</div>
                        <button onClick={() => props.startInvestJourney()} className="start-invest-btn">
                            Start Now
                        </button>
                    </div>
                    <div>
                        <div className="invest-journey-globe">
                            <img className="globe-image" src={GlobeIcon} alt="charts frames" />
                        </div>
                    </div>
                </div>
                <div className="ft-branding-info">
                    <div className="patented">
                        <div>Patented</div>
                        <div>
                            {" "}
                            <div className="patented-image" />
                        </div>
                    </div>
                    <div className="journals">
                        <div className="journals-left-blur" />
                        <div className="header">Published in Renowned Journals</div>
                        <div className="journals-scroll-animation">
                            <div className="journal-wealth-image" />
                            <div className="computational-science-image" />
                            <div className="join-image" />
                            <div className="journal-risk-image" />

                            <div className="journal-wealth-image" />
                            <div className="computational-science-image" />
                            <div className="join-image" />
                            <div className="journal-risk-image" />
                        </div>
                        <div className="journals-right-blur" />
                    </div>

                    <div className="awards">
                        <div>Recipient of Prestigious Awards</div>
                        <div>
                            <div className="harry-award-image" />
                            <div className="industry-award-image" />
                            <div className="best-award-image" />
                        </div>
                    </div>
                </div>
            </div>
            <div className="bottom-half">
                <div>
                    <p>
                        Traditional portfolio management sees risk as volatility within a portfolio. For investors, risk
                        is more about the outcome. The Goals Optimization Engine creates a portfolio for each goal an
                        investor has. GOE then actively adjusts the asset mix over time, seeking to maximize the
                        probability of successfully reaching each goal. Each portfolio is probability-driven,
                        personalized, and responsive to changes in the market or to any changes the investor might make
                        to the goal. GOE is available in select DC managed accounts, on our AdvisorEngine® platform for
                        RIAs, as well as in Thailand through our partnership with FINNOMENA. We can also deploy custom
                        implementations of GOE according to the specific needs of a firm.
                    </p>
                </div>
                <div>
                    <img className="building-investment" src={BuildingInvestment} alt="charts frames" />
                </div>
            </div>
        </div>
    );
};

export default InvestorJourney;
