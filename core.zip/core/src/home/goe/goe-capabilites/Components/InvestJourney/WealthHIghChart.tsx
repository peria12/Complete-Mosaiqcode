import React, { useState, useCallback } from "react";
import Highcharts, { Chart as HighchartsChart } from "highcharts";
import HighchartsReact from "highcharts-react-official";
import { Tooltip } from "./Tooltip";

const Chart = (props: any) => {
    const [chart, setChart] = useState<HighchartsChart | null>(null);
    const callback = useCallback((chart: HighchartsChart) => {
        setChart(chart);
    }, []);
    return (
        <>
            <HighchartsReact highcharts={Highcharts} options={props.data} callback={callback} />

            <Tooltip chart={chart}>
                {(formatterContext) => {
                    const data: any = formatterContext.point.options;
                    const recommendedClass = data.suggested <= 0 ? "negative" : "positive";
                    const initialInput = "$" + Math.floor(data.initialInput).toLocaleString();
                    let formattedRecommended = "$" + Math.abs(Math.floor(data.recommendation)).toLocaleString();

                    if (recommendedClass === "negative") {
                        formattedRecommended = "-" + formattedRecommended;
                    } else {
                        formattedRecommended = "+" + formattedRecommended;
                    }
                    return (
                        <div className="wealth-tooltip-details">
                            <div className="goal-name">{data.name}</div>
                            <div className="goal-suggested">{initialInput}</div>
                            {
                                formatterContext.series.name === "Election" &&
                                <div className={`goal-recommended ${recommendedClass}`}>{formattedRecommended}</div>
                            }
                        </div>
                    );
                }}
            </Tooltip>
        </>
    );
};
export default Chart;
