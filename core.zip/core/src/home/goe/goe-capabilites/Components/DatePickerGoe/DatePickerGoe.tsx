import React from "react";
import "./DatePickerGoe.scss";
function DatePickerGoe({ label_value, onChangeDate, name }) {
    return (
        <div className="div-date-picker-goe">
            <div className="div-date-picker-label-goe">
                <label>{label_value}</label>
            </div>
            <div className="div-date-picker-input-goe">
                <input
                    onChange={onChangeDate}
                    className="date-picker-goe"
                    type="date"
                    name={name}
                    placeholder="dd-mm-yyyy"
                ></input>
            </div>
        </div>
    );
}

export default DatePickerGoe;
