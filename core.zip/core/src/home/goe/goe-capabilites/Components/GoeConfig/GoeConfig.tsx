import React, { useEffect, useState } from "react";
import "./GoeConfig.scss";
import DownCircle from "../../assets/images/svg/DownCircle.svg";
import UpCircle from "../../assets/images/svg/UpCircle.svg";
import ReAllocation from "./Forms/ReAllocation";
import DownsideProtection from "./Forms/DownsideProtection";
import GoalPriority from "./Forms/GoalPriority";
import RetirementConfiguration from "./Forms/RetirementConfiguration";
import Recommendations from "./Forms/Recommendations";
import GeneralSettings from "./Forms/GeneralSettings";
import PortfolioConfigurations from "./Forms/PortfolioConfigurations";
const GoeConfig = () => {
    const [isOpen, setIsOpen] = useState({
        "Re-allocation": { flag: false },
        "Goal Priority": { flag: false },
        "Downside Protection": { flag: false },
        "Retirement Configuration": { flag: false },
        Recommendations: { flag: false },
        "General Settings": { flag: false },
        "Portfolio Configuration": { flag: false },
    });

    const configArray = [
        "Re-allocation",
        "Goal Priority",
        "Downside Protection",
        "Retirement Configuration",
        "Recommendations",
        "General Settings",
        "Portfolio Configuration",
    ];

    const [configFormData, setConfigFormData] = useState({});

    function handleOnInputChange({ formName, fieldName, value }) {
        setConfigFormData((data) => {
            const updatedConfigFormData = { ...data, [formName]: { ...data[formName], [fieldName]: value } };

            return updatedConfigFormData;
        });
    }

    useEffect(() => {
        console.log("configFormData", configFormData);
    }, [configFormData]);

    const getForm = (itemname) => {
        if (itemname === "Re-allocation") {
            return <ReAllocation />;
        } else if (itemname === "Goal Priority") {
            return <GoalPriority />;
        } else if (itemname === "Downside Protection") {
            return <DownsideProtection data={configFormData} onInputChange={handleOnInputChange} />;
        } else if (itemname === "Retirement Configuration") {
            return <RetirementConfiguration data={configFormData} onInputChange={handleOnInputChange} />;
        } else if (itemname === "Recommendations") {
            return <Recommendations data={configFormData} onInputChange={handleOnInputChange} />;
        } else if (itemname === "General Settings") {
            return <GeneralSettings data={configFormData} onInputChange={handleOnInputChange} />;
        } else if (itemname === "Portfolio Configuration") {
            return <PortfolioConfigurations data={configFormData} onInputChange={handleOnInputChange} />;
        }
    };

    return (
        <div className="ft-goe-cap-config-parent-main-div">
            <div className="ft-goe-cap-config-inner-div-outer">
                <div className="ft-goe-cap-config-main-div">
                    {configArray.map((item, index) => {
                        return (
                            <div
                                className={`ft-goe-cap-config-section-div ${
                                    isOpen[item].flag ? "ft-goe-cap-config-section-div-active" : ""
                                }`}
                                key={index}
                            >
                                <div
                                    className={`ft-goe-cap-config-section-inner-div ${
                                        isOpen[item].flag ? "ft-goe-cap-config-section-div-bottam" : ""
                                    }`}
                                >
                                    <span
                                        className={`ft-goe-cap-config-section-span ${
                                            isOpen[item].flag ? "ft-goe-cap-config-section-span-active" : ""
                                        }`}
                                    >
                                        {item}
                                    </span>
                                    <img
                                        src={isOpen[item].flag ? UpCircle : DownCircle}
                                        onClick={() =>
                                            setIsOpen({
                                                ...isOpen,
                                                [item]: { flag: !isOpen[item].flag },
                                            })
                                        }
                                    />
                                </div>
                                {isOpen[item].flag && getForm(item)}
                            </div>
                        );
                    })}
                </div>
                <div className="ft-goe-cap-config-save-div">
                    <div className="ft-goe-cap-config-save-button">
                        <span className="ft-goe-cap-config-save-button-text">Save</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GoeConfig;
