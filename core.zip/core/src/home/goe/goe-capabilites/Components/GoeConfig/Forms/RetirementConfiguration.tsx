import React from "react";
import GoeToggleButton from "../Toggle/GoeToggleButton";
import DelImg from "../../../assets/images/svg/trash-can-dis.svg";
import PlusCircle from "../../../assets/images/svg/plus-circle.svg";
import { IConfigFormProp } from "home/goe/common/interfaces";
const FORM_NAME = "retirement_configuration";

function Recommendations(props: IConfigFormProp) {
    const { onInputChange } = props;
    const handleToggle = (fieldName: string, value: string) => {
        onInputChange({
            formName: FORM_NAME,
            fieldName,
            value,
        });
    };
    return (
        <div className="ft-goe-cap-goe-config-down-protection ft-goe-cap-goe-config-ret-config-data-main-div">
            <span className="ft-goe-cap-config-section-span ft-goe-cap-config-inner-div-span">
                Planning Horizon Assumptions
            </span>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Data Tables</span>
                </div>
                <div className="ft-goe-cap-goe-config-ret-config-data-tab-div">
                    <div className="d-flex">
                        <div className="ft-goe-cap-goe-config-ret-config-data-tab-select">Type</div>
                        <div className="ft-goe-cap-goe-config-ret-config-data-tab-select ft-goe-cap-goe-config-ret-config-data-tab-input-right">
                            Table Name
                        </div>
                    </div>
                    <div className="d-flex">
                        <div>
                            <select
                                name="lifestyleStatus"
                                className="input-goe-goal-amt ft-goe-cap-goe-config-ret-config-data-tab-select"
                                // onChange={handleInput}
                                // value={apiPayload.lifestyleStatus}
                            >
                                <option>Select</option>
                            </select>
                        </div>
                        <div className="ft-goe-cap-goe-config-ret-config-data-tab-input-right">
                            <input
                                className="input-goe-goal-amt ft-goe-cap-goe-config-ret-config-data-tab-select"
                                type="text"
                                placeholder="Enter text"
                                // onChange={handleChangeSlider}
                                // value={inputData["dateOfBirth"]}
                            ></input>
                        </div>
                        <img src={DelImg} />
                    </div>
                    <div className="ft-goe-cap-goe-config-ret-config-data-tab-add-div">
                        <img src={PlusCircle} />
                        <span className="ft-goe-cap-goe-config-ret-config-data-tab-add-span">Add more</span>
                    </div>
                </div>
            </div>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Max Age</span>
                </div>
                <div>
                    <input
                        className="input-goe-goal-amt"
                        type="text"
                        placeholder=" 0"
                        // onChange={handleChangeSlider}
                        // value={inputData["dateOfBirth"]}
                    ></input>
                </div>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" width="912" height="2" viewBox="0 0 912 2" fill="none">
                <path d="M0 1H912" stroke="#BFBFBF" strokeOpacity="0.25" />
            </svg>
            <span className="ft-goe-cap-config-section-span ft-goe-cap-config-inner-div-span">De-risk</span>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">
                        Safeguard Achieved Wealth in Last Year
                    </span>
                </div>
                <GoeToggleButton
                    onChange={(val) => handleToggle("safeguard_achieved_wealth", val)}
                    variantTrue="yes"
                    variantFalse="No"
                />
            </div>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">
                        Minimum portfolios for last year
                    </span>
                </div>
                <div>
                    <input
                        className="input-goe-goal-amt"
                        type="text"
                        placeholder=" 0"
                        // onChange={handleChangeSlider}
                        // value={inputData["dateOfBirth"]}
                    ></input>
                </div>
            </div>
        </div>
    );
}

export default Recommendations;
