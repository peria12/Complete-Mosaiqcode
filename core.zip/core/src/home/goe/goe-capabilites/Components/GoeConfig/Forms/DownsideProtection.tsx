import React from "react";
import GoeToggleButton from "../Toggle/GoeToggleButton";
import { IConfigFormProp } from "home/goe/common/interfaces";
const FORM_NAME = "downside_protection";

function DownsideProtection(props: IConfigFormProp) {
    const { onInputChange } = props;
    const handleToggle = (fieldName: string, value: string) => {
        onInputChange({
            formName: FORM_NAME,
            fieldName,
            value,
        });
    };
    return (
        <div className="ft-goe-cap-goe-config-down-protection">
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Loss Threshold Floor</span>
                </div>
                <GoeToggleButton
                    onChange={(val) => handleToggle("loss_threshold_floor", val)}
                    variantTrue="yes"
                    variantFalse="No"
                />
            </div>
            <div className="ft-goe-cap-goe-config-down-protection-toggle">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Loss Threshold Probability</span>
                </div>
                <div>
                    <input
                        className="input-goe-goal-amt"
                        type="text"
                        placeholder=" 0%"
                        // onChange={handleChangeSlider}
                        // value={inputData["dateOfBirth"]}
                    ></input>
                </div>
            </div>
            <span className="ft-goe-cap-goe-config-down-protection-head-span">Loss Threshold Value</span>
            <div className="row-div-fpt-rc">
                <div className="subcontent-head-div-fpt-rc">
                    <div className="ft-goe-cap-goe-config-down-protection-subcontent">
                        <span className="rc_subcontent_span">Accumulation Goals</span>
                    </div>
                    <div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Need</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="traditionContribution"
                                        // value={
                                        //     (inputData["traditionContribution"]
                                        //         ? inputData["traditionContribution"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Want</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="companyContribution"
                                        // value={
                                        //     (inputData["companyContribution"]
                                        //         ? inputData["companyContribution"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Wish</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="autoEscalationRate"
                                        // value={
                                        //     (inputData["autoEscalationRate"]
                                        //         ? inputData["autoEscalationRate"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Dream</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="autoEscalationRate"
                                        // value={
                                        //     (inputData["autoEscalationRate"]
                                        //         ? inputData["autoEscalationRate"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <span className="ft-goe-cap-goe-config-down-protection-subsection-span">
                            (Note: Target Wealth as % of IRR)
                        </span>
                    </div>
                </div>

                <div className="subcontent-head-div-span-fpt-rc-right">
                    <div className="ft-goe-cap-goe-config-down-protection-subcontent">
                        <span className="rc_subcontent_span">De-accumulation Goals</span>
                    </div>
                    <div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Need</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="rothContribution"
                                        // value={
                                        //     (inputData["rothContribution"]
                                        //         ? inputData["rothContribution"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Want</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="companyContributionRoth"
                                        // value={
                                        //     (inputData["companyContributionRoth"]
                                        //         ? inputData["companyContributionRoth"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Wish</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="autoEscalationRateRoth"
                                        // value={
                                        //     (inputData["autoEscalationRateRoth"]
                                        //         ? inputData["autoEscalationRateRoth"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="ft-goe-cap-goe-config-down-protection-row">
                            <div className="subcontent-div-fpt-rc">
                                <div className="ft-goe-cap-goe-config-down-protection-row-span">
                                    <div className="ft-goe-cap-goe-config-down-protection-row-span-div">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='gray-span-goalstemp'><span class='black-span-goalstemp'>Dream</span></span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <input
                                        className={`ft-goe-cap-goe-config-down-protection-row-input input-goe-invest-questiontemp`}
                                        type="text"
                                        name="autoEscalationRateRoth"
                                        // value={
                                        //     (inputData["autoEscalationRateRoth"]
                                        //         ? inputData["autoEscalationRateRoth"]
                                        //         : "0") + "%"
                                        // }
                                        placeholder="0%"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <span className="ft-goe-cap-goe-config-down-protection-subsection-span">
                            (Note: As a % of Target Wealth)
                        </span>
                    </div>
                </div>
            </div>
            <div className="ft-goe-cap-goe-config-down-protection-radio-div">
                <div className="ft-goe-cap-config-section-options-toggle-div">
                    <span className="ft-goe-cap-config-section-options-span-black">Downside Protection Overlay</span>
                </div>
                <div className="ft-goe-cap-config-section-options-radio-group-div">
                    <div className="ft-goe-cap-config-section-options-radio-div">
                        <input type="radio"></input>
                        <span className="ft-goe-cap-config-section-options-span-black">Maximize Goal Probability</span>
                    </div>
                    <div className="ft-goe-cap-config-section-options-radio-div">
                        <input type="radio"></input>
                        <span className="ft-goe-cap-config-section-options-span-black">
                            Maximize Loss Threshold Probability
                        </span>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default DownsideProtection;
