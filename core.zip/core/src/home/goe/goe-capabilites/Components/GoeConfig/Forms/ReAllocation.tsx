import React from "react";
// import GoeToggleButton from "../Toggle/GoeToggleButton";
const ReAllocation = () => {
    const reallocationArray = [
        "When the user re-takes the RTQ",
        "When the user changes the investment tenure",
        "When the user re-prioritizes a goal",
        "When risk indicator flashes",
        "When user changes the goal",
        "When the client wants to re-allocate",
    ];
    // const handleToggle = (tabname) => {
    //     setIsToggle({ flag: !isToggleFlag.flag, tab: tabname });
    // };
    return (
        <div>
            <div className="ft-goe-cap-config-section-options-div">
                <span className="ft-goe-cap-config-section-span ft-goe-cap-config-inner-div-span">
                    Re-allocation Configuration
                </span>
                <div className="ft-goe-cap-config-section-options-div1-allocation">
                    <span className="ft-goe-cap-config-section-options-span-black">Re-allocation Frequency</span>
                    <div className="ft-goe-cap-config-section-options-radio-group-div">
                        <div className="ft-goe-cap-config-section-options-radio-div">
                            <input type="radio"></input>
                            <span className="ft-goe-cap-config-section-options-span-black">Yearly</span>
                        </div>
                        <div className="ft-goe-cap-config-section-options-radio-div">
                            <input type="radio"></input>
                            <span className="ft-goe-cap-config-section-options-span-black">Half-yearly</span>
                        </div>
                        <div className="ft-goe-cap-config-section-options-radio-div">
                            <input type="radio"></input>
                            <span className="ft-goe-cap-config-section-options-span-black">Quarterly</span>
                        </div>
                    </div>
                </div>
                <div className="ft-goe-cap-config-section-options-div2">
                    <span className="ft-goe-cap-config-section-options-span-black">Re-allocation Date</span>
                    <input type="date" className="ft-goe-cap-config-section-options-input-date" />
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" width="912" height="2" viewBox="0 0 912 2" fill="none">
                    <path d="M0 1H912" stroke="#BFBFBF" strokeOpacity="0.25" />
                </svg>
                <span className="ft-goe-cap-config-section-span ft-goe-cap-config-inner-div-span">
                    When do you want re-allocation to happen?
                </span>
                {reallocationArray.map((item, index) => {
                    return (
                        <div className="d-flex" key={index}>
                            <div className="ft-goe-cap-config-section-options-toggle-div">
                                <span className="ft-goe-cap-config-section-options-span-black">{item}</span>
                            </div>
                            {/* <GoeToggleButton
                                                        item={item}
                                                        isToggleFlag={isToggleFlag}
                                                        setIsToggle={()=>handleToggle(item)}
                                                    /> */}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default ReAllocation;
