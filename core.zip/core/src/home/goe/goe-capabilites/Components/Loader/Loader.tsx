import React from "react";
const Loader = (props: any) => {
    return (
        <div className="loader-overlay" style={{ width: props.width + "%" }}>
            {" "}
            <div className="lds-spinner">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    );
};

export default Loader;
