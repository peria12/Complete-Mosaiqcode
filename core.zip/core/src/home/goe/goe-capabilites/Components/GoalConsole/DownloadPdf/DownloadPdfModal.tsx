import Modal from "react-bootstrap/Modal";
import React, { useRef } from "react";
import jsPDF from "jspdf";
import FTLogo from "../../../assets/images/svg/ft_logo_transparent.svg";
import GOELogo from "../../../assets/images/svg/goe_logo_transparent.svg";

import "./DownloadPdfModal.scss";

import html2canvas from "html2canvas";
import { formatDollar, getgoalLabels } from "home/goe/common/utils";
import PortfolioFormSection from "../../Invest/PortfolioFormSection/PortfolioFormSection";
import ForwardLooking from "../../Invest/GoalDetailOverview/ForwardLooking/ForwardLooking";
import PortfolioFormSectionRet from "../../Invest/PortfolioFormSection/PortfolioFormSectionRet";
import PortfolioFormSectionDrawIncome from "../../Invest/PortfolioFormSection/PortfolioFormSectionDrawIncome";
import PortfolioComposition from "../../Invest/GoalDetailOverview/GoalProposal/PortfolioComposition/PortfolioComposition";
import GoalProbability from "../../Invest/GoalDetailOverview/GoalProposal/GoalProbability/GoalProbability";

const DownloadPdfModal = ({ show, handleModalOnHide, basicInfo, advisorData, goal, portfolioComposition, isUpa }) => {
    const goalProbData = {
        goalDataPriority: [goal],
        addedGoalList: basicInfo.goals,
        applyRecommendationFlag: false,
        isUpa,
        goalUpaReport: {},
        goalUpaReportConfig: {},
    };

    const pdfHtmlRef = useRef<HTMLDivElement>(null);
    const sectionOneRef = useRef<HTMLDivElement>(null);
    const sectionTwoRef = useRef<HTMLDivElement>(null);
    const sectionThreeRef = useRef<HTMLDivElement>(null);
    const sectionFiveRef = useRef<HTMLImageElement>(null);
    const dateObject = new Date();
    const year = dateObject.getFullYear();
    const month = dateObject.getMonth();
    const date = dateObject.getDate();
    const hour = dateObject.getHours();
    const minutes = dateObject.getMinutes();
    const seconds = dateObject.getSeconds();
    console.log(month - date - year, hour - minutes - seconds, "date"); //this will be removed later
    // format('MM-DD-YYYY HH:mm:ss')
    const exportAsImageURI = async (elementRef) => {
        if (elementRef.current) {
            const canvas = await html2canvas(elementRef.current);
            const imageURI = canvas.toDataURL("image/jpeg", 1.0);

            return imageURI;
        }
    };

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const handleGeneratePdf = async () => {
        const doc = new jsPDF({
            format: "a4",
            unit: "px",
        });

        // Adding the fonts.
        //doc.setFont('Inter-Regular', 'normal');
        const pdf_name = `${basicInfo.full_name}_`;
        if (pdfHtmlRef.current) {
            doc.text(
                "I could not find any method that can help me calculate \n the Y cordinate of last image so that I can add next image or \n text after it",
                50,
                50
            );
            const secOneScreenshotURI: string = (await exportAsImageURI(sectionOneRef)) || "";
            const secTwoScreenshotURI: string = (await exportAsImageURI(sectionTwoRef)) || "";
            const secThreeScreenshotURI: string = (await exportAsImageURI(sectionThreeRef)) || "";
            // const pdfHtmlRef: string = (await exportAsImageURI(sectionThreeRef)) || "";
            const secFiveScreenshotURI: string = (await exportAsImageURI(sectionFiveRef)) || "";

            secFiveScreenshotURI && doc.addImage(secFiveScreenshotURI, "JPEG", 15, 200, 400, 250);
            doc.addPage();
            secOneScreenshotURI && doc.addImage(secOneScreenshotURI, "JPEG", 15, 200, 400, 250);
            doc.addPage();
            secTwoScreenshotURI && doc.addImage(secTwoScreenshotURI, "JPEG", 15, 50, 400, 250);
            doc.addPage();
            secThreeScreenshotURI && doc.addImage(secThreeScreenshotURI, "JPEG", 15, 50, 300, 250);
            //doc.addImage(secThreeScreenshotURI, "PNG", 0, 100, 120, 50);
            //doc.addImage(imgData, 'JPEG', 15, 40, 180, 160);
            await doc.save(pdf_name);
        }
    };

    return (
        <Modal dialogClassName="pdf-modal" backdrop="static" centered size="xl" show={show} onHide={handleModalOnHide}>
            <Modal.Header closeButton>
                <Modal.Title>
                    <div></div>
                </Modal.Title>
            </Modal.Header>

            <Modal.Body className="pdf-body-content">
                {isUpa && <h1>Coming Soon</h1>}
                {!isUpa && (
                    <>
                        <div className="pdf-backgroundImage"></div>
                        <div ref={sectionFiveRef} style={{ margin: "20px" }}>
                            <div
                                style={{
                                    display: "flex",
                                    flexDirection: "row",
                                    justifyContent: "space-between",
                                    marginBottom: "60px",
                                }}
                            >
                                <div style={{ marginTop: "5px" }}>
                                    <img src={GOELogo} alt="GOE Brand Logo" className="pdf-logo" />
                                </div>
                                <div>
                                    <img src={FTLogo} alt="FT Brand Logo" className="pdf-logo" />
                                </div>
                            </div>
                            <div
                                style={{
                                    display: "flex",
                                    flexDirection: "column",
                                    rowGap: "30px",
                                }}
                            >
                                <div
                                    style={{
                                        display: "flex",
                                        flexDirection: "column",
                                        rowGap: "30px",
                                    }}
                                >
                                    <div>
                                        <label className="advisor-modal-title">Adviosor Details:</label>
                                        <div>{advisorData["first-name"]}</div>
                                        <div>{advisorData.email}</div>
                                        {/* <div>123 456 789</div> */}
                                    </div>
                                    <div>
                                        <label className="advisor-modal-title">Client Details:</label>
                                        <div>{basicInfo.full_name}</div>
                                        <div>{basicInfo.dob}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="pdf-goals">
                            <div ref={sectionOneRef}>
                                <h4 className="pdf-subsection-title">
                                    Goal Details: {goal.name.replace(/[^A-Za-z]+/g, " ")}
                                </h4>
                                {goal.goal_type === "retirement" ? (
                                    goal.goal_key === "plan_retirement" ? (
                                        <PortfolioFormSectionRet
                                            data={goal}
                                            isEscalation={goal.escalation_percentage ? false : true}
                                            isShowInPDF={true}
                                        />
                                    ) : (
                                        <PortfolioFormSectionDrawIncome
                                            data={goal}
                                            isEscalation={goal.escalation_percentage ? false : true}
                                            isShowInPDF={true}
                                        />
                                    )
                                ) : (
                                    <PortfolioFormSection
                                        data={goal}
                                        isEscalation={goal.escalation_percentage ? false : true}
                                        isShowInPDF={true}
                                    />
                                )}
                            </div>
                            <div ref={sectionTwoRef}>
                                <h4 className="pdf-subsection-title">Your Proposal</h4>
                                <div className="pdf-portfolio-view">
                                    <div ref={sectionThreeRef} className="pdf-grid-item">
                                        <GoalProbability
                                            goalWealthReportConfig={goal.goal_response.payload}
                                            goalWealthReport={goal.goal_response.normal}
                                            isUpa={isUpa}
                                            addedGoalList={goalProbData.addedGoalList}
                                            goalDataPriority={goalProbData.goalDataPriority}
                                            getgoalLabels={getgoalLabels}
                                            formatDollar={formatDollar}
                                            basicInfo={basicInfo}
                                            setApplyRecommendationFlag={console.log}
                                            applyRecommendationFlag={goalProbData.applyRecommendationFlag}
                                            isShowInPDF={true}
                                        />
                                    </div>
                                    <div className="pdf-grid-item">
                                        <PortfolioComposition
                                            applyRecommendationFlag={goalProbData.applyRecommendationFlag}
                                            goalWealthReport={goal.goal_response.normal}
                                            saveProposalData={basicInfo}
                                            isShowInPDF={true}
                                            isUpa={goalProbData.isUpa}
                                        />
                                    </div>
                                </div>
                                <ForwardLooking
                                    goalWealthReport={goal.goal_response.normal}
                                    startDate={goal["created_at"]}
                                    endDate={goal["achieve_this_goal"]}
                                    goalType={goal["goal_key"]}
                                    addedGoalList={goalProbData.addedGoalList}
                                    portfolioComposition={portfolioComposition}
                                    isShowInPDF={true}
                                />
                                <div>
                                    <div style={{ fontSize: "20px", margin: "50px" }}>
                                        <h4 className="pdf-subsection-title">Disclaimer :</h4> Goals Optimization Engine
                                        (GOE) and any and all data, portfolios, allocations, and illustrations generated
                                        from GOE (Output) are purely hypothetical and provided solely for information
                                        purposes within this demo, neither GOE nor the Output constitutes investment
                                        advice or an investment recommendation by Franklin Templeton or its affiliates
                                        or any other person.
                                    </div>
                                </div>
                            </div>
                        </div>{" "}
                    </>
                )}
            </Modal.Body>
            {/* this will be used in future */}
            {/* <Modal.Footer>
                <Button variant="primary" onClick={handleGeneratePdf}>
                    Save PDF
                </Button>
            </Modal.Footer> */}
        </Modal>
    );
};

export default DownloadPdfModal;
