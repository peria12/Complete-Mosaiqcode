import React from "react";
import moment from "moment";

interface Props {
    startDate?: string;
    endDate?: string;
}

export const TimeToGoal = ({ startDate, endDate }: Props) => {
    if (!startDate || !endDate) return null;

    const endDateMoment = moment(endDate, "YYYY-MM-DD");
    const startDateMoment = moment(startDate, "YYYY-MM-DD");
    const formattedEndDate = endDateMoment.format("MMM YYYY");
    const currentDate = moment();

    const duration = moment.duration(endDateMoment.diff(startDateMoment));
    const durationLeft = moment.duration(endDateMoment.diff(currentDate));

    const percentageTimeLeft = (durationLeft.asMilliseconds() / duration.asMilliseconds()) * 100;
    const roundedPercentage = percentageTimeLeft.toFixed(2);

    const years = duration.years();
    const months = duration.months();
    const days = duration.days();

    let timeLeft;

    if (years > 0) {
        timeLeft = `${years} yr${years > 1 ? "s" : ""} left`;
    } else if (months > 0) {
        timeLeft = `${months} mo${months > 1 ? "s" : ""} left`;
    } else {
        timeLeft = `${days} day${days > 1 ? "s" : ""} left`;
    }

    return (
        <div className="time-to-goal-wrapper">
            <div className="goal-end-date">{formattedEndDate}</div>
            <div className="time-to-goal">
                <div className="progress-bar">
                    <div className="progress" style={{ width: `${roundedPercentage}%` }}>
                        {roundedPercentage}%
                    </div>
                </div>
                {timeLeft}
            </div>
        </div>
    );
};
