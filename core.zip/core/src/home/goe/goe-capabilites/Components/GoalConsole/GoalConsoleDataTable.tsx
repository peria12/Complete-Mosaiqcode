import moment from "moment";
import React, { useContext, useEffect, useState } from "react";
import Api from "utils/api";
import { GoeCapabilitiesContext } from "../../GoeCapabilitiesContext";
import CopyIcon from "../../assets/images/svg/goal_console/copy.svg";
import EditIcon from "../../assets/images/svg/goal_console/edit.svg";
import SaveIcon from "../../assets/images/svg/goal_console/save.svg";
import { GoalDetail } from "./GoalConsoleDetails";
import { GoalName } from "./GoalName";
import { GoalStatus } from "./GoalStatus";
import { TimeToGoal } from "./TimeToGoal";
import DownloadPdfModal from "./DownloadPdf/DownloadPdfModal";

const headers = [
    "Goal Name",
    "Algorithm",
    "Goal Amount",
    "Goal Type",
    "Goal Created",
    "Goal Status",
    "Time to Goal",
    "Proposal",
    "Status",
];

export type adviosrData = {
    advisor_id: string;
    goals: [];
};
interface GoalConsoleDataTableProps {
    goals: GoalDetail[];
    priorityOrder?: string[];
    setLoading?: (loading: boolean) => void;
    filter: () => void;
    basicInfo?: { advisor_id: string; risk_profile: string };
    advisorData?: object;
    setRoutingPath?: (path: string) => void;
    clientId: string;
}
export const GoalConsoleDataTable = ({
    goals,
    priorityOrder,
    setLoading,
    filter,
    basicInfo,
    advisorData,
    setRoutingPath,
    clientId,
}: GoalConsoleDataTableProps) => {
    const [isStatusActive, setIsStatusActive] = useState({});
    const { setActiveGoal, setGoalEditType, setWlthSplitter, setJourneyPath, setStartJourney, setRiskProfile } =
        useContext(GoeCapabilitiesContext);
    const [portfolioComposition, setPortfolioComposition] = useState({});
    const [showPdfModal, setShowPdfModal] = useState<boolean>(false);
    const [currentGoal, setCurrentGoal] = useState();

    let isUpa;

    useEffect(() => {
        const goalsList = goals.reduce((goalsList, goal) => {
            goalsList[goal._id] = goal.is_active;
            return goalsList;
        }, {});
        setIsStatusActive(goalsList);
    }, [goals]);

    useEffect(() => {
        Api.getPortfolioComposition()
            .then((response: any) => {
                setPortfolioComposition(response.body.asset_category_distribution);
            })
            .catch(() => {
                console.log("something went wrong");
            });
    }, []);

    const markStatus = async (status, goal_id) => {
        try {
            setLoading?.(true);
            await Api.updateAndCloneGoals({
                goal_id: goal_id,
                action: "update",
                values: {
                    is_active: status,
                },
            });
        } catch (error) {
            setIsStatusActive({
                ...isStatusActive,
                [goal_id]: !isStatusActive[goal_id],
            });
        } finally {
            filter();
            setLoading?.(false);
        }
    };

    const handleClick = (goal_id) => {
        markStatus(!isStatusActive[goal_id], goal_id);
        setIsStatusActive({
            ...isStatusActive,
            [goal_id]: !isStatusActive[goal_id],
        });
    };

    const cloneGoals = async (goalId: string) => {
        try {
            setLoading?.(true);
            await Api.updateAndCloneGoals({
                goal_id: goalId,
                action: "duplicate",
                values: {},
            });
        } catch (error) {
            console.log("API Failed");
        } finally {
            filter();
            setLoading?.(false);
        }
    };

    const onEditClicked = (currentGoal: any) => {
        localStorage.setItem("clientId", clientId);
        setJourneyPath?.("goal-type");
        setStartJourney?.(true);
        setRoutingPath?.("invest");
        if (basicInfo?.risk_profile) {
            setRiskProfile?.(basicInfo.risk_profile);
        }
        setGoalEditType?.("EDIT");
        if (currentGoal) {
            currentGoal["goal-key"] = currentGoal._id;
            setActiveGoal?.(currentGoal);
        }
        setWlthSplitter?.("");
    };

    const getGoalType = (goalKey: string) => {
        switch (goalKey) {
            case "plan_retirement":
                return "Retirement";
            case "draw_income":
                return "Income";
            default:
                return "Wealth";
        }
    };

    const ModifyGoalAction = ({ goalId, cloneGoals, goal, onEditClicked }) => {
        return (
            <div className="goals-modify">
                <img className="goals-modify-icon" onClick={onEditClicked} src={EditIcon} />
                <img className="goals-modify-icon" onClick={() => cloneGoals(goalId)} src={CopyIcon} />
                <img
                    className="goals-modify-icon"
                    onClick={() => {
                        setShowPdfModal(true);
                        setCurrentGoal(goal);
                    }}
                    src={SaveIcon}
                />
            </div>
        );
    };

    return (
        <div className="consoleDataTable">
            <div className="detailsGrid my-goals-prob-border-gradient-green">
                {headers.map((header) => (
                    <div key={header} className="consoleDataTableHeaderItem">
                        {header}
                    </div>
                ))}
            </div>
            {goals.length === 0 && <div className="no-goal-result"> No records per current filter</div>}
            {goals.map((goal) => {
                isUpa = goal?.goal_response?.isUpa;
                const avgStatus = Object.keys(priorityOrder ?? {}).find((item) => item === goal.goal_priority) ?? 0;

                let endDateString = goal.goal_key === "plan_retirement" ? goal.end_on_date : goal.achieve_this_goal;
                let startDateString =
                    goal.goal_key === "plan_retirement" ? goal.plan_start_retirement : goal.end_on_date;

                if (goal.goal_key === "plan_retirement") {
                    endDateString = goal.end_on_date;
                    startDateString = goal.plan_start_retirement;
                } else if (goal.goal_key === "draw_income") {
                    endDateString = goal.last_withdrawal;
                    startDateString = goal.start_first_withdrawal;
                } else {
                    endDateString = goal.achieve_this_goal;
                    const currentDate = new Date();
                    const year = currentDate.getFullYear();
                    const month = String(currentDate.getMonth() + 1).padStart(2, "0");
                    const day = String(currentDate.getDate()).padStart(2, "0");
                    startDateString = `${year}-${month}-${day}`; // TODO: need to get this from Chattan
                }

                const createdOn = moment(
                    goal.goal_key === "plan_retirement" ? goal.plan_start_retirement : new Date(),
                    "YYYY-MM-DD"
                );
                const formattedCreatedOn = createdOn.format("MMM YYYY");
                return (
                    <div className="detailsGrid" key={goal._id}>
                        <div className="gridData">
                            <GoalName name={goal.name} goalKey={goal.goal_key} priority={goal.goal_priority} />
                        </div>
                        <div className="gridData">GOE</div>
                        <div className="gridData">{goal.goal_amount}</div>
                        <div className="gridData">{getGoalType(goal.goal_key)}</div>
                        <div className="gridData">{formattedCreatedOn}</div>
                        <div className="gridData">
                            <GoalStatus avgStatus={+avgStatus} goalProbability={goal.goal_probability} />
                        </div>
                        <div className="gridData">
                            <TimeToGoal startDate={startDateString} endDate={endDateString} />
                        </div>
                        <div className="gridData">
                            <ModifyGoalAction
                                goalId={goal._id}
                                cloneGoals={cloneGoals}
                                goal={goal}
                                onEditClicked={() => onEditClicked(goal)}
                            />
                        </div>
                        <div className="gridData">
                            <label className="switch switchGoalType">
                                <input
                                    type="checkbox"
                                    onClick={() => handleClick(goal._id)}
                                    checked={isStatusActive[goal._id]}
                                />
                                <span className="slider round"></span>
                            </label>
                            <div>{isStatusActive[goal._id] ? "Active" : "Inactive"}</div>
                        </div>
                    </div>
                );
            })}
            {currentGoal && (
                <DownloadPdfModal
                    show={showPdfModal}
                    isUpa={isUpa}
                    handleModalOnHide={() => setShowPdfModal(false)}
                    basicInfo={basicInfo}
                    advisorData={advisorData && basicInfo?.advisor_id && advisorData[basicInfo.advisor_id]}
                    goal={currentGoal}
                    portfolioComposition={portfolioComposition}
                />
            )}
        </div>
    );
};
