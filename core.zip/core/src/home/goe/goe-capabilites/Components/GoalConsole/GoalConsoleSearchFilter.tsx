import React, { useState, useMemo } from "react";
import SearchIcon from "../../assets/images/svg/search.svg";
import PlanForRetirementIconSelected from "../../assets/images/svg/goals_icons/plan_retirement.svg";
import PlanForRetirementIcon from "../../assets/images/svg/goals_icons/plan_retirement_dis.svg";
import OwnAHouseIconSelected from "../../assets/images/svg/goals_icons/own_house.svg";
import OwnAHouseIcon from "../../assets/images/svg/goals_icons/own_house_dis.svg";
import SaveForCollegeIconSelected from "../../assets/images/svg/goals_icons/save_college.svg";
import SaveForCollegeIcon from "../../assets/images/svg/goals_icons/save_college_dis.svg";
import BuyACarIconSelected from "../../assets/images/svg/goals_icons/buy_car.svg";
import BuyACarIcon from "../../assets/images/svg/goals_icons/buy_car_dis.svg";
import TakeVacationIconSelected from "../../assets/images/svg/goals_icons/take_vacation.svg";
import TakeVacationIcon from "../../assets/images/svg/goals_icons/take_vacation_dis.svg";
import DrawIncomeIconSelected from "../../assets/images/svg/goals_icons/draw_income.svg";
import DrawIncomeIcon from "../../assets/images/svg/goals_icons/draw_income_dis.svg";
import CustomGoalIconSelected from "../../assets/images/svg/goals_icons/custom_goal.svg";
import CustomGoalIcon from "../../assets/images/svg/goals_icons/custom_goal_dis.svg";
import Slider from "@mui/material/Slider";

import "./styles/goal-console.scss";

export const goalsConfig = {
    own_house: {
        selected: OwnAHouseIconSelected,
        notSelected: OwnAHouseIcon,
        key: "own_house",
    },
    plan_retirement: {
        selected: PlanForRetirementIconSelected,
        notSelected: PlanForRetirementIcon,
        key: "plan_retirement",
    },
    draw_income: {
        selected: DrawIncomeIconSelected,
        notSelected: DrawIncomeIcon,
        key: "draw_income",
    },
    save_collage: {
        selected: SaveForCollegeIconSelected,
        notSelected: SaveForCollegeIcon,
        key: "save_college",
    },

    buy_car: {
        selected: BuyACarIconSelected,
        notSelected: BuyACarIcon,
        key: "buy_car",
    },
    take_vacation: {
        selected: TakeVacationIconSelected,
        notSelected: TakeVacationIcon,
        key: "take_vacation",
    },
    custom_goal: {
        selected: CustomGoalIconSelected,
        notSelected: CustomGoalIcon,
        key: "custom_goal",
    },
};

const activeRiskProfile = ["Conservative", "Moderate", "Aggressive"];
const goals = ["All", "Wealth", "Income"];

export const GoalConsoleSearchFilter = (props: any) => {
    const {
        goal,
        setGoal,
        goalPriority,
        priorityOrder,
        setGoalPriority,
        riskProfile,
        setRiskProfile,
        goalType,
        setGoalType,
        clientName,
        setClientName,
        activeGoalKeys = [],
        goalConsoleData,
        setMinMaxDate,
        setMinMaxGoalAmount,
        defaultMinMaxGoalAmount,
    } = props;
    const [name, setName] = useState(clientName);
    const [dateRange, setDateRange] = useState(["", ""]);
    const activeGoalPriority = Object.keys(priorityOrder).sort((a, b) => priorityOrder[b] - priorityOrder[a]);
    const [value, setValue] = React.useState<number[]>([0, 100]);

    const extractMinMaxGoalAmounts = useMemo(() => {
        return (goalConsoleData) => {
            return goalConsoleData.reduce(
                (acc, { goals }) => {
                    goals.forEach((goal) => {
                        const amount = parseFloat(goal.goal_amount.replace(/\$|,/g, ""));
                        if (acc[0] > amount) acc[0] = amount;
                        if (acc[1] < amount) acc[1] = amount;
                    });
                    return acc;
                },
                [Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY]
            );
        };
    }, []);

    const minMaxGoalAmount = extractMinMaxGoalAmounts(goalConsoleData ?? []) || [0, 100000];
    if (minMaxGoalAmount[0] === minMaxGoalAmount[1]) minMaxGoalAmount[0] = 0;
    if (minMaxGoalAmount[1] === Number.NEGATIVE_INFINITY) minMaxGoalAmount[1] = defaultMinMaxGoalAmount[1];

    const resetFilter = () => {
        setGoal(null);
        setGoalPriority(null);
        setRiskProfile(null);
        setGoalType(null);
        setClientName("");
        setName("");
    };

    const mapPercentToValue = (val: number) => {
        const range = defaultMinMaxGoalAmount[1] - defaultMinMaxGoalAmount[0];
        const converted = defaultMinMaxGoalAmount[0] + (range / 100) * val;
        return converted;
    };

    const handleChange = (event: Event, newValue: number | number[]) => {
        setValue(newValue as number[]);
    };

    const updateMinMaxAmount = (event: React.SyntheticEvent | Event, newValue: number | number[]) => {
        setMinMaxGoalAmount([
            mapPercentToValue(parseInt(newValue[0], 10)),
            mapPercentToValue(parseInt(newValue[1], 10)),
        ]);
    };

    function formatCurrency(number) {
        return `$${number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
    }

    const onBeginDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const date = e.target.value;
        setDateRange([date, dateRange[1]]);
        setMinMaxDate([date, dateRange[1]]);
    };
    const onEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const date = e.target.value;
        setDateRange([dateRange[0], date]);
        setMinMaxDate([dateRange[0], date]);
    };
    return (
        <div className="searchWrapper">
            <div className="my-goals-prob-border-gradient-green console-filter-top">
                <h5 className="subHeading">Select Filter</h5>
                <div className="console-clear-all-filter " onClick={resetFilter}>
                    Reset Filter
                </div>
            </div>

            <div className="searchNameWrapper">
                <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="searchNameInput"
                    placeholder="Search Name"
                />
                <img className="searchIcon" onClick={() => setClientName(name)} src={SearchIcon} />
            </div>

            <div className="goalsWrapper">
                <label className="subtitle">Goals</label>
                <div className="goals">
                    {activeGoalKeys.map((g) => {
                        const { selected, notSelected, key } = goalsConfig[g as keyof typeof goalsConfig];
                        return (
                            <img
                                onClick={() => setGoal(key)}
                                key={key}
                                className="goalItem"
                                src={goal === key ? selected : notSelected}
                            />
                        );
                    })}
                </div>
            </div>

            <div className="goalsPriorityWrapper">
                <label className="subtitle">Goal Priority</label>
                <div className="spanButtonWrapper">
                    {activeGoalPriority.map((eachPriority) => {
                        return (
                            <div
                                onClick={() => setGoalPriority(eachPriority)}
                                key={eachPriority}
                                className={`span-button span-priority ${
                                    goalPriority === eachPriority ? "span-button-selected" : "span-button-unselected"
                                }`}
                            >
                                <span className={`unSelectedPriority selectedPriority`}>{eachPriority}</span>
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className="riskProfileWrapper">
                <label className="subtitle">Risk Profile</label>
                <div className="spanButtonWrapper">
                    {activeRiskProfile.map((eachRisk) => {
                        return (
                            <div
                                onClick={() => setRiskProfile(eachRisk)}
                                key={eachRisk}
                                className={`span-button ${
                                    riskProfile === eachRisk ? "span-button-selected" : "span-button-unselected"
                                }`}
                            >
                                <span className={`unSelectedPriority selectedPriority `}>{eachRisk}</span>
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className="goalAmountWrapper">
                <label className="subtitle">Goal Amount</label>
                <div className="goal-range">
                    <label style={{ width: "70px" }}>{formatCurrency(mapPercentToValue(value[0])) ?? 0} </label>
                    <Slider
                        value={value}
                        onChangeCommitted={updateMinMaxAmount}
                        onChange={handleChange}
                        valueLabelDisplay="off"
                    />
                    <label style={{ width: "auto" }}>{formatCurrency(mapPercentToValue(value[1])) ?? 0} </label>
                </div>

                <div className="riskProfileWrapper">
                    <label className="subtitle">Goals</label>
                    <div className="spanButtonWrapper">
                        {goals.map((goal) => {
                            return (
                                <div
                                    onClick={() => setGoalType(goal)}
                                    key={goal}
                                    className={`span-button ${
                                        goalType === goal ? "span-button-selected" : "span-button-unselected"
                                    }`}
                                >
                                    <span className={`unSelectedPriority selectedPriority `}>{goal}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>

                <div className="subtitle"> Goal Creation Date</div>
                <div className="console-filter-top">
                    <input
                        type="date"
                        onChange={onBeginDateChange}
                        name="creationDate"
                        className="creationDateInput"
                        placeholder="Start Range"
                    />

                    <input
                        type="date"
                        onChange={onEndDateChange}
                        name="creationDate"
                        className="creationDateInput"
                        placeholder="End Range"
                    />
                </div>
            </div>
        </div>
    );
};
