import React from "react";
import ReviewIcon from "../../assets/images/svg/exclamation-circle.svg";
import AlignedIcon from "../../assets/images/svg/progress_more_50.svg";
import UnrealisticIcon from "../../assets/images/svg/circle-xmark.svg";

interface Props {
    goalProbability?: number;
    avgStatus: number;
}

export const GoalStatus = ({ goalProbability, avgStatus }: Props) => {
    if (goalProbability === undefined) return null;

    const stagedConfig = {
        Unrealistic: UnrealisticIcon,
        Review: ReviewIcon,
        Aligned: AlignedIcon,
    };
    const stageData =
        goalProbability === undefined || goalProbability < 0.35
            ? "Unrealistic"
            : goalProbability < avgStatus
            ? "Review"
            : "Aligned";

    return (
        <div className={`console-goal-status-${stageData.toLowerCase()}`} style={{ padding: "0" }}>
            {(goalProbability * 100).toFixed(0)}%:
            <img src={stagedConfig[stageData]} className="my-goals-prob-review-img" />
        </div>
    );
};
