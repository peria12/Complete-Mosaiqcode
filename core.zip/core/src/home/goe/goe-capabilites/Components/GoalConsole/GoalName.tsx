import React from 'react'
import { goalsConfig } from './GoalConsoleSearchFilter'

interface Props {
    goalKey: (keyof typeof goalsConfig)
    priority: string
    name: string
}

export const GoalName = ({ goalKey, priority, name }: Props) => {
    return (
        <div className='goal-name-wrapper'>
            <img src={goalsConfig[goalKey].selected} />
            <div>
                <div>{name}</div>
                <div className='goal-priority'>{priority}</div>
            </div>

        </div>
    )
}