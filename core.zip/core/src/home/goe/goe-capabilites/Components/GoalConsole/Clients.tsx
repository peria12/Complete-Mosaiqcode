import React from "react";
import ToggleDownIcon from "../../assets/images/svg/goal_console/chevron-down.svg";
import ToggleUpIcon from "../../assets/images/svg/goal_console/chevron-up.svg";
import FavoriteIcon from "../../assets/images/svg/goal_console/favorite.svg";
import NonFavoriteIcon from "../../assets/images/svg/goal_console/non_favorite.svg";
import { GoalConsoleDataTable } from "./GoalConsoleDataTable";
import { GoalDetail } from "./GoalConsoleDetails";
import Api from "utils/api";
import { goalsConfig } from "./GoalConsoleSearchFilter";
import { headerGenpayload } from "../../GoeController";

interface ClientsProps {
    clientId: string;
    isFavorite: boolean;
    clientName: string;
    riskProfile: string;
    onFavoriteClick: () => void;
    onToggleClick?: () => void;
    favoriteToggle?: () => void;
    goalKeys?: (keyof typeof goalsConfig)[];
    isExpanded?: boolean;
    goals: GoalDetail[];
    priorityOrder?: string[];
    setLoading?: (loading: boolean) => void;
    filter: () => void;
    basicInfo?: { advisor_id: string; risk_profile: string };
    advisorData?: {
        _id: string;
        advisor_id: string;
    };
    setRoutingPath?: (path: string) => void;
}
export const Clients = ({
    clientName,
    clientId,
    isFavorite,
    goals,
    riskProfile,
    onFavoriteClick,
    setLoading,
    priorityOrder,
    filter,
    basicInfo,
    advisorData,
    setRoutingPath,
}: ClientsProps) => {
    const [isExpanded, setIsExpanded] = React.useState(false);
    const goalKeys = goals.map((goal) => goal.goal_key as unknown as keyof typeof goalsConfig);
    const toggleFavorite = async () => {
        try {
            setLoading?.(true);
            await Api.toggleFavoriteClient(
                {
                    client_id: clientId,
                    is_favorite: !isFavorite,
                },
                headerGenpayload
            );
            onFavoriteClick();
        } catch (e) {
            console.log("error favoriting client", e);
        } finally {
            setLoading?.(false);
        }
    };

    return (
        <div>
            <div
                className="tableWrapper"
                style={{
                    borderRadius: `${isExpanded ? "8px 8px 0 0" : "8px"}`,
                    background: isExpanded ? "rgba(255, 255, 255, 0.60)" : "",
                }}
            >
                <ClientDetails
                    isFavorite={isFavorite}
                    clientName={clientName}
                    riskProfile={riskProfile}
                    onFavoriteClick={toggleFavorite}
                    filter={filter}
                    advisorData={advisorData}
                />
                <ClientGoals
                    goalKeys={goalKeys}
                    onToggleClick={() => setIsExpanded(!isExpanded)}
                    isExpanded={isExpanded}
                    filter={filter}
                />
            </div>
            {isExpanded && (
                <GoalConsoleDataTable
                    goals={goals}
                    priorityOrder={priorityOrder}
                    setLoading={setLoading}
                    filter={filter}
                    basicInfo={basicInfo}
                    advisorData={advisorData}
                    setRoutingPath={setRoutingPath}
                    clientId={clientId}
                />
            )}
        </div>
    );
};

const ClientDetails = ({
    isFavorite = false,
    clientName,
    riskProfile,
    onFavoriteClick,
}: Omit<ClientsProps, "onToggleClick" | "goalKeys" | "clientId" | "goals" | "isExpanded">) => {
    return (
        <div className="clientDetails">
            <img className="favoriteIcon" onClick={onFavoriteClick} src={isFavorite ? FavoriteIcon : NonFavoriteIcon} />
            <div className="clientWrapper">
                <div className="clientHeader">Client Name</div>
                <div className="clientDescription clientName">{clientName}</div>
            </div>
            <div className="clientWrapper">
                <div className="clientHeader">Risk Profile</div>
                <div className="clientDescription">{riskProfile}</div>
            </div>
        </div>
    );
};

const ClientGoals = ({
    goalKeys = [],
    onToggleClick,
    isExpanded,
}: Omit<ClientsProps, "isFavorite" | "goals" | "clientName" | "clientId" | "riskProfile" | "onFavoriteClick">) => {
    return (
        <div className="clientDetails">
            {goalKeys.map((key) => {
                return (
                    <img
                        className="goalItem"
                        style={{ marginRight: "28px", cursor: "default" }}
                        key={key}
                        src={goalsConfig[key].notSelected}
                    />
                );
            })}
            <div className="toggle" onClick={onToggleClick}>
                <img src={isExpanded ? ToggleUpIcon : ToggleDownIcon} />
            </div>
        </div>
    );
};
