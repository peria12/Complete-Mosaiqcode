import React, { useState } from "react";
import DownloadPyFull from "../../../../../../../../core/src/assets/ft-icons/DownloadPhLight.svg";
import DownloadPdfModal from "./DownloadPdfModal";

export const DownloadPdf = ({ basicInfo, advisorData, isUpa, goal, portfolioComposition }) => {
    const [showPdfModal, setShowPdfModal] = useState<boolean>(false);
    const openPdfModal = async () => {
        setShowPdfModal(true);
    };
    return (
        <div>
            <DownloadPdfModal
                show={showPdfModal}
                isUpa={isUpa}
                handleModalOnHide={() => setShowPdfModal(false)}
                basicInfo={basicInfo}
                advisorData={advisorData[basicInfo.advisor_id]}
                goal={goal}
                portfolioComposition={portfolioComposition}
            />
            <img className="goals-modify-icon" onClick={openPdfModal} src={DownloadPyFull} />
        </div>
    );
};
