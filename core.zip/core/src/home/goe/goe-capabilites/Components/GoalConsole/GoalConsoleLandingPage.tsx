import React, { useEffect, useMemo } from "react";
import { GoalConsoleSearchFilter } from "./GoalConsoleSearchFilter";
import { GoalConsoleDetails } from "./GoalConsoleDetails";
import Api from "utils/api";
import { initialConsoleRequest } from "../GoalConsole/utils";
import { concat } from "lodash";
import "./styles/goal-console.scss";
import { headerGenpayload } from "../../GoeController";

export const GoalConsoleLandingPage = ({ setRoutingPath }) => {
    const [loading, setLoading] = React.useState<boolean>(false);
    const [goalConsoleData, setGoalConsoleData] = React.useState([]);
    const [goal, setGoal] = React.useState<string | null>(null);
    const [goalPriority, setGoalPriority] = React.useState<string | null>(null);
    const [riskProfile, setRiskProfile] = React.useState<string | null>(null);
    const [goalType, setGoalType] = React.useState<string>("All");
    const [clientName, setClientName] = React.useState<string>("");
    const [activeGoalKeys, setActiveGoalKeys] = React.useState<string[]>([]);
    const [priorityOrder, setPriorityOrder] = React.useState<string[]>([]);
    const [minMaxGoalAmount, setMinMaxGoalAmount] = React.useState<number[]>([0, 0]);
    const [minMaxDate, setMinMaxDate] = React.useState([undefined, undefined]);
    const [favoriteToggle, setFavoriteToggle] = React.useState<boolean>(false);
    const [defaultAmount, setDefaultAmount] = React.useState([Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY]);
    const [advisorData, setAdvisorData] = React.useState<object>({});

    useEffect(() => {
        const fetchGoalKeys = async () => {
            try {
                setLoading(true);
                const { body = [] } = await Api.getGoalTypes();
                setActiveGoalKeys(body.map((goalKeyObject) => goalKeyObject.goal_key) ?? []);
            } catch (error) {
                return [];
            } finally {
                setLoading(false);
            }
        };
        fetchGoalKeys();
    }, []);

    useEffect(() => {
        // getting the config for advisor console using a dummy request
        setLoading(true);

        Api.advisorConsoleConfig(initialConsoleRequest, headerGenpayload).then((response) => {
            if (response.body) {
                setPriorityOrder(response.body?.pipe_config?.goal_priority_prob_list);
            }
            setLoading(false);
        });
    }, []);

    const extractMinMaxGoalAmounts = useMemo(() => {
        return (goalConsoleData) => {
            return goalConsoleData.reduce(
                (acc, { goals }) => {
                    goals.forEach((goal) => {
                        const amount = parseFloat(goal.goal_amount.replace(/\$|,/g, ""));
                        if (acc[0] > amount) acc[0] = amount;
                        if (acc[1] < amount) acc[1] = amount;
                    });
                    return acc;
                },
                [Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY]
            );
        };
    }, []);

    const goalFilter = async () => {
        const payload = {};
        if (goal) payload["goal_key"] = goal;
        if (goalPriority) payload["goal_priority"] = goalPriority;
        if (riskProfile) payload["risk_profile"] = riskProfile;
        if (goalType && goalType !== "All") {
            payload["goal_type"] = goalType === "Income" ? "retirement" : "regular";
        } else {
            delete payload["goal_type"];
        }
        if (clientName) payload["user_name_search"] = clientName;
        if (minMaxDate[0]) payload["goal_creation_date_min"] = minMaxDate[0];
        if (minMaxDate[1]) payload["goal_creation_date_max"] = minMaxDate[1];

        const goalAmtMin = minMaxGoalAmount[0] === 0 ? defaultAmount[0] : minMaxGoalAmount[0];
        const goalAmtMax = minMaxGoalAmount[1] === 0 ? defaultAmount[1] : minMaxGoalAmount[1];
        if (Number.isFinite(goalAmtMax) && Number.isFinite(goalAmtMin)) {
            payload["goal_amt_min"] = goalAmtMin.toString();
            payload["goal_amt_max"] = goalAmtMax.toString();
        }

        try {
            setLoading(true);
            const { body, unwanted_clients, advisor: advisorInfo } = await Api.filterGoalConsole(payload);

            const unSavedClients = unwanted_clients.map((client) => {
                client.goals = [];
                return client;
            });
            const mergedData = concat(body, unSavedClients);
            if (defaultAmount[0] === Number.POSITIVE_INFINITY && defaultAmount[1] === Number.NEGATIVE_INFINITY) {
                const range = extractMinMaxGoalAmounts(body ?? []);
                if (range[0] === range[1]) range[0] = 0;
                setDefaultAmount(range || [0, 100000]);
            }
            setAdvisorData(advisorInfo);
            setGoalConsoleData(mergedData ?? []);
        } catch (error) {
            return [];
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        goalFilter();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [goal, goalPriority, riskProfile, goalType, clientName, favoriteToggle, minMaxDate, minMaxGoalAmount]);

    return (
        <div className="goalConsoleWrapper">
            {loading && (
                <div className="goal-console-loader-overlay-prob">
                    {" "}
                    <div className="lds-spinner">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            )}

            <h4 className="my-goals-prob-border-gradient-green goalConsoleHeading">Goal Console</h4>
            <div className="goalConsoleContent">
                <div className="goalConsoleContentLeft">
                    <GoalConsoleSearchFilter
                        goal={goal}
                        setGoal={setGoal}
                        goalPriority={goalPriority}
                        setGoalPriority={setGoalPriority}
                        riskProfile={riskProfile}
                        setRiskProfile={setRiskProfile}
                        goalType={goalType}
                        setGoalType={setGoalType}
                        clientName={clientName}
                        setClientName={setClientName}
                        activeGoalKeys={activeGoalKeys}
                        priorityOrder={priorityOrder}
                        goalConsoleData={goalConsoleData}
                        setMinMaxDate={setMinMaxDate}
                        setMinMaxGoalAmount={setMinMaxGoalAmount}
                        defaultMinMaxGoalAmount={defaultAmount}
                    />
                </div>
                <div className="goalConsoleContentRight">
                    <GoalConsoleDetails
                        priorityOrder={priorityOrder}
                        advisorData={advisorData}
                        goalConsoleData={goalConsoleData}
                        favoriteToggle={favoriteToggle}
                        setFavoriteToggle={() => setFavoriteToggle(!favoriteToggle)}
                        setLoading={setLoading}
                        filter={goalFilter}
                        setRoutingPath={setRoutingPath}
                    />
                </div>
            </div>
        </div>
    );
};
