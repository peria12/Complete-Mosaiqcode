import React from "react";
import { Clients } from "./Clients";
import { goalsConfig } from "./GoalConsoleSearchFilter";
import { partition } from "lodash";

import "./styles/goal-console.scss";

export type GoalDetail = {
    _id: string;
    name: string;
    goal_amount: string;
    end_on_date?: string; // for retirement
    achieve_this_goal?: string; // for other goals
    plan_start_retirement?: string; // for retirement
    is_favorite: boolean;
    goal_key: keyof typeof goalsConfig;
    goal_priority: string;
    last_withdrawal: string; // draw income
    start_first_withdrawal: string; // draw income
    goal_probability?: number;
    is_active: boolean;
    goal_response: { api_name: string; isUpa: string; message: string };
    filter: () => void;
};

export const GoalConsoleDetails = ({ goalConsoleData, ...props }: any) => {
    const [favoriteData, nonFavoriteData] = partition(goalConsoleData, (item) => item.is_favorite);
    console.log("goalConsoleData", goalConsoleData);
    console.log(props.advisorData, "advisordata");
    const toggleClientFavorite = () => {
        props.setFavoriteToggle();
    };

    return (
        <div className="goalConsoleDetailsWrapper">
            <div className="goalConsoleDetailsHeader">Favorites</div>

            {favoriteData &&
                favoriteData.map((item) => {
                    return (
                        <Clients
                            key={item._id}
                            clientId={item._id}
                            clientName={item.full_name}
                            isFavorite={item.is_favorite}
                            riskProfile={item.risk_profile}
                            onFavoriteClick={toggleClientFavorite}
                            goals={item.goals ?? []}
                            setLoading={props.setLoading}
                            priorityOrder={props.priorityOrder}
                            filter={props.filter}
                            basicInfo={item}
                            advisorData={props?.advisorData}
                            setRoutingPath={props.setRoutingPath}
                        />
                    );
                })}

            <div className="goalConsoleDetailsHeader"> Other Clients </div>

            {nonFavoriteData &&
                nonFavoriteData.map((item) => {
                    return (
                        <Clients
                            clientId={item._id}
                            key={item._id}
                            clientName={item.full_name}
                            isFavorite={item.is_favorite}
                            riskProfile={item.risk_profile}
                            onFavoriteClick={toggleClientFavorite}
                            goals={item.goals ?? []}
                            setLoading={props.setLoading}
                            priorityOrder={props.priorityOrder}
                            filter={props.filter}
                            basicInfo={item}
                            advisorData={props.advisorData}
                            setRoutingPath={props.setRoutingPath}
                        />
                    );
                })}
        </div>
    );
};
