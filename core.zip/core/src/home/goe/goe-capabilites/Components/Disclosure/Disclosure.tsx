import React, { useState } from "react";
import TermsOfUsage from "./TermsOfUsage";

function Disclosure() {
    const [showTermsPage, setShowTermsPage] = useState(false);
    const showTermsOfPage = () => {
        setShowTermsPage(true);
    };

    return (
        <div className="ft-goe-disclosure">
            <p>
                Goals Optimization Engine (GOE) and any and all data, portfolios, allocations, and illustrations
                (current or future) generated from GOE (Output) are purely hypothetical, do not reflect actual
                investment results, and are provided solely for information purposes within this demo; neither GOE nor
                the Output constitutes investment advice or an investment recommendation by
                <span style={{ whiteSpace: "nowrap", marginLeft: "5px" }}>Franklin Templeton </span> or its affiliates
                or any other person.
                <br />
                <a href="#" onClick={showTermsOfPage}>
                    {" "}
                    Additional information about this investment analysis tool.{" "}
                </a>
            </p>
            <TermsOfUsage show={showTermsPage} onHide={() => setShowTermsPage(false)} />
        </div>
    );
}

export default Disclosure;
