import React, { useState, useEffect } from "react";
import "./GoalAmount.scss";
import TitleBar from "../../../Components/FinancialPlanningTools/TitleBar/TitleBar";
import Vector from "../../../assets/images/svg/Vector.svg";
import Grid from "@mui/material/Grid";
// import axios from "axios";
import DateFnsUtils from "@date-io/date-fns";
import Slider from "@mui/material/Slider";
import Api from "utils/api";
import { MuiPickersUtilsProvider, KeyboardDatePicker } from "@material-ui/pickers";
import { makeStyles } from "@material-ui/core/styles";

function GoalAmount(props: any) {
    const titleName = "What is the right goal amount for you? Take this simple quiz to find out.";
    const [inputData, setInputData] = useState({ goal_id: props.input_data.goal_id });
    const [jsonBody, setJsonBody] = useState({});
    const [calculateAmount, setCalculateAmount] = useState(0);
    const [selectedDate, handleSelectedDateChange] = useState(null);
    const [medianListingPrice, setMedianListingPrice] = useState(0);
    const [goalName, setGoalName] = useState("");
    const [sourceName, setSourceName] = useState("");

    useEffect(() => {
        Api.getGoalData(props.input_data.goal_id)
            .then((response: any) => {
                console.log("response", response);
                setJsonBody(response.body);
            })
            .catch((err) => {
                console.log("error", err);
            });

        if (props.goalJson.goal_key === "own_house") {
            setGoalName("house");
            setSourceName("Realtor.com");
        } else if (props.goalJson.goal_key === "save_collage") {
            setGoalName("college");
            setSourceName("College Board");
        } else if (props.goalJson.goal_key === "buy_car") {
            setGoalName("car");
            setSourceName("Kelly Blue Book");
        } else {
            setGoalName("");
        }
    }, [props.input_data.goal_id, props.goalJson.goal_key]);

    const handleDateChange = (itemname, date) => {
        handleSelectedDateChange(date);
        setInputData({ ...inputData, [itemname]: formatDate(date) });
    };

    const handleChangeInputDollar = (event) => {
        const name = event.target.name;
        let value = event.target.value;
        if (event.target.name === "number_of_nights") {
            setInputData({ ...inputData, [name]: value });
        } else {
            value = event.target.value.replace(/\D/g, "");
            setInputData({ ...inputData, [name]: "$" + parseInt(value.replaceAll("$", "")).toLocaleString() });
        }
    };

    const handleChange = (event) => {
        const name = event.target.name === "type" ? "type_of_college" : event.target.name;
        let value = event.target.value;
        if (event.target.name === "perc_cost") {
            value = value / 100;
        }

        setInputData({ ...inputData, [name]: value });
    };

    const formatDate = (dateData) => {
        const yyyy = dateData.getFullYear();
        let mm = dateData.getMonth() + 1; // Months start at 0!
        let dd = dateData.getDate();
        if (dd < 10) dd = "0" + dd;
        if (mm < 10) mm = "0" + mm;
        const formattedToday = "01" + "-" + mm + "-" + yyyy;
        return formattedToday;
    };

    const now = new Date();
    const today = formatDate(now);
    const calculateDiff = (selected_date: string) => {
        const date1 = new Date(today);
        const date2 = new Date(selected_date);
        const diff = Math.abs(date1.getTime() - date2.getTime());
        const diffDays = Math.ceil(diff / (1000 * 3600 * 24));

        return diffDays;
    };

    const onAccept = () => {
        props.handleClose();
        const number = "$" + calculateAmount.toLocaleString();
        props.onButtonClick("goal_amount", number);
    };

    const getGoalAmountMessage = () => {
        let message = "";
        if (props.goalJson.goal_key === "own_house") {
            message = `Based on a median home price of  $${medianListingPrice.toLocaleString()} in the state of  ${
                inputData["state"]
            }`;
        } else if (props.goalJson.goal_key === "save_collage") {
            message = `Based on an average cost of $${medianListingPrice.toLocaleString()} for a ${
                inputData["type_of_college"]
            } college`;
        } else if (props.goalJson.goal_key === "buy_car") {
            message = `Buy a car : Based on an average cost of $${medianListingPrice.toLocaleString()} for a ${
                inputData["vehicle_category"]
            }`;
        } else {
            message = `Based on a average daily expense`;
        }
        return message;
    };

    const calculateData = async () => {
        if (props.input_data.goal_id === 5) {
            const result =
                (parseInt(inputData["transportation_costs"].replaceAll("$", "").replaceAll(",", "")) +
                    (parseInt(inputData["hotel_per_night"].replaceAll("$", "").replaceAll(",", "")) +
                        parseInt(inputData["food_per_day"].replaceAll("$", "").replaceAll(",", "")) +
                        parseInt(inputData["other_per_day"].replaceAll("$", "").replaceAll(",", ""))) *
                        parseInt(inputData["number_of_nights"])) *
                Math.pow(
                    1,
                    calculateDiff(inputData["plan_take_vacation"].replaceAll("$", "").replaceAll(",", "")) / 365
                );
            setCalculateAmount(Math.floor(result));
        } else {
            Api.calculateGoalAmount(inputData)
                .then((response: any) => {
                    const amount = response.body.goal_amt;
                    setCalculateAmount(amount);
                    if (props.goalJson.goal_key === "save_collage") {
                        setMedianListingPrice(response.body.room_and_boards + response.body.tution_and_fees);
                    } else if (props.goalJson.goal_key === "buy_car") {
                        setMedianListingPrice(response.body.cost);
                    } else {
                        setMedianListingPrice(response.body.median_listing_price);
                    }
                })
                .catch((err) => {
                    console.log("error", err);
                });
        }
    };

    const onButtonClick = (keyname, value) => {
        setInputData({ ...inputData, [keyname]: value === "Yes" ? true : false });
    };

    const useInputStyles = makeStyles({
        root: {
            verticalAlign: "middle",
            fontSize: "16px",
            border: "1px solid #E6E6E6 !important",
            height: "35px",
            width: "100%",
            background: "#FFFFFF",
            borderRadius: "4px",
            paddingLeft: "5px",
            fontFamily: "TT Commons",
            fontStyle: "normal",
            fontWeight: 500,
            lineHeight: "19px",
        },
    });

    const inputClasses = useInputStyles();
    return (
        <div className="modal-goal-amount">
            <div className="outer-main-div-invest">
                <div>
                    <div className="main-div-goal-amt">
                        <TitleBar title={titleName} />
                        <div className="d-flex">
                            <div className="row-div-fpt-rc">
                                <div className="subcontent-div-goal-amt">
                                    {props.input_data.help_data.map((item) => {
                                        return (
                                            <div key={item.id} className="inner-row-div-fpt-rc">
                                                <label className="label-goe-goal-amt">{item.label}</label>
                                                {item.type === "button" ? (
                                                    <div className="d-flex button-input-div-goal-amt">
                                                        {item.options.map((itembutton, index) => {
                                                            return (
                                                                <div
                                                                    onClick={() => onButtonClick(item.name, itembutton)}
                                                                    key={index}
                                                                    className={
                                                                        itembutton ===
                                                                        (inputData[item.name] ? "Yes" : "No")
                                                                            ? "button_goal_amt_quetiontemp"
                                                                            : "button_goal_amt_quetiontemp-disble"
                                                                    }
                                                                >
                                                                    {itembutton}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                ) : item.type === "text" ? (
                                                    <input
                                                        className="input-goe-goal-amt"
                                                        type="text"
                                                        value={inputData[item.name]}
                                                        name={item.name}
                                                        onChange={handleChangeInputDollar}
                                                        placeholder={item.placeholder}
                                                    ></input>
                                                ) : item.type === "range" ? (
                                                    <div className="d-flex">
                                                        <div className="range-slider">
                                                            <div className="range-group">
                                                                <Slider
                                                                    size="small"
                                                                    defaultValue={0}
                                                                    step={5}
                                                                    aria-label="Small"
                                                                    valueLabelDisplay="auto"
                                                                    name={item.name}
                                                                    onChange={handleChange}
                                                                />
                                                            </div>
                                                        </div>
                                                        <input
                                                            disabled
                                                            className="input-range-goe-invest-questiontemp input-goe-invest-questiontemp"
                                                            type="text"
                                                            name={item.name}
                                                            value={
                                                                inputData[item.name] == undefined
                                                                    ? "0 %"
                                                                    : `${Math.floor(inputData[item.name] * 100)} %`
                                                            }
                                                            placeholder={item.placeholder}
                                                        ></input>
                                                    </div>
                                                ) : item.type === "date" ? (
                                                    <div className="d-flex button-input-div-goal-amt">
                                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                            <Grid container sx={{ justifyContent: "space-around" }}>
                                                                <KeyboardDatePicker
                                                                    InputProps={{ classes: inputClasses }}
                                                                    autoOk={true}
                                                                    // openTo="yea"
                                                                    views={["year", "month"]}
                                                                    disableToolbar
                                                                    variant="inline"
                                                                    format="MM-yyyy"
                                                                    margin="normal"
                                                                    name={item.name}
                                                                    style={{ width: "100%", marginTop: "0px" }}
                                                                    id="date-picker-inline"
                                                                    minDate={today}
                                                                    // maxDate={after_thirty_years}
                                                                    value={selectedDate}
                                                                    onChange={(e) => handleDateChange(item.name, e)}
                                                                    KeyboardButtonProps={{
                                                                        "aria-label": "change date",
                                                                    }}
                                                                />
                                                            </Grid>
                                                        </MuiPickersUtilsProvider>
                                                    </div>
                                                ) : (
                                                    <select
                                                        className={
                                                            inputData[
                                                                item.name === "type" ? "type_of_college" : item.name
                                                            ] === undefined
                                                                ? "select-input-goe-goal-amt select-input-goe-goal-amt-before"
                                                                : "select-input-goe-goal-amt"
                                                        }
                                                        name={item.name}
                                                        onChange={handleChange}
                                                    >
                                                        <option value="" selected>
                                                            Select
                                                        </option>
                                                        {jsonBody[item.name] &&
                                                            jsonBody[item.name].map((select_item, index) => {
                                                                return (
                                                                    <option key={index} value={select_item}>
                                                                        {select_item}
                                                                    </option>
                                                                );
                                                            })}
                                                    </select>
                                                )}
                                            </div>
                                        );
                                    })}
                                    <div className="inner-row-div-fpt-rc">
                                        <label className="label-goe-goal-amt"></label>
                                        <div className="button-goal-amt" onClick={() => calculateData()}>
                                            <label className="label-cursor">Calculate</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="amount-div-box">
                                <span className="amount-div-box-span">Your {goalName} goal is estimated to be</span>
                                <div className="amount-div-dollar-span">
                                    <span className="amount-dollar-span">
                                        $ {calculateAmount != 0 && calculateAmount.toLocaleString()}
                                    </span>
                                    <hr className="amount-div-box-hr" />
                                </div>
                                {calculateAmount != 0 ? (
                                    <div className="d-flex amount-message-label-div">
                                        <div>
                                            {" "}
                                            <img src={Vector} className="i-icon-message-label" />
                                        </div>
                                        <span className="amount-div-box-span">{getGoalAmountMessage()}</span>
                                    </div>
                                ) : (
                                    <span className="amount-div-box-span">
                                        Enter details to calculate your goal estimate
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="button-div-goal-amt">
                        <div className="ft-goe-cap-goal-amount-button-div-left">
                            {props.goalJson.goal_key != "take_vacation" && (
                                <span className="label-goe-goal-amt ft-goe-cap-goal-amount-span-div-left">
                                    <i>Source:&nbsp;{sourceName}</i>
                                </span>
                            )}
                        </div>
                        <div className="ft-goe-cap-goal-amount-button-div-left ft-goe-cap-goal-amount-button">
                            <div className="cancel-button-goal-amt" onClick={() => props.handleClose()}>
                                <label className="label-cursor">Cancel</label>
                            </div>
                            <div
                                className={
                                    calculateAmount != 0
                                        ? "button-invest_quetiontemp"
                                        : "button-invest_quetiontemp-disable"
                                }
                            >
                                <label className="label-cursor" onClick={onAccept}>
                                    Accept
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default GoalAmount;
