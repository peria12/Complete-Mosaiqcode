import React from "react";
// import "./style.scss";
import "./GoalOverview.scss";
// import GradientSVG from "./GradientSVG";
// import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
// import "react-circular-progressbar/dist/styles.css";
import RetiermentCal from "../../../assets/images/svg/goals_icons/plan_retirement.svg";
import saveCollege from "../../../assets/images/svg/goals_icons/save_college.svg";
import buyCar from "../../../assets/images/svg/goals_icons/buy_car.svg";
import drawIncome from "../../../assets/images/svg/goals_icons/draw_income.svg";
import ownHouse from "../../../assets/images/svg/goals_icons/own_house.svg";
import takeVacation from "../../../assets/images/svg/goals_icons/take_vacation.svg";
import customGoal from "../../../assets/images/svg/goals_icons/custom_goal.svg";
import RightArrow from "../../../assets/images/svg/Right.svg";
// import TitleBar from "../../../Components/FinancialPlanningTools/TitleBar/TitleBar";
// import DonutChart from "./DonutChart";
// import { Progress } from "antd";
// import PieCharts from "./PieCharts";
import PieChart from "./PieChart";
import DonutChart from "./DonutChart";
function GoalGrid(props: any) {
    const {
        goalItem,
        goalWealthReportAllData,
        goalWealthReportConfigAllData,
        portfolioComposition,
        getgoalLabels,
        // formatDollar,
        setGoalWealthReportData,
        setGoalWealthReportDataConfig,
    } = props;

    const goalWealthReport = goalWealthReportAllData[goalItem["goal-key"]];
    const goalWealthReportConfig = goalWealthReportConfigAllData[goalItem["goal-key"]];

    let goalIcon = RetiermentCal;
    if (goalItem["goal_key"] === "save_collage") {
        goalIcon = saveCollege;
    } else if (goalItem["goal_key"] === "buy_car") {
        goalIcon = buyCar;
    } else if (goalItem["goal_key"] === "take_vacation") {
        goalIcon = takeVacation;
    } else if (goalItem["goal_key"] === "custom_goal") {
        goalIcon = customGoal;
    } else if (goalItem["goal_key"] === "draw_income") {
        goalIcon = drawIncome;
    } else if (goalItem["goal_key"] === "own_house") {
        goalIcon = ownHouse;
    }

    const dateLabel =
        goalItem[
            goalItem["goal_key"] === "plan_retirement"
                ? "plan_start_retirement"
                : goalItem["goal_key"] === "draw_income"
                ? "start_first_withdrawal"
                : "achieve_this_goal"
        ];

    // const findYears = (probData) => {
    //     if (probData != "NA") {
    //         const splitedData = probData.split(";");
    //         let years = 0;

    //         const splitedDataPer = splitedData[1].split(":");
    //         const splitedDataPerT = splitedDataPer[0].trim().split(" ");
    //         if (goalItem["goal_key"] === "plan_retirement") {
    //             splitedDataPerT.forEach((element) => {
    //                 if (Number(element)) {
    //                     years = Number(element);
    //                 }
    //             });
    //         } else {
    //             years = parseInt(splitedDataPerT[3].split("+")[1]);
    //         }
    //         const d = new Date(dateLabel);
    //         const year = d.getFullYear();
    //         const month = d.getMonth();
    //         const day = d.getDate();

    //         const fulldate = new Date(year + years, month, day);
    //         const months = ["Jan", "Feb", "March", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
    //         const convertedDate = months[fulldate.getMonth()] + " " + fulldate.getFullYear();
    //         return convertedDate;
    //     }
    //     return probData;
    // };

    const formatDate = (dateString) => {
        const fulldate = new Date(dateString);
        const months = ["Jan", "Feb", "March", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
        const convertedDate = months[fulldate.getMonth()] + " " + fulldate.getFullYear();
        return convertedDate;
    };

    const currentGoalProb = goalWealthReport["analysisReport"]["currentGoalProbability"].toFixed(2);
    const goalPriorityValue =
        goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][goalItem["goal_priority"]];
    const realisticGoalProb = goalWealthReportConfig["pipe_config"]["realistic_goal_prob"];
    const stageData =
        currentGoalProb < 0.35 ? "Unrealistic" : currentGoalProb < goalPriorityValue ? "Review" : "Aligned";

    const onViewDetails = () => {
        props.setIsOverview({ flag: false, goalKey: goalItem["goal-key"] });
        setGoalWealthReportData(goalWealthReport);
        setGoalWealthReportDataConfig(goalWealthReportConfig);
    };

    return (
        <div>
            <div className="main-div-overview-grid">
                <div className="d-flex">
                    <div className="left-header-div-overview">
                        <img src={goalIcon} className="overview_icon" />
                        <div className="div-header-grid-overview">
                            <span className="span-goal-name">{goalItem["name"]}</span>
                        </div>
                    </div>
                    <div className="priority-div-need-main">
                        <div className={`priority-div-Need priority-div-${goalItem["goal_priority"]}`}>
                            <span className="ft-goe-cap-goal-overview-grid-span">{goalItem["goal_priority"]}</span>
                        </div>
                    </div>
                </div>
                <div className="row-div-overview">
                    <div className="left-side-div-left-overview">
                        <div className={"left-panel-div-overview-aligned left-panel-div-overview"}>
                            <div className="span-div-left-panel-left">
                                <span className="span-left-panel-top">
                                    <b>{goalItem["goal_amount"]}</b>
                                </span>
                                <span className="span-left-panel-subtitle">
                                    {getgoalLabels(goalItem)["yearly_withdrawal"]}
                                </span>
                            </div>
                            <div className="span-div-left-panel-right">
                                <span className="span-left-panel-top">
                                    <b>{formatDate(dateLabel)}</b>
                                </span>
                                <span className="span-left-panel-subtitle">{getgoalLabels(goalItem)["ret_date"]}</span>
                            </div>
                        </div>
                        <div
                            className={
                                "left-panel-div-overview-aligned left-panel-div-overview bottom-left-panel-div-overview"
                            }
                        >
                            <div className="donut-chart-parent-div">
                                <span className="span-bottom-div-chart-s1">Goal Probability </span>
                                <div className="donutchart-div">
                                    <DonutChart
                                        currentGoalProb={currentGoalProb}
                                        realisticGoalProb={realisticGoalProb}
                                        goalPriorityValue={goalPriorityValue}
                                        stageData={stageData}
                                    />
                                </div>
                            </div>
                            <div className="bar-chart-parent-div">
                                <span className="span-bottom-div-chart-s1">Portfolio Composition</span>
                                <div>
                                    <PieChart
                                        portfolioCompositionData={
                                            portfolioComposition[
                                                goalWealthReport["analysisReport"]["recommendedPortfolioId"]
                                            ]
                                        }
                                    />
                                    <div className="div-span-bottom-div-chart-s2">
                                        <span className="equatiy-dot"></span>&nbsp;
                                        <span className="span-bottom-div-chart-s2">Equity</span>&nbsp;&nbsp;
                                        <span className="equatiy-dot fixed-dot"></span>&nbsp;
                                        <span className="span-bottom-div-chart-s2">Fixed Income</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="button-div-goal-overview ">
                <div className="view_details_button" onClick={onViewDetails}>
                    <span className="view_details_span">View Details</span>
                    <img src={RightArrow} />
                </div>
            </div>
        </div>
    );
}

export default GoalGrid;
