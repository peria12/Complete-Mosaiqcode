import React from "react";
import "./GoalPriority.scss";
import TitleBar from "../../../Components/FinancialPlanningTools/TitleBar/TitleBar";
import PriorityArrow from "../../../assets/images/svg/goal_priority/priority_arrow.svg";
import ChartFrame from "../../../assets/images/svg/goal_priority/charts_frame.svg";
import Wish from "../../../assets/images/svg/goal_priority/wish.svg";
import Need from "../../../assets/images/svg/goal_priority/need.svg";
import Want from "../../../assets/images/svg/goal_priority/want.svg";
import Dream from "../../../assets/images/svg/goal_priority/dream.svg";

function GoalPriority(props: any) {
    const titleName = "What is a goal priority? ";
    return (
        <div className="modal-goal-amount">
            <div className="outer-main-div-invest">
                <div className="main-div-goal-priority">
                    <TitleBar title={titleName} />
                    <div className="goal-priority-image-div">
                        <img className="goal-priority-image need-goal-priority-image" src={Need} />
                        <img className="goal-priority-image want-goal-priority-image" src={Want} />
                        <img className="goal-priority-image wish-goal-priority-image" src={Wish} />
                        <img className="goal-priority-image dream-goal-priority-image" src={Dream} />
                    </div>
                    <div className="d-flex ">
                        <div className="goal-priority-span-div">
                            <span className="goal-priority-span">Probability&nbsp;Threshold</span>
                        </div>
                        <img src={PriorityArrow} />
                        <img className="goal-priority-chart-image" src={ChartFrame} />
                    </div>
                </div>
                <div className="button-div-goal-amt-goal-priority">
                    <div className="button-invest_quetiontemp">
                        <label className="label-cursor" onClick={() => props.setshowGoalPriotiy(false)}>
                            Okay
                        </label>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default GoalPriority;
