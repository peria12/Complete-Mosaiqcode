import React from "react";
import * as d3 from "d3";
import { useEffect, useRef } from "react";
import { DataPoint, chartMargin } from "./ForwardLooking";

interface BarChartProps {
    data: DataPoint[];
    chartWidth: number;
    chartHeight: number;
    maxHeight: number;
    isZoomedOut: boolean;
}

const BarChart = ({ data, chartWidth, chartHeight, maxHeight, isZoomedOut }: BarChartProps) => {
    const barRef = useRef<SVGGElement>(null);

    useEffect(() => {
        if (barRef.current && data.length > 0) {
            const xScale = d3
                .scaleBand()
                .domain(data.map((d) => d.date))
                .range([0, chartWidth]);

            const yScale = d3.scaleLinear().domain([0, maxHeight]).range([chartHeight, 0]).nice();

            const svg = d3.select(barRef.current);

            // Remove existing bars before rendering new ones
            svg.selectAll("rect").remove();

            const barGroup = svg.append("g").attr("transform", `translate(${0}, ${chartMargin.top})`);
            barGroup
                .selectAll("rect")
                .data(data)
                .enter()
                .append("rect")
                .attr("x", (d) => xScale(d.date)! + (isZoomedOut ? 13 : 0))
                .attr("y", (d) => yScale(d.value))
                .attr("width", xScale.bandwidth() / 2)
                .attr("height", (d) => chartHeight - yScale(d.value))
                .attr("fill", "url(#gradient)")
                .attr("transform", `translate(0, 0)`);

            // Define the linear gradient
            const gradient = svg
                .append("defs")
                .append("linearGradient")
                .attr("id", "gradient")
                .attr("gradientUnits", "userSpaceOnUse")
                .attr("x1", 0)
                .attr("y1", 0)
                .attr("x2", 0)
                .attr("y2", chartHeight);

            gradient.append("stop").attr("offset", "0%").style("stop-color", "rgba(255, 156, 102, 0.9)");

            gradient.append("stop").attr("offset", "100%").style("stop-color", "rgba(255, 186, 102, 0.9)");
        }
    }, [data, chartWidth, chartHeight, maxHeight, isZoomedOut]);

    return <g ref={barRef} />;
};

export default BarChart;
