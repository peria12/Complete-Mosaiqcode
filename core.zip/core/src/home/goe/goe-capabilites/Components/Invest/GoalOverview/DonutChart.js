import React, { useRef } from "react";
import Highcharts from "highcharts/highcharts.js";
import highchartsMore from "highcharts/highcharts-more.js";
import solidGauge from "highcharts/modules/solid-gauge.js";
import HighchartsReact from "highcharts-react-official";
import ReviewIcon from "../../../assets/images/svg/exclamation-circle.svg";
import AlignedIcon from "../../../assets/images/svg/progress_more_50.svg";
import UnrealisticIcon from "../../../assets/images/svg/circle-xmark.svg";
highchartsMore(Highcharts);
solidGauge(Highcharts);

const DonutChart = (props) => {
  const chartComponentRef = useRef();
  const { currentGoalProb, goalPriorityValue, realisticGoalProb, isProbability, Stage, isUpa, currentGoalProbMod = 0 } = props;
  const currentGoalProbMapping = currentGoalProb < 0.01 ? 0.01 : currentGoalProb > 0.99 ? 0.99 : currentGoalProb;
  const currentGoalProbModMapping = currentGoalProbMod < 0.01 ? 0.01 : currentGoalProbMod > 0.99 ? 0.99 : currentGoalProbMod;
  const stageData =
    (isUpa ? currentGoalProbModMapping : currentGoalProbMapping) < realisticGoalProb
      ? {
        startColor: "#FF3D00",
        endColor: "#DC0546",
        stage: "Unrealistic",
        stageColor: "#DC0546",
        stageIcon: UnrealisticIcon,
        backgroundColor: "#FFDDD2",
        heading: "This goal is unrealistic.",
        content: props.applyRecommendationFlag ? "Please consider editing your goal." : "Please follow below recommendations."
      }
      : (isUpa ? currentGoalProbModMapping : currentGoalProbMapping) < goalPriorityValue
        ? {
          startColor: "#FF9665",
          endColor: "#FAB518",
          stage: "Review",
          stageColor: "#FAB518",
          stageIcon: ReviewIcon,
          backgroundColor: "#FFE9B7",
          heading: `Need to reach the target probability of ${goalPriorityValue * 100}%`,
          content: props.applyRecommendationFlag ? "Please edit the goal parameters to reach target probability." : "Please follow below recommendations."
        }
        : {
          startColor: "#00847D",
          endColor: "#67F5DC",
          stage: "Aligned",
          stageColor: "#00A096",
          stageIcon: AlignedIcon,
          backgroundColor: "#DAFFFB",
          heading: "Superb! No additional action required.",
          content: "The goal is aligned according to its priority."
        };

  const stageData1 = currentGoalProbMapping < realisticGoalProb
    ? {
      startColor: "#FF3D00",
      endColor: "#DC0546",
      stage: "Unrealistic",
      stageColor: "#DC0546",
      stageIcon: UnrealisticIcon,
      backgroundColor: "#FFDDD2",
      heading: "This goal is unrealistic.",
      content: props.applyRecommendationFlag ? "Please consider editing your goal." : "Please follow below recommendations."
    }
    : currentGoalProbMapping < goalPriorityValue
      ? {
        startColor: "#FF9665",
        endColor: "#FAB518",
        stage: "Review",
        stageColor: "#FAB518",
        stageIcon: ReviewIcon,
        backgroundColor: "#FFE9B7",
        heading: `Need to reach the target probability of ${goalPriorityValue * 100}%`,
        content: "Please follow below recommendations."
      }
      : {
        startColor: "#00847D",
        endColor: "#67F5DC",
        stage: "Aligned",
        stageColor: "#00A096",
        stageIcon: AlignedIcon,
        backgroundColor: "#DAFFFB",
        heading: "Superb! No additional action required.",
        content: "The goal is aligned according to its priority."
      };



  const donutData = isUpa ? [
    {
      color: {
        linearGradient: [0, 100],
        stops: [
          [0, stageData.startColor],
          [1, stageData.endColor],
        ],
      },
      radius: "112%",
      innerRadius: "88%",
      y: Math.floor(currentGoalProbModMapping * 100),
    },
    {
      color: {
        linearGradient: [0, 100],
        stops: [
          [0, stageData1.startColor],
          [1, stageData1.endColor],
        ],
      },
      radius: "112%",
      innerRadius: "88%",
      y: Math.floor(currentGoalProbMapping * 100),
    }
  ] : [
    {
      color: {
        linearGradient: [0, 100],
        stops: [
          [0, stageData.startColor],
          [1, stageData.endColor],
        ],
      },
      radius: "112%",
      innerRadius: "88%",
      y: Math.floor(currentGoalProbMapping * 100),
    }
  ]

  const options = {
    chart: {
      type: "solidgauge",
      height: "100%",
    },

    title: {
      text: "",
      style: {
        fontSize: "24px",
      },
    },
    pane: {
      startAngle: 0,
      endAngle: 360,
      background: [
        {
          // Track for Move
          outerRadius: "112%",
          innerRadius: "88%",
          backgroundColor: stageData['backgroundColor'],
          borderWidth: 0,
        },
      ],
    },

    yAxis: {
      min: 0,
      max: 100,
      lineWidth: 0,
      tickPositions: [],
    },
    tooltip: {
      enabled: false,
    },
    plotOptions: {
      solidgauge: {
        size: '170px',
        dataLabels: {
          format:
            isUpa ? `<div style="text-align:center"><span style="
            font-family: 'TT Commons';
            font-style: normal;
            font-weight: 600;
            font-size: 24px;
            line-height: 29px;
            text-align: center;
            color: #000000;">{y}%</span></br><span style="font-family: 'TT Commons';
            font-style: normal;
            font-weight: 600;
            font-size: 16px;
            line-height: 19px;
            text-align: center;
            color: ${stageData.stageColor}"` +
              ">" + `(+${((currentGoalProbModMapping - currentGoalProbMapping) * 100).toFixed(0)}%)</span><br/></div>` : `<div style="text-align:center"><span style="font-size: 20.9092px; font-weight: 600; font-family: TT Commons; color: ${stageData.stageColor}"` +
            ">{y}%</span><br/></div>",
          x: 0,
          y: -20,
          borderWidth: 0,
          useHTML: true,
        },
        linecap: "round",
        stickyTracking: false,
        rounded: true,
      },


    },

    series: [
      {
        name: "",
        data: donutData,
      },
    ],
    credits: { enabled: false }
  };

  return (
    <div>
      {
        isProbability ? <div>
          <div className="my-goals-prob-main-div-review">
            <HighchartsReact
              containerProps={{ style: { height: "150px", width: "150px" } }}
              highcharts={Highcharts}
              options={options}
              ref={chartComponentRef}
            />
            <div className={`my-goals-prob-div-${stageData["stage"]}`}>
              <div className="my-goals-prob-div-review-img">
                <img src={stageData["stageIcon"]} className="my-goals-prob-review-img" />
                &nbsp;
                <span className={`my-goals-prob-donut-span span-bottom-div-chart-s2 span-bottom-div-chart-s2-${stageData["stage"]}`}>{stageData["stage"]}</span>
              </div>
              <div className="d-flex">
                <span className="donut-chart-heading">{stageData.heading}</span>
              </div>
              <div className="d-flex">
                <span className="donut-chart-subcontent">{stageData.content}</span>
              </div>

            </div>
          </div>
        </div> : <div>
          <HighchartsReact
            containerProps={{ style: { height: "150px", width: "150px" } }}
            highcharts={Highcharts}
            options={options}
            ref={chartComponentRef}
          />
          <div className="div-span-bottom-div-chart-left-s2">
            <img src={stageData["stageIcon"]} />
            &nbsp;
            <span className={`span-bottom-div-chart-s2 span-bottom-div-chart-s2-${stageData["stage"]}`}>{stageData["stage"]}</span>
          </div>
        </div>

      }

    </div>
  );
};

export default DonutChart;