import React, { useRef, useEffect } from "react";
import * as d3 from "d3";

import AreaChart from "./AreaChart";
import BarChart from "./BarChart";
import LineChart from "./LineChart";
import ScatterChart from "./ScatterChart";
import FixedLeftAxis from "./FixedLeftAxis";
import FixedRightAxis from "./FixedRightAxis";
import "./ForwardLooking.scss";
import PortfolioValueIcon from "../../../../assets/images/svg/forward_looking/portfolio_value.svg";
import FixedIncomeIcon from "../../../../assets/images/svg/forward_looking/fixed_income.svg";
import EquityIcon from "../../../../assets/images/svg/forward_looking/equity.svg";
import { transformRetirementInfusions } from "../../../../GoeController";
import ZoomIn from "@mui/icons-material/ZoomIn";
import ZoomOut from "@mui/icons-material/ZoomOut";

export const chartMargin = { top: 10, right: 100, bottom: 90, left: 100 };
const maxChartWidth = 1349;
export interface DataPoint {
    date: Date;
    value: number;
}

interface ForwardLookingProps {
    startDate: string;
    endDate: string;
    goalWealthReport: any;
    goalType: string;
    addedGoalList: any;
    portfolioComposition: Record<string, { equity: number; fixed_income: number }>;
    isShowInPDF?: boolean; //isPdfView = false
}

const ForwardLooking = ({
    startDate,
    goalWealthReport,
    goalType,
    addedGoalList,
    portfolioComposition,
    isShowInPDF = false,
}: ForwardLookingProps) => {
    const chartRef = useRef<SVGSVGElement>(null);
    const [chartWrapper, setChartWrapper] = React.useState<any>(null);
    const [chartWidth, setChartWidth] = React.useState(0);
    const [retirementInfusions, setRetirementInfusions] = React.useState<number[]>([]);
    const [displayEquityExposure, setDisplayEquityExposure] = React.useState(isShowInPDF ? true : false);
    const [isZoomedOut, setZoomedOut] = React.useState(true);
    const [showZoom, setShowZoom] = React.useState(false);
    const portfolioPath: number[] = goalWealthReport["pathReport"]["portfolioPath"];
    const chartHeight = 500 - chartMargin.top - chartMargin.bottom;

    const dateParts = startDate.split(" ")[0].split("-");
    const year = parseInt(dateParts[2], 10);
    const month = parseInt(dateParts[1], 10) - 1;
    const day = parseInt(dateParts[0], 10);
    const start = new Date(year, month, day);

    const areaChartCurrentDate = new Date(start);
    const areaChartData: DataPoint[] = goalWealthReport["pathReport"]["wealthPath"].reduce(
        (acc: DataPoint[] = [], curr) => {
            const dateValuePair = { date: new Date(areaChartCurrentDate), value: curr };
            areaChartCurrentDate.setFullYear(areaChartCurrentDate.getFullYear() + 1);
            return [...acc, { ...dateValuePair }];
        },
        []
    );
    const barChartCurrentDate = new Date(start);
    const barChartData: DataPoint[] = retirementInfusions.reduce((acc: DataPoint[] = [], curr) => {
        const dateValuePair = { date: new Date(barChartCurrentDate), value: curr > 0 ? 0 : -curr };
        barChartCurrentDate.setFullYear(barChartCurrentDate.getFullYear() + 1);
        return [...acc, { ...dateValuePair }];
    }, []);
    const scatterChartCurrentDate = new Date(start);
    const donutChartData = portfolioPath?.map((path) => portfolioComposition[path]) ?? [];
    const scatterChartData: DataPoint[] = donutChartData.reduce((acc: DataPoint[] = [], curr) => {
        const dateValuePair = { date: new Date(scatterChartCurrentDate), value: curr?.equity * 100 };
        scatterChartCurrentDate.setFullYear(scatterChartCurrentDate.getFullYear() + 1);
        return [...acc, { ...dateValuePair }];
    }, []);
    useEffect(() => {
        const retirementGoal = addedGoalList.find((goal: any) => goal.goal_key === "plan_retirement");
        if (retirementGoal) {
            setRetirementInfusions(transformRetirementInfusions(retirementGoal, false, 0));
        }
        if (areaChartData.length < 16) {
            setShowZoom(false);
            setZoomedOut(false);
        } else {
            setZoomedOut(true);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [goalType, addedGoalList]);

    useEffect(() => {
        if (areaChartData.length < 16 || isZoomedOut) {
            setShowZoom(isZoomedOut);
            setChartWidth(maxChartWidth - chartMargin.left - chartMargin.right);
        } else {
            setShowZoom(true);
            setChartWidth(areaChartData.length * 100 - chartMargin.left - chartMargin.right);
        }
    }, [goalType, areaChartData.length, isZoomedOut]);

    useEffect(() => {
        if (chartRef.current && chartWidth > 0) {
            // Select x-axis and remove them to prevent overlapping
            d3.select(".x-axis").remove();

            const svg = d3
                .select(chartRef.current)
                .attr("width", chartWidth)
                .attr("height", chartHeight + chartMargin.top + chartMargin.bottom);

            // scales for the charts
            const xScale = d3
                .scaleTime()
                .domain([areaChartData[0].date, areaChartData[areaChartData.length - 1].date])
                .range([0, chartWidth]);

            const xAxis = d3
                .axisBottom(xScale)
                .tickValues(areaChartData.map((d) => d.date).slice(0, -1))
                .tickFormat(d3.timeFormat("%Y"));

            svg.selectAll("text").remove();

            // Add x-axis
            const xAxisValues = svg
                .append("g")
                .attr("class", "x-axis")
                .attr("transform", `translate(20, ${chartHeight + chartMargin.top})`)
                .call(xAxis)
                .selectAll("text")
                .style("font-size", "16px")
                .style("line-height", "19px")
                .style("font-weight", "400")
                .style("font-family", "TT Commons");

            if (isZoomedOut) {
                // make xAxis vertical
                xAxisValues
                    .style("text-anchor", "end")
                    .attr("dx", "-10px")
                    .attr("dy", "-5px")
                    .attr("transform", "rotate(-90)");
            }

            // Hide x-axis tick lines
            svg.selectAll(".x-axis path.domain").style("display", "none");
            svg.selectAll(".tick line").style("display", "none");

            // get the width of the main chart body
            const chartWrapperWidth = document.getElementById("forward-looking-chart")?.offsetWidth;
            if (chartWrapperWidth) {
                setChartWrapper(chartWrapperWidth);
            }
        }
    }, [chartWidth, chartHeight, areaChartData, chartWrapper, isZoomedOut]);

    return (
        <div className="div-forward-looking-wrapper">
            <div className={!isShowInPDF ? "main-div-forward-looking" : "pdf-main-div-forward-looking"}>
                <div className="my-goals-prob-border-gradient-green space-between">
                    <span className="main-div-goal-probability-span">Portfolio Value </span>
                    {showZoom && (
                        <span className="span-equity-exposure">
                            <label className={`${!isZoomedOut ? "label-grey-out" : "zoom"}`}>
                                <ZoomIn
                                    fontSize="medium"
                                    onClick={() => {
                                        if (isZoomedOut) setZoomedOut(!isZoomedOut);
                                    }}
                                />
                            </label>
                            <label className={`${isZoomedOut ? "label-grey-out" : "zoom"}`}>
                                <ZoomOut
                                    fontSize="medium"
                                    onClick={() => {
                                        if (!isZoomedOut) setZoomedOut(!isZoomedOut);
                                    }}
                                />
                            </label>
                        </span>
                    )}
                </div>
                <div className="div-flex-container">
                    <div className="div-chart-legend-left">
                        <li className="list-legend-left">
                            <img className="img-legend" src={PortfolioValueIcon} />
                            Portfolio Value
                        </li>
                        {goalType === "plan_retirement" && (
                            <li className="list-legend-left legend-withdrawal">Withdrawals</li>
                        )}
                        {displayEquityExposure && (
                            <>
                                <li className="list-legend-left">
                                    <img className="img-legend" src={EquityIcon} />
                                    Equity
                                </li>
                                <li className="list-legend-left">
                                    <img className="img-legend" src={FixedIncomeIcon} />
                                    Fixed Income
                                </li>
                            </>
                        )}
                    </div>
                    {!isShowInPDF && (
                        <div>
                            Equity Exposure:
                            <span className="span-equity-exposure">
                                <label className={`${!displayEquityExposure && "label-grey-out"}`}>Hide</label>
                                <label className="switch switch-equity-exposure">
                                    <input
                                        type="checkbox"
                                        onChange={() => setDisplayEquityExposure(!displayEquityExposure)}
                                    />
                                    <span className="slider round"></span>
                                </label>
                                <label className={`${displayEquityExposure && "label-grey-out"}`}>Show</label>
                            </span>
                        </div>
                    )}
                </div>
                <div style={{ display: "flex" }}>
                    <FixedLeftAxis chartHeight={chartHeight} data={areaChartData} />
                    <div
                        id="forward-looking-chart"
                        style={{
                            width: "100%",
                            maxWidth: `${maxChartWidth + chartMargin.left + chartMargin.right}px`,
                            overflowX: "scroll",
                            position: "relative",
                            marginLeft: "20px",
                        }}
                    >
                        <svg ref={chartRef} className="d-flex" overflow="auto" width={"100%"} height={chartHeight}>
                            <AreaChart data={areaChartData} chartWidth={chartWidth} chartHeight={chartHeight} />

                            {displayEquityExposure && (
                                <LineChart
                                    isZoomedOut={isZoomedOut}
                                    donutChartData={donutChartData}
                                    data={scatterChartData}
                                    chartWidth={chartWidth}
                                    chartHeight={chartHeight}
                                    startDate={areaChartData[0].date}
                                    endDate={areaChartData[areaChartData.length - 1].date}
                                />
                            )}

                            {goalType === "plan_retirement" && (
                                <BarChart
                                    data={barChartData.slice(0, -1)}
                                    chartWidth={chartWidth}
                                    chartHeight={chartHeight}
                                    isZoomedOut={isZoomedOut}
                                    maxHeight={Math.ceil(Math.max(...areaChartData.map((d) => d.value)))}
                                />
                            )}
                        </svg>
                        {displayEquityExposure && (
                            <ScatterChart
                                isZoomedOut={isZoomedOut}
                                donutChartData={donutChartData}
                                data={scatterChartData}
                                chartWidth={chartWidth}
                                chartHeight={chartHeight}
                                startDate={areaChartData[0].date}
                                endDate={areaChartData[areaChartData.length - 1].date}
                            />
                        )}
                    </div>

                    <FixedRightAxis displayEquityExposure={displayEquityExposure} chartHeight={chartHeight} />
                </div>
            </div>
        </div>
    );
};

export default ForwardLooking;
