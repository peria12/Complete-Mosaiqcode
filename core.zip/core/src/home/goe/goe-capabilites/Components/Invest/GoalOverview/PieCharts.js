import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';

const PieCharts = () => {
  const data = [
    {
      Equity: 'equity',
      FixedIncome: 70,
    },
    {
      Equity: 'fixed',
      FixedIncome: 30,
    },
  ];
  const config = {
    // appendPadding: 10,
    data,
    angleField: 'FixedIncome',
    colorField: 'Equity',
    radius: 0.8,
    legend: false,
    height:135,
    width:140,
    label: {
      type: 'inner',
      offset: '-50%',
      style: {
        fill: '#fff',
        fontSize: 10,
        textAlign: 'center',
      },
    },
    pieStyle: ({ Equity }) => {
      if (Equity === 'equity') {
        return {
          fill: '#FF9665',
        };
      }

      return {
        fill: '#00A096',
      };
    },
    tooltip: false,
    // interactions: [
    //   {
    //     type: 'element-single-selected',
    //   }
    // ],
  };
  return <></>
};

export default PieCharts;


// import React from "react";
// import { render } from "react-dom";
// // Import Highcharts
// import Highcharts from "highcharts/highstock";
// //import HighchartsReact from "./HighchartsReact.js";
// import PieChart from "highcharts-react-official";

// const PieCharts = () => {
//   var pieColors = (function () {
//     var colors = ['#00A096','#FAB518'];
//     return colors;
// }());

// const options = {
//     chart: {
//         plotBackgroundColor: null,
//         plotBorderWidth: null,
//         plotShadow: false,
//         type: 'pie'
//     },
//     tooltip: {
//         pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
//     },
//     accessibility: {
//         point: {
//             valueSuffix: '%'
//         }
//     },
//     plotOptions: {
//         pie: {
//             allowPointSelect: true,
//             cursor: 'pointer',
//             colors: pieColors,
//             dataLabels: {
//                 enabled: true,
//                 format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
//                 distance: -50,
//                 filter: {
//                     property: 'percentage',
//                     operator: '>',
//                     value: 4
//                 }
//             }
//         }
//     },
//     series: [{
//         name: 'Share',
//         data: [
//             { name: '', y: 90},
//             { name: '', y: 10 }
//         ]
//     }]
// };

//   return <PieChart highcharts={Highcharts} options={options} />

// };

// export default PieCharts;