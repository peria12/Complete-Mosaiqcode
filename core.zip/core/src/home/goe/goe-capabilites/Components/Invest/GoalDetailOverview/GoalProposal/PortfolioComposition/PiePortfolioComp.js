import React, { useRef } from 'react';
import * as Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';


const PiePortfolioComp = (props) => {
  const {portfolioData,colorMappingFixedIncome,colorMappingEquity} = props;
  const chartComponentRef = useRef()
  
  const colorMapping = colorMappingEquity.concat(colorMappingFixedIncome)
  const pieChartData = portfolioData.map((item,index)=>{
    return {
      name:item.asset_key,
      y:Math.ceil((Math.round(item.port_value * 100) / 100).toFixed(2)*100),
      color:colorMapping[index]
    }
  })

  const options = {
    chart: {
      backgroundColor:'transparent',
      // plotBackgroundColor: null,
      // plotBorderWidth: null,
      // plotShadow: false,
      type: 'pie',
      // height:'100%'
    },
    title: {
      text: ' ',
      align: 'left',
    },
    tooltip:{
      enabled: true,
      formatter: function () {
        if(this.y<10){
        const header = `<span style="color: blue;">${this.key}<br>${this.y} %</span><br/>`
        return header
        }
        else{
          return false
        }
      }
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        borderWidth: 0,
        // colors: pieColors,
        size: '170px',
        // height: '100%',
        // width:'100%',
        // colors:colorMapping,
        dataLabels: {
            enabled: true,
            // format: `<div><span style="font-family: 'TT Commons';fill=none; stroke:none; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; display: flex; align-items: center; text-align: center; color: #FFFFFF;">{point.percentage:.1f} %</div>`,
            distance: -30,
            formatter: function() {
              if (this.y > 10 ) {
                  // this.point.dataLabels.color = 'red';
                  // this.point.dataLabels.distance = 20;
                  return `<div><span style="font-family: 'TT Commons';fill=none; stroke:none; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; display: flex; align-items: center; text-align: center; color: #FFFFFF;">${this.y} %</div>`
              } else {
                  return ""
              }

      }
        },
    }
    ,
    },
    series: [
      {
        name: '',
        data: pieChartData,
      },
    ],
    credits: { enabled: false }
  };
  return (
    <HighchartsReact
      // containerProps={{ style: { height: "170", width:"170"} }}
      highcharts={Highcharts}
      options={options}
      ref={chartComponentRef}
    />
  );
};

export default PiePortfolioComp;