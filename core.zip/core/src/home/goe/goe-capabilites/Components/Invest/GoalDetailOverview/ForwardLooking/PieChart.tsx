interface PieChartData { label: string, value: number }
import { DataPoint } from "./ForwardLooking";
import * as d3 from "d3";

interface PieChartProps {
    data: PieChartData[];
    isZoomed?: boolean;
}

const createPieChartSvg = ({ data }: PieChartProps): SVGSVGElement | null => {
    const width = 90;
    const height = 90;
    const svg = d3
        .create("svg")
        .attr("width", width)
        .attr("height", height)
        .attr("viewBox", [-width / 2, -height / 2, width, height])
        .attr("style", "max-width: 100%; height: auto; font: 10px sans-serif;");

    const radius = Math.min(width, height) / 2;
    const arc = d3
        .arc<DataPoint>()
        .innerRadius(0)
        .outerRadius(radius - 1);

    const pie = d3
        .pie<DataPoint>()
        .value((d) => d.value)
        .sort(null);

    const labelRadius = arc.outerRadius()() * 0.5;

    // A separate arc generator for labels.
    const arcLabel = d3.arc().innerRadius(labelRadius).outerRadius(labelRadius);

    const equityGradient = svg.append("defs").append("linearGradient").attr("id", "equityGradient");

    equityGradient.append("stop").attr("offset", "0%").attr("stop-color", "#00A096");

    equityGradient.append("stop").attr("offset", "100%").attr("stop-color", "#01D6C8");

    const fixedIncomeGradient = svg.append("defs").append("linearGradient").attr("id", "fixedIncomeGradient");

    fixedIncomeGradient.append("stop").attr("offset", "0%").attr("stop-color", "#FF9665");
    fixedIncomeGradient.append("stop").attr("offset", "100%").attr("stop-color", "#FAB518");

    const color = d3.scaleOrdinal<string>().domain([0, 1]).range(["url(#fixedIncomeGradient)", "url(#equityGradient)"]);

    svg.append("g")
        .attr("stroke", "white")
        .selectAll()
        .data(pie(data))
        .join("path")
        .attr("fill", (d, i) => color(i))
        .attr("d", arc);

    return svg.node() as SVGSVGElement;
};

export default createPieChartSvg;