import React from 'react';
import * as Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

const PieChart = (props) => {
  const { portfolioCompositionData, width = '150px', height = '150px' } = props;
  const chartComponentRef = React.useRef()
  const options = {
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      type: 'pie',
      height: '100%'
    },
    title: {
      text: ' ',
      align: 'left',
    },
    tooltip: {
      enabled: false,
      valueDecimals: 0
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        borderWidth: 0,
        size: '100%',
        height: '100%',
        width: '100%',
        tooltip: {
          enabled: false,
          valueDecimals: 0
        },
        dataLabels: {
          enabled: true,
          formatter: function () {
            return `<div><span style="font-family: 'TT Commons';fill=none; stroke:none; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; display: flex; align-items: center; text-align: center; color: #FFFFFF;">${Math.round(this.y)}%</div>`
          },
          distance: -30,
        },
      }
      ,
    },
    series: [
      {
        name: '',
        data: [
          {
            name: '',
            y: Number(portfolioCompositionData['fixed_income'] * 100),
            color: {
              linearGradient: [0, 100],
              stops: [
                [0, '#00A096'],
                [1, '#01D6C8'],
              ],
            },
          },
          {
            name: '',
            y: Number(portfolioCompositionData['equity'] * 100),
            color: {
              radialGradient: [30, 130],
              stops: [
                [0, '#FF9665'],
                [1, '#FAB518'],
              ],
            },
          }
        ],
      },
    ],
    credits: { enabled: false }
  };
  return (
    <HighchartsReact
      containerProps={{ style: { height, width } }}
      highcharts={Highcharts}
      options={options}
      ref={chartComponentRef}
    />
  );
};

export default PieChart;