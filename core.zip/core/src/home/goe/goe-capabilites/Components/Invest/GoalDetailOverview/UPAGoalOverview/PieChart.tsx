import * as d3 from "d3";
import { IChartData } from "home/goe/common/interfaces";

interface PieChartProps {
    initialData: { equity: number; fixed_income: number };
    isZoomed?: boolean;
    isLabelVisible?: boolean;
}

const createPieChartSvg = ({
    initialData,
    isZoomed = false,
    isLabelVisible = false,
}: PieChartProps): SVGSVGElement | null => {
    const width = isZoomed ? 90 : 45;
    const height = isZoomed ? 90 : 45;

    const data: { label: string; value: number }[] = Object.keys(initialData).map((key) => {
        return { label: key, value: initialData[key] * 100 };
    });

    const svg = d3
        .create("svg")
        .attr("width", width)
        .attr("height", height)
        .attr("viewBox", [-width / 2, -height / 2, width, height])
        .attr("style", "max-width: 100%; height: auto; font: 10px sans-serif;");

    const radius = Math.min(width, height) / 2;
    const arc = d3
        .arc<IChartData>()
        .innerRadius(0)
        .outerRadius(radius - 1);

    const pie = d3
        .pie<IChartData>()
        .value((d) => d.value)
        .sort(null);

    const equityGradient = svg.append("defs").append("linearGradient").attr("id", "equityGradient");

    equityGradient.append("stop").attr("offset", "0%").attr("stop-color", "#00A096"); // deep green

    equityGradient.append("stop").attr("offset", "100%").attr("stop-color", "#01D6C8"); // light green

    const fixedIncomeGradient = svg.append("defs").append("linearGradient").attr("id", "fixedIncomeGradient");

    fixedIncomeGradient.append("stop").attr("offset", "0%").attr("stop-color", "#FF9665"); // deep orange

    fixedIncomeGradient.append("stop").attr("offset", "100%").attr("stop-color", "#FAB518"); // light orange

    const color = d3.scaleOrdinal<string>().domain([0, 1]).range(["url(#fixedIncomeGradient)", "url(#equityGradient)"]);

    svg.append("g")
        .attr("stroke", "white")
        .selectAll()
        .data(pie(data))
        .join("path")
        .attr("fill", (d, i) => color(i))
        .attr("d", arc);

    if (isLabelVisible) {
        const labelRadius = arc.outerRadius()() * 0.5;

        // A separate arc generator for labels.
        const arcLabel = d3.arc().innerRadius(labelRadius).outerRadius(labelRadius);

        svg.append("g")
            .attr("text-anchor", "middle")
            .selectAll()
            .data(pie(data))
            .join("text")
            .attr("transform", (d) => `translate(${arcLabel.centroid(d)})`)
            .call(
                (text) =>
                    text.append("tspan").attr("font-weight", "bold").attr("font-size", "80%").attr("fill", "#FFFFFF")
                // .text((d) => `${d.value}%`)
            );
    }

    return svg.node() as SVGSVGElement;
};

export default createPieChartSvg;
