import React, { useLayoutEffect, useState, useContext, useMemo } from "react";
import "./GoalDetailOverview.scss";
import MyGoals from "./MyGoals/MyGoals";
import GoalProposal from "./GoalProposal/GoalProposal";
import GoalProposalUPA from "./GoalProposal/GoalProposalUPA";
import ForwardLooking from "./ForwardLooking/ForwardLooking";
import { GoeCapabilitiesContext } from "../../../GoeCapabilitiesContext";
import GOEOverviewGraph from "./GOEGoalOverview/GOEOverViewGraph";
import UPAOverviewGraph from "./UPAGoalOverview/UPAOverViewGraph";
import BackArrow from "../../../assets/images/svg/arrow-left-back.svg";

function GoalDetailOverview(props: any) {
    const {
        addedGoalList,
        goalWealthReport,
        goalWealthReportConfig,
        goalKeyP,
        getgoalLabels,
        formatDollar,
        findYears,
        setGoalWealthReport,
        digitFromator,
        setJourneyPath,
        setOverview,
        setActiveGoal,
        setGoalQuestionnaire,
        setGoalEditType,
        goalWealthReportPayload,
        goalWealthReportConfigPayload,
        setGoalWealthReportDataConfig,
        setGoalWealthReportData,
        isUpa,
        goalUpaReport,
        goalUpaReportConfig,
        portfolioComposition,
        goBackClick,
        saveProposalData,
        setRoutingPath,
    } = props;
    const { name, riskProfile } = useContext(GoeCapabilitiesContext);
    const basicInfo = { name: name, risk_profile_type: riskProfile };

    const goalList = useMemo(() => props.addedGoalList || [], [props.addedGoalList]);

    const goalPrioritys = useMemo(() => ["Need", "Want", "Wish", "Dream"], []);
    const [goalDetailSection, setGoalDetailSection] = useState(isUpa ? "Original Plan" : "Proposal");
    const [seeOverviewFlag, setSeeOverviewFlag] = useState(true);
    const [applyRecommendationFlag, setApplyRecommendationFlag] = useState(false);
    const [viewDetails, setViewDetails] = useState(false);

    const [goalKey, setGoalKey] = useState(goalKeyP);
    // const [goalData,setgoalData]=useState([]);
    const goalData =
        goalList.filter((goal) => {
            return goal["goal-key"] === goalKey;
        }) || [];

    useLayoutEffect(() => {
        const goalsKey: string[] = [];

        setGoalEditType("EDIT");
        if (!goalKey) {
            goalPrioritys.map((goalPriority) => {
                const priorityGoals =
                    goalList.filter((goal) => {
                        return goal["goal_priority"] === goalPriority;
                    }) || [];

                if (priorityGoals.length > 0) {
                    priorityGoals.map((goalItem: any) => {
                        // return goalItem["goal-key"]

                        goalsKey.push(goalItem["goal-key"]);
                        // return goalItem["goal-key"]
                    });
                }
            });
            setGoalKey(() => goalsKey[0]);
        }
    }, [goalKey, setGoalEditType, goalPrioritys, goalList]);
    const setGoalData = (goalId) => {
        const goalData =
            goalList.filter((goal) => {
                return goal["goal-key"] === goalId;
            }) || [];

        setGoalWealthReportData(() => goalWealthReportPayload[goalId]);
        setGoalWealthReportDataConfig(() => goalWealthReportConfigPayload[goalId]);

        setApplyRecommendationFlag(false);
        setViewDetails(!viewDetails);
        const goalPriorityValueArr = [0];
        let initialInvestment = 0;
        const unFormaAmount = (formatterNUmber) => {
            if (typeof formatterNUmber != "number") {
                return Number(formatterNUmber.replace(/[$,]/g, ""));
            }
            return formatterNUmber;
        };
        const goalWealthReport = goalWealthReportPayload[goalId];
        const goalWealthReportConfig = goalWealthReportConfigPayload[goalId];
        addedGoalList.forEach((item) => {
            const goalProbData =
                goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][item["goal_priority"]];
            initialInvestment = initialInvestment + unFormaAmount(item["initial_investment"]);

            goalPriorityValueArr.push(goalProbData);
        });
        const currentGoalProb = goalWealthReport["analysisReport"]["currentGoalProbability"].toFixed(2);
        // const currentGoalProb = 0.80
        const goalPriorityValue =
            goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][goalData[0]["goal_priority"]];
        const stageData =
            currentGoalProb < 0.35 ? "Unrealistic" : currentGoalProb < goalPriorityValue ? "Review" : "Aligned";

        if (stageData === "Aligned") {
            setApplyRecommendationFlag(true);
            setViewDetails(false);
        }
        if (!isUpa) {
            findYears(goalWealthReport["analysisReport"]["recommendedTenure"]);
            if (
                goalData[0]["goal_key"] === "plan_retirement" &&
                goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0 &&
                (goalData[0]["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"]) == 0 &&
                (goalData[0]["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"]) &&
                goalWealthReport["analysisReport"]["recommendedTenure"] == "NA"
            ) {
                setApplyRecommendationFlag(true);
                setViewDetails(false);
            } else if (
                goalData[0]["goal_key"] === "draw_income" &&
                goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0 &&
                (goalData[0]["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpDecumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpDecumulation"])
            ) {
                setApplyRecommendationFlag(true);
                setViewDetails(false);
            } else if (
                goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0 &&
                (goalData[0]["contribution_time"] === "month"
                    ? goalWealthReport["analysisReport"]["monthlyTopUpAccumulation"]
                    : goalWealthReport["analysisReport"]["yearlyTopUpAccumulation"]) == 0 &&
                goalWealthReport["analysisReport"]["recommendedTenure"] == "NA"
            ) {
                setApplyRecommendationFlag(true);
                setViewDetails(false);
            }
        } else {
            if (goalWealthReport["analysisReport"]["oneTimeTopUp"] == 0) {
                setApplyRecommendationFlag(true);
                setViewDetails(false);
            }
        }
        setGoalKey(goalId);
    };

    return (
        <div className="">
            <div className="div-details-overview-backbutton label-cursor" onClick={goBackClick}>
                <img className="img-overview-backbutton" src={BackArrow} />
                &nbsp;<span className="span-overview-backbutton">Back</span>
            </div>
            <MyGoals
                addedGoalList={props.addedGoalList}
                goalPrioritys={goalPrioritys}
                goalKey={goalKey}
                goalData={goalData}
                seeOverviewFlag={seeOverviewFlag}
                setSeeOverviewFlag={setSeeOverviewFlag}
                isUpa={isUpa}
                setGoalData={setGoalData}
            />
            <div className="div-placeholderdetails">
                <div className="div-placeholderdetails-left">
                    <span className="div-placeholderdetails-left-span">
                        <b>
                            {isUpa
                                ? ""
                                : seeOverviewFlag
                                ? goalData.length > 0
                                    ? goalData[0]["name"]
                                    : ""
                                : "Overview"}
                        </b>
                    </span>
                </div>
                {seeOverviewFlag && (
                    <div className="div-placeholderdetails-right">
                        <div
                            className="inner-div-placeholderdetails"
                            onClick={() => setGoalDetailSection(isUpa ? "Original Plan" : "Proposal")}
                        >
                            <span
                                className={
                                    goalDetailSection === "Proposal" || goalDetailSection === "Original Plan"
                                        ? "inner-div-placeholderdetails-span inner-div-placeholderdetails-span-enable"
                                        : "inner-div-placeholderdetails-span"
                                }
                            >
                                {isUpa ? "Original Plan" : "Proposal"}
                            </span>
                        </div>
                        <div
                            className="inner-div-placeholderdetails"
                            onClick={() => setGoalDetailSection(isUpa ? "Optimized Plan" : "Forward looking")}
                        >
                            <span
                                className={
                                    goalDetailSection === "Forward looking" || goalDetailSection === "Optimized Plan"
                                        ? "inner-div-placeholderdetails-span inner-div-placeholderdetails-span-enable"
                                        : "inner-div-placeholderdetails-span"
                                }
                            >
                                {isUpa ? "Optimized Plan" : "Forward looking"}
                            </span>
                        </div>
                    </div>
                )}
            </div>
            {seeOverviewFlag ? (
                goalDetailSection === (isUpa ? "Original Plan" : "Proposal") ? (
                    <div>
                        <GoalProposal
                            formatDollar={formatDollar}
                            getgoalLabels={getgoalLabels}
                            goalDataPriority={goalData}
                            goalWealthReportConfig={goalWealthReportConfig}
                            goalWealthReport={goalWealthReport}
                            addedGoalList={addedGoalList}
                            findYears={findYears}
                            setGoalWealthReport={setGoalWealthReport}
                            basicInfo={basicInfo}
                            digitFromator={digitFromator}
                            setJourneyPath={setJourneyPath}
                            setOverview={setOverview}
                            setActiveGoal={setActiveGoal}
                            setGoalQuestionnaire={setGoalQuestionnaire}
                            setGoalWealthReportData={setGoalWealthReportData}
                            setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                            setApplyRecommendationFlag={setApplyRecommendationFlag}
                            applyRecommendationFlag={applyRecommendationFlag}
                            isUpa={isUpa}
                            goalUpaReport={goalUpaReport}
                            goalUpaReportConfig={goalUpaReportConfig}
                            setViewDetails={setViewDetails}
                            viewDetails={viewDetails}
                            saveProposalData={saveProposalData}
                            setRoutingPath={setRoutingPath}
                        />
                    </div>
                ) : goalDetailSection === "Optimized Plan" ? (
                    <div>
                        <GoalProposalUPA
                            formatDollar={formatDollar}
                            getgoalLabels={getgoalLabels}
                            goalDataPriority={goalData}
                            goalWealthReportConfig={goalWealthReportConfig}
                            goalWealthReport={goalWealthReport}
                            addedGoalList={addedGoalList}
                            findYears={findYears}
                            setGoalWealthReport={setGoalWealthReport}
                            basicInfo={basicInfo}
                            digitFromator={digitFromator}
                            setJourneyPath={setJourneyPath}
                            setOverview={setOverview}
                            setActiveGoal={setActiveGoal}
                            setGoalQuestionnaire={setGoalQuestionnaire}
                            setGoalWealthReportData={setGoalWealthReportData}
                            setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                            setApplyRecommendationFlag={setApplyRecommendationFlag}
                            applyRecommendationFlag={applyRecommendationFlag}
                            isUpa={isUpa}
                            goalUpaReport={goalUpaReport}
                            goalUpaReportConfig={goalUpaReportConfig}
                            goalDetailSection={goalDetailSection}
                            goalWealthReportConfigPayload={goalWealthReportConfigPayload}
                            portfolioComposition={portfolioComposition}
                            saveProposalData={saveProposalData}
                            setRoutingPath={setRoutingPath}
                        />
                    </div>
                ) : (
                    <div>
                        <ForwardLooking
                            goalWealthReport={goalWealthReport}
                            startDate={goalData[0]["created_at"]}
                            endDate={goalData[0]["achieve_this_goal"]}
                            goalType={goalData[0]["goal_key"]}
                            addedGoalList={addedGoalList}
                            portfolioComposition={portfolioComposition}
                        />
                    </div>
                )
            ) : (
                <>
                    {isUpa ? (
                        <UPAOverviewGraph
                            goalWealthReport={goalWealthReport}
                            goalWealthReportConfigPayload={goalWealthReportConfigPayload}
                            addedGoalList={addedGoalList}
                            portfolioComposition={portfolioComposition}
                        />
                    ) : (
                        <GOEOverviewGraph
                            goalWealthReport={goalWealthReport}
                            goalWealthReportConfigPayload={goalWealthReportConfigPayload}
                            addedGoalList={addedGoalList}
                            goalWealthReportAllData={goalWealthReportPayload}
                            portfolioComposition={portfolioComposition}
                        />
                    )}
                </>
            )}
            <div></div>
        </div>
    );
}

export default GoalDetailOverview;
