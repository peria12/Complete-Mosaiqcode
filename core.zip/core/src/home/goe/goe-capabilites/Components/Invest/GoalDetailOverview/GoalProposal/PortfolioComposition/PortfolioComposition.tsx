import React, { useEffect, useState } from "react";
import "./PortfolioComposition.scss";
// import ProgressBar from "react-bootstrap/ProgressBar";
import PiePortfolioComp from "./PiePortfolioComp";
import Api from "utils/api";
import PurpleLine from "../../../../../assets/images/svg/purp_line.svg";
import { header } from "../../../../../GoeController";
function PortfolioComposition(props: any) {
    const {
        goalWealthReport,
        applyRecommendationFlag,
        goalDetailSection,
        setViewDetails,
        viewDetails,
        saveProposalData,
        isShowInPDF,
        setRoutingPath,
        // isUpa,
    } = props;
    const [portfolioData, setPortfolioData] = useState([
        {
            asset_category: "",
            asset_key: "",
            asset_name: "",
            port_value: 0,
        },
    ]);

    const [equityExposure, setEquityExposure] = useState({
        equity: 0,
        fixed_income: 0,
    });

    const colorMappingEquity = ["#CC4C03", "#DA6900", "#FF8A1F", "#FFB55D", "#FFCBA4"];
    const colorMappingFixedIncome = ["#017973", "#23A29C", "#00C2B6", "#3FE3DB", "#9FDBDB"];
    const dataEquity = portfolioData.filter((item) => item.asset_category === "Equity");
    const dataFixedIncome = portfolioData.filter((item) => item.asset_category === "Fixed income").reverse();
    const goalId =
        goalDetailSection === "Optimized Plan"
            ? goalWealthReport.analysisReportMod.recommendedPortfolioId
            : goalWealthReport.analysisReport.recommendedPortfolioId;

    useEffect(() => {
        async function getPortfolioComposition(id) {
            await Api.getPortfolioComposition(id)
                .then((response: any) => {
                    function sortByProperty(property) {
                        return function (b, a) {
                            if (a[property] > b[property]) return 1;
                            else if (a[property] < b[property]) return -1;
                            return 0;
                        };
                    }
                    const sortData = response.body.sort(sortByProperty("port_value"));

                    setPortfolioData(sortData);
                })
                .catch(() => {
                    console.log("something went wrong");
                });

            await Api.getPortfolioComposition()
                .then((response: any) => {
                    setEquityExposure(response.body.asset_category_distribution[id]);
                })
                .catch(() => {
                    console.log("something went wrong");
                });
        }
        getPortfolioComposition(goalId);
    }, [goalId]); // NOQA

    const viewDetailsFunc = () => {
        // setApplyRecommendationFlag(false)
        setViewDetails(true);
    };
    let countEquity = -1;
    let countFixedIncome = -1;
    console.log(saveProposalData, "saveproposaldata");
    const saveProposal = () => {
        // /goalconsole
        Api.saveProposalData(saveProposalData, header).then((response) => {
            if (response?.body?.message === "Success") {
                sessionStorage.setItem("save_proposal_objId", response.body.obj_id);
                setRoutingPath("goalconsole");
            }
        });
    };
    return (
        <div className="main-div-portfolio-comp">
            <div className={!isShowInPDF ? "top-main-div-portfolio-comp" : "top-pdf-portfoliocomposition"}>
                <div className="my-goals-prob-border-gradient-green">
                    <span className="main-div-goal-probability-span">Portfolio Composition </span>
                </div>
                <div className="d-flex">
                    <div className="pie-chart-portfolio-comp">
                        <PiePortfolioComp
                            portfolioData={dataEquity.concat(dataFixedIncome)}
                            colorMappingEquity={colorMappingEquity}
                            colorMappingFixedIncome={colorMappingFixedIncome.reverse()}
                        />
                    </div>
                    <div className="div-side-pie-chart-portfolio-composition">
                        <div>
                            <img src={PurpleLine} className="ft-goe-img-side-pie-chart-portfolio-composition" />
                        </div>
                        <div>
                            <div>
                                <div className="d-flex">
                                    <span className="span-pie-chart-portfolio-composition">
                                        Current Portfolio Composition
                                    </span>
                                </div>
                                <div className="d-flex">
                                    <span className="span1-pie-chart-portfolio-composition">
                                        {Number(equityExposure.equity * 100).toFixed(0)}% Equity &{" "}
                                        {Number(equityExposure.fixed_income * 100).toFixed(0)}% Fixed Income
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {(viewDetails || !applyRecommendationFlag || goalDetailSection === "Optimized Plan") && (
                <div className={!isShowInPDF ? "bottom-main-div-portfolio-comp" : "bottom-pdf-portfoliocomposition"}>
                    <div className="div-details-list-portfolio-composition">
                        <span className="span-head-detail-list-portfolio-composition">Detailed list:</span>
                        <span className="span-subhead-detail-list-portfolio-composition">
                            Detailed Composition of Equity vs. Fixed income
                        </span>
                    </div>
                    <div className={!isShowInPDF ? "scroll-div-detail-list-portfolio-composition" : "pdf-scroll-div"}>
                        <div className="subdiv-detail-list-portfolio-composition">
                            <div className="d-flex">
                                <span className="span-head-detail-list-portfolio-composition">Equity</span>
                            </div>
                            {dataEquity.map((item) => {
                                countEquity++;
                                return (
                                    <div key={item.asset_key} className="div-detail-list-portfolio-composition">
                                        <div
                                            className="circle-div-detail-list-portfolio-composition"
                                            style={{ background: colorMappingEquity[countEquity] }}
                                        ></div>
                                        <div className="inner-div-detail-list-portfolio-composition">
                                            <span className="span-div-detail-list-portfolio-composition">
                                                {item.asset_name}
                                            </span>
                                        </div>
                                        <div className="inner-div1-detail-list-portfolio-composition">
                                            <span className="span-div-detail-list-portfolio-composition">
                                                {item.asset_key}
                                            </span>
                                        </div>
                                        <div className="inner-div2-detail-list-portfolio-composition">
                                            <span className="span1-div-detail-list-portfolio-composition">
                                                {(Number(item.port_value) * 100).toFixed(1)}%
                                            </span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                        <div className="subdiv-detail-list-portfolio-composition">
                            <div className="d-flex">
                                <span className="span-head-detail-list-portfolio-composition">Fixed Income</span>
                            </div>
                            {dataFixedIncome.map((item) => {
                                countFixedIncome++;
                                return (
                                    <div key={item.asset_key} className="div-detail-list-portfolio-composition">
                                        <div
                                            className="circle-div-detail-list-portfolio-composition"
                                            style={{
                                                background: colorMappingFixedIncome[countFixedIncome],
                                            }}
                                        ></div>
                                        <div className="inner-div-detail-list-portfolio-composition">
                                            <span className="span-div-detail-list-portfolio-composition">
                                                {item.asset_name}
                                            </span>
                                        </div>
                                        <div className="inner-div1-detail-list-portfolio-composition">
                                            <span className="span-div-detail-list-portfolio-composition">
                                                {item.asset_key}
                                            </span>
                                        </div>
                                        <div className="inner-div2-detail-list-portfolio-composition">
                                            <span className="span1-div-detail-list-portfolio-composition">
                                                {(Number(item.port_value) * 100).toFixed(1)}%
                                            </span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            )}

            {!viewDetails && applyRecommendationFlag && goalDetailSection !== "Optimized Plan" && (
                <div
                    className={
                        applyRecommendationFlag
                            ? "my-goals-prob-div-buttons my-goals-prob-div-buttons-apply-flag"
                            : "my-goals-prob-div-buttons"
                    }
                >
                    <div
                        className="my-goals-prob-div-buttons-editgoal portfolio-composition-view-details"
                        onClick={viewDetailsFunc}
                    >
                        <span className="my-goals-prob-editgoal-span">View Details</span>
                    </div>
                </div>
            )}
            {!isShowInPDF && (
                <div className="save_proposal_section">
                    <div className="save_proposal_container">
                        <span className="save_proposal_button" onClick={saveProposal}>
                            Save Proposal
                        </span>
                    </div>
                </div>
            )}
        </div>
    );
}

export default PortfolioComposition;
