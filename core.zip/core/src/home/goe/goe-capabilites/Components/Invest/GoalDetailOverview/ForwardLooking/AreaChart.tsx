import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { DataPoint, chartMargin } from "./ForwardLooking";

interface AreaChartProps {
    data: DataPoint[];
    chartWidth: number;
    chartHeight: number;
}

// This component creates an svg group element (Area Chart) to be appended to the main svg chart in Forward looking
const AreaChart = ({ data, chartWidth, chartHeight }: AreaChartProps) => {
    const areaRef = useRef<SVGGElement>(null);

    useEffect(() => {
        if (areaRef.current && data.length > 0) {
            const xScale = d3
                .scaleTime()
                .domain([data[0].date, data[data.length - 1].date])
                .range([0, chartWidth]);

            const yScale = d3
                .scaleLinear()
                .domain([0, Math.max(...data.map((d) => d.value))])
                .range([chartHeight, 0]);

            const areaGenerator = d3
                .area<DataPoint>()
                .x((d) => xScale(d.date))
                .y0(yScale(0))
                .y1((d) => yScale(d.value))
                .curve(d3.curveLinear);

            const svg = d3.select(areaRef.current);

            // Remove existing AreaChart (path element) before rendering a new one. - this prevents overlapping of the area chart
            svg.select("path").remove();

            const gradientId = "areaGradient";

            // Define the gradient
            const gradient = svg
                .append("defs")
                .append("linearGradient")
                .attr("id", gradientId)
                .attr("gradientUnits", "userSpaceOnUse")
                .attr("x1", 0)
                .attr("y1", yScale(d3.max(data, (d) => d.value)))
                .attr("x2", 0)
                .attr("y2", yScale(0));

            gradient.append("stop").attr("offset", "0%").style("stop-color", "rgba(109, 192, 187, 0.75)");

            gradient.append("stop").attr("offset", "100%").style("stop-color", "rgba(225, 253, 253, 0.75)");

            svg.append("path")
                .datum(data)
                .attr("d", areaGenerator)
                .attr("fill", `url(#${gradientId})`)
                .attr("transform", `translate(0, ${chartMargin.top})`);
        }
    }, [data, chartWidth, chartHeight]);

    return <g style={{ overflowX: "scroll" }} ref={areaRef}></g>;
};

export default AreaChart;
