import React from "react";
import PortfolioComposition from "./PortfolioComposition/PortfolioComposition";
import GoalProbabilityUPA from "./GoalProbabilityUPA/GoalProbabilityUPA";
import UPAOverviewGraph from "../UPAGoalOverview/UPAOverViewGraph";
import "./GoalProposalUPA.scss";
function GoalProposalUPA(props: any) {
    const {
        addedGoalList,
        goalWealthReport,
        goalWealthReportConfig,
        goalWealthReportPayload,
        goalDataPriority,
        getgoalLabels,
        formatDollar,
        findYears,
        setGoalWealthReport,
        basicInfo,
        digitFromator,
        setJourneyPath,
        setOverview,
        setActiveGoal,
        setGoalQuestionnaire,
        setGoalWealthReportData,
        setGoalWealthReportDataConfig,
        setApplyRecommendationFlag,
        applyRecommendationFlag,
        isUpa,
        saveProposalData,
        // goalUpaReport,
        // goalUpaReportConfig,
        portfolioComposition,
        goalWealthReportConfigPayload,
        goalDetailSection,
        setRoutingPath,
    } = props;

    // const disableGoalIconsFlag = true;
    return (
        <div>
            <div className="d-flex">
                <GoalProbabilityUPA
                    goalWealthReportConfig={goalWealthReportConfig}
                    goalWealthReport={goalWealthReport}
                    isUpa={isUpa}
                    addedGoalList={addedGoalList}
                    goalDataPriority={goalDataPriority}
                    getgoalLabels={getgoalLabels}
                    formatDollar={formatDollar}
                    findYears={findYears}
                    setGoalWealthReport={setGoalWealthReport}
                    basicInfo={basicInfo}
                    digitFromator={digitFromator}
                    setJourneyPath={setJourneyPath}
                    setOverview={setOverview}
                    setActiveGoal={setActiveGoal}
                    setGoalQuestionnaire={setGoalQuestionnaire}
                    setGoalWealthReportData={setGoalWealthReportData}
                    setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                    setApplyRecommendationFlag={setApplyRecommendationFlag}
                    applyRecommendationFlag={applyRecommendationFlag}
                    goalWealthReportPayload={goalWealthReportPayload}
                    portfolioComposition={portfolioComposition}
                    saveProposalData={saveProposalData}
                />
                <PortfolioComposition
                    isUpa={isUpa}
                    goalDetailSection={goalDetailSection}
                    applyRecommendationFlag={applyRecommendationFlag}
                    goalWealthReport={goalWealthReport}
                    setApplyRecommendationFlag={setApplyRecommendationFlag}
                    setRoutingPath={setRoutingPath}
                />
            </div>
            <div className="Overview-container-graph">
                <UPAOverviewGraph
                    goalWealthReport={goalWealthReport}
                    goalWealthReportConfigPayload={goalWealthReportConfigPayload}
                    addedGoalList={addedGoalList}
                    portfolioComposition={portfolioComposition}
                    isGoalDisablityEnabled={true}
                />
            </div>
        </div>
    );
}

export default GoalProposalUPA;
