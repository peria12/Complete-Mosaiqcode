import React, { useEffect, useState } from "react";
import "./GoalOverview.scss";
import BackArrow from "../../../assets/images/svg/arrow-left-back.svg";
import GoalGrid from "./GoalGrid";
import Api from "utils/api";
import GoalDetailOverview from "../GoalDetailOverview/GoalDetailOverview";
import Loader from "../../InvestJourney/Loader";
import { digitFromator, formatDollar, getgoalLabels } from "home/goe/common/utils";
function GoalOverview(props: any) {
    const {
        addedGoalList,
        goalWealthReport,
        goalWealthReportsGeneratepayloadonly,
        setGoalWealthReport,
        setJourneyPath,
        setOverview,
        setActiveGoalOverView,
        setGoalQuestionnaire,
        setGoalEditType,
        isUpa,
        goalUpaReport,
        goalUpaReportConfig,
        goalWealthReportData,
        setGoalWealthReportData,
        goalWealthReportDataConfig,
        setGoalWealthReportDataConfig,
        onGoBackClick,
        saveProposalData,
        setRoutingPath,
    } = props;
    const [portfolioComposition, setPortfolioComposition] = useState({});
    const [loadingPortfolioCompositions, setLoadingPortfolioCompositions] = useState(false);
    const [isOverview, setIsOverview] = useState({ flag: true, goalKey: "" });

    useEffect(() => {
        props.setWlthSplitter("");

        setLoadingPortfolioCompositions(true);
        Api.getPortfolioComposition()
            .then((response: any) => {
                setLoadingPortfolioCompositions(false);
                setPortfolioComposition(response.body);
            })
            .catch(() => {
                setLoadingPortfolioCompositions(false);
                console.log("something went wrong");
            });
    }, [props]);

    const findYears = (probData) => {
        if (probData != "NA") {
            const splitedData = probData.split(";");
            let years = 0;
            if (parseInt(splitedData[0].split(":")[1]) > parseInt(splitedData[1].split(":")[1])) {
                const splitedDataPer = splitedData[0].split(":");
                const splitedDataPerT = splitedDataPer[0].trim().split(" ");
                years = parseInt(splitedDataPerT[3].split("+")[1]);
            } else {
                const splitedDataPer = splitedData[1].split(":");
                const splitedDataPerT = splitedDataPer[0].trim().split(" ");
                years = parseInt(splitedDataPerT[3].split("+")[1]);
            }

            const d = new Date();
            const year = d.getFullYear();
            const month = d.getMonth();
            const day = d.getDate();
            const fulldate = new Date(year + years, month, day);
            const months = ["Jan", "Feb", "March", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
            const convertedDate = months[fulldate.getMonth()] + " " + fulldate.getFullYear();
            return convertedDate;
        }
        return probData;
    };

    if (props.loading || loadingPortfolioCompositions) {
        return (
            <div className="main-div-overview">
                <Loader />
            </div>
        );
    }

    return (
        <div className="main-div-overview">
            {!isUpa && isOverview.flag ? (
                <div>
                    <div
                        className="div-overview-backbutton label-cursor"
                        onClick={() => {
                            props.getAllGoals();
                            props.setOverview("");
                            onGoBackClick(isUpa);
                        }}
                    >
                        <img className="img-overview-backbutton" src={BackArrow} />
                        &nbsp;<span className="span-overview-backbutton">Back</span>
                    </div>
                    <div className="div-overview-header">
                        <span className="span-overview-header">Overview</span>
                    </div>
                    <div className="goal-overview-main-div">
                        {Object.keys(portfolioComposition).length > 0 &&
                            addedGoalList.map((goalItem) => {
                                return (
                                    <GoalGrid
                                        priority="NEED"
                                        percentage={50}
                                        key={goalItem["goal-key"]}
                                        goalItem={goalItem}
                                        goalWealthReportAllData={goalWealthReport}
                                        goalWealthReportConfigAllData={goalWealthReportsGeneratepayloadonly}
                                        portfolioComposition={portfolioComposition["asset_category_distribution"]}
                                        setIsOverview={setIsOverview}
                                        getgoalLabels={getgoalLabels}
                                        formatDollar={formatDollar}
                                        findYears={findYears}
                                        digitFromator={digitFromator}
                                        goalKeyP={isOverview.goalKey}
                                        setGoalWealthReportData={setGoalWealthReportData}
                                        setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                                    />
                                );
                            })}

                        {/* <GoalGrid priority="WANT" percentage={76} />
        <GoalGrid priority="WISH" percentage={82} />
        <GoalGrid priority="DREAM" percentage={45} /> */}
                    </div>
                </div>
            ) : (
                <GoalDetailOverview
                    goalKeyP={isOverview.goalKey}
                    goBackClick={() => {
                        if (isUpa) {
                            props.getAllGoals();
                            props.setOverview("");
                            onGoBackClick(isUpa);
                        } else {
                            setIsOverview({ flag: true, goalKey: "" });
                        }
                    }}
                    isUpa={isUpa}
                    goalUpaReport={goalUpaReport}
                    isOverview={isOverview}
                    setOverview={setOverview}
                    addedGoalList={addedGoalList}
                    goalWealthReportPayload={goalWealthReport}
                    goalWealthReportConfigPayload={goalWealthReportsGeneratepayloadonly}
                    goalWealthReport={goalWealthReportData}
                    goalWealthReportConfig={goalWealthReportDataConfig}
                    getgoalLabels={getgoalLabels}
                    formatDollar={formatDollar}
                    findYears={findYears}
                    setGoalWealthReport={setGoalWealthReport}
                    digitFromator={digitFromator}
                    setJourneyPath={setJourneyPath}
                    setActiveGoal={setActiveGoalOverView}
                    setGoalQuestionnaire={setGoalQuestionnaire}
                    setGoalEditType={setGoalEditType}
                    setGoalWealthReportData={setGoalWealthReportData}
                    setGoalWealthReportDataConfig={setGoalWealthReportDataConfig}
                    goalUpaReportConfig={goalUpaReportConfig}
                    portfolioComposition={portfolioComposition["asset_category_distribution"]}
                    saveProposalData={saveProposalData}
                    setRoutingPath={setRoutingPath}
                />
            )}
        </div>
    );
}

export default GoalOverview;
