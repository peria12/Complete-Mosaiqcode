import React from "react";
import "./GoalProbabilityUPA.scss";
import DonutChart from "../../../GoalOverview/DonutChart";
import EditImage from "../../../../../assets/images/svg/pen.svg";
import moment from "moment";

function GoalProbabilityUPA(props: any) {
    const {
        addedGoalList,
        applyRecommendationFlag,
        goalWealthReport,
        goalWealthReportConfig,
        goalDataPriority,
        formatDollar,
        setJourneyPath,
        setOverview,
        setActiveGoal,
        setGoalQuestionnaire,
        isUpa,
    } = props;
    const goalJson = isUpa ? {} : JSON.parse(JSON.stringify(goalDataPriority[0]));
    const unFormaAmount = (formatterNUmber) => {
        if (typeof formatterNUmber != "number") {
            return Number(formatterNUmber.replace(/[$,]/g, ""));
        }
        return formatterNUmber;
    };

    const goalPriorityValueArr = [0];
    let initialInvestment = 0;

    addedGoalList.forEach((item) => {
        const goalProbData = goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][item["goal_priority"]];
        initialInvestment = initialInvestment + unFormaAmount(item["initial_investment"]);
        goalPriorityValueArr.push(goalProbData);
    });

    const goalPriorityValue = isUpa
        ? Math.max(...goalPriorityValueArr)
        : goalWealthReportConfig["pipe_config"]["goal_priority_prob_list"][goalJson["goal_priority"]];

    const calculateTotal = (originalAmount, optimizedAmount) => {
        return originalAmount + optimizedAmount;
    };

    const handleEditgoal = () => {
        setJourneyPath("goal-type");
        setOverview("");
        setActiveGoal(goalJson);
        setGoalQuestionnaire(goalJson["goal_key"]);
    };

    return (
        <div>
            <div className={"main-div-goal-probability"}>
                <div className="my-goals-prob-border-gradient-green">
                    <span className="main-div-goal-probability-span">
                        {isUpa ? "Plan Achievement Probability" : "Goal Probability"}
                    </span>
                </div>
                {goalWealthReport["analysisReport"] && (
                    <DonutChart
                        isProbability={true}
                        currentGoalProb={goalWealthReport["analysisReport"]["currentGoalProbability"]}
                        realisticGoalProb={goalWealthReportConfig["pipe_config"]["realistic_goal_prob"]}
                        currentGoalProbMod={goalWealthReport["analysisReportMod"]["currentGoalProbability"]}
                        goalPriorityValue={goalPriorityValue}
                        applyRecommendationFlag={applyRecommendationFlag}
                        isUpa={isUpa}
                    />
                )}
                <div>
                    <div className="d-flex">
                        <span className="goal-prob-upa-span-1">Optimization:</span>
                    </div>
                    <div className="d-flex">
                        <span className="goal-prob-upa-span-gray">Detailed Composition of Equity vs. Fixed Income</span>
                    </div>
                </div>
                <table style={{ width: "100%" }}>
                    <tr className="goal-prob-upa-table-heading">
                        <th style={{ textAlign: "left" }}>
                            <span className="goal-prob-upa-span-2"></span>
                        </th>
                        <th style={{ textAlign: "left" }}>
                            <span className="goal-prob-upa-span-2">Goal Lumpsum</span>
                        </th>
                        <th style={{ textAlign: "left" }}>
                            <span className="goal-prob-upa-span-2">Goal Income</span>
                        </th>
                        <th style={{ textAlign: "left" }}>
                            <span className="goal-prob-upa-span-2">Goal Tenure</span>
                        </th>
                    </tr>
                    {goalWealthReport.analysisReportMod.goalsResponse.map((item, index) => {
                        const endDateGoal = new Date(
                            addedGoalList[index][
                                addedGoalList[index]["goal_key"] === "plan_retirement"
                                    ? "end_on_date"
                                    : addedGoalList[index]["goal_key"] === "draw_income"
                                    ? "last_withdrawal"
                                    : "achieve_this_goal"
                            ]
                        ).getFullYear();
                        const endDate = moment(item.endDate, "DD-MM-YYYY").format("YYYY-MM-DD");

                        const tenureDiff = new Date(endDate).getFullYear() - endDateGoal;

                        return (
                            <tr
                                key={index}
                                className={index % 2 != 0 ? "ft-goe-cap-upa-table-tr-even" : "ft-goe-cap-upa-table-tr"}
                            >
                                <td className="ft-goe-cap-upa-td">
                                    <div className="goal-prob-upa-table-td-div-1">
                                        <div className="goal-prob-upa-div1-goal">
                                            <span className="goal-prob-upa-span-goal">{item.goalId}</span>
                                        </div>
                                        <div
                                            className={`goal-prob-upa-goal-priority-div goal-prob-upa-goal-priority-div-${item.priority}`}
                                        >
                                            <span className="goal-prob-upa-span1-goal">{item.priority}</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    {item.goalId === "Plan for Retirement" ? (
                                        <div className="goal-prob-upa-span-2 goal-prob-upa-table-td-no-change">--</div>
                                    ) : (
                                        <div className="goal-prob-upa-table-div">
                                            <div className="d-flex">
                                                <span className="goal-prob-upa-span-value-goal">
                                                    {formatDollar(
                                                        calculateTotal(item.goalAmt[0], item.modifiedGoalAmt[0])
                                                    )}
                                                </span>
                                            </div>
                                            <div className="d-flex">
                                                <div className="goal-prob-upa-table-td-subdiv">
                                                    <span className="goal-prob-upa-span2-goal">Original</span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span3-goal">
                                                        &nbsp;&nbsp;:&nbsp;&nbsp;
                                                    </span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span2-goal">
                                                        {formatDollar(item.goalAmt[0])}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="d-flex">
                                                <div className="goal-prob-upa-table-td-subdiv">
                                                    <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">
                                                        Optimized
                                                    </span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span3-goal">
                                                        &nbsp;&nbsp;:&nbsp;&nbsp;
                                                    </span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">
                                                        {formatDollar(item.modifiedGoalAmt[0])}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </td>
                                <td>
                                    {item.goalId === "Plan for Retirement" ? (
                                        <div className="goal-prob-upa-table-td-div goal-prob-upa-table-div">
                                            <div className="d-flex">
                                                <span className="goal-prob-upa-span-value-goal">
                                                    {formatDollar(
                                                        calculateTotal(
                                                            unFormaAmount(addedGoalList[index]["goal_amount"]),
                                                            item.modifiedGoalAmt[0] - item.goalAmt[0]
                                                        )
                                                    )}{" "}
                                                    (manually)
                                                </span>
                                            </div>
                                            <div className="d-flex">
                                                <div className="goal-prob-upa-table-td-subdiv">
                                                    <span className="goal-prob-upa-span2-goal">Original</span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span3-goal">
                                                        &nbsp;&nbsp;:&nbsp;&nbsp;
                                                    </span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span2-goal">
                                                        {formatDollar(
                                                            unFormaAmount(addedGoalList[index]["goal_amount"])
                                                        )}
                                                    </span>
                                                </div>
                                                {/* <span className="goal-prob-upa-span2-goal">Original</span>
                                        <span className="goal-prob-upa-span3-goal">:</span>
                                        <span className="goal-prob-upa-span2-goal">{formatDollar(unFormaAmount(addedGoalList[index]['goal_amount']))}</span> */}
                                            </div>
                                            <div className="d-flex">
                                                <div className="goal-prob-upa-table-td-subdiv">
                                                    <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">
                                                        Optimized
                                                    </span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span3-goal">
                                                        &nbsp;&nbsp;:&nbsp;&nbsp;
                                                    </span>
                                                </div>
                                                <div className="d-flex">
                                                    <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">
                                                        {item.modifiedGoalAmt[0] - item.goalAmt[0] != 0
                                                            ? formatDollar(item.modifiedGoalAmt[0] - item.goalAmt[0])
                                                            : "no change"}
                                                    </span>
                                                </div>
                                                {/* <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">Optimized</span>
                                        <span className="goal-prob-upa-span3-goal">:</span>
                                        <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">{item.modifiedGoalAmt[0] - item.goalAmt[0] != 0 ? formatDollar(item.modifiedGoalAmt[0] - item.goalAmt[0]) : "no change"}</span> */}
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="goal-prob-upa-span-2 goal-prob-upa-table-td-no-change">--</div>
                                    )}
                                </td>

                                <td>
                                    <div className="goal-prob-upa-table-td-div goal-prob-upa-table-div">
                                        <div className="d-flex">
                                            <span className="goal-prob-upa-span-value-goal">
                                                {calculateTotal(endDateGoal, tenureDiff)}
                                            </span>
                                        </div>
                                        <div className="d-flex">
                                            <div className="goal-prob-upa-table-td-subdiv">
                                                <span className="goal-prob-upa-span2-goal">Original</span>
                                            </div>
                                            <div className="d-flex">
                                                <span className="goal-prob-upa-span3-goal">
                                                    &nbsp;&nbsp;:&nbsp;&nbsp;
                                                </span>
                                            </div>
                                            <div className="d-flex">
                                                <span className="goal-prob-upa-span2-goal">{endDateGoal}</span>
                                            </div>
                                            {/* <span className="goal-prob-upa-span2-goal">Original</span>
                                    <span className="goal-prob-upa-span3-goal">:</span>
                                    <span className="goal-prob-upa-span2-goal">{endDateGoal}</span> */}
                                        </div>
                                        <div className="d-flex">
                                            <div className="goal-prob-upa-table-td-subdiv">
                                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">
                                                    Optimized
                                                </span>
                                            </div>
                                            <div className="d-flex">
                                                <span className="goal-prob-upa-span3-goal">
                                                    &nbsp;&nbsp;:&nbsp;&nbsp;
                                                </span>
                                            </div>
                                            <div className="d-flex">
                                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">
                                                    &nbsp;
                                                    {tenureDiff != 0
                                                        ? tenureDiff > 0
                                                            ? "+" + tenureDiff
                                                            : tenureDiff + "years"
                                                        : "no change"}
                                                </span>
                                            </div>
                                            {/* <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">Optimized</span>
                                    <span className="goal-prob-upa-span3-goal">:</span>
                                    <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">&nbsp;{
                                        tenureDiff != 0 ? tenureDiff > 0 ? "+" + tenureDiff:tenureDiff + "years": "no change"}</span> */}
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        );
                        // <div key={index} className="d-flex" style={{'gap':"20px"}}></div>
                    })}
                </table>
                {/* <div className="goal-prob-upa-div-1">
                    <div className="goal-prob-upa-span-2">
                    <span >Goal Lumpsum</span>  
                    </div>
                    <div className="goal-prob-upa-span-2">
                    <span >Goal Income</span>
                    </div>
                    <div className="goal-prob-upa-span-2">
                    <span >Goal Tenure</span>
                    </div>
                </div> */}
                {/* {
                    goalWealthReport.analysisReportMod.goalsResponse.map((item,index)=>{
                        return <div key={index} className="d-flex" style={{'gap':"20px"}}>
                        <div className="goal-prob-upa-div-goal">
                            <div className="goal-prob-upa-div1-goal">
                                <span className="goal-prob-upa-span-goal">{item.goalId}</span>
                            </div>
                            <div className={`goal-prob-upa-goal-priority-div-Want`}>
                                <span className="goal-prob-upa-span1-goal">{item.priority}</span>
                            </div>
                        </div>
                        {
                            item.goalId === "Plan for Retirement" ?  <div className="goal-prob-upa-span-2">
                                -
                        </div> :  <div className="goal-prob-upa-span-2">
                            <div className="d-flex">
                                <span className="goal-prob-upa-span-value-goal">$600,000 </span>
                            </div>
                            <div className="d-flex">
                                <span className="goal-prob-upa-span2-goal">Original</span>
                                <span className="goal-prob-upa-span3-goal">:</span>
                                <span className="goal-prob-upa-span2-goal">{item.goalAmt[0]}</span>
                            </div>
                            <div className="d-flex">
                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">Optimized</span>
                                <span className="goal-prob-upa-span3-goal">:</span>
                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">{item.modifiedGoalAmt[0]}</span>
                            </div>
                        </div>
                        }

                        {
                            item.goalId === "Plan for Retirement" ? <div className="goal-prob-upa-span-2 goal-prob-upa-div-span1">
                            <div className="d-flex">
                                <span className="goal-prob-upa-span-value-goal">$600,000(manually) </span>
                            </div>
                            <div className="d-flex">
                                <span className="goal-prob-upa-span2-goal">Original</span>
                                <span className="goal-prob-upa-span3-goal">:</span>
                                <span className="goal-prob-upa-span2-goal">$900,000</span>
                            </div>
                            <div className="d-flex">
                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">Optimized</span>
                                <span className="goal-prob-upa-span3-goal">:</span>
                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">{item.modifiedGoalAmt[0]-item.goalAmt[0]!=0 ? item.modifiedGoalAmt[0]-item.goalAmt[0] : "no change"}</span>
                            </div>
                        </div> : <div className="goal-prob-upa-span-2">
                                -
                        </div>
                        }
                       
                        
                        <div className="goal-prob-upa-span-2 goal-prob-upa-div-span2">
                            <div className="d-flex">
                                <span className="goal-prob-upa-span-value-goal">2064 </span>
                            </div>
                            <div className="d-flex">
                                <span className="goal-prob-upa-span2-goal">Original</span>
                                <span className="goal-prob-upa-span3-goal">:</span>
                                <span className="goal-prob-upa-span2-goal">$900,000</span>
                            </div>
                            <div className="d-flex">
                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span-value-goal">Optimized</span>
                                <span className="goal-prob-upa-span3-goal">:</span>
                                <span className="goal-prob-upa-span2-goal goal-prob-upa-span2-red-goal">$900,000</span>
                            </div>
                        </div>
                    </div>
                    })
                } */}
            </div>
            <div className="my-goals-prob-div-buttons">
                <div className="my-goals-prob-div-buttons-editgoal" onClick={handleEditgoal}>
                    <img src={EditImage} className="my-goals-prob-editgoal-span-img" />{" "}
                    <span className="my-goals-prob-editgoal-span">Edit Plan</span>
                </div>
            </div>
        </div>
    );
}

export default GoalProbabilityUPA;
