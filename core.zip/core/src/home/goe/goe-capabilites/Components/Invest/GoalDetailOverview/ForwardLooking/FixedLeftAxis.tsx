import React, { useEffect, useRef } from "react";
import { DataPoint, chartMargin } from "./ForwardLooking";
import * as d3 from "d3";

interface FixedLeftAxisProps {
    chartHeight: number;
    data: DataPoint[]; // this is usually the chart with the longest width
}
const FixedLeftAxis = ({ chartHeight, data }: FixedLeftAxisProps) => {
    // Create a new SVG element for the left y-axis
    const leftYAxisRef = useRef<SVGSVGElement>(null);
    useEffect(() => {
        if (leftYAxisRef.current) {
            // Remove any existing left y-axis
            // d3.select(".y-axis-left").remove();

            const svg = d3
                .select(leftYAxisRef.current)
                .attr("height", chartHeight + chartMargin.top + chartMargin.bottom);

            const leftYScale = d3
                .scaleLinear()
                .domain([0, Math.ceil(Math.max(...data.map((d) => d.value)))])
                .nice()
                .range([chartHeight, 0]);

            // Add left y-axis
            const yAxisLeft = d3.axisLeft(leftYScale).tickFormat((d) => `$${d3.format(",")(d)}`);

            svg.selectAll("text").remove();

            svg.append("g")
                .attr("class", "y-axis-left")
                .attr("transform", `translate(${chartMargin.left}, ${chartMargin.top})`)
                .call(yAxisLeft)
                .selectAll("text")
                .style("font-size", "12px")
                .style("line-height", "19px")
                .style("font-weight", "400")
                .style("font-family", "TT Commons");

            // Add left y-axis title
            svg.append("text")
                .attr("class", "y-axis-title")
                .attr("x", -chartMargin.top - chartHeight / 2)
                .attr("y", chartMargin.left / 2)
                .attr("transform", "rotate(-90)")
                .style("text-anchor", "middle")
                .style("font-size", "16px")
                .style("line-height", "19px")
                .style("font-weight", "500")
                .text("Portfolio Value (In $)")
                .attr("dy", `-30px`);

            // Hide left y-axis tick lines
            svg.selectAll(".y-axis-left path.domain").style("display", "none");
            svg.selectAll(".tick line").style("display", "none");
        }
    }, []);

    return (
        <svg ref={leftYAxisRef} className="left-y-axis-svg" width={chartMargin.left} height={chartHeight}>
            <g transform={`translate(${chartMargin.left},${chartMargin.top})`} className="y-axis left-y-axis" />
        </svg>
    );
};

export default FixedLeftAxis;
