import React, { ChangeEvent, ReactEventHandler, useEffect, useRef, useState } from "react";
import "./PortfolioFormSection.scss";
import Slider from "@mui/material/Slider";
import GoalSec1Icon from "../../../assets/images/svg/regular_goal_icon.svg";
import OwnHouseIcon from "../../../assets/images/svg/escalations_icon.svg";
import DrawIncomeIcon from "../../../assets/images/svg/withdrawl_icon.svg";
import InfoCircle from "../../../assets/images/svg/info-circle.svg";
import PortfolioFormSectionHeaderDiv from "./PortfolioFormSecttionHeaderDiv";

interface IFormError {
    targeted_retirement_income: boolean;
    goal_priority: boolean;
    plan_start_retirement: boolean;
    end_on_date: boolean;
    my_withdrawal_frequency: boolean;
    leave_bequest: boolean;
    goal_amount: boolean;
    initial_investment: boolean;
    recurring_contributions: boolean;
    contribution_time: boolean;
    escalate_contributions: boolean;
    escalation_percentage: boolean;
    every_years: boolean;
}

let initialFormErrors: IFormError = {
    targeted_retirement_income: false,
    goal_priority: false,
    plan_start_retirement: false,
    end_on_date: false,
    my_withdrawal_frequency: false,
    leave_bequest: false,
    goal_amount: false,
    initial_investment: false,
    recurring_contributions: false,
    contribution_time: false,
    escalate_contributions: false,
    escalation_percentage: false,
    every_years: false,
};
const FORM_FIELDS: Array<Array<string>> = [
    [
        "targeted_retirement_income",
        "goal_priority",
        "plan_start_retirement",
        "end_on_date",
        "my_withdrawal_frequency",
        "leave_bequest",
        "goal_amount",
    ],
    ["initial_investment", "recurring_contributions", "contribution_time"],
    ["escalate_contributions", "escalation_percentage", "every_years"],
];

const GOAL_PRIORITIES: Array<string> = ["Need", "Want", "Wish", "Dream"];
const TOTAL_FORM_COUNT = 3;
const FORM_COMPLETE_STATUS = [false, false, false];

function PortfolioFormSectionRet(props) {
    const mainDivRef = useRef<HTMLDivElement>(null);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [selectedForm, setSelectedForm] = useState(1);
    const [formErrors, setFormErrors] = useState(initialFormErrors);
    const {
        data,
        onButtonClick,
        handleChange,
        onChangeDate,
        handleChangeInputDollar,
        isEscalation,
        setshowGoalPriotiy,
        turnRetirementIncome,
    } = props;
    console.log(data, "data");

    useEffect(() => {
        //If Not Last form is selected
        if (data && selectedForm !== TOTAL_FORM_COUNT) {
            // if (checkIsFormComplete(selectedForm)) {
            //     moveToForm(selectedForm + 1);
            //     selectForm(selectedForm + 1);
            // }
            // console.log(formErrors);

            setFormErrors(initialFormErrors);
        }
        //eslint-disable-next-line
    }, [data]);

    /*function moveToForm(formNumber: number): void {
        const mainDiv = mainDivRef.current;
        const containerScrollWidth = mainDiv?.scrollWidth;
        const containerRenderedWidth = mainDiv?.clientWidth;

        if (containerScrollWidth && containerRenderedWidth) {
            const scrollWidth = containerScrollWidth - containerRenderedWidth;
            let scrollLeftPosition = 0;

            if (formNumber == 2) {
                //middle
                scrollLeftPosition = scrollWidth / 2;
            } else if (formNumber == 3) {
                //last
                scrollLeftPosition = scrollWidth;
            }

            mainDiv.scrollTo({
                left: scrollLeftPosition,
                behavior: "smooth",
            });
        }
    }

    function selectForm(formNumber: number): void {
        setSelectedForm(formNumber);
    }*/

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    function getFormContainerClass(formNumber: number): string {
        const cls = "ft-goe-cap-redesigned-forms-ret";

        // if (selectedForm === formNumber) {
        //     cls += " ft-goe-cap-redesigned-forms-selected";
        // } else if (!FORM_COMPLETE_STATUS[formNumber - 1] && !checkIsFormComplete(formNumber)) {
        //     cls += " disabled";
        // }

        return cls;
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    function checkIsFormComplete(formNumber: number): boolean {
        let formComplete = false;
        const fieldsToValidate = FORM_FIELDS[formNumber - 1];

        for (let index = 0; index < fieldsToValidate.length; index++) {
            const field = fieldsToValidate[index];
            const value = data[field];

            if (formNumber === 3 && field === "escalate_contributions" && value === "no") {
                formComplete = true;
                initialFormErrors = { ...initialFormErrors, [field]: false };
                break;
            }

            if (value) {
                formComplete = true;
                initialFormErrors = { ...initialFormErrors, [field]: false };
            } else if (field === "targeted_retirement_income" || (field === "goal_amount" && value === undefined)) {
                initialFormErrors = { ...initialFormErrors, [field]: false };
            } else {
                formComplete = false;
                initialFormErrors = { ...initialFormErrors, [field]: true };
                break;
            }
        }

        FORM_COMPLETE_STATUS[formNumber - 1] = formComplete;

        return formComplete;
    }

    function getOnChangeHandler(formNumber: number, onChangeFunc): ReactEventHandler {
        return (evt: ChangeEvent) => {
            onChangeFunc(evt);
        };
    }
    return (
        <div className="pfs d-flex flex-column forms_container">
            <div className="pfs__body d-flex ft-goe-cap-redesigned-forms-main-div" ref={mainDivRef}>
                <div className={getFormContainerClass(1)} id="pfs-form-1">
                    <PortfolioFormSectionHeaderDiv
                        icon={GoalSec1Icon}
                        classname="ft-goe-cap-redesigned-forms-head-icon-div-sec1"
                    />
                    <div className="pfs__goal-form-body position-relative">
                        <div className="pfs__form-overlay"></div>
                        <form autoComplete="off">
                            <div className="d-flex">
                                <div className="ft-goe-cap-redesigned-forms-ret-left-div">
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Retirement income goal ($)
                                                </span>
                                            </div>
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-right">
                                                <img src={InfoCircle}></img>
                                                <span
                                                    className="ft-goe-cap-redesigned-forms-ret-left-div-span-help"
                                                    onClick={turnRetirementIncome}
                                                >
                                                    get help
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="text"
                                            name="targeted_retirement_income"
                                            value={data.targeted_retirement_income}
                                            onChange={getOnChangeHandler(1, handleChangeInputDollar)}
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="10,000"
                                        />
                                        {formErrors.targeted_retirement_income ? (
                                            <p className="pfs__input-error">Goal Amount can not be 0</p>
                                        ) : null}
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Goal Priority
                                                </span>
                                            </div>
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-right">
                                                <img src={InfoCircle}></img>
                                                <span
                                                    className="ft-goe-cap-redesigned-forms-ret-left-div-span-help"
                                                    onClick={setshowGoalPriotiy}
                                                >
                                                    help
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full d-flex">
                                            {GOAL_PRIORITIES.map((priority) => (
                                                <div
                                                    key={priority}
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                        data["goal_priority"] === priority
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                            : ""
                                                    }`}
                                                    onClick={getOnChangeHandler(1, () =>
                                                        onButtonClick("goal_priority", priority)
                                                    )}
                                                >
                                                    <span
                                                        className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                            data["goal_priority"] === priority
                                                                ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                                : ""
                                                        }`}
                                                    >
                                                        {priority}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                        {/* <input type="text" className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full" placeholder="10,000"/> */}
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Retirement start date
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="date"
                                            onChange={getOnChangeHandler(1, onChangeDate)}
                                            name="plan_start_retirement"
                                            value={data["plan_start_retirement"]}
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="10,000"
                                        />
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Retirement end date
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="date"
                                            onChange={onChangeDate}
                                            value={data["end_on_date"]}
                                            name="end_on_date"
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="10,000"
                                        />
                                    </div>
                                </div>
                                <div className="ft-goe-cap-redesigned-forms-ret-left-div">
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Withdrawal frequency
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full d-flex">
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["my_withdrawal_frequency"] === "Year"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("my_withdrawal_frequency", "Year")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["my_withdrawal_frequency"] === "Year"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    Year
                                                </span>
                                            </div>
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["my_withdrawal_frequency"] === "Month"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("my_withdrawal_frequency", "Month")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["my_withdrawal_frequency"] === "Month"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    Month
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Leave a bequest
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full d-flex">
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["leave_bequest"] === "yes"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("leave_bequest", "yes")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["leave_bequest"] === "yes"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    Yes
                                                </span>
                                            </div>
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["leave_bequest"] === "no"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("leave_bequest", "no")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["leave_bequest"] === "no"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    No
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Bequest amount
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="text"
                                            value={data["goal_amount"]}
                                            onChange={getOnChangeHandler(1, handleChangeInputDollar)}
                                            name="goal_amount"
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="Enter Amount"
                                        />
                                        {formErrors.goal_amount ? (
                                            <p className="pfs__input-error">Goal Amount can not be 0</p>
                                        ) : null}
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div className={getFormContainerClass(2)} id="pfs-form-2">
                    <PortfolioFormSectionHeaderDiv
                        icon={DrawIncomeIcon}
                        classnameouter="ft-goe-cap-redesigned-forms-sec1"
                        classname="ft-goe-cap-redesigned-forms-head-icon-div-sec2"
                    />
                    <div className="pfs__goal-form-body position-relative">
                        <div className="pfs__form-overlay"></div>
                        <form className="ft-goe-cap-redesigned-forms-ret-left-div" autoComplete="off">
                            <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                <div className="d-flex">
                                    <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                        <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                            Initial investment
                                        </span>
                                    </div>
                                </div>
                                <input
                                    type="text"
                                    value={data["initial_investment"]}
                                    onChange={getOnChangeHandler(2, handleChangeInputDollar)}
                                    name="initial_investment"
                                    className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full-sec1"
                                    placeholder="Enter Amount"
                                />
                            </div>
                            <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                <div className="d-flex">
                                    <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                        <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                            Recurring contributions
                                        </span>
                                    </div>
                                </div>
                                <input
                                    type="text"
                                    onChange={getOnChangeHandler(2, handleChangeInputDollar)}
                                    value={data["recurring_contributions"]}
                                    name="recurring_contributions"
                                    className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full-sec1"
                                    placeholder="Enter Amount"
                                />
                            </div>
                            <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                <div className="d-flex">
                                    <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                        <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                            Recurring every
                                        </span>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                            data["my_withdrawal_frequency"] === "Year"
                                                ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                : ""
                                        }`}
                                        onClick={getOnChangeHandler(2, () =>
                                            onButtonClick("my_withdrawal_frequency", "Year")
                                        )}
                                    >
                                        <span
                                            className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                data["my_withdrawal_frequency"] === "Year"
                                                    ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                    : ""
                                            }`}
                                        >
                                            Year
                                        </span>
                                    </div>
                                    <div
                                        className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                            data["my_withdrawal_frequency"] === "Month"
                                                ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                : ""
                                        }`}
                                        onClick={getOnChangeHandler(2, () =>
                                            onButtonClick("my_withdrawal_frequency", "Month")
                                        )}
                                    >
                                        <span
                                            className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                data["my_withdrawal_frequency"] === "Month"
                                                    ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                    : ""
                                            }`}
                                        >
                                            Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div className={getFormContainerClass(3)} id="pfs-form-3">
                    <PortfolioFormSectionHeaderDiv
                        icon={OwnHouseIcon}
                        classnameouter="ft-goe-cap-redesigned-forms-sec2"
                        classname="ft-goe-cap-redesigned-forms-head-icon-div-sec3"
                    />
                    <div className="pfs__goal-form-body position-relative">
                        <div className="pfs__form-overlay"></div>
                        <form className="ft-goe-cap-redesigned-forms-ret-left-div" autoComplete="off">
                            <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                <div className="d-flex">
                                    <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                        <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                            Escalate contributions
                                        </span>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                            data["escalate_contributions"] === "yes"
                                                ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                : ""
                                        }`}
                                        onClick={() => onButtonClick("escalate_contributions", "yes")}
                                    >
                                        <span
                                            className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                data["escalate_contributions"] === "yes"
                                                    ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                    : ""
                                            }`}
                                        >
                                            Yes
                                        </span>
                                    </div>
                                    <div
                                        className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                            data["escalate_contributions"] === "no"
                                                ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                : ""
                                        }`}
                                        onClick={() => onButtonClick("escalate_contributions", "no")}
                                    >
                                        <span
                                            className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                data["escalate_contributions"] === "no"
                                                    ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                    : ""
                                            }`}
                                        >
                                            No
                                        </span>
                                    </div>
                                </div>
                            </div>
                            {!isEscalation && (
                                <div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Escalation percentage
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1 d-flex">
                                            <div className="d-flex ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                                <div className="range-slider">
                                                    <div className="ft-goe-cap-redesigned-forms-range-group range-group">
                                                        <Slider
                                                            size="small"
                                                            defaultValue={0}
                                                            aria-label="Small"
                                                            valueLabelDisplay="auto"
                                                            name="escalation_percentage"
                                                            value={data["escalation_percentage"] * 100}
                                                            onChange={handleChange}
                                                            disabled={isEscalation}
                                                        />
                                                    </div>
                                                </div>
                                                <input
                                                    className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp `}
                                                    type="text"
                                                    name="escalation_percentage"
                                                    value={data["escalation_percentage"] * 100 + "%"}
                                                    placeholder="0%"
                                                    disabled
                                                ></input>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    every (in years)
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1 d-flex">
                                            <div className="d-flex">
                                                <div className="range-slider">
                                                    <div className="ft-goe-cap-redesigned-forms-range-group range-group">
                                                        <Slider
                                                            size="small"
                                                            defaultValue={1}
                                                            aria-label="Small"
                                                            valueLabelDisplay="auto"
                                                            name="every_years"
                                                            value={data["every_years"]}
                                                            onChange={handleChange}
                                                            disabled={true}
                                                        />
                                                    </div>
                                                </div>
                                                <input
                                                    className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp `}
                                                    type="text"
                                                    name="every_years"
                                                    value={1}
                                                    placeholder="0"
                                                    disabled
                                                ></input>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PortfolioFormSectionRet;
