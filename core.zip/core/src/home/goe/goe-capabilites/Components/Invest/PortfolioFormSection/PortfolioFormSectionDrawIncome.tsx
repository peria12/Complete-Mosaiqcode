import React, { ChangeEvent, ReactEventHandler, useEffect, useRef, useState } from "react";
import "./PortfolioFormSectionRet.scss";
import GoalSec1Icon from "../../../assets/images/svg/regular_goal_icon.svg";
import DrawIncomeIcon from "../../../assets/images/svg/withdrawl_icon.svg";
import InfoCircle from "../../../assets/images/svg/info-circle.svg";
import PortfolioFormSectionHeaderDiv from "./PortfolioFormSecttionHeaderDiv";

interface IFormError {
    draw_income: boolean;
    goal_amount: boolean;
    goal_priority: boolean;
    last_withdrawal: boolean;
    plan_leave_bequest: boolean;
    start_first_withdrawal: boolean;
    initial_investment: boolean;
}

let initialFormErrors: IFormError = {
    draw_income: false,
    goal_amount: false,
    goal_priority: false,
    last_withdrawal: false,
    plan_leave_bequest: false,
    start_first_withdrawal: false,
    initial_investment: false,
};
const FORM_FIELDS: Array<Array<string>> = [
    ["draw_income", "goal_amount", "goal_priority", "last_withdrawal", "plan_leave_bequest", "start_first_withdrawal"],
    ["initial_investment"],
];

const GOAL_PRIORITIES: Array<string> = ["Need", "Want", "Wish", "Dream"];
const TOTAL_FORM_COUNT = 3;
const FORM_COMPLETE_STATUS = [false, false, false];
function PortfolioFormSectionDrawIncome(props) {
    const mainDivRef = useRef<HTMLDivElement>(null);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [selectedForm, setSelectedForm] = useState(1);
    const [formErrors, setFormErrors] = useState(initialFormErrors);
    const {
        data,
        onButtonClick,
        // handleChange,
        onChangeDate,
        handleChangeInputDollar,
        // isEscalation,
        setshowGoalPriotiy,
    } = props;
    console.log(data, "data");

    useEffect(() => {
        //If Not Last form is selected
        if (data && selectedForm !== TOTAL_FORM_COUNT) {
            // if (checkIsFormComplete(selectedForm)) {
            //     moveToForm(selectedForm + 1);
            //     selectForm(selectedForm + 1);
            // }
            // console.log(formErrors);

            setFormErrors(initialFormErrors);
        }
        //eslint-disable-next-line
    }, [data]);

    // function moveToForm(formNumber: number): void {
    //     const mainDiv = mainDivRef.current;
    //     const containerScrollWidth = mainDiv?.scrollWidth;
    //     const containerRenderedWidth = mainDiv?.clientWidth;

    //     if (containerScrollWidth && containerRenderedWidth) {
    //         const scrollWidth = containerScrollWidth - containerRenderedWidth;
    //         let scrollLeftPosition = 0;

    //         if (formNumber == 2) {
    //             //middle
    //             scrollLeftPosition = scrollWidth / 2;
    //         } else if (formNumber == 3) {
    //             //last
    //             scrollLeftPosition = scrollWidth;
    //         }

    //         mainDiv.scrollTo({
    //             left: scrollLeftPosition,
    //             behavior: "smooth",
    //         });
    //     }
    // }

    // function selectForm(formNumber: number): void {
    //     setSelectedForm(formNumber);
    // }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    function getFormContainerClass(formNumber: number): string {
        const cls = "ft-goe-cap-redesigned-forms-ret";

        // if (selectedForm === formNumber) {
        //     cls += " ft-goe-cap-redesigned-forms-selected";
        // } else if (!FORM_COMPLETE_STATUS[formNumber - 1] && !checkIsFormComplete(formNumber)) {
        //     cls += " disabled";
        // }

        return cls;
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    function checkIsFormComplete(formNumber: number): boolean {
        let formComplete = false;
        const fieldsToValidate = FORM_FIELDS[formNumber - 1];

        for (let index = 0; index < fieldsToValidate.length; index++) {
            const field = fieldsToValidate[index];
            const value = data[field];

            if (formNumber === 3 && field === "initial_investment" && value === "no") {
                formComplete = true;
                initialFormErrors = { ...initialFormErrors, [field]: false };
                break;
            }

            if (value) {
                formComplete = true;
                initialFormErrors = { ...initialFormErrors, [field]: false };
            } else if (field === "draw_income" || (field === "goal_amount" && value === undefined)) {
                initialFormErrors = { ...initialFormErrors, [field]: false };
            } else {
                formComplete = false;
                initialFormErrors = { ...initialFormErrors, [field]: true };
                break;
            }
        }

        FORM_COMPLETE_STATUS[formNumber - 1] = formComplete;

        return formComplete;
    }

    function getOnChangeHandler(formNumber: number, onChangeFunc): ReactEventHandler {
        return (evt: ChangeEvent) => {
            onChangeFunc(evt);
        };
    }
    return (
        <div className="pfs d-flex flex-column forms_container">
            <div className="pfs__body d-flex ft--cap-redesigned-forms-main-div" ref={mainDivRef}>
                <div className={getFormContainerClass(1)} id="pfs-form-1">
                    <PortfolioFormSectionHeaderDiv
                        icon={GoalSec1Icon}
                        classname="ft-goe-cap-redesigned-forms-head-icon-div-sec1"
                    />
                    <div className="pfs__goal-form-body position-relative">
                        <div className="pfs__form-overlay"></div>
                        <form autoComplete="off">
                            <div className="d-flex">
                                <div className="ft-goe-cap-redesigned-forms-ret-left-div">
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Income goal ($)
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="text"
                                            name="draw_income"
                                            value={data.draw_income}
                                            onChange={getOnChangeHandler(1, handleChangeInputDollar)}
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="10,000"
                                        />
                                        {formErrors.draw_income ? (
                                            <p className="pfs__input-error">Goal Amount can not be 0</p>
                                        ) : null}
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    every
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full d-flex">
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["contribution_time"] === "year"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("contribution_time", "year")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["contribution_time"] === "year"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    Year
                                                </span>
                                            </div>
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["contribution_time"] === "month"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("contribution_time", "month")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["contribution_time"] === "month"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    Month
                                                </span>
                                            </div>
                                        </div>
                                        <span className="ft-goe-cap-redesigned-forms-ret-left-button-span">
                                            This frequency will be applied for personal contributions & escalation%
                                        </span>
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Goal Priority
                                                </span>
                                            </div>
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-right">
                                                <img src={InfoCircle}></img>
                                                <span
                                                    className="ft-goe-cap-redesigned-forms-ret-left-div-span-help"
                                                    onClick={setshowGoalPriotiy}
                                                >
                                                    help
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full d-flex">
                                            {GOAL_PRIORITIES.map((priority) => (
                                                <div
                                                    key={priority}
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                        data["goal_priority"] === priority
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                            : ""
                                                    }`}
                                                    onClick={getOnChangeHandler(1, () =>
                                                        onButtonClick("goal_priority", priority)
                                                    )}
                                                >
                                                    <span
                                                        className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                            data["goal_priority"] === priority
                                                                ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                                : ""
                                                        }`}
                                                    >
                                                        {priority}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                        {/* <input type="text" className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full" placeholder="10,000"/> */}
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Start first withdrawal
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="date"
                                            onChange={getOnChangeHandler(1, onChangeDate)}
                                            name="start_first_withdrawal"
                                            value={data["start_first_withdrawal"]}
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="10,000"
                                        />
                                    </div>
                                </div>
                                <div className="ft-goe-cap-redesigned-forms-ret-left-div">
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Last withdrawal
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="date"
                                            onChange={getOnChangeHandler(1, onChangeDate)}
                                            value={data["last_withdrawal"]}
                                            name="last_withdrawal"
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="10,000"
                                        />
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Residual Wealth
                                                </span>
                                            </div>
                                        </div>
                                        <div className="ft-goe-cap-redesigned-forms-ret-div-full d-flex">
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["plan_leave_bequest"] === "yes"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("plan_leave_bequest", "yes")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["plan_leave_bequest"] === "yes"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    Yes
                                                </span>
                                            </div>
                                            <div
                                                className={`ft-goe-cap-redesigned-forms-ret-left-div-button ${
                                                    data["plan_leave_bequest"] === "no"
                                                        ? "ft-goe-cap-redesigned-forms-ret-left-div-button-enable"
                                                        : ""
                                                }`}
                                                onClick={() => onButtonClick("plan_leave_bequest", "no")}
                                            >
                                                <span
                                                    className={`ft-goe-cap-redesigned-forms-ret-left-div-button-span ${
                                                        data["plan_leave_bequest"] === "no"
                                                            ? "ft-goe-cap-redesigned-forms-ret-left-div-button-span-enable"
                                                            : ""
                                                    }`}
                                                >
                                                    No
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="ft-goe-cap-redesigned-forms-ret-div-full">
                                        <div className="d-flex">
                                            <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                                <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                                    Residual Wealth amount
                                                </span>
                                            </div>
                                        </div>
                                        <input
                                            type="text"
                                            value={data["goal_amount"]}
                                            onChange={getOnChangeHandler(1, handleChangeInputDollar)}
                                            name="goal_amount"
                                            className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full"
                                            placeholder="Enter Amount"
                                        />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div className={getFormContainerClass(2)} id="pfs-form-2">
                    <PortfolioFormSectionHeaderDiv
                        icon={DrawIncomeIcon}
                        classnameouter="ft-goe-cap-redesigned-forms-sec1"
                        classname="ft-goe-cap-redesigned-forms-head-icon-div-sec2"
                    />
                    <div className="pfs__goal-form-body position-relative">
                        <div className="pfs__form-overlay"></div>
                        <form className="ft-goe-cap-redesigned-forms-ret-left-div" autoComplete="off">
                            <div className="ft-goe-cap-redesigned-forms-ret-div-full-sec1">
                                <div className="d-flex">
                                    <div className="ft-goe-cap-redesigned-forms-ret-left-div-span-left">
                                        <span className="ft-goe-cap-redesigned-forms-ret-left-div-span">
                                            Initial investment
                                        </span>
                                    </div>
                                </div>
                                <input
                                    type="text"
                                    value={data["initial_investment"]}
                                    onChange={getOnChangeHandler(2, handleChangeInputDollar)}
                                    name="initial_investment"
                                    className="ft-goe-cap-redesigned-forms-ret-left-div-input ft-goe-cap-redesigned-forms-ret-div-full-sec1"
                                    placeholder="Enter Amount"
                                />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default PortfolioFormSectionDrawIncome;
