import React from "react";
import closeIcon from "../../assets/images/svg/x-circle.svg";
import "./Modal.scss";
function Modal(props) {
    const {
        fillingStratagy,
        is_ssc,
        setShowModal,
        responseData,
        goalJson,
        setGoalJson,
        setIsRetshow,
        apiResponse,
        setInputData,
        setcalculatorName,
        inputData,
        isFPT,
        setIsSSCshow,
    } = props;
    // const formatDollar = (dollarValue) => {
    //     // const USDollar = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
    //     if (dollarValue && typeof dollarValue !== "number") {
    //         // return Number(dollarValue.replace(/[$,]/g, ""));
    //         return "$" + digitFromator(dollarValue.replace(/[$,]/g, "")).replace(".00", "");
    //     }
    //     return "$" + digitFromator(dollarValue).replace(".00", "");
    // };

    // const digitFromator = (labelValue) => {
    //     // Nine Zeroes for Billions
    //     return Math.abs(Number(labelValue)) >= 1.0e9
    //         ? (Math.abs(Number(labelValue)) / 1.0e9).toFixed(2) + "B"
    //         : // Six Zeroes for Millions
    //         Math.abs(Number(labelValue)) >= 1.0e6
    //         ? (Math.abs(Number(labelValue)) / 1.0e6).toFixed(2) + "M"
    //         : // Three Zeroes for Thousands
    //         Math.abs(Number(labelValue)) >= 1.0e3
    //         ? (Math.abs(Number(labelValue)) / 1.0e3).toFixed(2) + "K"
    //         : Math.abs(Number(labelValue)).toFixed(2);
    // };
    const formatter = new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
        // minimumFractionDigits: 2
    });

    formatter.format(1000);

    const applyCalculation = () => {
        setGoalJson({
            ...goalJson,
            targeted_retirement_income: formatter.format(responseData.IncomeGoalBeforeTax).replaceAll(".00", ""),
        });
        setShowModal(false);
        setIsRetshow(false);
    };

    const applySocialSecRes = () => {
        setInputData({
            ...inputData,
            socialSecurityIncome: fillingStratagy
                ? "$" + apiResponse.filingStrategyRecommendedReceivablePerMonth.toLocaleString()
                : "$" + apiResponse.socialSecurityReceivablePerMonth.toLocaleString(),
        });
        setShowModal(false);
        if (isFPT) {
            setcalculatorName("Retirement Calculator");
        } else {
            setIsRetshow(true);
            setIsSSCshow(false);
        }
    };

    const dateFormat = (dateString) => {
        const d = new Date(dateString);
        const year = d.getFullYear();
        const month = d.getMonth();
        const day = d.getDate();
        const months = ["Jan", "Feb", "March", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
        const convertedDate = day + " " + months[month] + " " + year;
        return convertedDate;
    };

    return (
        <section className="center">
            <div className="center__inner">
                <div className="content">
                    <input
                        type="checkbox"
                        name="ft-goe-cap-ret-modal__state"
                        id="ft-goe-cap-ret-modal__state"
                        className="ft-goe-cap-ret-modal__state"
                    />
                    <div className="ft-goe-cap-ret-modal__overlay">
                        <label
                            htmlFor="ft-goe-cap-ret-modal__state"
                            className="ft-goe-cap-ret-modal__overlay-close"
                        ></label>
                        <div className="model-fpt-ssc">
                            <label className="modal__close" htmlFor="ft-goe-cap-ret-modal__state">
                                <img src={closeIcon} />
                            </label>
                        </div>
                        {is_ssc ? (
                            <div className="model-fpt-ssc">
                                <label
                                    className="modal__close"
                                    htmlFor="ft-goe-cap-ret-modal__state"
                                    onClick={() => setShowModal(false)}
                                >
                                    <img src={closeIcon} />
                                </label>
                                <div className="display-flex div-heading-model-fpt-ssc">
                                    <hr className="inner-div-line mt-2" />
                                    <span className="main-heading-model-fpt-ssc">Your Social Security Benefits</span>
                                    <hr className="inner-div-line mt-2" />
                                </div>
                                <div className="display-flex">
                                    <div className="inner_div_model-fpt-ssc">
                                        <span className="inner_span_heading_model-fpt-ssc">
                                            {"$" + apiResponse.socialSecurityReceivablePerMonth.toLocaleString()}
                                        </span>
                                        <span className="inner_span_title_model-fpt-ssc">Social Security Income</span>
                                        <span className="inner_span_subtitle_model-fpt-ssc">receivable per month</span>
                                    </div>
                                    <div className="inner_div_model-fpt-ssc">
                                        <span className="inner_span_heading_model-fpt-ssc">
                                            {apiResponse.socialSecurityEntitlementAge}
                                        </span>
                                        <span className="inner_span_title_model-fpt-ssc">Receivable Age</span>
                                        <span className="inner_span_subtitle_model-fpt-ssc">in years</span>
                                    </div>
                                    <div className="inner_div_model-fpt-ssc">
                                        <span className="inner_span_heading_model-fpt-ssc">
                                            {dateFormat(apiResponse.socialSecurityEntitlementDate)}
                                        </span>
                                        <span className="inner_span_title_model-fpt-ssc">Receivable Date</span>
                                        <span className="inner_span_subtitle_model-fpt-ssc">dd mmm yyyy</span>
                                    </div>
                                </div>
                                {fillingStratagy && (
                                    <div>
                                        <div className="display-flex div-heading-model-fpt-ssc">
                                            <hr className="inner-div-line mt-2" />
                                            <span className="main-heading-model-fpt-ssc">
                                                Filing Strategy Recommendations
                                            </span>
                                            <hr className="inner-div-line mt-2" />
                                        </div>
                                        <div className="display-flex">
                                            <div className="inner_div_model-fpt-ssc">
                                                <span className="inner_span_heading_model-fpt-ssc">
                                                    {"$" +
                                                        apiResponse.filingStrategyRecommendedReceivablePerMonth.toLocaleString()}
                                                </span>
                                                <span className="inner_span_title_model-fpt-ssc">
                                                    Social Security Income
                                                </span>
                                                <span className="inner_span_subtitle_model-fpt-ssc">
                                                    receivable per month
                                                </span>
                                            </div>
                                            <div className="inner_div_model-fpt-ssc">
                                                <span className="inner_span_heading_model-fpt-ssc">
                                                    {apiResponse.filingStrategyRecommendedAge}
                                                </span>
                                                <span className="inner_span_title_model-fpt-ssc">Receivable Age</span>
                                                <span className="inner_span_subtitle_model-fpt-ssc">in years</span>
                                            </div>
                                            <div className="inner_div_model-fpt-ssc">
                                                <span className="inner_span_heading_model-fpt-ssc">
                                                    {dateFormat(apiResponse.filingStrategyRecommendedDate)}
                                                </span>
                                                <span className="inner_span_title_model-fpt-ssc">Receivable Date</span>
                                                <span className="inner_span_subtitle_model-fpt-ssc">dd mmm yyyy</span>
                                            </div>
                                        </div>
                                    </div>
                                )}
                                <div className="model-button-div-fpt-ssc" onClick={applySocialSecRes}>
                                    <div className="model-button-fpt-ssc">Apply Social Security Results</div>
                                </div>
                            </div>
                        ) : (
                            <>
                                <div className="model-fpt-ssc">
                                    <label
                                        className="modal__close"
                                        htmlFor="ft-goe-cap-ret-modal__state"
                                        onClick={() => setShowModal(false)}
                                    >
                                        <img src={closeIcon} />
                                    </label>
                                </div>
                                <div className="ft-goe-cap-retcal-modal">
                                    <div className="div-value-model-fpt-ssc">
                                        <div>
                                            <span className="main-heading-model-fpt-rc">
                                                You would need an estimated annual Retirement Income of{" "}
                                            </span>
                                        </div>
                                        <div className="model-inner-div-fpt-rc">
                                            <span className="inner_span_heading_model-fpt-ssc">
                                                {"$" + responseData.IncomeGoalBeforeTax.toLocaleString()}
                                            </span>
                                        </div>
                                        <div className="ft-goe-cap-retcal-subcon-div">
                                            <span className="main-heading-model-fpt-rc">from GOE</span>
                                        </div>
                                        <div className="model-button-div-fpt-ssc">
                                            <div
                                                className={
                                                    isFPT
                                                        ? "model-button-fpt-ssc model-button-fpt-ssc-disable"
                                                        : "model-button-fpt-ssc "
                                                }
                                                onClick={
                                                    isFPT
                                                        ? () => {
                                                              console.log("button disbled");
                                                          }
                                                        : applyCalculation
                                                }
                                            >
                                                <span className="main-heading-model-fpt-rc">Apply Calculations</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Modal;
