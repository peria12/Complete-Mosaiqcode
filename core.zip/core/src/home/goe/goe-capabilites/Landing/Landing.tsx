import React, { useEffect } from "react";
import Features from "../Features/Features";
import Capabilites from "../Capabilites/Capabilites";
import Difference from "../Difference/Difference";
import "./Landing.scss";
import ChartsFrames from "../assets/images/svg/charts_frames.svg";
import SkipButton from "../assets/images/svg/skip-button.svg";
import BackgroundImage1 from "../assets/images/svg/background1.svg";
import BackgroundImage2 from "../assets/images/svg/background_img2.svg";

import BackgroundImage3 from "../assets/images/svg/background2.svg";
import BackgroundImage4 from "../assets/images/svg/background3.svg";
import OverviewBackground from "../assets/images/svg/Overview_background.svg";
import GlobeIcon from "../assets/images/svg/globe-icon.svg";
import Aggressive from "../assets/images/svg/aggressive.svg";
import conservative from "../assets/images/svg/conservative.svg";
import moderate from "../assets/images/svg/moderate.svg";
import DropDown from "../assets/images/svg/caret-down-solid.svg";

import PlanForRetirementImage from "../assets/images/svg/plan-of-retirement.svg"
import OwnAHourse from "../assets/images/svg/own-a-house.svg";
import SaveCollege from "../assets/images/svg/save-college.svg";
import BuyCar from "../assets/images/svg/buy-car.svg";
import TakeVacation from "../assets/images/svg/take-vacation.svg";
import DrawIncome from "../assets/images/svg/draw-income.svg";
import CustomGoal from "../assets/images/svg/custom-goal.svg";

import EachGoalImage from "../assets/images/svg/one-portfolio-each-goal.svg";
import AllGoalsImage from "../assets/images/svg/one-portfolio-all-goal.svg";


function Landing(props: any) {
    const routeFunc = () => {
        props.setRoutingPath("invest");
    };

    useEffect(() => {
        props.setRoutingPath("about");
    }, []);

    return (
        <div className="main-div" style={{
            backgroundImage: `url(${BackgroundImage1}), url(${BackgroundImage2})`
        }}>

            <div onClick={routeFunc} className="main-div-skip-button">
                <img src={SkipButton}></img>
            </div>
            <span className="main-content">What GOE Represents</span>
            <div className="main-image-div">
                <img className="main-image" src={ChartsFrames} alt="charts frames" />
            </div>
            <Features />
            <Capabilites />
            <Difference />

            <div className="goe-capabilites-image-pre-fetch">
                <img src={BackgroundImage3} />
                <img src={BackgroundImage4} />
                <img src={BackgroundImage4} />
                <img src={OverviewBackground} />
                <img src={GlobeIcon} />

                <img src={conservative} />
                <img src={moderate} />
                <img src={Aggressive} />
                <img src={DropDown} />

                <img src={PlanForRetirementImage} />
                <img src={OwnAHourse} />
                <img src={SaveCollege} />
                <img src={BuyCar} />
                <img src={TakeVacation} />
                <img src={DrawIncome} />
                <img src={CustomGoal} />

                <img src={EachGoalImage} />
                <img src={AllGoalsImage} />
            </div>
        </div>
    );
}

export default Landing;
