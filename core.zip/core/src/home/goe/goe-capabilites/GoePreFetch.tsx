import React from "react";
import NoAccess from "./assets/images/svg/no_access.svg";
import ChartsFrames from "./assets/images/svg/charts_frames.svg";
import SkipButton from "./assets/images/svg/skip-button.svg";
import ProbabilityDriveImage from "./assets/images/svg/Probability.svg";
import PersonalisedImage from "./assets/images/svg/Personalised.svg";
import ResponsiveImage from "./assets/images/svg/Responsive.svg";
import Background1 from "./assets/images/svg/background1.svg";
import Background2 from "./assets/images/svg/background_img2.svg";
import GoeIcon from "./assets/images/svg/goe_icon.svg";
import SearchIcon from "./assets/images/svg/search.svg";
import PlanForRetirementIconSelected from "./assets/images/svg/goals_icons/plan_retirement.svg";
import PlanForRetirementIcon from "./assets/images/svg/goals_icons/plan_retirement_dis.svg";
import OwnAHouseIconSelected from "./assets/images/svg/goals_icons/own_house.svg";
import OwnAHouseIcon from "./assets/images/svg/goals_icons/own_house_dis.svg";
import SaveForCollegeIconSelected from "./assets/images/svg/goals_icons/save_college.svg";
import SaveForCollegeIcon from "./assets/images/svg/goals_icons/save_college_dis.svg";
import BuyACarIconSelected from "./assets/images/svg/goals_icons/buy_car.svg";
import BuyACarIcon from "./assets/images/svg/goals_icons/buy_car_dis.svg";
import TakeVacationIconSelected from "./assets/images/svg/goals_icons/take_vacation.svg";
import TakeVacationIcon from "./assets/images/svg/goals_icons/take_vacation_dis.svg";
import DrawIncomeIconSelected from "./assets/images/svg/goals_icons/draw_income.svg";
import DrawIncomeIcon from "./assets/images/svg/goals_icons/draw_income_dis.svg";
import CustomGoalIconSelected from "./assets/images/svg/goals_icons/custom_goal.svg";
import CustomGoalIcon from "./assets/images/svg/goals_icons/custom_goal_dis.svg";

export default function GoePreFetch() {
    return (
        <div className="goe-capabilites-image-pre-fetch">
            <img src={GoeIcon} />
            <img src={Background1} />
            <img src={Background2} />
            <img src={SkipButton}></img>
            <img className="main-image" src={ChartsFrames} alt="charts frames" />
            <img src={ProbabilityDriveImage} />
            <img src={PersonalisedImage} />
            <img src={ResponsiveImage} />
            <img src={NoAccess} />
            <img src={SearchIcon} />
            <img src={PlanForRetirementIconSelected} />
            <img src={PlanForRetirementIcon} />
            <img src={OwnAHouseIconSelected} />
            <img src={OwnAHouseIcon} />
            <img src={SaveForCollegeIconSelected} />
            <img src={SaveForCollegeIcon} />
            <img src={BuyACarIconSelected} />
            <img src={BuyACarIcon} />
            <img src={TakeVacationIconSelected} />
            <img src={TakeVacationIcon} />
            <img src={DrawIncomeIconSelected} />
            <img src={DrawIncomeIcon} />
            <img src={CustomGoalIconSelected} />
            <img src={CustomGoalIcon} />
        </div>
    );
}
