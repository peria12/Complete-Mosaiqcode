import moment from "moment";
import Api from "utils/api";

const environment = {
    dev: {
        clientEmail: "gdasara+9@frk.com",
    },
    test: {
        clientEmail: "goecapabilitiesshowcasetool@franklintempleton.com",
    },
    uat: {
        clientEmail: "goecapabilitiesshowcasetool@franklintempleton.com",
    },
    prod: {
        clientEmail: "goecapabilitiesshowcasetool@franklintempleton.com",
    },
};

const BUILD_ENV = process.env?.REACT_APP_BUILD_ENV || "dev";

export const header = {
    version: 4,
    clientemail: environment[BUILD_ENV].clientEmail,
};

export const headerGenpayload = {
    version: 4,
    clientemail: environment[BUILD_ENV].clientEmail,
    generatepayloadonly: true,
};

const unFormaAmount = (formatterNUmber) => {
    if (formatterNUmber && typeof formatterNUmber !== "number") {
        return Number(formatterNUmber.replace(/[$,]/g, ""));
    }
    return formatterNUmber;
};

const getRangeBetweenDates = (startDate, endDate, type) => {
    const fromDate = moment(startDate, "DD-MM-YYYY");
    const toDate = moment(endDate, "DD-MM-YYYY");
    const diff = toDate.diff(fromDate, type);
    const range: any[] = [];
    for (let i = 0; i <= diff; i++) {
        const date = moment(startDate, "DD-MM-YYYY").add(i, type).format("DD-MM-YYYY");
        range.push(date);
    }
    return range;
};

const getInfusions = (infusionType, goalStartDate, goalEndData, isUpa = false) => {
    const dateFormat = "DD-MM-YYYY";
    const sd = goalStartDate;
    const cd = "01-01-1970";
    const ed = goalEndData;

    let infusionDates: any[] = [];
    const start_year = sd.split("-")[2];
    const end_year = ed.split("-")[2];
    if (infusionType == "yearly") {
        let start_date = moment(sd, dateFormat);
        let end_date = moment(ed, dateFormat);
        if (isUpa) {
            start_date = moment(moment(sd).format(dateFormat), dateFormat);
            end_date = moment(moment(ed).format(dateFormat), dateFormat);
        }

        const cash_date_month = cd.split("-");

        for (let year = start_year; year <= end_year; year++) {
            const infusionDate = cash_date_month[0] + "-" + cash_date_month[1] + "-" + String(year);
            infusionDates.push(infusionDate);
        }
        infusionDates[0] = sd;
        infusionDates[infusionDates.length - 1] = ed;

        let cash_date_start: any = cash_date_month[0] + "-" + cash_date_month[1] + "-" + String(start_year);
        cash_date_start = moment(cash_date_start, dateFormat);

        let cash_date_end: any = cash_date_month[0] + "-" + cash_date_month[1] + "-" + String(end_year);
        cash_date_end = moment(cash_date_end, dateFormat);

        if (start_date < cash_date_start && cash_date_start < moment(infusionDates[1], dateFormat)) {
            const formatted_cash_date_start = moment(cash_date_start).format(dateFormat);
            infusionDates.splice(1, 0, formatted_cash_date_start);
        }
        if (end_date > cash_date_end && cash_date_end > moment(infusionDates[infusionDates.length - 2], dateFormat)) {
            const formatted_cash_date_start = moment(cash_date_end).format(dateFormat);
            infusionDates.splice(infusionDates.length - 1, 0, formatted_cash_date_start);
        }
    } else {
        let start_date = moment(sd, dateFormat);
        let end_date = moment(ed, dateFormat);
        if (isUpa) {
            start_date = moment(moment(sd).format(dateFormat), dateFormat);
            end_date = moment(moment(ed).format(dateFormat), dateFormat);
        }
        const cash_date_month: any = cd.split("-"); //01-01;
        const infusionData: any[] = [];
        infusionDates = getRangeBetweenDates(sd, ed, "months");

        for (let i = 0; i < infusionDates.length; i++) {
            const date = infusionDates[i];
            const dateArr = date.split("-");
            const formated_date: any = cash_date_month[0] + "-" + dateArr[1] + "-" + dateArr[2];
            infusionData.push(formated_date);
        }
        infusionData[0] = sd;
        const lastInfusionDateinRange = moment(infusionData[infusionData.length - 1], "DD-MM-YYYY");
        if (end_date > lastInfusionDateinRange) {
            infusionData.push(ed);
        } else {
            infusionData[infusionData.length - 1] = ed;
        }

        let cash_date_start: any = cash_date_month[0] + "-" + cash_date_month[1] + "-" + String(start_year);
        cash_date_start = moment(cash_date_start, "DD-MM-YYYY");

        let cash_date_end: any = cash_date_month[0] + "-" + cash_date_month[1] + "-" + String(end_year);
        cash_date_end = moment(cash_date_end, "DD-MM-YYYY");

        const second_start_date: any = moment(infusionData[1], "DD-MM-YYYY");
        const second_end_date = moment(infusionData[infusionData.length - 2], "DD-MM-YYYY");

        if (start_date.date() < cash_date_start.date() && cash_date_start.date() <= second_start_date.date()) {
            const formatted_cash_date_start =
                String(cash_date_end.date()) + "-" + String(start_date.month() + 1) + "-" + String(start_date.year());
            infusionData.splice(1, 0, formatted_cash_date_start);
        }
        if (end_date.date() > cash_date_end.date() && cash_date_end.date() >= second_end_date.date()) {
            const formatted_cash_date_end =
                String(cash_date_end.date()) + "-" + String(end_date.month() + 1) + "-" + String(end_date.year());
            infusionData.splice(infusionData.length - 1, 0, formatted_cash_date_end);
        }
        return infusionData;
    }
    return infusionDates;
};

export const transformRetirementInfusions = (
    goalDetails,
    isEditInfusions,
    topUpAmount,
    topUpType = "",
    delayData = {},
    isTenure = false
) => {
    const escalationpercentage = goalDetails["escalation_percentage"] ? goalDetails["escalation_percentage"] * 100 : 0;
    const targetRetirementIncome = goalDetails["targeted_retirement_income"];
    const recurringContribution = goalDetails["recurring_contributions"];
    const dateTenure = moment(delayData["fulldateData"]).format("YYYY-MM-DD");
    const planStartRetirement = goalDetails["plan_start_retirement"];
    const infusionType = goalDetails["my_withdrawal_frequency"] === "Month" ? "monthly" : "yearly";
    const startDate = moment().format("DD-MM-YYYY");
    const planStartDate =
        isEditInfusions && isTenure ? moment(dateTenure, "YYYY-MM-DD") : moment(planStartRetirement, "YYYY-MM-DD");
    const endDate = moment(goalDetails["end_on_date"], "YYYY-MM-DD").format("DD-MM-YYYY");
    const infusions: any = getInfusions(infusionType, startDate, endDate);
    infusions[0] = 0;
    let lastInfusionMonthcount = 1;
    const contributionAmount = unFormaAmount(recurringContribution);
    let lastInfusionAmount = contributionAmount + (contributionAmount * escalationpercentage) / 100;
    let yearContributionRange = 0;
    for (let i = 1; i < infusions.length; i++) {
        const contributionAmount = unFormaAmount(recurringContribution);
        const currentInfusionDate = infusions[i];
        if (moment(currentInfusionDate, "DD-MM-YYYY") < planStartDate) {
            if (escalationpercentage) {
                let infusionamount = 0;
                if (infusionType == "yearly") {
                    if (yearContributionRange == 0) {
                        infusionamount = contributionAmount;
                        yearContributionRange++;
                    } else {
                        infusionamount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                    }
                } else {
                    if (lastInfusionMonthcount == 12) {
                        lastInfusionMonthcount = 0;
                        lastInfusionAmount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                    }
                    infusionamount = lastInfusionAmount;
                    lastInfusionMonthcount++;
                }
                if (isEditInfusions && topUpType !== "Dec") {
                    infusionamount = infusionamount + topUpAmount;
                    infusions[i] = Math.floor(infusionamount);
                }
                infusions[i] = Math.floor(infusionamount);
                lastInfusionAmount = infusionamount;
            } else {
                if (isEditInfusions && topUpType !== "Dec") {
                    infusions[i] = Math.floor(contributionAmount + topUpAmount);
                } else {
                    infusions[i] = Math.floor(contributionAmount);
                }
            }
        } else {
            const infusionRetirementamount = unFormaAmount(targetRetirementIncome);
            if (isEditInfusions && topUpType === "Dec") {
                infusions[i] = -infusionRetirementamount + topUpAmount;
            } else {
                infusions[i] = -infusionRetirementamount;
            }
        }
    }

    if (infusions[infusions.length - 1] == endDate) {
        infusions[infusions.length - 1] = contributionAmount;
    } else {
        infusions[infusions.length - 1] = 0;
    }
    return infusions;
};

export const runPipeController = (
    goalDetails,
    basicInfo,
    generatepayloadonly,
    isEditInfusions,
    topUpAmount,
    delayData = {},
    topUpType = "",
    isTenure = false
) => {
    const todayDate = moment(new Date()).format("DD-MM-YYYY");

    let request = {};
    if (goalDetails["goal_key"] === "plan_retirement") {
        const infusionType = goalDetails["my_withdrawal_frequency"] === "Month" ? "monthly" : "yearly";
        const infusions: any = transformRetirementInfusions(
            goalDetails,
            isEditInfusions,
            topUpAmount,
            topUpType,
            delayData,
            isTenure
        );

        request = {
            isNewGoalPriority: true,
            isNewRiskProfile: true,
            isNewInvestmentTenure: true,
            isNewGoal: true,
            getPath: true,
            currentPortfolioId: null,
            riskProfile: basicInfo["risk_profile_type"],
            initialInvestment: unFormaAmount(goalDetails["initial_investment"]),
            cashflowDate: null,
            currentWealth: unFormaAmount(goalDetails["initial_investment"]),
            goalPriority: goalDetails["goal_priority"],
            reallocationFreq: "yearly",
            goalAmount: unFormaAmount(goalDetails["goal_amount"]),
            startDate: todayDate,
            endDate: moment(new Date(goalDetails["end_on_date"])).format("DD-MM-YYYY"),
            infusions: infusions,
            scenarioType: "retirement",
            infusionType: infusionType,
            currDate: todayDate,
            lossThreshold: null,
            considerMortality: false,
            riskOverride: false,
            calibrateRecommendations: true,
        };
    } else if (goalDetails["goal_key"] === "draw_income") {
        const planStart = goalDetails["start_first_withdrawal"];
        const infusionType = goalDetails["contribution_time"] === "month" ? "monthly" : "yearly";
        const planStartDate = moment(planStart, "YYYY-MM-DD");
        const endDate = moment(goalDetails["last_withdrawal"], "YYYY-MM-DD").format("DD-MM-YYYY");
        const startDate = moment().format("DD-MM-YYYY");
        const infusions: any = getInfusions(infusionType, startDate, endDate);
        infusions[0] = 0;
        const drawIncome = goalDetails["draw_income"];
        const withDrawl = unFormaAmount(drawIncome);

        for (let i = 1; i < infusions.length; i++) {
            const currentInfusionDate = infusions[i];
            if (moment(currentInfusionDate, "DD-MM-YYYY") < planStartDate) {
                infusions[i] = 0;
            } else {
                if (isEditInfusions) {
                    infusions[i] = -withDrawl + topUpAmount;
                } else {
                    infusions[i] = -withDrawl;
                }
            }
        }

        if (infusions[infusions.length - 1] == endDate) {
            if (isEditInfusions) {
                infusions[infusions.length - 1] = -withDrawl + topUpAmount;
            } else {
                infusions[infusions.length - 1] = -withDrawl;
            }
        } else {
            infusions[infusions.length - 1] = 0;
        }

        request = {
            isNewGoalPriority: true,
            isNewRiskProfile: true,
            isNewInvestmentTenure: true,
            isNewGoal: true,
            getPath: true,
            currentPortfolioId: null,
            riskProfile: basicInfo["risk_profile_type"],
            initialInvestment: unFormaAmount(goalDetails["initial_investment"]),
            cashflowDate: null,
            currentWealth: unFormaAmount(goalDetails["initial_investment"]),
            goalPriority: goalDetails["goal_priority"],
            reallocationFreq: "yearly",
            goalAmount: unFormaAmount(goalDetails["goal_amount"]),
            startDate: todayDate,
            endDate: moment(new Date(goalDetails["last_withdrawal"])).format("DD-MM-YYYY"),
            scenarioType: "retirement",
            infusionType: infusionType,
            infusions: infusions,
            currDate: todayDate,
            lossThreshold: null,
            considerMortality: false,
            riskOverride: false,
            calibrateRecommendations: true,
        };
    } else {
        const infusionType = goalDetails["contribution_time"] === "month" ? "monthly" : "yearly";
        const recurringContribution = goalDetails["recurring_contributions"];
        const escalationpercentage = goalDetails["escalation_percentage"] * 100;

        const startDate = moment(new Date()).format("DD-MM-YYYY");
        const endDate = moment(goalDetails["achieve_this_goal"]).format("DD-MM-YYYY");

        const infusions: any = getInfusions(infusionType, startDate, endDate);

        infusions[0] = 0;
        let lastInfusionMonthcount = 1;
        const contributionAmount = unFormaAmount(recurringContribution);
        let lastInfusionAmount = contributionAmount;
        const contributionRange = goalDetails["every_years"];
        let contributionRangeCount = 0;
        for (let i = 1; i < infusions.length; i++) {
            const contributionAmount = unFormaAmount(recurringContribution);
            if (escalationpercentage) {
                let infusionamount = 0;
                if (infusionType == "yearly") {
                    if (contributionRangeCount < contributionRange) {
                        infusionamount = lastInfusionAmount;
                        contributionRangeCount++;
                    } else {
                        infusionamount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                        contributionRangeCount = 1;
                    }
                } else {
                    if (lastInfusionMonthcount == 12) {
                        lastInfusionMonthcount = 0;

                        if (contributionRangeCount < contributionRange) {
                            infusionamount = lastInfusionAmount;
                            contributionRangeCount++;
                        } else {
                            lastInfusionAmount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                            contributionRangeCount = 1;
                        }
                    } else {
                        if (contributionRangeCount == 0) {
                            contributionRangeCount = 1;
                        }
                    }
                    infusionamount = lastInfusionAmount;
                    lastInfusionMonthcount++;
                }
                if (isEditInfusions) {
                    infusionamount = infusionamount + topUpAmount;
                    infusions[i] = Math.floor(infusionamount);
                }
                infusions[i] = Math.floor(infusionamount);

                lastInfusionAmount = infusionamount;
            } else {
                if (isEditInfusions) {
                    infusions[i] = Math.floor(contributionAmount + topUpAmount);
                } else {
                    infusions[i] = Math.floor(contributionAmount);
                }
            }
        }

        if (infusions[infusions.length - 1] == endDate) {
            infusions[infusions.length - 1] = contributionAmount;
        } else {
            infusions[infusions.length - 1] = 0;
        }

        request = {
            isNewGoalPriority: true,
            isNewRiskProfile: true,
            isNewInvestmentTenure: true,
            isNewGoal: true,
            getPath: true,
            currentPortfolioId: null,
            riskProfile: basicInfo["risk_profile_type"],
            initialInvestment: unFormaAmount(goalDetails["initial_investment"]),
            cashflowDate: null,
            currentWealth: unFormaAmount(goalDetails["initial_investment"]),
            goalPriority: goalDetails["goal_priority"],
            reallocationFreq: "yearly",
            goalAmount: unFormaAmount(goalDetails["goal_amount"]),
            startDate: todayDate,
            endDate: moment(new Date(goalDetails["achieve_this_goal"])).format("DD-MM-YYYY"),
            infusions: infusions,
            scenarioType: "regular",
            infusionType: infusionType,
            currDate: todayDate,
            lossThreshold: null,
            considerMortality: false,
            riskOverride: false,
            calibrateRecommendations: true,
        };
    }

    const header = {
        version: 4,
        clientemail: environment[BUILD_ENV].clientEmail,
        generatepayloadonly: generatepayloadonly,
    };

    return Api.runPipe(request, header);
};

export const wealthSplitterController = (goalList, basicInfo) => {
    const unFormaAmount = (formatterNUmber) => {
        if (formatterNUmber && typeof formatterNUmber !== "number") {
            return Number(formatterNUmber.replace(/[$,]/g, ""));
        }
        return formatterNUmber;
    };

    const goalprofileList = goalList.map((goalData, index) => {
        let infusionType;
        let scenarioType;
        let reqEndDate;
        let infusions: any;
        if (goalData["goal_key"] === "plan_retirement") {
            scenarioType = "retirement";
            const escalationpercentage = goalData["escalation_precentage"];
            const targetRetirementIncome = goalData["targeted_retirement_income"];
            const recurringContribution = goalData["recurring_contributions"];
            const planStartRetirement = goalData["plan_start_retirement"];
            infusionType = goalData["my_withdrawal_frequency"] === "Month" ? "monthly" : "yearly";
            const planStartDate = moment(planStartRetirement, "YYYY-MM-DD");
            reqEndDate = moment(goalData["end_on_date"]).format("DD-MM-yyyy");
            const startDate = moment().format("DD-MM-YYYY");
            const endDate = moment(goalData["end_on_date"], "YYYY-MM-DD").format("DD-MM-YYYY");

            infusions = getInfusions(infusionType, startDate, endDate);
            infusions[0] = 0;
            let lastInfusionMonthcount = 1;
            const contributionAmount = unFormaAmount(recurringContribution);
            let yearContributionRange = 0;
            let lastInfusionAmount = contributionAmount + (contributionAmount * escalationpercentage) / 100;
            for (let i = 1; i < infusions.length; i++) {
                const contributionAmount = unFormaAmount(recurringContribution);
                const currentInfusionDate = infusions[i];
                if (moment(currentInfusionDate, "DD-MM-YYYY") < planStartDate) {
                    if (escalationpercentage) {
                        let infusionamount = 0;
                        if (infusionType == "yearly") {
                            if (yearContributionRange == 0) {
                                infusionamount = contributionAmount;
                                yearContributionRange++;
                            } else {
                                infusionamount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                            }
                        } else {
                            if (lastInfusionMonthcount == 12) {
                                lastInfusionMonthcount = 0;
                                lastInfusionAmount =
                                    lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                            }
                            infusionamount = lastInfusionAmount;
                            lastInfusionMonthcount++;
                        }
                        infusions[i] = Math.floor(infusionamount);
                        lastInfusionAmount = infusionamount;
                    } else {
                        infusions[i] = Math.floor(contributionAmount);
                    }
                } else {
                    const infusionRetirementamount = unFormaAmount(targetRetirementIncome);
                    infusions[i] = -infusionRetirementamount;
                }
            }

            if (infusions[infusions.length - 1] == endDate) {
                infusions[infusions.length - 1] = contributionAmount;
            } else {
                infusions[infusions.length - 1] = 0;
            }
        } else if (goalData["goal_key"] === "draw_income") {
            const planStart = goalData["start_first_withdrawal"];
            scenarioType = "retirement";
            infusionType = goalData["contribution_time"] === "month" ? "monthly" : "yearly";
            const planStartDate = moment(planStart, "YYYY-MM-DD");
            reqEndDate = moment(goalData["last_withdrawal"]).format("DD-MM-yyyy");
            const endDate = moment(goalData["last_withdrawal"], "YYYY-MM-DD").format("DD-MM-YYYY");
            const startDate = moment().format("DD-MM-YYYY");
            infusions = getInfusions(infusionType, startDate, endDate);
            infusions[0] = 0;
            const drawIncome = goalData["draw_income"];
            const withDrawl = unFormaAmount(drawIncome);

            for (let i = 1; i < infusions.length; i++) {
                const currentInfusionDate = infusions[i];
                if (moment(currentInfusionDate, "DD-MM-YYYY") < planStartDate) {
                    infusions[i] = 0;
                } else {
                    infusions[i] = -withDrawl;
                }
            }

            if (infusions[infusions.length - 1] == endDate) {
                infusions[infusions.length - 1] = -withDrawl;
            } else {
                infusions[infusions.length - 1] = 0;
            }
        } else {
            scenarioType = "regular";
            infusionType = goalData["contribution_time"] === "month" ? "monthly" : "yearly";
            const recurringContribution = goalData["recurring_contributions"];
            const escalationpercentage = goalData["escalation_percentage"] * 100;
            reqEndDate = moment(goalData["achieve_this_goal"]).format("DD-MM-yyyy");
            const startDate = moment(new Date()).format("DD-MM-YYYY");
            const endDate = moment(goalData["achieve_this_goal"]).format("DD-MM-YYYY");
            infusions = getInfusions(infusionType, startDate, endDate);
            infusions[0] = 0;
            let lastInfusionMonthcount = 1;
            const contributionAmount = unFormaAmount(recurringContribution);
            let lastInfusionAmount = contributionAmount;
            const contributionRange = goalData["every_years"];
            let contributionRangeCount = 0;
            for (let i = 1; i < infusions.length; i++) {
                const contributionAmount = unFormaAmount(recurringContribution);
                if (escalationpercentage) {
                    let infusionamount = 0;
                    if (infusionType == "yearly") {
                        if (contributionRangeCount < contributionRange) {
                            infusionamount = lastInfusionAmount;
                            contributionRangeCount++;
                        } else {
                            infusionamount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                            contributionRangeCount = 1;
                        }
                    } else {
                        if (lastInfusionMonthcount == 12) {
                            lastInfusionMonthcount = 0;

                            if (contributionRangeCount < contributionRange) {
                                infusionamount = lastInfusionAmount;
                                contributionRangeCount++;
                            } else {
                                lastInfusionAmount =
                                    lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                                contributionRangeCount = 1;
                            }
                        } else {
                            if (contributionRangeCount == 0) {
                                contributionRangeCount = 1;
                            }
                        }
                        infusionamount = lastInfusionAmount;
                        lastInfusionMonthcount++;
                    }
                    infusions[i] = Math.floor(infusionamount);

                    lastInfusionAmount = infusionamount;
                } else {
                    infusions[i] = Math.floor(contributionAmount);
                }
            }

            if (infusions[infusions.length - 1] == endDate) {
                infusions[infusions.length - 1] = contributionAmount;
            } else {
                infusions[infusions.length - 1] = 0;
            }
        }

        return {
            goalId: goalData["goal-key"] || "Goal_" + index,
            goalValue: unFormaAmount(goalData["goal_amount"]),
            cashflowType: infusionType,
            scenarioType: scenarioType,
            purpose: goalData["name"],
            goalPriority: goalData["goal_priority"],
            currWealth: unFormaAmount(goalData["initial_investment"]),
            cashflowDate: "01-01-2023",
            lossThreshold: null,
            cashflow: infusions,
            endDate: reqEndDate,
        };
    });

    const iwsRuquest = {
        currDate: moment().format("DD-MM-yyyy"),
        startDate: moment().format("DD-MM-yyyy"),
        riskProfile: basicInfo["risk_profile_type"],
        engagedParticipant: false,
        goalProfileList: goalprofileList,
    };

    return Api.wealthSplitter(iwsRuquest, header);
};

export const UPAController = (goalList, basicInfo, generatepayloadonly, isEdit = false, topUpAmount = 0) => {
    const unFormaAmount = (formatterNUmber) => {
        if (formatterNUmber && typeof formatterNUmber !== "number") {
            return Number(formatterNUmber.replace(/[$,]/g, ""));
        }
        return formatterNUmber;
    };
    let initialInvestment = 0;
    const infusionsRegular: any = [];
    const goalsArray = [{}];
    // unFormaAmount(goalDetails["goal_amount"])
    const todayDate = moment(new Date()).format("MM-DD-YYYY");
    // const planStartRetirement = goalDetails["plan_start_retirement"];
    for (let i = 0; i < goalList.length; i++) {
        const planStartRetirement = goalList[i]["plan_start_retirement"];
        const planStartDate = moment(planStartRetirement).format("MM-DD-YYYY");
        const startDrawIncome = goalList[i]["start_first_withdrawal"];
        const drawIncomeStartDate = moment(startDrawIncome).format("MM-DD-YYYY");

        let startDate =
            goalList[i]["goal_key"] === "plan_retirement"
                ? planStartDate
                : goalList[i]["goal_key"] === "draw_income"
                ? drawIncomeStartDate
                : todayDate;

        const d1 = new Date();
        const d2 = new Date(startDate);
        if (
            (goalList[i]["goal_key"] === "plan_retirement" || goalList[i]["goal_key"] === "draw_income") &&
            d1.setHours(0, 0, 0, 0).valueOf() > d2.setHours(0, 0, 0, 0).valueOf()
        ) {
            startDate = moment("01-01-" + (d1.getFullYear() + 1).toString()).format("MM-DD-YYYY");
        }
        // else{
        //     // startDate = moment(d1.toLocaleDateString('en-ca')).format('DD-MM-YYYY');
        //     // const planStartDate = moment(startDate, "YYYY-MM-DD");
        //     const planStartDate1 = moment(planStartRetirement, "YYYY-MM-DD").format("DD-MM-YYYY");
        //     startDate = planStartDate1
        // }

        const goalDetails = goalList[i];
        let infusionsAmt: any = [];
        const merge = (a, b, predicate = (a, b) => a === b) => {
            const c = [...a]; // copy to avoid side effects
            // add all items from B to copy C if they're not already present
            b.forEach((bItem) => (c.some((cItem) => predicate(bItem, cItem)) ? null : c.push(bItem)));
            return c;
        };
        if (goalDetails["goal_key"] === "plan_retirement") {
            const escalationpercentage = goalDetails["escalation_precentage"];
            let targetRetirementIncome = unFormaAmount(goalDetails["targeted_retirement_income"]);
            const recurringContribution = goalDetails["recurring_contributions"];
            let planStartRetirement = goalDetails["plan_start_retirement"];
            const d1 = new Date();
            const d2 = new Date(planStartRetirement);
            if (d1.setHours(0, 0, 0, 0).valueOf() > d2.setHours(0, 0, 0, 0).valueOf()) {
                planStartRetirement = moment("01-01-" + (d2.getFullYear() + 1).toString()).format("YYYY-MM-DD");
            }
            const infusionType = goalDetails["my_withdrawal_frequency"] === "Month" ? "monthly" : "yearly";
            const startDateToday = moment().format("MM-DD-YYYY");
            const planStartDate = moment(planStartRetirement, "YYYY-MM-DD");
            // const planStartDate1 = moment(planStartRetirement, "YYYY-MM-DD").format("MM-DD-YYYY");
            const endDate = moment(goalDetails["end_on_date"], "YYYY-MM-DD").format("MM-DD-YYYY");
            // const infusions: any = getInfusions("yearly", startDateToday, endDate);
            const infusions2: any = getInfusions("yearly", startDateToday, startDate, true);
            const infusions1: any = getInfusions("yearly", startDate, endDate, true);
            const infusions = merge(infusions2, infusions1);
            const infusionsAmtData: any = getInfusions("yearly", startDate, endDate, true);
            let contributionAmount = unFormaAmount(recurringContribution);
            if (infusionType === "monthly") {
                targetRetirementIncome = targetRetirementIncome * 12;
                contributionAmount = contributionAmount * 12;
            }
            infusionsAmt = infusionsAmtData.map(() => {
                return targetRetirementIncome;
            });

            infusions[0] = 0;
            const infusionDateData: any = [{ [startDateToday]: 0 }];
            // const infusionDateData: any = [];
            let lastInfusionMonthcount = 1;
            let lastInfusionAmount = contributionAmount + (contributionAmount * escalationpercentage) / 100;
            for (let j = 1; j < infusions.length; j++) {
                const contributionAmount = unFormaAmount(recurringContribution);
                const currentInfusionDate = infusions[j];
                if (moment(currentInfusionDate, "MM-DD-YYYY") < planStartDate) {
                    if (infusions[j] == endDate) {
                        infusionDateData.push({
                            [infusions[infusions.length - 1]]: -targetRetirementIncome,
                        });
                        infusions[infusions.length - 1] = contributionAmount;
                    } else {
                        if (escalationpercentage) {
                            let infusionamount = 0;
                            if (infusionType == "yearly") {
                                infusionamount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                            } else {
                                if (lastInfusionMonthcount == 12) {
                                    lastInfusionMonthcount = 0;
                                    lastInfusionAmount =
                                        lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                                }
                                infusionamount = lastInfusionAmount;
                                lastInfusionMonthcount++;
                            }
                            infusionDateData.push({ [infusions[j]]: infusionamount });
                            // infusions[i] = Math.floor(infusionamount);
                            lastInfusionAmount = infusionamount;
                        } else {
                            infusionDateData.push({
                                [infusions[j]]: Math.floor(contributionAmount),
                            });
                            // infusions[i] = Math.floor(contributionAmount);
                        }
                    }
                } else {
                    if (infusions[j] == endDate) {
                        infusionDateData.push({
                            [infusions[infusions.length - 1]]: -targetRetirementIncome,
                        });
                        infusions[infusions.length - 1] = contributionAmount;
                    } else {
                        const infusionRetirementamount = targetRetirementIncome;
                        infusionDateData.push({
                            [infusions[j]]: -infusionRetirementamount,
                        });
                    }
                }
            }

            infusionsRegular.push(infusionDateData);
        } else if (goalDetails["goal_key"] === "draw_income") {
            const planStart = goalDetails["start_first_withdrawal"];
            const planStartDate = moment(planStart, "YYYY-MM-DD");
            const infusionType = goalDetails["contribution_time"] === "month" ? "monthly" : "yearly";
            const endDate = moment(goalDetails["last_withdrawal"], "YYYY-MM-DD").format("MM-DD-YYYY");
            const infusionsAmtData: any = getInfusions("yearly", startDate, endDate, true);
            const infusions: any = getInfusions("yearly", startDate, endDate, true);
            const infusionslen = infusionsAmtData.length;
            const drawIncome = goalDetails["draw_income"];
            let withDrawl = unFormaAmount(drawIncome);
            if (infusionType === "monthly") {
                withDrawl = withDrawl * 12;
            }
            // else{
            //     infusionsAmt = infusionsAmtData.map(() => {
            //         return unFormaAmount(withDrawl);
            //     });
            // }
            const infusionDateData: any = [];
            // const infusionDateData: any = [{ [startDate]: 0 }];
            // infusionsAmt.push(withDrawl)
            for (let j = 0; j < infusionslen; j++) {
                if (infusions[j] == endDate) {
                    infusionDateData.push({
                        [infusions[infusions.length - 1]]: -withDrawl,
                    });
                } else {
                    const currentInfusionDate = infusions[i];
                    if (moment(currentInfusionDate, "MM-DD-YYYY") < planStartDate) {
                        infusionDateData.push({ [infusions[j]]: 0 });
                    } else {
                        infusionDateData.push({ [infusions[j]]: -withDrawl });
                    }
                }
                infusionsAmt.push(withDrawl);
            }
            infusionsRegular.push(infusionDateData);
        } else {
            const infusionType = goalDetails["contribution_time"] === "month" ? "monthly" : "yearly";
            const recurringContribution = goalDetails["recurring_contributions"];
            const escalationpercentage = goalDetails["escalation_percentage"] * 100;

            const startDate = moment(new Date()).format("MM-DD-YYYY");
            const endDate = moment(goalDetails["achieve_this_goal"]).format("MM-DD-YYYY");

            const infusions: any = getInfusions("yearly", startDate, endDate, true);
            infusions[0] = 0;
            const infusionDateData: any = [{ [startDate]: unFormaAmount(goalDetails["initial_investment"]) }];
            let lastInfusionMonthcount = 1;
            let contributionAmount = unFormaAmount(recurringContribution);
            if (infusionType === "monthly") {
                contributionAmount = contributionAmount * 12;
            }
            let lastInfusionAmount = contributionAmount + (contributionAmount * escalationpercentage) / 100;
            for (let j = 1; j < infusions.length; j++) {
                const contributionAmount = unFormaAmount(recurringContribution);
                if (escalationpercentage) {
                    if (infusions[j] != endDate) {
                        let infusionamount = 0;
                        if (infusionType == "yearly") {
                            infusionamount = lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                        } else {
                            if (lastInfusionMonthcount == 12) {
                                lastInfusionMonthcount = 0;
                                lastInfusionAmount =
                                    lastInfusionAmount + (lastInfusionAmount * escalationpercentage) / 100;
                            }
                            infusionamount = lastInfusionAmount;
                            lastInfusionMonthcount++;
                        }

                        infusionDateData.push({ [infusions[j]]: infusionamount });
                        infusions[j] = Math.floor(infusionamount);
                        lastInfusionAmount = infusionamount;
                    } else {
                        infusionDateData.push({
                            [infusions[infusions.length - 1]]: -unFormaAmount(goalList[i]["goal_amount"]),
                        });
                    }
                } else {
                    if (infusions[j] != endDate) {
                        4;
                        infusionDateData.push({
                            [infusions[j]]: Math.floor(contributionAmount),
                        });
                        // infusions[infusions.length - 1] = contributionAmount;
                    } else {
                        infusionDateData.push({
                            [infusions[infusions.length - 1]]: -unFormaAmount(goalList[i]["goal_amount"]),
                        });
                    }
                }
            }

            infusionsRegular.push(infusionDateData);
        }

        initialInvestment = initialInvestment + unFormaAmount(goalList[i]["initial_investment"]);

        // achieve_this_goal
        const endDateReg = moment(goalList[i]["achieve_this_goal"]).format("MM-DD-YYYY");
        const endPlanRet = moment(goalList[i]["end_on_date"]).format("MM-DD-YYYY");
        const endDrawIncome = moment(goalList[i]["last_withdrawal"]).format("MM-DD-YYYY");

        const endDate =
            goalList[i]["goal_key"] === "plan_retirement"
                ? endPlanRet
                : goalList[i]["goal_key"] === "draw_income"
                ? endDrawIncome
                : endDateReg;

        // const infusionsAmtFinal = infusionsAmt.filter((item)=> item!=null)
        const scenarioType =
            goalList[i]["goal_key"] === "plan_retirement" || goalList[i]["goal_key"] === "draw_income"
                ? "retirement"
                : "regular";
        const goalJson = {
            goalID: goalList[i]["name"],
            goalAmt:
                goalDetails["goal_key"] === "plan_retirement" || goalDetails["goal_key"] === "draw_income"
                    ? infusionsAmt
                    : [unFormaAmount(goalList[i]["goal_amount"])],
            startDate: moment(startDate).format("DD-MM-YYYY"),
            endDate: moment(endDate).format("DD-MM-YYYY"),
            priority: goalList[i]["goal_priority"],
            scenarioType: scenarioType,
        };
        goalsArray.push(goalJson);
    }

    const finalAllGoalData = infusionsRegular;
    const dataDict = {};
    const infusionArray: any = [];
    for (let i = 0; i < finalAllGoalData.length; i++) {
        for (let k = 0; k < finalAllGoalData[i].length; k++) {
            if (dataDict[Object.keys(finalAllGoalData[i][k])[0]]) {
                dataDict[Object.keys(finalAllGoalData[i][k])[0]] =
                    dataDict[Object.keys(finalAllGoalData[i][k])[0]] +
                    finalAllGoalData[i][k][Object.keys(finalAllGoalData[i][k])[0]];
            } else {
                dataDict[Object.keys(finalAllGoalData[i][k])[0]] =
                    finalAllGoalData[i][k][Object.keys(finalAllGoalData[i][k])[0]];
            }
        }
    }

    const dates = Object.keys(dataDict).map((dateStr) => new Date(dateStr));
    dates.sort((a, b) => a.getTime() - b.getTime());
    const sortedDateObject = {};
    dates.forEach((date) => {
        const formattedDate = moment(date).format("MM-DD-YYYY");
        sortedDateObject[formattedDate] = dataDict[formattedDate];
    });
    for (const key in sortedDateObject) {
        infusionArray.push(sortedDateObject[key]);
    }
    // infusionArray.push(0);
    goalsArray.shift();
    const request = {
        isNewRiskProfile: true,
        isNewInvestmentTenure: true,
        isNewGoalPriority: true,
        isNearTermVolatility: true,
        isNewGoal: true,
        getPath: true,
        reallocationFreq: "yearly",
        initialInvestment: isEdit ? initialInvestment + topUpAmount : initialInvestment,
        currentWealth: isEdit ? initialInvestment + topUpAmount : initialInvestment,
        currentPortfolioId: null,
        currDate: moment(todayDate).format("DD-MM-YYYY"),
        infusions: infusionArray,
        riskProfile: basicInfo["risk_profile_type"],
        cashflowDate: null,
        infusionType: "yearly",
        goalProfileList: goalsArray,
    };

    const header = {
        version: 4,
        clientemail: environment[BUILD_ENV].clientEmail,
        generatepayloadonly: generatepayloadonly,
    };

    return Api.UPA(request, header);
};
