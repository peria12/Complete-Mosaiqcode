import React from "react";
import "./Difference.scss";
import TgpImage from "../assets/images/svg/tgp.svg";
import DynamicReallocationImage from "../assets/images/svg/dynamic_relocation.svg";
import MultiplePrioritiesImage from "../assets/images/svg/multipriorites.svg";
import FiniteTimeHorizonsImage from "../assets/images/svg/finite_time.svg";
import LiquidityConstraintsImage from "../assets/images/svg/liquidity_const.svg";
import TaxPlanningImage from "../assets/images/svg/tax_planning.svg";
function Difference() {
    interface ListData {
        id: number;
        titleRight: string;
        titleLeft: string;
        contentRight: string;
        contentLeft: string;
        image: string;
        alt: string;
    }

    const DIFFRENCES: ListData[] = [
        {
            id: 1,
            titleRight: "Targets Risk/Volatility",
            titleLeft: "Targets Goal Probability",
            contentRight: "Risk-based approach targets risk/volatility",
            contentLeft: "GOE targets probability of success",
            image: TgpImage,
            alt: "Targets Risk/Volatility",
        },
        {
            id: 2,
            titleRight: "Static Portfolio",
            titleLeft: "Dynamic Reallocation",
            contentRight: "The traditional approach sticks to one portfolio/risk target ",
            contentLeft:
                "As markets and goal change, GOE will reallocate the portfolio as needed to keep probability of success high",
            image: DynamicReallocationImage,
            alt: "Dynamic Reallocation",
        },
        {
            id: 3,
            titleRight: "One treatment for all",
            titleLeft: "Multiple Priorities",
            contentRight:
                "Portfolios are often managed to a single risk tolerance, without an ability to treat goals differently ",
            contentLeft: "Individuals have multiple goals with different importance and priority",
            image: MultiplePrioritiesImage,
            alt: "Multiple Priorities",
        },
        {
            id: 4,
            titleRight: "Perpetual",
            titleLeft: "Finite Time Horizons",
            contentRight: "Portfolios exist in perpetuity",
            contentLeft: "Goals have finite time horizons",
            image: FiniteTimeHorizonsImage,
            alt: "Finite Time Horizons",
        },
        {
            id: 5,
            titleRight: "Underfunding",
            titleLeft: "Liquidity Constraints",
            contentRight: "Institutions can withstand periods of underfunding",
            contentLeft: "Individuals have liquidity constraints",
            image: LiquidityConstraintsImage,
            alt: "Liquidity Constraints",
        },
        {
            id: 6,
            titleRight: "No Tax Planning",
            titleLeft: "Tax Planning",
            contentRight: "Investment solutions often don’t align to tax situation",
            contentLeft: "Planning includes taxes",
            image: TaxPlanningImage,
            alt: "Tax Planning",
        },
    ];
    return (
        <div className="difference-main-div-outer landing-components">
            <div className="difference-heading-div">
                <span className="components-heading-content">How is&nbsp;</span>
                <span className="components-heading-content components-heading-content-blue">GOE</span>
                <span className="components-heading-content">&nbsp;different ?</span>
            </div>
            <div className="difference-heading-subcontent-div">
                <span className="components-heading-subcontent">
                    Understand how GOE is superior to a traditional risk based approach
                </span>
            </div>
            <div className="difference-heading-subcontent-div">
                <span className="components-heading-subcontent">in these six ways.</span>
            </div>
            <div className="difference-main-div">
                <div className="d-flex">
                    <div className="circle-div">
                        {DIFFRENCES.map((item, index) => {
                            return (
                                <div key={item.id}>
                                    <div
                                        className={
                                            index != DIFFRENCES.length - 1
                                                ? "d-flex inner-component-div-bottom"
                                                : "d-flex inner-component-div"
                                        }
                                    >
                                        <div className="circle-mid">
                                            <img className="circle-mid-img" src={item.image} alt={item.alt}></img>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    <div className="goal-optimization-engine">
                        <div className="line-div">
                            <strong className="difference-header-content difference-header-left-content">
                                GOE Approach
                            </strong>
                        </div>
                        {DIFFRENCES.map((item, index) => {
                            return (
                                <div key={item.id}>
                                    <div
                                        className={
                                            index != DIFFRENCES.length - 1
                                                ? "d-flex inner-component-div-bottom"
                                                : "d-flex inner-component-div"
                                        }
                                    >
                                        <div className="line-div">
                                            <strong className="title-up">{item.titleLeft}</strong>
                                            <span className="subcontent">{item.contentLeft}</span>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    <div className="reach-based-approch-div">
                        <div className="line-div">
                            <strong className="difference-header-content difference-header-right-content reach-based-approch-div-inner">
                                {" "}
                                Risk-Based Approach
                            </strong>
                        </div>
                        {DIFFRENCES.map((item, index) => {
                            return (
                                <div key={item.id}>
                                    <div
                                        className={
                                            index != DIFFRENCES.length - 1
                                                ? "d-flex inner-component-div-bottom"
                                                : "d-flex inner-component-div"
                                        }
                                    >
                                        <div className="line-div reach-based-approch-div-inner">
                                            <strong className="riskTitle">{item.titleRight}</strong>
                                            <span className="subcontent">{item.contentRight}</span>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Difference;
