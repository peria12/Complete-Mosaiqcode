import React, { useEffect, useState, useMemo } from "react";
import "./Invest.scss";
import allGoals from "./Invest_json";
import BackImage from "../../assets/images/svg/arrow-left-back.svg";
import GoalAmount from "../../Components/Invest/GoalAmountCalculation/GoalAmount";
import GoalPriority from "../../Components/Invest/GoalPriority/GoalPriority";
import { v4 as uuidv4 } from "uuid";
import PortfolioFormSectionRet from "../../Components/Invest/PortfolioFormSection/PortfolioFormSectionRet";
import PortfolioFormSectionDrawIncome from "../../Components/Invest/PortfolioFormSection/PortfolioFormSectionDrawIncome";
import PortfolioFormSection from "../../Components/Invest/PortfolioFormSection/PortfolioFormSection";
import PortfolioFormSectionHeader from "../../Components/Invest/PortfolioFormSection/PortfolioFormSectionHeader";

// import moment from "moment";

function Invest(props: any) {
    const { goalJson, setGoalJson } = props;
    const goalData = allGoals[props.goalId];
    const addedGoalList = props.addedGoalList || [];
    const dataArray: any = [];
    for (let i = 0; i < goalData.input_data.length; i++) {
        dataArray.push(goalData.input_data[i].name);
    }
    const [show, setShow] = useState(false);
    const [duplicateName, setDuplicateName] = useState(false);
    const [showGoalPriotiy, setshowGoalPriotiy] = useState(false);
    const [isEscalation, setIsEscalation] = useState(true);
    const [isEdit, setIsEdit] = useState(false);
    let depArr: any = [];
    const initialgoalData = useMemo(() => {
        const defaultPlanForRetGoalJson = {
            goalWorkspaceId: uuidv4(),
            // "created_at": "Thu, 08 Jun 2023 11:49:32 GMT",
            date_of_birth: "1996-11-09",
            retirementAge: 0,
            planningAge: 0,
            //currentSalary:"",
            salaryGrowthRate: 0,
            outsideAccountBalance: 0,
            companyContribution: 10,
            companyContributionRoth: 0,
            autoEscalationRateRoth: 0,
            traditionContribution: 0,
            rothContribution: 0,
            autoEscalationRate: 0,
            replacementRate: 0,
            outsideIncome: 0,
            inflation: 1,
            socialSecurityIncome: 0,
            end_on_date: "2062-01-01",
            escalate_contributions: "no",
            escalation_percentage: 0,
            every_years: 0,
            // "goal-key": "88522d42-05f2-11ee-847b-fedc3e6c160f",
            goal_amount: "$200,000",
            goal_key: props.goalId,
            goal_priority: "Need",
            icon: goalData.icon,
            initial_investment: "$150,000",
            leave_bequest: "yes",
            my_withdrawal_frequency: "Year",
            name: goalData.label,
            plan_start_retirement: "2043-01-01",
            recurring_contributions: "$20,000",
            targeted_retirement_income: goalJson["targeted_retirement_income"]
                ? goalJson["targeted_retirement_income"]
                : "$70,000",
            tenure: "38 years",
            // "updated_at": "2023-06-08 11:51:33.104000"
        };

        if (props.goalEditType == "NEW") {
            if (props.goalId === "save_collage") {
                return {
                    goalWorkspaceId: uuidv4(),
                    achieve_this_goal: "2033-01-01",
                    contribution_time: "year",
                    // "created_at": "Thu, 08 Jun 2023 11:42:26 GMT",
                    escalate_contributions: "no",
                    escalation_percentage: 0,
                    every_years: 0,
                    // "goal-key": "8a8f133c-05f1-11ee-a989-626295e7fe2e",
                    goal_amount: goalJson["goal_amount"] ? goalJson["goal_amount"] : "$200,000",
                    goal_key: props.goalId,
                    goal_priority: "Need",
                    icon: goalData.icon,
                    initial_investment: "$50,000",
                    name: goalData.label,
                    recurring_contributions: "$12,000",
                    tenure: "9 years",
                    // "updated_at": "Thu, 08 Jun 2023 11:51:18 GMT"
                };
            } else if (props.goalId === "own_house") {
                return {
                    goalWorkspaceId: uuidv4(),
                    achieve_this_goal: "2030-01-01",
                    contribution_time: "year",
                    // "created_at": "Thu, 08 Jun 2023 11:39:34 GMT",
                    escalate_contributions: "no",
                    escalation_percentage: 0,
                    every_years: 0,
                    // "goal-key": "24538300-05f1-11ee-847b-fedc3e6c160f",
                    goal_amount: goalJson["goal_amount"] ? goalJson["goal_amount"] : "$100,000",
                    goal_key: props.goalId,
                    goal_priority: "Want",
                    icon: goalData.icon,
                    initial_investment: "$35,000",
                    name: goalData.label,
                    recurring_contributions: "$5,000",
                    tenure: "6 years",
                    // "updated_at": "Fri, 09 Jun 2023 09:22:26 GMT"
                };
            } else if (props.goalId === "plan_retirement") {
                return { ...defaultPlanForRetGoalJson, ...goalJson };
            } else {
                return {
                    goalWorkspaceId: uuidv4(),
                    name: goalData.label,
                    icon: goalData.icon,
                    goal_key: props.goalId,
                };
            }
        } else {
            // eslint-disable-next-line react-hooks/exhaustive-deps
            depArr = [props.goalData];

            if (props.goalId === "plan_retirement") {
                return { ...defaultPlanForRetGoalJson, ...props.goalData };
            }

            return props.goalData;
        }
    }, [props.goalData, props.goalEditType, goalData, props.goalId, goalJson]);
    useEffect(() => {
        setGoalJson(initialgoalData);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, depArr);

    let goalJsonKeys: any = [];
    if (props.goalEditType == "NEW") {
        if (props.goalId === "save_collage") {
            goalJsonKeys = Object.keys(goalJson);
        } else if (props.goalId === "own_house") {
            goalJsonKeys = Object.keys(goalJson);
        } else if (props.goalId === "plan_retirement") {
            goalJsonKeys = Object.keys(goalJson);
        } else {
            goalJsonKeys = Object.keys(goalJson).slice(4);
        }
    } else {
        if (goalJson["goalJson"]) {
            setGoalJson({ ...goalJson, escalation_percentage: 0, every_years: 0 });
        }
        goalJsonKeys = Object.keys(goalJson);
        goalJsonKeys.push("escalation_percentage");
        goalJsonKeys.push("every_years");
    }
    const difference = dataArray.filter((x) => !goalJsonKeys.includes(x));

    const handleClose = () => {
        setShow(false);
    };

    // const handleShow = () => setShow(true);

    const turnRetirementIncome = () => {
        props.setStartJourney(false);
        props.setIsRetshow(true);
    };

    const handleDuplicate = () => {
        setIsEdit(!isEdit);
        onSaveGoals();
    };

    const handleChangeInputDollar = (event) => {
        const name = event.target.name;
        let value = event.target.value;
        value = event.target.value.replace(/\D/g, "");

        if (parseInt(value)) {
            setGoalJson({ ...goalJson, [name]: "$" + parseInt(value.replaceAll("$", "")).toLocaleString() });
        } else {
            setGoalJson({ ...goalJson, [name]: 0 });
        }
    };

    const handleChange = (event) => {
        const name = event.target.name;
        let value = event.target.value;
        if (name === "escalation_percentage") {
            value = value / 100;
        }
        setGoalJson({ ...goalJson, [name]: value });
    };
    const onChangeDate = (event) => {
        // const newDate = moment(new Date(event.target.value)).format("YYYY-MM-DD");
        setGoalJson({ ...goalJson, [event.target.name]: event.target.value });
    };

    const onButtonClick = (keyname, value) => {
        if (keyname === "escalate_contributions" && value === "no") {
            setIsEscalation(true);
            setGoalJson({ ...goalJson, [keyname]: value, escalation_percentage: 0, every_years: 0 });
        } else if (keyname === "escalate_contributions" && value === "yes") {
            setIsEscalation(false);
            setGoalJson({ ...goalJson, [keyname]: value, escalation_percentage: 0, every_years: 0 });
        } else if (keyname === "leave_bequest" && value === "no") {
            setGoalJson({ ...goalJson, [keyname]: value, goal_amount: "$0" });
        } else {
            setGoalJson({ ...goalJson, [keyname]: value });
        }
    };

    const onSaveGoals = (isSaveGoal = false) => {
        const existingGoals = addedGoalList.filter((goal) => {
            return goal.goalWorkspaceId !== goalJson.goalWorkspaceId;
        });

        const duplicateGoals = existingGoals.filter((goal) => {
            const currentGoalName = goalJson.name.toLowerCase();
            const goalName = goal.name.toLowerCase();
            return currentGoalName === goalName;
        });

        if (duplicateGoals.length) {
            setDuplicateName(true);
        } else {
            if (isSaveGoal) {
                props.saveGoal(goalJson);
            }
            setDuplicateName(false);
        }
    };

    return (
        <div className="goal-selection label-cursor">
            <div className="pfs d-flex flex-column">
                <PortfolioFormSectionHeader
                    data={goalJson}
                    duplicateName={duplicateName}
                    handleChange={handleChange}
                    subtitle={props.goalId === "plan_retirement" ? "Taxable Accounts" : ""}
                    isEdit={isEdit}
                    handleDuplicate={handleDuplicate}
                />
                {goalData["goal_id"] === 6 ? (
                    <PortfolioFormSectionDrawIncome
                        handleChangeInputDollar={handleChangeInputDollar}
                        data={goalJson}
                        configData={goalData}
                        onButtonClick={onButtonClick}
                        handleChange={handleChange}
                        onChangeDate={onChangeDate}
                        isEscalation={isEscalation}
                        setshowGoalPriotiy={() => setshowGoalPriotiy(true)}
                    />
                ) : goalData["goal_id"] === 1 ? (
                    <PortfolioFormSectionRet
                        duplicateName={duplicateName}
                        handleChangeInputDollar={handleChangeInputDollar}
                        data={goalJson}
                        configData={goalData}
                        onButtonClick={onButtonClick}
                        handleChange={handleChange}
                        onChangeDate={onChangeDate}
                        isEscalation={isEscalation}
                        setshowGoalPriotiy={() => setshowGoalPriotiy(true)}
                        turnRetirementIncome={turnRetirementIncome}
                    />
                ) : (
                    <PortfolioFormSection
                        handleChangeInputDollar={handleChangeInputDollar}
                        data={goalJson}
                        configData={goalData}
                        onButtonClick={onButtonClick}
                        handleChange={handleChange}
                        onChangeDate={onChangeDate}
                        isEscalation={isEscalation}
                        setshowGoalPriotiy={() => setshowGoalPriotiy(true)}
                        turnRetirementIncome={turnRetirementIncome}
                        setShow={setShow}
                    />
                )}
                <div className="pfs__footer d-flex justify-content-between">
                    <div className="pfs__action">
                        <button
                            type="button"
                            className="btn btn-link pfs__button--link"
                            onClick={() => props.backClick()}
                        >
                            <img src={BackImage} />
                            <span className="d-inline-block m-2">Back</span>
                        </button>
                    </div>
                    <div className="pfs__action">
                        <button
                            // className="btn btn-primary pfs__button--brand" onClick={onSaveGoals}
                            className={
                                difference.length === 0
                                    ? "button-invest_quetiontemp"
                                    : "button-invest_quetiontemp-disable"
                            }
                            onClick={
                                difference.length === 0
                                    ? () => onSaveGoals(true)
                                    : () => {
                                          console.log("");
                                      }
                            }
                        >
                            Save Goal Details
                        </button>
                    </div>
                </div>
                {show && (
                    <GoalAmount
                        handleClose={handleClose}
                        onButtonClick={onButtonClick}
                        input_data={goalData}
                        goalJson={goalJson}
                    />
                )}
                {showGoalPriotiy && <GoalPriority setshowGoalPriotiy={setshowGoalPriotiy} />}

                {/* {showRetirementIncome (<RetirementCalculator/>)} */}
            </div>
        </div>
    );
}

export default Invest;
