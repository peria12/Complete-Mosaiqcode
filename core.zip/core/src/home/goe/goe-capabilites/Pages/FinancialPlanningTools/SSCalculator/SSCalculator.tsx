import React, { useEffect, useState, useContext } from "react";
import TitleBar from "../../../Components/FinancialPlanningTools/TitleBar/TitleBar";
import "./SSCalculator.scss";
import Modal from "../../../Components/Modal/Modal";
import Slider from "@mui/material/Slider";
import Api from "utils/api";
import moment from "moment";
import Grid from "@mui/material/Grid";
import DateFnsUtils from "@date-io/date-fns";
import { MuiPickersUtilsProvider, KeyboardDatePicker } from "@material-ui/pickers";
import { makeStyles } from "@material-ui/core/styles";
import DownCircle from "../../../assets/images/svg/DownCircle.svg";
import UpCircle from "../../../assets/images/svg/UpCircle.svg";
import Loader from "../../../Components/Loader/Loader";
import { GoeCapabilitiesContext } from "../../../GoeCapabilitiesContext";
import * as XLSX from "xlsx";
import { header, headerGenpayload } from "home/goe/goe-capabilites/GoeController";

function SSCalculator(props: any) {
    const [showModal, setShowModal] = useState(false);
    const [apiResponse, setApiResponse] = useState({});
    const [yearlyEarningList, setYearlyEarningList] = useState([0]);
    const [isOpen, setIsOpen] = useState(false);
    const [selectedDate, handleSelectedDateChange] = useState(null);
    const [loading, setLoading] = useState(false);
    const [showEntDateError, setShowEntDateError] = useState(false);
    const [showYincomeError, setYincomeDateError] = useState(false);
    const [showFileError, setFileError] = useState(false);
    const [currentYearConfig, setCurrentYearConfig] = useState(2023);
    const { dob } = useContext(GoeCapabilitiesContext);

    const [apiPayload, setApiPayload] = useState({
        considerAWIGrowth: true,
        considerBenefitsGrowth: true,
        yearlyIncomeMethod: "manualIncomeEntry",
        ageOfFirstIncome: 18,
        filingStrategyRecommendation: false,
        lifestyleStatus: "General",
        gender: "Male",
        growthRateAboveAWI: 0,
        dateOfBirth: dob ? moment(dob).format("YYYY-MM-DD") : "",
        // entitlementDate:""
    });

    const KeyArray = [
        "dateOfBirth",
        "gender",
        "lifestyleStatus",
        "entitlementDate",
        "considerAWIGrowth",
        "considerBenefitsGrowth",
        "yearlyIncomeMethod",
        "ageOfFirstIncome",
        apiPayload["yearlyIncomeMethod"] === "manualIncomeEntry" ? "yearlyEarningList" : "latestIncome",
        "growthRateAboveAWI",
        "filingStrategyRecommendation",
        "yearOfLatestIncome",
    ];

    useEffect(() => {
        const ApiCall = async () => {
            const payload = {
                dateOfBirth: "02-01-1975",

                gender: "Male",

                lifestyleStatus: "General",

                entitlementDate: "02-01-2042",

                considerAWIGrowth: true,

                considerBenefitsGrowth: true,

                yearlyIncomeMethod: "manualIncomeEntry",

                ageOfFirstIncome: 38,

                firstIncomeAmount: 50000,

                incomeGrowthPercentage: 2.0,

                yearlyEarningList: [
                    2000,

                    2100,

                    2000,

                    2000,

                    2100,

                    2200,

                    2000,

                    2000,

                    2100,

                    2200,

                    2000,

                    2000,

                    2100,

                    2200,

                    18600,

                    19500,

                    20600,

                    21800,

                    22300,

                    22500,

                    23000,

                    2000,

                    2000,

                    2100,

                    2200,

                    18600,

                    19500,

                    20600,

                    21800,

                    22300,

                    22500,

                    23000,

                    24100,

                    25000,

                    26200,

                    27300,

                    28000,

                    27500,

                    28200,

                    29100,

                    30000,

                    30400,

                    31400,

                    32500,

                    32900,

                    34000,

                    35300,

                    36600,

                    37600,

                    40000,
                ],

                latestIncome: 150000,

                yearOfLatestIncome: 2021,

                lastYearOfEarning: 2044,

                growthRateAboveAWI: 2.0,

                filingStrategyRecommendation: true,

                currentYear: 2022,
            };
            const response = await Api.getSocialSecurityData(payload, headerGenpayload);
            setCurrentYearConfig(response.body.currentYear);
        };
        ApiCall();
    }, []);

    useEffect(() => {
        if (apiPayload["dateOfBirth"]) {
            const dateOfBirth = new Date(apiPayload["dateOfBirth"] + "T00:00:00");
            const newdate =
                dateOfBirth.getFullYear() +
                62 +
                "-" +
                (dateOfBirth.getMonth() + 1 > 9 ? dateOfBirth.getMonth() + 1 : "0" + (dateOfBirth.getMonth() + 1)) +
                "-" +
                (dateOfBirth.getDate() > 9 ? dateOfBirth.getDate() : "0" + dateOfBirth.getDate());
            const finalDate = moment(newdate).format("YYYY-MM-DD");
            const apiPayload1 = { ...apiPayload };
            apiPayload1["entitlementDate"] = finalDate;
            setApiPayload(apiPayload1);
        }
        // eslint-disable-next-line
    }, [apiPayload["dateOfBirth"]]);

    const RetJsonKeys = Object.keys(apiPayload);
    let difference = KeyArray.filter((x) => !RetJsonKeys.includes(x));
    if (
        apiPayload["yearlyIncomeMethod"] === "manualIncomeEntry" &&
        apiPayload["dateOfBirth"] &&
        apiPayload["entitlementDate"] &&
        yearlyEarningList.length > 1 &&
        apiPayload["yearOfLatestIncome"]
    ) {
        difference = [];
    }

    const unFormaAmount = (formatterNUmber) => {
        if (formatterNUmber && typeof formatterNUmber !== "number") {
            return Number(formatterNUmber.replace(/[$,]/g, ""));
        }
        return formatterNUmber;
    };

    const handleInput = (event) => {
        const name = event.target.name;
        let value = event.target.value;
        if (event.target.name === "yearOfLatestIncome") {
            value = parseInt(value);
        }
        if (event.target.type === "date" && name === "entitlementDate") {
            let dateDiff = 1;
            const date = new Date(value);
            const dateOfBirth = new Date(apiPayload["dateOfBirth"]);
            dateDiff = date.getFullYear() - dateOfBirth.getFullYear();
            if (70 >= dateDiff && dateDiff >= 62) {
                setShowEntDateError(false);
                setApiPayload({ ...apiPayload, [name]: value });
            } else {
                delete apiPayload["entitlementDate"];
                setShowEntDateError(true);
            }
        } else if (event.target.type != "text" || event.target.id === "year") {
            setApiPayload({ ...apiPayload, [name]: value });
        } else {
            value = event.target.value.replace(/\D/g, "");
            setApiPayload({ ...apiPayload, [name]: "$" + parseInt(value.replaceAll("$", "")).toLocaleString() });
        }
    };

    const handleSlider = (event) => {
        const name = event.target.name;
        let value = event.target.value;
        if (name === "escalation_percentage") {
            value = value / 100;
        }
        setApiPayload({ ...apiPayload, [name]: value });
    };

    const handleSsaAppraoch = (event) => {
        setApiPayload({ ...apiPayload, yearlyIncomeMethod: event.target.value });
    };

    const handleToggle = (event) => {
        if (event.target.name === "considerAWIGrowth") {
            setApiPayload({ ...apiPayload, considerAWIGrowth: !apiPayload.considerAWIGrowth });
        } else if (event.target.name === "considerBenefitsGrowth") {
            setApiPayload({ ...apiPayload, considerBenefitsGrowth: !apiPayload.considerBenefitsGrowth });
        } else {
            setApiPayload({ ...apiPayload, filingStrategyRecommendation: !apiPayload.filingStrategyRecommendation });
        }
    };

    const handleBack = () => {
        props.setIsRetshow(true);
        props.setIsSSCshow(false);
    };

    const onSubmit = async () => {
        let apiRequest = {};
        setLoading(true);
        if (apiPayload.yearlyIncomeMethod === "manualIncomeEntry") {
            apiRequest = {
                dateOfBirth: moment(apiPayload["dateOfBirth"]).format("DD-MM-YYYY"),
                gender: apiPayload.gender,
                lifestyleStatus: apiPayload.lifestyleStatus,
                entitlementDate: moment(apiPayload["entitlementDate"]).format("DD-MM-YYYY"),
                considerAWIGrowth: apiPayload.considerAWIGrowth,
                considerBenefitsGrowth: apiPayload.considerBenefitsGrowth,
                yearlyIncomeMethod: apiPayload.yearlyIncomeMethod,
                ageOfFirstIncome: apiPayload.ageOfFirstIncome,
                yearlyEarningList: yearlyEarningList,
                growthRateAboveAWI: 0,
                filingStrategyRecommendation: apiPayload.filingStrategyRecommendation,
                yearOfLatestIncome: apiPayload["yearOfLatestIncome"],
            };
        } else {
            apiPayload["dateOfBirth"] = moment(apiPayload["dateOfBirth"]).format("DD-MM-YYYY");
            apiPayload["entitlementDate"] = moment(apiPayload["entitlementDate"]).format("DD-MM-YYYY");
            apiPayload["latestIncome"] = unFormaAmount(apiPayload["latestIncome"]);
            apiRequest = apiPayload;
        }
        const response = await Api.getSocialSecurityData(apiRequest, header);
        setApiResponse(response.body);
        setLoading(false);
        setShowModal(true);
    };

    const handleFile = async (e: any) => {
        const file = e.target.files[0];
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data);
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        let jsonData = [0];
        jsonData = XLSX.utils.sheet_to_json(worksheet, {
            header: 1,
            defval: "",
        });
        // const excelArr = []
        const excelArr: number[] = [];
        jsonData.shift();
        jsonData.forEach((item) => {
            excelArr.push(item[0]);
        });
        const entitlementDate = new Date(apiPayload["entitlementDate"]);
        const dateOfBirth = new Date(apiPayload["dateOfBirth"]);
        // the returned value to "n"
        // let n = date
        const arrayLen = entitlementDate.getFullYear() - (dateOfBirth.getFullYear() + 18) + 1;
        if (excelArr.length === arrayLen) {
            yearlyEarningList.shift();
            setYearlyEarningList(excelArr);
            RetJsonKeys.push("yearlyEarningList");
            setFileError(false);
        } else {
            setFileError(true);
        }
        e.target.value = "";
    };
    const useInputStyles = makeStyles({
        root: {
            verticalAlign: "middle",
            fontSize: "16px",
            border: "1px solid #E6E6E6 !important",
            height: "35px",
            width: "100%",
            background: "#FFFFFF",
            borderRadius: "4px",
            paddingLeft: "5px",
            fontFamily: "TT Commons",
            fontStyle: "normal",
            fontWeight: 500,
            lineHeight: "19px",
        },
    });

    const handleDateChange = (itemname, date) => {
        handleSelectedDateChange(date);
        const yyyy = date.getFullYear();
        const dateOfBirth = new Date(apiPayload["dateOfBirth"]).getFullYear();
        // const currentYear = new Date().getFullYear();
        // entitlementDate
        const entitlementDate = new Date(apiPayload["entitlementDate"]).getFullYear();
        if (yyyy > dateOfBirth + 18 && Math.min(entitlementDate, currentYearConfig) > yyyy) {
            setApiPayload({ ...apiPayload, [itemname]: yyyy });
            setYincomeDateError(false);
        } else {
            setYincomeDateError(true);
        }
    };

    const calculatorName = "Social Security Calculator";
    const inputClasses = useInputStyles();
    return (
        <div>
            {loading ? <Loader width={100} /> : <></>}
            <div className="outer-main-div-fpt">
                <div className="back" onClick={props.isFPT ? () => props.setcalculatorName("") : handleBack}>
                    <span className="arrow"></span>
                    <div>back</div>
                </div>
                <div className="main-div-fpt-rc">
                    <TitleBar title={calculatorName} />
                    <div className="row-div-fpt-rc">
                        <div className="subcontent-div-fpt-rc">
                            <div className="span-div-fpt-rc">
                                <div className="label-div-goe-invest-questiontemp">
                                    <div
                                        dangerouslySetInnerHTML={{
                                            __html: "<span class='black-span-goalstemp'>Date of Birth</span>",
                                        }}
                                    ></div>
                                </div>
                            </div>
                            <div>
                                {dob ? (
                                    <input
                                        name="dateOfBirth"
                                        className="input-goe-goal-amt"
                                        type="date"
                                        onChange={handleInput}
                                        value={apiPayload["dateOfBirth"]}
                                        disabled={dob ? true : false}
                                        required
                                    ></input>
                                ) : (
                                    <input
                                        name="dateOfBirth"
                                        className="input-goe-goal-amt"
                                        type="date"
                                        onChange={handleInput}
                                        required
                                    ></input>
                                )}
                            </div>
                        </div>
                        <div className="subcontent-div-fpt-rc subcontent-div-fpt-rc-right">
                            <div className="span-div-fpt-rc">
                                <div className="label-div-goe-invest-questiontemp">
                                    <div
                                        dangerouslySetInnerHTML={{
                                            __html: "<span class='black-span-goalstemp'>Lifestyle Status</span>",
                                        }}
                                    ></div>
                                </div>
                            </div>
                            <div>
                                <select
                                    name="lifestyleStatus"
                                    className="input-goe-goal-amt"
                                    onChange={handleInput}
                                    value={apiPayload.lifestyleStatus}
                                >
                                    <option>General</option>
                                    <option>Non-smoker and super-preferred</option>
                                    <option>Non-smoker and preferred</option>
                                    <option>Smoker and preferred</option>
                                    <option>Smoker and residual-standard</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div className="row-div-fpt-rc">
                        <div className="subcontent-div-fpt-rc">
                            <div className="span-div-fpt-rc">
                                <div className="label-div-goe-invest-questiontemp">
                                    <div
                                        dangerouslySetInnerHTML={{
                                            __html: "<span class='black-span-goalstemp'>Gender</span>",
                                        }}
                                    ></div>
                                </div>
                            </div>
                            <div>
                                <select
                                    name="gender"
                                    className="input-goe-goal-amt"
                                    onChange={handleInput}
                                    value={apiPayload.gender}
                                >
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Other</option>
                                </select>
                            </div>
                        </div>
                        <div className="subcontent-div-fpt-rc subcontent-div-fpt-rc-right">
                            <div className="span-div-fpt-rc">
                                <div className="label-div-goe-invest-questiontemp">
                                    <div
                                        dangerouslySetInnerHTML={{
                                            __html: "<span class='black-span-goalstemp'>Entitlement Date</span>",
                                        }}
                                    ></div>
                                </div>
                            </div>
                            <div>
                                <input
                                    name="entitlementDate"
                                    className="input-goe-goal-amt"
                                    type="date"
                                    onChange={handleInput}
                                    value={apiPayload["entitlementDate"]}
                                ></input>
                                {showEntDateError && (
                                    <span className="ft-goe-cap-ret-errormsg">
                                        Age of entitlement should be between 62 and 70
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                    <hr className="row_line_fpt" />
                    <div className="row-div-fpt-rc">
                        <div className="span-div-fpt-rc">
                            <div className="radio_head">
                                <div
                                    dangerouslySetInnerHTML={{
                                        __html: "<span class='black-span-goalstemp'>Select approach to derive yearly earning :</span>",
                                    }}
                                ></div>
                            </div>
                        </div>
                        <div id="main">
                            <div className="radio-div-goe-fpt-ssc">
                                <input
                                    type="radio"
                                    name="satyed"
                                    className="form-check-input radio_checkbox"
                                    checked={apiPayload.yearlyIncomeMethod === "manualIncomeEntry"}
                                    // checked={ssaApproch === "usemee_approach"}
                                    onChange={handleSsaAppraoch}
                                    value="manualIncomeEntry"
                                />
                                <label className="radio-inline">
                                    <span className="radio_field">Manual earning entry approach</span>
                                </label>
                            </div>
                            <div className="radio-div-goe-fpt-ssc">
                                <input
                                    type="radio"
                                    name="satyed"
                                    className="form-check-input radio_checkbox"
                                    // checked={ssaApproch === "usessa_approach"}
                                    checked={apiPayload.yearlyIncomeMethod === "ssaMethod"}
                                    onChange={handleSsaAppraoch}
                                    value="ssaMethod"
                                />
                                <label className="radio-inline">
                                    <span className="radio_field">Use SSA approach</span>
                                </label>
                            </div>
                            <div className="radio-div-goe-fpt-ssc">
                                <input
                                    type="radio"
                                    name="satyed"
                                    className="form-check-input radio_checkbox"
                                    onChange={handleSsaAppraoch}
                                    checked={apiPayload.yearlyIncomeMethod === "AWIMethod"}
                                    value="AWIMethod"
                                />
                                <label className="radio-inline">
                                    <span className="radio_field">Use AWI and latest income</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    {apiPayload["yearlyIncomeMethod"] === "manualIncomeEntry" &&
                        (!apiPayload["dateOfBirth"] || !apiPayload["entitlementDate"]) && (
                            <span className="ft-goe-cap-ret-errormsg">
                                Please select Date of birth and Entitlement date first
                            </span>
                        )}
                    {showFileError && (
                        <span className="ft-goe-cap-ret-errormsg">Salary data does not conform to the template.</span>
                    )}
                    {apiPayload.yearlyIncomeMethod === "manualIncomeEntry" ? (
                        <div className="file-upload">
                            <div className="file-field">
                                <div className="ss-calc-file-selector">
                                    <label className="custom-file-upload">
                                        <i className="fa fa-cloud-arrow-up"></i> Upload Annual Salary File
                                        <input
                                            id="file-upload"
                                            type="file"
                                            onInput={handleFile}
                                            disabled={
                                                !apiPayload["dateOfBirth"] && !apiPayload["entitlementDate"]
                                                    ? true
                                                    : false
                                            }
                                        />
                                    </label>
                                </div>
                                <div className="template_label">
                                    <label>Looking for the salary file template?</label>
                                    <div>
                                        <a href={require("./Sample.csv")} download="Sample">
                                            <label className="ft-goe-cap-ss-link ">Download here</label>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            {/* <div className="file-field">
                                
                            </div> */}
                        </div>
                    ) : (
                        <div>
                            <div className="row-div-fpt-rc">
                                <div className="row-div-fpt-rc">
                                    <div className="subcontent-div-fpt-rc">
                                        <div className="span-div-fpt-rc">
                                            <div className="label-div-goe-invest-questiontemp">
                                                <div
                                                    dangerouslySetInnerHTML={{
                                                        __html: "<span class='black-span-goalstemp'>Latest annual Income?</span>",
                                                    }}
                                                ></div>
                                            </div>
                                        </div>
                                        <div>
                                            <input
                                                name="latestIncome"
                                                className="input-goe-goal-amt"
                                                type="text"
                                                placeholder="$0"
                                                value={apiPayload["latestIncome"]}
                                                onChange={handleInput}
                                            ></input>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                    <div className="row-div-fpt-rc">
                        <div className="row-div-fpt-rc">
                            <div className="subcontent-div-fpt-rc">
                                <div className="span-div-fpt-rc">
                                    <div className="label-div-goe-invest-questiontemp">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='black-span-goalstemp'>Year of your latest annual Income?</span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <div className="d-flex button-input-div-goal-amt">
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <Grid container sx={{ justifyContent: "space-around" }}>
                                            <KeyboardDatePicker
                                                InputProps={{ classes: inputClasses }}
                                                autoOk={true}
                                                // openTo="yea"
                                                views={["year"]}
                                                disableToolbar
                                                variant="inline"
                                                format="yyyy"
                                                margin="normal"
                                                name="yearOfLatestIncome"
                                                style={{ width: "100%", marginTop: "0px" }}
                                                id="date-picker-inline"
                                                // minDate={today}
                                                // maxDate={after_thirty_years}
                                                value={selectedDate}
                                                // onChange={(e) => handleInput}
                                                onChange={(e) => handleDateChange("yearOfLatestIncome", e)}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date",
                                                }}
                                            />
                                        </Grid>
                                    </MuiPickersUtilsProvider>
                                </div>
                                {showYincomeError && (
                                    <span className="ft-goe-cap-ret-errormsg">
                                        This should be between year of DOB + 18 and Min (year of entitlement date, year
                                        of current date)
                                    </span>
                                )}
                                {/* <div>
                                <input
                                    id="year"
                                    name="yearOfLatestIncome"
                                    className="input-goe-goal-amt"
                                    type="text"
                                    placeholder="yyyy"
                                    maxLength={4}
                                    onChange={handleInput}
                                ></input>
                            </div> */}
                            </div>
                        </div>
                    </div>

                    <div
                        className={`ft-goe-cap-drop-down-section-div ${
                            isOpen ? "ft-goe-cap-drop-down-section-div-active" : ""
                        }`}
                    >
                        <div
                            className={`ft-goe-cap-drop-down-section-inner-div ${
                                isOpen ? "ft-goe-cap-drop-down-section-div-bottam" : ""
                            }`}
                        >
                            <span
                                className={`ft-goe-cap-drop-down-section-span ${
                                    isOpen ? "ft-goe-cap-drop-down-section-span-active" : ""
                                }`}
                            ></span>
                            <img src={isOpen ? UpCircle : DownCircle} onClick={() => setIsOpen(!isOpen)} />
                        </div>
                    </div>
                    {/* <hr className="row_line_fpt" /> */}
                    {isOpen && (
                        <div>
                            <div className="row-div-fpt-rc">
                                <div className="span-div-fpt-sc">
                                    <div className="label-div-goe-fpt-rc">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='black-span-goalstemp'> Assume growth in AWI after current year (applies for entitlement dates in the future)</span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <span className="slider-label-left">No</span>
                                <label className="switch">
                                    <input
                                        type="checkbox"
                                        name="considerAWIGrowth"
                                        onChange={handleToggle}
                                        checked={apiPayload.considerAWIGrowth}
                                    />
                                    <span className="slider round"></span>
                                </label>
                                <span className="slider-label-right">Yes</span>
                            </div>
                            {apiPayload.yearlyIncomeMethod !== "manualIncomeEntry" && (
                                <div className="row-toggle-true-container">
                                    <div className="row-toggle-div-input">
                                        <label className="awi-growth-label">Additional growth rate</label>
                                        <span className="rgf">(Realtive Growth Factor in %)</span>
                                    </div>
                                    <div className="row-toggle-div-input-box">
                                        <div className="d-flex">
                                            <div className="range-slider">
                                                <div className="range-group">
                                                    <Slider
                                                        size="small"
                                                        defaultValue={0}
                                                        aria-label="Small"
                                                        valueLabelDisplay="auto"
                                                        name="growthRateAboveAWI"
                                                        value={apiPayload["growthRateAboveAWI"]}
                                                        onChange={handleSlider}
                                                    />
                                                </div>
                                            </div>
                                            <input
                                                className={`input-range-goe-invest-questiontemp input-goe-invest-questiontemp `}
                                                type="text"
                                                name="growthRateAboveAWI"
                                                value={apiPayload["growthRateAboveAWI"]}
                                                placeholder="0%"
                                                disabled
                                            ></input>
                                        </div>
                                        {/* <input name="growthRateAboveAWI" className="input-goe-goal-amt" type="text" placeholder="0%" /> */}
                                    </div>
                                </div>
                            )}
                            <div className="row-div-fpt-rc slider-div">
                                <div className="span-div-fpt-sc">
                                    <div className="label-div-goe-fpt-rc">
                                        <div
                                            dangerouslySetInnerHTML={{
                                                __html: "<span class='black-span-goalstemp'>Assume Benefit growth (applies for entitlement dates in the future)</span>",
                                            }}
                                        ></div>
                                    </div>
                                </div>
                                <span className="slider-label-left">No</span>
                                <label className="switch">
                                    <input
                                        type="checkbox"
                                        name="considerBenefitsGrowth"
                                        onChange={handleToggle}
                                        checked={apiPayload.considerBenefitsGrowth}
                                    />
                                    <span className="slider round"></span>
                                </label>
                                <span className="slider-label-right">Yes</span>
                            </div>
                        </div>
                    )}
                </div>
                <div className="button-div-fpt-rc">
                    <div className="button-fpt-rc">
                        <input type="checkbox" className="filing-strategy-checkbox" onChange={handleToggle} />
                        <span className="filing-strategy">Get Filing Strategy</span>
                        <button
                            className={
                                difference.length === 0
                                    ? "button-invest_quetiontemp"
                                    : "button-invest_quetiontemp-disable"
                            }
                            onClick={
                                difference.length === 0
                                    ? onSubmit
                                    : () => {
                                          console.log("test");
                                      }
                            }
                        >
                            Submit For Calculation
                        </button>
                    </div>
                </div>
                {showModal && (
                    <Modal
                        is_ssc={true}
                        fillingStratagy={apiPayload.filingStrategyRecommendation}
                        setShowModal={setShowModal}
                        showModal={showModal}
                        apiResponse={apiResponse}
                        setInputData={props.setInputData}
                        inputData={props.inputData}
                        setcalculatorName={props.setcalculatorName}
                        isFPT={props.isFPT}
                        setIsSSCshow={props.setIsSSCshow}
                        setIsRetshow={props.setIsRetshow}
                    />
                )}
            </div>
        </div>
    );
}

export default SSCalculator;
