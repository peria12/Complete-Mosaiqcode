import React, { useState, useRef } from "react";
import "./SocialSecurityCalculator.scss";
import TitleBar from "../../../Components/FinancialPlanningTools/TitleBar/TitleBar";
import coludArrow from "../../../assets/images/svg/cloud-arrow-up.svg";
import Modal from "../../../Components/Modal/Modal";
function SocialSecurityCalculator() {
    const calculatorName = "Social Security Calculator";
    const [ssaApproch, setSsaApproch] = useState("mee_approach");
    const [inputData, setInputData] = useState({});
    const [awiGrowthToggle, setAwiGrowthToggle] = useState(false);
    const [fillingStratagy, setfillingStratagy] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const inputFile = useRef<HTMLInputElement | null>(null);

    const onUploadClick = () => {
        inputFile.current?.click();
    };

    const handleChange = (event) => {
        setInputData({ ...inputData, [event.target.name]: event.target.value });
    };
    const onChangeDate = (event) => {
        setInputData({ ...inputData, [event.target.name]: event.target.value });
    };
    const handleAwiToggle = () => {
        setAwiGrowthToggle(!awiGrowthToggle);
    };
    const handleSsaAppraoch = (event) => {
        setSsaApproch(event.target.value);
    };
    const handleFillingStragegy = () => {
        setfillingStratagy(!fillingStratagy);
    };

    const applyCalculation = () => {
        setShowModal(true);
    };

    return (
        <div className="outer-main-div-fpt">
            <div className="main-div-fpt-rc">
                <TitleBar title={calculatorName} />
                <div className="row-div-fpt-rc">
                    <div className="subcontent-div-fpt-rc">
                        <div className="row-div-fpt-rc">
                            <label className="label-goe-fpt-ssc">Date of birth</label>
                            <input
                                className="input-goe-fpt-ssc"
                                type="date"
                                name="dateOfBirth"
                                onChange={onChangeDate}
                                placeholder="dd-mm-yyyy"
                            ></input>
                        </div>
                        <div className="row-div-fpt-rc">
                            <label className="label-goe-fpt-ssc">Gender</label>
                            <select className="input-goe-fpt-ssc" name="gender" onChange={handleChange}>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                    <div className="subcontent-div-fpt-rc right-subcontent-div-fpt-rc">
                        <div className="row-div-fpt-rc">
                            <label className="label-goe-fpt-ssc">Lifestyle Status</label>
                            <select className="input-goe-fpt-ssc" name="lifestyleStatus" onChange={handleChange}>
                                <option value="General">General</option>
                                <option value="Non-smoker and super-preferred">Non-smoker and super-preferred</option>
                                <option value="Non-smoker and preferred">Non-smoker and preferred</option>
                                <option value="Smoker and preferred">Smoker and preferred</option>
                                <option value="Smoker and residual-standard">Smoker and residual-standard</option>
                            </select>
                        </div>
                        <div className="row-div-fpt-rc">
                            <label className="label-goe-fpt-ssc">Entitlement Date</label>
                            <input
                                className="input-goe-fpt-ssc"
                                type="date"
                                name="entitlementDate"
                                onChange={onChangeDate}
                                placeholder="dd-mm-yyyy"
                            ></input>
                        </div>
                    </div>
                </div>
                <hr />
                <div className="row-div-fpt-rc">
                    <div>
                        <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">
                            Select approach to derive yearly earning :
                        </label>
                    </div>
                    <div className="radio-div-goe-fpt-ssc">
                        <input
                            type="radio"
                            className="form-check-input"
                            checked={ssaApproch === "mee_approach"}
                            onChange={handleSsaAppraoch}
                            value="mee_approach"
                        />
                        <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">
                            Manual earning entry approach
                        </label>
                    </div>
                    <div className="radio-div-goe-fpt-ssc">
                        <input
                            type="radio"
                            className="form-check-input"
                            checked={ssaApproch === "usessa_approach"}
                            onChange={handleSsaAppraoch}
                            value="usessa_approach"
                        />

                        <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">Use SSA approach</label>
                    </div>
                    <div className="radio-div-goe-fpt-ssc">
                        <input
                            type="radio"
                            className="form-check-input"
                            checked={ssaApproch === "awi_income_approach"}
                            onChange={handleSsaAppraoch}
                            value="awi_income_approach"
                        />

                        <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">Use AWI and latest income</label>
                    </div>
                </div>
                {ssaApproch === "mee_approach" ? (
                    <div className="dotted-div-goe-fpt-ssc">
                        <input type="file" id="file" ref={inputFile} style={{ display: "none" }} />
                        <div onClick={onUploadClick} className="upload-salary-div-goe-fpt-ssc">
                            <img src={coludArrow} />
                            <span className="upload-salary-sapn-goe-fpt-ssc">Upload Annual Salary File</span>
                        </div>
                        <div className="download-file-div-goe-fpt-ssc">
                            <span className="looking-file-span-goe-fpt-ssc">Looking for the salary file template?</span>
                            <a>
                                <span className="download-file-span-goe-fpt-ssc">Download here</span>
                            </a>
                        </div>
                    </div>
                ) : (
                    <div>
                        {" "}
                        <div className="row-div-fpt-rc">
                            <div className="ssa-approch-inner-div-goe-fpt-ssc">
                                <div className="ssa-approch-label-div-goe-fpt-ssc">
                                    <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">
                                        Latest annual Income?
                                    </label>
                                    <label className="looking-file-span-goe-fpt-ssc">(in Us dollar $)</label>
                                </div>
                                <div className="ssa-approch-input-div-goe-fpt-ssc">
                                    <input
                                        className="input-goe-fpt-ssc"
                                        type="text"
                                        value={inputData["latest_annual_income"]}
                                        name="latest_annual_income"
                                        onChange={handleChange}
                                        placeholder="$0"
                                    ></input>
                                </div>
                            </div>
                        </div>
                        <div className="row-div-fpt-rc">
                            <div className="ssa-approch-inner-div-goe-fpt-ssc">
                                <div className="ssa-approch-label-div-goe-fpt-ssc">
                                    <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">
                                        Year of your latest annual Income?
                                    </label>
                                </div>
                                <div className="ssa-approch-input-div-goe-fpt-ssc">
                                    <input
                                        className="input-goe-fpt-ssc"
                                        type="text"
                                        value={inputData["year_latest_annual_income"]}
                                        name="year_latest_annual_income"
                                        onChange={handleChange}
                                        placeholder="yyyy"
                                    ></input>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                <hr />
                <div>
                    <div className="display-flex">
                        <div className="ssa-approch-label-div-goe-fpt-ssc-toggle">
                            <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">Assume AWI Growth</label>
                        </div>
                        <div className="display-flex" onClick={handleAwiToggle}>
                            No
                            {awiGrowthToggle ? (
                                <div className="toggle-goe-fpt-ssc-active">
                                    <button className="toggle-button-goe-fpt-ssc"></button>
                                </div>
                            ) : (
                                <div className="toggle-goe-fpt-ssc">
                                    <button className="toggle-button-goe-fpt-ssc"></button>
                                </div>
                            )}
                            Yes
                        </div>
                    </div>
                    {awiGrowthToggle && (
                        <div className="ssa-approch-inner-div-goe-fpt-ssc ">
                            <div className="ssa-approch-label-div-goe-fpt-ssc">
                                <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">
                                    What growth rate over and above AWI do you want to assume?
                                </label>
                                <label className="looking-file-span-goe-fpt-ssc">(Relative growth Factor in %)</label>
                            </div>
                            <div className="ssa-approch-input-div-goe-fpt-ssc">
                                <input
                                    className="input-goe-fpt-ssc"
                                    type="text"
                                    value={inputData["latest_annual_income"]}
                                    name="latest_annual_income"
                                    onChange={handleChange}
                                    placeholder="0%"
                                ></input>
                            </div>
                        </div>
                    )}
                    <div className="display-flex">
                        <div className="ssa-approch-label-div-goe-fpt-ssc-toggle">
                            <label className="label-goe-fpt-ssc label-goe-fpt-ssc-radio">Assume Benefit Growth</label>
                        </div>
                        <div className="display-flex">
                            No{" "}
                            <div className="toggle-goe-fpt-ssc">
                                <button className="toggle-button-goe-fpt-ssc"></button>
                            </div>
                            Yes
                        </div>
                    </div>
                </div>
            </div>
            <div className="button-div-fpt-rc">
                <div>
                    <input className="checkbox-fpt-ssc" onChange={handleFillingStragegy} type="checkbox" />
                    <span>Get Filing Strategy </span>
                </div>
                <div className="button-fpt-rc" onClick={applyCalculation}>
                    <label htmlFor="modal__state">Submit For Calculation</label>
                </div>
            </div>
            <div>{showModal && <Modal is_ssc={true} setShowModal={setShowModal} responseData={{}} />}</div>
        </div>
    );
}

export default SocialSecurityCalculator;
