import React, { useState } from "react";

import "./index.scss";
import Login from "./Login";
import ForgotPassword from "./ForgotPassword";
import ForgotPasswordConfirmation from "./ForgotPasswordConfirmation";

const UnAuthenticatedPages = ({ lodingInfo, setIsAuthenticated, setPath }) => {
    const [currentPage, setCurrentPage] = useState("login");
    const [isRegister, setIsRegister] = useState(false);

    switch (currentPage) {
        case "forgotPassword":
            return (
                <ForgotPassword setCurrentPage={setCurrentPage} isRegister={isRegister} setIsRegister={setIsRegister} />
            );
        case "forgotPasswordConfirmation":
            return (
                <ForgotPasswordConfirmation
                    setCurrentPage={setCurrentPage}
                    isRegister={isRegister}
                    setIsRegister={setIsRegister}
                />
            );
        default:
            return (
                <Login
                    setCurrentPage={setCurrentPage}
                    lodingInfo={lodingInfo}
                    setIsAuthenticated={setIsAuthenticated}
                    setPath={setPath}
                    setIsRegister={setIsRegister}
                />
            );
    }
};

export default UnAuthenticatedPages;
