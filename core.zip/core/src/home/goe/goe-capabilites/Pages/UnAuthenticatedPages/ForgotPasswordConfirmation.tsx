import React from "react";

import GoeLogo from "../../assets/images/svg/goe_logo.svg";
import NoAccess from "../../assets/images/svg/no_access.svg";

const ForgotPasswordConfirmation = ({ setCurrentPage, isRegister, setIsRegister }) => {
    return (
        <div className="goe-capabilites-login">
            <div
                className="login-container"
                style={{
                    backgroundImage: `url(${NoAccess})`,
                }}
            >
                <div
                    className="login-inner-main-container"
                    style={{
                        maxWidth: "25%",
                    }}
                >
                    <div className="login-logo-container">
                        <img src={GoeLogo} alt="GOE Logo" />
                    </div>

                    <div
                        className="fp-confirmation-container"
                        style={{
                            textAlign: "center",
                        }}
                    >
                        <p>
                            {isRegister
                                ? "Registration successful. Please follow the instructions in the email from Okta."
                                : "An Email with instructions on recovering your password has been sent. Please follow the instructions to reset your password."}
                        </p>

                        <div className="login-hr" />

                        <div
                            className="login-link"
                            onClick={() => {
                                setIsRegister(false);
                                setCurrentPage("login");
                            }}
                            style={{ textAlign: "end" }}
                        >
                            <span>Back to Login</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ForgotPasswordConfirmation;
