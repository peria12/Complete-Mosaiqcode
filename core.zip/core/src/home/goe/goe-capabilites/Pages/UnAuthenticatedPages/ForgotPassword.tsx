import React, { useState } from "react";
import { useForm } from "react-hook-form";

import GoeLogo from "../../assets/images/svg/goe_logo.svg";
import NoAccess from "../../assets/images/svg/no_access.svg";
import Api from "utils/api";

const ForgotPassword = ({ setCurrentPage, isRegister, setIsRegister }) => {
    const [notUser, setNotUser] = useState(false);
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm<{
        email: string;
    }>();

    const onForgotPassword = (values) => {
        if (isRegister) {
            Api.signUpUser({
                sender_email: values.email,
            }).then(() => {
                setCurrentPage("forgotPasswordConfirmation");
            });
        } else {
            Api.forgotPassword({
                email: values.email,
            })
                .then(() => {
                    setCurrentPage("forgotPasswordConfirmation");
                })
                .catch(function (error) {
                    if (error.response.status === 400) {
                        setNotUser(true);
                    }
                });
        }
    };

    return (
        <div className="goe-capabilites-login">
            <div
                className="login-container"
                style={{
                    backgroundImage: `url(${NoAccess})`,
                }}
            >
                <div className="login-inner-main-container">
                    <div className="login-logo-container">
                        <img src={GoeLogo} alt="GOE Logo" />
                    </div>

                    <form
                        className="login-form-container"
                        onSubmit={handleSubmit(onForgotPassword)}
                        autoComplete="off"
                        autoCorrect="off"
                    >
                        <div className="name">
                            <div className="row-div row-div-left">
                                <label
                                    className="login-form-label"
                                    style={{
                                        color: errors.email ? "red" : "black",
                                    }}
                                >
                                    Enter Email Address
                                </label>
                            </div>
                            <div className="row-div">
                                <input
                                    className="login-input"
                                    placeholder="Email"
                                    {...register("email", {
                                        required: "This field is required",
                                        pattern: {
                                            value: /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                                            message: "Invalid email address",
                                        },
                                    })}
                                    style={{
                                        borderColor: errors.email ? "red" : "black",
                                    }}
                                />
                            </div>
                            {errors.email && <span className="form-error">{errors.email.message}</span>}
                            <br></br>
                            {notUser && (
                                <span className="form-error">
                                    Account with this email does not exist. Please Verify that you have entered the
                                    email address correctly.
                                </span>
                            )}
                        </div>
                        <div className="login-hr" />

                        <button className="login-button" type="submit">
                            Continue
                        </button>

                        <div className="login-hr" />

                        <div
                            className="login-link"
                            onClick={() => {
                                setCurrentPage("login");
                                setIsRegister(false);
                            }}
                            style={{ textAlign: "end" }}
                        >
                            <span>Go Back</span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default ForgotPassword;
