import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { IconButton } from "@mui/material";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import VisibilityOffOutlinedIcon from "@mui/icons-material/VisibilityOffOutlined";

import GoeLogo from "../../assets/images/svg/goe_logo.svg";
import NoAccess from "../../assets/images/svg/no_access.svg";
import Loader from "../../Components/Loader/Loader";
import Api from "utils/api";
import moment from "moment";

const Login = ({ setCurrentPage, lodingInfo, setIsAuthenticated, setPath, setIsRegister }) => {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm<{
        login: string;
        password: string;
    }>();

    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    const [loginError, setLoginError] = useState(false);
    const [loading, setLoading] = useState(false);

    const onRegister = () => {
        setCurrentPage("forgotPassword");
        setIsRegister(true);
    };

    const onLogin = ({ login, password }) => {
        setLoading(true);
        Api.signInWithOkta({
            email: login,
            password,
        })
            .then(({ AuthenticationResult }) => {
                if (AuthenticationResult.AccessToken) {
                    sessionStorage.setItem("gcd-access-token", AuthenticationResult.AccessToken);
                    sessionStorage.setItem(
                        "gcd-access-token-expiration",
                        moment().add("seconds", AuthenticationResult.ExpiresIn).format("YYYY-MM-DD HH:mm:ss")
                    );
                    Api.ExternLoginSetToken(AuthenticationResult.AccessToken, login);
                    if (setIsAuthenticated) {
                        setIsAuthenticated({ ...lodingInfo, loggedIn: true });
                    }
                    setPath("about");
                } else {
                    setLoginError(true);
                }
                setLoading(false);
            })
            .catch(() => {
                setLoginError(true);
                setLoading(false);
            });
    };

    return (
        <div className="goe-capabilites-login">
            <div
                className="login-container"
                style={{
                    backgroundImage: `url(${NoAccess})`,
                }}
            >
                {loading && <Loader width="100" />}
                <div className="login-inner-main-container">
                    <div className="login-logo-container">
                        <img src={GoeLogo} alt="GOE Logo" />
                    </div>

                    <form className="login-form-container" onSubmit={handleSubmit(onLogin)}>
                        <div className="name">
                            <div className="row-div row-div-left">
                                <label
                                    className="login-form-label"
                                    style={{
                                        color: errors.login ? "red" : "black",
                                    }}
                                >
                                    Login
                                </label>
                            </div>
                            <div className="row-div">
                                <input
                                    className="login-input"
                                    type="text"
                                    placeholder="Enter login Email"
                                    {...register("login", {
                                        required: "This field is required",
                                    })}
                                    style={{
                                        borderColor: errors.login ? "red" : "#E6E6E6",
                                    }}
                                />

                                {errors.login && <span className="form-error">{errors.login.message}</span>}
                            </div>
                        </div>

                        <div className="login-hr" />

                        <div className="name">
                            <div className="row-div row-div-left">
                                <label
                                    className="login-form-label"
                                    style={{
                                        color: errors.password ? "red" : "black",
                                    }}
                                >
                                    Password
                                </label>
                            </div>
                            <div className="login-password-input row-div">
                                <input
                                    className="login-input"
                                    type={isPasswordVisible ? "text" : "password"}
                                    placeholder="Enter password"
                                    {...register("password", {
                                        required: "This field is required",
                                    })}
                                    style={{
                                        borderColor: errors.password ? "red" : "#E6E6E6",
                                    }}
                                />

                                <IconButton
                                    onClick={() => setIsPasswordVisible(!isPasswordVisible)}
                                    className="login-show-password"
                                >
                                    {isPasswordVisible ? <VisibilityOffOutlinedIcon /> : <VisibilityOutlinedIcon />}
                                </IconButton>

                                {errors.password && <span className="form-error">{errors.password.message}</span>}
                            </div>
                        </div>

                        <div className="login-link" onClick={() => setCurrentPage("forgotPassword")}>
                            <span>Forgot your password?</span>
                        </div>

                        <div className="login-hr" />

                        <button className="login-button" type="submit">
                            Log In
                        </button>

                        <hr></hr>
                        <div className="login-regdiv">
                            <span className="login-regspan">Don’t have a Login ID?</span>
                        </div>

                        <div className="reg-button" onClick={onRegister}>
                            <span className="button-span">Register</span>
                        </div>

                        {loginError && (
                            <div style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}>
                                <div className="login-hr" />

                                <span className="form-error" style={{ textAlign: "center" }}>
                                    Invalid Email or Password
                                </span>
                            </div>
                        )}
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Login;
