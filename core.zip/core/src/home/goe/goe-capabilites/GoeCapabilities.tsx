import React, { useEffect, useState, useCallback } from "react";
import Header from "./Components/Header/Header";
import Landing from "./Landing/Landing";
import "./styles/goe-capabilites.scss";
import { useLocation, useHistory } from "react-router-dom";
import InvestorJourney from "./Components/InvestJourney/InvestLandingPage";
import { GoalConsoleLandingPage } from "./Components/GoalConsole/GoalConsoleLandingPage";
import FinancialPlanningTools from "./Pages/FinancialPlanningTools/FinancialPlanningTools";
import GoeConfig from "./Components/GoeConfig/GoeConfig";
import { useScreenshot } from "utils/helpers";
import ComingSoon from "./Components/InvestJourney/ComingSoon";
import UnAuthenticatedPages from "./Pages/UnAuthenticatedPages";
import { GoeCapabilitiesContextProvider } from "./GoeCapabilitiesContext";

import Api from "utils/api";

export default function GoeCapabilities({
    lodingInfo = { skipLoading: false, loading: false, loggedIn: false },
    setIsAuthenticated,
    appId,
    zoneId,
}: any) {
    const history = useHistory();
    const pathName = useLocation();

    const [path, setPath] = useState("about");
    const [showModal, setShowModal] = useState(false);
    const isGoeCapabilitiesAppUrl = Api.isGoeCapabilitiesAppUrl;
    const screenshot = useScreenshot();
    const initialGoeContext = { appId: appId, zoneId: zoneId };
    const isAuthenticated = lodingInfo.loggedIn;
    const loading = lodingInfo.loading;

    const navigateToLoginPage = useCallback(() => {
        setPath("login");
        history.push({ pathname: "/login" });
    }, [history]);

    useEffect(() => {
        if (path) {
            if (!isGoeCapabilitiesAppUrl) {
                history.push({ pathname: `/goe-capabilities/${zoneId}` + "/" + path });
            } else {
                if (isAuthenticated) history.push({ pathname: "/" + path });
            }
        }
    }, [path, history, zoneId, isAuthenticated, isGoeCapabilitiesAppUrl]);

    useEffect(() => {
        document.title = "GOE Capabilities Support Tool";

        return () => {
            document.title = "Unified Investment Portal";
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        // This will handle unauthenticated user from accessing other pages
        if (path !== "login" && !isAuthenticated && !loading && isGoeCapabilitiesAppUrl) {
            navigateToLoginPage();
        }
        // eslint-disable-next-line
    }, [path, isAuthenticated, loading, navigateToLoginPage]);

    useEffect(() => {
        if (!isGoeCapabilitiesAppUrl) {
            screenshot.take();
        }
    }, [screenshot, isGoeCapabilitiesAppUrl]);

    const setRoutingPath = (path) => {
        setPath(path);
        if (path == "backtest" || path == "goeconfig") {
            setShowModal(true);
        }
    };

    const getRoute = () => {
        const endpoints = pathName.pathname.split("/");
        if (endpoints[endpoints.length - 1] === "login") {
            return (
                <UnAuthenticatedPages
                    lodingInfo={lodingInfo}
                    setIsAuthenticated={setIsAuthenticated}
                    setPath={setPath}
                />
            );
        } else if (endpoints[endpoints.length - 1] === "financialplanningtools") {
            return <FinancialPlanningTools />;
        } else if (endpoints[endpoints.length - 1] === "invest") {
            return <InvestorJourney setRoutingPath={setRoutingPath} />;
        } else if (endpoints[endpoints.length - 1] === "goalconsole") {
            return <GoalConsoleLandingPage setRoutingPath={setRoutingPath} />;
        } else if (endpoints[endpoints.length - 1] === "backtest") {
            return (
                <ComingSoon
                    show={showModal}
                    closeModal={() => {
                        setShowModal(false);
                    }}
                />
            );
        } else if (endpoints[endpoints.length - 1] === "goeconfig") {
            return <GoeConfig />;
        } else {
            return <Landing setRoutingPath={setRoutingPath} />;
        }
    };

    if (loading) {
        return <>Loading.... </>;
    }

    return (
        <div>
            <GoeCapabilitiesContextProvider {...initialGoeContext}>
                {(isAuthenticated || !isGoeCapabilitiesAppUrl) && (
                    <Header path={path} setRoutingPath={setRoutingPath} />
                )}
                {getRoute()}
            </GoeCapabilitiesContextProvider>
        </div>
    );
}
