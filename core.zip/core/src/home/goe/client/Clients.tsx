import React, { useEffect, useState } from "react";
import { Switch, Route, Link, useLocation } from "react-router-dom";
import { Button } from "@mui/material";
import FTSelect from "common/FTSelect";
import Table from "common/Table";
import moment from "moment";

import Api from "utils/api";
import CreateClient from "./CreateClient";
import { goeClientUpdateNotification } from "utils/events";
import Access from "utils/access";
import { useScreenshot } from "utils/helpers";
import AppCover from "home/dashboad/AppCover";

const DATE_FORMAT = "YYYY-MM-DD HH:mm:ss";

const getName = ({ cell }) => {
    const original = cell?.row?.original || {};
    let name = cell.value || original.email;
    if (original.status === "Draft" && !name) {
        name = original?.orig?.email || "";
    }
    return <Link to={`/goe/client-settings/${cell.row.original.id}`}> {name} </Link>;
};
const NewClients = () => {
    const [isAdmin] = useState<any>(Access.hasAccessToZone("goe", "client-settings", ["admin"]));

    return (
        <Button
            component={Link}
            to="/goe/client-settings/create"
            className="no-hover-link"
            color="primary"
            variant="contained"
            disabled={!isAdmin}
        >
            Create New Client
        </Button>
    );
};

export default function Clients() {
    const columns = [
        { Header: "Client Name", Cell: getName, width: "col-2", accessor: "name" },
        { Header: "Region", accessor: "region", width: "col-2" },
        { Header: "Distribution Channel", accessor: "channel", width: "col-2" },
        { Header: "Client Status", accessor: "status", width: "col-2" },
        { Header: "Updated Date", accessor: "updated_at", width: "col-2" },
        { Header: "Updated By", accessor: "updated_by", width: "col-2" },
    ];
    const statusOptions = ["No Filter", "Draft", "Active", "Inactive"].map((x) => ({ key: x, value: x }));
    const [data, setData] = useState<any>({ rows: [], filter: "No Filter", loading: true });
    const [draft, setDraft] = useState<any>({});
    const location = useLocation();

    const screenshot = useScreenshot();

    useEffect(() => {
        refresh();
        const sub = goeClientUpdateNotification.subscribe(refresh);
        return () => {
            sub.unsubscribe();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function refresh() {
        const call1 = Api.getGoeClients({ roleFilter: "CLIENT" }).then((resp) => {
            return resp?.data?.map((x) => {
                const userInfo = x?.app_settings?.goe["client-settings"] || {};
                const user = { id: x._id, name: x.name, email: x.email };
                const updatedAt = x.__meta?.timestamp;
                return {
                    id: x._id,
                    name: x.name,
                    email: x.email,
                    region: userInfo?.country?.name,
                    channel: userInfo?.config?.channelName,
                    status: userInfo.status?.name,
                    updated_by: x.__meta?.author,
                    updated_at: updatedAt ? moment(updatedAt).format(DATE_FORMAT) : "",
                    orig: { ...user, ...userInfo },
                };
            });
        });

        const call2 = Api.getGoeLatestDraft().then((resp) => {
            setDraft(resp?.data || {});
            const c = resp?.data?.client;
            const updatedAt = c?.createdBy?.__meta?.timestamp;
            if (c && Object.keys(c).length > 0) {
                const draft = [
                    {
                        id: resp.userId,
                        name: c.customer_name,
                        region: c.country,
                        segment: c.segment,
                        status: "Draft",
                        channel: `${c.country || ""}_${c.segment || ""}`,
                        updated_by: c?.createdBy?.__meta?.author,
                        updated_at: updatedAt ? moment(updatedAt).format(DATE_FORMAT) : "",
                        orig: c,
                    },
                ];

                return draft;
            }
            return [];
        });
        Promise.all([call1, call2]).then((resps) => {
            const all = resps.filter((x) => x).flat();
            setData({ ...data, all_rows: all, rows: all, loading: false });
            screenshot.take();
        });
    }

    const filterStatus = (filter) => {
        const rows = filter == "No Filter" ? data.all_rows : data.all_rows.filter((x) => x.status == filter);
        setData({ ...data, rows, filter });
    };

    const filter = (
        <FTSelect label="Status" value={data.filter} options={statusOptions} onChange={filterStatus}></FTSelect>
    );

    return (
        <AppCover>
            <Switch>
                <Route
                    path="/goe/client-settings/:id"
                    render={(props) => <CreateClient {...props} data={data.rows} draft={draft} />}
                />
            </Switch>
            <div
                className={
                    location.pathname == "/goe/client-settings" || location.pathname == "/goe/client-settings/"
                        ? ""
                        : "d-none"
                }
            >
                <div className="clients-table">
                    <Table
                        columns={columns}
                        data={data.rows}
                        loading={data.loading}
                        end_widgets={filter}
                        start_widgets={NewClients()}
                    ></Table>
                </div>
            </div>
        </AppCover>
    );
}
