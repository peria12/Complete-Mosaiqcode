import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import createStyles from "@mui/styles/createStyles";
import makeStyles from "@mui/styles/makeStyles";
import Paper from "@mui/material/Paper";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import { useForm } from "react-hook-form";
import HeaderPanel from "../common/HeaderPanel";
import PortfolioCard from "./PortfolioCard";
import { MuiForm } from "common/mui-form/MuiForm";
import { goeClientUpdateNotification } from "utils/events";

import {
    parseOptions,
    parseOptionsForPortfolio,
    extractDisplayablePortfolioList,
    getPortfolioOptionsForSwingConstraints,
    getLossThresholdValues,
    parseActuarialNameOptions,
    extractBundleIds,
    checkActuarialSelected,
    checkAggregatedRetirementAccountsSelected,
    checkIfAllRiskValuesEntered,
    parseFormData,
    segregateConfig,
    checkDatesInterval,
} from "../goe-helper";
import {
    tabs,
    editModeButtons,
    createModeButtons,
    viewModeButtons,
    clientFormConfig,
    clientFormConfigDefaults as defaultValues,
    generalSettingsConfigs,
    clientFormConfigDefaults,
    makeClientForm,
    generalSettingsKeys,
    ActuarialTypes,
    taxDataTableTypes,
    defaultPortfolioConfig,
} from "./client-config";

// import Loader from "common/Loader";
import clsx from "clsx";
import Api from "utils/api";
import { errorHandler } from "utils/error-handler";
import { groupBy } from "utils/helpers";
import errorNotification from "utils/api-error";
import Access from "utils/access";

const useStyles = makeStyles(() =>
    createStyles({
        base: {
            width: "100%",
            // background: "white"
        },
        container: {
            width: "100%",
            padding: "0 30px",
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
        },
        formBase: {
            width: "100%",
            padding: "8px 0px",
            display: "flex",
            justifyContent: "flex-start",
            flexDirection: "row",
            alignItems: "center",
        },
        tab: {
            textTransform: "capitalize",
            fontSize: "1.15rem",
        },
        formContainer: {
            background: "white",
            margin: "25px",
        },
        formPanel: {
            width: "100%",
            padding: "28px 48px",
        },
        label: {
            color: "#9b9ba3",
            width: "26%",
            fontSize: "15px",
            fontWeight: 700,
            textTransform: "uppercase",
        },
        subheading: {
            color: "rgba(0, 0, 0, 0.87)",
            width: "100%",
            fontSize: "17px",
            margin: "10px",
            fontWeight: 600,
        },
        inputField: {
            width: "74%",
        },
        fieldGrp: {
            display: "flex",
            alignItems: "center",
        },
    })
);

export default function CreateClient({ match, data, draft }) {
    const classes = useStyles();
    const [formValues, setFormValues] = useState<any>({ ...defaultValues });
    const methods = useForm<any>({ mode: "onChange", defaultValues: formValues });
    const [currTabInfo, setCurrTabInfo] = useState<any>({ ...tabs[0] });
    const [configStates, setConfigStates] = useState<any>({});
    const [formConfig, setFormConfig] = useState<any>(clientFormConfig);
    const [portfolioDataRiskOn, setPortfolioDataRiskOn] = useState([]);
    const [portfolioDataRiskOff, setPortfolioDataRiskOff] = useState([]);
    const [portfolioId, setPortfolioId] = useState(0);
    const [swingConstraintNumberBase, setSwingConstraintNumberBase] = useState([]);
    const [selectedPortfolio, setSelectedPortfolio] = useState<any>({});
    const [customErr, setCustomErr] = useState(false);
    const [portfolioList, setPortfolioList] = useState([]);
    const [state, setState] = useState<any>({
        title: "Title",
        type: "view",
        obj: null,
        btnLoading: false,
    });
    const [isAdmin] = useState<any>(Access.hasAccessToZone("goe", "client-settings", ["admin"]));
    const [prevRiskLevel, setPrevRiskLevel] = useState(0);
    const formFields = {};
    const history = useHistory();

    const {
        handleSubmit,
        setValue,
        watch,
        getValues,
        formState: { errors },
    } = methods;

    const selectedSegments = watch("segment");
    const selectedCountry = watch("country");
    const isFtPortfolio = watch("using_ft_portfolio");
    const selectedPortfolioBundle = watch("portfolio_selection");
    const riskLevel = watch("risk_level");
    const riskIndicatorFlag = watch("riskOverlay");
    const configuration = watch("select_configuration");
    const safeGuard = watch("safe_guard_wealth_last_year");
    const lossThreshold = watch("loss_threshold_floor");
    const swingConstraint = watch("swing_constraint");
    const goalLevel = watch("select_goal_level");
    // const goalLevels = watch("select_goal_levels");
    const levelsOfGoalPriority = watch("levelsOfGoalPriority");
    const lossThresholdValues = watch("loss_threshold_values");
    const shortTenure = watch("tenure_years");
    const reallocationDates = watch("reallocation_frequency_dates");
    const selectedAdjustFees = watch("adjust_fees");
    const selectedAdditionalWealthPaths = watch("additional_wealth_paths");
    const selectedPessimisticPathProbability = watch("pessimistic_path_probability");
    const selectedOptimisticPathProbability = watch("optimistic_path_probability");
    const selectedWealthPath = watch("wealth_path");
    // const selectedGridFrequency = watch("grid_frequency");
    const selectedAggRetirementAccounts = watch("aggregatedRetirementAccounts");
    const selectedActuarialData = watch("actuarialData");
    const selectedFixedPlanningAge = watch("useAFixedPlanningAge");
    const customErrorHandler = (isValid) => {
        setCustomErr(isValid);
    };

    const handleSaveDraft = (form) => {
        const customer_name = form?.customer_name?.trim();
        if (!customer_name || errors?.customer_name) {
            errorNotification.next({
                type: "error",
                text: "Please enter customer name",
                open: true,
            });
            return;
        }
        Api.goeSaveDraft({ data: { ...draft, client: form } }).then(() => {
            errorNotification.next({
                type: "success",
                text: "Draft saved successfully",
                open: true,
            });
            goeClientUpdateNotification.next();
            history.push(".");
        });
    };

    useEffect(() => {
        Api.getZoneSettings("goe", "client-settings").then((response: any) => {
            console.log("response?.client_profile_templates", response?.client_profile_templates);
            if (response?.client_profile_templates) {
                setConfigStates((configState) => ({
                    ...configState,
                    fileTemplates: response?.client_profile_templates || {},
                }));
            }
        });
        // eslint-disable-next-line
    }, []);

    useEffect(() => {
        const id = match.params.id;
        const value = (data || []).find((x) => x.id == id);
        // console.log("User", value);
        async function getPortfolioData(val) {
            if (val.country.name && val.segment.name && val.portfolioBundle.name) {
                const dataObj = {
                    country: val.country.name,
                    segment: val.segment.name,
                    portfolioBundleName: val.portfolioBundle.name || "",
                };
                setSelectedPortfolio({});
                Api.getGoePortfolioBundlesInfo(dataObj)
                    .then((selectedPortfolio: any) => {
                        setSelectedPortfolio(selectedPortfolio);
                        setValue("portfolio_description", selectedPortfolio.description);
                        const _formData = makeClientForm(val, selectedPortfolio);
                        if (_formData?.risk_level) {
                            setPrevRiskLevel(Number(_formData?.risk_level));
                        }
                        setFormValues({ ...JSON.parse(JSON.stringify(_formData)) });
                        setState({
                            ...state,
                            title: `View ${val.name}`,
                            type: "view",
                            mode: "",
                            obj: val,
                        });
                    })
                    .catch((err) => errorHandler(err));
            }
        }
        if (value) {
            const val = value.orig;
            if (value.status == "Draft") {
                setFormValues({ ...val });
                setState({
                    ...state,
                    title: `Edit Draft ${value.name}`,
                    type: "new",
                    mode: "draft",
                    obj: null,
                });
            } else {
                getPortfolioData(val);
            }
        } else {
            setFormValues({ ...clientFormConfigDefaults });
            setState({
                ...state,
                title: "New Client",
                type: "new",
                mode: "",
                obj: null,
            });
        }
        // eslint-disable-next-line
    }, [match.params.id, data]);

    useEffect(() => {
        if (state?.type === "edit" && currTabInfo?.tab_id === 2 && riskLevel) {
            if (riskLevel !== prevRiskLevel) {
                setValue("portfolioConfig", defaultPortfolioConfig);
            }
            if (riskLevel === formValues?.risk_level) {
                setValue("portfolioConfig", formValues?.portfolioConfig);
            }
            setPrevRiskLevel(riskLevel);
        }
        // eslint-disable-next-line
    }, [riskLevel]);

    function setDeriskingData(pfConfig) {
        const list: any = [];
        Object.keys(pfConfig).map((key: any) => {
            if (defaultPortfolioConfig[key] && pfConfig[key]?.upperLimit) {
                list.push(pfConfig[key]?.upperLimit);
            }
        });
        const max = Math.max(...list);
        const pfs: any = [];
        for (let i = max; i > 0; i--) {
            pfs.push({ key: i, value: i });
        }
        setConfigStates((configState) => ({
            ...configState,
            deriskingPortfolioNames: pfs,
        }));
    }

    const handler = (id) => {
        const step = currTabInfo?.tab_id;
        const values = getValues();
        if (customErr) {
            return 0;
        }
        if (step === 6) {
            if (checkAggregatedRetirementAccountsSelected(values.actuarialData, selectedAggRetirementAccounts)) {
                errorNotification.next({
                    open: true,
                    text: "Please select data table PortfolioMapping when AggregatedRetirementAccounts is Yes",
                    type: "error",
                });
                return 0;
            }
        }
        if (id == "continue") {
            setTimeout(() => {
                if (Object.keys(errors)?.length > 0) {
                    return;
                }
                if (step === 2) {
                    setSwingConstraintMaxNumber(values.portfolioConfig);
                    if (!shortTenure) {
                        errorNotification.next({
                            type: "error",
                            text: "Goal Tenure is required",
                            open: true,
                        });
                        return;
                    }
                    /** To check if any risk level duplicacy */
                    const { portfolioConfig } = values;
                    const labelValues: any = [];
                    for (const key in portfolioConfig) {
                        if (portfolioConfig[key].labelValue) {
                            labelValues.push(portfolioConfig?.[key]?.labelValue);
                        }
                    }
                    const uniqElements = Array.from(new Set(labelValues));
                    if (labelValues.length !== uniqElements.length) {
                        errorNotification.next({
                            type: "error",
                            text: "Risk profile names must be distinct",
                            open: true,
                        });
                        return;
                    }

                    /** To check if both risk label and portfolios are entered based on risk Level */
                    const hasAllFieldsEntered = checkIfAllRiskValuesEntered(riskLevel, portfolioConfig);
                    if (!hasAllFieldsEntered) {
                        errorNotification.next({
                            type: "error",
                            text: "Please enter all risk profile details",
                            open: true,
                        });
                        return;
                    }
                    setDeriskingData(values?.portfolioConfig);
                    setValue("probabilityThresholds", values?.probabilityThresholds);
                } else if (step === 3) {
                    /** To check duplicacy in goalNames in levels of goal priority */
                    const { levelsOfGoalPriority } = values;
                    const arr: any = Object.values(levelsOfGoalPriority);
                    let hasDupicacy = false;
                    let hasFieldsNotEntered = false;

                    for (let i = 0; i < arr.length; i++) {
                        for (let j = i + 1; j < arr.length; j++) {
                            if (arr[i].labelValue && arr[i].labelValue === arr[j].labelValue) {
                                hasDupicacy = true;
                                break;
                            }
                        }
                    }

                    for (let i = 0; i < Number(goalLevel); i++) {
                        if (!arr[i].labelValue) {
                            hasFieldsNotEntered = true;
                            break;
                        }
                    }

                    if (hasFieldsNotEntered) {
                        errorNotification.next({
                            open: true,
                            type: "error",
                            text: "Please enter goal priority details",
                        });
                        return 0;
                    }

                    if (hasDupicacy) {
                        errorNotification.next({
                            open: true,
                            type: "error",
                            text: "All goal priority names should be unique",
                        });
                        return 0;
                    }
                    if (values.swing_constraint && !values.swing_constraint_number) {
                        errorNotification.next({
                            open: true,
                            text: "Please select a swing constraint number",
                            type: "error",
                        });
                        return 0;
                    }
                    const gip_values = values?.guaranteedIncomePercent;
                    const updatedGIP = {};
                    Object.keys(gip_values).map((k) => {
                        updatedGIP[k] = { ...gip_values[k], ...levelsOfGoalPriority[k] };
                    });
                    setValue("guaranteedIncomePercent", updatedGIP);
                }
                if (currTabInfo?.tab_id < 6) {
                    setCurrTabInfo({ ...tabs[currTabInfo?.tab_id] });
                    return;
                }
            }, 100);
        } else if (id == "save_draft") {
            const values = getValues();
            handleSaveDraft(values);
        } else if (id == "edit") {
            setState({ ...state, title: `Edit ${state.obj?.name}`, type: "edit" });
        } else if (id == "stop_edit") {
            setState({ ...state, title: `View ${state.obj?.name}`, type: "view" });
        } else if (id == "reset_password") {
            Api.resetPassword(state.obj.id)
                .then(() => {
                    errorNotification.next({
                        type: "success",
                        text: "Password is reset. Sent link to user to change password",
                        open: true,
                    });
                })
                .catch(() => {
                    errorNotification.next({
                        type: "error",
                        text: "Failed to reset password",
                        open: true,
                    });
                });
        }
    };

    function onSubmit(values) {
        if (currTabInfo?.tab_id === 6) {
            if (checkActuarialSelected(values.actuarialData)) {
                errorNotification.next({
                    open: true,
                    text: "Please select data table name",
                    type: "error",
                });
                return 0;
            }
            const {
                tenureForShortTerm: { shortTermRetirementGoalTenure, shortTermRetirementGoalTenureUnengaged },
            } = values;
            if (!shortTermRetirementGoalTenureUnengaged || !shortTermRetirementGoalTenure) {
                errorNotification.next({
                    open: true,
                    type: "error",
                    text: "Tenure for short term retirement goals is invalid!",
                });
                return 0;
            }
            const ids = extractBundleIds(selectedPortfolio?.portfolios, true);
            let riskOffIds = extractBundleIds(selectedPortfolio?.portfolios, false);
            if (!riskIndicatorFlag) riskOffIds = [];
            values.maxAge = values.maxAge ? values.maxAge : null;
            values.portfolioConfig = segregateConfig(
                values.portfolioConfig,
                values.decumulationProfile,
                values.retirementProfile
            );
            const parsedData = parseFormData(values, generalSettingsKeys, ids, riskOffIds);
            let apiReq: any = null;
            const id = match.params.id;
            if (id && state.type == "edit" && state?.mode != "draft") {
                const updatePayload = { ...parsedData, id: id };
                console.log("updatePayload", updatePayload);
                apiReq = Api.goeUpdateClient(updatePayload);
                // return
            } else {
                apiReq = Api.goeCreateClient(parsedData);
            }
            setState({ ...state, btnLoading: true });
            apiReq
                .then((response: any) => {
                    setState({ ...state, btnLoading: false });
                    if (response.statusCode === 400 || response.success == false) {
                        errorNotification.next({
                            type: "error",
                            text: response.message || "Failed",
                            open: true,
                        });
                        return;
                    }
                    errorNotification.next({
                        type: "success",
                        text: state.type == "edit" ? "Client updated successfully" : "Client created!",
                        open: true,
                    });
                    if (response.success == true && state?.mode == "draft") {
                        Api.goeSaveDraft({ data: { ...draft, client: {} } }).then(() => {
                            goeClientUpdateNotification.next();
                            onBack();
                        });
                    } else {
                        goeClientUpdateNotification.next();
                        onBack();
                    }
                })
                .catch((err) => {
                    setState({ ...state, btnLoading: false });
                    errorHandler(err);
                });
        }
    }

    useEffect(() => {
        Promise.all([Api.getGoePortfolioEnums()]).then(([porfolioEnums]) => {
            if (porfolioEnums) {
                const { countries, segments, portfolioBundleNames } = porfolioEnums;
                const pfNames = parseOptionsForPortfolio(portfolioBundleNames, true);
                setConfigStates((configState) => ({
                    ...configState,
                    countries: parseOptions(countries),
                    segments: parseOptions(segments),
                    portfolios: pfNames,
                }));
                setPortfolioList(portfolioBundleNames);
            }
        });
    }, []);

    useEffect(() => {
        if (selectedPortfolio) {
            const portfolioOptionsForSwingConstraints = getPortfolioOptionsForSwingConstraints(
                selectedPortfolio.portfolios
            );
            const swingConstraintNumber: any = [];
            for (let i = 1; i <= portfolioOptionsForSwingConstraints.length; i++) {
                swingConstraintNumber.push({ value: i, key: i });
            }
            setSwingConstraintNumberBase(swingConstraintNumber);
            setPortfolioId(selectedPortfolio.id);
            const newPortfolioData = extractDisplayablePortfolioList(selectedPortfolio?.portfolios, true);
            const newPortfolioDataOff = extractDisplayablePortfolioList(selectedPortfolio?.portfolios, false);
            setPortfolioDataRiskOn(newPortfolioData);
            setPortfolioDataRiskOff(newPortfolioDataOff);
        } else {
            setPortfolioId(-1);
        }
        // eslint-disable-next-line
    }, [selectedPortfolio]);

    const isTabDisabled = (index) => {
        const tab_id = currTabInfo?.tab_id;
        return tab_id <= index;
    };

    const handleChange = (event, newValue) => {
        const tabInfo = tabs.find((tab) => tab.id == newValue) || {};
        setCurrTabInfo({ ...tabInfo });
    };

    const onChange = (value, key) => {
        formFields[key] = value;
    };

    // get selected portfolio details
    useEffect(() => {
        if (selectedCountry && selectedSegments && selectedPortfolioBundle) {
            const dataObj = {
                country: selectedCountry,
                segment: selectedSegments,
                portfolioBundleName: selectedPortfolioBundle || "",
            };
            setSelectedPortfolio({});
            Api.getGoePortfolioBundlesInfo(dataObj)
                .then((selectedPortfolio: any) => {
                    setSelectedPortfolio(selectedPortfolio);
                    setValue("portfolio_description", selectedPortfolio.description);
                })
                .catch((err) => errorHandler(err));
        }
        // eslint-disable-next-line
    }, [selectedCountry, selectedSegments, selectedPortfolioBundle, match.params.id, data]);

    // get selected portfolio details
    useEffect(() => {
        const id = match.params.id;
        const value = (data || []).find((x) => x.id == id);
        // console.log("User", value);
        if (value) {
            const val = value.orig;
            if (val.country.name && val.segment.name && val.portfolioBundle.name) {
                const dataObj = {
                    country: val.country.name,
                    segment: val.segment.name,
                    portfolioBundleName: val.portfolioBundle.name || "",
                };
                // setSelectedPortfolio({});
                Api.getGoePortfolioBundlesInfo(dataObj)
                    .then((selectedPortfolio: any) => {
                        setSelectedPortfolio(selectedPortfolio);
                        setValue("portfolio_description", selectedPortfolio.description);
                    })
                    .catch((err) => errorHandler(err));
            }
        }
        // eslint-disable-next-line
    }, [match.params.id, data]);
    // set distribution_channel
    useEffect(() => {
        if (portfolioList?.length > 0) {
            setConfigStates((configState) => ({
                ...configState,
                portfolios: parseOptionsForPortfolio(portfolioList, isFtPortfolio),
            }));
        }
        // eslint-disable-next-line
    }, [isFtPortfolio]);

    useEffect(() => {
        if (selectedSegments && selectedCountry) {
            setPortfolioList([]);
            Api.getGoeFilterPortfolios({
                country: selectedCountry,
                segment: selectedSegments,
            })
                .then((portfolios: any) => {
                    setConfigStates((configState) => ({
                        ...configState,
                        portfolios: parseOptionsForPortfolio(portfolios, isFtPortfolio),
                    }));
                    setPortfolioList(portfolios);
                })
                .catch((err) => {
                    errorHandler(err);
                    setConfigStates((configState) => ({
                        ...configState,
                        portfolios: [],
                    }));
                    setPortfolioList([]);
                });
            const distributionChannelObj = {
                value: `${selectedCountry.toString()}_${selectedSegments.toString()}`,
                key: `${selectedCountry.toString()}_${selectedSegments.toString()}`,
            };
            setConfigStates((configStates: any) => ({
                ...configStates,
                channels: [distributionChannelObj],
            }));
            setValue("distribution_channel", distributionChannelObj.value);
        }
        // eslint-disable-next-line
    }, [selectedCountry, selectedSegments]);

    // reset client form config
    useEffect(() => {
        const newPortfolioData = extractDisplayablePortfolioList(selectedPortfolio?.portfolios, true);
        // const newPortfolioDataOff = extractDisplayablePortfolioList(selectedPortfolio?.portfolios, false);
        const newLength = newPortfolioData.length;
        const newPortfolioSettings = formConfig["portfolio_configuration"].map((item) => {
            if (item.name === "portfolioConfig") {
                item.config.forEach((child) => {
                    if (child.levels.includes(riskLevel)) {
                        child.display = true;
                    } else {
                        child.display = false;
                    }
                });
                return {
                    ...item,
                    max: newLength,
                    min: 1,
                };
            }
            if (item.name === "risk_indicator_flag_value") {
                return {
                    ...item,
                    display: riskIndicatorFlag,
                    required: riskIndicatorFlag,
                };
            }
            if (item.name === "decumulationProfile") {
                return { ...item, max: newLength, min: 1 };
            }
            if (item.name === "retirementProfile") {
                return { ...item, max: newLength, min: 1 };
            }
            return item;
        });
        const newGeneralSettings = formConfig["configuration"].map((item) => {
            if (item.name === "minimum_portfolios_for_last_year") {
                return { ...item, display: safeGuard, required: safeGuard };
            }
            if (item.name == "annual_in_bps") {
                return {
                    ...item,
                    display: selectedAdjustFees == "Common",
                    required: selectedAdjustFees == "Common",
                };
            }
            if (item.name == "pessimistic_path_probability") {
                return {
                    ...item,
                    display: selectedAdditionalWealthPaths == "Yes",
                    required: selectedAdditionalWealthPaths == "Yes",
                };
            }
            if (item.name == "optimistic_path_probability") {
                return {
                    ...item,
                    display: selectedAdditionalWealthPaths == "Yes",
                    required: selectedAdditionalWealthPaths == "Yes",
                };
            }
            if (item.name == "wealth_path_probability") {
                return {
                    ...item,
                    display: selectedWealthPath == "Custom",
                    required: selectedWealthPath == "Custom",
                };
            }
            if (lossThreshold && item.name === "downside_protection") {
                setValue("downside_protection", "Maximize Loss Threshold Probability");
                return { ...item };
            }
            if (!lossThreshold && item.name === "downside_protection") {
                setValue("downside_protection", "Maximize Goal Probability");
                return { ...item };
            }
            if (item.name === "swing_constraint_number") {
                return { ...item, display: swingConstraint, required: swingConstraint };
            }

            if (item.name === "goal_priority_level_and_loss_threshold_values") {
                const updatedElements = item["elements"].map((ele) => {
                    if (ele.name === "levelsOfGoalPriority") {
                        ele.config.forEach((child) => {
                            if (child.levels.includes(goalLevel)) {
                                child.display = true;
                            } else {
                                child.display = false;
                            }
                        });
                        return { ...ele };
                    }
                    if (ele.name === "loss_threshold_values" || ele.name === "loss_threshold_value_label") {
                        const itemClone = { ...ele };
                        if (ele.name === "loss_threshold_values") {
                            itemClone.config[0].inputs = getLossThresholdValues(0, goalLevel);
                            itemClone.config[1].inputs = getLossThresholdValues(1, goalLevel);
                        }
                        return {
                            ...itemClone,
                            display: lossThreshold,
                            required: lossThreshold,
                        };
                    }
                });

                return { ...item, elements: updatedElements };
            }

            if (item.name === "loss_threshold_probability") {
                const itemClone = { ...item };
                if (item.name === "loss_threshold_values") {
                    itemClone.config[0].inputs = getLossThresholdValues(0, goalLevel);
                    itemClone.config[1].inputs = getLossThresholdValues(1, goalLevel);
                }
                return {
                    ...itemClone,
                    display: lossThreshold,
                    required: lossThreshold,
                };
            }
            return item;
        });
        const newRetirementSettings = formConfig["retirement"].map((item) => {
            if (item.name == "PortfolioMappingTable") {
                let portfolioMappingExists = false;
                if (selectedActuarialData !== undefined) {
                    selectedActuarialData.map((data) => {
                        if (data["key"] == "PortfolioMapAggRetirementAccounts-H") {
                            setValue("PortfolioMappingTable", data["valueTwo"]);
                            portfolioMappingExists = true;
                        }
                    });
                }
                if (!portfolioMappingExists) {
                    setValue("PortfolioMappingTable", "");
                }

                return {
                    ...item,
                    display: selectedAggRetirementAccounts == true,
                    required: selectedAggRetirementAccounts == true,
                };
            }
            if (item.name == "contributionRate") {
                return {
                    ...item,
                    display: selectedAggRetirementAccounts == true,
                    required: selectedAggRetirementAccounts == true,
                };
            }
            if (item.name == "fixedBenefits") {
                return {
                    ...item,
                    display: selectedAggRetirementAccounts == true,
                    required: selectedAggRetirementAccounts == true,
                };
            }
            if (item.name == "calculateGoals") {
                return {
                    ...item,
                    display: selectedAggRetirementAccounts == true,
                    required: selectedAggRetirementAccounts == true,
                };
            }
            if (item.name == "derisking") {
                return {
                    ...item,
                    display: selectedAggRetirementAccounts == true,
                    required: selectedAggRetirementAccounts == true,
                };
            }
            if (item.name === "guaranteedIncomePercent") {
                const configs = item["config"].map((child) => {
                    if (child.levels.includes(goalLevel)) {
                        child.display = true;
                    } else {
                        child.display = false;
                    }
                    return { ...child };
                });
                return { ...item, config: configs };
            }
            if (item.name == "planningAge") {
                return {
                    ...item,
                    display: selectedFixedPlanningAge == true,
                    required: selectedFixedPlanningAge == true,
                };
            }
            if (item.name == "minimumPlanningAge") {
                return {
                    ...item,
                    display: selectedFixedPlanningAge == false,
                    required: selectedFixedPlanningAge == false,
                };
            }
            return item;
        });

        const newUpaConfig = formConfig["upa"].map((item) => {
            if (item.name === "goalModification") {
                const configs = item["config"].map((child) => {
                    if (child.levels.includes(goalLevel)) {
                        child.display = true;
                    } else {
                        child.display = false;
                    }
                    return { ...child };
                });
                return { ...item, config: configs };
            }

            return item;
        });

        const newFormConfig = {
            ...formConfig,
            portfolio_configuration: newPortfolioSettings,
            configuration: newGeneralSettings,
            retirement: newRetirementSettings,
            upa: newUpaConfig,
        };
        setFormConfig(newFormConfig);
        // eslint-disable-next-line
    }, [
        riskIndicatorFlag,
        selectedPortfolio,
        isFtPortfolio,
        riskLevel,
        goalLevel,
        lossThreshold,
        swingConstraint,
        safeGuard,
        selectedAdjustFees,
        selectedAdditionalWealthPaths,
        selectedPessimisticPathProbability,
        selectedOptimisticPathProbability,
        selectedWealthPath,
        // selectedGridFrequency,
        selectedAggRetirementAccounts,
        selectedFixedPlanningAge,
    ]);

    useEffect(() => {
        if (lossThresholdValues) {
            const lossThresholdValuesClone = { ...lossThresholdValues };
            for (const key in levelsOfGoalPriority) {
                lossThresholdValuesClone["accumulation"][key].labelValue = levelsOfGoalPriority[key]?.labelValue;
                lossThresholdValuesClone["decumulation"][key].labelValue = levelsOfGoalPriority[key]?.labelValue;
            }
            setValue("loss_threshold_values", lossThresholdValuesClone);
        }
        // eslint-disable-next-line
    }, [levelsOfGoalPriority]);

    //To do: validation
    useEffect(() => {
        const riskOffIds = extractBundleIds(selectedPortfolio?.portfolios, false);
        if (riskIndicatorFlag && !riskOffIds.length && currTabInfo?.tab_id === 2 && state?.mode != "draft") {
            errorNotification.next({
                type: "info",
                text: "Risk off profiles are not present",
                open: true,
            });
        }
        // eslint-disable-next-line
    }, [riskIndicatorFlag, selectedPortfolio]);

    const setSwingConstraintMaxNumber = (portfolioConfig: any) => {
        const upperLimit: any = [];
        for (const key in portfolioConfig) {
            if (!portfolioConfig[key].upperLimit) {
                upperLimit.push(portfolioConfig?.[key]?.lowerLimit);
            }
            upperLimit.push(portfolioConfig?.[key]?.upperLimit);
        }
        const swingConstraintNumberClone = swingConstraintNumberBase.filter((item: any) => {
            if (item.value <= Math.max(...upperLimit)) {
                return item;
            }
        });
        setConfigStates((configState) => ({
            ...configState,
            swingConstraintNumber: swingConstraintNumberClone,
        }));
    };

    useEffect(() => {
        if (reallocationDates) {
            const haveEqualIntervals = checkDatesInterval(reallocationDates.reallocationDatesByFrequency);
            if (haveEqualIntervals) {
                errorNotification.next({
                    type: "info",
                    text: "Dates are not at the same interval",
                    open: true,
                });
            }
        }
        // eslint-disable-next-line
    }, [reallocationDates]);

    useEffect(() => {
        if (selectedSegments && selectedCountry) {
            const payload = { country: selectedCountry, status: "Active" };
            const actuarialOptions = {};
            const taxDataTableOptions = {};
            ActuarialTypes.forEach((at) => (actuarialOptions[at?.key] = []));
            taxDataTableTypes.forEach((at) => (taxDataTableOptions[at?.key] = []));
            Api.getActuarialNames({ ...payload }).then((response) => {
                if (response) {
                    const actuarialByTypes = groupBy(response, "type");
                    const taxDataByTypes = groupBy(response, "type");
                    Object.keys(actuarialOptions).forEach((key) => {
                        if (actuarialByTypes?.[key]) {
                            actuarialOptions[key] = parseActuarialNameOptions(actuarialByTypes?.[key]);
                        }
                    });
                    Object.keys(taxDataTableOptions).forEach((key) => {
                        if (taxDataByTypes?.[key]) {
                            taxDataTableOptions[key] = parseActuarialNameOptions(actuarialByTypes?.[key]);
                        }
                    });
                }
                setConfigStates((configState) => ({
                    ...configState,
                    actuarialNames: actuarialOptions,
                    taxActuarialNames: taxDataTableOptions,
                }));
            });
        }
        // eslint-disable-next-line
    }, [selectedCountry, selectedSegments]);

    useEffect(() => {
        const newForm = generalSettingsConfigs?.[configuration] || {};
        Object.keys(newForm).map((item) => {
            setValue(item, newForm[item]);
            return 0;
        });
        // eslint-disable-next-line
    }, [configuration]);

    const buttons = {
        view: viewModeButtons,
        edit: editModeButtons,
        new: createModeButtons,
    };

    useEffect(() => {
        methods.reset(formValues);
        // eslint-disable-next-line
    }, [formValues]);
    useEffect(() => {
        let portfolioMappingExists = false;
        if (selectedActuarialData !== undefined) {
            selectedActuarialData.map((data) => {
                if (data["key"] == "PortfolioMapAggRetirementAccounts-H") {
                    setValue("PortfolioMappingTable", data["valueTwo"]);
                    portfolioMappingExists = true;
                }
            });
        }
        if (!portfolioMappingExists) {
            setValue("PortfolioMappingTable", "");
        } // eslint-disable-next-line
    }, [selectedActuarialData]);
    function onBack() {
        setFormValues({});
        history.push(".");
    }

    return (
        <div className={classes.base}>
            <form onSubmit={handleSubmit(onSubmit)}>
                <HeaderPanel
                    title={state.title}
                    onBack={onBack}
                    buttons={buttons[state.type]}
                    handler={handler}
                    onSubmit={handleSubmit(onSubmit)}
                    isLastTab={currTabInfo?.tab_id == 6}
                    userId={match.params.id}
                    email={state.obj?.email}
                    state={state}
                    isAdmin={isAdmin}
                />
                <div className={classes.container}>
                    <Paper square>
                        <Tabs
                            value={currTabInfo.id}
                            indicatorColor="primary"
                            textColor="primary"
                            color="default"
                            onChange={handleChange}
                        >
                            {tabs?.map((tab: any, index: number) => (
                                <Tab
                                    key={tab.id}
                                    className={classes.tab}
                                    value={tab.id}
                                    label={tab.label}
                                    disabled={isTabDisabled(index)}
                                />
                            ))}
                        </Tabs>
                    </Paper>
                    <div className={classes.formContainer}>
                        <div className={classes.formPanel}>
                            {formConfig?.[currTabInfo?.id].map((field: any, index) => {
                                if (field?.type == "subheading") {
                                    return (
                                        <div
                                            key={field.key}
                                            className={classes.subheading}
                                            style={{ width: "100%", marginLeft: "-10px" }}
                                        >
                                            {field.label}
                                        </div>
                                    );
                                }
                                let isDisabled = field.disabled;
                                if (state.type == "view") {
                                    isDisabled = true;
                                } else if (state.type === "edit" && field?.name === "email") {
                                    isDisabled = true;
                                }

                                const form = (
                                    <MuiForm
                                        key={field.key}
                                        field={{ ...field, disabled: isDisabled }}
                                        value={defaultValues?.[field?.key] || ""}
                                        methods={methods}
                                        style={{ width: "55%" }}
                                        showPlaceholder={true}
                                        variant="outlined"
                                        onChange={(value) => onChange(value, field?.id || field.key)}
                                        configState={configStates[field?.stateKey]}
                                        customErrorHandler={customErrorHandler}
                                    />
                                );
                                const fullWidthTypes = ["range-select-group", "heading", "date-group"];
                                const hideField = field.display === false ? true : false;
                                if (field?.type == "field-group") {
                                    return (
                                        <div key={index} className={classes.formBase}>
                                            <div className={classes.label} />
                                            <div className={classes.inputField + " " + classes.fieldGrp}>
                                                {field?.elements.map((field: any) => {
                                                    const hideField = field.display === false ? true : false;
                                                    let isDisabled = field.disabled;
                                                    if (state.type == "view") {
                                                        isDisabled = true;
                                                    } else if (state.type === "edit" && field?.name === "email") {
                                                        isDisabled = true;
                                                    }
                                                    return (
                                                        <>
                                                            {
                                                                <div key={field.key} style={{ width: "50%" }}>
                                                                    {!hideField && (
                                                                        <MuiForm
                                                                            key={"form_" + field.key}
                                                                            field={{ ...field, disabled: isDisabled }}
                                                                            value={defaultValues?.[field?.key] || ""}
                                                                            methods={methods}
                                                                            style={{ width: "55%" }}
                                                                            showPlaceholder={true}
                                                                            variant="outlined"
                                                                            onChange={(value) =>
                                                                                onChange(value, field?.id || field.key)
                                                                            }
                                                                            configState={configStates[field?.stateKey]}
                                                                            customErrorHandler={customErrorHandler}
                                                                        />
                                                                    )}
                                                                </div>
                                                            }
                                                        </>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    );
                                }
                                return (
                                    <>
                                        {
                                            <div
                                                key={field.key}
                                                className={clsx({
                                                    [classes.formBase]: !["heading"]?.includes(field.type),
                                                })}
                                            >
                                                {fullWidthTypes.includes(field?.type) ? (
                                                    <> {form} </>
                                                ) : (
                                                    !hideField && (
                                                        <>
                                                            <div className={classes.label}> {field.label} </div>
                                                            <div className={classes.inputField}> {form} </div>
                                                        </>
                                                    )
                                                )}
                                            </div>
                                        }
                                    </>
                                );
                            })}
                        </div>
                        <div hidden={currTabInfo?.id !== "portfolio_configuration"}>
                            <PortfolioCard data={portfolioDataRiskOn} key={portfolioId} />
                            {riskIndicatorFlag && (
                                <PortfolioCard data={portfolioDataRiskOff} key={`${portfolioId}off`} />
                            )}
                        </div>
                    </div>
                </div>
            </form>
        </div>
    );
}
