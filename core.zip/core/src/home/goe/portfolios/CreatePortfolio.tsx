import { MuiFormLine } from "common/mui-form/MuiForm";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";
import GoePortfolios from "home/goe/common/GoePortfolios";
import Api from "utils/api";
import HeaderPanel from "home/goe/common/HeaderPanel";
import { goePortfolioUpdateNotification } from "utils/events";
import Access from "utils/access";
import errorNotification from "utils/api-error";
import ConfirmDialog from "common/ConfirmDialog";
import { parseOptions } from "../goe-helper";

import { FormFile } from "common/forms/FormFile";
import { errorHandler } from "utils/error-handler";
import Loader from "common/Loader";

const getFormData = (value) => {
    const mapper = (x) => {
        return {
            meanPercent: x.meanPercent,
            sdPercent: x.sdPercent,
            assetAllocations: x.assetAllocations,
            feesAdjuster: x.feesAdjuster,
        };
    };
    const riskOn = (value.portfolios || []).filter((x) => x.riskOn).map(mapper);
    const riskOff = (value.portfolios || []).filter((x) => !x.riskOn).map(mapper);
    const portfolios = riskOn.map((x, index) => {
        const ret = { ...x };
        if (index < riskOff.length) {
            const obj = riskOff[index];
            Object.keys(obj).forEach((key) => {
                ret[`${key}_risk_off`] = obj[key];
            });
        }
        return ret;
    });
    return {
        email: value.createdBy?.email,
        name: value.name,
        isFtPortfolio: value.isFtPortfolio,
        description: value.description,
        segment: value.segment?.name,
        country: value.country?.name,
        channel: `${value.segment?.name}_${value.country?.name}`,
        risk_off: value.portfolios?.some((x) => !x.riskOn),
        portfolios,
    };
};
const editBttons: any = [
    {
        id: "clone",
        label: "Clone",
        adminOnly: true,
    },
];

const newBttons: any = [
    {
        id: "cancel",
        label: "Cancel",
        color: "secondary",
        adminOnly: true,
    },
    {
        id: "save_draft",
        label: "Save Draft",
        color: "secondary",
        adminOnly: true,
    },
    {
        id: "create",
        label: "Create",
        adminOnly: true,
        isLoaderRequired: true,
    },
];

const emptyFormData = {
    name: "",
    isFtPortfolio: "",
    description: "",
    segment: "",
    country: "",
    channel: "",
    risk_off: false,
    portfolios: [...new Array(16)].map(() => ({
        meanPercent: 0,
        sdPercent: 0,
        assetAllocations: [{ name: "bond", weightPercent: 0 }],
        feesAdjuster: 0,
        meanPercent_risk_off: 0,
        sdPercent_risk_off: 0,
        assetAllocations_risk_off: [{ name: "bond", weightPercent: 0 }],
        feesAdjuster_risk_off: 0,
    })),
};

const getPortfolios = (risk_off, portfolios, name) => {
    const mapper = (y) => ({ name: y.name, weightPercent: parseFloat(y.weightPercent) });
    const p1 = portfolios.map((x) => ({
        riskOn: true,
        meanPercent: parseFloat(x.meanPercent),
        sdPercent: parseFloat(x.sdPercent),
        feesAdjuster: parseFloat(x.feesAdjuster),
        assetAllocations: x.assetAllocations.map(mapper),
        name,
    }));

    if (risk_off) {
        const p2 = portfolios.map((x) => ({
            riskOn: false,
            meanPercent: parseFloat(x.meanPercent_risk_off),
            sdPercent: parseFloat(x.sdPercent_risk_off),
            feesAdjuster: parseFloat(x.feesAdjuster_risk_off),
            assetAllocations: (x.assetAllocations_risk_off || []).map(mapper),
            name,
        }));
        return p1.concat(p2);
    }
    return p1;
};

const validatePortfolio = ([p]) => {
    let sum = 0;
    p.assetAllocations.forEach((a) => (sum = sum + parseFloat(a.weightPercent)));
    if (sum == 100) return false;
    return true;
};

export default function CreatePortfolio({ match, data, draft }) {
    const methods = useForm<any>({ mode: "onChange", defaultValues: {} });
    const [state, setState] = useState<any>({ title: "", new: false, obj: null, clone: false, btnLoading: false });
    const history = useHistory();
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [isAdmin] = useState<any>(Access.hasAccessToZone("goe", "portfolios", ["admin"]));
    const [configStates, setConfigStates] = useState<any>({});

    const country = methods.watch("country");
    const segment = methods.watch("segment");

    useEffect(() => {
        Api.getGoePortfolioEnums().then((porfolioEnums) => {
            if (porfolioEnums) {
                const { countries, segments } = porfolioEnums;
                setConfigStates((configState) => ({
                    ...configState,
                    countries: parseOptions(countries),
                    segments: parseOptions(segments),
                }));
            }
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const id = match.params.id;
        const value = (data || []).find((x) => x.id == id);
        if (value) {
            const val = value.orig;
            if (value.status == "Draft") {
                methods.reset(val);
                setState({
                    ...state,
                    new: true,
                    title: `Edit Draft ${value.name}`,
                    mode: "draft",
                    obj: null,
                    clone: false,
                });
            } else {
                methods.reset(getFormData(val));

                setState({
                    ...state,
                    new: false,
                    title: `View Portfolio ${value.name}`,
                    mode: "",
                    obj: val,
                    clone: false,
                });
            }
        } else if (!methods.getValues()?.name) {
            methods.reset({ ...emptyFormData, email: Access.userInfo.email });
            setState({ ...state, new: true, title: "New Portfolio", mode: "", obj: null, clone: false });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [match.params.id, data]);

    const handleSaveDraft = (form) => {
        const pf_name = form?.name?.trim();
        if (!pf_name) {
            errorNotification.next({ type: "error", text: "Please enter valid portfolio name", open: true });
            return;
        }
        Api.goeSaveDraft({ data: { ...draft, portfolio: form } }).then(() => {
            errorNotification.next({
                type: "success",
                text: "Draft saved successfully",
                open: true,
            });

            goePortfolioUpdateNotification.next();
            history.push(".");
        });
    };

    const handleCreate = (val) => {
        const bad_ones = val.portfolios
            .map((val, i) => [val, i + 1])
            .filter(validatePortfolio)
            .map((arr) => arr[1])
            .join(",");

        if (bad_ones.length) {
            const text = `IncorrectVales in Portfolio Bundles, check the portfolios: ${bad_ones}`;
            errorNotification.next({ type: "error", text, open: true });
            return 0;
        }

        if (state.clone) {
            if ((data || []).find((x) => x.name == val.name)) {
                errorNotification.next({
                    type: "error",
                    text: "Please do update the portfolio name. Another portfolio has the same name",
                    open: true,
                });
                return 0;
            }
        }

        const obj = {
            email: Access.userInfo.email,
            name: val.name,
            description: val.description,
            country: val.country,
            segment: val.segment,
            isFtPortfolio: val.isFtPortfolio === true,
            portfolios: getPortfolios(val.risk_off, val.portfolios, val.name),
        };
        setState({ ...state, btnLoading: true });
        Api.createGoePortfolioBundle(obj)
            .then((response) => {
                setState({ ...state, btnLoading: false });
                errorNotification.next({ type: "success", text: "Portfolio created successfully.", open: true });
                if (response && state?.mode == "draft") {
                    Api.goeSaveDraft({ data: { ...draft, portfolio: {} } }).then(() => {
                        goePortfolioUpdateNotification.next();
                        history.push(".");
                    });
                } else {
                    goePortfolioUpdateNotification.next();
                    history.push(".");
                }
            })
            .catch((err) => {
                setState({ ...state, btnLoading: true });
                console.log("ERRR", err);
            });
    };

    const handler = (id) => {
        if (id == "clone") {
            methods.setValue("email", Access.userInfo.email);
            setState({ ...state, new: true, title: "New Portfolio", clone: true });
        } else if (id == "cancel") {
            setConfirmOpen(true);
        } else if (id == "create") {
            methods.handleSubmit(handleCreate, (data) => console.log("BADDATA", data))();
        } else if (id == "save_draft") {
            handleSaveDraft(methods.getValues());
        }
    };

    const handleCancel = () => {
        if (state.clone) {
            methods.reset(getFormData(state.obj));
            setState({ ...state, new: false, title: `View portfolio ${state.obj?.name}`, clone: false });
        } else {
            history.push(".");
        }
    };

    if (country && segment) {
        methods.setValue("channel", `${country}_${segment}`);
    }
    const [portfolioData, setPortfolioData] = useState({
        isLoading: false,
    });
    function handleFileChange(fileData) {
        setPortfolioData({ ...portfolioData, isLoading: true });
        Api.getPortfolioLoad({ attachments: fileData })
            .then((response: any) => {
                if (response?.data?.statusCode == 200) {
                    setPortfolioData({ ...portfolioData, isLoading: false });
                    setState({
                        ...state,
                        new: true,
                        title: "New Portfolio",
                        mode: "",
                        obj: response?.body,
                        clone: false,
                    });
                    methods.reset({
                        ...JSON.parse(JSON.stringify(response?.data?.body)),
                        email: Access.userInfo.email,
                    });
                } else {
                    errorNotification.next({ type: "error", text: response?.message || "failed", open: true });
                    setPortfolioData({ ...portfolioData, isLoading: false });
                }
            })
            .catch((e: any) => {
                const resp = e?.response?.data || {};
                if (resp.statusCode === 400) {
                    errorNotification.next({ type: "error", text: resp?.body || "Failed", open: true });
                    setPortfolioData({ ...portfolioData, isLoading: false });
                    return;
                }
                errorHandler(e);
                errorNotification.next({ type: "error", text: "Error...", open: true });
                setPortfolioData({ ...portfolioData, isLoading: false });
            });
    }

    return (
        <>
            <HeaderPanel
                title={state.title}
                onBack={() => history.push(".")}
                buttons={state.new ? newBttons : editBttons}
                handler={handler}
                state={state}
                isAdmin={isAdmin}
            />
            <div style={{ background: "white", maxWidth: "800px" }} className="mx-4 p-3">
                <MuiFormLine
                    field={{
                        label: "EMAIL",
                        placeholder: "Email",
                        name: "email",
                        type: "text",
                        required: true,
                        disabled: true,
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "PORTFOLIO ORIGIN",
                        name: "isFtPortfolio",
                        type: "switch",
                        placeholder: "Portfolio Origin",
                        required: false,
                        skipRequired: true,
                        states: { on: "FT", off: "Non FT" },
                        wider: true,
                        disabled: !state.new,
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "PORTFOLIO NAME",
                        placeholder: "Portfolio Name",
                        name: "name",
                        type: "text",
                        required: true,
                        disabled: !state.new,
                        tooltip: "FT_US_Retail_2020CME naming convention",
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "PORTFOLIO DESCRIPTION",
                        placeholder: "Portfolio Description",
                        name: "description",
                        type: "text",
                        disabled: !state.new,
                        required: true,
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "SEGMENT",
                        placeholder: "Segment",
                        name: "segment",
                        type: "select",
                        required: true,
                        disabled: !state.new,
                        options: configStates.segments || [],
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "COUNTRY",
                        placeholder: "Country",
                        name: "country",
                        type: "select",
                        required: true,
                        disabled: !state.new,
                        options: configStates.countries || [],
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{ label: "CHANNEL", placeholder: "Channel", name: "channel", type: "text", disabled: true }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "DO YOU WANT TO ADD RISK OFF PORTFOLIOS",
                        name: "risk_off",
                        type: "switch",
                        required: false,
                        skipRequired: true,
                        disabled: !state.new,
                        states: { on: "Yes", off: "No" },
                        wider: true,
                    }}
                    methods={methods}
                />
                <FormFile
                    title={"Drag and Drop or Select File (Only *.csv files will be accepted)"}
                    value={[]}
                    onChange={handleFileChange}
                    multiple={false}
                    showFileName={false}
                    height={"100px"}
                    accept={".csv"}
                />
            </div>
            {portfolioData?.isLoading && <Loader />}
            <div>
                <GoePortfolios methods={methods} disabled={!state.new} />
            </div>
            <ConfirmDialog
                title={`Are you sure you want to cancel?`}
                open={confirmOpen}
                setOpen={setConfirmOpen}
                onConfirm={handleCancel}
            >
                You will lose all the information if you leave this page.
            </ConfirmDialog>
        </>
    );
}
