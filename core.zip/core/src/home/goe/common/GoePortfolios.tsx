import React, { useState } from "react";
import { useFieldArray } from "react-hook-form";
import { Tabs, Tab, Button, IconButton, Typography } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { MuiForm } from "common/mui-form/MuiForm";
import CloseIcon from "@mui/icons-material/Close";
import AddIcon from "@mui/icons-material/Add";
import { CustomErrorMessage } from "common/mui-form/ErrorMessage";

const useStyles = makeStyles((theme) => ({
    paginationContainer: {
        margin: "2rem",
        boxShadow: "0 0 11px 0 rgba(0, 0, 0, 0.1)",
        border: "solid 1px #f2f2f2",
        backgroundColor: "#ffffff",
        "& .MuiTab-root": {
            minWidth: "0px",
            padding: "0px 12px",
            boxShadow: "0 0 11px 0 rgba(0,0,0,0.1)",
            border: "solid 1px #f2f2f2",
            color: theme.palette.primary.main,
        },
        "& .MuiTabs-root": {
            marginBottom: "1rem",
        },
        "& .Mui-selected": {
            borderBottom: "0px !important",
            color: theme.palette.common.white,
            background: theme.palette.primary.main,
        },
    },
    tabIndicator: {
        background: "rgba(0,0,0,0)",
    },
    createPortfolio: {
        "& fieldset": {
            border: 0,
            borderBottom: "1px solid rgba(0, 0, 0, 0.42) !important",
        },
    },
}));



const options = [
    { key: "equity", value: "Equity" },
    { key: "bond", value: "Bond" },
    { key: "money_market", value: "Money Market" },
];

function ShowError({ show }) {
    return show ? <CustomErrorMessage text="Total weightage must be equal to 100%" /> : <></>;
}

const TabForm = ({ index, methods, suffix, disabled }) => {
    const hasError = () => {
        let sum = 0;
        const ports = methods.getValues("portfolios");
        if (ports) {
            const arr = ports[index][`assetAllocations${suffix}`] || [];
            arr.forEach((x) => (sum += parseInt(x.weightPercent, 10) || 0));
            return sum != 100;
        }
        return false;
    };

    const aaForm = useFieldArray<any>({
        control: methods.control,
        name: `portfolios.${index}.assetAllocations${suffix}`,
    });
    [0, 1, 2].map((x) => methods.watch(`portfolios.${index}.assetAllocations${suffix}.${x}.name`));
    [0, 1, 2].map((x) => methods.watch(`portfolios.${index}.assetAllocations${suffix}.${x}.weightPercent`));

    const showError = hasError();
    const classes = useStyles();

    return (
        <>
            <div className={classes.createPortfolio}>
                <Typography variant="h5" component="div">
                    {suffix == "_risk_off" ? "RISK OFF" : "RISK ON"}
                </Typography>
                <div style={{ maxWidth: "300px" }}>
                    <div className="my-4">
                        <MuiForm
                            field={{
                                title: "MEAN RETURNS",
                                name: `portfolios.${index}.meanPercent${suffix}`,
                                type: "percent",
                                required: true,
                                width: "100%",
                                disabled,
                            }}
                            variant="standard"
                            methods={methods}
                        />
                    </div>

                    <div className="my-4">
                        <MuiForm
                            field={{
                                title: "STANDARD DEVIATION",
                                name: `portfolios.${index}.sdPercent${suffix}`,
                                type: "percent",
                                required: true,
                                width: "100%",
                                disabled,
                            }}
                            variant="standard"
                            methods={methods}
                        />
                    </div>
                </div>
                <div className="my-4">
                    <MuiForm
                        field={{
                            title: "FEES ADJUSTER (ANNUAL IN BPS)",
                            name: `portfolios.${index}.feesAdjuster${suffix}`,
                            type: "number",
                            required: true,
                            width: "100%",
                            disabled,
                            max: 10000,
                            min: 0,
                        }}
                        variant="standard"
                        methods={methods}
                    />
                </div>

                <Typography variant="h6" component="div">
                    ASSET ALLOCATION
                </Typography>

                {aaForm.fields.map((ff: any, index2) => (
                    <div className="row" key={ff.id}>
                        <div className="col-5 p-2">
                            <MuiForm
                                field={{
                                    title: "ALLOCATION",
                                    name: `portfolios.${index}.assetAllocations${suffix}.${index2}.name`,
                                    disabled,
                                    type: "select",
                                    options: options.filter(
                                        (x) => ff.name == x.key || aaForm.fields.every((f: any) => f.name != x.key)
                                    ),
                                }}
                                variant="standard"
                                methods={methods}
                            />
                        </div>
                        <div className="col-5 p-2">
                            <MuiForm
                                field={{
                                    title: "WEIGHTAGE",
                                    name: `portfolios.${index}.assetAllocations${suffix}.${index2}.weightPercent`,
                                    type: "percent",
                                    required: true,
                                    variant: "standard",
                                    disabled,
                                }}
                                variant="standard"
                                methods={methods}
                            />
                        </div>
                        <div className="col-2 p-2">
                            <IconButton
                                onClick={() => {
                                    if (aaForm.fields.length > 1) {
                                        aaForm.remove(index2);
                                    }
                                }}
                                disabled={disabled || aaForm.fields.length <= 1}
                                size="large"
                            >
                                <CloseIcon fontSize="small" color={"secondary"} />
                            </IconButton>
                        </div>
                    </div>
                ))}
                <div className="row">
                    <div className="col-5 my-2">
                        <Button
                            disabled={disabled}
                            onClick={() => {
                                const name = options.find((x) => !aaForm.fields.some((f: any) => f.name == x.key))?.key;
                                if (name) {
                                    aaForm.append({ name, weightPercent: 0 });
                                }
                            }}
                            variant="outlined"
                        >
                            <AddIcon fontSize="small" color={"primary"} /> Add Allocation
                        </Button>
                    </div>
                    *
                    <div className="col-5 p-1">
                        <ShowError show={showError} />
                    </div>
                </div>
            </div>
        </>
    );
};

const TabPanel = ({ index, onRemove, methods, form, disabled, risk_off }) => {
    return (
        <>
            <div className="d-flex flex-row-reverse">
                <div className="px-2">
                    <Button
                        onClick={() => {
                            if (form.fields.length > 1) {
                                form.remove(index);
                                onRemove(index);
                            }
                        }}
                        color="secondary"
                        variant="outlined"
                        disabled={disabled || form.fields.length <= 1}
                    >
                        <CloseIcon fontSize="small" color={"secondary"} />
                        Remove Portfolio
                    </Button>
                </div>
            </div>
            <div className="row m-2">
                <div className="col-6 pe-5">
                    <TabForm index={index} methods={methods} suffix={""} disabled={disabled} />
                </div>
                {risk_off ? (
                    <div className="col-6 ps-5">
                        <TabForm index={index} methods={methods} suffix={"_risk_off"} disabled={disabled} />
                    </div>
                ) : (
                    <></>
                )}
            </div>
        </>
    );
};

export default function GoePortfolios({ methods, disabled }) {
    const classes = useStyles();
    const form = useFieldArray<any>({ control: methods.control, name: "portfolios" });

    const addPortfolio = () => {
        form.append({
            riskOn: true,
            meanPercent: 0,
            sdPercent: 0,
            assetAllocations: [{ name: "bond", weightPercent: 0 }],
            feesAdjuster: 0,
        });
    };

    const [selected, setSelected] = useState(0);

    const handleTabChange = (e, selectedData) => {
        setSelected(selectedData);
    };

    const risk_off = methods.watch("risk_off");

    const removePortfolio = (index) => {
        if (index >= form.fields.length - 1) {
            setSelected(index - 1);
        }
    };

    return (
        <div className={classes.paginationContainer}>
            <div className="d-flex flex-row-reverse">
                <div className="p-2">
                    <Button onClick={addPortfolio} color="primary" variant="outlined" disabled={disabled}>
                        <AddIcon fontSize="small" />
                        Add Portfolio
                    </Button>
                </div>
            </div>
            <Tabs
                value={selected}
                indicatorColor="primary"
                textColor="primary"
                onChange={handleTabChange}
                aria-label="disabled tabs example"
                TabIndicatorProps={{ className: classes.tabIndicator }}
            >
                {form.fields.map((item, index) => (
                    <Tab key={item.id} value={index} label={index + 1} />
                ))}
            </Tabs>

            {form.fields.map((field: any, index) =>
                index == selected ? (
                    <TabPanel
                        key={field.id}
                        index={index}
                        onRemove={removePortfolio}
                        disabled={disabled}
                        form={form}
                        risk_off={risk_off}
                        methods={methods}
                    />
                ) : (
                    <></>
                )
            )}
        </div>
    );
}
