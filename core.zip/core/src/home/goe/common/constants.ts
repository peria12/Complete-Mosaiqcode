import OwnHousedis from "../goe-capabilites/assets/images/svg/goals_icons/own_house_dis.svg";
import OwnHouse from "../goe-capabilites/assets/images/svg/goals_icons/own_house.svg";
import PlanRetDis from "../goe-capabilites/assets/images/svg/goals_icons/plan_retirement_dis.svg";
import PlanRet from "../goe-capabilites/assets/images/svg/goals_icons/plan_retirement.svg";
import BuyCardis from "../goe-capabilites/assets/images/svg/goals_icons/buy_car_dis.svg";
import BuyCar from "../goe-capabilites/assets/images/svg/goals_icons/buy_car.svg";
import SaveCollege from "../goe-capabilites/assets/images/svg/goals_icons/save_college.svg";
import SaveCollegedis from "../goe-capabilites/assets/images/svg/goals_icons/save_college_dis.svg";
import DrawIncome from "../goe-capabilites/assets/images/svg/goals_icons/draw_income.svg";
import DrawIncomedis from "../goe-capabilites/assets/images/svg/goals_icons/draw_income_dis.svg";
import TakeVacation from "../goe-capabilites/assets/images/svg/goals_icons/take_vacation.svg";
import TakeVacationdis from "../goe-capabilites/assets/images/svg/goals_icons/take_vacation_dis.svg";
import CustomGoal from "../goe-capabilites/assets/images/svg/goals_icons/custom_goal.svg";
import CustomGoaldis from "../goe-capabilites/assets/images/svg/goals_icons/custom_goal_dis.svg";
import ReviewIcon from "../goe-capabilites/assets/images/svg/exclamation-circle.svg";
import AlignedIcon from "../goe-capabilites/assets/images/svg/progress_more_50.svg";
import UnrealisticIcon from "../goe-capabilites/assets/images/svg/circle-xmark.svg";
import Equity from "../goe-capabilites/assets/images/svg/forward_looking/equity.svg";
import FixedIncome from "../goe-capabilites/assets/images/svg/forward_looking/fixed_income.svg";
// import ZoomIn from "@mui/icons-material/ZoomIn";
// import ZoomOut from "@mui/icons-material/ZoomOut";
import { IChartMargin } from "./interfaces";

export const CHART_X_AXIS_VALUE_GAP = 100;

export const CHART_X_AXIS_TICK_ADJUSTMENT = 22;
export const ICON_TOP_HEIGHT = 6;
export const CHART_X_AXIS_START_MARGIN = 20;

export const CHART_MARGIN: IChartMargin = {
    top: 70,
    right: 100,
    bottom: 90,
    left: 100,
};

export const MAX_CHART_WIDTH = 1349;
export const MAX_CHART_HEIGHT = 500;
export const RENDERABLE_CHART_WIDTH = MAX_CHART_WIDTH - CHART_MARGIN.left - CHART_MARGIN.right;

//reach out to api to folow names to be caps
//modify goe component name
export const GOAL_ICONS = {
    buy_car_light: BuyCardis,
    buy_car: BuyCar,
    own_house_light: OwnHousedis,
    own_house: OwnHouse,
    plan_retirement_light: PlanRetDis,
    plan_retirement: PlanRet,
    save_collage_light: SaveCollegedis,
    save_collage: SaveCollege,
    draw_income_light: DrawIncomedis,
    draw_income: DrawIncome,
    take_vacation_light: TakeVacationdis,
    take_vacation: TakeVacation,
    custom_goal_light: CustomGoaldis,
    custom_goal: CustomGoal,
};

export const GOAL_TYPES = {
    ONE_TIME: "ONE_TIME",
    TENURE: "TENURE",
};

export const GOAL_ICON_SIZE = {
    small: {
        width: 20,
        height: 20,
    },
    large: {
        width: 60,
        height: 60,
    },
};

export const GOE_GOAL_STAGES = {
    ALIGNED: "Aligned",
    REVIEW: "Review",
    UNREALISTIC: "Unrealistic",
};

export const GOE_GOAL_STAGE_ICONS = {
    [GOE_GOAL_STAGES.ALIGNED]: AlignedIcon,
    [GOE_GOAL_STAGES.REVIEW]: ReviewIcon,
    [GOE_GOAL_STAGES.UNREALISTIC]: UnrealisticIcon,
};

export const UPA_GOAL_STAGES = {
    EQUITY: "Equity",
    FIXEDINCOME: "Fixed Income",
};

export const UPA_GOAL_STAGE_ICONS = {
    [UPA_GOAL_STAGES.FIXEDINCOME]: FixedIncome,
    [UPA_GOAL_STAGES.EQUITY]: Equity,
};

export const X_AXIS_YEAR_GAP = 27;

export const DONUT_CHART_SIZES = {
    small: {
        width: 20,
        height: 20,
    },
    large: {
        width: 50,
        height: 50,
    },
};

export const DONUT_CHART_COLORS = {
    color1: {
        start: "#00847D",
        end: "#67F5DC",
    },
    color2: {
        start: "#E15000",
        end: "#F2AE00",
    },
};

export const ZOOM_FEATURE_ENABLED_COMPONENTS = ["UPAOverviewGraph", "GOEOverviewGraph"];
