import * as d3 from "d3";
import { IChartData, IChartDomain, ID3ScaleMethod, IGoalData, IGoalTenureData } from "./interfaces";

import {
    CHART_MARGIN,
    CHART_X_AXIS_START_MARGIN,
    CHART_X_AXIS_TICK_ADJUSTMENT,
    CHART_X_AXIS_VALUE_GAP,
    GOAL_TYPES,
    MAX_CHART_HEIGHT,
    RENDERABLE_CHART_WIDTH,
    ZOOM_FEATURE_ENABLED_COMPONENTS,
} from "./constants";
import { runPipeController, wealthSplitterController } from "../goe-capabilites/GoeController";

export function getMaxValueOfKeyFromChartData(key: string, chartData: Array<IChartData>): number {
    let maxValue = -Infinity;

    for (const item of chartData) {
        const value = item[key];
        // Find maximum value
        if (value > maxValue) maxValue = value;
    }

    return maxValue;
}

export function getXDomains(wealthPathData: Array<IChartData>, goalData?: IGoalData): IChartDomain {
    const minValue: number = new Date().getFullYear();
    let maxValue: number = minValue;

    if (goalData) {
        const goalType = getGoalTypeByGoal(goalData);

        if (goalType === GOAL_TYPES.ONE_TIME) {
            maxValue = getYearFromDateString(goalData.achieve_this_goal);
        } else if (goalType === GOAL_TYPES.TENURE && goalData?.end_on_date) {
            maxValue = getYearFromDateString(goalData.end_on_date);
        } else if (goalType === GOAL_TYPES.TENURE && goalData?.last_withdrawal) {
            maxValue = getYearFromDateString(goalData.last_withdrawal);
        }
    } else {
        maxValue = getMaxValueOfKeyFromChartData("year", wealthPathData);
    }

    return [minValue, maxValue];
}

export function getYDomains(wealthPathData: Array<IChartData>): IChartDomain {
    const maxValue = getMaxValueOfKeyFromChartData("value", wealthPathData);

    return [0, maxValue];
}

export function getYearFromDateString(date: string): number {
    //date: YYYY-MM-DD
    return Number(date.split("-")[0]);
}

export function getGoalByYearFromGoalList(goalList: Array<any>, year: number) {
    for (const goal of goalList) {
        const { achieve_this_goal, plan_start_retirement, end_on_date, start_first_withdrawal, last_withdrawal } = goal;

        if (achieve_this_goal) {
            const goalYear = Number(getYearFromDateString(achieve_this_goal));

            if (goalYear === year) {
                return goal;
            }
        } else if (plan_start_retirement) {
            const goalStartYear = Number(getYearFromDateString(plan_start_retirement));

            const goalEndYear = Number(getYearFromDateString(end_on_date));
            if (year >= goalStartYear && year <= goalEndYear) {
                return goal;
            }
        } else {
            const goalStartYear = Number(getYearFromDateString(start_first_withdrawal));

            const goalEndYear = Number(getYearFromDateString(last_withdrawal));
            if (year >= goalStartYear && year <= goalEndYear) {
                return goal;
            }
        }
    }

    return null;
}

export function getGoalTypeByGoal(goal) {
    if (goal.achieve_this_goal) {
        return GOAL_TYPES.ONE_TIME;
    }

    return GOAL_TYPES.TENURE;
}

export function getChartWidth(count: number): number {
    return count * CHART_X_AXIS_VALUE_GAP - CHART_MARGIN.left - CHART_MARGIN.right;
}

export function getChartHeight(): number {
    return MAX_CHART_HEIGHT - CHART_MARGIN.top - CHART_MARGIN.bottom;
}

export function getGoalTenureData(goal): IGoalTenureData | undefined {
    const goalType = getGoalTypeByGoal(goal);
    const { plan_start_retirement, end_on_date, start_first_withdrawal, last_withdrawal } = goal;
    if (goalType === GOAL_TYPES.TENURE) {
        if (start_first_withdrawal) {
            const startYear = Number(getYearFromDateString(start_first_withdrawal));
            const endYear = Number(getYearFromDateString(last_withdrawal));

            const tenure = endYear - startYear;

            return { startYear, endYear, tenure };
        } else if (plan_start_retirement) {
            const startYear = Number(getYearFromDateString(plan_start_retirement));
            const endYear = Number(getYearFromDateString(end_on_date));

            const tenure = endYear - startYear;

            return { startYear, endYear, tenure };
        }
    }
}

export function getGoalWidthOnChartByTenure(
    tenure: number,
    xValuesLength: number,
    chartWidth?: number,
    isZoomed?: boolean
): number {
    let xAxisValueGap = CHART_X_AXIS_VALUE_GAP;

    if (chartWidth) {
        xAxisValueGap = getChartXAxisValueGap(chartWidth, xValuesLength, isZoomed);
    }

    return xAxisValueGap * tenure;
}

export function getScalesNDomainsForChartByData(
    data: Array<IChartData>,
    selectedGoalData?: IGoalData,
    chartWidth: number = RENDERABLE_CHART_WIDTH
): [ID3ScaleMethod, ID3ScaleMethod, IChartDomain, IChartDomain] {
    const xDomains: IChartDomain = getXDomains(data, selectedGoalData);
    const yDomains: IChartDomain = getYDomains(data);
    const chartHeight = getChartHeight();

    const xScale: ID3ScaleMethod = d3
        .scaleLinear()
        .domain(xDomains)
        .range([0, chartWidth - CHART_X_AXIS_START_MARGIN - CHART_X_AXIS_TICK_ADJUSTMENT]);

    //Left Y-axis scale
    const yScale: ID3ScaleMethod = d3.scaleLinear().domain(yDomains).range([chartHeight, 0]).nice();

    return [xScale, yScale, xDomains, yDomains];
}

export function getChartTranslateValues() {
    const xTranslate = CHART_X_AXIS_START_MARGIN;
    const yTranslate = CHART_MARGIN.top;

    return { xTranslate, yTranslate };
}

export function getWealthRecommendations(addedGoalList, basicInfo): Promise<any> {
    return wealthSplitterController(addedGoalList, basicInfo).then((response) => {
        const wealthData = response.body.goalResponseList.map((gs) => {
            const goalData = addedGoalList.filter((g) => g["goal-key"] == gs.goalId)[0];
            return {
                name: gs.goal,
                initialInput: gs.origCurrWealth,
                suggested: gs.wealthSplit,
                recommendation: gs.wealthSplit - gs.origCurrWealth,
                priority: goalData["goal_priority"],
                tenure: goalData["tenure"],
                fundStatus: gs.fundedStatus,
                goalId: gs.goalId,
            };
        });

        return wealthData;
    });
}

export async function getX(addedGoalList, wealthRecommendations, basicInfo) {
    const runPipeCalls: any = [];
    const runPipeCallsGeneratepayloadonly: any = [];
    const runPipeGoalsKeys: any = [];

    for (let i = 0; i < addedGoalList.length; i++) {
        runPipeGoalsKeys.push(addedGoalList[i]["goal-key"]);
        const goalDetails = addedGoalList[i];
        const recommendation: any = wealthRecommendations.filter((rc: any) => {
            return rc.goalId == goalDetails["goal-key"];
        });
        if (recommendation && recommendation.length) {
            // goalDetails initialWealth= recommendation.suggested
            goalDetails["initial_investment"] = recommendation[0].suggested;
        }

        const [runPipePromise, runPipePromiseGeneratepayloadonly] = await Promise.all([
            runPipeController(goalDetails, basicInfo, false, false, 0),
            runPipeController(addedGoalList[i], basicInfo, true, false, 0),
        ]);

        runPipeCalls.push(runPipePromise);
        runPipeCallsGeneratepayloadonly.push(runPipePromiseGeneratepayloadonly);
    }

    const goalWealthReports = {};
    const goalWealthReportsGeneratepayloadonly = {};

    const res = await Promise.all(runPipeCalls);
    const resGeneratepayloadonly = await Promise.all(runPipeCallsGeneratepayloadonly);
    await Promise.all(
        res.map((r, i) => {
            goalWealthReports[runPipeGoalsKeys[i]] = r.body;
            return r.body;
        })
    );

    await Promise.all(
        resGeneratepayloadonly.map((r, i) => {
            goalWealthReportsGeneratepayloadonly[runPipeGoalsKeys[i]] = r.body;
            return r.body;
        })
    );

    return { goalWealthReports, goalWealthReportsGeneratepayloadonly };
}

export function ChartData(this: IChartData, x, y, xKeyName = "year", yKeyName = "value") {
    this[xKeyName] = x;
    this[yKeyName] = y;
}

export function checkZoomFeaturedEnabled(componentName: string): boolean {
    return ZOOM_FEATURE_ENABLED_COMPONENTS.includes(componentName);
}

export function getChartXAxisValueGap(chartWidth: number, xValuesLength: number, isZoomed = false): number {
    const gap = chartWidth / xValuesLength;

    if (isZoomed) {
        return gap + 2.2;
    }

    return gap + 0.5;
}

export function getWealthPathDataByAllData(goalWealthReportAllData): Array<number> {
    const data: Array<number> = [];

    for (const key in goalWealthReportAllData) {
        const {
            pathReport: { wealthPath },
        } = goalWealthReportAllData[key];

        wealthPath.forEach((wealth, index) => {
            data[index] = data[index] ? data[index] + wealth : wealth;
        });
    }

    return data;
}
export const getgoalLabels = (goalItem) => {
    const goalLabels = {
        yearly_withdrawal: goalItem["goal_key"] === "draw_income" ? "Yearly withdrawal" : "Goal Value",
        ret_date:
            goalItem["goal_key"] === "draw_income"
                ? "Beginning"
                : goalItem["goal_key"] === "plan_retirement"
                ? "Retirement date"
                : "Goal date",
        analysisReport_oneTimeTopUp:
            goalItem["goal_key"] === "draw_income" ? "Add a one-time lumpsum" : "Add a one-time lumpsum",
        analysisReport_yearlyTopUpAccumulation:
            goalItem["goal_key"] === "draw_income" ? "Save more (yearly)" : "Save more (yearly)",
        analysisReport_yearlyTopUpDecumulation:
            goalItem["goal_key"] === "draw_income" ? "Reduce yearly withdrawals" : "Spend less (yearly)",
        analysisReport_MonthlyTopUpAccumulation:
            goalItem["goal_key"] === "draw_income" ? "Save more (monthly)" : "Save more (monthly)",
        analysisReport_MonthlyTopUpDecumulation:
            goalItem["goal_key"] === "draw_income" ? "Reduce monthly withdrawals" : "Spend less (monthly)",
        analysisReport_recommendedTenure:
            goalItem["goal_key"] === "draw_income"
                ? "Reduce spend down time"
                : goalItem["goal_key"] === "plan_retirement"
                ? "Delay Retirement"
                : "Delay the goal",
    };
    return goalLabels;
};

export const digitFromator = (labelValue) => {
    // Nine Zeroes for Billions
    return Math.abs(Number(labelValue)) >= 1.0e9
        ? (Math.abs(Number(labelValue)) / 1.0e9).toFixed(2) + "B"
        : // Six Zeroes for Millions
        Math.abs(Number(labelValue)) >= 1.0e6
        ? (Math.abs(Number(labelValue)) / 1.0e6).toFixed(2) + "M"
        : // Three Zeroes for Thousands
        Math.abs(Number(labelValue)) >= 1.0e3
        ? (Math.abs(Number(labelValue)) / 1.0e3).toFixed(2) + "K"
        : Math.abs(Number(labelValue)).toFixed(2);
};
export const formatDollar = (dollarValue, is_dollar) => {
    // const USDollar = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
    if (is_dollar && dollarValue && typeof dollarValue !== "number") {
        // return Number(dollarValue.replace(/[$,]/g, ""));
        return "$" + digitFromator(dollarValue.replace(/[$,]/g, "")).replace(".00", "");
    }
    return "$" + digitFromator(dollarValue).replace(".00", "");
};
