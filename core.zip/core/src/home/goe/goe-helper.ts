export const parseOptions = (data) => {
    if (!data) return [];

    const options = data.map((item) => {
        const option = { value: item.description, key: item.name };
        return option;
    });
    return options;
};

export const parseOptionsForPortfolio = (data, isFtPortfolio = false) => {
    if (!data) return [];

    const parsedData = data.filter((item) => {
        return item.isFtPortfolio === isFtPortfolio;
    });

    const options = parsedData.map((item, index) => {
        const option = { id: index + 1, value: item.name, key: item.name };
        return option;
    });
    return options;
};

export const extractDisplayablePortfolioList = (portfolios = [], val) => {
    const newPortfolioBundle = [...portfolios];
    const displayBundle: any = [];
    newPortfolioBundle.map((item: any) => {
        if (val !== item.riskOn) {
            return 0;
        }
        let portfolioObject = {
            ...item,
        };
        const assetAllocations = item.assetAllocations.map((asset) => ({
            name: { value: asset.name, key: asset.name },
            value: asset.weightPercent,
        }));
        portfolioObject = { ...portfolioObject, assetAllocations };
        return displayBundle.push(portfolioObject);
    });
    return displayBundle;
};

export const getPortfolioOptionsForSwingConstraints = (portfolios) => {
    const portfolioOptions: any = [];
    portfolios &&
        portfolios.map((item) => {
            if (item.riskOn) {
                portfolioOptions.push({ value: item.id, key: item.id });
            }
            return 0;
        });
    return portfolioOptions;
};

export const getLossThresholdValues = (index, goalLevel) => {
    const lossThresholdValues = [
        [
            {
                id: 1,
                key: "need",
                label: "NEED",
                percent: true,
            },
            {
                id: 2,
                key: "want",
                label: "WANT",
                percent: true,
            },
            {
                id: 3,
                key: "wish",
                label: "WISH",
                percent: true,
            },
            {
                id: 4,
                key: "dream",
                label: "DREAM",
                percent: true,
            },
            {
                id: 5,
                key: "desire",
                label: "DESIRE",
                percent: true,
            },
        ],
        [
            {
                id: 1,
                key: "need",
                label: "NEED",
                percent: true,
            },
            {
                id: 2,
                key: "want",
                label: "WANT",
                percent: true,
            },
            {
                id: 3,
                key: "wish",
                label: "WISH",
                percent: true,
            },
            {
                id: 4,
                key: "dream",
                label: "DREAM",
                percent: true,
            },
            {
                id: 5,
                key: "desire",
                label: "DESIRE",
                percent: true,
            },
        ],
    ];

    return lossThresholdValues[index].slice(0, goalLevel);
};

export const parseActuarialNameOptions = (data) => {
    if (!data) return [];

    const options = data.map((item) => {
        const option = { value: item.name, key: item.name };
        return option;
    });
    return options;
};

export const extractBundleIds = (portfolios = [], val) => {
    const ids: any = [];
    portfolios?.map((item: any) => {
        if ((item?.riskOn || true) === val) ids.push(item?.id);
        return 0;
    });
    return ids;
};

const riskLevelProfilesOnly = {
    1: ["defaultRiskProfiles"],
    3: ["conservativeRiskProfiles", "moderateRiskProfiles", "aggressiveRiskProfiles"],
    5: [
        "conservativeRiskProfiles",
        "conservativelyModerateRiskProfiles",
        "moderateRiskProfiles",
        "moderatelyAggressiveRiskProfiles",
        "aggressiveRiskProfiles",
    ],
    7: [
        "veryConservativeRiskProfiles",
        "conservativeRiskProfiles",
        "conservativelyModerateRiskProfiles",
        "moderateRiskProfiles",
        "moderatelyAggressiveRiskProfiles",
        "aggressiveRiskProfiles",
        "veryAggressiveRiskProfiles",
    ],
};

export const checkIfAllRiskValuesEntered = (riskLevel, portfolioConfig) => {
    let hasEnteredAll = true;
    for (let i = 0; i < riskLevelProfilesOnly[riskLevel].length; i++) {
        const currentIndex = riskLevelProfilesOnly[riskLevel][i];
        if (
            !portfolioConfig[currentIndex].upperLimit ||
            (currentIndex !== "defaultRiskProfiles" && !portfolioConfig[currentIndex].labelValue)
        ) {
            hasEnteredAll = false;
            break;
        }
    }

    return hasEnteredAll;
};

export const checkActuarialSelected = (actuarialData) => {
    let flag = false;
    if (actuarialData)
        for (let i = 0; i < actuarialData.length; i++) {
            if (!actuarialData[i].valueTwo) {
                flag = true;
                break;
            }
        }
    return flag;
};

export const checkAggregatedRetirementAccountsSelected = (actuarialData, selectedAggRetirementAccounts) => {
    let flag = false;
    let portfolioMappingSelected = false;
    if (actuarialData)
        for (let i = 0; i < actuarialData.length; i++) {
            if (actuarialData[i].key === "PortfolioMapAggRetirementAccounts-H") {
                portfolioMappingSelected = true;
                break;
            }
        }
    if (selectedAggRetirementAccounts === true && !portfolioMappingSelected) {
        flag = true;
    }
    return flag;
};

export const getNextIntervalDate = (val, interval) => {
    const month = new Date(val).getMonth() + interval;
    const date = new Date(val).getDate();
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const displayDate = new Date(currentYear, month, date);
    const displayDateString = displayDate.toString().slice(0, 15);
    return displayDateString;
};

export const checkDatesInterval = (reallocationDatesByFrequency) => {
    const reallocationDatesByFrequencyClone = JSON.parse(JSON.stringify(reallocationDatesByFrequency));
    let defaultDatesArr: any = [];

    for (const key in reallocationDatesByFrequencyClone) {
        for (let i = 0; i < reallocationDatesByFrequencyClone[key].length; i++) {
            const interval = key === "halfyearly" ? 6 : 3;
            if (i !== 0) {
                reallocationDatesByFrequencyClone[key][i] = getNextIntervalDate(
                    reallocationDatesByFrequencyClone[key][i - 1],
                    interval
                );
            }
        }
        const dates = reallocationDatesByFrequencyClone[key].map((item) => item);
        defaultDatesArr = [...defaultDatesArr, ...dates];
    }

    let clientDates: any = [];
    for (const key in reallocationDatesByFrequency) {
        const dates = reallocationDatesByFrequency[key].map((item) => item);
        clientDates = [...clientDates, ...dates];
    }
    const isEqual =
        Array.isArray(defaultDatesArr) &&
        Array.isArray(clientDates) &&
        defaultDatesArr?.length === clientDates?.length &&
        defaultDatesArr?.every((val, index) => val === clientDates[index]);
    if (!isEqual) {
        return true;
    }
    return false;
};

function get(object, path, value?: any) {
    if (typeof path != "string") {
        path = path + "";
    }
    const pathArray = Array.isArray(path) ? path : path.split(".").filter((key) => key);
    const pathArrayFlat = pathArray.flatMap((part) => (typeof part === "string" ? part.split(".") : part));
    const checkValue = pathArrayFlat.reduce((obj, key) => obj && obj[key], object);
    return checkValue === undefined ? value : checkValue;
}

const extractDataFromSelectGroup = (keyValuePairs, data, divide = false) => {
    const obj = {};
    keyValuePairs.map((item) => {
        const name = get(item, "name", "error");
        if (divide) obj[name] = get(data, item.accessKey, 0) / 100;
        else obj[name] = get(data, item.accessKey, "");
        return 0;
    });
    return obj;
};

const extractDataFromSwitchGroup = (keyValuePairs, data, divide = false) => {
    const obj: any = [];
    keyValuePairs.map((item) => {
        const name = get(item, "name", "error");
        let value = 0;
        if (divide) value = get(data, item.accessKey, 0) / 100;
        else value = get(data, item.accessKey, "");
        obj.push({ name, value });
        return 0;
    });
    return obj;
};

export const extractDataFromObject = (config, data) => {
    const dataObject = {};
    config.map((item) => {
        if (item.conditionalExtract) {
            const { dependency, dependentValue } = item;
            const dependentItemValue = get(data, dependency, "");
            if (dependentItemValue !== dependentValue) {
                return 0;
            }
        }
        switch (item.type) {
            case "text":
                dataObject[item.name] = get(data, item.accessKey, "");
                return 0;
            case "percent":
                dataObject[item.name] = get(data, item.accessKey, 0) / 100;
                return 0;
            case "number": {
                const value = get(data, item.accessKey);
                dataObject[item.name] = value ? Number(value) : value;
                return 0;
            }
            case "selectGroup": {
                const selectGroupObj = get(data, item.accessKey, {});
                const selectGroupKeyValue = get(item, "keyValuePairs", []);
                dataObject[item.name] = extractDataFromSelectGroup(selectGroupKeyValue, selectGroupObj);
                return 0;
            }
            case "selectGroupPercent": {
                const selectGroupObj = get(data, item.accessKey, {});
                const selectGroupKeyValue = get(item, "keyValuePairs", []);
                dataObject[item.name] = extractDataFromSelectGroup(selectGroupKeyValue, selectGroupObj, true);
                return 0;
            }
            case "switchGroup": {
                const switchGroupKeyValue = get(item, "keyValuePairs", []);
                dataObject[item.name] = extractDataFromSwitchGroup(switchGroupKeyValue, data);
                return 0;
            }
            case "sliderGroup": {
                const sliderGroupKeyValue = get(item, "keyValuePairs", []);
                dataObject[item.name] = extractDataFromSwitchGroup(sliderGroupKeyValue, data, true);
                return 0;
            }
            case "sliderGroupWithLabel": {
                const dataObj = get(data, item.accessKey, {});
                const arr: any = [];
                for (const key in dataObj) {
                    if (dataObj[key].labelValue) {
                        const obj = {};
                        obj["name"] = dataObj[key].labelValue;
                        obj["value"] = dataObj[key].value / 100;
                        if ("val" in dataObj[key]) {
                            obj["min"] = Number((dataObj[key].val / 100).toFixed(2));
                        }
                        arr.push(obj);
                    }
                }
                dataObject[item.name] = arr;
                return 0;
            }
            case "columnarInput": {
                const dataObj = get(data, item.accessKey, {});
                const arr: any = [];
                for (const key in dataObj) {
                    if (dataObj[key]) {
                        const obj = {};
                        obj["labelValue"] = dataObj[key].labelValue / 100;
                        obj["value"] = dataObj[key].value / 100;
                        obj["val"] = dataObj[key].val ? Number(dataObj[key].val) : dataObj[key].val;
                        arr.push(obj);
                    }
                }
                dataObject[item.name] = arr;
                return 0;
            }
            case "rangeTextGroup": {
                const rangeTextObject = get(data, item.accessKey, {});
                const returnArr: any = [];
                const iterOver = rangeTextObject?.accumulation
                    ? rangeTextObject.accumulation
                    : rangeTextObject.mingipercent;
                for (const key in iterOver) {
                    const obj: any = {};
                    const labelValue = iterOver[key].labelValue;
                    if (labelValue) {
                        obj["name"] = iterOver[key].labelValue;
                        if (rangeTextObject.accumulation) {
                            obj["accumulation"] = iterOver[key].value / 100;
                        }
                        if (rangeTextObject.decumulation) {
                            obj["decumulation"] = rangeTextObject.decumulation[key].value / 100;
                        }
                        if (rangeTextObject.mingipercent) {
                            obj["mingipercent"] = rangeTextObject.mingipercent[key].value / 100;
                        }
                        returnArr.push(obj);
                    }
                }
                dataObject[item.name] = returnArr;
                return 0;
            }
            case "customRadio": {
                const boolVariable = get(data, item.accessKey, "");
                if (boolVariable) {
                    dataObject[item.name] = get(item, "onTrue", true);
                } else {
                    dataObject[item.name] = get(item, "onFalse", false);
                }
                return 0;
            }
            case "general": {
                const generalConfig = get(item, "keyValuePairs", []);
                dataObject[item.name] = extractDataFromObject(generalConfig, data);
                return 0;
            }
            default:
                return 0;
        }
    });
    return dataObject;
};

const extractActuarials = (values) => {
    const res: any = [];
    if (values && values.length) {
        values.forEach((item) => {
            res.push({ name: item.valueTwo, type: item.value });
        });
    }
    return res;
};

const extractDeriskData = (values) => {
    const res: any = [];
    if (values && values.length) {
        values.forEach((item) => {
            res.push({ age: item.value, portfolio: item.valueTwo });
        });
    }
    return res;
};

const riskLevelProfiles = {
    1: [
        "defaultRiskProfiles",
        "shortTermGoalProfiles",
        "decumulationScenarioProfiles",
        "shortTermRetirementGoalProfiles",
    ],
    3: [
        "conservativeRiskProfiles",
        "moderateRiskProfiles",
        "aggressiveRiskProfiles",
        "shortTermGoalProfiles",
        "decumulationScenarioProfiles",
        "shortTermRetirementGoalProfiles",
    ],
    5: [
        "conservativeRiskProfiles",
        "conservativelyModerateRiskProfiles",
        "moderateRiskProfiles",
        "moderatelyAggressiveRiskProfiles",
        "aggressiveRiskProfiles",
        "shortTermGoalProfiles",
        "decumulationScenarioProfiles",
        "shortTermRetirementGoalProfiles",
    ],
    7: [
        "veryConservativeRiskProfiles",
        "conservativeRiskProfiles",
        "conservativelyModerateRiskProfiles",
        "moderateRiskProfiles",
        "moderatelyAggressiveRiskProfiles",
        "aggressiveRiskProfiles",
        "veryAggressiveRiskProfiles",
        "shortTermGoalProfiles",
        "decumulationScenarioProfiles",
        "shortTermRetirementGoalProfiles",
    ],
};

const resetPortfolioConfig = (config, riskLevel) => {
    const configClone = { ...config };
    for (const key in config) {
        const riskLevelValidator = riskLevelProfiles[riskLevel].includes(key);
        if (!config[key] || !riskLevelValidator) {
            configClone[key] = {
                lowerLimit: null,
                upperLimit: null,
            };
        }
    }
    return configClone;
};

const formatKeyToPascal = (key) => {
    switch (key) {
        case "veryConservativeRiskProfiles":
            return "VeryConservative";
        case "conservativeRiskProfiles":
            return "Conservative";
        case "conservativelyModerateRiskProfiles":
            return "ConservativelyModerate";
        case "moderateRiskProfiles":
            return "Moderate";
        case "moderatelyAggressiveRiskProfiles":
            return "ModeratelyAggressive";
        case "aggressiveRiskProfiles":
            return "Aggressive";
        case "veryAggressiveRiskProfiles":
            return "VeryAggressive";
        default:
            return "Default";
    }
};

const mapConfigToPortfolioIds = (ids, riskOffIds, portfolioConfig) => {
    const pfConfig = get(portfolioConfig, "portfolioConfig", {});
    const newPortfolioConfig = { ...pfConfig };
    Object.keys(newPortfolioConfig).map((item) => {
        const innerObject = get(newPortfolioConfig, item, {});
        const itemArray: any = [];
        const lower = get(innerObject, "lowerLimit", null);
        const upper = get(innerObject, "upperLimit", null);
        if (lower !== null && upper !== null && lower <= upper) {
            for (let i = lower; i <= upper; i += 1) {
                const id = get(ids, i - 1, null);
                if (id !== null) itemArray.push(id);
            }
            if (riskOffIds.length !== 0) {
                for (let i = lower; i <= upper; i += 1) {
                    const id = get(riskOffIds, i - 1, null);
                    if (id !== null) itemArray.push(id);
                }
                if (upper === null) {
                    const id = get(riskOffIds, lower - 1, null);
                    if (id !== null) itemArray.push(id);
                }
                if (lower === null) {
                    const id = get(riskOffIds, upper - 1, null);
                    if (id !== null) itemArray.push(id);
                }
            }
        }
        if (upper === null) {
            const id = get(ids, lower - 1, null);
            if (id !== null) itemArray.push(id);
        }
        if (lower === null) {
            const id = get(ids, upper - 1, null);
            if (id !== null) itemArray.push(id);
        }
        newPortfolioConfig[item] = itemArray;
        return 0;
    });
    return { ...portfolioConfig, portfolioConfig: newPortfolioConfig };
};

export const parseFormData = (data, generalSettingsKeys, ids, riskOffIds) => {
    if (data?.risk_indicator_flag_value && Object.keys(data?.risk_indicator_flag_value)) {
        const res = {
            lower: Number(data.risk_indicator_flag_value.lower),
            upper: Number(data.risk_indicator_flag_value.upper),
        };
        data.risk_indicator_flag_value = res;
    }
    const config: any = {};

    config.portfolioConfig = extractDataFromObject(get(generalSettingsKeys, "portfolioConfig", []), data);

    config.allocationConfiguration = extractDataFromObject(
        get(generalSettingsKeys, "allocationConfiguration", []),
        data
    );

    config.goalPriority = extractDataFromObject(get(generalSettingsKeys, "goalPriority", []), data);

    //extracting actuarials
    config.goalPriority.generalSettings.actuarials = extractActuarials(data.actuarialData);
    config.goalPriority.generalSettings.taxActuarialData = extractActuarials(data.taxActuarialData);
    config.goalPriority.generalSettings.derisking = extractDeriskData(data.deriskingPortfolios);
    config.goalPriority.generalSettings.LYTargetAllocations = extractDeriskData(data.LYTargetAllocations);
    config.goalPriority.generalSettings.LYCMEPackage = extractDeriskData(data.LYCMEPackage);

    // Hardcoding initialWealth
    config.goalPriority.generalSettings.recommendInitialWealth = false;
    config.configuration = get(data, "select_configuration", "");
    config.goalLevel = get(data, "select_goal_level", "");

    // WealthpathProbability
    config.goalPriority.generalSettings.wealthPathProbability =
        get(data, "wealth_path_probability", "") === "" ||
        get(data, "wealth_path_probability", "") === null ||
        get(data, "wealth_path_probability", "") === undefined ||
        get(data, "wealth_path") === "PriorityBased"
            ? null
            : get(data, "wealth_path_probability", "") / 100;

    // Resetting portfolioConfig based on risk level
    config.portfolioConfig.portfolioConfig = resetPortfolioConfig(
        config.portfolioConfig.portfolioConfig,
        config.portfolioConfig.level
    );

    // for (const key in config.portfolioConfig.portfolioConfig) {
    //     if (!config.portfolioConfig.portfolioConfig[key].upperLimit) {
    //     //     config.portfolioConfig.portfolioConfig[key].lowerLimit = 1;
    //     // } else {
    //         config.portfolioConfig.portfolioConfig[key].lowerLimit = null;
    //     }
    // }

    const portfolioMapping = {};
    for (const key in config.portfolioConfig.portfolioConfig) {
        const labelValue = config.portfolioConfig.portfolioConfig[key].labelValue;
        const upperLimit = config.portfolioConfig.portfolioConfig[key].upperLimit;
        if (labelValue && upperLimit) {
            portfolioMapping[labelValue] = formatKeyToPascal(key);
        }
    }

    config.portfolioConfig = mapConfigToPortfolioIds(ids, riskOffIds, config.portfolioConfig);

    config.portfolioConfig["portfolioMapping"] = portfolioMapping;
    config.portfolioConfig["shortTermGoalTenure"] = Number(data["tenure_years"]);
    config.portfolioConfig["shortTermRetirementGoalTenure"] =
        data["tenureForShortTerm"]["shortTermRetirementGoalTenure"];
    config.portfolioConfig["shortTermRetirementGoalTenureUnengaged"] =
        data["tenureForShortTerm"]["shortTermRetirementGoalTenureUnengaged"];

    const lossthresholdValues = [
        { name: "need", accumulation: 0.05, decumulation: 0.5 },
        { name: "want", accumulation: -0.01, decumulation: 0.25 },
        { name: "wish", accumulation: 0.8, decumulation: 0 },
        { name: "dream", accumulation: 0.6, decumulation: 0 },
        { name: "desire", accumulation: 0.4, decumulation: 0 },
    ];

    const solvencyRiskValues = [
        { name: "need", mingipercent: 0 },
        { name: "want", mingipercent: 0.1 },
        { name: "wish", mingipercent: 0.8 },
        { name: "dream", mingipercent: 0.6 },
        { name: "desire", mingipercent: 0.4 },
    ];

    const { lossThreshold } = config.goalPriority;
    if (!lossThreshold) {
        config.goalPriority = {
            ...config.goalPriority,
            lossthresholdValues,
            solvencyRiskValues,
            lossThresholdProbability: 0.99,
        };
    }
    config.goalPriority.generalSettings.socialSecurityFilingAge = {
        minimumSocialSecurityFilingAge: data?.socialSecurityFilingAge?.minimumSocialSecurityFilingAge,
        maximumSocialSecurityFilingAge: data?.socialSecurityFilingAge?.maximumSocialSecurityFilingAge,
    };
    config.decummulationFiles = {
        additionalConsumptionCap: data?.additionalConsumptionCap,
        minConsumptionFloor: data?.minConsumptionFloor,
        maxEquityExposure: data?.maxEquityExposure,
        ageBasedAnnuityCap: data?.ageBasedAnnuityCap,
        ageBasedGICap: data?.ageBasedGICap,
    };

    const parsedData = {
        role: "CLIENT",
        name: data.customer_name,
        email: data.email,
        portfolioBundleName: data.portfolio_selection,
        phone: data.contact_phone_number?.toString(),
        segment: data.segment,
        country: data.country,
        // distributionChannel: data.distribution_channel,
        notes: data.notes,
        contactId: data.contact_id,
        contactName: data.contact_name,
        config,
        activate: true,
    };

    delete parsedData.config.goalPriority.generalSettings.actuarialName;
    delete parsedData.config.goalPriority.generalSettings.actuarialType;

    // If Grid frequency is not selected
    if (!config.goalPriority.generalSettings.gridFrequency) {
        delete parsedData.config.goalPriority.generalSettings.gridFrequency;
    }

    return parsedData;
};

export const segregateConfig = (portfolioConfig, decumulationProfile, retirementProfile) => {
    return {
        defaultRiskProfiles: portfolioConfig.defaultRiskProfiles,
        conservativeRiskProfiles: portfolioConfig.conservativeRiskProfiles,
        veryConservativeRiskProfiles: portfolioConfig.veryConservativeRiskProfiles,
        moderateRiskProfiles: portfolioConfig.moderateRiskProfiles,
        conservativelyModerateRiskProfiles: portfolioConfig.conservativelyModerateRiskProfiles,
        moderatelyAggressiveRiskProfiles: portfolioConfig.moderatelyAggressiveRiskProfiles,
        aggressiveRiskProfiles: portfolioConfig.aggressiveRiskProfiles,
        veryAggressiveRiskProfiles: portfolioConfig.veryAggressiveRiskProfiles,
        shortTermGoalProfiles: portfolioConfig.shortTermGoalProfiles,
        decumulationScenarioProfiles: decumulationProfile.decumulationScenarioProfiles,
        shortTermRetirementGoalProfiles: retirementProfile.shortTermRetirementGoalProfiles,
    };
};
