import React, { useEffect, useState } from "react";
import makeStyles from "@mui/styles/makeStyles";
import { useForm } from "react-hook-form";
import Api from "utils/api";
import { AdornedButton } from "common/FTButtons";
import errorNotification from "utils/api-error";
import Typography from "@mui/material/Typography";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Paper from "@mui/material/Paper";
import { MuiForm } from "common/mui-form/MuiForm";
import { HChart } from "common/HChart";
import moment from "moment";
import AppCover from "home/dashboad/AppCover";
import Loader from "common/Loader";

import { defaultFormData, defaultFormConfig, chartConfigs, tabs } from "./aus-ret-config";
import { useScreenshot } from "utils/helpers";

const useStyles = makeStyles(() => ({
    tab: {
        textTransform: "capitalize",
        fontSize: "1.15rem",
    },
    container: {
        display: "flex",
        alignItems: "flex-start",
        flexDirection: "row",
        justifyContent: "flex-start",
        width: "100%",
    },
    formBase: {
        width: "25%",
        height: "100%",
        padding: "0 12px",
        borderRight: "2px solid grey",
    },
    btnBase: {
        marginTop: "16px",
        display: "flex",
        justifyContent: "center",
        marginBottom: "10px",
    },
    inputform: {
        paddingLeft: "20px",
        display: "flex",
        width: "100%",
        flexDirection: "row",
        flexFlow: "row wrap",
    },
    reportBase: {
        width: "75%",
        paddingLeft: "30px",
    },
    formLabel: {
        color: "#9b9ba3",
        fontSize: "15px",
        fontWeight: 600,
        marginBottom: "1px",
    },
    pieChartRep: {
        width: "100%",
        marginTop: "20px",
        display: "flex",
        flexFlow: "row wrap",
        alignItems: "center",
    },
    btn: {
        textTransform: "capitalize",
    },
    centerAlignField: {
        alignItems: "center",
        display: "flex",
        flexDirection: "column",
        width: "100%",
    },
}));

function transformData(data) {
    const result = {};
    Object.keys(chartConfigs).forEach((key) => {
        const config = chartConfigs[key] || {};
        const reportData = data[key];
        if (key == "retirement_income") {
            config.xAxis.categories = [...(reportData.find((ele) => ele.id == "age")?.data || [])];
            config.series = config.series.map((series) => {
                const seriesData = reportData.find((ele) => ele.id == series.id)?.data;
                return { ...series, data: seriesData || [] };
            });
        } else if (key == "wealth") {
            const seriesData = reportData?.[0]?.data || [];
            config.xAxis.categories = [...(seriesData?.map((rp) => rp?.Age) || [])];
            config.series = [
                {
                    ...config.series[0],
                    data: seriesData?.map((rp) => rp?.Wealth),
                },
            ];
        } else if (key == "asset_allocation") {
            const seriesData = data["asset_allocation"].find((rp) => rp.id == "asset_allocation")?.data || {};
            config.series = [
                {
                    ...config.series[0],
                    data: Object.keys(seriesData).map((key) => ({ name: key, y: seriesData[key] })),
                },
            ];
        } else if (key == "portfolio_composition") {
            const seriesData = data["asset_allocation"].find((rp) => rp.id == "portfolio_composition")?.data || {};
            config.series = [
                {
                    ...config.series[0],
                    data: Object.keys(seriesData).map((key) => ({ name: key, y: seriesData[key] })),
                },
            ];
        } else if (key == "portfolio") {
            const rpData = reportData?.[0]?.data || [];
            config.subtitle.text = `Probability of reaching the goal<br/> <b style="font-size: 20px;">${data?.probability_of_reaching_goal}</b>`;
            config.series = [
                {
                    ...config.series[0],
                    data: rpData.map((ele) => [ele.Age, ele.Portfolio]),
                },
            ];
        }
        result[key] = config;
    });
    return result;
}

// function isValidAge(date) {
//     const diff = moment().diff(moment(date), "years");
//     return diff >= 65 && diff <= 99;
// }

function TopAlignedLabelForm({ classes, config, methods }) {
    return (
        <div style={{ marginTop: "5px", width: config?.width || "50%" }}>
            {!["heading"].includes(config?.type) && (
                <div className={classes.formLabel}>
                    {config?.displayTextOnly ? config?.displayTextOnlyLabel : config.label}
                </div>
            )}
            <div style={{ paddingLeft: "6px" }}>
                <MuiForm key={config.key} field={config} methods={methods} />
            </div>
        </div>
    );
}

export default function AustralianRetirementCalculator() {
    const classes = useStyles();
    const methods = useForm<any>({ mode: "onChange", defaultValues: defaultFormData });
    const [reportsInfo, setReportsInfo] = useState<any>({ isLoading: true });
    const [formConfig] = useState<any>(defaultFormConfig || []);
    const [currTabInfo, setCurrTabInfo] = useState<any>({ ...tabs[0] });
    const screenshot = useScreenshot();

    const gender = methods.watch("gender");
    const home_owner = methods.watch("home_owner");
    const date_of_birth = methods.watch("date_of_birth");
    const risk_profile = methods.watch("risk_profile");
    const current_super_balance = methods.watch("current_super_balance");
    const other_income = methods.watch("other_income");
    const other_assets = methods.watch("other_assets");
    const optimize_retirement_income = methods.watch("optimize_retirement_income");

    function generatePayload(values) {
        values.date_of_birth = moment(values.date_of_birth).format("DD-MM-YYYY");
        delete values?.optimize_retirement_income_value;
        return values;
    }

    useEffect(() => {
        if (optimize_retirement_income === "Yes") {
            const values = methods.getValues();
            const payload = generatePayload(values);
            Api.genrateAusRetIncome({ ...payload, optimize_retirement_income: "Yes" })
                .then((response) => {
                    if (response.statusCode === 400) {
                        errorNotification.next({ type: "error", text: response?.body || "Failed", open: true });
                        return;
                    }
                    if (response?.body) {
                        const value = response?.body?.optimized_retirement_income;
                        methods?.setValue("optimize_retirement_income_value", value);
                        methods?.setValue("desired_retirement_income", value);
                    }
                    screenshot.take();
                })
                .catch((err) => {
                    const resp = err?.response?.data || {};
                    if (resp.statusCode === 400) {
                        errorNotification.next({ type: "error", text: resp?.body || "Failed", open: true });
                        return;
                    }
                });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        gender,
        optimize_retirement_income,
        home_owner,
        date_of_birth,
        risk_profile,
        current_super_balance,
        other_income,
        other_assets,
    ]);

    useEffect(() => {
        if (optimize_retirement_income === "No") {
            methods?.setValue("optimize_retirement_income_value", "");
            methods?.setValue("desired_retirement_income", defaultFormData?.desired_retirement_income);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [optimize_retirement_income]);

    const handleChange = (event, newValue) => {
        const tabInfo = tabs.find((tab) => tab.id == newValue) || {};
        setCurrTabInfo({ ...tabInfo });
    };

    const handler = () => {
        methods.handleSubmit(
            (data) => {
                // if (!isValidAge(data.date_of_birth)) {
                //     errorNotification.next({ type: "error", text: "Age must be between 65 and 99", open: true });
                //     return;
                // }
                setReportsInfo({ isLoading: true, btnLoading: true });
                const payload = generatePayload(data);
                Api.runAusRetCalculator(payload)
                    .then((response) => {
                        if (response.statusCode === 400) {
                            errorNotification.next({ type: "error", text: response?.body || "Failed", open: true });
                            setReportsInfo({ ...reportsInfo, btnLoading: false });
                        } else if (response?.body) {
                            setReportsInfo({ ...transformData(response?.body), isLoading: false, btnLoading: false });
                        }
                    })
                    .catch((err) => {
                        setReportsInfo((rpInfo) => ({ ...rpInfo, btnLoading: false }));
                        const resp = err?.response?.data || {};
                        if (resp.statusCode === 400) {
                            errorNotification.next({ type: "error", text: resp?.body || "Failed", open: true });
                            return;
                        }
                    });
            },
            (err) => {
                console.log("ERR", err);
            }
        )();
    };

    const panelStyle: any = { display: "block", height: "calc(100vh - 170px)", overflowY: "auto" };

    return (
        <AppCover>
            <div className={classes.container}>
                <div className={classes.formBase} style={panelStyle}>
                    <Typography style={{ color: "#616161" }} align="left" component="div" variant="h6">
                        {" "}
                        Customer Details{" "}
                    </Typography>
                    <div className={classes.inputform}>
                        {formConfig?.map((config) => {
                            return (
                                <TopAlignedLabelForm
                                    key={config.key}
                                    classes={classes}
                                    config={config}
                                    methods={methods}
                                />
                            );
                        })}
                    </div>
                    <div className={classes.btnBase}>
                        <AdornedButton
                            className={classes.btn}
                            variant="contained"
                            color="primary"
                            onClick={handler}
                            loading={reportsInfo?.btnLoading}
                        >
                            Generate Results
                        </AdornedButton>
                    </div>
                </div>
                <div className={classes.reportBase} style={{ ...panelStyle, padding: "0 30px" }}>
                    {reportsInfo.btnLoading ? (
                        <Loader />
                    ) : (
                        <>
                            {!reportsInfo?.isLoading && (
                                <>
                                    <Paper square style={{ marginTop: "20px" }}>
                                        <Tabs
                                            value={currTabInfo.id}
                                            indicatorColor="primary"
                                            textColor="primary"
                                            color="default"
                                            onChange={handleChange}
                                        >
                                            {tabs?.map((tab: any) => (
                                                <Tab
                                                    key={tab.id}
                                                    className={classes.tab}
                                                    value={tab.id}
                                                    label={tab.label}
                                                />
                                            ))}
                                        </Tabs>
                                    </Paper>
                                    {currTabInfo?.id === "asset_allocation" ? (
                                        <div className={classes.pieChartRep}>
                                            <Typography
                                                style={{ width: "100%", color: "#616161", fontWeight: 600 }}
                                                align="left"
                                                component="div"
                                                variant="h6"
                                            >
                                                {" "}
                                                Initial Asset Allocation{" "}
                                            </Typography>
                                            <div style={{ width: "30%", marginTop: "16px" }}>
                                                <HChart
                                                    option={reportsInfo?.asset_allocation}
                                                    style={{ height: "350px" }}
                                                />
                                            </div>
                                            <div style={{ width: "70%", marginTop: "16px" }}>
                                                <HChart
                                                    option={reportsInfo?.portfolio_composition}
                                                    style={{ height: "350px" }}
                                                />
                                            </div>
                                        </div>
                                    ) : (
                                        <HChart
                                            option={reportsInfo?.[currTabInfo?.id]}
                                            style={{ height: "500px", marginTop: "20px" }}
                                        />
                                    )}
                                </>
                            )}
                        </>
                    )}
                </div>
            </div>
        </AppCover>
    );
}
