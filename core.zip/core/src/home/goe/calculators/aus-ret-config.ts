import moment from "moment";

const currDate = new Date();
export const defaultFormData = {
    gender: "Male",
    home_owner: "Y",
    date_of_birth: moment().format(`${currDate.getFullYear() - 65}-MM-01`),
    risk_profile: "Conservative",
    current_super_balance: 400000,
    other_income: 0,
    other_assets: 0,
    optimize_retirement_income: "Yes",
    desired_retirement_income: 40000,
    optimize_retirement_income_value: 0,
};

export const defaultFormConfig = [
    {
        label: "Personal Information",
        type: "heading",
        key: "client_Profile",
        width: "100%",
    },
    {
        label: "Gender",
        type: "radio",
        key: "gender",
        width: "40%",
        row: false,
        states: [
            { key: "Male", label: "Male" },
            { key: "Female", label: "Female" },
        ],
    },
    {
        label: "Date of Birth",
        type: "date",
        width: "60%",
        key: "date_of_birth",
        format: "dd-MM-yyyy",
    },
    {
        label: "Home Owner",
        type: "radio",
        width: "40%",
        key: "home_owner",
        row: false,
        states: [
            { key: "Y", label: "Y" },
            { key: "N", label: "N" },
        ],
    },
    {
        label: "Risk Profile",
        name: "risk_profile",
        type: "select",
        width: "60%",
        key: "risk_profile",
        options: [
            { key: "Conservative", value: "Conservative" },
            { key: "Moderate", value: "Moderate" },
            { key: "Aggressive", value: "Aggressive" },
        ],
    },
    {
        label: "Assets/Income",
        type: "heading",
        key: "assets_income",
        width: "100%",
    },
    {
        width: "100%",
        label: "Current Super Balance",
        name: "current_super_balance",
        type: "slider-group",
        notes: "5000000",
        key: "current_super_balance",
        min: 1000,
        max: 5000000,
        step: 100000,
    },
    {
        key: "other_income",
        type: "number-input-btn",
        width: "100%",
        step: 1000,
        label: "Any Other Income",
    },
    {
        key: "other_assets",
        type: "number-input-btn",
        step: 1000,
        width: "100%",
        label: "Other Assets",
    },
    {
        label: "Retirement Income Optimizer",
        type: "heading",
        key: "retirement_income",
        width: "100%",
    },
    {
        label: "Your optimized income is",
        type: "text",
        key: "optimize_retirement_income_value",
        width: "60%",
        disabled: true,
        position: "center",
        inputPropsStyle: {
            paddingTop: "13px",
        },
    },
    {
        label: "",
        type: "radio",
        width: "100%",
        key: "optimize_retirement_income",
        row: false,
        position: "center",
        states: [
            { key: "Yes", label: "Use optimized income" },
            { key: "No", label: "Input your desired income" },
        ],
    },
    // {
    //     label: "Help me optimize my retirement income",
    //     name: "optimize_retirement_income",
    //     type: "select",
    //     width: "100%",
    //     key: "optimize_retirement_income",
    //     options: [
    //         { key: "Yes", value: "Yes" },
    //         { key: "No", value: "No" },
    //     ],
    // },
    {
        key: "desired_retirement_income",
        type: "number-input-btn",
        width: "100%",
        step: 1000,
        label: "Please provide desired  retirement income",
        displayTextOnlyLabel: "Your optimized Income",
    },
];

export const tabs = [
    {
        id: "retirement_income",
        label: "Retirement Income",
        tab_id: 1,
    },
    {
        id: "wealth",
        label: "Wealth",
        tab_id: 2,
    },
    {
        id: "asset_allocation",
        label: "Asset Allocation",
        tab_id: 3,
    },
    {
        id: "portfolio",
        label: "Portfolio",
        tab_id: 4,
    },
];

export const retirement_income = {
    chart: {
        type: "column",
    },
    title: {
        text: "Projected Retirement Income",
        align: "left",
        style: {
            fontWeight: "bold",
        },
    },
    xAxis: {
        tickInterval: 5,
        categories: [],
        min: 0,
        dataLabels: {
            enabled: false,
        },
    },
    yAxis: {
        tickInterval: 5000,
        min: 0,
        title: {
            text: "USD$",
        },
        stackLabels: {
            enabled: false,
            style: {
                fontWeight: "bold",
                color: "gray",
            },
        },
    },
    legend: {
        align: "right",
        x: 10,
        verticalAlign: "top",
        y: 5,
        floating: true,
        backgroundColor: "white",
        itemDistance: 1,
        borderColor: "#CCC",
        borderWidth: 1,
        shadow: false,
    },
    tooltip: {
        headerFormat: "",
        // pointFormat: "{series.name}: {point.y}<br/>Total: {point.stackTotal}",
        pointFormatter: function () {
            const yAxisVal = Math.round((this as any)?.y / 1000);
            const percentage = Math.round((this as any)?.percentage);
            const total = Math.round((this as any)?.stackTotal / 1000);
            let str = `Age:${(this as any)?.category}`;
            if (yAxisVal) {
                str += `<br/>${(this as any)?.series?.name}: ${isNaN(yAxisVal) ? "" : "$" + yAxisVal + "k"}`;
            }
            if (total) {
                str += `<br/> Total: ${isNaN(total) ? "" : "$" + total + "k"}`;
            }
            if (percentage) {
                str += `<br/>Percentage: ${isNaN(percentage) ? "" : percentage + "%"}`;
            }
            return str;
        },
    },
    colors: ["rgb(17, 141, 255)", "rgb(55 83 109)", "#00e676", "grey"],
    plotOptions: {
        column: {
            stacking: "normal",
            dataLabels: {
                enabled: false,
            },
            groupPadding: 0,
            pointPadding: 0,
        },
        line: {
            marker: {
                enabled: false,
            },
        },
    },
    series: [
        {
            id: "age_pension",
            name: "Age Pension",
            data: [],
        },
        {
            id: "super_drawdown",
            name: "Super drawdown",
            data: [],
        },
        {
            id: "minimum_drawdown",
            type: "spline",
            name: "Minimum Drawdown",
            data: [],
        },
        {
            id: "retirement_income",
            type: "line",
            dashStyle: "Dash",
            name: "Retirement Income",
            data: [],
        },
    ],
};

export const wealth = {
    chart: {
        zoomType: "x",
    },
    title: {
        text: "Your wealth",
        align: "left",
        style: {
            fontWeight: "bold",
        },
    },
    subtitle: { text: null },
    xAxis: {
        tickInterval: 5,
        title: {
            text: "Age",
        },
    },
    yAxis: {
        title: {
            text: "Wealth",
        },
    },
    legend: {
        enabled: false,
    },
    tooltip: {
        headerFormat: "",
        pointFormatter: function () {
            const wealth = Math.round((this as any)?.y / 1000);
            return `Age:${(this as any)?.category} <br/> Wealth: ${isNaN(wealth) ? "" : "$" + wealth + "k"} <br/ > `;
        },
    },
    plotOptions: {
        area: {
            fillColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, "#81d4fa"],
                    [1, "#e1f5fe"],
                ],
            },
            marker: {
                radius: 0,
            },
            lineWidth: 1,
            states: {
                hover: {
                    lineWidth: 1,
                },
            },
            threshold: null,
        },
    },
    series: [
        {
            type: "area",
            name: "USD to EUR",
            data: [],
        },
    ],
};

export const asset_allocation = {
    colors: ["#10487F", "#346DA4", "#7CB5EC", "#a9cef2"],
    chart: { type: "pie" },
    title: {
        text: "Asset Allocation",
        align: "center",
        style: {
            fontWeight: "bold",
        },
    },
    subtitle: { text: null },
    tooltip: {
        pointFormat: "{series.name}: <b>{point.percentage:.0f}%</b>",
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: "pointer",
            borderColor: "#0000FF",
            dataLabels: {
                enabled: true,
                distance: -45,
                format: "{point.name}: {y} %",
            },
            showInLegend: true,
        },
    },
    series: [
        {
            name: "Asset Allocation",
            colorByPoint: true,
            innerSize: "40%",
            data: [],
        },
    ],
};

export const portfolio_composition = {
    // colors: ["#10487F", "#346DA4", "#7CB5EC", "#a9cef2"],
    colors: ["#FFEC21", "#378AFF", "#FFA32F", "#F54F52", "#93F03B", "#9552EA", "#AADEA7"],
    chart: {
        type: "pie",
    },

    title: {
        text: "Portfolio Composition",
        align: "left",
        style: {
            fontWeight: "bold",
        },
    },
    subtitle: { text: null },
    tooltip: {
        pointFormat: "{series.name}: <b>{point.percentage:.0f}%</b>",
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: "pointer",
            borderColor: "#0000FF",
            dataLabels: {
                enabled: true,
                distance: -45,
                format: "{y} %",
            },
            center: ["20%"],
            showInLegend: true,
        },
    },
    legend: {
        align: "right",
        layout: "vertical",
        x: 0,
        verticalAlign: "center",
        y: 100,
        floating: true,
        backgroundColor: "white",
        borderColor: "#CCC",
        borderWidth: 0,
        shadow: true,
    },
    series: [
        {
            name: "Registration",
            colorByPoint: true,
            innerSize: "40%",
            data: [],
        },
    ],
};

export const portfolio = {
    chart: { type: "spline" },
    title: {
        text: "Your Portfolio",
        align: "left",
        style: {
            fontWeight: "bold",
        },
    },
    subtitle: {
        text: "",
        useHTML: true,
        align: "left",
    },
    yAxis: {
        title: { text: "Portfolio" },
    },
    tooltip: {
        crosshairs: true,
        shared: false,
        headerFormat: "",
        // pointFormat: "{series.name}: {point.x}<br/>",
        pointFormatter: function () {
            return `Age:${(this as any)?.x} <br/> Portfolio: ${(this as any)?.y} `;
        },
    },
    plotOptions: {
        spline: {
            marker: {
                radius: 5,
                lineColor: "#666666",
                lineWidth: 1,
            },
        },
    },
    xAxis: {
        minPadding: 0,
        maxPadding: 0,
        tickInterval: 5,
    },
    series: [
        {
            name: "Age",
            marker: { symbol: "circle", radius: 8 },
            data: [],
        },
    ],
};

export const chartConfigs = {
    retirement_income,
    wealth,
    portfolio_composition,
    asset_allocation,
    portfolio,
};
