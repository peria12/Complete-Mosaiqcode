import React, { useEffect, useState } from "react";
import { Button, Checkbox, TextareaAutosize, FormGroup, FormControlLabel } from "@mui/material";
import FTSelect from "common/FTSelect";
import Loader from "common/Loader";
import Api from "utils/api";
import CopyAllIcon from "@mui/icons-material/CopyAll";
import AppCover from "home/dashboad/AppCover";
import { useScreenshot } from "utils/helpers";
import "./style.css";

export default function CustomApi() {
    const [loader, setLoader] = useState(true);
    const [emailData, setEmailData] = useState([]);
    const [algoList, setAlgoList] = useState([]);
    const [selectedEmail, setSelectedEmail] = useState("");
    const [selectedApi, setSelectedApi] = useState("");
    const [apiMethod, setApiMethod] = useState("");
    const [selectedVersion, setSelectedVersion] = useState(false);
    const [generatepayloadonly, setGeneratepayloadonly] = useState(false);
    const [bodyValue, setBodyValue] = useState("");
    const [message, setMessage] = useState("");
    const [copy, setCopy] = useState(false);

    const screenshot = useScreenshot();

    const [statusCode, setStatusCode] = useState(200);

    useEffect(() => {
        if (copy) {
            setTimeout(() => setCopy(false), 2000);
        }
    }, [copy]);

    useEffect(() => {
        Api.getGoeClients({ roleFilter: "CLIENT" })
            .then((response: any) => {
                const newdata = response?.data?.map((x) => {
                    return { key: x.email, value: x.email, disbaled: false };
                });
                if (newdata) setEmailData(newdata);
                setLoader(false);
            })
            .catch((e: any) => {
                console.log("error", e);
                setLoader(false);
            });

        Api.goeApiEndPoint()
            .then((response: any) => {
                const endPoints = response?.api_end_points?.map((x) => {
                    return { key: x.api_end_point, value: x.api_end_point, method: x.method, disbaled: false };
                });
                setAlgoList(endPoints);
                screenshot.take();
            })
            .catch((e: any) => {
                console.log("error", e);
            });
    }, [screenshot]);

    const triggereApi = () => {
        const headerObj = {
            clientemail: selectedEmail,
            version: selectedVersion ? 4 : "",
            generatepayloadonly: generatepayloadonly,
        };
        const bodyObj = apiMethod === "POST" ? (isJson(bodyValue) ? JSON.parse(bodyValue) : {}) : {};
        setMessage("");
        setLoader(true);
        Api.customApiUrl({ header: headerObj, method: apiMethod, apiUrl: selectedApi, body: bodyObj })
            .then((response: any) => {
                setMessage(JSON.stringify(response));
                setStatusCode(response.statusCode);
                if (selectedApi === "/v1/historicalLiveScenarios/callback" && generatepayloadonly != true) {
                    const sub = setInterval(() => {
                        const requestId = response.body.requestId;
                        Api.customApiUrl({
                            header: headerObj,
                            method: "GET",
                            apiUrl: `/v1/historicalLiveScenarios/${requestId}`,
                        })
                            .then((resp) => {
                                if (resp.statusCode != 202) {
                                    setMessage(JSON.stringify(resp));
                                    clearInterval(sub);
                                    setLoader(false);
                                } else {
                                    setMessage(JSON.stringify(resp));
                                }
                            })
                            .catch(() => clearInterval(sub));
                    }, 2000);
                } else {
                    setLoader(false);
                }
            })
            .catch((e: any) => {
                if (e.response) {
                    setLoader(false);
                    // Request made and server responded
                    setStatusCode(e.response.data.statusCode);
                    setMessage(JSON.stringify(e.response.data));
                }
            });
    };

    const handleCheckbox = (item, name) => {
        if (name === "version") {
            setSelectedVersion(item);
        } else {
            setGeneratepayloadonly(item);
        }
    };

    const handleTextArea = (e) => {
        setBodyValue(e.target.value);
    };

    const handleAPi = (item) => {
        let apiMethodVal = "";
        algoList.filter((data) => {
            if (data["key"] === item) {
                apiMethodVal = data["method"];
            }
        });
        setSelectedApi(item);
        setApiMethod(apiMethodVal);
    };

    const isJson = (str) => {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    };

    return (
        <AppCover>
            <div className="mx-1">
                <div className="row">
                    <div className="col-xl-6 col-lg-6 col-12">
                        <div className="row" style={{ marginTop: "15px" }}>
                            <div className=" col-12">
                                <FTSelect
                                    label="Select Algo"
                                    value={selectedApi}
                                    onChange={(item) => {
                                        handleAPi(item);
                                    }}
                                    options={algoList}
                                    style={{ margin: "2rem" }}
                                />
                            </div>
                        </div>

                        <div className="row mt-3">
                            <div className="col-5">
                                <FormGroup>
                                    <FormControlLabel
                                        control={
                                            <Checkbox
                                                onChange={(e) => handleCheckbox(e.target.checked, "version")}
                                                checked={selectedVersion}
                                                size={"small"}
                                                tabIndex={-1}
                                                color="primary"
                                                disableRipple
                                            />
                                        }
                                        label="Version 4"
                                    />
                                </FormGroup>
                            </div>
                            <div className="col-5">
                                <FormGroup>
                                    <FormControlLabel
                                        control={
                                            <Checkbox
                                                onChange={(e) => handleCheckbox(e.target.checked, "payload")}
                                                checked={generatepayloadonly}
                                                size={"small"}
                                                tabIndex={-1}
                                                color="primary"
                                                disableRipple
                                            />
                                        }
                                        label="Generate Payload Only"
                                    />
                                </FormGroup>
                            </div>
                        </div>

                        <div className=" col-12" style={{ marginTop: "25px" }}>
                            <FTSelect
                                label="ClientEmail"
                                value={selectedEmail}
                                onChange={(item) => {
                                    setSelectedEmail(item);
                                }}
                                options={emailData}
                                style={{ margin: "2rem", height: "50px" }}
                            />
                        </div>

                        <div className=" col-12" style={{ marginTop: "25px" }}>
                            <div className="mb-2">Body</div>
                            <TextareaAutosize
                                onChange={(e) => handleTextArea(e)}
                                maxRows={15}
                                minRows={15}
                                aria-label="maximum height"
                                placeholder="Please enter body details"
                                defaultValue={bodyValue}
                                style={{ width: "100%", resize: "none" }}
                            />
                        </div>

                        <div className="float-right  col-12">
                            <Button
                                style={{ float: "right", textTransform: "capitalize", marginTop: "20px" }}
                                variant="contained"
                                disabled={!selectedApi || !selectedEmail}
                                onClick={() => triggereApi()}
                                color="secondary"
                            >
                                Run API
                            </Button>
                        </div>
                    </div>
                    <div className="col-xl-6 col-lg-6 col-12">
                        {loader ? (
                            <Loader />
                        ) : (
                            <div style={{ height: "calc(100vh - 185px)" }}>
                                <TextareaAutosize
                                    disabled
                                    aria-label="maximum height"
                                    placeholder="response"
                                    defaultValue={message}
                                    style={{
                                        width: "100%",
                                        height: "100%",
                                        resize: "none",
                                        color: statusCode === 200 || statusCode === 202 ? "green" : "red",
                                    }}
                                />
                                <div
                                    className="customAPitooltip"
                                    style={{ float: "right", cursor: "pointer" }}
                                    onClick={() => {
                                        navigator.clipboard.writeText(message);
                                        setCopy(true);
                                    }}
                                >
                                    <CopyAllIcon />
                                    {copy ? <span className="customAPitooltiptext">Copied</span> : ""}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </AppCover>
    );
}
