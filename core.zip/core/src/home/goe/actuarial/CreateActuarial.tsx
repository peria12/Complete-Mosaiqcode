import { MuiFormLine } from "common/mui-form/MuiForm";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";
import HeaderPanel from "../common/HeaderPanel";
import Api from "utils/api";
import GoeForm from "../common/GoeForm";
import { FileDownload } from "common/FileDownload";
import { goeActuarialUpdateNotification } from "utils/events";
import Access from "utils/access";
import { AdornedButton } from "common/FTButtons";
import errorNotification from "utils/api-error";
import ConfirmDialog from "common/ConfirmDialog";
import { parseOptions } from "../goe-helper";
import Table from "common/Table";
import Typography from '@mui/material/Typography';

const viewButtons: any = [
    {
        id: "edit",
        label: "Edit",
        adminOnly: true,
    },
];

const saveButtons: any = [
    {
        id: "cancel",
        label: "Cancel",
        color: "secondary",
        adminOnly: true,
    },
    {
        id: "save",
        label: "Save",
        adminOnly: true,
        isLoaderRequired: true,
    },
];

const newBttons: any = [
    {
        id: "create",
        label: "Create",
        adminOnly: true,
        isLoaderRequired: true,
    },
];
const emptyFormData = {
    email: "",
    name: "",
    description: "",
    segment: "",
    country: "",
    channel: "",
    type: "Mortality",
};

const makeForm = (val) => ({
    email: val.createdBy?.email,
    name: val.name,
    description: val.description,
    segment: val.segment?.name,
    country: val.country?.name,
    channel: `${val.segment?.name}_${val.country?.name}`,
    type: val.type?.name,
});

const columns = [
    { Header: "ActuarialId", width: "col-2", accessor: "actuarialid" },
    { Header: "id", accessor: "id", width: "col-2" },
    { Header: "Download", accessor: "path", width: "col-1" },
    { Header: "Active", accessor: "active", width: "col-2" },
    { Header: "CreatedAt", accessor: "createdat", width: "col-2" },
];

export default function CreateActuarial({ match, data }) {
    const methods = useForm<any>({ mode: "onChange", defaultValues: {} });
    const [state, setState] = useState<any>({
        title: "",
        type: "new",
        obj: null,
        btnLoading: false,
        histLoading: false,
    });
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [isAdmin] = useState<any>(Access.hasAccessToZone("goe", "actuarials", ["admin"]));
    const [configStates, setConfigStates] = useState<any>({});
    const [historicalActFiles, setHistoricalActFiles] = useState([]);
    const [loadhistoricalAct, setLoadhistoricalAct] = useState(true);
    const [rows, setRows] = useState([]);
    const country = methods.watch("country");
    const segment = methods.watch("segment");
    useEffect(() => {
        Api.getGoePortfolioEnums().then((porfolioEnums) => {
            if (porfolioEnums) {
                const { countries, segments } = porfolioEnums;
                setConfigStates((configState) => ({
                    ...configState,
                    countries: parseOptions(countries),
                    segments: parseOptions(segments),
                }));
            }
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const history = useHistory();

    const onSubmit = (data) => {
        setState({ ...state, btnLoading: true });
        Api.createGoeActuarial(data)
            .then(() => {
                setState({ ...state, btnLoading: false });
                goeActuarialUpdateNotification.next();
                errorNotification.next({ type: "success", text: "Data table created successfully.", open: true });
                history.push(".");
            })
            .catch((err) => {
                console.log("ERR", err);
                setState({ ...state, btnLoading: false });
            });
    };

    const handler = (id) => {
        if (id == "edit") {
            setState({ ...state, type: "edit", title: `Update ${state.obj?.name}` });
        } else if (id == "cancel") {
            setConfirmOpen(true);
        } else if (id == "create") {
            methods.handleSubmit(onSubmit, (err) => console.log("ERR", err))();
        } else if (id == "save") {
            methods.handleSubmit(
                (data) => {
                    setState({ ...state, btnLoading: true });
                    Api.updateGoeActuarial(state.obj.id, data).then(() => {
                        setState({ ...state, btnLoading: false });
                        goeActuarialUpdateNotification.next();
                        history.push(".");
                    });
                },
                (err) => {
                    setState({ ...state, btnLoading: false });
                    console.log("ERR", err);
                }
            )();
        }
    };

    const handleCancel = () => {
        methods.reset(makeForm(state.obj));
        setState({ ...state, type: "view", title: `View ${state.obj?.name}` });
    };

    useEffect(() => {
        const id = match.params.id;
        const value = (data || []).find((x) => x.id == id);
        // const inactive_values = (data || []).find((x) => x.id == id);
        if (value) {
            const val = value.orig;
            methods.reset(makeForm(val));
            setState({ ...state, title: `View ${val.name}`, type: "view", obj: val });
        } else {
            methods.reset({ ...emptyFormData, email: Access.userInfo.email });
            setState({ ...state, title: "Create New Data Table", type: "new", obj: null });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        const row = {
            actuarialid: "",
            id: "",
            path: "",
            createdat: "",
            status: "",
        };
        if (value) {
            Api.getHistoricalActuarialFiles(id)
                .then((data) => {
                    console.log("getHistoricalActuarialFiles", data);
                    setHistoricalActFiles(data);
                    setLoadhistoricalAct(false);
                    const newData = data
                        .filter((item) => item.files.active === false)
                        .map((item) => {
                            return {
                                ...row,
                                actuarialid: item.files.actuarialId,
                                id: item.files.id,
                                // path: <a href={`/api/file-id/${item.files.path.replace('actuarialTypeFile-', '')}`}>{item.files.path.replace("actuarialTypeFile-", "")}</a>,
                                path: (
                                    <FileDownload file_id={item.files.path.replace("actuarialTypeFile-", "")}>
                                        <AdornedButton variant="contained" color="primary">
                                            View
                                        </AdornedButton>
                                    </FileDownload>
                                ),
                                createdat: item.files.createdAt,
                                active: item.files.active === null || item.files.active ? "Active" : "Inactive",
                            };
                        });
                    console.log("newData", newData);
                    setRows(newData);
                    console.log("rows", rows);
                })
                .catch((err) => {
                    console.log("ERR", err);
                });
        }
    }, [match.params.id, data]);

    const getFileId = () => {
        return state.obj?.files?.path.split("-")[1];
    };

    if (country && segment) {
        methods.setValue("channel", `${country}_${segment}`);
    }

    return (
        <>
            <HeaderPanel
                title={state.title}
                onBack={() => history.push(".")}
                buttons={state.type == "new" ? newBttons : state.type == "view" ? viewButtons : saveButtons}
                handler={handler}
                state={state}
                isAdmin={isAdmin}
            />
            <div style={{ background: "white", maxWidth: "800px" }} className="mx-4 p-3">
                <MuiFormLine
                    field={{
                        label: "EMAIL",
                        placeholder: "Email",
                        name: "email",
                        type: "email",
                        required: false,
                        disabled: true,
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "DATA TABLE NAME",
                        placeholder: "Data Table Name",
                        name: "name",
                        type: "text",
                        disabled: state.type == "view",
                        required: true,
                        tooltip: "US_MORTALITY_2021 naming convention",
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "DATA TABLE DESCRIPTION",
                        placeholder: "Data Table Description",
                        name: "description",
                        type: "text",
                        disabled: state.type == "view",
                        required: true,
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "SEGMENT",
                        placeholder: "Segment",
                        name: "segment",
                        type: "select",
                        options: configStates.segments || [],
                        disabled: state.type == "view",
                        required: true,
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "COUNTRY",
                        placeholder: "Country",
                        name: "country",
                        type: "select",
                        options: configStates.countries || [],
                        disabled: state.type == "view",
                        required: true,
                    }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{ label: "CHANNEL", placeholder: "Channel", name: "channel", type: "text", disabled: true }}
                    methods={methods}
                />

                <MuiFormLine
                    field={{
                        label: "TYPE",
                        name: "type",
                        type: "select",
                        skipRequired: true,
                        options: [
                            { key: "Mortality", value: "Mortality" },
                            { key: "LifeExpectancy", value: "Life Expectancy" },
                            { key: "AgeBasedGlidePath", value: "Age Based Glide Path" },
                            { key: "AgeBasedEquityCap", value: "Age Based Equity Cap" },
                            { key: "BendPoints", value: "Bend Points" },
                            { key: "BenefitsAcrossRetirementAges", value: "Benefits Across Retirement Ages" },
                            { key: "BenefitBase", value: "Benefit Base" },
                            { key: "CostOfLivingAdjustment", value: "Cost Of Living Adjustment" },
                            { key: "DelayedRetirementCredit", value: "Delayed Retirement Credit" },
                            { key: "IndexFactor", value: "Index Factor" },
                            { key: "MortalityGenericMale", value: "Mortality Generic Male" },
                            { key: "MortalityGenericFemale", value: "Mortality Generic Female" },
                            { key: "MortalityByLifestyle", value: "Mortality By Lifestyle" },
                            { key: "FullRetirementAge", value: "Full Retirement Age" },
                            {
                                key: "PortfolioMapAggRetirementAccounts-H",
                                value: "Portfolio Map Agg Retirement Accounts-H",
                            },
                            { key: "TaxBracket", value: "Tax Bracket" },
                            { key: "RIConfigParam", value: "RI Config Param" },
                            { key: "FixedDiscretionary", value: "Fixed Discretionary" },
                            { key: "LYTargetAllocations", value: "LY Target Allocations" },
                            { key: "LYCMEPackage", value: "LY CME Package" },
                            { key: "DecumulationLookUp", value: "DecumulationLookUp" },
                            { key: "GoalDiscoveryLookUp", value: "GoalDiscoveryLookUp" },
                            { key: "FTLongTermCME", value: "FTLongTermCME" },
                            { key: "HistoricalIndexList", value: "HistoricalIndexList" },
                        ],
                        disabled: state.type == "view",
                        required: true,
                    }}
                    methods={methods}
                />

                {state.type == "view" ? (
                    <GoeForm label="FILE">
                        <FileDownload file_id={getFileId()}>
                            <AdornedButton variant="contained" color="primary">
                                View
                            </AdornedButton>
                        </FileDownload>
                    </GoeForm>
                ) : (
                    <MuiFormLine
                        field={{
                            label: "FILE",
                            name: "file",
                            type: "files",
                            required: true,
                            accept: ".csv",
                            text: "Drag and Drop or Select a CSV File",
                        }}
                        methods={methods}
                    />
                )}
            </div>
            <ConfirmDialog
                title={`Are you sure you want to cancel?`}
                open={confirmOpen}
                setOpen={setConfirmOpen}
                onConfirm={handleCancel}
            >
                You will lose all the information if you leave this page.
            </ConfirmDialog>
            <div>
                {state.type == "view" ? (
                    loadhistoricalAct ? (
                        <div>Loading...</div>
                    ) : rows.length > 0 ? (
                        <div>
                            <div className="px-3 pb-3">
                                <Typography>Historical Data</Typography>
                                <Table columns={columns || []} data={rows || []} loading={!rows} ></Table>
                            </div>
                        </div>
                    ) : (
                        <div></div>
                    )
                ) : (
                    <div></div>
                )}
            </div>
        </>
    );
}
