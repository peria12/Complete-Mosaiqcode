import React, { useEffect } from "react";

import { useParams } from "react-router-dom";
import Api from "utils/api";

export function Download() {
    const params = useParams();
    useEffect(() => {
        Api.getFileRaw(params.id).then((resp: any) => {
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(new Blob([resp.data]));
            link.download = resp.headers["content-disposition"].split("filename=")[1].split('"').join("");
            link.click();
        });
    }, [params.id]);
    return <></>;
}
